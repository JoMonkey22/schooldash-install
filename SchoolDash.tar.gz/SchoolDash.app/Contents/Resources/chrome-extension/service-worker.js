/* SchoolDash Bridge — the fetching half.
 *
 * Everything SchoolDash reads from Canvas and Veracross, it normally reads by
 * driving its own headless browser and signing in as the student. That is the
 * most fragile part of the whole program: Google SSO is broken in branded
 * Chrome on a cloud-managed school Mac; a Veracross session lives about
 * thirty minutes and needs a scheduled job to keep it warm; Canvas hands out
 * session-only cookies that REPLACE the persistent ones; and the Veracross
 * login sits behind a reCAPTCHA that no automation may satisfy on its own.
 *
 * The browser the student is sitting in front of has none of those problems.
 * It is already signed in to both.
 *
 * **This file is a courier and nothing else.** It asks the app which pages it
 * wants, fetches those URLs with the cookies already in this profile, and
 * posts the bodies back. It parses nothing — SchoolDash parses a bridged page
 * with exactly the code it uses for its own fetches, because two parsers for
 * one document is how they come to disagree. And it knows nothing about any
 * school: the URLs come from the app, whose config already holds them, so a
 * classmate elsewhere needs no change here.
 *
 * Nothing is sent anywhere except 127.0.0.1. No server, no analytics, no
 * account. A password is never seen, asked for or stored — the entire point
 * is to use a session that already exists.
 *
 * The app names the URLs, so the app could in principle name a bad one. Every
 * URL is checked against this file's own host allowlist before it is fetched,
 * because "the app tells the browser what to fetch" is otherwise a
 * redirection primitive pointed at a browser holding live school sessions.
 *
 * Service workers are ephemeral, so nothing is kept in a variable between
 * events: every listener re-reads chrome.storage, and the sweep is a
 * chrome.alarms alarm rather than setInterval.
 */

const APP = "http://127.0.0.1:5055";
const ALARM = "schooldash-sweep";

/* Must agree with bridge.ALLOWED_HOSTS in the app. Checked on both sides on
 * purpose: the app is the party that could be wrong. */
const ALLOWED = [".instructure.com", "portals.veracross.com",
                 "portals-embed.veracross.com", "documents.veracross.com"];

function hostAllowed(url) {
  let parsed;
  try { parsed = new URL(url); } catch (err) { return false; }
  if (parsed.protocol !== "https:") return false;
  const host = parsed.hostname.toLowerCase();
  return ALLOWED.some((ok) => host === ok || host.endsWith(ok));
}

async function token() {
  const { token } = await chrome.storage.local.get("token");
  return token || "";
}

/* ---------------- talking to the app ---------------- */

async function ask(pairing) {
  const response = await fetch(`${APP}/api/bridge/status`, {
    headers: { "X-SchoolDash-Token": pairing } });
  if (response.status === 403) {
    throw new Error("that pairing code is not this Mac's — copy it again "
      + "from SchoolDash Settings");
  }
  if (!response.ok) throw new Error(`the app answered ${response.status}`);
  return await response.json();
}

async function send(kind, key, body, url, pairing) {
  const response = await fetch(`${APP}/api/bridge/capture`, {
    method: "POST",
    headers: { "Content-Type": "application/json",
               "X-SchoolDash-Token": pairing },
    body: JSON.stringify({ kind, key, body, url }),
  });
  let payload = {};
  try { payload = await response.json(); } catch (err) { /* not JSON */ }
  if (!response.ok || payload.error) {
    throw new Error((payload.error && payload.error.message)
      || `the app answered ${response.status}`);
  }
  return payload.saved;
}

/* ---------------- reading the school's pages ---------------- */

/* `credentials: "include"` is the whole reason this extension exists: the
 * cookies already in this profile. Without it the fetch is anonymous and
 * Veracross answers with a sign-in screen — which would then be posted back
 * and parsed as a gradebook holding no marks. So a reply that is plainly a
 * login page is refused here rather than handed on. */
async function grab(url) {
  const response = await fetch(url, {
    credentials: "include",
    redirect: "follow",
    headers: { "Accept": "text/html,application/json;q=0.9,*/*;q=0.8" },
  });
  if (!response.ok) throw new Error(`answered ${response.status}`);
  const text = await response.text();
  const head = text.slice(0, 4000);
  if (/id="?username|Sign in with Google|<title>[^<]*(Log ?in|Sign ?in)/i.test(head)) {
    throw new Error("came back as a sign-in screen — open it in a tab, "
      + "sign in, then try again");
  }
  if (!text.trim()) throw new Error("came back empty");
  return text;
}

/* ---------------- the one job everything calls ---------------- */

async function runCapture() {
  const pairing = await token();
  if (!pairing) {
    return { ok: false, sent: 0,
             problems: ["not paired yet — paste the code from SchoolDash Settings"] };
  }
  let status;
  try {
    status = await ask(pairing);
  } catch (err) {
    const why = /pairing code/.test(err.message) ? err.message
      : "SchoolDash is not running on this Mac. Open it and try again.";
    return { ok: false, sent: 0, problems: [why] };
  }

  const problems = [];
  let sent = 0;
  const list = Array.isArray(status.wanted) ? status.wanted : [];
  if (!list.length) {
    problems.push(status.wanted_error
      || "nothing to fetch — everything the app wanted is already fresh");
  }
  for (const item of list) {
    const label = item.name || item.key || item.kind;
    if (!hostAllowed(item.url)) {
      problems.push(`${label}: refused — ${item.url} is not a school address`);
      continue;
    }
    try {
      await send(item.kind, item.key, await grab(item.url), item.url, pairing);
      sent += 1;
    } catch (err) {
      problems.push(`${label}: ${err.message}`);
    }
  }
  const at = Date.now();
  await chrome.storage.local.set({ lastRun: at, lastSent: sent,
                                   lastProblems: problems.slice(0, 6) });
  await chrome.action.setBadgeText({ text: sent ? String(sent) : "" });
  await chrome.action.setBadgeBackgroundColor({
    color: sent ? "#2563EB" : "#B03024" });
  return { ok: sent > 0, sent, problems, at };
}

/* ---------------- wiring ---------------- */

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      if (message && message.type === "capture") {
        sendResponse(await runCapture());
        return;
      }
      if (message && message.type === "status") {
        const pairing = await token();
        const saved = await chrome.storage.local.get(
          ["lastRun", "lastSent", "lastProblems", "auto"]);
        let app = { running: false, paired: false, held: 0, wanted: 0 };
        if (pairing) {
          try {
            const status = await ask(pairing);
            app = { running: true, paired: true,
                    held: Object.values(status.held || {})
                      .reduce((total, rows) => total + rows.length, 0),
                    wanted: (status.wanted || []).length,
                    freshMinutes: status.fresh_minutes };
          } catch (err) {
            app = { running: !/not running/.test(err.message), paired: false,
                    why: err.message, held: 0, wanted: 0 };
          }
        }
        sendResponse({ paired: !!pairing, app, ...saved });
        return;
      }
      sendResponse({ ok: false });
    } catch (err) {
      sendResponse({ ok: false, sent: 0,
                     problems: [String((err && err.message) || err)] });
    }
  })();
  return true;                 // the channel stays open for the async reply
});

chrome.runtime.onInstalled.addListener(async () => {
  // Hourly, not every few minutes: a gradebook changes when a teacher marks
  // something, and the app treats a capture as fresh for four hours anyway.
  await chrome.alarms.create(ALARM, { periodInMinutes: 60, delayInMinutes: 2 });
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== ALARM) return;
  const saved = await chrome.storage.local.get(["auto", "token"]);
  if (saved.auto === false || !saved.token) return;
  try {
    await runCapture();
  } catch (err) {
    // A failed sweep is not worth a notification. The popup says why, and the
    // app carries on signing in for itself exactly as it did before.
    console.warn("[schooldash] hourly capture failed:", err);
  }
});
