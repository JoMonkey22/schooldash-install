# Setting up SchoolDash from the repo

For someone who has been given access to this GitHub repository. It takes
about ten minutes, most of which is waiting. **No administrator password is
needed at any point**, which matters on a school-managed Mac.

You need: a Mac (macOS 12 or later), your school Google account, and access to
this repo.

There are two ways through this. They install exactly the same thing.

- **With Claude Code** — paste the prompt in [`CLAUDE-SETUP-PROMPT.md`](CLAUDE-SETUP-PROMPT.md)
  and it does steps 1–3 for you, then hands the app back to you for step 4.
- **By hand** — the four steps below.

The same thing as a printable handout, with screenshots of every setup screen:
[`packaging/setup-guide/SchoolDash-Setup-Guide.pdf`](packaging/setup-guide/SchoolDash-Setup-Guide.pdf).

---

## 1. Get the code

Open **Terminal** (⌘-Space, type "Terminal") and paste:

```bash
git clone https://github.com/ElMagoCT/schooldash.git ~/schooldash
```

If macOS offers to install the **Xcode Command Line Tools**, click **Install**
and wait for it to finish, then run the line again. That is what provides
`git`; it needs no password.

If git asks for a username and password, you do not have access to the repo
yet — ask whoever sent you here.

## 2. Run the setup script

```bash
cd ~/schooldash && ./packaging/setup-from-git.sh
```

It builds SchoolDash from the source you just cloned, puts it in your
`~/Applications`, pins it to your Dock, and opens it. Two or three minutes.

**The first launch then downloads what it needs** — its own Python and a copy
of Chromium, about 150 MB — and you get a notification when that is done. This
is the slow part, and it happens once.

Two things worth knowing:

- **Gatekeeper will not stop you.** Because the app is built on your own Mac
  rather than downloaded by a browser, macOS never tags it as quarantined, so
  you will not see *"Apple could not verify SchoolDash is free of malware"* and
  you will not need the System Settings detour.
- **It installs into your home folder only.** Nothing is written outside
  `~/Applications` and `~/Library/Application Support/SchoolDash`.

## 3. The window opens on Setup

Five steps across the top. Each one can be retried on its own, and you can
leave and come back.

**Step 1 — your sign-ins.** Your school Google email and password. Canvas and
Veracross both log in with your school Google account, so SchoolDash saves it
once and signs in for you — the first time, and every later time a session runs
out — instead of asking you again.

The password is kept in a file only your account can read, on your Mac. It is
never sent anywhere except the Google sign-in page itself. If Google asks for a
phone tap or a code, a window opens for you to do that one step yourself.

**Step 2 — connect.** Press **Open the sign-in windows**. SchoolDash signs in
to Canvas and Veracross, finds your class-schedule feed, and checks it can read
your grades. Tick *"Stay signed in"* on Canvas if it offers.

**Step 3 — your classes.** Press **Detect materials and learn my classes**. For
each class it finds the textbook, the syllabus, the teacher's homework doc and
the tools that class uses. Check them, fix anything wrong, add what it missed.

**Step 4 — first pull.** Press **Pull my homework now**. Seven to twenty
seconds. Optionally turn on the 7am / 5pm reminders.

Then **Open the board**.

## 4. Daily use

Open SchoolDash from the Dock. It refreshes itself every half hour while the
Mac is awake; **Refresh** gets you the latest right now.

If nothing opens, the reason is in
`~/Library/Application Support/SchoolDash/logs/schooldash.log`, and a stuck
sign-in leaves a screenshot in `logs/login-shots/`.

---

## Updating later

```bash
cd ~/schooldash && git pull && ./packaging/setup-from-git.sh
```

Your sign-ins, classes and history live outside the app bundle, so they
survive this untouched.

## Which school this works for

The shipped configuration is **Brophy College Preparatory** — its Canvas host
and its Veracross portal. Another school would need those changed in
`config.example.json` before step 2; there is no config wizard for it yet.

## About the class profiles

A *profile* is how SchoolDash knows the way one teacher writes their homework
doc. The repo ships the ones in `seed-profiles/`, and setup copies in any you
are missing without ever overwriting one of your own.

This matters more than it sounds. A profile describes the *teacher's* doc, so
it is the same for everyone in that class, and nothing student-specific is in
one. Measured against the golden fixtures, with no profile and no AI:

| course | with a profile | heuristics only |
| --- | --- | --- |
| AP Chemistry | 31 | 31 |
| AP Physics C | 98 | 98 |
| AP English Literature | 24 | **1** |
| Science and Religion | 4 | **0** |

Table-shaped docs read fine without one. Prose-shaped docs are lost almost
entirely, and lost *silently*. So if you have a class nobody has profiled,
`run.py health` will say that course is `heuristic` rather than `learned` — and
with Claude Code you can teach it:

```bash
PY="$HOME/Library/Application Support/SchoolDash/venv/bin/python"
cd ~/Applications/SchoolDash.app/Contents/Resources/app
"$PY" run.py setup --profile-all
```

Claude Code is optional. Without it you still get everything except the chat
box and the ability to learn a teacher nobody has profiled yet — reading a doc
through an existing profile is deterministic and runs no model at all.

## Checking it worked

```bash
PY="$HOME/Library/Application Support/SchoolDash/venv/bin/python"
cd ~/Applications/SchoolDash.app/Contents/Resources/app
"$PY" run.py health
```

That prints whether Canvas and the schedule feed are connected, when the last
pull was, and which courses are `learned` versus `heuristic`.
