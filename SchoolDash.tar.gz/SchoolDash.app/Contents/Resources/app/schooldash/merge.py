"""Merge & dedupe. Order matters (spec §10.9):

1. doc items dedupe against each other (the same deadline written twice —
   "Homework: finish X" on the day set, "Due Today: X" on the day wanted)
2. Canvas wins on a duplicate — authoritative date, points, submitted — but the
   doc's links and detail are KEPT (the doc often carries the AP Classroom link
   Canvas lacks), and merged_from records the absorbed id
3. Veracross / canvas-ics items merge last, lowest precedence

Every merge is logged so a wrong merge is discoverable.
"""

import re
from datetime import date

from schooldash.logging_setup import get
from schooldash.models import Item

log = get("merge")

# Words, and numbers WITH their separators intact.
#
# [MEASURED] 2026-09-03: splitting on the dot turned "2.1" and "2.2" both into
# {"2"}, and "Chapters 2-5" and "Chapters 6-9" into a shared "chapters" plus
# digits that overlapped as often as not. A section number is one name, not a
# sequence of digits — "2.1" identifies work the way "Alchemist" does — so it
# is tokenised whole. Colons stay out, so a time ("11:59") does not become one
# token pretending to be a section.
WORD = re.compile(r"[a-z]+|\d+(?:[.\-/]\d+)*")


def _words(text: str) -> set[str]:
    """The tokens that identify a piece of work.

    Words of three letters or more, PLUS numbers of two digits or more.
    [MEASURED] 2026-09-02: dropping every short token reduced
    "2.1 #27-49 (odds)" to {"odds"}, so every problem set in Honors Algebra
    ending "(odds)" matched every other at Jaccard 1.0 — and "2.1 HW: #27-49",
    which he had to tell us about, was absorbed into "2.2 HW: #109-131" and
    vanished from the board.

    In maths homework the page numbers ARE the name of the work.

    [MEASURED] 2026-09-03, and this is the second half of the same fix. The
    first version kept numbers of two digits or more and wrote the gap down as
    a decision — "single digits stay out, being mostly section counters".
    They are not counters, they are names:

        Chapters 2-5   vs  Chapters 6-9        both -> {chapters}
        Notes 2.1      vs  Notes 2.2           both -> {notes}
        Quiz 2         vs  Quiz 3              both -> {quiz}

    `dedupe_docs` matches within one date, so four of five such pairs lost an
    item. Nothing had broken on his board only because those happen to fall on
    different days; two quizzes announced for one class would have cost him a
    quiz.

    So: every token carrying a digit counts, at any length. That follows the
    rule stated in the next sentence rather than contradicting it — keeping
    digits is the MORE discriminative direction, and a missed merge shows a
    duplicate while a false merge hides work.
    """
    return {w for w in WORD.findall((text or "").lower())
            if len(w) > 2 or any(c.isdigit() for c in w)}


def _due(item: Item) -> date | None:
    return date.fromisoformat(item.due_date) if item.due_date else None


# "100 points", "15 pts", "5 points." — a mark a teacher wrote into the line.
RE_STATED_MARK = re.compile(r"\b(\d{1,3})\s*(?:pts?|points?)\b", re.I)

# How far apart a doc's statement of a deadline and Canvas's may be and still
# be the same work. One day, because a teacher who moves a deadline restates
# it — [MEASURED] AI Frontiers' doc says both "Due Friday, Sep. 25" and "due
# Sep 26" for one project — and because a doc line stating a date without a
# time is a day out whenever Canvas's deadline is 23:59.
MARK_DATE_SLACK_DAYS = 1


def _stated_mark(item: Item) -> int | None:
    """The mark a doc line claims for itself, if it claims one."""
    for text in (item.title, item.detail):
        match = RE_STATED_MARK.search(text or "")
        if match:
            return int(match.group(1))
    return None


def _same_marked_work(canvas: Item, doc: Item) -> bool:
    """Canvas names the work; the teacher describes it. Match on the mark.

    [MEASURED] 2026-09-02: "Side Hustle Proposal" (Canvas, 100 points, due
    Sep 25) and "100 points. Due Friday, Sep. 25, 11:59 PM. This is the
    project everything since Aug 18 has been feeding." (the teacher's doc)
    share not one word of their titles, so word overlap can never see it — and
    the board carried the same project three times.

    What both state is the mark and the day, and a course does not usually
    hold two different 100-point assignments due within a day of each other.
    Narrow on purpose: the doc line must state a mark, the marks must be
    equal, and the dates must be within a day.
    """
    if canvas.course_key != doc.course_key:
        return False
    if canvas.points is None:
        return False
    mark = _stated_mark(doc)
    if mark is None or int(canvas.points) != mark:
        return False
    canvas_day, doc_day = _due(canvas), _due(doc)
    if not canvas_day or not doc_day:
        return False
    return abs((canvas_day - doc_day).days) <= MARK_DATE_SLACK_DAYS


def _numbers(words: set[str]) -> set[str]:
    return {w for w in words if w[:1].isdigit()}


def _same_work(a: Item, b: Item, window_days: int) -> bool:
    if a.course_key != b.course_key:
        return False
    a_words, b_words = _words(a.title), _words(b.title)
    if not a_words or not b_words:
        return False
    # Different numbers mean different work, however alike the words are.
    #
    # [MEASURED] 2026-09-03: "True Diary Chapters 2-5 are due with highlighted
    # characters" and the same sentence with "6-9" share eight words of ten and
    # score 0.80 — comfortably a merge, and one chapter range would be gone.
    # The overlap cannot see that the single token they differ on is the only
    # part that names the work.
    #
    # Disjoint, not unequal: {2.1} and {2.1, 27-49} are the same section
    # described in more detail by one source, and those SHOULD merge. Two sets
    # that share nothing are two pieces of work. An item with no numbers at all
    # tells us nothing either way, so the word overlap below decides.
    a_nums, b_nums = _numbers(a_words), _numbers(b_words)
    if a_nums and b_nums and not (a_nums & b_nums):
        return False
    smaller = min(len(a_words), len(b_words))
    if not smaller or len(a_words & b_words) / smaller < 0.7:
        return False
    da, db_ = _due(a), _due(b)
    if da and db_:
        return abs((da - db_).days) <= window_days
    return True


def dedupe_docs(doc_items: list[Item]) -> list[Item]:
    """Collapse the same deadline written twice in one doc. The longer wording
    is kept because it carries the instructions."""
    kept: list[Item] = []
    for item in sorted(doc_items, key=lambda i: -len(i.title or "")):
        twin = next((k for k in kept if _same_work(item, k, 0)), None)
        if twin is None:
            kept.append(item)
        else:
            twin.merged_from.append(f"doc:{item.item_id}")
            seen = {l.url if hasattr(l, "url") else l.get("url") for l in twin.links}
            for link in item.links:
                url = link.url if hasattr(link, "url") else link.get("url")
                if url not in seen:
                    twin.links.append(link)
            log.info("doc dedupe: %r absorbed %r", twin.title[:50], item.title[:50])
    return kept


def merge(canvas_items: list[Item], doc_items: list[Item],
          window_days: int = 3, report: list | None = None) -> list[Item]:
    """Canvas wins where both describe the same work; the doc copy's links and
    detail survive on the winner.

    `report` collects the cases where the two sources disagreed about the DATE.
    Canvas is authoritative, so the disagreement is resolved silently — but it
    is also the only independent check on whether a class profile reads its
    teacher's doc correctly, and a class whose doc is consistently one meeting
    out has a profile bug, not bad luck. The pipeline looks for that pattern.
    """
    kept_docs: list[Item] = []
    for item in dedupe_docs(doc_items):
        winner = next((c for c in canvas_items
                       if _same_work(item, c, window_days)), None)
        if winner is None:
            # Canvas names the work and the teacher describes it, so their
            # words can share nothing at all. The mark and the day are what
            # both state (see _same_marked_work).
            winner = next((c for c in canvas_items
                           if _same_marked_work(c, item)), None)
        if winner is None:
            kept_docs.append(item)
            continue
        winner.merged_from.append(f"doc:{item.item_id}")
        if (report is not None and item.due_date and winner.due_date
                and item.due_date != winner.due_date):
            report.append({"course_key": item.course_key,
                           "course": item.course,
                           "title": winner.title,
                           "doc_date": item.due_date,
                           "canvas_date": winner.due_date})
        seen = {l.url if hasattr(l, "url") else l.get("url") for l in winner.links}
        for link in item.links:
            url = link.url if hasattr(link, "url") else link.get("url")
            if url and url not in seen:
                winner.links.append(link)
                seen.add(url)
        if len(item.detail or "") > len(winner.detail or ""):
            winner.detail = item.detail
        if item.date_note and "Canvas" in winner.date_note:
            winner.date_note = (f"{winner.date_note}; the course doc says: "
                                f"{item.date_note}")
        log.info("canvas wins: %r absorbed doc %r", winner.title[:50],
                 item.title[:50])
    return list(canvas_items) + kept_docs


def merge_secondary(primary: list[Item], secondary: list[Item],
                    window_days: int = 3) -> list[Item]:
    """Veracross / canvas-ics fallback items: appended only when nothing
    already covers the same work."""
    out = list(primary)
    for item in secondary:
        twin = next((p for p in out if _same_work(item, p, window_days)), None)
        if twin is None:
            out.append(item)
        else:
            twin.merged_from.append(f"{item.source}:{item.item_id}")
    return out
