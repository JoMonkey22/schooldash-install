"""One-time import from the predecessor assignment-tracker project.

Translates its flat config.json into the new shape and points the browser
profile at the existing logged-in session, so nobody re-logs-in. Reads
only his own local files; prints redacted values only.
"""

import json

from schooldash import config, paths
from schooldash.logging_setup import get

log = get("legacy_import")


def import_doc_done(items, doc_done: dict, conn) -> int:
    """One-time: map an existing doc_done.json (keyed by the predecessor's
    doc_id recipe) onto the new item_ids via each item's legacy_doc_id.
    Returns how many keys matched. Never claims success on a zero match —
    the caller reports the count."""
    from schooldash import db
    matched = 0
    by_legacy = {}
    for item in items:
        legacy_id = item.get("legacy_doc_id") if isinstance(item, dict) \
            else item.legacy_doc_id
        if legacy_id:
            item_id = item.get("item_id") if isinstance(item, dict) else item.item_id
            by_legacy[legacy_id] = item_id
    for key in doc_done or {}:
        if key in by_legacy:
            db.set_done(conn, by_legacy[key], True)
            matched += 1
    return matched


def cli_import() -> int:
    tracker = paths.legacy_tracker_dir()
    source = tracker / "config.json"
    if not source.exists():
        print(f"no predecessor config found at {source}")
        print("Set feeds up fresh instead: python run.py login --veracross")
        return 1

    try:
        old = json.loads(source.read_text(encoding="utf-8"))
    except ValueError as exc:
        print(f"predecessor config.json is not valid JSON: {exc}")
        return 1

    updates = {
        "school": {"time_zone": old.get("time_zone") or "America/Phoenix"},
        "canvas": {"name": old.get("canvas_name") or ""},
        "veracross": {
            "class_ics": old.get("veracross_class_ics") or "",
            "assignments_ics": old.get("veracross_assignments_ics") or "",
        },
        "canvas_ics": old.get("canvas_ics_url") or "",
        # Prior doc discovery: {canvas_course_id: {name, kind, file_id, course_url}}.
        # Used as a starting point by discovery/profiling, then superseded.
        "legacy_course_docs": old.get("course_docs") or {},
    }

    profile = tracker / "browser_profile"
    if profile.exists():
        updates["browser"] = {"profile_dir": str(profile)}

    config.save(updates)
    cfg = config.load(refresh=True)

    print("Imported from the assignment-tracker project:")
    print(f"  class feed        {config.redact(cfg['veracross']['class_ics'])}")
    print(f"  assignments feed  {config.redact(cfg['veracross']['assignments_ics'])}")
    print(f"  canvas ics        {config.redact(cfg['canvas_ics'])}")
    print(f"  course docs       {len(cfg.get('legacy_course_docs') or {})} prior entries")
    print(f"  browser profile   {'reusing existing logged-in profile' if profile.exists() else 'none found'}")
    missing = config.missing_for_refresh(cfg)
    if missing:
        print("Still missing:")
        for line in missing:
            print(f"  - {line}")
    log.info("legacy import completed (%d course docs)", len(cfg.get("legacy_course_docs") or {}))
    return 0
