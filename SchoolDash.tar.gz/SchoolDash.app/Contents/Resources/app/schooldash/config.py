"""Load, validate, and redact config.json.

config.json is secret-bearing: the Veracross and Canvas feed URLs carry their
credential in the URL itself. Nothing in this module (or anywhere else) may
write a real feed URL into a log line, error message, or document — use
redact() whenever a config value might reach output.
"""

import copy
import json
import os
from pathlib import Path

from schooldash import paths

DEFAULTS = {
    "school": {"name": "Brophy College Preparatory", "time_zone": "America/Phoenix"},
    "canvas": {"host": "https://brophyprep.instructure.com", "name": ""},
    "veracross": {
        "class_ics": "",
        "assignments_ics": "",
        "portal": "https://portals.veracross.com/brophyprep/student",
    },
    "canvas_ics": "",
    "window": {"days_back": 8, "days_forward": 14},
    # canvas_pages: homework typed onto the course homepage or a schedule-ish
    # wiki page (schooldash/feeds/canvas_pages.py). canvas_announcements: work
    # named in a recent announcement. Both on by default — [MEASURED]
    # 2026-09-01 a class showed zero homework for a term because its work was
    # only ever on its homepage — and both switchable if a teacher's page ever
    # turns out to be noisy.
    "sources": {"veracross_assignments": False, "canvas_ics_fallback": True,
                "canvas_pages": True, "canvas_announcements": True,
                # Ungraded discussion topics. On by default because they carry
                # real homework — [MEASURED] 2026-09-03, Honors English:
                # "Select 3 movies ... = 15 points", not graded, not in the
                # planner, so it reached the board through nothing at all.
                "canvas_discussions": True},
    "ai": {
        "provider": "auto",
        "profiling_provider": "claude_code",
        "chat_provider": "auto",
        # Haiku 4.5, his choice on 2026-09-03 after seeing the numbers:
        # a chat answer is a short factual lookup over a board the
        # extractor has already done the hard work on, and Haiku costs a
        # fifth of Opus for it. See plans.py for the measured figures.
        "claude_model": "haiku",
        "ollama_model": "llama3.2",
        "ollama_host": "http://127.0.0.1:11434",
        "max_adjudications_per_run": 12,
        # How long ⚡ Accelerate may take to write one guide. Reading the
        # material and producing a structured guide measured 30-90 s; the cap
        # is generous because the alternative is losing the work already done.
        "accelerate_timeout": 420,
    },
    "browser": {"profile_dir": "", "channel": "auto"},
    "server": {"host": "127.0.0.1", "port": 5055, "stale_after_hours": 18},
    "docs": {"include_private": False, "cache_keep": 3},
    "scoring": {"low_priority": 20, "estimate_scale": 0.4},
    # Scheduled macOS banner: fixed clock times, because "7am and 5pm" is
    # something a person can reason about. A slot missed while asleep is
    # skipped rather than queued, matching the publish schedule's behaviour.
    "notify": {"times": ["07:00", "17:00"]},
    # Online account. `server` empty = no gate at all, which is how a solo
    # install runs. The account holds an email and a password hash; homework
    # never leaves this machine either way.
    "account": {"server": "", "required": True},
    "publish": {
        # Remote snapshot page (Master Planner, read-only, encrypted).
        # netlify_site_id + netlify_token enable the scheduled push; the token
        # is a secret — never printed, never committed.
        "netlify_site_id": "",
        "netlify_token": "",
        "passphrase": "",
        "schedule_school": ["06:30", "10:40", "14:20", "17:00"],
        "schedule_off": ["06:00", "12:00"],
    },
}

# Keys whose values are credentials and must never appear in output.
SECRET_PATHS = [
    ("veracross", "class_ics"),
    ("veracross", "assignments_ics"),
    ("canvas_ics",),
    ("publish", "netlify_token"),
    ("publish", "passphrase"),
]

_cached: dict | None = None


class ConfigError(RuntimeError):
    pass


def _merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base)
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _merge(out[key], value)
        else:
            out[key] = value
    return out


def load(path: Path | None = None, refresh: bool = False) -> dict:
    """The full config with defaults filled in. Missing file -> defaults only."""
    global _cached
    if _cached is not None and not refresh and path is None:
        return _cached
    target = path or paths.config_path()
    raw = {}
    if target.exists():
        try:
            raw = json.loads(target.read_text(encoding="utf-8"))
        except ValueError as exc:
            raise ConfigError(f"{target.name} is not valid JSON: {exc}") from exc
    merged = _merge(DEFAULTS, raw)
    _blank_placeholders(merged)
    # A second copy for development can run beside the installed app without
    # editing anyone's config.json: SCHOOLDASH_PORT wins over server.port.
    port_override = os.environ.get("SCHOOLDASH_PORT")
    if port_override and port_override.isdigit():
        merged["server"]["port"] = int(port_override)
    if path is None:
        _cached = merged
    return merged


def _blank_placeholders(cfg: dict) -> None:
    """Turn a copied-from-the-example value into "" in place.

    config.example.json carries `<SECRET FEED URL …>` markers so a human can
    see what belongs there. Copied verbatim, those are non-empty strings, so
    every `if not value` guard downstream reads them as configured — and the
    refresh then tries to fetch a URL whose scheme is a `<`. Normalising here
    means one fix covers missing_for_refresh, the feed readers, and health.
    """
    for keys in SECRET_PATHS:
        node = cfg
        for key in keys[:-1]:
            node = node.get(key)
            if not isinstance(node, dict):
                break
        else:
            value = node.get(keys[-1])
            if isinstance(value, str) and value.startswith("<") and value.endswith(">"):
                node[keys[-1]] = ""


def save(updates: dict, path: Path | None = None) -> dict:
    """Merge-write updates into config.json (like the predecessor's save_config)."""
    global _cached
    target = path or paths.config_path()
    existing = {}
    if target.exists():
        try:
            existing = json.loads(target.read_text(encoding="utf-8"))
        except ValueError:
            existing = {}
    merged = _merge(existing, updates)
    tmp = target.with_suffix(".tmp")
    tmp.write_text(json.dumps(merged, indent=2), encoding="utf-8")
    tmp.replace(target)
    _cached = None
    return load(path=None if path is None else path, refresh=True)


def redact(value: str) -> str:
    """A display-safe form of a secret: never the value itself."""
    if not value:
        return "<not set>"
    return f"<set, {len(value)} chars>"


def missing_for_refresh(cfg: dict | None = None) -> list[str]:
    """What is still needed before a refresh can produce anything.

    Only the class feed is mandatory — everything else degrades gracefully.
    """
    cfg = cfg or load()
    missing = []
    if not cfg["veracross"]["class_ics"]:
        missing.append(
            "veracross.class_ics — the class-schedule feed URL. "
            "Capture it with: python run.py login --veracross"
        )
    return missing


def summary(cfg: dict | None = None) -> dict:
    """A redacted view safe to print or serve."""
    cfg = cfg or load()
    return {
        "school": cfg["school"],
        "canvas_host": cfg["canvas"]["host"],
        "veracross_class_ics": redact(cfg["veracross"]["class_ics"]),
        "veracross_assignments_ics": redact(cfg["veracross"]["assignments_ics"]),
        "canvas_ics": redact(cfg["canvas_ics"]),
        "window": cfg["window"],
        "ai": {k: v for k, v in cfg["ai"].items()},
        "server": cfg["server"],
        "browser": {
            "profile_dir": cfg["browser"]["profile_dir"] or "<default>",
            "channel": cfg["browser"]["channel"],
        },
    }
