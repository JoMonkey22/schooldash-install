"""Structure fingerprint: changes when the SHAPE changes, not the content.

Included: per top-level table (document order) the normalized detected-header
texts and the expanded column count, plus normalized h1–h3 text.
Excluded deliberately: cell contents, row counts, dates, styling, and Google's
per-render CSS class names (regenerated every publish).
"""

import hashlib
import json
import pathlib
import re

from schooldash.docs import tables as tables_mod

_PUNCT = re.compile(r"[^\w\s]")


def _norm(text: str) -> str:
    return " ".join(_PUNCT.sub("", (text or "").lower()).split())


def content_signature(doc_html: str) -> str:
    """A hash of what extraction actually consumes: the visible text and the
    cleaned link targets. Google regenerates CSS class names and ust= link
    timestamps on every render of a published doc, so hashing raw HTML would
    churn on every fetch and defeat the incremental cache."""
    from schooldash.docs import links as links_mod
    _tables, body = tables_mod.parse_tables(doc_html)
    text = " ".join(body.get_text(" ", strip=True).split())
    hrefs = sorted({links_mod.strip_tracking(links_mod.unwrap_google(a["href"]))
                    for a in body.find_all("a", href=True)})
    digest = hashlib.sha1(
        json.dumps([text, hrefs], ensure_ascii=False).encode("utf-8")).hexdigest()
    return f"sig:{digest[:16]}"


def fingerprint(doc_html: str) -> str:
    table_nodes, body = tables_mod.parse_tables(doc_html)
    structure = {"tables": [], "headings": []}
    for node in table_nodes:
        grid = tables_mod.build_grid(node)
        if not grid:
            continue
        header_idx, _rule = tables_mod.detect_header(grid)
        headers = [_norm(c.text) for c in grid[header_idx]] if header_idx >= 0 else []
        structure["tables"].append({
            "headers": headers,
            "columns": len(grid[0]) if grid else 0,
        })
    for heading in body.find_all(["h1", "h2", "h3"]):
        text = _norm(heading.get_text(" ", strip=True))
        if text:
            structure["headings"].append(text)
    digest = hashlib.sha1(
        json.dumps(structure, sort_keys=True).encode("utf-8")).hexdigest()
    return f"sha1:{digest[:16]}"


# ---------------------------------------------------------------------------
# The version of the code that reads a document
#
# Both caches — the doc pipeline's incremental cache and the Canvas pages one —
# ask "has the document changed?" and used to ignore "would we read it
# differently now?".
#
# [PROVEN] tests/test_prosecution.py, twice. The second time cost more: after
# teaching the doc pipeline to read prose, a full refresh still reported
# Honors English 1 as 0 items, because the cache handed back the old empty
# extraction. A stale cache looks exactly like a course with no homework.
#
# Hashing the modules that decide extraction means nobody has to remember to
# bump a version, and a mismatch costs one re-read per document, once.
# Every module whose CODE decides what an item is. A change to any of them
# has to invalidate both caches, because nothing else in the key notices that
# the reader changed — twice already a stale cache has made an improved
# extractor look like a course with no homework.
#
# `cellblocks` was missing from here from the day it was written (0.12.8.0):
# it is the only reader AI Frontiers has, and edits to it changed nothing
# until an unrelated edit to `prose` happened to move the hash. Found
# 2026-09-03 while checking that a prose fix would actually reach the board.
_EXTRACTION_MODULES = ("items", "prose", "cellblocks", "dates", "columns",
                       "tables", "links", "adjudicate", "fingerprint")
_version_cache: str | None = None


def extraction_version() -> str:
    global _version_cache
    if _version_cache is not None:
        return _version_cache
    here = pathlib.Path(__file__).resolve().parent
    digest = hashlib.sha1()
    for name in _EXTRACTION_MODULES:
        try:
            digest.update((here / f"{name}.py").read_bytes())
        except OSError:
            _version_cache = "unknown"
            return _version_cache
    _version_cache = digest.hexdigest()[:8]
    return _version_cache
