"""Link extraction — first-class output, not a byproduct.

The number-one reason link extraction from published docs looks broken is
Google's redirect wrapper: every outbound link becomes
https://www.google.com/url?q=<encoded target>&sa=D&... — take q and decode it.
"""

import posixpath
import re
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse, unquote

from schooldash.models import Link

TRACKING_PARAMS = re.compile(r"^(utm_.*|sa|source|ust|usg|ved|fbclid)$", re.I)


def unwrap_google(href: str) -> str:
    """Handle both google.com/url?q=<target> and the bare form."""
    if not href:
        return ""
    if "google.com/url" in href:
        target = parse_qs(urlparse(href).query).get("q")
        if target:
            return unquote(target[0]) if "%" in target[0] else target[0]
    return href


def strip_tracking(url: str) -> str:
    try:
        parts = urlparse(url)
    except ValueError:
        return url
    if not parts.query:
        return url
    kept = [(k, v) for k, v in
            [pair.split("=", 1) if "=" in pair else (pair, "")
             for pair in parts.query.split("&")]
            if not TRACKING_PARAMS.match(k)]
    return urlunparse(parts._replace(query=urlencode(kept, doseq=False)))


def classify(url: str) -> str:
    """Host+path -> Link.kind. Unknown -> 'other', never dropped."""
    try:
        parts = urlparse(url)
    except ValueError:
        return "other"
    host = (parts.netloc or "").lower()
    path = (parts.path or "").lower()
    if "myap.collegeboard.org" in host or "apclassroom.collegeboard.org" in host:
        return "ap_classroom"
    if "instructure.com" in host:
        return "canvas"
    if host.endswith("docs.google.com"):
        if path.startswith("/document"):
            return "google_doc"
        if path.startswith("/presentation"):
            return "google_slides"
        if path.startswith("/spreadsheets"):
            return "google_sheet"
        if path.startswith("/forms"):
            return "google_form"
        return "google_drive_file"
    if host.endswith("forms.gle"):
        return "google_form"
    if host.endswith("drive.google.com"):
        return "google_drive_file"
    if host.endswith("youtube.com") or host.endswith("youtu.be"):
        return "youtube"
    if path.endswith(".pdf"):
        return "pdf"
    for name in ("quizlet", "kahoot", "desmos", "edpuzzle", "turnitin"):
        if name in host:
            return name
    if "albert.io" in host:
        return "albert"
    if "khanacademy.org" in host:
        return "khan"
    return "other"


def _anchor_text(node, url: str) -> str:
    text = node.get_text(" ", strip=True)
    if text and not text.startswith("http"):
        return text
    # a bare-URL anchor: use the last meaningful path segment
    try:
        segment = posixpath.basename(urlparse(url).path.rstrip("/"))
    except ValueError:
        segment = ""
    return segment or text or url


def extract_links(node, base: str = "") -> list[Link]:
    """Every <a href> under a node -> cleaned, classified, deduped Links."""
    return from_anchors(node.find_all("a", href=True), base)


def from_anchors(anchors, base: str = "") -> list[Link]:
    found: dict[str, Link] = {}
    for anchor in anchors:
        href = anchor["href"].strip()
        if not href or href.startswith("#"):
            continue
        url = strip_tracking(unwrap_google(href))
        if url.startswith("//"):
            url = "https:" + url
        if base and url.startswith("/"):
            url = base.rstrip("/") + url
        if not url.lower().startswith(("http://", "https://")):
            continue
        key = url.rstrip("/").lower()
        link = Link(url=url, text=_anchor_text(anchor, url), kind=classify(url))
        if key in found:
            if len(link.text) > len(found[key].text):
                found[key] = link
        else:
            found[key] = link
    return list(found.values())


BEST_ORDER = ["ap_classroom", "canvas", "google_form"]


def best_link(links: list[Link]) -> str | None:
    """ap_classroom -> canvas -> google_form -> first google_* -> first other."""
    for kind in BEST_ORDER:
        for link in links:
            if link.kind == kind:
                return link.url
    for link in links:
        if link.kind.startswith("google_"):
            return link.url
    return links[0].url if links else None
