"""Doc discovery: course homepage -> embedded Google file candidates, ranked
by KIND, never by page order. Every candidate is recorded with a `why` so a
wrong pick is visible. `run.py discover` is a standing operation — a teacher
swapping, adding, or unpublishing a doc must show up, in plain English.
"""

import re
import time

from schooldash import config
from schooldash.logging_setup import get

log = get("discover")

# Ordered most-specific first: the published patterns must win over the plain
# ones for the same URL.
PATTERNS = [
    ("published-document", re.compile(r"docs\.google\.com/document/d/e/([\w-]{10,})")),
    ("published-spreadsheet", re.compile(r"docs\.google\.com/spreadsheets/d/e/([\w-]{10,})")),
    ("document", re.compile(r"docs\.google\.com/document/d/(?!e/)([\w-]{10,})")),
    ("spreadsheet", re.compile(r"docs\.google\.com/spreadsheets/d/(?!e/)([\w-]{10,})")),
    ("presentation", re.compile(r"docs\.google\.com/presentation/d/(?:e/)?([\w-]{10,})")),
    ("form", re.compile(r"docs\.google\.com/forms/d/e?/?([\w-]{10,})")),
    ("drive-file", re.compile(r"drive\.google\.com/file/d/([\w-]{10,})")),
    ("drive-open", re.compile(r"drive\.google\.com/open\?id=([\w-]{10,})")),
]

RANK = {kind: index for index, (kind, _) in enumerate(PATTERNS)}
KIND_WHY = {
    "published-document": "a published document — the schedule doc is always this kind",
    "document": "an ordinary (private) document — needs a login to read",
    "presentation": "a slide deck, not a schedule",
    "spreadsheet": "a spreadsheet, unlikely to be the schedule",
    "published-spreadsheet": "a published spreadsheet, unlikely to be the schedule",
    "form": "a form, not a schedule",
    "drive-file": "a drive file, not a schedule",
    "drive-open": "a drive link, not a schedule",
}


def candidates(homepage_html: str) -> list[dict]:
    """Every embedded Google file, deduped by id, most-schedule-like first."""
    found: dict[str, dict] = {}
    for kind, pattern in PATTERNS:
        for match in pattern.finditer(homepage_html or ""):
            file_id = match.group(1)
            if file_id in found:
                continue
            url = (f"https://docs.google.com/document/d/e/{file_id}/pub"
                   if kind == "published-document"
                   else match.group(0))
            found[file_id] = {"file_id": file_id, "kind": kind,
                              "url": url if url.startswith("http")
                              else f"https://{url}",
                              "chosen": False, "why": KIND_WHY.get(kind, kind)}
    ranked = sorted(found.values(), key=lambda c: RANK.get(c["kind"], 99))
    return ranked


def pick_schedule_doc(cands: list[dict]) -> dict | None:
    """Published document first, then an ordinary document; never page order."""
    for wanted in ("published-document", "document"):
        matches = [c for c in cands if c["kind"] == wanted]
        if matches:
            chosen = matches[0]
            chosen["chosen"] = True
            chosen["why"] = ("the only published document on the homepage"
                             if wanted == "published-document" and len(matches) == 1
                             else f"the first {wanted} of {len(matches)} on the homepage")
            return chosen
    return None


def scan_courses(context) -> dict[str, dict]:
    """{course_key: {course, canvas_course_id, canvas_url, candidates, chosen}}
    for every dashboard course. Needs the session."""
    from schooldash.feeds import canvas as canvas_mod
    from schooldash.models import course_key_from_raw

    results: dict[str, dict] = {}
    for course in canvas_mod.dashboard_courses(context):
        try:
            html = canvas_mod.homepage_html(context, course.canvas_course_id)
        except Exception as exc:  # noqa: BLE001 — one bad homepage, not the run
            log.warning("homepage failed for %s: %s", course.course_raw, exc)
            results[course.course_key] = {
                "course": course, "candidates": [], "chosen": None,
                "error": str(exc)}
            continue
        cands = candidates(html)
        chosen = pick_schedule_doc(cands)
        results[course.course_key] = {"course": course, "candidates": cands,
                                      "chosen": chosen}
    return results


def cli_discover() -> int:
    from playwright.sync_api import sync_playwright
    from schooldash import browser
    from schooldash.profiling import store

    profiles, _ = store.load_all()
    print("Scanning course homepages for their schedule docs…")
    with sync_playwright() as pw:
        context = browser.open_context(pw, headless=True)
        try:
            if not browser.whoami(context):
                print("the Canvas session is expired — run: python run.py login")
                return 1
            results = scan_courses(context)
        finally:
            browser.close_context(context)

    changes = 0
    for key, entry in sorted(results.items()):
        course = entry["course"]
        chosen = entry["chosen"]
        profile = profiles.get(key)
        old_id = profile.get("doc", "file_id", default=None) if profile else None
        old_source = profile.get("homework_source") if profile else None
        if entry.get("error"):
            print(f"  ! {course.course_raw}: {entry['error']}")
            continue
        if chosen and not old_id:
            changes += 1
            if old_source == "none":
                print(f"  + {course.course_raw}: a doc was NEWLY ADDED to a "
                      f"course previously marked 'none' ({chosen['kind']}). "
                      f"Relearn it: python run.py profile --course {key} --relearn")
            else:
                print(f"  + {course.course_raw}: found a {chosen['kind']}")
        elif chosen and old_id and chosen["file_id"] != old_id:
            changes += 1
            print(f"  ~ {course.course_raw}: the homepage doc CHANGED. "
                  f"Relearn it: python run.py profile --course {key} --relearn")
        elif not chosen and old_id:
            changes += 1
            print(f"  - {course.course_raw}: the doc is gone from the homepage")
        else:
            print(f"    {course.course_raw}: unchanged "
                  f"({chosen['kind'] if chosen else 'no doc'})")
        if profile and chosen:
            raw = profile.raw
            raw.setdefault("doc", {})
            raw["doc"]["candidates"] = entry["candidates"]
            if not profile.get("locked") and chosen["file_id"] != old_id:
                raw["doc"].update({"file_id": chosen["file_id"],
                                   "kind": chosen["kind"], "url": chosen["url"]})
            store.save(raw)

    config.save({"last_discover": time.strftime("%Y-%m-%dT%H:%M:%S")})
    print(f"\n{changes} change(s)." if changes else "\nNo changes.")
    return 0
