"""Date resolution — the hardest part of the pipeline.

Every resolution stamps its own extractor, confidence, and a plain-English
date_note built from the canonical templates below (golden files match them
exactly — never build these strings inline elsewhere).

The two rules that carry the whole feature, both cross-validated against
Canvas by the predecessor:
- Day N rows align to the END of the block when row count ≠ meeting count.
- The weekday letter in a "F, 12"-style cell beats the day number.
"""

import re
from dataclasses import dataclass, field
from datetime import date

# Canonical date_note templates (spec §10.6). En dash between block dates,
# zero-padded days.
NOTES = {
    "day_n_exact": "Day {n} of the {start}–{end} block",
    "day_n_end_aligned": ("Day {n} of the {start}–{end} block — approximate "
                          "({written} days written, {met} classes met)"),
    "day_n_outside": ("Day {n} of the {start}–{end} block — outside the {met} "
                      "classes met"),
    "day_n_no_block": "Day {n}; the doc has no block heading, so it could not be dated",
    "day_n_no_meetings": "Day {n} of the {start}–{end} block; no meetings in the feed",
    "day_n_no_feed": "Day {n}; no class feed to date it against",
    "weekday_mismatch": ("doc says '{cell}'; {claimed_long} is a {actual_weekday}, "
                         "so moved to {chosen}"),
    "weekday_not_meeting": ("doc says '{cell}'; no class that day, so moved to {chosen}"),
    "weekday_exact": "'{cell}' under the {month} heading — {resolved}",
    "absolute_stated": "{stated} as written in the doc",
    "absolute_literal": "no class that day; date taken from the doc as written",
    "absolute_snapped": "assigned {stated}, due next class",
    "homework_shift": "assigned {assigned}, due next class",
    "unresolved": "no date could be determined from the doc; shown so you can check it",
    "adjudicated": "the doc was ambiguous here; this date was inferred — worth checking",
    # Homework typed onto the Canvas page itself rather than into a table
    # (schooldash/docs/prose.py). `where` names the page in the student's own
    # words — "the class homepage", "the page 'Weekly Assignments'" — because
    # "the doc" would be a lie about where they should go to check it.
    "page_stated": "{stated} — {where} says '{heading}'",
    "page_stated_not_class": ("{stated} — {where} says '{heading}', though there "
                              "is no class that day"),
    "page_homework": "assigned {assigned} on {where} under '{heading}', due next class",
    "page_weekday_snapped": ("{where} says '{heading}'; {claimed} is a "
                             "{actual_weekday}, so moved to {chosen}"),
    "page_day_counted": ("Day {n} on {where}, counted forward from '{anchor}' "
                         "— {resolved}"),
    "page_day_counted_back": ("{label} on {where}, counted back from '{anchor}' "
                              "— {resolved}"),
    # Short on purpose: the class is already named beside the item, and this
    # note shares a small panel with the assignment's own words.
    "page_weekday_only": ("{label} on {where} — {resolved}, your only class "
                          "that week"),
    "page_weekday_several": ("{label} on {where} names {named}; you have more "
                             "than one of those that week, so the earlier "
                             "class was taken ({resolved})"),
    "line_deadline": "'{phrase}' as stated in the line itself",
    "cell_deadline": "'{phrase}' — stated once for everything in that cell",
    "labelled_only": ("the doc's '{cell}' — {resolved} is the one your {course} "
                      "actually meets"),
    "labelled_several": ("the doc's '{cell}' names more than one of your {course} "
                         "class days, so the earlier was taken ({resolved})"),
    "page_day_no_anchor": ("Day {n} on {where}; nothing above it gives a date, so "
                           "it could not be dated"),
    "page_unresolved": ("{where} lists this under '{heading}' with no date; shown "
                        "so you can check it"),
    "announcement_dated": "'{phrase}' in the announcement '{title}' ({posted})",
    "announcement_undated": ("from the announcement '{title}' ({posted}); it gave no "
                             "date, so this is shown undated"),
}

MONTHS = {m.lower(): i for i, m in enumerate(
    ["January", "February", "March", "April", "May", "June", "July",
     "August", "September", "October", "November", "December"], 1)}
MONTH_ABBR = {name[:3]: num for name, num in MONTHS.items()}
MONTH_ABBR["sept"] = 9

# "F, 7" / "Tu, 11" / "Th (C), 9" — weekday letters then day of month. Both
# halves are independent claims; the class feed breaks ties (snap_weekday).
RE_WEEKDAY_DAY = re.compile(
    r"^\s*(m|tu|t|w|th|f|sa|su|mon|tue|wed|thu|fri|sat|sun)\b[^,\d]*,\s*(\d{1,2})\s*$", re.I)
WEEKDAYS = {"m": 0, "mon": 0, "tu": 1, "tue": 1, "t": 1, "w": 2, "wed": 2,
            "th": 3, "thu": 3, "f": 4, "fri": 4, "sa": 5, "sat": 5,
            "su": 6, "sun": 6}
# How much of a heading a date_note may quote.
#
# [MEASURED] 2026-09-02 on his own window (995x605 CSS pixels — his screenshot
# was a 2x capture, which is why it looked fine at twice that): the English
# notes ran to 289 characters, printing the 69-character heading "Class 10 :
# Tuesday for Periods 1 & 3 / Wednesday for Periods 5, 6 & 7" TWICE, once to
# say how the date was found and once to say the homework shifted. That wall of
# italic text pushed the assignment's title, date and buttons out of a 244px
# panel: "i can not see the assignment info when I click".
#
# A note still has to explain how the date was worked out (spec §5.9); it does
# not have to transcribe the heading. This trims ONLY where a note is written —
# the full text stays in the data, because the weekdays inside a heading are
# what date it, and trimming first cut "Wednesday" off and broke the dating.
NOTE_LABEL_CHARS = 34


def quote_label(text: str, limit: int = NOTE_LABEL_CHARS) -> str:
    """A heading as a note should quote it: enough to find the line again."""
    label = " ".join((text or "").split())
    if len(label) <= limit:
        return label
    return label[:limit].rstrip(" ,;:-–—") + "…"


WEEKDAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday",
                 "Saturday", "Sunday"]
# "Aug 11", "Sept 3", "August 21", "Aug. 11"
RE_MONTH_DAY = re.compile(r"^\s*([A-Za-z]{3,9})\.?\s+(\d{1,2})(?:st|nd|rd|th)?\s*$")
# "8/27" or "8/27/26"
RE_SLASH_DATE = re.compile(r"^\s*(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?\s*$")
# "Day 3"
RE_DAY_N = re.compile(r"^\s*Day\s*(\d{1,2})\s*$", re.I)
# "Aug 17-21", "Aug 31-Sep 4" — en dash, em dash, hyphen, missing second month
RE_RANGE = re.compile(
    r"([A-Za-z]{3,9})\.?\s*(\d{1,2})\s*[‐‑–—-]\s*(?:([A-Za-z]{3,9})\.?\s*)?(\d{1,2})")
# A standalone month name on its own line (Physics C's "September")
RE_BARE_MONTH = re.compile(r"^\s*([A-Za-z]{3,9})\s*$")
# Cells that mean "no class", not "an assignment"
NON_DAY_WORDS = re.compile(
    r"^(fall|thanksgiving|christmas|spring|easter|winter)?\s*break\s*$|"
    r"^(no school|no class(es)?|holiday|finals?|exam week|tba|tbd)\s*$", re.I)
# Junk that is not an assignment
SKIP_TEXT = re.compile(r"^\s*(none|n/?a|-+|–+|\.|no homework\.?)\s*$", re.I)

DATE_LIKE = re.compile(r"\d")


@dataclass
class Resolution:
    when: date | None
    note: str
    extractor: str
    confidence: str
    flags: list = field(default_factory=list)


def month_number(word: str) -> int | None:
    word = (word or "").strip().lower().rstrip(".")
    if word in MONTHS:
        return MONTHS[word]
    return MONTH_ABBR.get(word[:4]) or MONTH_ABBR.get(word[:3])


def year_for(month: int, year_start: int | None) -> int | None:
    """Aug–Dec belong to the first half of the school year, Jan–Jul the second.
    year_start comes from the class feed's span, never date.today()."""
    if not year_start:
        return None
    return year_start if month >= 7 else year_start + 1


def parse_range(text: str, year_start: int | None):
    """'Aug 17-21 Week 3 Aug 24-28 Week 4' -> (date(8,17), date(8,28))."""
    spans = []
    for m1, d1, m2, d2 in RE_RANGE.findall(text or ""):
        start_month = month_number(m1)
        end_month = month_number(m2) if m2 else start_month
        if not start_month or not end_month:
            continue
        try:
            start = date(year_for(start_month, year_start), start_month, int(d1))
            end = date(year_for(end_month, year_start), end_month, int(d2))
        except (TypeError, ValueError):
            continue
        spans.append((start, end))
    if not spans:
        return None
    return min(s for s, _ in spans), max(e for _, e in spans)


def parse_block_pattern(text: str, pattern: str, year_start: int | None):
    """A profile-supplied block_heading_pattern with start/end named groups."""
    try:
        match = re.search(pattern, text or "")
    except re.error:
        return None
    if not match:
        return None
    combined = f"{match.group('start')} - {match.group('end')}"
    return parse_range(combined, year_start)


def parse_day_cell(text: str, month_hint: int | None, year_start: int | None,
                   date_styles: list[str]):
    """What is the first cell of a row saying?

    Returns (kind, value) with kind in:
      "date"    -> value: date                 (absolute)
      "dayn"    -> value: int                  (rotation Day N)
      "weekday" -> value: (date, weekday, raw) (month_heading / weekday_letter)
      "block"   -> value: (start, end)
      None      -> a break, spacer, or unrecognized
    Only strategies the profile lists are tried, in the listed order.
    """
    text = (text or "").strip()
    if not text or SKIP_TEXT.match(text) or NON_DAY_WORDS.match(text):
        return None, None

    # A heading naming one or two week ranges sets the block, whatever styles say.
    span = parse_range(text, year_start)
    if span and RE_RANGE.search(text) and not RE_MONTH_DAY.match(text):
        return "block", span

    for style in date_styles or []:
        if style == "day_n":
            match = RE_DAY_N.match(text)
            if match:
                return "dayn", int(match.group(1))
        elif style == "absolute":
            match = RE_MONTH_DAY.match(text)
            if match:
                month = month_number(match.group(1))
                if month:
                    try:
                        return "date", date(year_for(month, year_start), month,
                                            int(match.group(2)))
                    except (TypeError, ValueError):
                        return None, None
            match = RE_SLASH_DATE.match(text)
            if match:
                month, day = int(match.group(1)), int(match.group(2))
                year = match.group(3)
                try:
                    when = date(int(year) + (2000 if year and int(year) < 100 else 0)
                                if year else year_for(month, year_start), month, day)
                    return "date", when
                except (TypeError, ValueError):
                    return None, None
        elif style in ("month_heading", "weekday_letter"):
            match = RE_WEEKDAY_DAY.match(text)
            if match and month_hint:
                try:
                    when = date(year_for(month_hint, year_start), month_hint,
                                int(match.group(2)))
                except (TypeError, ValueError):
                    return None, None
                return "weekday", (when, WEEKDAYS.get(match.group(1).lower()), text)
    return None, None


def looks_date_like(text: str) -> bool:
    """For ambiguity flagging: a cell that failed every strategy but carries a
    date-shaped token."""
    text = (text or "").strip()
    if not text or SKIP_TEXT.match(text) or NON_DAY_WORDS.match(text):
        return False
    if not DATE_LIKE.search(text):
        return False
    return bool(RE_MONTH_DAY.match(text) or RE_WEEKDAY_DAY.match(text)
                or RE_DAY_N.match(text) or RE_SLASH_DATE.match(text)
                or RE_RANGE.search(text))


def _span_label(block) -> tuple[str, str]:
    return f"{block[0]:%b %d}", f"{block[1]:%b %d}"


def resolve_day_n(course: str, number: int, block, meetings,
                  rows_in_block: int) -> Resolution:
    """'Day 3' -> a real date via the class's own meetings, END-aligned on a
    mismatch (the Klara rule — see spec §6.5)."""
    if not meetings.available:
        return Resolution(None, NOTES["day_n_no_feed"].format(n=number),
                          "unresolved", "low")
    if not block:
        return Resolution(None, NOTES["day_n_no_block"].format(n=number),
                          "unresolved", "low")

    dates = meetings.in_range(course, block[0], block[1])
    start, end = _span_label(block)
    if not dates:
        return Resolution(None, NOTES["day_n_no_meetings"].format(
            n=number, start=start, end=end), "unresolved", "low")

    if rows_in_block and rows_in_block != len(dates):
        # Align the last written day with the last real meeting.
        index = len(dates) - (rows_in_block - number) - 1
        if 0 <= index < len(dates):
            return Resolution(
                dates[index],
                NOTES["day_n_end_aligned"].format(
                    n=number, start=start, end=end,
                    written=rows_in_block, met=len(dates)),
                "day_n_end_aligned", "medium")
        return Resolution(None, NOTES["day_n_outside"].format(
            n=number, start=start, end=end, met=len(dates)),
            "unresolved", "low")

    if 1 <= number <= len(dates):
        return Resolution(dates[number - 1], NOTES["day_n_exact"].format(
            n=number, start=start, end=end), "day_n_exact", "high")
    return Resolution(None, NOTES["day_n_outside"].format(
        n=number, start=start, end=end, met=len(dates)), "unresolved", "low")


# Every date token anywhere in a cell, not anchored to the whole of it.
RE_ANY_SLASH_DATE = re.compile(r"\b(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?\b")
RE_ANY_MONTH_DAY = re.compile(
    r"\b([A-Za-z]{3,9})\.?\s+(\d{1,2})(?:st|nd|rd|th)?\b")


def dates_in_cell(text: str, year_start: int | None) -> list[date]:
    """Every real date a cell mentions, in the order written.

    The patterns above are deliberately unanchored, unlike the ones
    parse_day_cell uses: a cell that IS a date is a different thing from a cell
    that CONTAINS several.
    """
    found: list[date] = []
    for month, day, year in RE_ANY_SLASH_DATE.findall(text or ""):
        month, day = int(month), int(day)
        resolved_year = (int(year) + (2000 if int(year) < 100 else 0)
                         if year else year_for(month, year_start))
        if not resolved_year or not 1 <= month <= 12:
            continue
        try:
            found.append(date(resolved_year, month, day))
        except ValueError:
            continue
    for word, day in RE_ANY_MONTH_DAY.findall(text or ""):
        month = month_number(word)
        resolved_year = year_for(month, year_start) if month else None
        if not month or not resolved_year:
            continue
        try:
            found.append(date(resolved_year, month, int(day)))
        except ValueError:
            continue
    return found


def resolve_labelled_dates(course: str, text: str, year_start: int | None,
                           meetings) -> Resolution | None:
    """A cell that names one date per class section — "Day 1 / 8/6-A / 8/7-B".

    [MEASURED] 2026-09-02: Honors Algebra 1 produced 16 items and every one was
    undated with extractor "unresolved", because every date pattern here is
    anchored to the whole cell and this cell holds three lines. The date was
    written twice, right there.

    Which section the student is in is not in the document and is never
    assumed — their own timetable answers it. Returns None when none of the
    dates is one of their class days, so the caller can fall back rather than
    have a date invented for it.
    """
    if not meetings.available:
        return None
    candidates = dates_in_cell(text, year_start)
    if len(candidates) < 2:
        return None          # one date is parse_day_cell's job, not this
    mine = sorted({d for d in candidates if meetings.meeting_on(course, d)})
    if not mine:
        return None
    quoted = " ".join((text or "").split())[:40]
    short_course = course.split("-")[0].strip()
    if len(mine) == 1:
        return Resolution(mine[0], NOTES["labelled_only"].format(
            cell=quoted, course=short_course,
            resolved=f"{mine[0]:%a %b %d}"), "absolute", "high")
    return Resolution(mine[0], NOTES["labelled_several"].format(
        cell=quoted, course=short_course,
        resolved=f"{mine[0]:%a %b %d}"), "absolute", "medium",
        ["several_section_dates"])


def resolve_weekday_in_span(course: str, weekdays: set, span, label: str,
                            where: str, meetings) -> Resolution | None:
    """A heading that names weekdays but no date, inside a week that does.

    [MEASURED] Honors English writes "Class 10 : Tuesday for Periods 1 & 3 /
    Wednesday for Periods 5, 6 & 7" — the weekday depends on which period the
    student is in, which the doc cannot know and this must never guess. His own
    timetable settles it: of the days that week, only Wednesday is one his
    English actually meets.

    None when there is nothing to go on, so the caller can try counting.
    """
    if not weekdays or not span or not meetings.available:
        return None
    candidates = [d for d in meetings.in_range(course, span[0], span[1])
                  if d.weekday() in weekdays]
    if not candidates:
        return None
    named = ", ".join(WEEKDAY_NAMES[w] for w in sorted(weekdays))
    if len(candidates) == 1:
        return Resolution(candidates[0], NOTES["page_weekday_only"].format(
            label=quote_label(label), where=where, course=course.split("-")[0].strip(),
            resolved=f"{candidates[0]:%a %b %d}"), "weekday_snapped", "high")
    # Several: the earliest is the safe error — work shown a class early costs
    # nothing, and a class late costs marks.
    return Resolution(candidates[0], NOTES["page_weekday_several"].format(
        label=quote_label(label), where=where, named=named,
        course=course.split("-")[0].strip(),
        resolved=f"{candidates[0]:%a %b %d}"), "weekday_snapped", "medium")


def resolve_day_n_counted(course: str, number: int, anchor: date | None,
                          anchor_number: int, anchor_label: str, meetings,
                          where: str, label_is_class: bool = False) -> Resolution:
    """'Day 4' on a page whose last dated heading was 'Day 1 (8/10)'.

    The doc extractor's resolve_day_n indexes into a block's meetings, because
    a table's rows are bounded by the next block heading. A page section is not
    bounded that way, and [MEASURED] 2026-09-01 the real page proves indexing
    from the block heading is wrong: the "Week 1&2 … - 8/6" section opens with
    "Orientation Day (… 8/6)" and only then "Day 1 (… 8/10)", so counting Day N
    from 8/6 puts every day one class early.

    So Day N is counted forward from whatever date the page most recently
    stated — the teacher's own anchor — which also handles their numbering
    running across the school's block boundaries, as it does here.
    """
    if not meetings.available or not meetings.dates(course):
        return Resolution(None, NOTES["day_n_no_feed"].format(n=number),
                          "unresolved", "low")
    if anchor is None:
        return Resolution(None, NOTES["page_day_no_anchor"].format(
            n=number, where=where), "unresolved", "low")
    step = number - anchor_number
    if step == 0:
        return Resolution(anchor, NOTES["page_day_counted"].format(
            n=number, where=where, anchor=quote_label(anchor_label),
            resolved=f"{anchor:%a %b %d}"), "day_n_exact", "high")
    if step < 0:
        # Counting backwards, because a doc may list its weeks newest first —
        # [MEASURED] the Honors English doc does, so the first heading read is
        # the LATEST one and every earlier class is behind it.
        behind = [d for d in meetings.dates(course) if d < anchor]
        if len(behind) < -step:
            return Resolution(None, NOTES["page_day_no_anchor"].format(
                n=number, where=where), "unresolved", "low")
        when = behind[step]          # step is negative: index from the end
        return Resolution(when, NOTES["page_day_counted_back"].format(
            label=f"Class {number}" if label_is_class else f"Day {number}",
            where=where, anchor=quote_label(anchor_label),
            resolved=f"{when:%a %b %d}"),
            "day_n_exact", "medium")
    # Which end the anchor counts from depends on what it is. A stated day
    # ("Day 1 (8/10)") is itself a class, so Day 2 is the next one AFTER it. A
    # block heading ("Week 3&4 - 8/24") is a start line, so Day 1 is the first
    # class ON or after it. Using > for both dated every unnumbered day one
    # class late.
    ahead = [d for d in meetings.dates(course)
             if (d > anchor if anchor_number else d >= anchor)]
    if step > len(ahead):
        return Resolution(None, NOTES["page_day_no_anchor"].format(
            n=number, where=where), "unresolved", "low")
    when = ahead[step - 1]
    # Counted, not stated: medium confidence, and the note says what it counted
    # from so a wrong anchor is visible rather than silent.
    return Resolution(when, NOTES["page_day_counted"].format(
        n=number, where=where, anchor=quote_label(anchor_label),
        resolved=f"{when:%a %b %d}"), "day_n_exact", "medium")


def snap_weekday(course: str, claimed: date, weekday: int | None, raw_cell: str,
                 meetings, month_name: str) -> Resolution:
    """Reconcile a 'F, 12'-style cell against the real schedule.

    The doc makes two claims — the weekday and the number. When they disagree
    the doc is stale (Physics C's September table carries the previous year's
    numbering) and the weekday is the half worth keeping: the nearest actual
    meeting on that weekday wins, and the note quotes the doc's own cell.
    """
    resolved_label = f"{claimed:%a %b %d}"
    if not meetings.available or not meetings.dates(course):
        return Resolution(claimed, NOTES["weekday_exact"].format(
            cell=raw_cell, month=month_name, resolved=resolved_label),
            "month_heading", "medium", ["no_feed_check"])

    if meetings.meeting_on(course, claimed) and (
            weekday is None or claimed.weekday() == weekday):
        return Resolution(claimed, NOTES["weekday_exact"].format(
            cell=raw_cell, month=month_name, resolved=resolved_label),
            "month_heading", "high")

    nearby = [d for d in meetings.dates(course) if abs((d - claimed).days) <= 4]
    if not nearby:
        return Resolution(claimed, NOTES["absolute_literal"],
                          "absolute", "medium", ["not_a_class_day"])
    matching = [d for d in nearby if weekday is not None and d.weekday() == weekday]
    chosen = min(matching or nearby, key=lambda d: (abs((d - claimed).days), d))
    if weekday is not None and claimed.weekday() != weekday:
        note = NOTES["weekday_mismatch"].format(
            cell=raw_cell, claimed_long=f"{claimed:%b %d %Y}",
            actual_weekday=WEEKDAY_NAMES[claimed.weekday()],
            chosen=f"{chosen:%a %b %d}")
        return Resolution(chosen, note, "weekday_snapped", "medium",
                          ["stale_year_row"])
    note = NOTES["weekday_not_meeting"].format(cell=raw_cell,
                                               chosen=f"{chosen:%a %b %d}")
    return Resolution(chosen, note, "weekday_snapped", "medium")


def resolve_absolute(course: str, when: date, meetings, snap_forward: bool) -> Resolution:
    """A stated 'Aug 11'-style date. Three distinct outcomes, three distinct
    notes — never blurred (spec §10.6's table)."""
    stated = f"{when:%b %d}"
    if not meetings.available or meetings.meeting_on(course, when) or not meetings.dates(course):
        return Resolution(when, NOTES["absolute_stated"].format(stated=stated),
                          "absolute", "high")
    if snap_forward:
        following = meetings.next_after(course, when)
        if following:
            return Resolution(following, NOTES["absolute_snapped"].format(stated=stated),
                              "absolute_snapped_forward", "medium")
    return Resolution(when, NOTES["absolute_literal"], "absolute", "medium",
                      ["not_a_class_day"])
