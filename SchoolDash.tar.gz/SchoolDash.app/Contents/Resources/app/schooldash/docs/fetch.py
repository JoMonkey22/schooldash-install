"""Fetching course docs. Published docs are cookieless httpx — no browser.
Private docs need the session and are opt-in only. Raw HTML is cached at
cache/docs/<file_id_prefix>-<ts>.html (last N kept) — that is what makes
golden-file tests possible and lets the dashboard show the student the source.
"""

import re
import time
from pathlib import Path

import httpx

from schooldash import config, paths
from schooldash.logging_setup import get

log = get("fetch")


class DocError(RuntimeError):
    """A doc that cannot be fetched. gone=True (404/410) is a NORMAL outcome —
    a teacher unpublishing a doc is a Tuesday, not an exception."""

    def __init__(self, message, gone=False, needs_login=False):
        super().__init__(message)
        self.gone = gone
        self.needs_login = needs_login


def published_url(file_id: str) -> str:
    return f"https://docs.google.com/document/d/e/{file_id}/pub"


def private_export_url(file_id: str) -> str:
    return f"https://docs.google.com/document/d/{file_id}/export?format=html"


def _cache_key(file_id: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]", "", file_id)[:24] or "doc"


def _write_cache(file_id: str, html: str) -> Path:
    keep = config.load()["docs"]["cache_keep"]
    directory = paths.docs_cache_dir()
    stamp = time.strftime("%Y%m%d-%H%M%S")
    path = directory / f"{_cache_key(file_id)}-{stamp}.html"
    path.write_text(html, encoding="utf-8")
    old = sorted(directory.glob(f"{_cache_key(file_id)}-*.html"))
    for stale in old[:-keep] if keep > 0 else []:
        stale.unlink(missing_ok=True)
    return path


def cached_versions(file_id: str) -> list[Path]:
    return sorted(paths.docs_cache_dir().glob(f"{_cache_key(file_id)}-*.html"))


def latest_cached(file_id: str) -> str | None:
    versions = cached_versions(file_id)
    if not versions:
        return None
    return versions[-1].read_text(encoding="utf-8")


def fetch_published(file_id: str, timeout: float = 20.0, cache: bool = True) -> str:
    try:
        response = httpx.get(published_url(file_id), follow_redirects=True,
                             timeout=timeout,
                             headers={"User-Agent": "schooldash/0.1"})
    except httpx.HTTPError as exc:
        raise DocError(f"could not reach the doc: {type(exc).__name__}") from exc
    if response.status_code in (404, 410):
        raise DocError(f"the teacher unpublished this doc "
                       f"(HTTP {response.status_code})", gone=True)
    if response.status_code != 200:
        raise DocError(f"HTTP {response.status_code} fetching the doc")
    if "accounts.google.com" in str(response.url):
        raise DocError("Google asked for a sign-in on a published doc",
                       needs_login=True)
    html = response.text
    if cache:
        _write_cache(file_id, html)
    return html


def fetch_private(file_id: str, context, cache: bool = True) -> str:
    """Needs the browser session; only called with --include-private-docs."""
    response = context.request.get(private_export_url(file_id), timeout=60_000)
    if "accounts.google.com" in (response.url or ""):
        raise DocError("Google asked for a sign-in; run: python run.py login",
                       needs_login=True)
    if response.status in (404, 410):
        raise DocError(f"the doc is gone (HTTP {response.status})", gone=True)
    if not response.ok:
        raise DocError(f"HTTP {response.status} fetching the private doc")
    html = response.text()
    if cache:
        _write_cache(file_id, html)
    return html


def fetch_doc(kind: str, file_id: str, context=None, include_private=False,
              cache: bool = True) -> str:
    if kind == "published-document":
        return fetch_published(file_id, cache=cache)
    if not include_private:
        raise DocError("private doc skipped (pass --include-private-docs to read it)")
    if context is None:
        raise DocError("a private doc needs the browser session", needs_login=True)
    return fetch_private(file_id, context, cache=cache)
