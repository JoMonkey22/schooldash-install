"""Cells -> Items: the profile-driven extractor.

Semantics ported from the verified predecessor and kept under test:
- a prose cell is ONE item; only <li> bullets (and separate <p>s) split
- line prefixes are anchored at line start: Homework:/HW:/For tonight -> due at
  the NEXT meeting; Due Today:/Due:/Turn in -> this meeting; Agenda:/In class:/
  Plan: -> skipped
- an unlabelled row (chemistry's "For tonight ...") belongs to the day above it
- a row whose date cell is a block heading sets context and produces nothing
- nothing is ever dropped silently and no date is ever invented: unresolvable
  rows ship as extractor "unresolved" with an honest date_note
"""

import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, time

from schooldash import timezones
from schooldash.docs import columns as columns_mod
from schooldash.docs import dates as dates_mod
from schooldash.docs import links as links_mod
from schooldash.docs import tables as tables_mod
from schooldash.models import Item, course_key_from_raw

DEFAULT_PREFIXES = {
    "next_meeting": ["Homework", "HW", "For tonight", "Tonight"],
    "same_meeting": ["Due Today", "Due", "Turn in", "Hand in"],
    "skip": ["Agenda", "In class", "Plan", "Warm-up", "Bell work"],
}


@dataclass
class ExtractResult:
    items: list = field(default_factory=list)
    ambiguities: list = field(default_factory=list)
    diagnostics: dict = field(default_factory=dict)
    course_links: list = field(default_factory=list)   # course-wide, -> profile card


# A teacher who numbers their sections writes the marker second: "2.4 HW:
# #233-283". The marker still means homework, and the number is the name of the
# work — so the number is kept and only the marker is dropped, leaving
# "2.4 #233-283" rather than "#233-283".
# Deliberately WITHOUT any leading-decoration match: each caller supplies its
# own (items uses \s*, prose uses \W{0,3} so "**Tarea:" still works). Folding
# the two together made the whole lead optional-but-digit-requiring, and
# "**Tarea:" stopped matching at all.
NUMBERED_LEAD = (r"(?P<lead>(?:\d{1,2}(?:\.\d{1,2})?|ch(?:apter)?\.?\s*\d{1,2}"
                 r"|unit\s*\d{1,2}|lesson\s*\d{1,2})\s*)?")


def _prefix_regex(entries: list[str]) -> re.Pattern | None:
    cleaned = [re.escape(e.strip().rstrip(":-").strip()) for e in entries if e and e.strip()]
    if not cleaned:
        return None
    return re.compile(r"^\s*" + NUMBERED_LEAD + r"(?:%s)\b\s*[:\-–]?\s*"
                      % "|".join(cleaned), re.I)


def strip_prefix(pattern: re.Pattern, text: str) -> str:
    """Remove a matched line prefix, keeping any section number in front."""
    match = pattern.match(text)
    if not match:
        return text
    lead = (match.groupdict().get("lead") or "").strip()
    rest = text[match.end():].strip()
    return f"{lead} {rest}".strip() if lead else rest


def compile_prefixes(profile) -> dict:
    raw = (profile.get("line_prefixes", default=None) if profile else None) or {}
    merged = {key: raw.get(key) if raw.get(key) is not None else DEFAULT_PREFIXES[key]
              for key in DEFAULT_PREFIXES}
    return {
        "homework": _prefix_regex(merged["next_meeting"]),
        "due": _prefix_regex(merged["same_meeting"]),
        "skip": _prefix_regex(merged["skip"]),
    }


def classify_line(text: str, in_due_column: bool, prefixes: dict):
    """('due'|'homework'|'skip'|None, cleaned text). Prefixes beat column role,
    so a 'Homework:' line fires in any column; a bare line needs a due column."""
    if prefixes["homework"] and prefixes["homework"].match(text):
        return "homework", strip_prefix(prefixes["homework"], text)
    if prefixes["due"] and prefixes["due"].match(text):
        return "due", strip_prefix(prefixes["due"], text)
    if prefixes["skip"] and prefixes["skip"].match(text):
        return "skip", strip_prefix(prefixes["skip"], text)
    if in_due_column:
        return "due", text
    return None, ""


def clean_title(text: str, limit: int = 110) -> str:
    text = re.sub(r"\s+", " ", text or "").strip(" .;:-–")
    if len(text) > limit:
        cut = text[:limit].rsplit(" ", 1)[0]
        text = cut + "…"
    return text


def cell_blocks(cell_node, base: str = ""):
    """[(text, links)] — one per <p> and per <li>, in document order; else the
    whole cell. Document order matters: a bare "For tonight" <p> heading before
    a bullet list applies to the bullets after it (the sticky role in the
    caller). Links outside any <li> attach to every <li> item from that cell."""
    blocks = []
    elements = [e for e in cell_node.find_all(["p", "li"])
                if e.name == "li" or e.find_parent("li") is None]
    if elements:
        outside = links_mod.from_anchors(
            [a for a in cell_node.find_all("a", href=True)
             if a.find_parent("li") is None], base)
        for element in elements:
            text = " ".join(element.get_text(" ", strip=True).split())
            if not text:
                continue
            own = links_mod.extract_links(element, base)
            if element.name == "li":
                seen = {l.url for l in own}
                own = own + [l for l in outside if l.url not in seen]
            blocks.append((text, own))
        if blocks:
            return blocks
    text = " ".join(cell_node.get_text(" ", strip=True).split())
    if text:
        blocks.append((text, links_mod.extract_links(cell_node, base)))
    return blocks


def _parse_all_styles(text, month_hint, year_start, styles):
    """Every enabled style's reading of a cell. >1 distinct reading = ambiguous."""
    readings = []
    for style in styles or []:
        kind, value = dates_mod.parse_day_cell(text, month_hint, year_start, [style])
        if kind is not None:
            readings.append((kind, value))
    distinct = {(k, str(v)) for k, v in readings}
    if not readings:
        return None, None, False
    if len(distinct) > 1:
        return None, None, True
    return readings[0][0], readings[0][1], False


UNRESOLVED = dates_mod.Resolution(
    None, dates_mod.NOTES["unresolved"], "unresolved", "low")


def extract_doc(html: str, profile, meetings, source_url: str = "") -> ExtractResult:
    """Parse one course doc into Items, using that course's profile."""
    result = ExtractResult()
    course_display = (profile.get("display_name") or profile.get("course_raw")
                      or profile.course_key)
    course_lookup = profile.get("course_raw") or course_display
    styles = profile.get("layout", "date_styles", default=None) or \
        ["day_n", "absolute", "month_heading"]
    snap_absolute = bool(profile.get("layout", "snap_absolute_to_meeting",
                                     default=False))
    block_pattern = profile.get("layout", "block_heading_pattern", default=None)
    prefixes = compile_prefixes(profile)
    year_start = meetings.school_year_start() or timezones.to_local(
        datetime.now(timezones.zone())).year

    table_nodes, body = tables_mod.parse_tables(html)
    month_hint = None
    table_diags = []

    for node in body.find_all(["p", "h1", "h2", "h3", "table"]):
        if node.find_parent("table"):
            continue
        if node.name != "table":
            text = node.get_text(" ", strip=True)
            match = dates_mod.RE_BARE_MONTH.match(text)
            if match:
                number = dates_mod.month_number(match.group(1))
                if number:
                    month_hint = number
            # course-wide links live in the doc's header/paragraph area
            result.course_links.extend(links_mod.extract_links(node, source_url))
            continue

        grid = tables_mod.build_grid(node)
        if not grid:
            continue
        header_idx, header_rule = tables_mod.detect_header(grid)
        if header_idx < 0:
            continue
        headers = [c.text for c in grid[header_idx]]
        joined = " ".join(headers).lower()
        if "day" not in joined and "date" not in joined:
            # a resources/links table, not a schedule — its links are course-wide
            result.course_links.extend(links_mod.extract_links(node, source_url))
            continue
        # links in a schedule table's header row are course-wide too
        for cell in grid[header_idx]:
            if cell.origin and cell.node is not None:
                result.course_links.extend(
                    links_mod.extract_links(cell.node, source_url))
        roles, date_col = columns_mod.classify_columns(headers, profile)
        # A profile may list several date-ish columns (CLASS DAY and DATE/WEEK
        # both match). The real date column is the one whose CELLS actually
        # parse as day/date values — block-heading cells do not count.
        candidates = [i for i, role in enumerate(roles) if role == "date"]
        if len(candidates) > 1:
            def _hits(col_index):
                count = 0
                for r, row in enumerate(grid):
                    if r == header_idx or col_index >= len(row):
                        continue
                    kind, _, _ = _parse_all_styles(row[col_index].text,
                                                   month_hint, year_start, styles)
                    if kind in ("dayn", "date", "weekday"):
                        count += 1
                return count
            date_col = max(candidates, key=_hits)
            for other in candidates:
                if other != date_col:
                    roles[other] = "plain"
        diag = {"header_rule": header_rule, "headers": headers, "roles": roles,
                "rows": len(grid), "items": 0, "date_col": date_col}
        table_diags.append(diag)

        # ---- pass 1: date-cell parse + block context per row -----------------
        parsed: list[tuple] = []
        block = None
        for r, row in enumerate(grid):
            if r == header_idx:
                parsed.append((None, None, block, True, False))
                continue
            date_cell = row[date_col] if date_col < len(row) else None
            date_text = date_cell.text if date_cell else ""
            block_origin_row = False
            for cell in row[:date_col]:
                if not cell.text:
                    continue
                span = None
                if block_pattern:
                    span = dates_mod.parse_block_pattern(cell.text, block_pattern,
                                                         year_start)
                span = span or dates_mod.parse_range(cell.text, year_start)
                if span and dates_mod.RE_RANGE.search(cell.text):
                    block = span
                    if cell.origin and not date_text.strip():
                        block_origin_row = True
            kind, value, conflict = _parse_all_styles(date_text, month_hint,
                                                      year_start, styles)
            if kind is None and not conflict:
                # a block heading in the date column itself (chemistry-style)
                k2, v2 = dates_mod.parse_day_cell(date_text, month_hint,
                                                  year_start, [])
                if k2 == "block":
                    kind, value = k2, v2
            if kind is None and not conflict:
                # A cell naming one date per class section — "Day 1 / 8/6-A /
                # 8/7-B". Every pattern above is anchored to the whole cell, so
                # three lines match none of them. [MEASURED] 2026-09-02 that
                # left all 16 Honors Algebra items undated with the dates
                # written twice in the cell. Last, so it only ever rescues a
                # row nothing else could date.
                labelled = dates_mod.resolve_labelled_dates(
                    course_lookup, date_text, year_start, meetings)
                if labelled is not None:
                    kind, value = "resolved", labelled
            if kind == "block":
                block = value
                block_origin_row = True
            parsed.append((kind, value, block, block_origin_row, conflict))

        dayn_counts = Counter(b for (k, _, b, _, _) in parsed if k == "dayn")

        # ---- pass 2: build items --------------------------------------------
        last_res = None
        prev_block = None
        for r, row in enumerate(grid):
            kind, value, block, is_heading, conflict = parsed[r]
            if r == header_idx:
                continue
            if block != prev_block:
                last_res, prev_block = None, block
            if is_heading:
                continue
            date_cell = row[date_col] if date_col < len(row) else None
            date_text = date_cell.text if date_cell else ""

            res = None
            if kind == "resolved":
                res = value
            elif kind == "date":
                res = dates_mod.resolve_absolute(course_lookup, value, meetings,
                                                 snap_absolute)
            elif kind == "weekday":
                claimed, weekday, raw = value
                month_name = [k for k, v in dates_mod.MONTHS.items()
                              if v == month_hint]
                res = dates_mod.snap_weekday(
                    course_lookup, claimed, weekday, raw, meetings,
                    (month_name[0].capitalize() if month_name else "month"))
            elif kind == "dayn":
                res = dates_mod.resolve_day_n(course_lookup, value, block,
                                              meetings, dayn_counts.get(block, 0))
            if res is not None:
                last_res = res
            row_has_content = any(
                c.origin and c.text and c.col != date_col for c in row)
            if kind is None and (conflict or dates_mod.looks_date_like(date_text)):
                if row_has_content:
                    result.ambiguities.append({
                        "course_key": profile.course_key,
                        "cell": date_text,
                        "reason": ("two date styles disagree" if conflict
                                   else "no date style matched a date-like cell"),
                        "headers": headers,
                        "row_text": " | ".join(c.text for c in row if c.origin),
                        "block": [b.isoformat() for b in block] if block else None,
                    })

            use = res if res is not None else (last_res or UNRESOLVED)
            forced_homework = bool(prefixes["homework"]
                                   and prefixes["homework"].match(date_text or ""))

            for cell in row:
                if not cell.origin or cell.node is None:
                    continue
                if cell.col == date_col and kind is not None:
                    continue
                role_col = roles[cell.col] if cell.col < len(roles) else "plain"
                if role_col == "date" and kind is not None:
                    continue
                in_due = role_col == "due"
                # A column of work SET at this class: a bare line in it is
                # homework, which the shift below dates to the next meeting.
                in_assigned = role_col == "assigned"
                # A bare prefix line inside a cell ("For tonight" on its own,
                # then the actual work as following lines — chemistry writes
                # exactly this) sets a sticky role for the REST of that cell.
                sticky_role = None
                # A closing line that states a deadline and nothing else is an
                # instruction about the rest of the cell, not a task. AP
                # Chemistry writes a "For tonight" list and ends it with
                # "These should be done by August 11th." — the videos and the
                # book problems above it are what is due on the 11th.
                from schooldash.docs import prose as prose_mod

                blocks = list(cell_blocks(cell.node, source_url))
                cell_deadline = None
                instructions: set = set()
                for cell_text, _ in blocks:
                    only = prose_mod.deadline_only_line(cell_text, year_start)
                    if only is not None:
                        cell_deadline = only
                        instructions.add(cell_text)
                for text, blk_links in blocks:
                    if text in instructions:
                        continue
                    if dates_mod.SKIP_TEXT.match(text) or len(text) < 3:
                        continue
                    # explicit prefixes first; the bare due-column default
                    # applies LAST, after row-forced and sticky roles
                    role, cleaned = classify_line(text, False, prefixes)
                    if role == "skip":
                        if not cleaned:
                            sticky_role = "skip"
                        continue
                    if role and not cleaned:
                        sticky_role = role
                        continue
                    if role is None:
                        if forced_homework:
                            role, cleaned = "homework", text
                        elif sticky_role in ("homework", "due"):
                            role, cleaned = sticky_role, text
                        elif sticky_role == "skip":
                            continue
                        elif in_assigned:
                            role, cleaned = "homework", text
                        elif in_due:
                            role, cleaned = "due", text
                    if not role or not cleaned or len(cleaned) < 3:
                        continue

                    due_day = use.when
                    note = use.note
                    extractor = use.extractor
                    confidence = use.confidence
                    flags = list(use.flags)

                    # A deadline written in the cell wins outright, and is
                    # never shifted to the next class — it already IS the
                    # deadline. The same rule prose has had from the start, so
                    # a teacher who writes a table and a teacher who writes
                    # sentences are read the same way.
                    #
                    # [MEASURED] 2026-09-03, reported: "Work on SARA (25% due
                    # by 10/8)" sat in Honors Algebra's work column and was
                    # dated 2026-08-31 — "assigned Aug 27, due next class" —
                    # so a task due in five weeks was shown as overdue. The
                    # identical SARA programme in the English doc was dated
                    # correctly, because that teacher writes prose.
                    from schooldash.docs import prose as prose_mod

                    own = prose_mod.stated_deadline(text, year_start)
                    if own is not None:
                        due_day, phrase = own
                        note = dates_mod.NOTES["line_deadline"].format(phrase=phrase)
                        extractor, confidence = "absolute", "high"
                    elif cell_deadline is not None:
                        due_day, phrase = cell_deadline
                        note = dates_mod.NOTES["cell_deadline"].format(phrase=phrase)
                        extractor, confidence = "absolute", "high"
                    elif role == "homework" and due_day:
                        following = meetings.next_after(course_lookup, due_day)
                        if following:
                            shift = dates_mod.NOTES["homework_shift"].format(
                                assigned=f"{due_day:%b %d}")
                            if extractor == "absolute":
                                note = shift
                            else:
                                note = f"{note}; {shift}"
                            due_day = following

                    due = due_date = None
                    if due_day:
                        stamp = meetings.time_on(course_lookup, due_day)
                        when = stamp if stamp else datetime.combine(
                            due_day, time(23, 59), tzinfo=timezones.zone())
                        due, due_date = when.isoformat(), due_day.isoformat()

                    item = Item(
                        source="doc",
                        course_key=profile.course_key,
                        course=course_display,
                        title=clean_title(cleaned),
                        detail=re.sub(r"\s+", " ", text).strip(),
                        raw_cell=cell.text,
                        kind="homepage doc",
                        category="neutral",
                        due=due,
                        due_date=due_date,
                        all_day=False,
                        date_note=note,
                        confidence=confidence,
                        extractor=extractor,
                        url=links_mod.best_link(blk_links) or source_url or None,
                        links=blk_links,
                        flags=flags,
                    )
                    result.items.append(item.finalize())
                    diag["items"] += 1

    seen_urls: set[str] = set()
    deduped_links = []
    for link in result.course_links:
        key = link.url.rstrip("/").lower()
        if key not in seen_urls:
            seen_urls.add(key)
            deduped_links.append(link)
    result.course_links = deduped_links
    result.diagnostics = {"tables": table_diags,
                          "ambiguous_cells": len(result.ambiguities)}
    return result
