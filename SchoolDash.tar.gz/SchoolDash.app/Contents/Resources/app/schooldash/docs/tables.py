"""BeautifulSoup+lxml -> a normalized rectangular grid.

colspan/rowspan are expanded into real occupied cells BEFORE any column-index
logic — skipping this is the most common cause of a silently wrong column
mapping, and the English/Science&Religion docs rowspan their DATE/WEEK column
across whole blocks. Each expanded position knows whether it is the origin of
its cell, so content is only ever read once.
"""

from dataclasses import dataclass, field

from bs4 import BeautifulSoup

BLOCK_TAGS = {"p", "li", "div", "h1", "h2", "h3", "h4", "table", "tr"}


@dataclass
class Cell:
    row: int
    col: int
    text: str
    html: str
    links: list = field(default_factory=list)   # filled by docs.links
    is_header: bool = False
    origin: bool = True
    node: object = None


def cell_text(node) -> str:
    """Whitespace-collapsed visible text with \\n preserved between block
    elements (a <li> full of <span>s stays one line; <br> breaks)."""
    lines = []
    blocks = node.find_all(["p", "li", "h1", "h2", "h3", "h4"])
    if blocks:
        for block in blocks:
            text = " ".join(block.get_text(" ", strip=True).split())
            if text:
                lines.append(text)
    else:
        text = " ".join(node.get_text(" ", strip=True).split())
        if text:
            lines.append(text)
    return "\n".join(lines)


def build_grid(table) -> list[list[Cell]]:
    """One <table> -> rectangular grid of Cells with spans expanded."""
    occupied: dict[tuple[int, int], tuple] = {}   # (row, col) -> (node, origin)
    rows = table.find_all("tr")
    for r, tr in enumerate(rows):
        col = 0
        for node in tr.find_all(["td", "th"], recursive=False) or tr.find_all(["td", "th"]):
            while (r, col) in occupied:
                col += 1
            try:
                colspan = max(1, int(node.get("colspan") or 1))
            except ValueError:
                colspan = 1
            try:
                rowspan = max(1, int(node.get("rowspan") or 1))
            except ValueError:
                rowspan = 1
            for dr in range(rowspan):
                for dc in range(colspan):
                    if r + dr < len(rows):
                        occupied[(r + dr, col + dc)] = (node, dr == 0 and dc == 0)
            col += colspan

    if not occupied:
        return []
    width = max(c for _, c in occupied) + 1
    grid: list[list[Cell]] = []
    text_cache: dict[int, str] = {}
    for r in range(len(rows)):
        row_cells: list[Cell] = []
        for c in range(width):
            node, origin = occupied.get((r, c), (None, False))
            if node is None:
                row_cells.append(Cell(r, c, "", "", origin=False))
                continue
            key = id(node)
            if key not in text_cache:
                text_cache[key] = cell_text(node)
            row_cells.append(Cell(
                row=r, col=c,
                text=text_cache[key],
                html=node.decode_contents() if origin else "",
                is_header=node.name == "th",
                origin=origin,
                node=node,
            ))
        grid.append(row_cells)
    return grid


def detect_header(grid: list[list[Cell]]) -> tuple[int, str]:
    """(header_row_index, rule_that_fired). -1 when no plausible header.

    Order: a <th> row; else a row among the first two whose joined text
    mentions day/date (real docs put a colspan banner above the header);
    else an all-bold first row; else the first non-empty row.
    """
    for index, row in enumerate(grid[:3]):
        if row and all(c.is_header for c in row if c.origin) and any(c.origin for c in row):
            if any(c.text for c in row):
                return index, "th"
    for index, row in enumerate(grid[:2]):
        joined = " ".join(c.text for c in row if c.origin).lower()
        if joined and ("day" in joined or "date" in joined):
            return index, "day/date scan"
    if grid:
        first = grid[0]
        bold = [c for c in first if c.origin and c.node is not None and c.text]
        if bold and all(c.node.find(["b", "strong"]) is not None for c in bold):
            return 0, "all-bold"
        for index, row in enumerate(grid[:1]):
            if any(c.text for c in row):
                return 0, "first row"
    return -1, "none"


def parse_tables(html: str) -> tuple[list, object]:
    """(top-level table nodes, the content body) — Google's exported HTML is
    malformed often enough that html.parser mis-nests tables; lxml is required."""
    soup = BeautifulSoup(html, "lxml")
    body = soup.select_one("#contents") or soup.body or soup
    tables = [t for t in body.find_all("table") if not t.find_parent("table")]
    return tables, body
