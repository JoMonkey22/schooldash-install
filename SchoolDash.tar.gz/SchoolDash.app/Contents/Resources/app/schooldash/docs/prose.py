"""Homework typed onto the page itself — no table, and no Canvas assignment.

Why this exists. [MEASURED] 2026-09-01, across eleven course homepages: nine
are a single <iframe> embedding the teacher's Google Doc (which the doc
pipeline already reads), one is a module index, and one — Spanish 1 — **is**
the schedule, typed straight into the Canvas page as flat paragraphs:

    Week 3&4 (Block A and B) - 8/24
    Day 1 (Monday 8/24)
    p. 13-16 ( El calendario )
    **Tarea: P- 7, P-8, Finish Quizlet Write for Para Empezar set by day 4
    …
    Day 4 (Tues 9/1)
    Vocab Quiz on Para Empezar Vocab Set
    Day 5 (Thurs 9/3)
    Test on Para Empezar chapter

Nothing read it. The Canvas planner had no assignment for any of it and that
course's Google Doc is private, so the class showed **zero** homework all term
while its own homepage listed a quiz that day and a test two days later.

`items.py` cannot help: it builds items out of <table> rows, and there is no
table here. This is the prose half of the same job, under the same rules.

**What becomes an item, and what deliberately does not.** Only lines sitting
under a dated heading are even considered — everything above the first day
heading is course furniture (grading policy, e-text link, "Practice with
Conjuguemos!") and is never work. Of those lines, exactly three shapes count:

1. **a homework prefix** — "**Tarea:", "Homework:", "HW:", "Due:", "Turn in".
   The prefix is the teacher saying "this one is yours to do".
2. **an assessment named at the start of the line** — "Test on …", "Vocab Quiz
   on …". A graded event on a stated day is the single most costly thing to
   miss. It must be *at the start*: [MEASURED] on this page "Calentamiento -
   ¿Qué hora es? Practice Quiz (To show assessment procedures- No grade)" is a
   warm-up, and a substring match on "quiz" would have put a fake quiz on the
   board. A line that calls itself ungraded is not an assessment either.
3. **an instruction to do something that carries a link** — "Complete (Calendar
   and Dates Practice) WayGround Assignment". The link is what separates work
   to hand in from the page numbers the class will read together.

Everything else on the day — "p. 13-16 ( El calendario )", "Presentations of
Four 'F's handout", "Intro to alphabet" — is the lesson plan, and putting the
lesson plan on a homework board is how the board stops being read.

**Dates are read, never invented.** A line's date comes from the heading above
it, resolved against that class's real meetings, and every item says in plain
words which heading it came from. Homework is due at the NEXT meeting, matching
the doc extractor. When a line names a later deadline of its own ("…by day 4")
the earlier date is kept on purpose: doing the work a class early costs
nothing, and being told about it a class late costs marks.
"""

import re
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta

from schooldash import timezones
from schooldash.docs import dates as dates_mod
from schooldash.docs import links as links_mod
from schooldash.models import Item

# Line-start markers, wider than the doc extractor's defaults because a page
# is written by whoever owns the page and nobody profiled it first. Spanish's
# "**Tarea (HW):" is the reason the parenthetical is tolerated below.
PAGE_PREFIXES = {
    "next_meeting": ["Homework", "HW", "H.W", "Tarea", "Deberes", "Devoirs",
                     "Assignment", "Assignments", "To Do", "Todo", "Tonight",
                     "For tonight", "For tomorrow", "For next class", "At home"],
    "same_meeting": ["Due Today", "Due", "Turn in", "Hand in", "Submit", "Bring"],
    # The lesson plan. A line marked this way is what happens IN class.
    "skip": ["Agenda", "In class", "In-class", "Plan", "Warm-up", "Warm up",
             "Bell work", "Do Now", "Objective", "Calentamiento", "Repaso"],
}

# An annotation is not a lesson-plan marker: it is a wrapper around whatever
# comes next, and what comes next is often the homework.
#
# [PROVEN] tests/test_prosecution.py — these words used to sit in the skip list
# and were tested FIRST, so three of five real lines came back as nothing:
#   "Reminder: turn in your lab procedures tomorrow" -> (None, '')
#   "Please note: Homework is chapter 4"             -> (None, '')
#   "Note: HW is p. 30"                              -> (None, '')
# The prefix is peeled off and the rest of the line is classified on its own
# merits; a note with no work in it still becomes nothing.
ANNOTATION_PREFIXES = ["Note", "Notes", "Please note", "Reminder", "Reminders",
                       "Remember", "FYI", "NB", "N.B.", "Heads up", "Important",
                       "Aviso", "Ojo"]
# "Homework is chapter 4" reads as "is chapter 4" once the prefix goes, so a
# copula left stranded at the front is dropped too.
RE_STRANDED_COPULA = re.compile(r"^(?:is|are|was|were|will be|=)\s+", re.I)

# A line that OPENS with one of these is describing when something else
# happens, not naming itself. [MEASURED] "After the test, you will set up your
# SARA Account …" was filed as a TEST, because the rule below allows three
# words in front of the word and "After the" is two.
RE_SUBORDINATE_OPENER = re.compile(
    r"^(?:after|before|during|once|when|while|whenever|if|unless|since|until|"
    r"following|prior to|as soon as|in preparation for|to prepare for)\b", re.I)

# An assessment has to be named in the opening words of the line (at most three
# words in front of it, e.g. "Vocab Quiz on …"), or it is not the subject of
# the sentence and this must not guess that it is.
RE_ASSESSMENT_LEAD = re.compile(
    r"^(?:[\w'’¿?.-]+\s+){0,3}?"
    r"\b(tests?|quiz|quizzes|exams?|midterms?|finals?|assessments?|prueba|examen)\b",
    re.I)
# The teacher saying it does not count.
RE_NOT_GRADED = re.compile(
    r"\bno grade|not graded|ungraded|practice (quiz|test)|no points\b", re.I)
# "For Class 11, …" / "Next Class 9 - …" / "For next class" — work set now and
# wanted at the next meeting. [MEASURED] Honors English writes both forms, and
# without them the line was dated to the class it was ANNOUNCED in, one class
# early, which then failed to dedupe against that class's own copy of it.
RE_FOR_NEXT = re.compile(
    r"^\W{0,3}(?:for|next)\s+(?:class|session|lesson)\s*\d{1,3}\s*[,:;\-–—]?\s*"
    r"|^\W{0,3}for\s+(?:next\s+class|tomorrow|tonight|"
    r"mon|tues?|wed(?:nes)?|thur?s?|fri)[a-z]*\b\s*[,:;\-–—]?\s*", re.I)

# A line that states a deadline anywhere in it, not just at the front. This is
# how a prose doc marks homework: "True Diary Chapter 2-5 are due with …",
# "…must be completed = 25 points". Deliberately narrow — "you must also attain
# an 85% average" and "*120 minutes completed = 20 points" are not deadlines.
# [MEASURED] 2026-09-02: this gate decided "due by", "due today" and "due
# next" were deadlines and "due Sep 26", "due TONIGHT" and "due Monday" were
# not. AI Frontiers' doc states every deadline the second way — "100 pts, due
# Sep 26", "25 points, due TONIGHT by 11:59 pm", "15 points, due Monday" — so
# its work was never work, and the class had reported zero homework since
# August. The list of connectives was doing the job a date should do.
#
# Still narrow, and in the same way: "due" now has to be followed by an actual
# stated time — a weekday, a month and a day, a numeric date, or tonight. The
# lines the original comment protects stay out, because neither "you must also
# attain an 85% average" nor "*120 minutes completed = 20 points" names one.
RE_DUE_IN_LINE = re.compile(
    r"\b(?:is|are|will be)\s+due\b"
    r"|\bdue\s+(?:on|by|before|at|today|tonight|tomorrow|next)\b"
    r"|\bdue\s+(?:the\s+)?"
    r"(?:mon|tues?|wednes|wed|thurs|thur|thu|fri|sat|sun)[a-z]*\b"
    r"|\bdue\s+(?:the\s+)?"
    r"(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s*\d{1,2}\b"
    r"|\bdue\s+\d{1,2}\s*/\s*\d{1,2}\b"
    r"|\bmust be (?:completed|finished|turned in|submitted|done|read)\b"
    r"|\bturn(?:ed)? in\b|\bhand(?:ed)? in\b", re.I)

# A deadline the line states for itself. It beats the heading above it: an
# announcement made in one class about a date eleven days out is not due that
# class, and dating it there would repeat a false deadline under every week
# that mentions it.
RE_LINE_DEADLINE = re.compile(
    r"\b(?:due|by|before|completed by|finished by)\s+(?:the\s+)?"
    r"(?:(?:mon|tues?|wednes|wed|thurs|thur|thu|fri|sat|sun)[a-z]*\.?,?\s*)?"
    r"(?P<date>(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s*"
    r"\d{1,2}(?:st|nd|rd|th)?|\d{1,2}/\d{1,2}(?:/\d{2,4})?)", re.I)

# "100 pts", "20 points", "5 points." — a mark is a property of work, and no
# teacher labels a class day with one.
RE_MARKS_IN_LINE = re.compile(r"\b\d{1,3}\s*(?:pts?|points?)\b", re.I)

# A line that OPENS with what it is worth is the detail line of the work named
# on the line above it. [MEASURED] 2026-09-03, AI Frontiers writes every
# assessment this way:
#
#     Side Hustle Proposal
#     100 points. Due Friday, Sep. 25, 11:59 PM. This is the project ...
#
#     Second Pass: Revise the Mark
#     15 points. Due Tuesday, Aug. 25, 11:59 PM.
#
# Read on its own it became an item called "100 points. Due Friday, Sep. 25,
# 11:59 PM. This is the project everything since Aug 18 has been feeding" —
# a real deadline wearing a title that names no work. The points must LEAD
# the line: "Project launch: High School Side Hustle. 100 points, runs through
# week 8." names its own work and keeps it.
RE_POINTS_LEAD = re.compile(r"^\W{0,3}\d{1,3}\s*(?:pts?|points?)\b", re.I)

# The same thing without the marks. A line that OPENS with a comma is the tail
# of the line above it, not a sentence: Google Docs splits a sentence around a
# link into separate nodes, so "[Side Hustle Proposal], due Sep 26." arrives as
# "Side Hustle Proposal" then ", due Sep 26." — which became an item titled
# "Sep 26". [MEASURED] 2026-09-03.
RE_CONTINUATION = re.compile(r"^\s*[,;]")


def _is_detail_line(text: str) -> bool:
    """This line describes the work named on the line above it."""
    return bool(RE_POINTS_LEAD.match(text or "")
                or RE_CONTINUATION.match(text or ""))

# Something to DO. Only counts when the line also carries a link (see above).
RE_ACTION_LEAD = re.compile(
    r"^(complete|finish|submit|turn in|hand in|watch|read|write|register|join|"
    r"print|fill out|answer|record|upload|post|study for)\b", re.I)

# Date tokens inside a heading: "8/24", "9/1/26", "Sept 3", "August 21st".
RE_DATE_TOKEN = re.compile(
    r"(?P<m>\d{1,2})/(?P<d>\d{1,2})(?:/(?P<y>\d{2,4}))?"
    r"|\b(?P<mon>jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s*"
    r"(?P<dd>\d{1,2})(?:st|nd|rd|th)?\b", re.I)
RE_WEEKDAY_WORD = re.compile(
    r"\b(mon|tues|tue|wed|wednes|thurs|thur|thu|fri|sat|sun)[a-z]*\.?\b", re.I)
WEEKDAY_INDEX = {"mon": 0, "tue": 1, "tues": 1, "wed": 2, "wednes": 2,
                 "thu": 3, "thur": 3, "thurs": 3, "fri": 4, "sat": 5, "sun": 6}

# "Day 1", "Día 3" — numbered inside a block, so the count restarts at every
# block heading.
RE_DAY_N_LEAD = re.compile(r"^(?:day|d[íi]a)\s*(\d{1,2})\b", re.I)
# "Class 10", "Session 4", "Lesson 12" — numbered across the whole year, so a
# block heading must NOT reset the count. [MEASURED] Honors English numbers
# every class from the start of the year and lists its weeks newest first.
RE_CLASS_N_LEAD = re.compile(r"^(?:class|session|lesson|clase)\s*(\d{1,3})\b", re.I)
# "Orientation Day (first day of week 1 8/6)", "Back to School Day (8/6)"
RE_NAMED_DAY_LEAD = re.compile(r"^([A-Za-z][A-Za-z'’ ]{0,24}?\bday)\s*(?=\()", re.I)
# "Week 3&4 (Block A and B) - 8/24", "Week of Sept 8", "Unit 2 — Aug 31"
RE_BLOCK_LEAD = re.compile(r"^(?:week|semana|unit|block|quarter|term)\b", re.I)
# A heading is short, or ends in a parenthetical. Anything longer is a
# paragraph that happens to start with a date word.
HEADING_CHARS = 90

# An aside starting mid-line. A Canvas paragraph runs the thing itself and the
# teacher's note about it together — [MEASURED] the real line reads "Vocab Quiz
# on Para Empezar Vocab Set Please note: You will be given the word in English
# and you will have to type it out in Spanish…", which on the board is 110
# characters of title for a four-word quiz. The title stops at the aside; the
# whole line is kept in `detail` and shown when the item is opened.
RE_ASIDE = re.compile(
    r"\s+(?:please\s+note|note that|note:|nb:|n\.b\.|reminder:|"
    r"remember(?:\s+that)?:|fyi:?)\b", re.I)
# Far enough in that what remains is still a name for the work. "Read chapter
# 4" is 14 characters, so the bar sits below that; an aside at the very start
# ("Note: bring your book") is the whole line and is left alone.
MIN_TITLE_BEFORE_ASIDE = 10

# Junk lines: separators the teacher uses to divide weeks, and empties.
RE_SEPARATOR = re.compile(r"^[\s\-–—_=*.·•]{3,}$")

BLOCK_TAGS = ["h1", "h2", "h3", "h4", "h5", "h6", "p", "li", "div", "td", "th"]

# How far back a deadline read out of prose may be and still reach the board.
#
# A Canvas item carries submitted-status, so an overdue one is genuinely
# unsubmitted and belongs at the top. Prose states nothing about what was
# handed in: a schedule doc or a homepage is the record of what happened, and
# its past rows are as likely finished as not. [MEASURED] 2026-09-01 four
# workbook rows from the previous week took the top four places on the whole
# board; 2026-09-02 the English doc alone offered thirty past deadlines.
NO_SUBMISSION_GRACE_DAYS = 3


@dataclass
class ProseResult:
    items: list = field(default_factory=list)
    headings: list = field(default_factory=list)   # what dated the items
    diagnostics: dict = field(default_factory=dict)


def _prefix_regex(entries) -> re.Pattern | None:
    """A line-start prefix matcher that tolerates the decoration teachers put
    around these words: leading asterisks/bullets, a parenthetical gloss, and
    any of colon / dash / en dash as the separator."""
    cleaned = [re.escape(e.strip().rstrip(":-").strip())
               for e in entries or [] if e and e.strip()]
    if not cleaned:
        return None
    from schooldash.docs.items import NUMBERED_LEAD

    return re.compile(
        r"^\W{0,3}" + NUMBERED_LEAD
        + r"(?:%s)\b\s*(?:\([^)]{0,24}\))?\s*[:\-–—]?\s*" % "|".join(cleaned),
        re.I)


def compile_prefixes(profile=None) -> dict:
    """Page defaults, widened by the course's profile when it has one. The
    profile was learned from the teacher's DOC, but a teacher who writes
    "**Tarea:" in one place writes it in the other."""
    merged = {key: list(value) for key, value in PAGE_PREFIXES.items()}
    raw = (profile.get("line_prefixes", default=None) if profile else None) or {}
    for group in merged:
        for entry in raw.get(group) or []:
            if entry and entry not in merged[group]:
                merged[group].append(entry)
    return {"homework": _prefix_regex(merged["next_meeting"]),
            "due": _prefix_regex(merged["same_meeting"]),
            "skip": _prefix_regex(merged["skip"]),
            "annotation": _prefix_regex(ANNOTATION_PREFIXES)}


def _clean(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "")).strip()


def _date_in(text: str, year_start: int | None) -> date | None:
    """The first real date in a heading, or None. Never guesses a year: the
    school year comes from the class feed's own span."""
    for match in RE_DATE_TOKEN.finditer(text or ""):
        if match.group("m"):
            month, day = int(match.group("m")), int(match.group("d"))
            year_text = match.group("y")
            year = (int(year_text) + (2000 if int(year_text) < 100 else 0)
                    if year_text else dates_mod.year_for(month, year_start))
        else:
            month = dates_mod.month_number(match.group("mon"))
            day = int(match.group("dd"))
            year = dates_mod.year_for(month, year_start) if month else None
        if not month or not year or not 1 <= month <= 12:
            continue
        try:
            return date(year, month, day)
        except ValueError:
            continue
    return None


def _weekday_in(text: str) -> int | None:
    match = RE_WEEKDAY_WORD.search(text or "")
    if not match:
        return None
    return WEEKDAY_INDEX.get(match.group(1).lower())


def _weekdays_in(text: str) -> set:
    """EVERY weekday a heading names. A teacher writing one line for several
    class periods names one day per period."""
    return {WEEKDAY_INDEX[m.group(1).lower()]
            for m in RE_WEEKDAY_WORD.finditer(text or "")
            if m.group(1).lower() in WEEKDAY_INDEX}


def day_heading(text: str, year_start: int | None):
    """Is this line a dated heading? -> (kind, value, label, rest) or None.

    kind "date" -> value is a date; kind "dayn" -> value is the day number.
    `label` is the heading as the teacher wrote it (it goes in the date_note,
    so the student can find the line on the page). `rest` is any content that
    followed the heading in the same paragraph.
    """
    line = _clean(text)
    if not line or RE_SEPARATOR.match(line):
        return None
    # A line that states a deadline or a mark is work, never a section label.
    #
    # [MEASURED] 2026-09-02: "100 points. Due Friday, Sep. 25, 11:59 PM." and
    # "100 pts, due Sep 26" were promoted to headings — the two biggest
    # assignments in AI Frontiers' doc — and a heading is a label, so they
    # were deleted rather than shown. The date-ish lead is the same in both
    # cases ("Sep 25" reads exactly like a day heading); what separates them
    # is that a heading announces a day and this announces work.
    if RE_DUE_IN_LINE.search(line) or RE_MARKS_IN_LINE.search(line):
        return None
    stripped = line.lstrip("*•-–— \t")

    numbered = RE_DAY_N_LEAD.match(stripped)
    classed = None if numbered else RE_CLASS_N_LEAD.match(stripped)
    match = numbered or classed or RE_NAMED_DAY_LEAD.match(stripped)
    if match:
        # Offsets, carefully: the regexes ran against `stripped`, but the label
        # shown to the student has to come out of `line`. Getting this wrong
        # printed "Day 1 (Monday 8/24" with the bracket lopped off.
        lead = len(line) - len(stripped)
        tail = stripped[match.end():]
        spaces = len(tail) - len(tail.lstrip())
        after = tail.lstrip()
        paren = re.match(r"\(([^)]{0,60})\)", after)
        inside = paren.group(1) if paren else ""
        rest = after[paren.end():].strip() if paren else after
        # A heading has to be short OR self-terminate with its parenthetical.
        # Otherwise it is a paragraph that opens with the word "day".
        if not paren and len(line) > HEADING_CHARS:
            return None
        label_end = lead + match.end() + (spaces + paren.end() if paren else 0)
        label = line[:label_end].strip()
        when = _date_in(inside, year_start) or (
            _date_in(rest, year_start) if len(rest) < 40 else None)
        if when is not None:
            return "date", when, label, rest
        if numbered:
            return "dayn", int(match.group(1)), label, rest
        if classed:
            # The whole heading is the label: it carries the weekday names that
            # date it ("Class 10 : Tuesday for Periods 1 & 3 / Wednesday …").
            return "classn", int(match.group(1)), line, ""
        return None

    if len(line) > HEADING_CHARS:
        return None

    # "Monday 9/8", "Mon, Sept 8", "9/8", "September 8" — a bare dated heading.
    when = _date_in(line, year_start)
    if when is not None and not RE_BLOCK_LEAD.match(line):
        # Guard against a sentence that merely contains a date.
        words = len(line.split())
        if words <= 8:
            return "date", when, line, ""
    return None


def _heading_label(text: str) -> str:
    """The part of a heading worth quoting back. A block heading is often a
    heading plus a paragraph of instructions to the class ("Please note: we
    will be meeting 5 different times…"); the date_note only needs the part
    that lets the student find the line again."""
    line = _clean(text)
    match = RE_DATE_TOKEN.search(line[:120])
    if match:
        return line[:match.end()].strip()
    return (line[:70] + "…") if len(line) > 70 else line


def block_heading(text: str, year_start: int | None):
    """A 'Week 3&4 … - 8/24' heading -> (start_date, label), or None.

    Only the START matters here. A page section is not bounded the way a table
    is: the teacher names the day the block began and then lists its days.
    """
    line = _clean(text)
    if not line or not RE_BLOCK_LEAD.match(line.lstrip("*•-– \t")):
        return None
    # A real block heading names its date up front; the rest of the paragraph is
    # often a note to the class ("We will be meeting 5 different times…"), so
    # only the opening is searched. Without that bound, a paragraph mentioning
    # "week" and quoting some other date later on would move the whole block.
    opening = line[:120]
    span = dates_mod.parse_range(opening, year_start)
    if span:
        return span[0], span[1], _heading_label(line)
    when = _date_in(opening, year_start)
    if when is not None:
        # Only a start was given, so the week it opens is the span. A block
        # heading names the week; five school days covers it either way.
        return when, when + timedelta(days=6), _heading_label(line)
    return None


def _leaf_blocks(body):
    """Block elements in document order, innermost only, so nesting does not
    read the same sentence twice. Table cells are skipped: a page with a real
    table is handed to items.extract_doc, which understands columns."""
    nodes = []
    for node in body.find_all(BLOCK_TAGS):
        if node.find_parent("table") is not None:
            continue
        if node.find(BLOCK_TAGS) is not None:
            continue          # a container; its children are the leaves
        nodes.append(node)
    return nodes


# Which assessment word was named decides the category, so a quiz is not
# scored as a test. The scorer's own keyword pass reads titles, and a page line
# is long enough that an incidental word later in it would win otherwise.
TEST_WORDS = re.compile(r"^(tests?|exams?|midterms?|finals?|assessments?|examen)$", re.I)


def names_an_assessment(text: str) -> bool:
    """Does this line say that IT is a test or a quiz?"""
    bare = (text or "").lstrip("*•-–— \t")
    if RE_SUBORDINATE_OPENER.match(bare) or RE_NOT_GRADED.search(bare):
        return False
    return RE_ASSESSMENT_LEAD.match(bare) is not None


def assessment_category(text: str) -> str:
    bare = (text or "").lstrip("*•-–— \t")
    if not names_an_assessment(bare):
        return "neutral"
    match = RE_ASSESSMENT_LEAD.match(bare)
    return "test" if TEST_WORDS.match(match.group(1)) else "quiz"


def _kept_title(pattern, line: str) -> str:
    """Strip a prefix — unless stripping leaves a fragment.

    A LABEL prefix names the column and the information is whatever follows
    it: "Homework: large language models" is about large language models, and
    "HW: #27-49 (odds)" about the problems. A SENTENCE that happens to open
    with "Due" is itself the information.

    [MEASURED] 2026-09-02: "Due by the end of class" reached the board as "by
    the end of class", which names neither the work nor the day. The
    discriminator is the delimiter a label carries and a sentence does not,
    plus the case of what is left — a remainder starting mid-sentence in
    lower case is the tail of a sentence, not a title.
    """
    from schooldash.docs.items import strip_prefix

    match = pattern.match(line)
    stripped = strip_prefix(pattern, line)
    if not match or not stripped:
        return stripped
    if match.group(0).rstrip().endswith((":", "-", "–", "—")):
        return stripped
    return line if stripped[:1].islower() else stripped


def classify_line(text: str, prefixes: dict, links: list) -> tuple[str | None, str]:
    """(role, cleaned text). role: homework | due | assessment | action | None."""
    line = _clean(text)
    if not line or len(line) < 3 or RE_SEPARATOR.match(line):
        return None, ""
    if dates_mod.SKIP_TEXT.match(line):
        return None, ""
    # An annotation ("Reminder:", "Please note:") is peeled off first and what
    # is left is judged on its own merits. No extra guard is needed for a note
    # that wraps nothing: "Please note: I will be out on Thursday" matches no
    # rule once the prefix is gone, which is the right answer.
    annotation = prefixes.get("annotation")
    if annotation and annotation.match(line):
        from schooldash.docs.items import strip_prefix as _strip

        stripped_line = RE_STRANDED_COPULA.sub("", _strip(annotation, line))
        if len(stripped_line) >= 3:
            line = stripped_line
    from schooldash.docs.items import strip_prefix

    if RE_FOR_NEXT.match(line):
        return "homework", RE_FOR_NEXT.sub("", line).strip()
    if prefixes["homework"] and prefixes["homework"].match(line):
        return "homework", RE_STRANDED_COPULA.sub(
            "", _kept_title(prefixes["homework"], line))
    if prefixes["due"] and prefixes["due"].match(line):
        return "due", RE_STRANDED_COPULA.sub(
            "", _kept_title(prefixes["due"], line))
    if prefixes["skip"] and prefixes["skip"].match(line):
        return None, ""
    bare = line.lstrip("*•-–— \t")
    if names_an_assessment(bare) and not RE_NOT_GRADED.search(line):
        return "assessment", bare
    # A prose doc marks its homework by stating the deadline inside the
    # sentence rather than with a prefix, so a due phrase anywhere in the line
    # counts — but only under a dated heading, which the caller guarantees.
    if RE_DUE_IN_LINE.search(bare):
        return "due", bare
    if links and RE_ACTION_LEAD.match(bare):
        return "action", bare
    return None, ""


def stated_deadline(text: str, year_start: int | None):
    """(date, quoted phrase) when the line names its own deadline, else None.
    The FIRST one: "By September 18 … By October 14" — the nearer date is the
    one that can be missed next."""
    match = RE_LINE_DEADLINE.search(text or "")
    if not match:
        return None
    when = _date_in(match.group("date"), year_start)
    if when is None:
        return None
    return when, _clean(match.group(0))


# Words that carry no work on their own. A line made only of these plus a
# deadline is an instruction ABOUT the other lines, not a task of its own.
DEADLINE_FILLER = {
    "these", "this", "that", "those", "all", "both", "them", "they", "it",
    "should", "must", "need", "needs", "be", "is", "are", "was", "were",
    "have", "has", "do", "does", "done", "complete", "completed", "completing",
    "finish", "finished", "finishing", "turn", "turned", "hand", "handed",
    "in", "and", "or", "the", "a", "an", "to", "for", "by", "on", "of", "up",
    "please", "above", "below", "work", "assignments", "assignment", "items",
    "everything", "anything", "ready", "class", "tonight", "tomorrow", "due",
}


def deadline_only_line(text: str, year_start: int | None):
    """(date, phrase) when a line states a deadline and nothing else.

    [MEASURED] 2026-09-03. AP Chemistry writes a "For tonight" cell as a list
    and closes it with "These should be done by August 11th." — the deadline
    belongs to the list above it, not to that sentence, and the sentence is
    not homework.

    The test is what survives when the deadline phrase is removed: "These
    should be done" is pronouns and a verb, while "Work on SARA (25% due by
    10/8)" still names SARA and stays a task with a deadline of its own.
    """
    own = stated_deadline(text, year_start)
    if own is None:
        return None
    when, phrase = own
    rest = _clean((text or "").replace(phrase, " "))
    for token in re.findall(r"[a-z0-9]+", rest.lower()):
        if token.isdigit():
            continue
        if token not in DEADLINE_FILLER:
            return None
    return when, phrase


def _resolution(kind, value, label, course_lookup, meetings, where,
                days_written: int) -> dates_mod.Resolution:
    """Turn a heading into a dated Resolution, against the real timetable."""
    if kind == "dayn":
        return dates_mod.Resolution(
            None, dates_mod.NOTES["page_unresolved"].format(
                where=where, heading=dates_mod.quote_label(label)),
            "unresolved", "low")
    when = value
    weekday = _weekday_in(label)
    stated = f"{when:%a %b %d}"
    if weekday is not None and when.weekday() != weekday:
        # The weekday and the number disagree. The weekday is the reliable half
        # (spec §6.4), so snap to the nearest real meeting on that weekday.
        nearby = [d for d in meetings.dates(course_lookup)
                  if abs((d - when).days) <= 4 and d.weekday() == weekday]
        if nearby:
            chosen = min(nearby, key=lambda d: abs((d - when).days))
            return dates_mod.Resolution(
                chosen, dates_mod.NOTES["page_weekday_snapped"].format(
                    where=where, heading=dates_mod.quote_label(label),
                    claimed=f"{when:%b %d}",
                    actual_weekday=dates_mod.WEEKDAY_NAMES[when.weekday()],
                    chosen=f"{chosen:%a %b %d}"),
                "weekday_snapped", "medium", ["weekday_disagreed"])
    if not meetings.available or not meetings.dates(course_lookup) \
            or meetings.meeting_on(course_lookup, when):
        return dates_mod.Resolution(
            when, dates_mod.NOTES["page_stated"].format(
                stated=stated, where=where,
                heading=dates_mod.quote_label(label)), "absolute", "high")
    return dates_mod.Resolution(
        when, dates_mod.NOTES["page_stated_not_class"].format(
            stated=stated, where=where, heading=dates_mod.quote_label(label)),
        "absolute", "medium", ["not_a_class_day"])


# Link texts that name nothing. A teacher writes "click here" as often as the
# assignment's name, and a row called "here" is worse than a row called by its
# sentence. Matched WHOLE, so "Click here for Scientific Method Worksheet" — a
# real title in Honors Biology — is not caught by "click here".
GENERIC_LINK_TEXT = {
    "here", "click here", "link", "this", "this link", "that", "canvas",
    "assignment", "assignments", "the assignment", "form", "the form",
    "submission form", "board", "slides", "doc", "document", "google doc",
    "google docs", "read", "watch", "video", "page", "website", "site",
    "more", "learn more", "info", "details", "start here", "find it here",
    "find your task here", "find today's task here", "open", "download",
}

# Words a sentence ends on when it is handing off to the link that follows —
# "Open your [X]", "build toward the [X]", "Then do: [X]". A line ending on
# one of these has not named anything yet; the link does that.
HANDOFF_WORDS = {
    "the", "a", "an", "your", "my", "our", "this", "these", "those", "that",
    "to", "for", "on", "in", "into", "at", "from", "with", "toward", "towards",
    "start", "open", "see", "use", "using", "via", "is", "are", "and",
}

# How much longer than the link a line must be before the link is treated as
# the work's NAME rather than the line being about something else.
LINK_TITLE_SLACK = 12


def _hands_off_to(before: str, after: str) -> bool:
    """Does the sentence before a link hand the naming over to it?

    Two shapes, both from real lines:

      * it dangles — "Bring your numbers. Open your [Market Research with
        Perplexity] before class starts", "Then do: [CTN Practice: Fix a Weak
        Prompt]";
      * it has finished a sentence and the link is followed by marks or a
        deadline — "…[High School Side Hustle]. [Market Research with
        Perplexity], 20 points, now due TONIGHT by 11:59 pm".

    Neither is true of "Complete (Calendar and Dates Practice) [WayGround
    Assignment]" — Spanish 1's homepage, where the sentence names the work and
    the link is only the tool it lives in. Taking the link's words there turned
    a named quiz into "WayGround Assignment" and, because the category is read
    from the title, turned a QUIZ into untyped work. That is why this predicate
    exists instead of "a link wins".
    """
    before = (before or "").strip()
    after = (after or "").strip()
    if not before:
        return False                    # the line IS the link; nothing to do
    if before.endswith((":", "—", "–", "-")):
        return True
    words = re.findall(r"[A-Za-z']+", before)
    if words and words[-1].lower() in HANDOFF_WORDS:
        return True
    if before.endswith((".", "!", "?")):
        return bool(RE_MARKS_IN_LINE.search(after) or RE_DUE_IN_LINE.search(after))
    return False


def _link_title(line: str, links: list) -> str:
    """The work's name, when a line is a sentence wrapped around a link.

    [MEASURED] 2026-09-03. In AI Frontiers every assignment name is a link
    inside a sentence: "Then do: [CTN Practice: Fix a Weak Prompt] — 10
    points, due before class Wednesday". The sentence states the deadline and
    the link names the work, so the row wants the link's words and the
    sentence's date.

    The last qualifying link wins, not the first: these sentences open with
    the standing project and close with the thing that is actually due.
    """
    text = _clean(line)
    best = ""
    for link in links or []:
        name = _clean(getattr(link, "text", "") or "")
        if not 8 <= len(name) <= 70:
            continue
        if len(re.findall(r"[A-Za-z]+", name)) < 2:
            continue
        if name.lower().strip(" .,:;!?") in GENERIC_LINK_TEXT:
            continue
        if name not in text or len(text) < len(name) + LINK_TITLE_SLACK:
            continue
        before, _, after = text.partition(name)
        if _hands_off_to(before, after):
            best = name
    return best


def _names_the_work(line: str, year_start: int | None) -> str:
    """The line above a detail line, when it is a bare NAME for the work.

    "Side Hustle Proposal" and "Second Pass: Revise the Mark" classify as
    nothing at all — no verb, no prefix, no date — which is correct for a
    line on its own and wrong when the next line is "100 points. Due Friday,
    Sep. 25". A name is short, states no deadline of its own, and is not
    itself a detail line. Returns "" when the line is not one.
    """
    text = (line or "").strip()
    if not text or len(text) > 60 or RE_POINTS_LEAD.match(text):
        return ""
    if stated_deadline(text, year_start) is not None:
        return ""
    words = re.findall(r"[A-Za-z]+", text)
    if not 1 <= len(words) <= 9:
        return ""
    return text.rstrip(" .:;,-–—")


def extract_prose(html: str, course_key: str, course_display: str,
                  course_lookup: str, meetings, where: str = "the class homepage",
                  source_url: str = "", profile=None,
                  source: str = "canvas_page",
                  kind: str = "course homepage") -> ProseResult:
    """Every piece of work stated in one prose document. Pure: no network, no
    clock. `source`/`kind` say where it came from — a Canvas page or a
    teacher's own doc, which are the same shape and the same rules."""
    from bs4 import BeautifulSoup

    result = ProseResult()
    prefixes = compile_prefixes(profile)
    year_start = meetings.school_year_start() or timezones.to_local(
        datetime.now(timezones.zone())).year
    soup = BeautifulSoup(html or "", "lxml")
    body = soup.body or soup
    nodes = _leaf_blocks(body)

    # ---- pass 1: where are the headings, and how many days per block? -------
    parsed: list = []
    block_start = None
    for node in nodes:
        text = _clean(node.get_text(" ", strip=True))
        block = block_heading(text, year_start)
        if block is not None:
            block_start = block[0]
            parsed.append(("block", block, text, ""))
            continue
        heading = day_heading(text, year_start)
        if heading is not None:
            parsed.append(("day", heading, text, block_start))
            continue
        parsed.append(("line", None, text, node))

    days_per_block: dict = {}
    current = None
    for kind, value, _text, _extra in parsed:
        if kind == "block":
            current = value[0]
            days_per_block.setdefault(current, 0)
        elif kind == "day" and value[0] != "classn":
            days_per_block[current] = days_per_block.get(current, 0) + 1

    # ---- pass 2: build the items -------------------------------------------
    day_resolution = None
    day_label = ""
    block_start = None
    seen_first_day = False
    previous_line = ""          # the line above, for a points-led detail line
    previous_item = None        # and the item it made, which that line replaces
    skipped_before_first_day = 0
    # The most recent date the page actually stated, and the day number it was
    # attached to. An undated "Day 4" counts forward from here.
    anchor_date = None
    anchor_number = 0
    anchor_label = ""
    # A separate anchor for year-long "Class N" numbering, which a block
    # heading must never reset.
    class_anchor = None
    class_anchor_number = 0
    class_anchor_label = ""
    block_span = None

    for kind, value, text, extra in parsed:
        if kind == "block":
            block_start, block_end, block_label = value
            block_span = (block_start, block_end)
            day_resolution, day_label = None, ""
            anchor_date, anchor_number, anchor_label = block_start, 0, block_label
            result.headings.append(block_label)
            continue

        if kind == "day":
            heading_kind, heading_value, label, rest = value
            seen_first_day = True
            day_label = label
            if heading_kind == "classn":
                # Numbered across the whole year, so a block heading must not
                # reset the count — and its weekdays are the strongest evidence
                # available, because the doc names one day per class period and
                # only his own timetable says which is his.
                stated = dates_mod.resolve_weekday_in_span(
                    course_lookup, _weekdays_in(label), block_span, label,
                    where, meetings)
                if stated is not None and stated.confidence == "high":
                    day_resolution = stated
                elif class_anchor is not None:
                    day_resolution = dates_mod.resolve_day_n_counted(
                        course_lookup, heading_value, class_anchor,
                        class_anchor_number, class_anchor_label, meetings,
                        where, label_is_class=True)
                    if day_resolution.when is None and stated is not None:
                        day_resolution = stated
                elif stated is not None:
                    day_resolution = stated
                else:
                    day_resolution = dates_mod.Resolution(
                        None, dates_mod.NOTES["page_day_no_anchor"].format(
                            n=heading_value, where=where), "unresolved", "low")
                if day_resolution.when is not None and (
                        class_anchor is None
                        or day_resolution.confidence == "high"):
                    class_anchor = day_resolution.when
                    class_anchor_number = heading_value
                    class_anchor_label = label
            elif heading_kind == "dayn":
                day_resolution = dates_mod.resolve_day_n_counted(
                    course_lookup, heading_value, anchor_date, anchor_number,
                    anchor_label, meetings, where)
            else:
                day_resolution = _resolution(
                    heading_kind, heading_value, label, course_lookup, meetings,
                    where, days_per_block.get(block_start, 0))
                # A stated date becomes the anchor everything after it counts
                # from, whether or not it carried a day number.
                if day_resolution.when is not None:
                    anchor_date = day_resolution.when
                    anchor_label = label
                    number = RE_DAY_N_LEAD.match(label.lstrip("*•-–— \t"))
                    anchor_number = int(number.group(1)) if number else 0
            result.headings.append(label)
            # A new day starts a new context. Without this the detail line at
            # the top of one cell took its name from the last line of the
            # previous cell — a different day, often a different assignment.
            previous_line = ""
            previous_item = None
            if rest:
                # content that shared the paragraph with its heading
                role, cleaned = classify_line(rest, prefixes, [])
                if role:
                    item = _build(cleaned, rest, role, day_resolution, day_label,
                                  [], course_key, course_display, course_lookup,
                                  meetings, where, source_url, year_start,
                                  source, kind)
                    if item is not None:
                        result.items.append(item)
            continue

        node = extra
        if node is None or not text:
            continue
        if not seen_first_day:
            # Course furniture above the first dated heading. Counted, not
            # hidden: the diagnostics say how much was passed over.
            if len(text) > 3:
                skipped_before_first_day += 1
            continue
        links = links_mod.extract_links(node, source_url)
        role, cleaned = classify_line(text, prefixes, links)
        if not role:
            # A line with no letters in it is not the name of anything. Google
            # Docs splits a sentence around a link into three nodes, so
            # "Workshop: build toward the [Side Hustle Proposal]." arrives as
            # "Workshop: build toward the" / "Side Hustle Proposal" / "." —
            # and the line above the next one is a full stop. [MEASURED]
            # 2026-09-03: that lone "." is why "100 pts, due Sep 26" kept its
            # own name while the identical line two cells earlier did not.
            if any(c.isalpha() for c in text):
                previous_line = text
                previous_item = None
            continue
        titled = cleaned
        supersedes = None
        # In one real doc the assignment's name is the link and the sentence
        # around it is only the lead-in and the deadline.
        named_by_link = _link_title(cleaned, links)
        if named_by_link:
            titled = named_by_link
        if (_is_detail_line(text) and previous_line
                and not _is_detail_line(previous_line)):
            # The work is named above; the marks and the date are here. They
            # are ONE assignment, so the detail line does not add a row — it
            # replaces the row the line above made, taking its name and
            # keeping its own stated deadline.
            #
            # Replacing rather than appending is the whole point. A prefix
            # convention ("HOMEWORK:" means due next meeting) had already
            # dated the line above; a deadline the teacher typed on the next
            # line is a statement, and a statement beats a convention. Left as
            # two rows it was the same work twice, two days apart, with the
            # wrong one on top.
            _, named = classify_line(previous_line, prefixes, links)
            if named:
                titled = named
                supersedes = previous_item
            else:
                named = _names_the_work(previous_line, year_start)
                if named:
                    titled = named
        item = _build(titled, text, role, day_resolution, day_label, links,
                      course_key, course_display, course_lookup, meetings,
                      where, source_url, year_start, source, kind)
        if item is not None:
            if supersedes is not None and supersedes in result.items:
                result.items.remove(supersedes)
            result.items.append(item)
        previous_line = text
        previous_item = item

    # A teacher repeats a standing deadline under every class it covers —
    # [MEASURED] the Membean fortnight appears three times. Same work, same
    # date, same id: one item. (merge.dedupe_docs would also catch these, but
    # an extractor should not hand the same thing over three times.)
    unique: dict = {}
    for item in result.items:
        unique.setdefault(item.item_id, item)
    duplicates = len(result.items) - len(unique)
    result.items = list(unique.values())
    before = len(result.items)
    result.items = _collapse_restatements(result.items)
    duplicates += before - len(result.items)

    result.diagnostics = {
        "headings": len(result.headings),
        "lines_before_first_heading": skipped_before_first_day,
        "repeated_lines_collapsed": duplicates,
        "where": where,
    }
    return result


# "pts" and "points" are the same word, and a teacher uses both in one
# document. Normalised before comparing, or the restatement check below sees
# two different assignments.
RE_MARK_WORD = re.compile(r"\bpts?\b", re.I)
RE_NOT_WORD = re.compile(r"[^a-z0-9]+")


def _normalised(title: str) -> str:
    return RE_NOT_WORD.sub(" ", RE_MARK_WORD.sub(
        "points", (title or "").lower())).strip()


# How far apart two identical names may be and still be one assignment.
RESTATED_DAYS = 2


def date_mod_date(iso: str | None):
    """An ISO date string as a date, or None. Local helper — no clock."""
    try:
        return date.fromisoformat(iso) if iso else None
    except ValueError:
        return None


def _collapse_restatements(items: list) -> list:
    """One assignment the teacher wrote more than once, worded differently.

    [MEASURED] 2026-09-02, AI Frontiers' doc names a single project four
    times, in four cells:

        100 points. Due Friday, Sep. 25, 11:59 PM. This is the project …
        , due Sep 26.
        100 points, due Sep 26
        100 pts, due Sep 26

    Three of those share a date and are the same piece of work. `merge`'s 0.7
    Jaccard threshold scores "points" against "pts" at 0.67 and keeps both,
    and the fragment beginning with a comma is a line whose link text was
    lifted out of it. A board that lists one project three times is a board he
    stops reading.

    Deliberately narrow: same date, and one title must CONTAIN another once
    abbreviations are normalised. Two assignments that merely resemble each
    other are never collapsed, because losing real work is the worse error —
    and the longest wording is the one kept, since it carries the most detail.
    """
    by_date: dict = {}
    for item in items:
        by_date.setdefault(item.due_date, []).append(item)

    kept: list = []
    for _date, group in by_date.items():
        chosen: list = []
        for item in sorted(group, key=lambda i: len(i.title or ""), reverse=True):
            text = _normalised(item.title)
            if text and any(text and text in _normalised(other.title)
                            for other in chosen):
                continue
            chosen.append(item)
        kept.extend(chosen)

    # The same NAME on two dates a day or two apart is one assignment the
    # teacher dated twice, not two assignments. [MEASURED] 2026-09-03: AI
    # Frontiers writes "Side Hustle Proposal / 100 points. Due Friday, Sep.
    # 25" in one week's cell and "Side Hustle Proposal / 100 points, due Sep
    # 26" in another. Both are real lines; only one is a deadline.
    #
    # The EARLIER date wins, which is the rule COUNT 27 settled for a
    # different conflict and for the same reason: early is an annoyance, late
    # is a missed assignment. Identical names only — anything looser starts
    # deleting work that merely resembles other work.
    by_name: dict = {}
    for item in kept:
        by_name.setdefault(_normalised(item.title), []).append(item)
    dropped: set = set()
    for _name, group in by_name.items():
        if len(group) < 2:
            continue
        dated = sorted((i for i in group if i.due_date),
                       key=lambda i: i.due_date)
        for later in dated[1:]:
            first = date_mod_date(dated[0].due_date)
            this = date_mod_date(later.due_date)
            if first and this and (this - first).days <= RESTATED_DAYS:
                dropped.add(id(later))
    kept = [i for i in kept if id(i) not in dropped]
    return [item for item in items if item in kept]


def title_of(text: str) -> str:
    """The part of a line that names the work, without the teacher's aside."""
    line = _clean(text)
    match = RE_ASIDE.search(line)
    if match and match.start() >= MIN_TITLE_BEFORE_ASIDE:
        return line[:match.start()].rstrip(" ,;:-–")
    return line


def _item(cleaned, raw, course_key, course_display, due, due_date, note,
          confidence, extractor, flags, links, source_url, role,
          source: str = "canvas_page", kind: str = "course homepage"):
    """The one place a prose Item is constructed."""
    from schooldash.docs.items import clean_title

    category = assessment_category(cleaned) if role == "assessment" else None
    if category and category != "neutral":
        flags = [*flags, "stated_category"]
    item = Item(
        source=source, course_key=course_key, course=course_display,
        title=clean_title(title_of(cleaned)), detail=_clean(raw),
        raw_cell=_clean(raw), kind=kind, category=category or "neutral",
        due=due, due_date=due_date, all_day=False, date_note=note,
        confidence=confidence, extractor=extractor,
        url=links_mod.best_link(links) or source_url or None, links=links,
        flags=flags)
    return item.finalize()


def _build(cleaned: str, raw: str, role: str, resolution, heading: str,
           links: list, course_key: str, course_display: str, course_lookup: str,
           meetings, where: str, source_url: str,
           year_start: int | None = None, source: str = "canvas_page",
           kind: str = "course homepage") -> Item | None:
    """One classified line -> one Item, or None when it is not worth showing."""
    if not cleaned or len(cleaned) < 3:
        return None
    if resolution is None:
        resolution = dates_mod.Resolution(
            None, dates_mod.NOTES["page_unresolved"].format(
                where=where, heading=dates_mod.quote_label(heading) or "no heading"),
            "unresolved", "low")

    when = resolution.when
    note = resolution.note
    extractor = resolution.extractor
    confidence = resolution.confidence
    flags = list(resolution.flags)

    # A deadline the line states for itself wins outright, and is never shifted
    # to the next class — it already IS the deadline.
    own = stated_deadline(raw, year_start)
    if own is not None:
        when, phrase = own
        note = dates_mod.NOTES["line_deadline"].format(phrase=phrase)
        extractor, confidence = "absolute", "high"
        stamp = meetings.time_on(course_lookup, when)
        moment = stamp if stamp else datetime.combine(
            when, time(23, 59), tzinfo=timezones.zone())
        return _item(cleaned, raw, course_key, course_display, moment.isoformat(),
                     when.isoformat(), note, confidence, extractor, flags, links,
                     source_url, role, source=source, kind=kind)

    # Homework is set on the day and wanted at the next class — the same rule
    # the doc extractor uses, so a page and a doc never disagree about it.
    if role == "homework" and when is not None:
        following = meetings.next_after(course_lookup, when)
        if following is not None:
            shift = dates_mod.NOTES["page_homework"].format(
                assigned=f"{when:%b %d}", where=where,
                heading=dates_mod.quote_label(heading))
            # A note that explains a correction — a weekday that disagreed with
            # the date, a day counted forward, a date that is not a class day —
            # is the only record of why this item sits where it does. Replacing
            # it with the shift template threw that away, so the two are joined
            # instead (the same thing items.py does for a doc row).
            corrected = bool(flags) or resolution.extractor != "absolute"
            # When the first half already explains how the date was found,
            # repeating the heading and the source is 150 wasted characters —
            # see NOTE_LABEL_CHARS. Say only what the shift adds.
            note = (f"{note}; set then, so due at the next class" if corrected
                    else shift)
            when = following

    due = due_date = None
    if when is not None:
        stamp = meetings.time_on(course_lookup, when)
        moment = stamp if stamp else datetime.combine(
            when, time(23, 59), tzinfo=timezones.zone())
        due, due_date = moment.isoformat(), when.isoformat()

    return _item(cleaned, raw, course_key, course_display, due, due_date, note,
                 confidence, extractor, flags, links, source_url, role,
                 source=source, kind=kind)


# ---------------------------------------------------------------------------
# announcements
#
# A teacher's announcement is where "orally communicated" homework lands when
# they remember to write it down. [MEASURED] 2026-09-01, Honors Biology:
#
#   title "Quiz Today"
#   body  "…Reminder that you have a quiz today on the patterns of life
#          textbook and lecture content… Also, your measurements worksheet is
#          due today in class. ALL late work will receive a 50%…"
#
# Two items, and both need the POSTED date to mean anything: "today" is only a
# date relative to when it was written. So an announcement item must carry a
# date phrase of its own — no phrase, no item. Without that rule every "late
# work is 50%" policy note becomes an undated task, and the board fills with
# things that are not work.

RE_DUE_PHRASE = re.compile(r"\b(due|turn in|turned in|hand in|handed in|submit|"
                           r"bring|by the end of)\b", re.I)
RE_SENTENCE = re.compile(r"(?<=[.!?])\s+")


def _sentences(text: str) -> list[str]:
    return [s.strip() for s in RE_SENTENCE.split(_clean(text)) if s.strip()]


def extract_announcement(title: str, message_html: str, posted: date,
                         course_key: str, course_display: str, course_lookup: str,
                         meetings, url: str = "", profile=None) -> ProseResult:
    """Work stated in one announcement. `posted` anchors every relative date."""
    from bs4 import BeautifulSoup

    from schooldash import quickadd
    from schooldash.docs.items import clean_title

    result = ProseResult()
    prefixes = compile_prefixes(profile)
    soup = BeautifulSoup(message_html or "", "lxml")
    body = soup.body or soup
    links = links_mod.extract_links(body, url)
    posted_label = f"{posted:%b %d}"
    title = _clean(title)

    def add(text: str, phrase: str | None, category: str | None):
        when, how = (quickadd.parse_when(phrase, posted, meetings, course_lookup)
                     if phrase else (None, ""))
        if not when:
            return False
        note = dates_mod.NOTES["announcement_dated"].format(
            phrase=phrase, title=title[:60], posted=posted_label)
        stamp = meetings.time_on(course_lookup, date.fromisoformat(when))
        moment = stamp if stamp else datetime.combine(
            date.fromisoformat(when), time(23, 59), tzinfo=timezones.zone())
        item = Item(
            source="canvas_page", course_key=course_key, course=course_display,
            title=clean_title(title_of(text)), detail=_clean(text),
            raw_cell=_clean(text),
            kind="announcement", category=category or "neutral",
            due=moment.isoformat(), due_date=when, all_day=False,
            date_note=note, confidence="medium", extractor="absolute",
            url=links_mod.best_link(links) or url or None, links=links,
            flags=(["from_announcement", "stated_category"]
                   if category and category != "neutral" else ["from_announcement"]))
        result.items.append(item.finalize())
        return True

    def phrase_in(text: str) -> str | None:
        match = quickadd.WHEN.search(text or "")
        return match.group("when") if match else None

    # 1. the title, when the title is the news ("Quiz Today", "HW due Friday")
    title_bare = title.lstrip("*•-–— \t")
    title_phrase = phrase_in(title)
    claimed = False
    if title_phrase and not RE_NOT_GRADED.search(title):
        if RE_ASSESSMENT_LEAD.match(title_bare):
            claimed = add(title, title_phrase, assessment_category(title_bare))
        elif RE_DUE_PHRASE.search(title) or (prefixes["homework"]
                                             and prefixes["homework"].match(title)):
            claimed = add(title, title_phrase, None)

    # 2. sentences in the body that name work AND name when
    for sentence in _sentences(body.get_text(" ", strip=True)):
        if RE_NOT_GRADED.search(sentence):
            continue
        role, cleaned = classify_line(sentence, prefixes, links)
        category = assessment_category(sentence) if role == "assessment" else None
        if role not in ("homework", "due", "assessment"):
            if not RE_DUE_PHRASE.search(sentence):
                continue
            cleaned = sentence
            # a quiz/test named anywhere in a sentence that also states a
            # deadline is the subject of that sentence often enough to keep,
            # and the whole sentence is shown either way
            if re.search(r"\b(quiz|test|exam)\b", sentence, re.I):
                category = assessment_category(sentence)
                if category == "neutral":
                    category = "test" if re.search(r"\b(test|exam)\b", sentence,
                                                   re.I) else "quiz"
        phrase = phrase_in(sentence)
        if not phrase:
            continue
        if claimed and title_phrase == phrase and RE_ASSESSMENT_LEAD.match(title_bare) \
                and category in ("quiz", "test"):
            continue          # the title already said this
        add(cleaned or sentence, phrase, category)

    result.diagnostics = {"where": "an announcement", "title": title[:60]}
    return result
