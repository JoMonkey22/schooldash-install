"""Column classification: which columns hold work?

The profile's explicit headers win outright; heuristics apply only when the
profile is silent (None). An explicitly empty list means "no such columns" —
that is how Science & Religion's IN CLASS/HOMEWORK column stays honest: the
heuristic says due, the profile says only prefixed lines count.

Two traps, both live bugs in the predecessor, both tested:
- never match the bare word "practice" (it catches "In Class Topics & Practice")
- never let an "in class" veto beat the word "homework" in a heading
  (IN CLASS/HOMEWORK is a real column name and the veto silenced the course)
"""

import re

# "hw", "turn in" and "hand in" were missing, so a column headed plainly "HW"
# or "Turn in" was classified as neither work nor lesson plan — it was ignored.
# This is the one deliberate deviation from legacy/course_docs.py's byte-for-
# byte behaviour, and it only ever ADDS columns; every profiled course states
# its own headers explicitly, so none of them reach this.
STRONG_DUE = re.compile(
    r"due|homework|\bhw\b|the work|assign|out of class|turn in|hand in", re.I)
WEAK_DUE = re.compile(r"practice|work", re.I)
NOT_DUE = re.compile(r"in.?class|agenda|plan\b|topics|activity|notes", re.I)

# Two conventions share one header row. A column headed DUE / Turn in lists
# work wanted THAT day; a column headed HOMEWORK / THE WORK lists work SET that
# day and wanted at the NEXT class.
#
# [MEASURED] 2026-09-02, from him directly: Honors Algebra's "THE WORK" column
# put "2.1 HW / 2.2 HW" on the 8/31 row and both were due 9/2, and "2.4 HW" on
# the 9/2 row due 9/4. Reading that as a due column dated every item in the
# course exactly one class early.
#
# The "assigned" role is NEVER guessed from the header text, only stated in a
# profile. The header wording does not settle it — AP English uses the very
# same "THE WORK" as a due column — and the two possible errors are not
# equal: dating work a class EARLY means he does it early, and dating it a
# class LATE means he is late. So an unprofiled column keeps the earlier
# reading, and the model is asked the question when it learns the course
# (profiling/builder.py).


def is_due_column(heading: str) -> bool:
    """The heuristic, kept byte-compatible with legacy course_docs.py."""
    if STRONG_DUE.search(heading or ""):
        return True
    return bool(WEAK_DUE.search(heading or "") and not NOT_DUE.search(heading or ""))


def _norm(text: str) -> str:
    return " ".join((text or "").lower().split())


def _matches(header: str, entries) -> bool:
    if not entries:
        return False
    return _norm(header) in {_norm(e) for e in entries}


def classify_columns(headers: list[str], profile) -> tuple[list[str], int]:
    """(roles per column, date_column_index).

    Roles: 'date' | 'due' | 'skip' | 'plain'. date_column defaults to 0.
    """
    layout = profile.get("layout", default={}) if profile else {}
    date_headers = layout.get("date_column_headers")
    due_headers = layout.get("due_column_headers")     # None = silent, [] = explicitly none
    assigned_headers = layout.get("assigned_column_headers")
    skip_headers = layout.get("skip_column_headers")

    roles: list[str] = []
    date_col = None
    for index, header in enumerate(headers):
        if _matches(header, date_headers):
            roles.append("date")
            if date_col is None:
                date_col = index
            continue
        if _matches(header, skip_headers):
            roles.append("skip")
            continue
        # `due` is tested before `assigned` on purpose. A well-formed profile
        # never lists a header in both — schema.validate refuses that now
        # (COUNT 27) — but a profile saved before that check still has to be
        # read, and the tie must break towards the EARLIER date. Doing work a
        # class early is an annoyance; being told it is due next class when it
        # was due today is a missed assignment.
        if _matches(header, due_headers):
            roles.append("due")
            continue
        if _matches(header, assigned_headers):
            roles.append("assigned")
            continue
        if due_headers is not None or assigned_headers is not None:
            # The profile has an opinion about at least one kind, so it is the
            # authority on both. Never re-date a course somebody pinned down.
            # Both matches are handled above, so anything reaching here is a
            # column the profile did not name: plain, not guessed at.
            roles.append("plain")
            continue
        # profile silent about both -> heuristics
        if NOT_DUE.search(header or "") and not STRONG_DUE.search(header or ""):
            roles.append("skip")
        elif is_due_column(header):
            roles.append("due")          # never guessed as "assigned" — see above
        else:
            roles.append("plain")

    if date_col is None:
        # heuristic: a column literally headed day/date, else column 0
        for index, header in enumerate(headers):
            if re.fullmatch(r"\s*(class\s+)?(day|date)(/week)?\s*", (header or ""), re.I):
                date_col = index
                roles[index] = "date"
                break
    if date_col is None:
        date_col = 0
        if roles:
            roles[0] = "date"
    return roles, date_col
