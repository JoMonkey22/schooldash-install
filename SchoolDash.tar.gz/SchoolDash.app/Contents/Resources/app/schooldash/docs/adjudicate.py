"""Model adjudication of ambiguous cells — the one place a model touches a
refresh, tightly bounded (spec §10.10): capped per run, cached by
(fingerprint, cell hash), never overriding a deterministic result, and loudly
reported at the cap — coverage is never silently truncated.
"""

import hashlib
import json
import re
from datetime import datetime, time

from schooldash import db, timezones
from schooldash.docs import dates as dates_mod
from schooldash.logging_setup import get

log = get("adjudicate")

SCHEMA = {
    "type": "object",
    "properties": {
        "due_date": {"type": ["string", "null"],
                     "description": "YYYY-MM-DD or null when undecidable"},
        "reason": {"type": "string"},
        "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
    },
    "required": ["due_date", "reason", "confidence"],
    "additionalProperties": False,
}

ISO = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def cell_hash(ambiguity: dict) -> str:
    key = f"{ambiguity.get('course_key')}|{ambiguity.get('cell')}|{ambiguity.get('row_text')}"
    return hashlib.sha1(key.encode("utf-8")).hexdigest()[:16]


def _prompt(ambiguity: dict, meeting_dates: list) -> str:
    return f"""One cell of a teacher's schedule table could not be dated deterministically.
Decide the due date it implies, or null if it genuinely cannot be decided.

Course: {ambiguity.get('course_key')}
The cell: {ambiguity.get('cell')!r}
The whole row: {ambiguity.get('row_text')!r}
Column headers: {ambiguity.get('headers')}
The current block (if known): {ambiguity.get('block')}
Real meeting dates of this course nearby: {', '.join(meeting_dates) or 'unknown'}
Why it was flagged: {ambiguity.get('reason')}

The date must be one of the real meeting dates unless the cell explicitly
states otherwise. Answer null rather than guess."""


def run(ambiguities: list[dict], doc_items: list, diagnostics: dict,
        options, cfg) -> None:
    """Fills dates ONLY on items whose extractor is 'unresolved'."""
    from schooldash.ai import detect
    from schooldash.ai.base import ProviderError

    cap = int(cfg["ai"].get("max_adjudications_per_run") or 12)
    provider = detect.provider_for("adjudication")
    ok, reason = provider.available()
    if provider.name == "null" or not ok:
        diagnostics["adjudications_skipped"] = len(ambiguities)
        log.info("no provider for adjudication (%s); %d cells left unresolved",
                 reason, len(ambiguities))
        return

    conn = db.connect()
    calls = 0
    resolved = 0
    for ambiguity in ambiguities:
        fingerprint = ambiguity.get("fingerprint") or "unknown"
        chash = cell_hash(ambiguity)
        cached = db.adjudication_get(conn, fingerprint, chash)
        if cached is None:
            if calls >= cap:
                diagnostics["adjudication_cap_hit"] = True
                remaining = len(ambiguities) - (resolved + calls)
                log.warning("adjudication cap (%d) hit; %d ambiguous cell(s) "
                            "left unresolved this run", cap, remaining)
                break
            try:
                cached = provider.complete_structured(
                    system="You date one ambiguous schedule cell. Precision "
                           "beats coverage: answer null rather than guess.",
                    user=_prompt(ambiguity, _nearby_meetings(ambiguity, doc_items)),
                    schema=SCHEMA, timeout=180)
            except ProviderError as exc:
                log.warning("adjudication failed for %s: %s",
                            ambiguity.get("cell"), exc)
                continue
            calls += 1
            due = cached.get("due_date")
            if due is not None and not (isinstance(due, str) and ISO.match(due)):
                cached["due_date"] = None   # the schema's format is not enforced
            db.adjudication_put(conn, fingerprint, chash, cached)

        due = cached.get("due_date")
        if not due:
            continue
        for item in doc_items:
            if (item.course_key == ambiguity.get("course_key")
                    and item.extractor == "unresolved"
                    and item.detail and item.detail in
                    (ambiguity.get("row_text") or "")):
                when = datetime.combine(
                    datetime.strptime(due, "%Y-%m-%d").date(), time(23, 59),
                    tzinfo=timezones.zone())
                item.due = when.isoformat()
                item.due_date = due
                item.extractor = "model_adjudicated"
                item.confidence = cached.get("confidence") or "low"
                item.date_note = dates_mod.NOTES["adjudicated"]
                item.finalize()
                resolved += 1
    conn.close()
    diagnostics["model_calls"] = diagnostics.get("model_calls", 0) + calls
    diagnostics["adjudicated_items"] = resolved
    log.info("adjudication: %d call(s), %d item(s) dated", calls, resolved)


def _nearby_meetings(ambiguity: dict, doc_items: list) -> list[str]:
    dates = sorted({i.due_date for i in doc_items
                    if i.course_key == ambiguity.get("course_key") and i.due_date})
    return dates[:12]
