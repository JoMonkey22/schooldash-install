"""A doc whose table is not a table: one cell per class meeting.

[MEASURED] 2026-09-02 (prosecution COUNT 32). AI Frontiers' schedule doc had
reported **zero** homework since 2026-08-26 while holding nineteen lines that
name work, among them "100 points. Due Friday, Sep. 25, 11:59 PM". Both
readers missed it, for different reasons:

* `tables.parse_tables` returns the whole schedule as ONE row. The three
  column names — DATE/WEEK, CLASS DAY, IN CLASS/HOMEWORK — arrive inside a
  single cell separated by line breaks, and each school day is its own cell
  holding "Day 1 / Tuesday, Sep. 1 / …". There is no column for
  `classify_columns` to classify, so no row is ever an item.
* `prose.extract_prose` reported `headings: 0`. It anchors sections on
  headings and deliberately skips table cells — "a page with a real table is
  handed to items.extract_doc, which understands columns" — which is exactly
  the assumption that fails when the table is a layout device.

The teacher's document is not malformed. On screen it reads as three columns;
the HTML simply does not carry that structure. Google Docs does this when a
table is built by dragging rather than typing.

So this module does not add a third way to read a document. Each cell already
opens with its own date line, which is precisely what prose needs and lacks —
so the cells are rewritten as dated sections and handed to `prose`, whose line
classification, stated deadlines, assessment rules, de-duplication and date
notes then apply unchanged. A bug fixed in prose is fixed here too, and there
is no second set of rules to keep in step.

Fallback only, and last: a doc whose tables read as tables never reaches this,
so the golden fixtures are untouched.
"""

from __future__ import annotations

import html as html_mod
import re

from schooldash.docs import dates as dates_mod
from schooldash.docs import prose as prose_mod
from schooldash.docs import tables as tables_mod

# A layout table has a cell per meeting, so a doc read this way shows several.
# One or two dated cells is a normal table with a stray date in it, and
# rewriting that would be guessing at a document that already reads correctly.
MIN_DATED_CELLS = 3

# The header cell of such a table holds every column name at once. It is not a
# meeting and must not become a section: as a heading it would swallow the
# first real day's content.
RE_COLUMN_WORDS = re.compile(
    r"^(date|week|class\s*day|day|in\s*class|homework|hw|assignment|topic|"
    r"agenda|notes?|due)\b", re.I)

# Which lines open a meeting. Deliberately narrow, and matched only at the
# START of a line, because promotion is destructive: a line made into a
# heading is that section's label and never becomes an item.
#
# [MEASURED] 2026-09-02, and this is the whole reason for the rule. Handing
# every line to `prose.day_heading` promoted "100 pts, due Sep 26" — the
# 100-point project, the single most important thing in the document — into a
# section heading, which deleted it. Three other work lines went the same way.
# `day_heading` is right for a prose page, where a heading stands alone on its
# own line; inside a layout cell every line is its own line, so that test
# admits far too much.
MONTHS = (r"jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec|"
          r"january|february|march|april|june|july|august|september|"
          r"october|november|december")
WEEKDAYS = (r"mon|tue|tues|wed|weds|thu|thur|thurs|fri|sat|sun|monday|tuesday|"
            r"wednesday|thursday|friday|saturday|sunday")
RE_DAY_LEAD = re.compile(
    rf"^(?:"
    rf"(?:day|d[íi]a|class|session|lesson)\s*\d{{1,3}}"      # Day 4, Class 12
    rf"|(?:{WEEKDAYS})\.?,?\s*(?:(?:{MONTHS})\.?\s*\d{{1,2}}|\d{{1,2}}\s*/\s*\d{{1,2}})?"
    rf"|(?:{MONTHS})\.?\s*\d{{1,2}}"                          # Aug 6
    rf")\b\.?", re.I)

# A line that names work is content, whatever it starts with. Checked against
# the part that would BECOME the heading, so "Thursday, Aug. 13 by the end of
# class. Upload as a PDF" still opens a section and keeps its instruction.
RE_WORK_SIGNAL = re.compile(
    r"\b(due|pts|points|homework|hw|turn in|hand in|upload|submit|read|watch|"
    r"bring|complete|finish)\b", re.I)


# Tags that end a line. Everything else — notably <a> and <span>, which is
# what a Google Doc wraps every link and every styled run in — is part of the
# sentence around it.
# Both real documents write one line per <li>, with the sentence's fragments
# and its links as <span>s INSIDE that <li>. So the list containers have to be
# here too: without <ul>, the walk never descends into the list and buffers
# every bullet as a single line — [MEASURED] 2026-09-03, a whole day of
# Honors Biology arrived as "All Mixed Up Lab Procedures DUE Bell work
# Textbook Introductions/Tour Quiz Review/feedback…".
_BLOCK_TAGS = ("p", "div", "li", "ul", "ol", "dl", "dt", "dd",
               "table", "thead", "tbody", "tr", "td", "th",
               "section", "article", "blockquote", "pre",
               "h1", "h2", "h3", "h4", "h5", "h6")
_WS = re.compile(r"\s+")


def _cell_lines(cell) -> list[str]:
    """The cell's lines, however the teacher broke them.

    Read from the cell's own markup rather than its flattened text: a Google
    Doc separates lines inside a cell with paragraphs, a hand-written page
    with <br>, and `cell_text` renders the second kind as spaces. [MEASURED]
    2026-09-02: the real doc worked and the synthetic fixture reproducing it
    did not, purely because the fixture used <br> — which meant the fixture
    was testing something the real document never exercises.
    """
    node = getattr(cell, "node", None)
    if node is None:
        return [line.strip() for line in (getattr(cell, "text", "") or "").split("\n")
                if line.strip()]

    from bs4 import BeautifulSoup

    soup = BeautifulSoup(str(node), "html.parser")
    for br in soup.find_all("br"):
        br.replace_with("\n")
    # Break at BLOCK boundaries only. `get_text("\n")` breaks between every
    # pair of text nodes, and a link is a text node — so a sentence with a
    # link in the middle of it arrived as three lines:
    #
    #     Bring your numbers. Open your
    #     Market Research with Perplexity      <- the <a>
    #     before class starts.
    #
    # [MEASURED] 2026-09-03: that is one cause behind every fragment left in
    # AI Frontiers, a doc where almost every assignment name is a link. The
    # first piece became an item called "Bring your numbers. Open your", the
    # last piece was orphaned, and a deadline written after the link belonged
    # to nothing. Inline tags (a, span, b, i, em, strong, u, code) stay
    # inline; only p/div/li/h*/tr/td and <br> start a new line.
    return [_text_of(piece) for piece in _cell_pieces(soup)]


def _text_of(fragment: str) -> str:
    """A line's visible text, whitespace collapsed."""
    from bs4 import BeautifulSoup

    soup = BeautifulSoup(fragment, "html.parser")
    return _WS.sub(" ", soup.get_text(" ")).strip()


def _cell_pieces(soup) -> list[str]:
    """The cell's lines as HTML, so the links inside them survive.

    Text was enough while a line was only ever a title. It is not enough now:
    the rewritten sections are what `prose` reads, and `prose` takes an item's
    links from the markup of the line it came from. Escaping the line threw
    every anchor away — so for the two classes this reader serves, no row on
    the board had a link to click, and the rule that names an assignment after
    the link inside its sentence could never fire. [MEASURED] 2026-09-03.
    """
    pieces: list[str] = []
    buffer: list = []

    def flush() -> None:
        fragment = "".join(str(part) for part in buffer).strip()
        buffer.clear()
        if fragment and _text_of(fragment):
            pieces.append(fragment)

    def walk(parent) -> None:
        for child in getattr(parent, "children", []):
            name = getattr(child, "name", None)
            if name == "br":
                flush()
            elif name in _BLOCK_TAGS:
                flush()
                walk(child)
                flush()
            else:
                buffer.append(child)

    root = soup.find("td") or soup.find("th") or soup
    walk(root)
    flush()
    return pieces


def _cell_markup(cell) -> list[str]:
    """The cell's lines as HTML fragments (see `_cell_pieces`)."""
    node = getattr(cell, "node", None)
    if node is None:
        return [html_mod.escape(line) for line
                in (getattr(cell, "text", "") or "").split("\n") if line.strip()]

    from bs4 import BeautifulSoup

    soup = BeautifulSoup(str(node), "html.parser")
    return _cell_pieces(soup)


def _is_column_header_cell(lines: list[str]) -> bool:
    """A cell that is a stack of column names rather than a day.

    Every line has to look like a column name. "DATE/WEEK / CLASS DAY / IN
    CLASS/HOMEWORK" qualifies; a day cell whose first line happens to say
    "Homework" does not, because its other lines are prose.
    """
    if not lines or len(lines) > 6:
        return False
    return all(RE_COLUMN_WORDS.match(line) and len(line) <= 40
               for line in lines)


def to_sections(html: str, year_start: int | None) -> tuple[str, int]:
    """Rewrite a layout table's cells as dated sections. -> (html, days found).

    Promotion is per LINE, not per cell. [MEASURED] 2026-09-02: a cell in this
    doc can hold more than one meeting — "Day 1 … Day 2: AI Basics Exit Ticket
    …" — so treating a cell as one section buried every day after the first
    inside the previous day's content, and nine items came out where nineteen
    lines name work. A cell is a box the teacher dragged; it carries no
    meaning. The date lines do.

    Week ranges are tested BEFORE day headings, because "Aug 3–7 Week 1"
    matches both and reading it as a day invents a meeting on Aug 3.
    """
    nodes, _body = tables_mod.parse_tables(html)
    pieces: list[str] = []
    days = 0
    for node in nodes:
        grid = tables_mod.build_grid(node)
        for row in grid:
            for cell in row:
                if not cell.origin:
                    continue          # a colspan/rowspan echo of another cell
                markup = _cell_markup(cell)
                lines = [_text_of(piece) for piece in markup]
                if not lines or _is_column_header_cell(lines):
                    continue
                index = 0
                while index < len(lines):
                    line = lines[index]
                    # Ranges first. "Aug 31–Sep 4" starts with a date, so the
                    # day rule would claim it and invent a meeting on Aug 31
                    # — while what it really marks is the block those meetings
                    # are numbered inside.
                    if dates_mod.RE_RANGE.search(line) or \
                            prose_mod.RE_BLOCK_LEAD.match(line):
                        pieces.append(f"<h2>{html_mod.escape(line)}</h2>")
                        index += 1
                        continue
                    lead = RE_DAY_LEAD.match(line)
                    if lead and not RE_WORK_SIGNAL.search(lead.group(0)):
                        heading = lead.group(0).strip()
                        rest = line[lead.end():].strip(" .:—–-")
                        # "Day 2" on its own line, with "Monday, Aug. 10" on
                        # the next: one heading split by a line break. Folded
                        # only when that next line is itself a date, never
                        # when it is the day's content.
                        nxt = lines[index + 1] if index + 1 < len(lines) else ""
                        if not rest and nxt and not RE_WORK_SIGNAL.search(nxt):
                            follow = RE_DAY_LEAD.match(nxt)
                            if follow and follow.group(0).strip() == nxt.strip():
                                heading = f"{heading} ({nxt})"
                                index += 1
                        pieces.append(f"<h3>{html_mod.escape(heading)}</h3>")
                        days += 1
                        if rest:
                            pieces.append(f"<p>{html_mod.escape(rest)}</p>")
                        index += 1
                        continue
                    # The line's own markup, not its escaped text, so the
                    # anchors inside it reach `prose` and end up on the item.
                    pieces.append(f"<p>{markup[index]}</p>")
                    index += 1
    return f"<html><body>{''.join(pieces)}</body></html>", days


def extract_cells(html: str, course_key: str, course_display: str,
                  course_lookup: str, meetings, where: str = "the class doc",
                  source_url: str = "", profile=None, source: str = "doc",
                  kind: str = "cell-per-meeting doc"):
    """Read a layout-table doc, or return an empty result if it is not one."""
    from datetime import datetime

    from schooldash import timezones

    year_start = meetings.school_year_start() or timezones.to_local(
        datetime.now(timezones.zone())).year
    rewritten, days = to_sections(html, year_start)
    result = prose_mod.ProseResult()
    if days < MIN_DATED_CELLS:
        result.diagnostics["cells_dated"] = days
        return result

    result = prose_mod.extract_prose(
        rewritten, course_key, course_display, course_lookup, meetings,
        where=where, source_url=source_url, profile=profile, source=source,
        kind=kind)
    result.diagnostics["cells_dated"] = days
    return result
