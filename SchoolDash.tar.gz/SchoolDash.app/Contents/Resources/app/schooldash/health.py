"""`python run.py health` — what works right now, and the one-line fix for
whatever does not. Cache-only: no *outbound* network calls (the web
/api/health mirrors this rule). The port probe below talks to 127.0.0.1 only,
which never leaves the machine."""

import json
import platform
import socket
import sys
from datetime import datetime
from urllib.error import URLError
from urllib.request import urlopen

from schooldash import config, db, paths, timezones


def _port_line(host: str, port: int) -> str:
    """Free / ours / somebody else's — the third case is the one that needs a
    fix, and on macOS it is almost always AirPlay Receiver squatting on 5000."""
    probe = socket.socket()
    try:
        probe.bind((host, port))
        return f"{host}:{port} free"
    except OSError:
        pass
    finally:
        probe.close()

    try:
        with urlopen(f"http://{host}:{port}/api/health", timeout=1.0) as response:
            if response.status == 200:
                return f"{host}:{port} — SchoolDash is already serving"
    except (URLError, OSError, ValueError):
        pass

    fix = ("change server.port in config.json"
           if sys.platform != "darwin"
           else "System Settings > General > AirDrop & Handoff > turn off "
                "AirPlay Receiver, or change server.port in config.json")
    return f"{host}:{port} IN USE by another program — {fix}"


def unlearned_with_docs(profiles: dict) -> list[str]:
    """Courses whose homework really might be under-read: a doc to read, and no
    model has read it.

    [PROVEN] tests/test_prosecution.py: this used to name every heuristic
    profile, including five non-academic courses with no doc at all — a warning
    about nothing, which teaches the reader to skip the line.
    """
    from schooldash.profiling import builder

    return sorted(key for key, profile in profiles.items()
                  if builder.needs_learning(profile)[0] and builder.has_doc(profile))


def run(verbose: bool = False) -> int:
    print(f"SchoolDash health — {datetime.now(timezones.zone()):%Y-%m-%d %H:%M %Z}")
    print(f"  python     {platform.python_version()} on {sys.platform}")
    print(f"  project    {paths.project_root()}")

    # Timezone self-test: the Canvas-UTC trap, checked on every health run.
    probe = timezones.local_date("2026-08-14T06:59:00Z")
    tz_ok = probe.isoformat() == "2026-08-13"
    print(f"  timezone   {timezones.zone()} — UTC 06:59Z lands on {probe} "
          f"({'ok' if tz_ok else 'WRONG — expected 2026-08-13'})")

    cfg_file = paths.config_path()
    if not cfg_file.exists():
        print("  config     MISSING — run: python run.py setup --import-legacy")
    else:
        try:
            cfg = config.load(refresh=True)
            missing = config.missing_for_refresh(cfg)
            if missing:
                print("  config     incomplete:")
                for line in missing:
                    print(f"             - {line}")
            else:
                print("  config     ok "
                      f"(class feed {config.redact(cfg['veracross']['class_ics'])}, "
                      f"canvas ics {config.redact(cfg['canvas_ics'])})")
            server = cfg["server"]
            print(f"  port       {_port_line(server['host'], server['port'])}")
        except config.ConfigError as exc:
            print(f"  config     BROKEN — {exc}")

    try:
        conn = db.connect()
        runs = db.list_runs(conn, limit=1)
        done = len(db.get_done_ids(conn))
        conn.close()
        if runs:
            last = runs[0]
            print(f"  last run   {last['started']} ok={last['ok']} counts={json.dumps(last['counts'])}")
        else:
            print("  last run   never — run: python run.py refresh")
        print(f"  ticked off {done} item(s)")
    except Exception as exc:  # noqa: BLE001
        print(f"  database   ERROR — {exc}")

    state = paths.state_json_path()
    if state.exists():
        try:
            data = json.loads(state.read_text(encoding="utf-8"))
            print(f"  cache      {len(data.get('items', []))} item(s), "
                  f"generated {data.get('generated_at', '?')}")
        except ValueError:
            print("  cache      corrupt (a refresh rewrites it)")
    else:
        print("  cache      empty — the dashboard will show a setup message until a refresh")

    # Which courses can actually be read matters more than whether an AI is
    # present: a shipped profile needs no AI, and a heuristic one silently
    # returns almost nothing for a prose-shaped doc. Say so either way.
    try:
        from schooldash.profiling import store
        profiles, problems = store.load_all()
        if not profiles:
            print("  profiles   none — run: python run.py setup --profile-all")
        else:
            heuristic = sorted(k for k, p in profiles.items()
                               if p.raw.get("learned_by") in (None, "", "heuristic"))
            at_risk = unlearned_with_docs(profiles)
            print(f"  profiles   {len(profiles)} course(s), "
                  f"{len(profiles) - len(heuristic)} learned, "
                  f"{len(heuristic)} without a model")
            if at_risk:
                print(f"             unlearned WITH a doc (may under-read it): "
                      f"{', '.join(at_risk)} — run: python run.py setup --missing")
            elif heuristic:
                print(f"             the {len(heuristic)} without a model have no "
                      "doc to read, so there is nothing to learn")
        for problem in problems:
            print(f"  profiles   PROBLEM — {problem.splitlines()[0]}")
    except Exception as exc:  # noqa: BLE001
        print(f"  profiles   ERROR — {exc}")

    if sys.platform == "darwin":
        try:
            from schooldash import schedule_mac
            print(f"  notify     {schedule_mac.status()}")
        except Exception as exc:  # noqa: BLE001
            print(f"  notify     ERROR — {exc}")

    try:
        from schooldash.ai import detect
        name, note = detect.describe()
        extra = "" if name != "null" else " (optional — only chat and "
        print(f"  ai         {name} — {note}{extra}"
              + ("learning new teachers' docs need it)" if extra else ""))
    except ModuleNotFoundError:
        print("  ai         provider layer not built yet")

    log = paths.log_file()
    print(f"  log        {log}")
    return 0 if tz_ok else 1
