"""The credential vault: the sign-in details SchoolDash uses to log itself
back in when a session lapses.

Why this exists. Canvas at this school is Google single sign-on and Veracross
issues a thirty-minute session. Both expire, both used to need a person to
notice a red banner and sit through a browser window, and on a machine that is
not the developer's that step failed more often than it worked ([MEASURED]
2026-08-25 twice, 2026-08-26, 2026-09-01 on a second Mac). The owner's
decision (2026-09-01): the app may hold the student's own sign-in details and
use them to sign back in on their behalf — it is their own account, on their
own machine, doing what they would do by hand. This supersedes SPEC §5.1.

What is stored: per site, a username/email and a password, plus a flag saying
whether the site is entered through the Google account. Nothing else.

Where: data/credentials.json, written mode 0600, in the data home that is
gitignored and excluded from every installer payload. The owner explicitly
chose plain local storage over the macOS keychain for now ("since it's local
for the time being, don't worry about credential security"); the read/write
API here is the single seam to swap in the keychain later.

What never happens: a password is never logged, never printed, never sent
anywhere but the sign-in form of the site it belongs to, and never returned
by the status() call the dashboard reads. A test holds that line.
"""

import json
import os
import stat
from datetime import datetime

from schooldash import paths, timezones
from schooldash.logging_setup import get

log = get("credentials")

# The sites a student signs into. "google" is the school Google account that
# Canvas hands off to; Veracross may use the same account (SSO) or its own
# username and password, so it carries a `use_google` flag.
SITES = ("google", "veracross", "canvas")

FIELDS = {
    "google": ("email", "password"),
    "veracross": ("username", "password", "use_google"),
    "canvas": ("username", "password", "use_google"),
}


def _load() -> dict:
    target = paths.credentials_path()
    if not target.exists():
        return {}
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
    except (ValueError, OSError):
        log.warning("credentials.json is unreadable — treating it as empty")
        return {}
    return data if isinstance(data, dict) else {}


def _write(data: dict) -> None:
    target = paths.credentials_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(".tmp")
    # Create with owner-only permissions BEFORE any content lands in it.
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2)
    os.chmod(tmp, stat.S_IRUSR | stat.S_IWUSR)
    tmp.replace(target)
    try:
        os.chmod(target, stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass


def get(site: str) -> dict | None:
    """The stored details for one site, or None. The password is inside; the
    only callers are the sign-in flows in autologin.py."""
    entry = _load().get(site)
    if not isinstance(entry, dict):
        return None
    if not (entry.get("password") or entry.get("use_google")):
        return None
    return dict(entry)


def has(site: str) -> bool:
    return get(site) is not None


def set(site: str, **fields) -> dict:  # noqa: A001 — mirrors get()
    """Store or update one site's details. Only known fields are kept; an
    empty password leaves the existing one in place so a form that re-submits
    with the password box blank does not wipe it."""
    if site not in SITES:
        raise ValueError(f"unknown site {site!r}")
    data = _load()
    entry = dict(data.get(site) or {})
    for key in FIELDS[site]:
        if key not in fields:
            continue
        value = fields[key]
        if key == "password" and not value:
            continue
        if key == "use_google":
            entry[key] = bool(value)
        else:
            entry[key] = (value or "").strip()
    entry["updated"] = datetime.now(timezones.zone()).isoformat(timespec="seconds")
    data[site] = entry
    _write(data)
    log.info("credentials saved for %s (%s)", site,
             entry.get("email") or entry.get("username") or "no username")
    return status()[site]


def clear(site: str | None = None) -> None:
    if site is None:
        target = paths.credentials_path()
        if target.exists():
            target.unlink()
        log.info("all credentials cleared")
        return
    data = _load()
    if site in data:
        del data[site]
        _write(data)
        log.info("credentials cleared for %s", site)


def veracross_login() -> tuple[str, str] | None:
    """(username, password) for the Veracross form, or None.

    Veracross usernames at this school are the school email; when the student
    ticked "same as Google" the Google details are reused rather than asking
    for the same thing twice.
    """
    entry = get("veracross")
    google = get("google")
    if entry and entry.get("use_google") and google:
        return google.get("email") or entry.get("username") or "", google.get("password") or ""
    if entry and entry.get("password"):
        return entry.get("username") or (google or {}).get("email") or "", entry["password"]
    return None


def status() -> dict:
    """What the dashboard may see: which sites are set up and under which
    name. Passwords are reported as present/absent only — never their value,
    never their length."""
    data = _load()
    out = {}
    for site in SITES:
        entry = data.get(site) if isinstance(data.get(site), dict) else {}
        out[site] = {
            "configured": bool(entry.get("password") or entry.get("use_google")),
            "username": entry.get("email") or entry.get("username") or "",
            "use_google": bool(entry.get("use_google")),
            "has_password": bool(entry.get("password")),
            "updated": entry.get("updated"),
        }
    return out


def scrub(text: str) -> str:
    """Remove every stored password from a string before it is logged or
    shown. Cheap insurance for error messages that quote page text."""
    if not text:
        return text
    for entry in _load().values():
        if isinstance(entry, dict) and entry.get("password"):
            text = text.replace(entry["password"], "••••••")
    return text
