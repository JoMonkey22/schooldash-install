"""What each plan costs and how much AI it includes.

One place, because a price that lives in two files disagrees with itself
eventually — the amount the paywall shows and the amount the allowance is
computed from have to be the same number.

The allowances are set from measured cost, not from a guess (2026-09-03):

  * A chat question that reaches the model sends ~1,055 tokens in and comes
    back with ~155 (median of four real answers; the code caps output at
    1,024). On Haiku 4.5 that is $0.0018.
  * **Three in five chat questions never reach the model at all** — 18 of the
    app's 30 evaluation questions are answered by `ai/lookup.py` from the
    board itself, deterministically and for nothing. So an allowance of N
    model calls serves roughly 2.5N questions asked.
  * One Accelerate sends 1,092 tokens of fixed overhead plus the reading
    (capped at 40,000 characters) and writes ~2,240 tokens back — measured
    from the two real guides in the database, 9,233 and 8,696 characters. On
    Haiku 4.5 that is $0.014, and re-opening a guide is free because results
    are cached by content hash.

Basic is priced so the AI cannot eat the subscription: 200 chat calls and 10
guides is $0.50 of Haiku against $4.99, and a student who asks ten questions
a day never reaches it. Plus is ten times the usage for roughly twice the
price, which is only sane because the AI is a tenth of what the plan costs.
"""

from __future__ import annotations

# Haiku 4.5 list price, $ per million tokens (Anthropic, 2026-09-03).
HAIKU_IN_PER_MTOK = 1.00
HAIKU_OUT_PER_MTOK = 5.00

# Measured token sizes — see the module docstring for where each came from.
CHAT_TOKENS_IN = 1055
CHAT_TOKENS_OUT = 155
ACCELERATE_TOKENS_IN = 2592          # overhead + a ~6,000-character reading
ACCELERATE_TOKENS_OUT = 2240

# A photo of finished work, read by the model (`workcheck.py`, 2026-09-10).
# An image resized to 1600px on its long edge is about (1600*1200)/750 = 2,560
# tokens, plus ~400 for the rules and the assignment, and the replies measured
# ~300 back. On Haiku 4.5 that is $0.0044 — about 2.5 times a chat question,
# so it is charged as WORK_CHECK_CALLS chat calls rather than as one.
#
# It is NOT the $0.039 measured on his own machine: that figure is the Claude
# Code CLI's own ~18,000-token preamble, which it sends on every call and
# which is billed to the student's own Claude access, not to a plan. Only
# `anthropic_api` is ever metered — see allowance.METERED_PROVIDERS.
WORK_CHECK_TOKENS_IN = 2960
WORK_CHECK_TOKENS_OUT = 300

# Learning one course's profile — the model call that configures the
# deterministic extractor for one teacher's document. Measured from the prompt
# itself (2026-09-10): the template is 2,921 characters and the fenced excerpt
# is capped at 14,000 in `profiling/builder.py`, plus the 1,510-character
# output schema, at ~3.7 characters per token. On Haiku 4.5 that is $0.008.
#
# It is the best-value call in the app: it happens once per class and it is
# what makes that teacher's homework appear on the board at all. Without it
# extraction falls back to heuristics, which read tables fine and prose-shaped
# documents poorly — so a student whose grant ran out would not see a smaller
# app, they would see a WRONG one. That is why the free tier grants profiles
# separately instead of charging them against the monthly allowance.
PROFILE_TOKENS_IN = 4981
PROFILE_TOKENS_OUT = 600

# Profiles granted when an account is first set up: enough for a full
# timetable with room to spare. One-time, not monthly — a repair budget is
# monthly (see the `profiles` field on each plan), learning the timetable is
# not something that happens again every month.
SIGNUP_PROFILE_GRANT = 12

# What share of chat questions are answered without the model at all, so an
# allowance of model calls can be described honestly in questions.
LOOKUP_SHARE = 0.6

# **The free tier is 10 cents of Haiku a month, and that is a decision, not a
# rounding.** *"lest do 10c for the free one"* — 2026-09-10. Sized so that:
#
#   * it is plentiful for a normal student. 40 chat calls is ~100 questions
#     asked, because three in five never reach a model; or 13 photo checks; or
#     any mix, since a photo is charged as three chat calls.
#   * it is a FIFTH of Basic on both axes — 40 of 200 calls, 2 of 10 guides —
#     so there is a real gap to upgrade across. At 20c it would have been 40%
#     of what Basic costs to serve, and half its questions, which is too close
#     to sell against.
#   * a thousand free accounts using every call of it is $100 a month, not
#     $1,000. That is the number to plan a signup spike against.
#
# `profiles` is the repair budget and is NOT part of the 10c: a board that is
# wrong because an allowance ran out is the one failure that makes someone
# uninstall. 0 means unlimited, which is what the paid plans get.
PLANS: dict[str, dict] = {
    "free": {
        "key": "free",
        "name": "Free",
        "price": "0.00",
        "chat_calls": 40,
        "accelerations": 2,
        "profiles": 3,
        "blurb": "The whole board, and a taste of the AI. No card, no expiry.",
    },
    "basic": {
        "key": "basic",
        "name": "Basic",
        "price": "4.99",
        "chat_calls": 200,
        "accelerations": 10,
        "profiles": 0,                      # 0 means unlimited
        "blurb": "Everything on the board, chat, and ten study guides a month.",
    },
    "plus": {
        "key": "plus",
        "name": "Plus",
        "price": "10.00",
        "chat_calls": 2000,
        "accelerations": 100,
        "profiles": 0,
        "blurb": "Ten times the chat and the guides, for the weeks that need it.",
    },
}

DEFAULT_PLAN = "basic"
# What a signed-in account falls back to when its trial or subscription has
# run out. Before the free tier this was nothing and the app locked shut.
FREE_PLAN = "free"

# Everything the app does without any model at all: the board itself, the
# schedule, grades, links, ticking work off, and the three-in-five chat
# questions answered from the board. No plan limits any of it, and an
# exhausted allowance never takes it away.
ALWAYS_INCLUDED = (
    "the whole board and every date on it",
    "the schedule, grades and links",
    "the chat questions that need no model — about three in five",
)


def plan(key: str | None) -> dict:
    """The named plan, or Basic. An unknown name is never an error: a token
    minted by a future version must not lock someone out of the app."""
    return PLANS.get((key or "").strip().lower()) or PLANS[DEFAULT_PLAN]


def price_of(key: str | None) -> dict:
    p = plan(key)
    return {"amount": p["price"], "currency": "USD", "period": "month"}


def work_check_calls() -> int:
    """How many chat calls one photo check is worth, rounded up. Derived, not
    typed in, so it moves if either measurement does."""
    photo = (WORK_CHECK_TOKENS_IN / 1e6 * HAIKU_IN_PER_MTOK
             + WORK_CHECK_TOKENS_OUT / 1e6 * HAIKU_OUT_PER_MTOK)
    chat = (CHAT_TOKENS_IN / 1e6 * HAIKU_IN_PER_MTOK
            + CHAT_TOKENS_OUT / 1e6 * HAIKU_OUT_PER_MTOK)
    return max(1, -(-photo // chat).__int__()) if chat else 1


def allowance(key: str | None, kind: str) -> int:
    """Model calls of one kind included per month. 0 means unlimited — see
    allowance.check, which returns early on it rather than blocking, so a
    future plan that forgets to set one cannot lock the app."""
    field = {"chat": "chat_calls", "accelerate": "accelerations",
             "profiles": "profiles"}.get(kind)
    return int(plan(key).get(field, 0)) if field else 0


def _per_call(tokens_in: int, tokens_out: int) -> float:
    return (tokens_in / 1e6 * HAIKU_IN_PER_MTOK
            + tokens_out / 1e6 * HAIKU_OUT_PER_MTOK)


def monthly_ai_cost(key: str | None) -> float:
    """What a plan's full allowance of the features would cost on Haiku 4.5,
    if every call were used. Not a projection — a ceiling, so the price can be
    checked against it rather than hoped about.

    Repairs are deliberately NOT in this number; `repair_ceiling` has them.
    Adding them would make the figure the price was set against move for a
    reason that has nothing to do with what the student gets.
    """
    p = plan(key)
    chat = p["chat_calls"] * _per_call(CHAT_TOKENS_IN, CHAT_TOKENS_OUT)
    accel = p["accelerations"] * _per_call(ACCELERATE_TOKENS_IN,
                                           ACCELERATE_TOKENS_OUT)
    return round(chat + accel, 4)


def repair_ceiling(key: str | None) -> float:
    """What a plan's monthly profile-repair budget could cost. Zero for the
    paid plans, where it is unlimited and unmetered — a relearn only fires
    when a teacher restructures their document, which has happened 0 times in
    76 measured refreshes, so metering it there would be a limit for nobody.
    """
    return round(plan(key).get("profiles", 0)
                 * _per_call(PROFILE_TOKENS_IN, PROFILE_TOKENS_OUT), 4)


def signup_cost() -> float:
    """What it costs to learn a new account's whole timetable, once."""
    return round(SIGNUP_PROFILE_GRANT
                 * _per_call(PROFILE_TOKENS_IN, PROFILE_TOKENS_OUT), 4)


def questions_included(key: str | None) -> int:
    """The allowance stated the way a student experiences it: questions asked,
    not model calls, because most questions never make one."""
    calls = allowance(key, "chat")
    return int(round(calls / (1 - LOOKUP_SHARE))) if calls else 0


def for_display() -> list[dict]:
    """The plans someone can BUY, cheapest first, for the paywall and
    Settings. Free is not among them on purpose — it is where you already are
    when the paywall is showing, and a "$0.00 — buy now" row is nonsense.
    `free_summary()` describes it instead."""
    out = []
    for key in ("basic", "plus"):
        p = PLANS[key]
        out.append({
            "key": key,
            "name": p["name"],
            "price": p["price"],
            "blurb": p["blurb"],
            "chat_calls": p["chat_calls"],
            "questions": questions_included(key),
            "accelerations": p["accelerations"],
            "ai_ceiling": monthly_ai_cost(key),
        })
    return out


def free_summary() -> dict:
    """What the free tier includes, for the banner and Settings. Stated the
    way a student experiences it: questions asked, not model calls, and photo
    checks as an alternative use of the same pot rather than a separate one."""
    key = FREE_PLAN
    p = plan(key)
    return {
        "key": key,
        "name": p["name"],
        "blurb": p["blurb"],
        "questions": questions_included(key),
        "chat_calls": p["chat_calls"],
        "photo_checks": p["chat_calls"] // work_check_calls(),
        "accelerations": p["accelerations"],
        "profiles": p["profiles"],
        "signup_profiles": SIGNUP_PROFILE_GRANT,
        "ai_ceiling": monthly_ai_cost(key),
        "repair_ceiling": repair_ceiling(key),
        # Everything that needs no model, and therefore has no allowance at
        # all. This is most of the app and it is the reason a free tier is
        # worth having rather than a crippled demo.
        "always_free": ALWAYS_INCLUDED,
    }
