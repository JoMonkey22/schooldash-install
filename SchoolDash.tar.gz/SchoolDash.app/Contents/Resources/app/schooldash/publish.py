"""The anywhere-view: build a single self-contained Master Planner page from
the last refresh and (optionally) push it to Netlify on a schedule.

Privacy model: the snapshot NEVER contains feed URLs, tokens, or the session —
only the same schedule/homework the dashboard shows. Because a Netlify URL is
public, the payload is ENCRYPTED with a passphrase (PBKDF2-SHA256 210k +
AES-256-GCM); the page decrypts in the browser with WebCrypto and remembers
the passphrase on that device. No passphrase configured -> the publisher
refuses the Netlify push and says so (a local unencrypted file is still
written for the private claude.ai artifact flavor).
"""

import base64
import io
import json
import os
import re
import zipfile
from datetime import datetime
from pathlib import Path

import httpx

from schooldash import config, paths, pipeline, timezones
from schooldash.logging_setup import get

log = get("publish")

# An allowlist, not a denylist, and it must stay one: the snapshot leaves this
# machine, so anything added to state should be invisible remotely until
# someone deliberately names it here.
#
# "grades" is the reason this note exists. Course grades are read from the
# student's own portal session and are the most sensitive thing in state; they
# stay on the Mac. Do not add them here — not encrypted, not behind the
# passphrase. The passphrase protects a page from strangers, not from whoever
# the link gets forwarded to.
SNAPSHOT_KEYS = ["generated_at", "today", "block_label", "items",
                 "meetings_today", "schedule", "warnings", "errors"]


def build_snapshot(state: dict) -> dict:
    """Trim the state to what the remote page renders. No local paths, no
    diagnostics internals — and by construction no secrets ever enter state."""
    snapshot = {key: state.get(key) for key in SNAPSHOT_KEYS}
    snapshot["stale_after_hours"] = 30   # remote updates on the schedule
    snapshot["profiles"] = [
        {"course_key": p.get("course_key"), "display_name": p.get("display_name"),
         "course_type": p.get("course_type"), "canvas_url": p.get("canvas_url"),
         "notation": p.get("notation") or {}}
        for p in state.get("profiles", [])]
    per_course = (state.get("diagnostics") or {}).get("per_course") or {}
    snapshot["diagnostics"] = {"per_course": {
        key: {"course_links": info.get("course_links") or []}
        for key, info in per_course.items()}}
    snapshot["errors"] = [{"code": e.get("code"), "message": e.get("message"),
                           "fix": ""} for e in state.get("errors", [])]
    return snapshot


def _inline_assets() -> tuple[str, str, str]:
    web = paths.project_root() / "schooldash" / "web"
    template = (web / "templates" / "dashboard.html").read_text(encoding="utf-8")
    css = (web / "static" / "app.css").read_text(encoding="utf-8")
    js = (web / "static" / "app.js").read_text(encoding="utf-8")
    return template, css, js


# Only app.css and app.js were ever inlined, so every other `url_for` reached
# the published file as literal Jinja — `href="{{ url_for(...) }}"` — and the
# masthead logo and the favicon were broken on the one page meant to be read
# away from this Mac. The brand files are ~1.2 KB each, so they travel as
# data: URIs; anything not listed is dropped rather than shipped broken.
_BRAND_MIME = {".svg": "image/svg+xml", ".png": "image/png"}


def _data_uri(path: Path) -> str:
    mime = _BRAND_MIME.get(path.suffix.lower())
    if not mime or not path.exists():
        return ""
    return f"data:{mime};base64," + base64.b64encode(path.read_bytes()).decode("ascii")


# Controls that only exist because views.js wires them up. views.js is
# deliberately NOT inlined — a static snapshot has no server to set up, no
# classes to edit and no model to call — so its markup has to go too.
#
# [PROVEN] tests/test_prosecution.py: adding views.js to the template shipped
# `<script src="">` into both published flavours, which makes the browser fetch
# the PAGE as JavaScript, plus a Board/Classes/Settings nav and a microphone
# button that could never do anything.
LOCAL_ONLY_MARKUP = [
    r'<nav class="views"[^>]*>.*?</nav>',
    # 0.18: the panes are <section class="pane view"> and hold no nested
    # <section>, so the non-greedy match takes exactly one pane each.
    r'<section class="pane view" id="view-classes".*?</section>',
    r'<section class="pane view" id="view-settings".*?</section>',
    r'<section class="pane view" id="view-setup".*?</section>',
    r'<section class="pane" id="pane-accel">.*?</section>\s*</section>',
    r'<div class="chat-chips">.*?</div>',
    r'<div class="dock-context"[^>]*>.*?</div>',
    r'<button[^>]*id="chat-mic".*?</button>',
    r'<button[^>]*id="palette-open".*?</button>',
    r'<div id="palette" class="palette" hidden>.*?</div>\s*</div>\s*</div>',
]


def _strip_local_only(page: str) -> str:
    for pattern in LOCAL_ONLY_MARKUP:
        page = re.sub(pattern, "", page, flags=re.S)
    # Any script still pointing at a static file: app.js was replaced by the
    # payload above, so whatever is left has no file behind it on a static host.
    page = re.sub(r"\s*<script[^>]*src=\"\{\{[^}]*\}\}\"[^>]*>\s*</script>", "", page)
    return page


def _inline_static_refs(page: str) -> str:
    """Resolve the remaining {{ url_for('static', filename=...) }} refs.

    Static-only: the published page has no Flask behind it, so an unresolved
    one is a broken image, and a *guessed* path would be a broken image that
    looks deliberate.
    """
    static = paths.project_root() / "schooldash" / "web" / "static"

    def swap(match: re.Match) -> str:
        resolved = _data_uri(static / match.group("name"))
        if not resolved:
            log.warning("published page: no data URI for %s", match.group("name"))
        return resolved

    page = _strip_local_only(page)
    page = re.sub(
        r"\{\{\s*url_for\(\s*['\"]static['\"]\s*,\s*filename\s*=\s*"
        r"['\"](?P<name>[^'\"]+)['\"]\s*\)\s*\}\}",
        swap, page)
    # The manifest and service worker are the installable-app path, which only
    # exists on the local server; on a static snapshot both 404.
    page = re.sub(r'\s*<link rel="manifest"[^>]*>', "", page)
    return page


DECRYPT_BOOT = """
(function () {
  const enc = window.SNAPSHOT_ENC;
  const b64 = (s) => Uint8Array.from(atob(s), c => c.charCodeAt(0));
  async function unlock(pass) {
    const material = await crypto.subtle.importKey(
      "raw", new TextEncoder().encode(pass), "PBKDF2", false, ["deriveKey"]);
    const key = await crypto.subtle.deriveKey(
      { name: "PBKDF2", salt: b64(enc.salt), iterations: 210000, hash: "SHA-256" },
      material, { name: "AES-GCM", length: 256 }, false, ["decrypt"]);
    const plain = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: b64(enc.iv) }, key, b64(enc.data));
    return JSON.parse(new TextDecoder().decode(plain));
  }
  async function boot(pass, remember) {
    try {
      window.SNAPSHOT = await unlock(pass);
      if (remember) localStorage.setItem("schooldash.pass", pass);
      document.getElementById("pp-gate").remove();
      document.querySelectorAll("main, header.masthead, footer")
        .forEach((el) => { el.style.visibility = ""; el.hidden = false; });
      const s = document.createElement("script");
      s.textContent = window.__APP_SRC;
      document.body.appendChild(s);
    } catch (e) {
      const msg = document.getElementById("pp-gate-msg");
      msg.textContent = "that passphrase does not open this page — try again";
      localStorage.removeItem("schooldash.pass");
    }
  }
  window.addEventListener("DOMContentLoaded", () => {
    const saved = localStorage.getItem("schooldash.pass");
    if (saved) { boot(saved, false); return; }
    document.getElementById("pp-gate").hidden = false;
    document.getElementById("pp-gate-form").addEventListener("submit", (ev) => {
      ev.preventDefault();
      boot(document.getElementById("pp-gate-pass").value, true);
    });
  });
})();
"""

GATE_HTML = """
<div id="pp-gate" hidden style="max-width:340px;margin:18vh auto;text-align:center;
     font-family:'Public Sans',system-ui,sans-serif;">
  <h1 style="font-family:'Architects Daughter',cursive;">Master Planner</h1>
  <p style="color:#5E6757;">this page is locked — enter your passphrase</p>
  <form id="pp-gate-form" style="display:flex;gap:8px;justify-content:center;">
    <input id="pp-gate-pass" type="password" autocomplete="current-password"
           style="padding:8px 12px;border-radius:8px;border:1px solid #D9D6C4;">
    <button type="submit" style="padding:8px 14px;border-radius:8px;
            background:#1C4526;color:#F4F2E8;border:1px solid #1C4526;">open</button>
  </form>
  <p id="pp-gate-msg" style="color:#A33B2E;min-height:1.2em;"></p>
</div>
"""


def build_page(snapshot: dict, passphrase: str | None = None,
               flavor: str = "site") -> str:
    """One self-contained HTML file. With a passphrase the payload ships
    encrypted and the app boots only after WebCrypto decrypts it.

    flavor="artifact" targets the claude.ai artifact wrapper: no document
    skeleton of our own (the platform injects one) and no pre-paint theme
    script (the viewer stamps data-theme itself; our tokens follow it)."""
    template, css, js = _inline_assets()
    page = re.sub(r'<link rel="stylesheet" href="\{\{[^}]*app\.css[^}]*\}\}">',
                  lambda _: f"<style>\n{css}\n</style>", template)

    if passphrase:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        import base64
        import hashlib
        salt = os.urandom(16)
        iv = os.urandom(12)
        key = hashlib.pbkdf2_hmac("sha256", passphrase.encode("utf-8"), salt,
                                  210_000, dklen=32)
        data = AESGCM(key).encrypt(
            iv, json.dumps(snapshot, ensure_ascii=False, default=str)
            .encode("utf-8"), None)
        payload = (
            "<script>window.SNAPSHOT_ENC = "
            + json.dumps({"salt": base64.b64encode(salt).decode(),
                          "iv": base64.b64encode(iv).decode(),
                          "data": base64.b64encode(data).decode()})
            + ";\nwindow.__APP_SRC = " + json.dumps(js) + ";\n"
            + DECRYPT_BOOT + "</script>")
        page = page.replace('<main class="board">',
                            GATE_HTML + '\n<main class="board" style="visibility:hidden">')
        page = page.replace('<header class="masthead">',
                            '<header class="masthead" style="visibility:hidden">')
    else:
        payload = ("<script>window.SNAPSHOT = "
                   + json.dumps(snapshot, ensure_ascii=False, default=str)
                   + ";</script>\n<script>\n" + js + "\n</script>")

    page = re.sub(r'<script src="\{\{[^}]*app\.js[^}]*\}\}"></script>',
                  lambda _: payload, page)

    if flavor == "artifact":
        # strip the document skeleton (the platform provides one) and the
        # pre-paint theme script (the viewer stamps data-theme on its root)
        page = re.sub(r"<!DOCTYPE[^>]*>\s*", "", page)
        page = re.sub(r"</?(html|head|body)[^>]*>\s*", "", page)
        page = re.sub(r"<script>\s*\(function \(\) \{.*?themes?.*?\}\)\(\);\s*</script>",
                      "", page, flags=re.S)
        page = re.sub(
            r'<script>\s*\(function \(\) \{\s*try \{\s*var stored = localStorage\.getItem\("schooldash\.theme"\).*?\}\)\(\);\s*</script>',
            "", page, flags=re.S)
    return _inline_static_refs(page)


def netlify_deploy(page_html: str, site_id: str, token: str) -> str:
    """Zip-deploy one file to Netlify; returns the live URL. The _headers file
    keeps search engines out."""
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as bundle:
        bundle.writestr("index.html", page_html)
        bundle.writestr("_headers", "/*\n  X-Robots-Tag: noindex\n")
    response = httpx.post(
        f"https://api.netlify.com/api/v1/sites/{site_id}/deploys",
        content=buffer.getvalue(),
        headers={"Content-Type": "application/zip",
                 "Authorization": f"Bearer {token}",
                 "User-Agent": "schooldash/0.1"},
        timeout=120)
    response.raise_for_status()
    body = response.json()
    return body.get("ssl_url") or body.get("url") or ""


def cli_publish(local_only: bool = False) -> int:
    state = pipeline.load_state_overlaid()
    if not state:
        print("no cached state — run: python run.py refresh")
        return 1
    cfg = config.load(refresh=True)["publish"]
    snapshot = build_snapshot(state)
    out_dir = paths.data_root() / "publish"
    out_dir.mkdir(exist_ok=True)

    plain = build_page(snapshot, flavor="artifact")
    (out_dir / "artifact.html").write_text(plain, encoding="utf-8")
    print(f"wrote {out_dir / 'artifact.html'} (unencrypted — for the private "
          "claude.ai artifact only)")

    passphrase = cfg.get("passphrase") or ""
    if passphrase:
        locked = build_page(snapshot, passphrase)
        (out_dir / "index.html").write_text(locked, encoding="utf-8")
        print(f"wrote {out_dir / 'index.html'} (passphrase-locked)")
    else:
        print("no publish.passphrase in config.json — the public (Netlify) "
              "flavor is NOT built, because a public URL without encryption "
              "would expose your schoolwork. Add one line to config.json:\n"
              '  "publish": { "passphrase": "something you will remember" }')

    if local_only:
        return 0
    site_id, token = cfg.get("netlify_site_id") or "", cfg.get("netlify_token") or ""
    if not (site_id and token and passphrase):
        missing = [name for name, val in [("netlify_site_id", site_id),
                                          ("netlify_token", token),
                                          ("passphrase", passphrase)] if not val]
        print(f"Netlify push skipped — config.publish is missing: "
              f"{', '.join(missing)} (see README.md → Phone access)")
        return 0
    try:
        url = netlify_deploy((out_dir / "index.html").read_text(encoding="utf-8"),
                             site_id, token)
    except httpx.HTTPError as exc:
        print(f"Netlify deploy failed: {exc}")
        log.error("netlify deploy failed: %s", exc)
        return 1
    stamp = datetime.now(timezones.zone()).isoformat(timespec="seconds")
    config.save({"publish": {"last_publish": stamp}})
    print(f"published to {url} at {stamp}")
    log.info("published to netlify at %s", stamp)
    return 0
