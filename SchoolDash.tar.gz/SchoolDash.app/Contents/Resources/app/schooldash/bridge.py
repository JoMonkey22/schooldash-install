"""The Chrome bridge: pages handed to the app by a browser already signed in.

*"make it also a crome extetion that connects to the app so that it is easier
for the AI to read it though the extention"*

**Why this exists.** Everything the app reads from Canvas and Veracross, it
currently reads by driving its own headless browser and signing in as him.
That is the single most fragile part of the whole program, and the record is
long: Google SSO is broken in branded Chrome on this Mac by a cloud-management
policy (0.15); a Veracross session lives about 30 minutes and needs a launchd
job to touch it (`keepalive.py`); Canvas hands out session-only cookies that
REPLACE the persistent ones, which killed sign-ins within minutes until
0.18.5.0; and Veracross's login is gated by a reCAPTCHA that no automation may
ever satisfy on its own.

His own Chrome has none of those problems. He is already signed in to both.

So this module accepts pages fetched by an extension running in that browser,
using the cookies already in it, and hands them to the SAME parsers the
refresh uses. Nothing here parses anything: `veracross_gradebook.parse` reads
bridged HTML exactly as it reads fetched HTML, because two parsers for one
document is how they come to disagree.

**Three rules this module is built to keep.**

*A capture is a courier, never an authority.* It carries a page; what the page
MEANS is still decided by the existing parser and the existing grounding. A
browser extension is more trustworthy than a web page and less trustworthy
than the app's own fetch, so a stale capture is ignored rather than used.

*The token is the whole gate.* The app is loopback-only, but "loopback" is not
a permission — anything running on this Mac can reach 127.0.0.1. So a capture
must carry a token the app minted, compared in constant time. The token is
shown once in Settings and pasted into the extension by hand: no discovery
protocol, nothing broadcast, nothing a web page can guess at.

*Nothing here can fill the disk.* One file per kind and key, a size cap per
body and a count cap per kind, checked before the write.
"""

from __future__ import annotations

import json
import os
import re
import secrets
import time
from pathlib import Path

from schooldash import paths
from schooldash.logging_setup import get

log = get("bridge")

# What a capture may be. An allowlist, not a free-form string: the kind picks
# the folder and the reader, and a caller-chosen folder name is the oldest
# file-server bug there is.
KINDS = {
    "veracross_gradebook": "one class's grade-detail document",
    # Accepted, but NOTHING ASKS FOR IT and a plain fetch cannot fill it.
    # [MEASURED] 2026-09-10 from the extension's own console, with a live
    # session: the portal answers 200 with 33,907 bytes containing **zero**
    # `.course-grade` nodes, because it renders client-side — which is why
    # `veracross_grades.fetch_grades` waits on that selector before parsing.
    # Filling this kind needs the RENDERED DOM (a content script, or
    # chrome.scripting on an open portal tab), not a fetch. The name is kept
    # so that work has somewhere to land; `wanted()` deliberately omits it.
    "veracross_grades": "the portal page listing every class and its grade",
    "canvas_planner": "the Canvas planner/todo JSON",
    "canvas_courses": "the Canvas course list JSON",
    "course_page": "a Canvas course homepage, where some teachers post work",
}
KEY = re.compile(r"^[A-Za-z0-9_.:-]{1,80}\Z")
MAX_BODY = 4 * 1024 * 1024          # a rendered Veracross page is ~100 KB
MAX_PER_KIND = 40                   # ten classes with room to spare
TOKEN_BYTES = 24

# How old a capture may be and still be preferred over the app's own fetch.
# Long enough that a morning capture serves the school day's refreshes; short
# enough that a grade changed at lunchtime is not reported from breakfast.
FRESH_MINUTES = 240


class BridgeError(RuntimeError):
    def __init__(self, message: str, fix: str = "", status: int = 400):
        super().__init__(message)
        self.message = message
        self.fix = fix
        self.status = status


def token_path() -> Path:
    return paths.data_dir() / "bridge-token.txt"


def token(create: bool = True) -> str:
    """The pairing token, minted on first use. Never leaves this Mac except
    into the extension, by hand, through Settings."""
    path = token_path()
    if path.is_file():
        existing = path.read_text(encoding="utf-8").strip()
        if existing:
            return existing
    if not create:
        return ""
    minted = secrets.token_hex(TOKEN_BYTES)
    # Created 0600, not created-then-chmodded. [PROSECUTION 2026-09-11,
    # COUNT 5] `write_text` honours the umask, so the old order left the
    # pairing secret world-readable for the moment between the two calls —
    # short, but a window is a window, and `os.open` closes it for free.
    handle = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(handle, "w", encoding="utf-8") as out:
            out.write(minted)
    except Exception:                                        # pragma: no cover
        os.close(handle)
        raise
    log.info("minted a new Chrome-bridge pairing token")
    return minted


def forget_token() -> None:
    """Unpair every browser. The next capture from the old token is refused."""
    path = token_path()
    if path.is_file():
        path.unlink()
        log.info("Chrome-bridge token forgotten; every paired browser is out")


def check_token(offered: str | None) -> None:
    """Constant-time, and it refuses when no token has been minted yet — an
    empty token must never match an empty header."""
    want = token(create=False)
    if not want:
        raise BridgeError("this copy of SchoolDash has not been paired",
                          "open Settings and press Connect Chrome", 403)
    if not offered or not secrets.compare_digest(str(offered), want):
        raise BridgeError("that pairing code is not this Mac's",
                          "copy the code again from Settings", 403)


def _folder(kind: str, create: bool = False) -> Path:
    if kind not in KINDS:
        raise BridgeError(f"{kind!r} is not something the bridge accepts",
                          "update the extension", 400)
    path = paths.data_dir() / "bridge" / kind
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def _safe_key(key: str) -> str:
    if not isinstance(key, str) or not KEY.match(key):
        raise BridgeError("that capture has no usable id", "", 400)
    return key


def store(kind: str, key: str, body: str, url: str = "") -> dict:
    """Keep one page. Replaces the previous capture of the same kind and key —
    the newest version of a document is the only one worth having, and a
    history of a student's gradebook is data nobody asked to keep."""
    if not isinstance(body, str) or not body.strip():
        raise BridgeError("that capture was empty", "", 400)
    if len(body.encode("utf-8", "ignore")) > MAX_BODY:
        raise BridgeError("that page is too big to accept", "", 413)
    folder = _folder(kind, create=True)
    safe = _safe_key(key)
    if len(list(folder.glob("*.json"))) >= MAX_PER_KIND \
            and not (folder / f"{safe}.json").exists():
        raise BridgeError(f"already holding {MAX_PER_KIND} {kind} captures",
                          "", 429)
    record = {"kind": kind, "key": safe, "url": url[:500],
              "at": time.time(), "bytes": len(body), "body": body}
    (folder / f"{safe}.json").write_text(json.dumps(record), encoding="utf-8")
    log.info("bridged %s/%s (%d bytes)", kind, safe, len(body))
    return {"kind": kind, "key": safe, "bytes": len(body), "at": record["at"]}


def _read(kind: str, key: str) -> dict | None:
    path = _folder(kind) / f"{_safe_key(key)}.json"
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (ValueError, OSError):
        return None


def fresh(kind: str, key: str, minutes: int = FRESH_MINUTES) -> str | None:
    """The captured page, or None when there is none or it is stale.

    Stale returns None rather than the old page on purpose. The whole point of
    the bridge is to be a shortcut past a sign-in, and a shortcut that quietly
    serves yesterday's grades is worse than the sign-in it replaced.
    """
    record = _read(kind, key)
    if not record:
        return None
    age = (time.time() - float(record.get("at") or 0)) / 60
    if age > minutes:
        log.info("bridged %s/%s is %.0f minutes old — ignoring it", kind, key, age)
        return None
    return record.get("body") or None


def listing() -> dict:
    """What is held, for Settings and the extension's own status line. Never
    the bodies — this is asked for by a page.

    **Read from the filesystem's own metadata, not by parsing the files.**
    [PROSECUTION 2026-09-11, COUNT 1] this used to call `_read()` per capture,
    which `json.loads`es the whole record — body included. `status()` calls
    this, `/api/state` calls `status()`, and the board polls `/api/state`
    every 60 seconds: so nine bridged pages meant re-reading and re-parsing
    ~280 KB of HTML every minute, forever, to display a count. `stat()` gives
    both numbers for free.

    The size is therefore the file's size rather than the body's — a few
    hundred bytes of JSON larger. It is shown as "how much is held", where
    that is the more truthful of the two anyway.
    """
    out: dict[str, list] = {}
    now = time.time()
    for kind in KINDS:
        rows = []
        folder = _folder(kind)
        if folder.is_dir():
            for path in sorted(folder.glob("*.json")):
                try:
                    stat = path.stat()
                except OSError:                              # pragma: no cover
                    continue
                rows.append({"key": path.stem,
                             "bytes": stat.st_size,
                             "at": stat.st_mtime,
                             "minutes_old": round((now - stat.st_mtime) / 60, 1)})
        if rows:
            out[kind] = rows
    return out


def clear(kind: str = "") -> int:
    """Throw the captures away. Takes one kind, or all of them."""
    gone = 0
    for name in ([kind] if kind else list(KINDS)):
        folder = _folder(name)
        if folder.is_dir():
            for path in folder.glob("*.json"):
                path.unlink()
                gone += 1
    return gone


def status() -> dict:
    held = listing()
    return {
        "extension": extension(),
        "paired": bool(token(create=False)),
        "kinds": {k: {"what": v, "held": len(held.get(k) or [])}
                  for k, v in KINDS.items()},
        "held": held,
        "fresh_minutes": FRESH_MINUTES,
    }


# The hosts a capture may have come from. The app names the URLs it wants and
# the extension refuses any host outside its own allowlist — but the app is
# the party that could be wrong, so the check exists on both sides. Without
# this, "the app tells the extension what to fetch" is a redirection
# primitive: a bug here could point a browser holding live school sessions at
# any URL at all.
ALLOWED_HOSTS = (
    ".instructure.com",
    "portals.veracross.com",
    "portals-embed.veracross.com",
    "documents.veracross.com",
)


def host_allowed(url: str) -> bool:
    from urllib.parse import urlparse
    parsed = urlparse(url or "")
    if parsed.scheme != "https":
        return False
    host = (parsed.hostname or "").lower()
    return any(host == allowed or host.endswith(allowed)
               for allowed in ALLOWED_HOSTS)


def wanted() -> list[dict]:
    """The pages the app would like handed to it, as {kind, key, url}.

    The app names them, not the extension: which classes exist and where their
    documents live is knowledge this program already has, and duplicating it
    in JavaScript is how the two would come to disagree about a school. It
    also means a classmate at another school needs no change to the extension
    at all — their own config produces their own list.

    Only pages that are missing or stale are listed, so a capture that is
    still fresh is not fetched again.
    """
    from schooldash import config, pipeline
    from schooldash.feeds import veracross_gradebook as vg

    out: list[dict] = []
    try:
        state = pipeline.load_state_overlaid() or {}
    except Exception as exc:  # noqa: BLE001 — an empty list is a fine answer
        log.info("could not read the board to list wanted pages: %s", exc)
        state = {}

    school = vg.school_slug()
    for grade in state.get("grades") or []:
        class_id = vg.class_id_from(grade.get("detail_url") or "")
        if not class_id:
            continue
        if fresh("veracross_gradebook", str(class_id)):
            continue
        url = vg.doc_url(class_id, school)
        if host_allowed(url):
            out.append({"kind": "veracross_gradebook", "key": str(class_id),
                        "url": url, "name": grade.get("display_name") or ""})

    canvas = (config.load().get("canvas") or {}).get("host") or ""
    canvas = canvas.rstrip("/")
    for key, path in (("planner", "/api/v1/planner/items?per_page=100"),
                      ("courses",
                       "/api/v1/courses?enrollment_state=active&per_page=100")):
        kind = f"canvas_{key}"
        if fresh(kind, key):
            continue
        url = f"{canvas}{path}"
        if host_allowed(url):
            out.append({"kind": kind, "key": key, "url": url,
                        "name": f"Canvas {key}"})
    return out


def extension() -> dict:
    """Where the unpacked extension is, for Settings.

    `folder` is what goes into Chrome's "Load unpacked", and the app can open
    Finder there so nobody has to type it. `present` is false in a build that
    did not ship it — in which case the download page is still the way in.
    """
    folder = paths.chrome_extension_dir()
    version = ""
    if folder:
        try:
            version = json.loads(
                (folder / "manifest.json").read_text(encoding="utf-8")
            ).get("version", "")
        except (ValueError, OSError):                        # pragma: no cover
            version = ""
    return {"present": bool(folder), "folder": str(folder) if folder else "",
            "version": version}
