"""The one place a browser exists: persistent context, channel resolution,
session check, and the manual-login flow.

Rules honored here: never borrow the real Chrome profile, and never type a
password from THIS module — the hand-typed flows below only watch for a login
to finish. Signing in on the student's behalf, with details they saved on
purpose, lives in autologin.py (owner's decision 2026-09-01, superseding spec
§5.1). The dedicated profile at browser.profile_dir holds the session either
way; scripts reuse it.
Playwright's bundled Chromium is rejected by Google sign-in, so the channel
order is real Chrome, then Edge, then bundled Chromium as a last resort.
"""

import json
import os
import plistlib
import re
import signal
import subprocess
import sys
import time
from pathlib import Path

from schooldash import config, paths
from schooldash.logging_setup import get

log = get("browser")

CHANNELS = ["chrome", "msedge", ""]  # "" = bundled chromium, last resort

# Where macOS keeps the Chrome policy an MDM or Chrome Browser Cloud Management
# has pushed onto the machine.
CHROME_POLICY_PLIST = Path("/Library/Managed Preferences/com.google.Chrome.plist")


def chrome_is_cloud_managed() -> bool:
    """Is branded Chrome on this Mac enrolled in someone's admin console?

    [MEASURED] 2026-09-04, and this is why it matters. His Mac carries
    `/Library/Managed Preferences/com.google.Chrome.plist` with a
    `CloudManagementEnrollmentToken`, so every Google Chrome launched here —
    including the one this app drives — pulls the school's policy, and that
    policy requires signing into the BROWSER. The saved sign-in got as far as
    `accounts.google.com/o/saml2/continue` and Chrome then refused the
    redirect back to Canvas with its own interstitial:

        Your organization requires you to sign into Chrome
        To continue, sign in to Chrome as <the school address>

    The page ended on `chrome-error://chromewebdata/`, no Canvas session was
    ever created, and the refresh reported "Canvas unavailable" every half
    hour for a day. The same sign-in, with the same saved details, through
    Playwright's own Chromium — a different application, which does not read
    `com.google.Chrome` policy — completed and landed on the dashboard,
    signed in.

    So when Chrome is cloud-managed, Chromium goes FIRST. Chrome is not
    removed: it stays in the order behind Chromium, because a machine can
    carry the token and still work, and because being wrong here should cost
    a fallback rather than the whole feature.
    """
    try:
        if not CHROME_POLICY_PLIST.exists():
            return False
        with CHROME_POLICY_PLIST.open("rb") as handle:
            policy = plistlib.load(handle)
    except Exception:  # noqa: BLE001 — an unreadable policy is not a verdict
        return False
    if not isinstance(policy, dict):
        return False
    # The enrollment token is the specific thing that hands this browser's
    # rules to an admin console. Other managed keys (an extension blocklist,
    # say) do not break a redirect and must not cost anyone their Chrome.
    return bool(policy.get("CloudManagementEnrollmentToken")
                or policy.get("CloudManagementEnrollmentMandatory"))


def channel_order(preferred: str = "auto") -> list[str]:
    """The channels to try, most likely to work first.

    An explicit choice in config.json always wins — "chromium" is spelled ""
    at the Playwright boundary, which is why it is translated here rather than
    at every call site.
    """
    if preferred and preferred != "auto":
        return [""] if preferred == "chromium" else [preferred]
    if chrome_is_cloud_managed():
        log.info("Chrome on this Mac is cloud-managed — trying Chromium first")
        return ["", "chrome", "msedge"]
    return list(CHANNELS)

# Which channel actually launched, so the sign-in window can be raised above
# whatever else is on screen. page.bring_to_front() only reorders tabs inside
# the browser; it cannot lift the browser above another application.
LAST_CHANNEL = ""

APP_FOR_CHANNEL = {"chrome": "Google Chrome", "msedge": "Microsoft Edge"}

# The name macOS knows the BUNDLED browser by, which is not "Chromium".
# [MEASURED] 2026-09-06: Playwright ships
# `…/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app`,
# so `tell application "Chromium" to activate` addressed an application that
# does not exist and did nothing at all. That mattered the moment Chromium
# became the first channel (Chrome is cloud-managed here): the sign-in window
# opened BEHIND the app and he pressed the button again and again, each time
# being told a window was already open, with no window ever coming forward.
# Resolved from the executable rather than hardcoded, because the name has
# changed before ("Chromium" → "Google Chrome for Testing") and will again.
LAST_APP_NAME = ""


def _app_name_from_executable(path) -> str:
    for parent in Path(path).parents:
        if parent.suffix == ".app":
            return parent.stem
    return ""


def bundled_app_name() -> str:
    """What the bundled browser's .app is called, without starting Playwright.

    The web process needs this to raise a window a DIFFERENT process opened,
    and importing Playwright to ask would cost a subprocess per press.
    """
    base = Path.home() / "Library" / "Caches" / "ms-playwright"
    try:
        for app in sorted(base.glob("chromium-*/chrome-mac*/*.app")):
            if app.is_dir():
                return app.stem
    except OSError:
        pass
    return "Chromium"


def expected_app_name() -> str:
    """The application the next sign-in window will belong to."""
    if LAST_APP_NAME:
        return LAST_APP_NAME
    try:
        order = channel_order(config.load()["browser"]["channel"])
    except Exception:  # noqa: BLE001
        order = CHANNELS
    first = order[0] if order else ""
    return APP_FOR_CHANNEL.get(first) or bundled_app_name()


def raise_app(name: str = "") -> None:
    """Lift the browser above everything else. Cosmetic, never fatal."""
    app = name or expected_app_name()
    if not app or sys.platform != "darwin":
        return
    subprocess.run(["osascript", "-e", f'tell application "{app}" to activate'],
                   capture_output=True, timeout=10, check=False)


class SessionError(RuntimeError):
    """The Canvas session is missing or expired. .fix is the one-line remedy."""

    def __init__(self, message, fix="python run.py login"):
        super().__init__(message)
        self.fix = fix


def profile_dir() -> Path:
    cfg = config.load()
    configured = cfg["browser"]["profile_dir"]
    return Path(configured) if configured else paths.default_browser_profile_dir()


# A Chrome profile is single-instance. Launching a second Chrome on a profile
# a live Chrome already owns does not fail — it hands the request to the
# running instance and waits, which from Playwright's side is a launch that
# never returns. [MEASURED] logs/schooldash.log caught exactly that: "channel
# chrome failed: Timeout 180000ms exceeded" after three minutes of a refresh
# racing an open login window. Three minutes of nothing, then a fallback to
# bundled Chromium that Google sign-in rejects, is the worst of both worlds, so
# the collision is detected up front and named instead.
LAUNCH_TIMEOUT_MS = 45_000


def profile_owner_pid() -> int | None:
    """The pid of a live Chrome holding this profile, or None.

    Chrome records the owner in the SingletonLock symlink as
    "<hostname>-<pid>". A symlink left behind by a crash points at a pid that
    is gone (or belongs to something else now), which Chrome itself treats as
    stale — so only a running Chrome/Chromium counts.
    """
    lock = profile_dir() / "SingletonLock"
    try:
        target = os.readlink(lock)
    except OSError:
        return None
    _, _, pid_text = target.rpartition("-")
    try:
        pid = int(pid_text)
    except ValueError:
        return None
    if pid <= 0:
        return None
    try:
        os.kill(pid, 0)  # signal 0: existence check, changes nothing
    except OSError:
        return None  # stale lock — Chrome will clear it itself
    try:
        name = subprocess.run(["ps", "-p", str(pid), "-o", "comm="],
                              capture_output=True, text=True, timeout=5).stdout
    except (OSError, subprocess.SubprocessError):
        return pid
    return pid if ("chrome" in name.lower() or "chromium" in name.lower()) else None


def reclaim_profile() -> int:
    """Terminate any browser still holding our profile. Returns how many.

    A run that dies mid-login — the app quit, setup failed, the machine slept
    — leaves its Chrome alive holding browser_profile/. Nothing ever reaps it,
    so every later attempt is refused by the guard in open_context, and the
    advice it gives ("close that window") is useless because the orphan has no
    window to close. [MEASURED] one such orphan from a failed 10:38 run blocked
    every Veracross sign-in for half an hour; the only cure was killing it by
    hand, which is not something a student is going to do.

    Matching is on the profile path in the command line, so this can only ever
    hit a browser we launched ourselves. The user's own Chrome uses a different
    user-data-dir and is never a candidate.
    """
    directory = str(profile_dir())
    try:
        listing = subprocess.run(["ps", "-Ao", "pid=,command="],
                                 capture_output=True, text=True, timeout=10).stdout
    except (OSError, subprocess.SubprocessError):
        return 0

    targets = []
    for line in listing.splitlines():
        pid_text, _, command = line.strip().partition(" ")
        if f"--user-data-dir={directory}" not in command:
            continue
        try:
            targets.append(int(pid_text))
        except ValueError:
            continue
    if not targets:
        return 0

    # Ask first: a browser given the chance to exit writes its cookies out,
    # and those cookies are the signed-in session this whole app depends on.
    for pid in targets:
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            pass
    deadline = time.time() + 5
    while time.time() < deadline:
        if not any(_alive(pid) for pid in targets):
            break
        time.sleep(0.2)
    for pid in targets:
        if _alive(pid):
            try:
                os.kill(pid, signal.SIGKILL)
            except OSError:
                pass

    log.info("reclaimed the browser profile from %d orphaned process(es)", len(targets))
    return len(targets)


def _alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def open_context(playwright, headless: bool = True, reclaim: bool = False):
    """Launch the persistent profile with the first channel that works.

    reclaim=True first kills anything of ours still holding the profile. The
    sign-in flows pass it: a login is a deliberate fresh start, so any browser
    already on that profile is by definition left over from a run that failed.
    Refreshes do not, because a refresh firing while the student is halfway
    through typing a password should lose, not win.
    """
    cfg = config.load()
    order = channel_order(cfg["browser"]["channel"])
    directory = profile_dir()
    directory.mkdir(parents=True, exist_ok=True)

    if reclaim:
        reclaim_profile()

    owner = profile_owner_pid()
    if owner is not None:
        raise SessionError(
            f"another SchoolDash browser window is already open (pid {owner})",
            fix="close that window, then reopen SchoolDash")

    last_error = None
    for channel in order:
        try:
            context = playwright.chromium.launch_persistent_context(
                str(directory),
                channel=channel or None,
                headless=headless,
                args=["--disable-blink-features=AutomationControlled"],
                ignore_default_args=["--enable-automation"],
                timeout=LAUNCH_TIMEOUT_MS,
            )
            log.info("browser launched: channel=%s headless=%s profile=%s",
                     channel or "chromium", headless, directory)
            global LAST_CHANNEL, LAST_APP_NAME
            LAST_CHANNEL = channel or "chromium"
            LAST_APP_NAME = (APP_FOR_CHANNEL.get(channel)
                             or _app_name_from_executable(
                                 playwright.chromium.executable_path)
                             or bundled_app_name())
            return context
        except Exception as exc:  # noqa: BLE001 — try the next channel
            last_error = exc
            log.warning("channel %s failed: %s", channel or "chromium", exc)
    raise SessionError(
        f"no browser channel could launch the profile at {directory}: {last_error}",
        fix="close any window using that profile, or install Chrome/Edge")


def strip_while1(text: str) -> str:
    """Canvas prefixes JSON with while(1); — strip it, tolerate its absence."""
    return re.sub(r"^\s*while\s*\(\s*1\s*\)\s*;", "", text or "", count=1)


def whoami(context) -> dict | None:
    """The logged-in Canvas profile, or None."""
    host = config.load()["canvas"]["host"].rstrip("/")
    try:
        response = context.request.get(f"{host}/api/v1/users/self/profile",
                                       timeout=30_000)
        if not response.ok:
            return None
        data = json.loads(strip_while1(response.text()))
    except Exception:  # noqa: BLE001
        return None
    return data if isinstance(data, dict) and data.get("id") else None


def persist_session_cookies(context, days: int = 30) -> int:
    """Canvas issues session-only cookies unless "Stay signed in" is ticked.
    Rewrite expires<=0 cookies with a real future expiry so they survive.

    **Never raises.** [PROVEN] tests/test_prosecution.py: this is called on the
    "already signed in" path of both sites since 0.18.2.0, one line before the
    result that says the session is fine — and `add_cookies` rejects shapes it
    does not like ("Cookie should have a url or a domain/path pair"). An
    exception there turned a WORKING, signed-in Canvas into "Canvas
    unavailable" on the board. Saving a session for later is an optimisation;
    the session itself is the fact, and the fact must survive the optimisation
    failing.
    """
    try:
        cookies = context.cookies()
        expiring = [c for c in cookies if c.get("expires", -1) <= 0]
        if not expiring:
            return 0
        future = time.time() + days * 86400
        for cookie in expiring:
            cookie["expires"] = future
            cookie.pop("sameSite", None)
        context.add_cookies(expiring)
        return len(expiring)
    except Exception as exc:  # noqa: BLE001 — see the docstring
        log.info("could not give the session cookies a real expiry: %s", exc)
        return 0


def close_context(context) -> None:
    """Save the session, then close. Use this instead of `context.close()`.

    Why this exists, and why persisting once at sign-in was not enough.
    [MEASURED] 2026-09-08, live profile, in one run:

        right after a sign-in   _csrf_token, canvas_session, log_session_id
                                all on disk, all persistent, +30 days
        one context open/close  _csrf_token and log_session_id GONE
        five minutes later      nothing left, whoami() False, signed out

    Canvas answers ordinary requests with `Set-Cookie` and no `Expires`, and a
    session Set-Cookie does not just shadow the stored cookie — it REPLACES the
    persistent row with a session one, which Chromium then drops when the
    browser exits. So every refresh quietly downgraded the session that the
    sign-in had carefully saved, and the next browser exit threw it away. The
    student saw "sign in to Canvas" again a few minutes after signing in, over
    and over, which is exactly what he reported.

    The expiry therefore has to be rewritten at the END of every browser use,
    not only after a sign-in. There are eleven places that close a context;
    naming this one makes the rule impossible to half-apply, and none of them
    has a reason to prefer the bare close.

    Never raises: a failure to save the session must not break the work that
    was already done, and a failure to close must not mask it either.
    """
    try:
        persist_session_cookies(context)
    except Exception as exc:  # noqa: BLE001 — see the docstring
        log.info("could not save the session before closing: %s", exc)
    try:
        context.close()
    except Exception as exc:  # noqa: BLE001
        log.info("closing the browser context failed: %s", exc)


def session_valid() -> tuple[bool, str]:
    """Headless probe: is the saved Canvas session alive? (Used by refresh,
    never by /api/health, which is cache-only.)"""
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return False, "playwright is not installed"
    with sync_playwright() as pw:
        try:
            context = open_context(pw, headless=True)
        except SessionError as exc:
            return False, str(exc)
        try:
            profile = whoami(context)
        finally:
            close_context(context)
    if profile:
        return True, f"logged in as {profile.get('name', '?')}"
    return False, "the Canvas session is expired or missing"


# Half an hour. Long enough for a forgotten password, a password manager, and
# a phone that has to be found for the two-factor code.
LOGIN_DEADLINE_SECONDS = 1800

# How long the sign-in window may sit unnoticed before SchoolDash speaks up
# again. Two minutes is often enough to be useful and rare enough not to nag.
NUDGE_SECONDS = 120


class LoginCancelled(RuntimeError):
    """Every sign-in window was closed before the login finished.

    Distinct from a timeout on purpose: the launcher offers "try again" for
    this and gives up on that, and only one of the two is the student's doing.
    """


def watched_page(context):
    """The page to drive: the one the profile already opened.

    launch_persistent_context always arrives with a page. Calling new_page()
    on top of it leaves the student looking at two tabs — a blank one and the
    real one — and wondering which is which.
    """
    live = [page for page in context.pages if not page.is_closed()]
    return live[0] if live else context.new_page()


def open_pages(context) -> int:
    """How many windows/tabs the student still has open, 0 once they close the
    last one. Reaching for a closed context raises rather than answering, and
    a closed context means the same thing as no pages."""
    try:
        return len([page for page in context.pages if not page.is_closed()])
    except Exception:  # noqa: BLE001 — the whole browser is gone
        return 0


def surface(page, what, repeat=False):
    """Put the sign-in window where the student will actually see it.

    Two steps, because they do different things: bring_to_front() reorders
    tabs *within* the browser, and only activating the application lifts that
    browser above every other window. Doing just the first is why a window
    could be open and unnoticed for half an hour.
    """
    try:
        page.bring_to_front()
    except Exception:  # noqa: BLE001 — cosmetic
        pass
    raise_app()
    window = expected_app_name()
    if repeat:
        message = (f"Still waiting for your {what} sign-in. Look for the "
                   f"window called {window}.")
        log.info("still waiting for the %s sign-in (window: %s)", what, window)
    else:
        message = (f"Sign into {what} in the window that just opened — "
                   f"it is called {window}.")
    subprocess.run(
        ["osascript", "-e",
         f'display notification "{message}" with title "SchoolDash" '
         f'subtitle "Waiting for you"'],
        capture_output=True, timeout=10, check=False)


def await_login(context, page, done, what="Veracross",
                deadline_seconds=LOGIN_DEADLINE_SECONDS, poll_seconds=3):
    """Wait for a hand-typed login to finish. Returns whatever `done()` returns.

    `done(page)` is polled until it answers truthily. It is handed the page
    currently in front, because single sign-on does not stay in the tab it
    started in: Canvas hands off to Google, Google may open its own tab and
    close the original, and the tab that comes back is a different object than
    the one that left. Watching one page object for `is_closed()` therefore
    reported "the window was closed before login finished" while the student
    was still typing — [MEASURED] twice in first_run.log on 2026-08-25, which
    is what stopped setup finishing at all. So closure is judged on the whole
    context: while any window is open, the student is still working.

    Raises LoginCancelled when the last window closes, TimeoutError at the
    deadline.
    """
    deadline = time.monotonic() + deadline_seconds
    surface(page, what)
    next_nudge = time.monotonic() + NUDGE_SECONDS

    while time.monotonic() < deadline:
        if open_pages(context) == 0:
            raise LoginCancelled("the sign-in window was closed")
        if page.is_closed():
            page = watched_page(context)  # sign-on moved to another tab
        try:
            result = done(page)
        except Exception as exc:  # noqa: BLE001 — a navigation mid-poll
            log.debug("login poll raised, retrying: %s", exc)
            result = None
        if result:
            return result

        # Setup is silent while this loop runs, and the window it is waiting on
        # may be behind whatever the student was already doing.
        # [MEASURED] 2026-08-27: a classmate's first run sat here for the full
        # thirty minutes and then failed — the window had opened, and he never
        # saw it. Waiting quietly is indistinguishable from being broken.
        if time.monotonic() >= next_nudge:
            surface(page, what, repeat=True)
            next_nudge = time.monotonic() + NUDGE_SECONDS

        time.sleep(poll_seconds)
    raise TimeoutError(
        f"no {what} sign-in within {deadline_seconds // 60} minutes — the "
        "window was open the whole time. Reopen SchoolDash to try again; "
        "nothing you already did has to be redone")


FEED_LINK = re.compile(r"https://[^\"'\s]+/feeds/calendars/user_[A-Za-z0-9]+\.ics")
# Veracross calendar feeds, as they actually appear in the portal.
#
# [MEASURED] 2026-08-26 against Brophy's portal, three separate assumptions in
# the old pattern were wrong at once, and together they meant the class feed
# was never once captured automatically:
#
#   1. the page. Discovery loaded <portal>/calendar, which is a 404. The real
#      one is <portal>/calendar/subscribe/mine, linked as "Subscribe to
#      Calendars".
#   2. the scheme. Every href is webcal://, not https://. Same server, and it
#      answers https fine — but the pattern required https and matched nothing.
#   3. the shape. Only the three personal calendars are /subscribe/<token>.ics;
#      per-class feeds are /classes/<id>/assignments.ics?t=<token>.
#
# So: both schemes, both shapes, query string included — the token lives there
# for the per-class feeds and dropping it yields a URL that 401s.
VERACROSS_FEED = re.compile(
    r"(?:webcal|https)://api\.veracross\.com/[A-Za-z0-9_-]+/"
    r"(?:subscribe/[^\s\"'<>]+?\.ics|classes/\d+/assignments\.ics|teams/\d+\.ics)"
    r"(?:\?[^\s\"'<>]*)?")

# The page that lists them, and the path the app used to guess.
VERACROSS_SUBSCRIBE_PATHS = ["/calendar/subscribe/mine", "/calendar"]


def normalise_feed_url(url: str) -> str:
    """webcal:// is a hint to the OS about which app should open a URL, not a
    protocol. httpx cannot fetch one; the same host serves it over https."""
    return re.sub(r"^webcal://", "https://", (url or "").replace("&amp;", "&"))


def collect_feed_urls(page) -> set[str]:
    """Every subscription URL on the current page.

    Reads the anchors first — the subscribe buttons carry the URL in href, and
    asking the DOM cannot be defeated by entity-escaping or by markup that
    happens to split an attribute across lines. The regex over the raw HTML is
    kept as a second pass for anything rendered outside an <a>.
    """
    found = set()
    try:
        for anchor in page.query_selector_all("a[href]"):
            href = anchor.get_attribute("href") or ""
            if VERACROSS_FEED.fullmatch(href.replace("&amp;", "&")):
                found.add(normalise_feed_url(href))
    except Exception:  # noqa: BLE001 — fall through to the regex pass
        pass
    try:
        found.update(normalise_feed_url(m.group(0))
                     for m in VERACROSS_FEED.finditer(page.content()))
    except Exception:  # noqa: BLE001
        pass
    return found



def capture_veracross_feeds(page, portal: str) -> dict:
    """Visit the portal's calendar-subscription page and save the feed URLs.

    Returns {"ok", "message", "found"}. Picks the class feed by size (the one
    with hundreds of events) among the personal calendars only — a per-class
    assignments feed holds one course and must never be crowned the schedule.
    Shared by the hand-typed login and the automatic one.
    """
    found: set[str] = set()
    for path in VERACROSS_SUBSCRIBE_PATHS:
        try:
            page.goto(portal.rstrip("/") + path, wait_until="domcontentloaded",
                      timeout=60_000)
            page.wait_for_timeout(4000)
        except Exception:  # noqa: BLE001 — try the next path
            continue
        found.update(collect_feed_urls(page))
        if found:
            break
    if not found:
        return {"ok": False, "found": 0,
                "message": "no feed URLs found automatically. In the portal: "
                           "Calendar → Subscribe to Calendars, then try again"}
    config.save({"veracross": {"feed_candidates": sorted(found)}})
    cfg = config.load(refresh=True)
    message = f"found {len(found)} feed URL(s)"
    if not cfg["veracross"]["class_ics"]:
        personal = {u for u in found if "/subscribe/" in u}
        import httpx
        from schooldash.feeds import ical as ical_mod
        sized = []
        for url in (personal or found):
            try:
                text = httpx.get(url, timeout=30).text
                sized.append((len(ical_mod.parse(text)), url))
            except Exception:  # noqa: BLE001
                sized.append((0, url))
        sized.sort(reverse=True)
        if not sized or sized[0][0] == 0:
            return {"ok": False, "found": len(found),
                    "message": f"found {len(found)} feed URL(s) but none parsed to "
                               "any events"}
        updates = {"veracross": {"class_ics": sized[0][1]}}
        if len(sized) > 1:
            updates["veracross"]["assignments_ics"] = sized[1][1]
        config.save(updates)
        message += (f"; saved the class feed ({sized[0][0]} events)"
                    + (f" and the assignments feed ({sized[1][0]} events)"
                       if len(sized) > 1 else ""))
    return {"ok": True, "found": len(found), "message": message}


def cli_login(canvas_feed=False, veracross=False, check=False, reset=False,
              auto=False, all_sites=False, as_json=False) -> int:
    from playwright.sync_api import sync_playwright

    if auto or all_sites:
        # The saved-details path. `--auto` alone tries headless and, when a
        # step needs a person, opens a visible window for them; the web API
        # runs this and reads the JSON line at the end.
        import json as json_mod
        from schooldash import autologin
        sites = (["canvas", "veracross"] if all_sites
                 else ["veracross"] if veracross else ["canvas"])
        results = autologin.ensure(sites, allow_human=True)
        for result in results:
            print(f"{result.site}: {'ok' if result.ok else 'NOT signed in'} "
                  f"({result.how}) — {result.message}"
                  + (f" [{result.detail}]" if result.detail else ""))
        if as_json:
            print("JSON:" + json_mod.dumps([r.as_dict() for r in results]))
        return 0 if all(r.ok for r in results) else 1

    if reset:
        import shutil
        directory = profile_dir()
        if directory.exists():
            shutil.rmtree(directory)
            print(f"wiped {directory}")
        return 0

    if check:
        ok, message = session_valid()
        print(("session ok — " if ok else "session INVALID — ") + message)
        return 0 if ok else 1

    host = config.load()["canvas"]["host"].rstrip("/")

    if canvas_feed:
        with sync_playwright() as pw:
            context = open_context(pw, headless=True)
            try:
                if not whoami(context):
                    print("the Canvas session is expired — run: python run.py login")
                    return 1
                page = context.new_page()
                page.goto(f"{host}/calendar", wait_until="domcontentloaded",
                          timeout=60_000)
                try:
                    page.wait_for_load_state("networkidle", timeout=15_000)
                except Exception:  # noqa: BLE001
                    pass
                match = FEED_LINK.search(page.content())
                if not match:
                    print("no calendar-feed link found on /calendar")
                    return 1
                config.save({"canvas_ics": match.group(0)})
                print(f"saved the Canvas calendar feed URL "
                      f"({config.redact(match.group(0))})")
            finally:
                close_context(context)
        return 0

    if veracross:
        portal = config.load()["veracross"]["portal"]
        print("A browser window will open. Log into Veracross by hand; this "
              "window is watched only for when the login finishes.")
        with sync_playwright() as pw:
            context = open_context(pw, headless=False, reclaim=True)
            try:
                page = watched_page(context)
                page.goto(portal, wait_until="domcontentloaded", timeout=60_000)

                def past_the_login(current):
                    url = current.url or ""
                    return ("login" not in url
                            and "accounts.veracross" not in url
                            and not url.startswith("about:"))

                try:
                    await_login(context, page, past_the_login, what="Veracross", poll_seconds=2)
                except LoginCancelled:
                    print("the sign-in window was closed before the login finished")
                    return 2
                except TimeoutError as exc:
                    print(f"gave up waiting for the Veracross login ({exc})")
                    return 1
                page = watched_page(context)
                print("logged in. Looking for calendar-subscription feed URLs…")
                report = capture_veracross_feeds(page, portal)
                print(report["message"])
            finally:
                close_context(context)

        # Signing in is not the same as succeeding. Without the class feed the
        # dashboard has no schedule at all, so reporting success here is how a
        # first run marked "Veracross done" and moved on with a config that
        # could never work — which is exactly what happened on 2026-08-26.
        if not config.load(refresh=True)["veracross"]["class_ics"]:
            print("signed in, but the class-schedule feed was not captured — "
                  "nothing to build a schedule from.")
            return 1
        return 0

    # Default: the one-time manual Canvas login.
    print("A browser window will open at the Canvas login page. Log in by "
          "hand and TICK 'STAY SIGNED IN' — without it the session vanishes "
          "when the window closes. This window is only watched for success; "
          "nothing you type is read or stored.")
    with sync_playwright() as pw:
        context = open_context(pw, headless=False, reclaim=True)
        try:
            page = watched_page(context)
            page.goto(f"{host}/login", wait_until="domcontentloaded",
                      timeout=60_000)
            try:
                profile = await_login(context, page, lambda _page: whoami(context), what="Canvas")
            except LoginCancelled:
                print("the sign-in window was closed before the login finished")
                return 2
            except TimeoutError as exc:
                print(f"gave up waiting for the Canvas login ({exc})")
                return 1
            rewritten = persist_session_cookies(context)
            config.save({"canvas": {"name": profile.get("name", "")}})
            print(f"logged in as {profile.get('name')} "
                  f"({rewritten} session cookie(s) persisted for 30 days)")
        finally:
            close_context(context)
    return 0
