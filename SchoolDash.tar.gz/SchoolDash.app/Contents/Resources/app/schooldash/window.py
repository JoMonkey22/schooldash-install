"""`run.py app` — SchoolDash in its own window.

The dashboard used to open as a tab in whatever browser was default, which is
also where Google, Canvas and everything else live; a student closing "that
tab" lost the app, and on a fresh Mac the tab was a blank page for the seconds
the server took to start. This opens a native macOS window (WKWebView through
pywebview) pointed at the local server, after making sure the server answers.

The server itself is unchanged and still loopback-only; the window is just a
view of http://127.0.0.1:<port>/. Links that would open a new tab (Canvas,
docs, the textbook) go to the default browser, where the student is signed in
to those sites already.

When pywebview is not installed this falls back to the old behaviour: start
the server and open the default browser. Nothing is lost, only the window.

[MEASURED] 2026-09-02: *"mine is in the app but theirs is in the website"*. A
classmate's copy opened in a browser tab and his opened in its own window,
which looks like two different products. Two separate causes, and the fallback
above was hiding both: an install still on 0.11, which has no window at all,
and a venv where pywebview did not install — the library arrived in 0.12, so
every upgraded install has to add it.

So the fallback now (a) tries to install the library and reopen the window
before giving up, and (b) if it still cannot, says so where a person will
actually see it — a macOS notification and a line on the page, not a sentence
printed to a terminal nobody is looking at. A silent downgrade to a browser
tab is the app deciding, on its own, to be a worse product.
"""

import pathlib
import shutil
import sys

from schooldash import config, paths
from schooldash.logging_setup import get

log = get("window")


def _ensure_server() -> tuple[str, int, bool]:
    from schooldash.web import app as web_app
    cfg = config.load()["server"]
    host, port = cfg["host"], cfg["port"]
    if web_app.port_answering(host, port):
        return host, port, True
    code = web_app.serve_detached(open_browser=False)
    return host, port, code == 0


def _set_dock_icon() -> None:
    """When launched from the bundle the Dock already shows the app's icon;
    from a terminal it would show Python's. Best effort, never fatal."""
    try:
        from AppKit import NSApplication, NSImage  # type: ignore
        icon = paths.project_root() / "schooldash" / "web" / "static" / "brand" / "icon-1024.png"
        if icon.exists():
            image = NSImage.alloc().initWithContentsOfFile_(str(icon))
            if image is not None:
                NSApplication.sharedApplication().setApplicationIconImage_(image)
    except Exception as exc:  # noqa: BLE001 — cosmetic
        log.debug("dock icon not set: %s", exc)


def _tell_the_student(title: str, message: str) -> None:
    """A macOS notification. The student never sees stdout: the app is launched
    from the Dock, so a printed sentence is a sentence nobody reads."""
    import subprocess

    try:
        subprocess.run(
            ["osascript", "-e",
             f'display notification {message!r} with title {title!r}'],
            capture_output=True, timeout=10, check=False)
    except Exception as exc:  # noqa: BLE001 — a notification is never fatal
        log.debug("could not post a notification: %s", exc)


def _install_window_library():
    """Install pywebview into this venv and import it. None if that fails.

    pywebview arrived in 0.12, so an install whose environment was built by an
    earlier version has a venv without it — and the launcher's requirements
    check only runs at launch, which is too late if that run is the one that
    failed. Trying here means an upgraded install repairs itself on the next
    open instead of quietly staying a browser tab forever.

    Bounded, and never fatal: one attempt, sixty seconds, then the browser.
    """
    import os
    import subprocess

    venv = paths.data_root() / "venv"
    python = venv / "bin" / "python"
    if not python.exists():
        python = pathlib.Path(sys.executable)
    uv = shutil.which("uv") or str(pathlib.Path.home() / ".local" / "bin" / "uv")
    log.info("pywebview missing — installing it so the app can open a window")
    _tell_the_student("Finishing an update",
                      "Installing one more library so SchoolDash can open in "
                      "its own window…")
    env = dict(os.environ, VIRTUAL_ENV=str(venv))
    for command in ([uv, "pip", "install", "-q", "pywebview"],
                    [str(python), "-m", "pip", "install", "-q", "pywebview"]):
        if command[0] == uv and not (shutil.which("uv")
                                     or pathlib.Path(uv).exists()):
            continue
        try:
            done = subprocess.run(command, capture_output=True, timeout=120,
                                  env=env, check=False)
        except Exception as exc:  # noqa: BLE001
            log.warning("installing pywebview with %s failed: %s", command[0], exc)
            continue
        if done.returncode == 0:
            try:
                import webview  # pywebview

                log.info("pywebview installed — opening the window")
                return webview
            except ImportError:
                # Installed into a different interpreter than the one running.
                # Nothing more to try in this process; the launcher's own
                # requirements check will pick it up next time.
                log.warning("pywebview installed but not importable here")
                return None
        log.warning("installing pywebview with %s failed: %s", command[0],
                    (done.stderr or b"")[-200:])
    return None


def cli_app(path: str = "/") -> int:
    host, port, ok = _ensure_server()
    url = f"http://{host}:{port}{path}"
    if not ok:
        print(f"the server did not start — see {paths.log_file()}")
        return 1
    try:
        import webview  # pywebview
    except ImportError:
        webview = _install_window_library()
    if webview is None:
        log.warning("pywebview unavailable — opening the default browser instead")
        _tell_the_student(
            "SchoolDash opened in your browser",
            "Its own window needs one more library and it could not be "
            "installed. Everything works; reopen SchoolDash later to try again.")
        import webbrowser
        webbrowser.open(url)
        print(f"opened {url} in your browser — its own window needs pywebview")
        return 0

    log.info("opening the app window at %s", url)
    try:
        webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = True
        webview.settings["ALLOW_DOWNLOADS"] = True
    except Exception:  # noqa: BLE001 — older pywebview without settings
        pass
    webview.create_window("SchoolDash", url, width=1320, height=860,
                          min_size=(900, 600), text_select=True)
    webview.start(func=_set_dock_icon if sys.platform == "darwin" else None,
                  private_mode=False, storage_path=str(paths.data_root() / "webview"))
    return 0
