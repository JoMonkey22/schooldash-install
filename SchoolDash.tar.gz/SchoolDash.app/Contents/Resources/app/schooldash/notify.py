"""Scheduled macOS notifications for homework that is close or already late.

A digest, not per-item alerts: launchd fires this a couple of times a day and
each run posts at most one banner summarising what is actually pressing. That
is deliberate — an alert per assignment would be 15 banners on a Sunday night
and would train the student to swipe them all away without reading.

Nothing is invented here. The buckets come from the same due dates the
dashboard shows, and an item with no due date is never called urgent; it is
counted separately so a quiet banner never implies "nothing to do".
"""

import shutil
import subprocess

from schooldash import paths, pipeline
from schooldash.logging_setup import get
from schooldash.scoring import _due_of

log = get("notify")

TITLE = "SchoolDash"


# A test or a quiz is not work handed in — it is an event that happens. Once it
# is past there is nothing to do about it, so it is never "overdue".
#
# [MEASURED] 2026-09-02 the real 7am banner read "6 overdue · 2 due today · 3
# due tomorrow" and led with "Vocab Quiz on Para Empezar Vocab Set", which had
# been the day before. The app says this out loud elsewhere — lookup's study
# hints end "These are not things you hand in — they are things to have done
# before the day" — and the buckets simply did not agree with it.
ASSESSMENTS = {"test", "quiz"}


def is_assessment(item: dict) -> bool:
    return (item.get("category") or "") in ASSESSMENTS


def buckets(state: dict, today) -> dict[str, list[dict]]:
    """Split the current items into the groups worth a banner.

    `past_assessment` is kept separate rather than dropped: the item stays on
    the board and in the counts that describe the board, it just stops being
    called something it cannot be.
    """
    out: dict[str, list[dict]] = {"overdue": [], "today": [], "tomorrow": [],
                                  "undated": [], "past_assessment": []}
    for item in state.get("items") or []:
        if item.get("done"):
            continue
        due = _due_of(item)
        if due is None:
            out["undated"].append(item)
            continue
        days = (due - today).days
        if days < 0:
            out["past_assessment" if is_assessment(item) else "overdue"].append(item)
        elif days == 0:
            out["today"].append(item)
        elif days == 1:
            out["tomorrow"].append(item)
    return out


def _titles(items: list[dict], limit: int = 2) -> str:
    names = [(i.get("title") or "").strip() for i in items[:limit]]
    names = [n if len(n) <= 42 else n[:41].rstrip() + "…" for n in names if n]
    extra = len(items) - len(names)
    line = "; ".join(names)
    if extra > 0:
        line += f"; +{extra} more"
    return line


def compose(groups: dict[str, list[dict]]) -> tuple[str, str] | None:
    """(subtitle, body) for the banner, or None when nothing is pressing.

    Undated items alone never fire a banner — they have no deadline to be late
    for — but they are named in the body when something else does fire, so the
    count on screen and the count in the notification always agree.
    """
    overdue, due_today, tomorrow = (groups["overdue"], groups["today"],
                                    groups["tomorrow"])
    if not (overdue or due_today or tomorrow):
        return None

    headline_bits = []
    if overdue:
        headline_bits.append(f"{len(overdue)} overdue")
    if due_today:
        headline_bits.append(f"{len(due_today)} due today")
    if tomorrow:
        headline_bits.append(f"{len(tomorrow)} due tomorrow")
    subtitle = " · ".join(headline_bits)

    # lead with the group that is most likely to cost marks
    lead = overdue or due_today or tomorrow
    body = _titles(lead)
    if groups["undated"]:
        body += f" · {len(groups['undated'])} undated"
    return subtitle, body


def send(subtitle: str, body: str) -> bool:
    """Post one banner. Returns whether macOS accepted it.

    osascript is used rather than a new dependency. The banner is attributed
    to whichever app is running the script, so from launchd it shows up under
    Script Editor — the title below is what makes it self-identifying.
    """
    osascript = shutil.which("osascript")
    if not osascript:
        log.warning("no osascript on this machine — notifications are macOS only")
        return False
    script = (f'display notification {_applescript_string(body)} '
              f'with title {_applescript_string(TITLE)} '
              f'subtitle {_applescript_string(subtitle)}')
    try:
        result = subprocess.run([osascript, "-e", script], capture_output=True,
                                text=True, timeout=20, shell=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        log.error("could not post the notification: %s", exc)
        return False
    if result.returncode != 0:
        log.error("osascript refused: %s", (result.stderr or "").strip()[:200])
        return False
    return True


def _applescript_string(value: str) -> str:
    """AppleScript literal. Assignment titles are teacher-authored text that
    routinely contains quotes and backslashes, and this string is handed to an
    interpreter — so it is escaped, never interpolated raw."""
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return '"' + escaped.replace("\n", " ") + '"'


def cli_notify(refresh: bool = False, dry_run: bool = False) -> int:
    if refresh:
        from schooldash.pipeline import RefreshOptions, refresh as run_refresh
        try:
            run_refresh(RefreshOptions(docs_only=False, persist=True))
        except Exception as exc:  # noqa: BLE001
            # A failed refresh must not mean silence: notify on the last known
            # data and say it is stale, rather than pretending all is well.
            log.warning("refresh failed before notifying: %s", exc)

    state = pipeline.load_state_overlaid()
    if not state:
        print("no data yet — run: python run.py refresh")
        return 1

    groups = buckets(state, pipeline.today_local())
    composed = compose(groups)
    if composed is None:
        print("nothing due — no notification sent")
        return 0

    subtitle, body = composed
    if dry_run:
        print(f"{TITLE} — {subtitle}\n  {body}")
        return 0
    if not send(subtitle, body):
        print("the notification could not be posted — see "
              f"{paths.log_file()}")
        return 1
    print(f"notified: {subtitle}")
    return 0
