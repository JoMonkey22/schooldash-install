"""Rotating file log plus optional console output.

Anything console-less (the .pyw launcher, the detached server) MUST log to a
file: pythonw discards stdout and stderr entirely, so logs/schooldash.log is
the only place a silent failure can surface.
"""

import logging
import logging.handlers
import sys

from schooldash import paths

_configured = False


def setup(console: bool = True, level: int = logging.INFO) -> logging.Logger:
    global _configured
    root = logging.getLogger("schooldash")
    if _configured:
        return root
    root.setLevel(level)

    file_handler = logging.handlers.RotatingFileHandler(
        paths.log_file(), maxBytes=1_000_000, backupCount=5, encoding="utf-8"
    )
    file_handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    )
    root.addHandler(file_handler)

    if console:
        stream = logging.StreamHandler(sys.stderr)
        stream.setFormatter(logging.Formatter("%(levelname)s %(message)s"))
        root.addHandler(stream)

    _configured = True
    return root


def get(name: str = "") -> logging.Logger:
    base = "schooldash"
    return logging.getLogger(f"{base}.{name}" if name else base)


def last_error_lines(limit: int = 20) -> list[str]:
    """The most recent ERROR/CRITICAL lines from the log, for the dashboard."""
    log = paths.log_file()
    if not log.exists():
        return []
    try:
        lines = log.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []
    errors = [l for l in lines if " ERROR " in l or " CRITICAL " in l]
    return errors[-limit:]
