"""Keep the Veracross portal session warm.

Why this exists, measured on 2026-09-01. Cookie lifetimes in the app's browser
profile:

    brophyprep.instructure.com  canvas_session       695.0 h left   (~29 days)
    accounts.veracross.com      _gatekeeper_session    0.5 h left

Canvas lasts a month because "Stay signed in" was ticked at login. Veracross
issues a **30-minute** session, which is why grades were repeatedly present at
07:00 and gone by mid-morning — the student saw an empty Grades panel and no
reason for it.

The 30 minutes are a *sliding* window, not a countdown from login: visiting the
portal pushed the expiry from 26.8 minutes back out to 29.6. So touching the
portal more often than every 30 minutes keeps it alive, which is exactly what
leaving a browser tab open does.

What this cannot do, and does not pretend to: if the server has already dropped
the session, no amount of polling brings it back — a person has to sign in
again. So this reports what it found rather than claiming success, and the
dashboard's own sign-in button is the remedy when it reports a dead session.
"""

from datetime import datetime, timezone

from schooldash import config, timezones
from schooldash.logging_setup import get

log = get("keepalive")

# Comfortably inside the measured 30-minute window, so one missed run (a closed
# lid, a dropped network) does not by itself end the session.
INTERVAL_MINUTES = 20
COOKIE = "_gatekeeper_session"


def _minutes_left(context) -> float | None:
    """Minutes until the gatekeeper cookie expires, or None if it is absent.

    Never raises. [MEASURED] 2026-09-06: a sign-in started from the dashboard
    reclaims the browser profile, which kills whatever else is on it — and
    this call, one line after the re-login, brought the whole keep-alive down
    with `TargetClosedError` instead of reporting what it had already found.
    """
    now = datetime.now(timezone.utc).timestamp()
    try:
        cookies = context.cookies()
    except Exception:  # noqa: BLE001 — the browser went away underneath us
        return None
    for cookie in cookies:
        if cookie.get("name") == COOKIE:
            expires = cookie.get("expires", -1)
            if expires and expires > 0:
                return round((expires - now) / 60, 1)
            return None
    return None


def touch() -> dict:
    """Visit the portal once. Returns what was actually observed."""
    from playwright.sync_api import sync_playwright

    from schooldash import browser

    portal = (config.load()["veracross"]["portal"] or "").rstrip("/")
    result = {"at": datetime.now(timezones.zone()).isoformat(timespec="seconds"),
              "portal": bool(portal), "alive": False, "minutes_left": None,
              "landed": "", "note": ""}
    if not portal:
        result["note"] = "no Veracross portal configured"
        return result

    with sync_playwright() as pw:
        try:
            context = browser.open_context(pw, headless=True)
        except browser.SessionError as exc:
            # Something else has the profile — a refresh, or a sign-in window.
            # Both of those are themselves visiting the portal, so the session
            # is being kept warm by whatever is holding the browser. Skipping
            # is the correct outcome and NOT a failure: exiting non-zero here
            # made launchd log a failed job every twenty minutes for a
            # condition that means "no work needed".
            result["skipped"] = True
            result["note"] = f"skipped — {exc}"
            log.info("keepalive skipped: %s", exc)
            return result
        try:
            page = context.new_page()
            try:
                try:
                    page.goto(portal, wait_until="domcontentloaded", timeout=60_000)
                except Exception as exc:  # noqa: BLE001 — see below
                    # A closed lid, a dropped Wi-Fi, a school network that
                    # blocks the portal: the request never leaves the machine.
                    # [MEASURED] 2026-09-08 this raised out of touch() with a
                    # bare `finally`, so `run.py keepalive` ended in a
                    # traceback and exited non-zero — launchd recorded a failed
                    # job, and the log filled with
                    # `net::ERR_INTERNET_DISCONNECTED` stack traces that read
                    # like a broken session. Being offline is not a signed-out
                    # session and must not be reported as one: there is simply
                    # nothing to do until the network is back.
                    result["skipped"] = True
                    result["note"] = ("skipped — the portal could not be "
                                      f"reached ({type(exc).__name__}); the "
                                      "Mac is probably offline")
                    log.info("keepalive skipped: portal unreachable (%s)",
                             type(exc).__name__)
                    return result
                landed = page.url or ""
                result["landed"] = landed
                # The same test fetch_grades uses: an expired session is
                # redirected to accounts.veracross.com rather than erroring.
                result["alive"] = not ("accounts.veracross" in landed
                                       or "/login" in landed)
            finally:
                page.close()
            # A lapsed session is no longer the end of it: with saved details
            # the keep-alive signs back in, which is what a person would do.
            if not result["alive"]:
                from schooldash import autologin, credentials
                if credentials.veracross_login():
                    fixed = autologin.veracross(context, capture_feeds=False)
                    result["alive"] = fixed.ok
                    result["relogin"] = fixed.message
                    if fixed.ok:
                        result["landed"] = "portal (after automatic sign-in)"
            result["minutes_left"] = _minutes_left(context)
            # The whole point of touching the portal is to keep the session
            # usable LATER, which means it has to survive the browser closing.
            if result["alive"]:
                try:
                    kept = browser.persist_session_cookies(context)
                    if kept:
                        log.info("keepalive: gave %d session cookie(s) a real expiry", kept)
                except Exception as exc:  # noqa: BLE001 — never fail the touch
                    log.debug("could not persist cookies: %s", exc)
        finally:
            try:
                browser.close_context(context)
            except Exception:  # noqa: BLE001
                pass

    result["note"] = ("session extended" if result["alive"]
                      else ("signed out — the automatic sign-in did not finish: "
                            + result["relogin"] if result.get("relogin")
                            else "signed out — add your sign-in details in Settings so "
                                 "SchoolDash can sign back in itself, or sign in by hand"))
    log.info("keepalive: alive=%s minutes_left=%s", result["alive"],
             result["minutes_left"])
    return result


def cli_keepalive() -> int:
    outcome = touch()
    if outcome.get("skipped"):
        print(outcome["note"])
        return 0
    if not outcome["portal"]:
        print("no Veracross portal in config.json — nothing to keep alive")
        return 1
    left = outcome["minutes_left"]
    if outcome["alive"]:
        print(f"Veracross session is alive"
              + (f" ({left} minutes left on the cookie)" if left else "")
              + " — extended by this visit")
        return 0
    print("Veracross is signed out. Grades cannot load until someone signs in "
          "again: open the dashboard and press 'Sign in to Veracross'.")
    return 2
