"""Urgency ranking — behavior-preserving port of legacy/priority.py, plus the
caller-supplied-category hook the predecessor used (so the prose guard never
bakes keyword logic into the scorer). tests/test_scoring_parity.py asserts
identical ordering against the legacy implementation.
"""

import json
import re
from datetime import date, datetime

from schooldash import paths, timezones

LOW_PRIORITY = 20        # the opt-in "hide low priority" cutoff — web default shows all
PROSE_LIMIT = 55         # doc titles longer than this are prose, not names
HEAVY = {"test", "project", "essay", "quiz"}

TYPE_KEYWORDS = [
    ("test",        ["test", "exam", "midterm", "final exam", "assessment",
                     "unit test", "progress check"]),
    ("project",     ["project", "lab", "presentation", "portfolio", "essay",
                     "paper", "draft", "montage", "capstone"]),
    ("quiz",        ["quiz"]),
    # "watch" and "episode" are consumption; "video" is a noun that goes both
    # ways. [MEASURED] 2026-09-02: "Progress Video #5 – you know the drill"
    # (Guitar, from the teacher's doc, with no Canvas assignment to correct it
    # from) was filed as reading — weight 10 of 40, 45 minutes assumed — when
    # a progress video is a recording he makes. Canvas's submission_types fix
    # this where Canvas knows (see `must_submit`); for a doc line there is no
    # fact to read, and a bare noun is not evidence.
    ("reading",     ["read", "annotat", "textbook", "watch", "episode"]),
    # "notes" earns its place from real marked work, not from a guess:
    # [MEASURED] 2026-09-03, seven of Honors Biology's twelve graded pieces
    # are "Notes 2.2", "Ch 1.3 Notes", "Measurements WS" and the like. They
    # all landed in "other work", which made the strengths summary on that
    # class say nothing useful about the kind of work he does most of.
    ("problem_set", ["problem", "pset", "homework", "group work", "pogil",
                     "worksheet", "practice", "frq", "problems", "notes"]),
    ("discussion",  ["discussion", "discuss", "four corner", "db#", "journal",
                     "reflection", "post", "bell work", "sticky"]),
    ("writing",     ["rubric", "summary", "book card", "write", "writing"]),
]

KIND_TO_TYPE = {
    "quiz": "quiz",
    "discussion topic": "discussion",
    "wiki page": "reading",
    "assignment": "other",
}

URGENCY_POINTS = [(-1, 100), (0, 92), (1, 78), (2, 64), (4, 46),
                  (7, 30), (14, 15), (30, 6)]

CATEGORY_WEIGHT = {
    "test": 40, "project": 34, "essay": 30, "writing": 24, "quiz": 20,
    "problem_set": 12, "reading": 10, "discussion": 8, "other": 12,
    "neutral": 12,   # alias of "other" — same weight, so parity holds
}

DEFAULT_MINUTES = {
    "test": 60, "project": 120, "writing": 75, "essay": 90, "quiz": 20,
    "problem_set": 40, "reading": 45, "discussion": 20, "other": 30,
    "neutral": 30,
}


# How teachers abbreviate homework in a title: "Measurements WS", "HW 3.2".
RE_SHORTHAND = re.compile(r"\b(?:ws|hw)\b")


def _has_word(text, word):
    return re.search(r"\b" + re.escape(word), text) is not None


# Kinds Canvas is actually definitive about. "assignment" is NOT one of them:
# Canvas calls almost everything an assignment, so it says nothing and the title
# has to decide. The others are chosen deliberately in the teacher's setup.
AUTHORITATIVE_KINDS = {"quiz": "quiz", "discussion topic": "discussion",
                       "wiki page": "reading"}

# Respondus LockDown Browser is only ever required for a proctored quiz or exam,
# whatever the thing is called. It is the strongest signal in a title.
PROCTORED = ("lockdown browser", "respondus")


# Canvas submission types that mean the student PRODUCES something. Anything
# in this set is work handed in, whatever the title calls it.
PRODUCED = {"online_upload", "media_recording", "online_text_entry",
            "online_url", "online_quiz", "discussion_topic", "external_tool"}


def categorize(title, kind="", must_submit=False):
    """What kind of work this is.

    Order matters, and it changed on 2026-09-01. Title keywords used to run
    first, which meant a guess beat a fact: [MEASURED] "Shield Reflection —
    Requires Respondus LockDown Browser" is `kind: quiz` straight from Canvas,
    but the word "reflection" matched the discussion keywords and the student
    was shown a discussion. Being told a quiz is a discussion is how someone
    walks into a quiz having not studied.

    So Canvas's own type wins where Canvas is definite. Two exceptions on top of
    it: a proctored title is a quiz however it is labelled, and an explicit
    "test"/"exam" in the title upgrades a Canvas quiz to a test, because
    teachers deliver real exams through the quiz tool and the two deserve
    different amounts of studying.
    """
    text = (title or "").lower()
    lowered_kind = (kind or "").lower()

    test_words = dict(TYPE_KEYWORDS)["test"]
    says_test = any(_has_word(text, word) for word in test_words)

    authoritative = AUTHORITATIVE_KINDS.get(lowered_kind)
    if authoritative == "quiz":
        return "test" if says_test else "quiz"
    if any(marker in text for marker in PROCTORED):
        return "test" if says_test else "quiz"
    if authoritative:
        return authoritative

    # "reading" is off the table for something Canvas says must be handed in.
    # [MEASURED] 2026-09-02: "Progress Video 3" (Guitar) was filed as reading
    # — weight 10 of 40, 45 minutes assumed — because the reading keywords
    # include "video" and "watch". In a guitar class the progress video IS the
    # work: he records it and uploads it. Canvas states the difference in
    # `submission_types`, and guessing from the title when the fact is in hand
    # is the mistake PROCTORED already exists to prevent.
    for category, words in TYPE_KEYWORDS:
        if must_submit and category == "reading":
            continue
        if any(_has_word(text, word) for word in words):
            return category
    # Abbreviations, checked last so a fuller word in the same title still
    # wins. Both boundaries are required — `_has_word` only anchors the front,
    # and a bare `\bws` would also match "wsomething".
    if RE_SHORTHAND.search(text):
        return "problem_set"
    return KIND_TO_TYPE.get(lowered_kind, "other")


def load_estimates():
    path = paths.project_root() / "estimates.json"
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
        except (ValueError, OSError):
            pass
    return {}


def _estimate_scale() -> float:
    """The first student asked for time estimates cut by 60% (2026-08-22): the DEFAULT
    per-category guesses are scaled by scoring.estimate_scale (0.4). His own
    corrections in estimates.json are taken literally, never scaled."""
    try:
        from schooldash import config
        return float(config.load()["scoring"].get("estimate_scale", 1.0))
    except Exception:  # noqa: BLE001
        return 1.0


def estimate_minutes(category, estimates=None):
    estimates = estimates if estimates is not None else load_estimates()
    by_cat = estimates.get("by_category", {}) if isinstance(estimates, dict) else {}
    if category in by_cat:
        return int(by_cat[category])
    base = DEFAULT_MINUTES.get(category, DEFAULT_MINUTES["other"])
    return max(5, int(round(base * _estimate_scale())))


def format_minutes(minutes):
    minutes = int(round(minutes / 5.0)) * 5
    if minutes < 60:
        return f"~{minutes}m"
    hours, mins = divmod(minutes, 60)
    return f"~{hours}h" if mins == 0 else f"~{hours}h{mins:02d}m"


def urgency(days_until):
    if days_until <= URGENCY_POINTS[0][0]:
        return float(URGENCY_POINTS[0][1])
    if days_until >= URGENCY_POINTS[-1][0]:
        return float(URGENCY_POINTS[-1][1])
    for (d0, s0), (d1, s1) in zip(URGENCY_POINTS, URGENCY_POINTS[1:]):
        if d0 <= days_until <= d1:
            span = d1 - d0
            frac = (days_until - d0) / span if span else 0
            return s0 + (s1 - s0) * frac
    return 5.0


def points_weight(points):
    try:
        value = float(points)
    except (TypeError, ValueError):
        return 0.0
    return min(value, 100.0) / 5.0


def _due_of(item) -> date | None:
    """Accepts both the new shape (due/due_date ISO strings) and the legacy
    shape (when datetime / day date) so the parity test can feed both scorers
    identical inputs."""
    when = item.get("when")
    if isinstance(when, datetime):
        return when.date()
    due = item.get("due")
    if isinstance(due, str) and due:
        return timezones.local_date(due)
    due_date = item.get("due_date")
    if isinstance(due_date, str) and due_date:
        return date.fromisoformat(due_date)
    day = item.get("day")
    if isinstance(day, date):
        return day
    return None


# A test or a quiz is an event, not work handed in. Once it is past there is
# nothing to be late for, so it must not earn the overdue urgency band.
#
# [MEASURED] 2026-09-02: with this fixed in notify and on the row tags but not
# here, the hero card — the largest thing on the page — still read "OVERDUE —
# START HERE / Vocab Quiz on Para Empezar Vocab Set / Tue, Sep 1". Fixing the
# surfaces one at a time left the loudest one, so the rule lives here, where
# every surface reads it.
#
# The urgency of the 30-days-out band: low enough to sink under anything live,
# high enough to stay visible. It is never hidden — the row is tagged "was
# <date>" — because he may still have to make it up.
ASSESSMENTS = {"test", "quiz"}
PAST_ASSESSMENT_URGENCY = 6


# How much a weak class lifts its work up the list.
#
# *"prioratize assignment based on grade in the class"* — the same essay
# matters more in the class sitting at 78% than in the one at 100%, and the
# board should say so. Deliberately small: a nudge, not an override. Urgency
# is worth up to ~40 points and a category up to ~25, so ±8 changes the order
# of things due on the same day without ever putting next week's homework
# above tonight's.
#
# The bands are wide on purpose. A grade is a moving number, and a scale that
# reacted to every decimal would reshuffle his board twice a day for no
# reason a person could follow.
GRADE_NUDGE = (
    (70.0, 8.0),    # below 70: this class needs the attention
    (80.0, 5.0),
    (90.0, 2.0),
    (97.0, 0.0),    # 90-97 is fine; nothing to say
    (101.0, -2.0),  # already at 100: the marginal essay matters least
)


def grade_nudge(percent) -> float:
    """The lift for a class at this percentage. 0 when it is unknown —
    a missing grade must never change where work sits."""
    if percent is None:
        return 0.0
    try:
        value = float(percent)
    except (TypeError, ValueError):
        return 0.0
    for ceiling, nudge in GRADE_NUDGE:
        if value < ceiling:
            return nudge
    return 0.0


def score(item: dict, today: date, grades: dict | None = None):
    """(priority_number, reason_string). Honors a caller-supplied category —
    that is the hook the prose guard uses; the scorer knows nothing of prose.

    `grades` maps course_key to the class percentage, so work in a class he is
    behind in rises above the same work in a class he has already aced.
    """
    if item.get("done"):
        return -1.0, "done"

    due = _due_of(item)
    days_until = (due - today).days if due else 21
    category = item.get("category") or categorize(
        item.get("title", ""), item.get("kind", ""),
        must_submit="must_submit" in (item.get("flags") or []))
    over = days_until < 0 and category in ASSESSMENTS

    nudge = grade_nudge((grades or {}).get(item.get("course_key")))
    total = (PAST_ASSESSMENT_URGENCY if over else urgency(days_until)) \
        + CATEGORY_WEIGHT.get(category, 12) + points_weight(item.get("points")) \
        + nudge

    when_word = ("already happened" if over else
                 "overdue" if days_until < 0 else
                 "due today" if days_until == 0 else
                 "due tomorrow" if days_until == 1 else
                 f"due in {days_until} days" if due else "no due date")
    bits = [when_word, category.replace("_", " ")]
    if item.get("points"):
        bits.append(f"{item['points']:g} pts")
    # The reason line is shown on the board, so a nudge that changed the order
    # has to be visible. An invisible reordering is indistinguishable from a
    # bug — and he would be right to distrust it.
    # Worded by band, because "class you are behind in" is not true of a B.
    # A reason line that overstates is a reason line he learns to ignore.
    if nudge >= 5:
        bits.append("class you are behind in")
    elif nudge > 0:
        bits.append("weaker class")
    elif nudge < 0:
        bits.append("class already at 100%")
    return total, " · ".join(bits)


def apply_prose_guard(item: dict) -> str:
    """Doc and page titles longer than PROSE_LIMIT are prose; a heavy category
    matched inside prose is a false positive and drops to neutral.

    [MEASURED] 2026-09-01, live, the first refresh that read course homepages:
    "WB P-6 (Start reviewing for Para Empezar Test - next Block…)" scored as a
    TEST and led the whole board, and "P- 7, P-8, Finish Quizlet Write…" scored
    as a QUIZ — because "Quizlet" contains "quiz". Both are workbook pages.

    The exception is an item whose category the extractor *asserted* rather
    than guessed: prose.py reads "Test on Para Empezar chapter" off the front
    of the line, and that one really is a test. It says so with a flag, and a
    guard against keyword accidents must not overrule a direct statement.
    """
    category = item.get("category") or ""
    if "stated_category" in (item.get("flags") or []):
        return category
    if (item.get("source") in ("doc", "canvas_page")
            and len(item.get("title") or "") > PROSE_LIMIT
            and category in HEAVY):
        return "neutral"
    return category


def rank(items: list[dict], today: date,
         grades: list | None = None) -> list[dict]:
    """Attach category, estimate, priority, reason; sort by priority desc.
    Done items sink (score -1) but are never removed — nothing hidden."""
    estimates = load_estimates()
    # {course_key: percent} for the grade nudge. Only graded classes count: an
    # ungraded course must not be treated as a zero, which would shove every
    # club and advisory to the top of the board.
    by_course = {g.get("course_key"): g.get("percent")
                 for g in (grades or [])
                 if g.get("graded") and g.get("percent") is not None}
    for item in items:
        preset = item.get("category")
        if not preset or preset == "neutral":
            item["category"] = categorize(
                item.get("title", ""), item.get("kind", ""),
                must_submit="must_submit" in (item.get("flags") or []))
        item["category"] = apply_prose_guard(item)
        item["score"], item["reason"] = score(item, today, by_course)
        item["est_minutes"] = estimate_minutes(item["category"], estimates)
        item["est_label"] = format_minutes(item["est_minutes"])
    items.sort(key=lambda e: (e.get("score", 0)), reverse=True)
    return items
