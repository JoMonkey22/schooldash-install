"""Signing back in without a person at the keyboard.

Both school systems expire on their own schedule — Canvas when its month-long
"Stay signed in" cookie runs out, Veracross every thirty idle minutes — and
until now the only remedy was a red banner and a browser window someone had to
notice and finish. This module does what the person would do: opens the
sign-in page, picks the school-email option, types the saved details, and
waits for the site to land. It uses the same persistent browser profile every
refresh uses, so once it works the session simply continues.

What it will not do:
  - guess. Every step checks what page it is actually on before acting, and an
    unrecognised page ends the attempt with a screenshot in logs/login-shots/
    rather than a click in the dark.
  - fight a challenge. A two-step prompt, a phone confirmation, a CAPTCHA, or
    Google's "this browser may not be secure" wall all mean a person is needed.
    The result says so (`needs_human`), and the caller decides whether to open
    a visible window for them.
  - leak. Passwords come from credentials.py and go into one form field. Every
    message that could quote page text is passed through credentials.scrub().

Selectors are written loosely (type= and name= first, ids second, visible text
last) because Google and Veracross both restyle their sign-in pages without
notice; each step tries several and treats "none matched" as a stop, not a
crash. When a step stops, the saved screenshot is the evidence.
"""

import re
import time
from dataclasses import dataclass, field

from schooldash import browser, config, credentials, paths
from schooldash.logging_setup import get

log = get("autologin")

GOOGLE_HOST = "accounts.google.com"
VERACROSS_ACCOUNTS = "accounts.veracross.com"

# How long one full sign-in may take before it is called stuck. Google's
# redirect chain is typically 5-15 seconds; a slow school network was measured
# at 40. Ninety leaves room and still fails within a refresh's patience.
STEP_DEADLINE_S = 90


@dataclass
class LoginResult:
    site: str
    ok: bool
    how: str                  # already | auto | human | failed | skipped
    message: str
    needs_human: bool = False
    detail: str = ""
    shots: list = field(default_factory=list)

    def as_dict(self) -> dict:
        return {"site": self.site, "ok": self.ok, "how": self.how,
                "message": self.message, "needs_human": self.needs_human,
                "detail": self.detail, "shots": list(self.shots)}


# --------------------------------------------------------------------------
# small page helpers — every one tolerates a page mid-navigation


def _url(page) -> str:
    try:
        return page.url or ""
    except Exception:  # noqa: BLE001
        return ""


def _text(page) -> str:
    try:
        return page.inner_text("body", timeout=3000) or ""
    except Exception:  # noqa: BLE001
        return ""


def _settle(page, ms: int = 1200) -> None:
    try:
        page.wait_for_load_state("domcontentloaded", timeout=15_000)
    except Exception:  # noqa: BLE001
        pass
    try:
        page.wait_for_timeout(ms)
    except Exception:  # noqa: BLE001
        pass


def _first_visible(page, selectors: list[str]):
    """The first locator among `selectors` with a visible match, or None."""
    for selector in selectors:
        try:
            locator = page.locator(selector)
            count = locator.count()
        except Exception:  # noqa: BLE001
            continue
        for index in range(min(count, 6)):
            candidate = locator.nth(index)
            try:
                if candidate.is_visible():
                    return candidate
            except Exception:  # noqa: BLE001
                continue
    return None


def _click(locator) -> bool:
    try:
        locator.click(timeout=8000)
        return True
    except Exception as exc:  # noqa: BLE001
        log.debug("click failed: %s", exc)
        return False


def _fill(locator, value: str) -> bool:
    try:
        locator.click(timeout=5000)
    except Exception:  # noqa: BLE001
        pass
    try:
        locator.fill(value, timeout=8000)
        return True
    except Exception as exc:  # noqa: BLE001
        log.debug("fill failed: %s", exc)
        return False


def _shot(page, label: str, shots: list) -> None:
    """Save what the page looked like when a step stopped. Kept small: at most
    a dozen files, oldest deleted."""
    directory = paths.login_shots_dir()
    stamp = time.strftime("%Y%m%d-%H%M%S")
    target = directory / f"{label}-{stamp}.png"
    try:
        page.screenshot(path=str(target), full_page=False)
        shots.append(str(target))
    except Exception as exc:  # noqa: BLE001
        log.debug("screenshot failed: %s", exc)
        return
    # By AGE, not by name. [MEASURED] 2026-09-04: sorted() on the filenames is
    # alphabetical, and every "canvas-*" shot sorts before every
    # "veracross-*" one — so with twelve Veracross shots on disk the Canvas
    # screenshot was deleted in the same call that wrote it. The error said "a
    # screenshot was saved under logs/login-shots" and there was never a file
    # there, which is exactly the evidence needed to diagnose a failed sign-in.
    old = sorted(directory.glob("*.png"), key=lambda f: f.stat().st_mtime)
    for stale in old[:-12]:
        try:
            stale.unlink()
        except OSError:
            pass


# --------------------------------------------------------------------------
# Google


EMAIL_INPUTS = ['input[type="email"]', 'input[name="identifier"]', "#identifierId",
                'input[autocomplete="username"]']
PASSWORD_INPUTS = ['input[type="password"]', 'input[name="Passwd"]',
                   'input[name="password"]']
NEXT_BUTTONS = ["#identifierNext button", "#identifierNext",
                "#passwordNext button", "#passwordNext",
                'button:has-text("Next")', 'input[type="submit"]',
                'button[type="submit"]']

# Google's refusals, told apart because each needs different advice.
#
# [PROVEN] tests/test_prosecution.py: WRONG_PASSWORD matched the bare phrase
# "try again", which Google puts on several unrelated failures — including
# "Wrong code. Try again." on a two-step page. Reporting that as a wrong
# password sends him to change a password that was right, and buries the real
# cause. Every pattern here now needs a phrase that only its own case produces.
BLOCKED = re.compile(r"browser or app may not be secure|may not be secure", re.I)
WRONG_PASSWORD = re.compile(
    r"wrong password"
    r"|incorrect password"
    r"|password (?:you entered )?(?:was|is) incorrect", re.I)
# Google declined and did not say why. Not the browser wall, not a bad
# password — worth its own message rather than being called "stuck".
GOOGLE_REFUSED = re.compile(
    r"couldn.t sign you in|something went wrong|try again later", re.I)
NO_ACCOUNT = re.compile(r"couldn.t find your google account|enter a valid email", re.I)
# Chrome's OWN interstitial, not Google's page: shown when the browser is
# enrolled in an admin console whose policy requires signing into the browser
# itself. [MEASURED] 2026-09-04 it appeared AFTER the password was accepted,
# on the redirect back from `accounts.google.com/o/saml2/continue`, and left
# the page on `chrome-error://chromewebdata/` with no Canvas session. Nothing
# a person types can get past it in this profile — the answer is a browser
# that does not read that policy (browser.chrome_is_cloud_managed).
# "sign into Chrome" and "sign in to Chrome" are both on the same interstitial,
# one word apart — the space is optional, the "t" is not.
ENTERPRISE_WALL = re.compile(r"sign\s+in\s*to\s+chrome"
                             r"|requires you to sign in", re.I)
HUMAN_PAGE = re.compile(r"2-step verification|verify it.s you|confirm it.s you|"
                        r"check your phone|tap yes|enter the code|"
                        r"security key|passkey|unusual activity|"
                        r"verify your identity|captcha", re.I)


def google_sign_in(page, email: str, password: str, shots: list,
                   deadline_s: int = STEP_DEADLINE_S) -> str:
    """Drive accounts.google.com until the page leaves it.

    Returns one of: done | human | failed:blocked | failed:password |
    failed:email | failed:stuck. The caller maps these to a LoginResult.
    """
    deadline = time.monotonic() + deadline_s
    typed_email = typed_password = False
    last_url = ""
    while time.monotonic() < deadline:
        url = _url(page)
        if GOOGLE_HOST not in url:
            return "done"
        if url != last_url:
            log.info("google: at %s", re.sub(r"\?.*", "", url)[:120])
            last_url = url
        text = _text(page)

        if BLOCKED.search(text):
            _shot(page, "google-blocked", shots)
            return "failed:blocked"
        if WRONG_PASSWORD.search(text) and typed_password:
            _shot(page, "google-password", shots)
            return "failed:password"
        if NO_ACCOUNT.search(text) and typed_email:
            _shot(page, "google-email", shots)
            return "failed:email"
        # Checked after the specific cases and after the challenge test below
        # would have fired, so this only catches a refusal with no other tell.
        if GOOGLE_REFUSED.search(text) and not HUMAN_PAGE.search(text):
            _shot(page, "google-refused", shots)
            return "failed:google"

        # An account chooser listing the saved address: pick it.
        if not typed_email and email:
            chooser = _first_visible(page, [
                f'[data-identifier="{email}"]', f'[data-email="{email}"]',
                f'li:has-text("{email}")', f'div[role="link"]:has-text("{email}")'])
            if chooser is not None and _click(chooser):
                typed_email = True
                _settle(page)
                continue

        password_box = _first_visible(page, PASSWORD_INPUTS)
        if password_box is not None and not typed_password:
            if not password:
                _shot(page, "google-needs-password", shots)
                return "human"
            if _fill(password_box, password):
                typed_password = True
                nxt = _first_visible(page, ["#passwordNext button", "#passwordNext",
                                            'button:has-text("Next")'])
                if nxt is None or not _click(nxt):
                    try:
                        password_box.press("Enter")
                    except Exception:  # noqa: BLE001
                        pass
                _settle(page, 2000)
                continue

        email_box = _first_visible(page, EMAIL_INPUTS)
        if email_box is not None and not typed_email:
            if _fill(email_box, email):
                typed_email = True
                nxt = _first_visible(page, ["#identifierNext button", "#identifierNext",
                                            'button:has-text("Next")'])
                if nxt is None or not _click(nxt):
                    try:
                        email_box.press("Enter")
                    except Exception:  # noqa: BLE001
                        pass
                _settle(page, 2000)
                continue

        # Interstitials Google shows after a password: "protect your account",
        # recovery-phone nags. They all carry a way to decline.
        if "/speedbump/" in url or "/signinoptions/" in url or re.search(
                r"protect your account|add a recovery|simplify your sign-in",
                text, re.I):
            skip = _first_visible(page, ['button:has-text("Not now")',
                                         'button:has-text("Skip")',
                                         'button:has-text("Cancel")',
                                         'button:has-text("Confirm")',
                                         'button:has-text("Done")',
                                         'button:has-text("Continue")'])
            if skip is not None and _click(skip):
                _settle(page, 1500)
                continue

        # A challenge the app must not attempt: two-step, device prompt,
        # passkey, CAPTCHA. (challenge/pwd is just the password page and is
        # handled above.)
        if (re.search(r"/challenge/(?!pwd)", url) or HUMAN_PAGE.search(text)
                or _first_visible(page, ['iframe[src*="recaptcha"]']) is not None):
            _shot(page, "google-challenge", shots)
            return "human"

        try:
            page.wait_for_timeout(700)
        except Exception:  # noqa: BLE001
            pass
    _shot(page, "google-stuck", shots)
    return "failed:stuck"


def _await_host(page, host: str, seconds: int = 25) -> bool:
    """Wait for the page to actually reach `host`.

    [MEASURED] 2026-09-04: Canvas now answers /login with a discovery page on
    `iad.login.instructure.com`, and the click through to Google took between
    2.9 and 8 seconds on the same machine. The old code waited a flat 2s and
    then asked "are we at Google?" — so on the slow half of that range the
    Google step was skipped entirely and the failure was reported as though
    Google had run and finished. Wait for the thing, with a deadline.
    """
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if host in _url(page):
            return True
        if ENTERPRISE_WALL.search(_text(page)):
            return False
        try:
            page.wait_for_timeout(400)
        except Exception:  # noqa: BLE001
            break
    return host in _url(page)


def _outcome_to_result(site: str, outcome: str, shots: list) -> LoginResult:
    if outcome == "human":
        return LoginResult(site, False, "human",
                           "the sign-in needs a person: Google is asking for a "
                           "second step (a phone prompt, a code, or a check) "
                           "that SchoolDash must not do for you",
                           needs_human=True, shots=shots)
    if outcome == "failed:blocked":
        return LoginResult(site, False, "failed",
                           "Google refused the automated browser ('this browser "
                           "may not be secure'). A visible window usually gets "
                           "through — open one from the dashboard",
                           needs_human=True, detail=outcome, shots=shots)
    if outcome == "failed:password":
        return LoginResult(site, False, "failed",
                           "Google says the saved password is wrong — update it "
                           "in Settings", detail=outcome, shots=shots)
    if outcome == "failed:email":
        return LoginResult(site, False, "failed",
                           "Google does not recognise the saved email address — "
                           "check it in Settings", detail=outcome, shots=shots)
    if outcome == "failed:google":
        return LoginResult(site, False, "failed",
                           "Google declined the sign-in without saying why. Try "
                           "again in a minute; if it keeps happening, sign in by "
                           "hand once and it will carry on from there",
                           needs_human=True, detail=outcome, shots=shots)
    return LoginResult(site, False, "failed",
                       "the sign-in stalled on a page SchoolDash did not "
                       "recognise (a screenshot was saved under logs/login-shots)",
                       detail=outcome, shots=shots)


# --------------------------------------------------------------------------
# Canvas (Google single sign-on)


def canvas(context, shots: list | None = None) -> LoginResult:
    """Make the Canvas session in `context` valid, signing in if needed."""
    shots = shots if shots is not None else []
    if browser.whoami(context):
        # Same as Veracross below: a working session belongs on disk, not only
        # in the browser's memory.
        browser.persist_session_cookies(context)
        return LoginResult("canvas", True, "already", "Canvas is signed in")
    creds = credentials.get("google")
    if not creds or not creds.get("password"):
        return LoginResult("canvas", False, "skipped",
                           "no saved Google sign-in — add it in Settings, or sign "
                           "in by hand", needs_human=True)
    host = config.load()["canvas"]["host"].rstrip("/")
    page = context.new_page()
    try:
        try:
            page.goto(f"{host}/login", wait_until="domcontentloaded", timeout=60_000)
        except Exception as exc:  # noqa: BLE001
            return LoginResult("canvas", False, "failed",
                               f"could not open the Canvas login page ({type(exc).__name__})")
        _settle(page)
        # Canvas's login-method chooser ("Brophy Email" -> /login/saml/N). The
        # link text is school-specific; the href shape is not.
        reached_google = False
        if GOOGLE_HOST not in _url(page):
            saml = _first_visible(page, ['a[href*="/login/saml"]',
                                         'a:has-text("Email")',
                                         'a:has-text("Google")',
                                         'button:has-text("Google")'])
            if saml is not None:
                _click(saml)
                # The SAML hop is a redirect chain, not one navigation.
                _await_host(page, GOOGLE_HOST)
            elif "/login" in _url(page) and _first_visible(page, PASSWORD_INPUTS) is None:
                # a single-provider school redirects on its own; give it a moment
                _await_host(page, GOOGLE_HOST, seconds=10)
        if GOOGLE_HOST in _url(page):
            reached_google = True
            outcome = google_sign_in(page, creds.get("email", ""),
                                     creds.get("password", ""), shots)
            if outcome != "done":
                return _outcome_to_result("canvas", outcome, shots)
            _settle(page, 2500)
        # Back on Canvas — but which Canvas page? The API is the honest test.
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            profile = browser.whoami(context)
            if profile:
                persisted = browser.persist_session_cookies(context)
                config.save({"canvas": {"name": profile.get("name", "")}})
                log.info("canvas: signed in as %s (%d cookie(s) persisted)",
                         profile.get("name"), persisted)
                return LoginResult("canvas", True, "auto",
                                   f"signed in to Canvas as {profile.get('name', '?')}")
            try:
                page.wait_for_timeout(1500)
            except Exception:  # noqa: BLE001
                break
        _shot(page, "canvas-not-signed-in", shots)
        # Say what actually happened. This message used to read "Google
        # finished but Canvas still reports no session" in every case —
        # including when Google was never opened at all, and including the one
        # cause that was really behind it. A wrong explanation sent a day of
        # refreshes chasing a session that could not have been created.
        if ENTERPRISE_WALL.search(_text(page)) or _url(page).startswith("chrome-error"):
            return LoginResult(
                "canvas", False, "failed",
                "the browser itself blocked the sign-in: it is managed by your "
                "school's admin console, which requires you to sign in to "
                "Chrome. SchoolDash can use its own browser instead — that is "
                "what it now does; if you are seeing this, set browser.channel "
                "to \"chromium\" in Settings and try again",
                needs_human=True, detail="enterprise-wall", shots=shots)
        if not reached_google:
            return LoginResult(
                "canvas", False, "failed",
                "Canvas's sign-in page never handed over to Google, so the "
                "saved details were never used (a screenshot was saved under "
                "logs/login-shots)",
                detail="no-google", shots=shots)
        return LoginResult("canvas", False, "failed",
                           "Google finished but Canvas still reports no session "
                           "(a screenshot was saved under logs/login-shots)",
                           shots=shots)
    finally:
        try:
            page.close()
        except Exception:  # noqa: BLE001
            pass


# --------------------------------------------------------------------------
# Veracross


def veracross_landed(url: str) -> bool:
    """Signed in = on the portal itself, not on the accounts host."""
    url = url or ""
    return (bool(url) and VERACROSS_ACCOUNTS not in url and "/login" not in url
            and GOOGLE_HOST not in url and not url.startswith("about:"))


VERACROSS_BAD_LOGIN = re.compile(
    r"invalid|incorrect|does not match|not recognized|could not be found|"
    r"try again", re.I)

# The page after the username step at a Google school. [MEASURED] 2026-09-08,
# headed, real account: submitting the username lands on
# `/brophyprep/portals/login/external?username=…` reading "Your school is
# using Google — Please select the Google account associated with your
# school", with a Google Identity Services button under it.
VERACROSS_GOOGLE_PAGE = re.compile(r"school is using google|select the google account", re.I)

# The GSI button, verified by clicking it. It is rendered by Google's own
# script into the TOP-LEVEL document (there is also a
# `accounts.google.com/gsi/button` iframe, but the clickable element is not
# inside it), as a `div[role="button"]` carrying Google's generated classes —
# `nsm7Bb-HzV7m-LgbsSe …`, which are minified and will change. Its text is
# either "Sign in with Google" or, when Google knows the account,
# "Sign in as <name>", so the stable part is the role plus "Sign in".
# It renders ASYNCHRONOUSLY: at 4s after the username step it was not there
# at all and the whole page held no "Sign in" text, which is why this waits
# for it rather than looking once.
VERACROSS_GOOGLE_BUTTON = ['div[role="button"]:has-text("Sign in")',
                           'div[class*="nsm7Bb-HzV7m-LgbsSe"]',
                           'button:has-text("Sign in with Google")']


def _await_google_button(page, seconds: int = 25):
    """The GSI button once Google's script has drawn it, or None."""
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        found = _first_visible(page, VERACROSS_GOOGLE_BUTTON)
        if found is not None:
            return found
        try:
            page.wait_for_timeout(500)
        except Exception:  # noqa: BLE001
            break
    return _first_visible(page, VERACROSS_GOOGLE_BUTTON)


def veracross(context, shots: list | None = None, capture_feeds: bool = True) -> LoginResult:
    """Make the Veracross portal session in `context` valid, signing in if
    needed, and capture the calendar feed URLs when none are saved yet."""
    shots = shots if shots is not None else []
    cfg = config.load()
    portal = (cfg["veracross"]["portal"] or "").rstrip("/")
    if not portal:
        return LoginResult("veracross", False, "skipped", "no Veracross portal configured")
    page = context.new_page()
    try:
        try:
            page.goto(portal, wait_until="domcontentloaded", timeout=60_000)
        except Exception as exc:  # noqa: BLE001
            return LoginResult("veracross", False, "failed",
                               f"could not open the Veracross portal ({type(exc).__name__})")
        _settle(page)
        if veracross_landed(_url(page)):
            # Write the live session to disk before doing anything else.
            # [MEASURED] 2026-09-06 this is why he had to reconnect "every
            # time": the portal's session cookie is session-only, so it lived
            # in the browser's memory and nowhere else. Every browser exit —
            # a reclaim before a sign-in, a crash, a kill — threw away a
            # session that was working, and the next refresh found a signed-out
            # portal. persist_session_cookies() was called after a fresh
            # sign-in and NOT on this path, which is the path taken whenever
            # the session is fine.
            browser.persist_session_cookies(context)
            result = LoginResult("veracross", True, "already", "Veracross is signed in")
            if capture_feeds:
                _capture_feeds_if_missing(page, portal, result)
            return result

        creds = credentials.veracross_login()
        if not creds or not creds[1]:
            return LoginResult("veracross", False, "skipped",
                               "no saved Veracross sign-in — add it in Settings, "
                               "or sign in by hand", needs_human=True)
        username, password = creds
        entry = credentials.get("veracross") or {}
        google_creds = credentials.get("google") or {}

        deadline = time.monotonic() + STEP_DEADLINE_S
        typed_user = typed_password = clicked_google = False
        while time.monotonic() < deadline:
            url = _url(page)
            if veracross_landed(url):
                break
            if GOOGLE_HOST in url:
                outcome = google_sign_in(page, google_creds.get("email") or username,
                                         google_creds.get("password") or password, shots)
                if outcome != "done":
                    return _outcome_to_result("veracross", outcome, shots)
                _settle(page, 2500)
                continue
            text = _text(page)
            if typed_password and VERACROSS_BAD_LOGIN.search(text):
                _shot(page, "veracross-password", shots)
                return LoginResult("veracross", False, "failed",
                                   "Veracross rejected the saved username or "
                                   "password — update them in Settings",
                                   detail="failed:password", shots=shots)
            if _first_visible(page, ['iframe[src*="recaptcha"][src*="anchor"]:visible',
                                     'div.g-recaptcha:visible']) is not None \
                    and re.search(r"not a robot|verify you are human", text, re.I):
                _shot(page, "veracross-captcha", shots)
                return LoginResult("veracross", False, "human",
                                   "Veracross is showing a CAPTCHA, which only a "
                                   "person can answer", needs_human=True, shots=shots)

            # The Google hand-off, on whichever page offers it.
            #
            # This used to be gated on `not typed_user`, which meant it only
            # ever ran on the FIRST page. At this school the Google button is
            # on the page AFTER the username step ("Your school is using
            # Google"), so once the username had been typed the button was
            # never looked for again: the loop spun to its deadline doing
            # nothing and reported the failure as a stuck Next button — a
            # page that was no longer even on screen. [MEASURED] 2026-09-08:
            # eight identical `veracross-stuck` screenshots, every one of them
            # showing the Google page with a button nobody clicked.
            if entry.get("use_google") and not clicked_google:
                on_google_page = bool(VERACROSS_GOOGLE_PAGE.search(text)
                                      or "/login/external" in url)
                sso = (_await_google_button(page) if on_google_page
                       else _first_visible(page, ['a[href*="google"]',
                                                  'button:has-text("Google")',
                                                  'a:has-text("Google")']))
                if sso is not None and _click(sso):
                    clicked_google = True
                    _settle(page, 2500)
                    continue
                if on_google_page and sso is None:
                    _shot(page, "veracross-google-button", shots)
                    return LoginResult(
                        "veracross", False, "failed",
                        "Veracross handed over to Google but its Google button "
                        "never appeared, so the sign-in could not be finished "
                        "(a screenshot was saved under logs/login-shots)",
                        needs_human=True, detail="no-google-button", shots=shots)

            password_box = _first_visible(page, PASSWORD_INPUTS)
            if password_box is not None and not typed_password:
                if _fill(password_box, password):
                    typed_password = True
                    submit = _first_visible(page, ['input[type="submit"]:not([disabled])',
                                                   'button[type="submit"]:not([disabled])',
                                                   'button:has-text("Log in")',
                                                   'button:has-text("Sign in")'])
                    if submit is None or not _click(submit):
                        try:
                            password_box.press("Enter")
                        except Exception:  # noqa: BLE001
                            pass
                    _settle(page, 2500)
                    continue

            user_box = _first_visible(page, ["#username", 'input[name="username"]',
                                             'input[type="email"]', 'input[type="text"]'])
            if user_box is not None and not typed_user:
                if _fill(user_box, username):
                    typed_user = True
                    # The Next button is disabled until the page's own script
                    # (a reCAPTCHA v3 token) enables it. Waiting for that is
                    # not bypassing anything; clicking a disabled button is.
                    submit = None
                    wait_until = time.monotonic() + 20
                    while time.monotonic() < wait_until and submit is None:
                        submit = _first_visible(page, [
                            'input[type="submit"]:not([disabled])',
                            'button[type="submit"]:not([disabled])'])
                        if submit is None:
                            try:
                                page.wait_for_timeout(400)
                            except Exception:  # noqa: BLE001
                                break
                    if submit is None or not _click(submit):
                        try:
                            user_box.press("Enter")
                        except Exception:  # noqa: BLE001
                            pass
                    _settle(page, 2500)
                    continue

            try:
                page.wait_for_timeout(700)
            except Exception:  # noqa: BLE001
                break

        if not veracross_landed(_url(page)):
            _shot(page, "veracross-stuck", shots)
            # Name the gate when it is the gate. [MEASURED] 2026-09-04: the
            # username is typed correctly and Veracross's Next button
            # (input#recaptcha) is still disabled twenty seconds later —
            # reCAPTCHA v3 scores this headless browser and never enables it.
            # SchoolDash does not click a disabled button and does not answer a
            # CAPTCHA, so this is a step for a person, and the message has to
            # say which step rather than "a page SchoolDash did not recognise".
            #
            # `or typed_user` used to stand here, and it made this the answer
            # to EVERY unfinished Veracross sign-in — the username is typed in
            # all of them. [MEASURED] 2026-09-08: the eight screenshots taken
            # with this message attached all show the page AFTER the gate, with
            # a Google button on it, and the gate itself nowhere on screen. A
            # confident wrong diagnosis cost more than "stuck" would have: it
            # named a robot check as the blocker for two days while the real
            # blocker was an unclicked button. So the gate is now claimed only
            # when the disabled control is genuinely there to be seen.
            gate = _first_visible(page, ['input[type="submit"][disabled]',
                                         'button[type="submit"][disabled]',
                                         "#recaptcha[disabled]"])
            if gate is not None:
                return LoginResult(
                    "veracross", False, "human",
                    "Veracross would not let an automatic sign-in through: its "
                    "Next button stays switched off until the page's own robot "
                    "check is satisfied, and answering that is a person's job. "
                    "SchoolDash will try once more in a real browser window, "
                    "which the check usually accepts",
                    needs_human=True, detail="failed:recaptcha-gate", shots=shots)
            return LoginResult("veracross", False, "failed",
                               "the Veracross sign-in stalled on a page SchoolDash "
                               "did not recognise (a screenshot was saved under "
                               "logs/login-shots)", needs_human=True,
                               detail="failed:stuck", shots=shots)

        # The portal session cookie is session-only; give it the same 30-day
        # life the Canvas one gets so a closed browser does not end it.
        browser.persist_session_cookies(context)
        log.info("veracross: signed in (landed on %s)", re.sub(r"\?.*", "", _url(page))[:100])
        result = LoginResult("veracross", True, "auto", "signed in to Veracross")
        if capture_feeds:
            _capture_feeds_if_missing(page, portal, result)
        return result
    finally:
        try:
            page.close()
        except Exception:  # noqa: BLE001
            pass


def _capture_feeds_if_missing(page, portal: str, result: LoginResult) -> None:
    """Save the class-schedule feed URL if config has none yet. Without it the
    dashboard has no schedule, so a sign-in that forgets this step is not a
    finished sign-in — which is exactly what happened on 2026-08-26."""
    cfg = config.load(refresh=True)
    if cfg["veracross"]["class_ics"]:
        return
    try:
        report = browser.capture_veracross_feeds(page, portal)
    except Exception as exc:  # noqa: BLE001
        report = {"ok": False, "message": f"feed capture failed: {exc}"}
    result.detail = (result.detail + "; " if result.detail else "") + report.get("message", "")
    if not report.get("ok"):
        result.ok = False
        result.how = "failed"
        result.message = ("signed in to Veracross, but the class-schedule feed "
                          "was not found — " + report.get("message", ""))


# --------------------------------------------------------------------------
# orchestration


def _start_url(site: str) -> str:
    cfg = config.load()
    if site == "canvas":
        return cfg["canvas"]["host"].rstrip("/") + "/login"
    return (cfg["veracross"]["portal"] or "").rstrip("/")


def hand_to_human(site: str) -> LoginResult:
    """Open a visible window and wait for the person to finish the sign-in.
    Used when the automatic attempt hit a step it must not take."""
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        try:
            context = browser.open_context(pw, headless=False, reclaim=True)
        except browser.SessionError as exc:
            return LoginResult(site, False, "failed", str(exc), needs_human=True)
        try:
            page = browser.watched_page(context)
            page.goto(_start_url(site), wait_until="domcontentloaded", timeout=60_000)
            if site == "canvas":
                # jump straight to the school-email option when it is offered
                saml = _first_visible(page, ['a[href*="/login/saml"]'])
                if saml is not None:
                    _click(saml)
                done = lambda _p: browser.whoami(context)  # noqa: E731
                label = "Canvas"
            else:
                done = lambda p: veracross_landed(p.url or "")  # noqa: E731
                label = "Veracross"
            try:
                browser.await_login(context, page, done, what=label)
            except browser.LoginCancelled:
                return LoginResult(site, False, "failed",
                                   "the sign-in window was closed before it finished",
                                   needs_human=True)
            except TimeoutError as exc:
                return LoginResult(site, False, "failed", str(exc), needs_human=True)
            browser.persist_session_cookies(context)
            result = LoginResult(site, True, "human", f"signed in to {label} by hand")
            if site == "veracross":
                _capture_feeds_if_missing(browser.watched_page(context),
                                          _start_url(site), result)
            return result
        finally:
            try:
                browser.close_context(context)
            except Exception:  # noqa: BLE001
                pass


def retry_in_a_real_window(site: str) -> LoginResult:
    """Run the SAME automatic sign-in again, in a visible browser.

    Why a second attempt in a different browser is not superstition.
    [MEASURED] 2026-09-08, same profile, same saved details, minutes apart:

        headless   Veracross's Next button still disabled after 20s and 45s;
                   Canvas never reached accounts.google.com at all
        headed     Veracross enabled its own button in 0.0-0.5s and the whole
                   sign-in finished by itself, landing on the student portal;
                   Canvas completed the Google SAML hop and landed signed in

    Playwright's headless mode is `chrome-headless-shell`, a different binary
    from a browser, and both Google's sign-in and Veracross's reCAPTCHA v3
    treat it as such. Nothing here answers a challenge or skips one: the
    reCAPTCHA is satisfied by the page's own script, and the button that gets
    clicked is the button the site enabled. The only change is running in a
    real browser, which is what the student would be using anyway.

    This is deliberately NOT `hand_to_human`: nobody is asked for anything, no
    password is typed by a person, and the window closes on its own. It is the
    difference between "sign in again" and a few seconds of a window appearing
    — which is the whole of what he asked for.
    """
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        try:
            context = browser.open_context(pw, headless=False, reclaim=True)
        except browser.SessionError as exc:
            return LoginResult(site, False, "failed", str(exc), needs_human=True)
        try:
            result = canvas(context) if site == "canvas" else veracross(context)
        except Exception as exc:  # noqa: BLE001 — one site, not the run
            log.exception("%s retry in a real window crashed", site)
            result = LoginResult(site, False, "failed",
                                 credentials.scrub(f"{type(exc).__name__}: {exc}"[:200]),
                                 needs_human=True)
        finally:
            browser.close_context(context)
    if result.ok:
        log.info("%s: the automatic sign-in finished in a real window", site)
        result.detail = (result.detail + "; " if result.detail else "") + "headed-retry"
    return result


def ensure(sites: list[str], allow_human: bool = False, headless: bool = True) -> list[LoginResult]:
    """Sign in to each site in turn with one headless browser; optionally hand
    the ones that need a person to a visible window afterwards."""
    from playwright.sync_api import sync_playwright
    results: list[LoginResult] = []
    with sync_playwright() as pw:
        try:
            context = browser.open_context(pw, headless=headless, reclaim=allow_human)
        except browser.SessionError as exc:
            return [LoginResult(site, False, "failed", str(exc)) for site in sites]
        try:
            for site in sites:
                try:
                    result = canvas(context) if site == "canvas" else veracross(context)
                except Exception as exc:  # noqa: BLE001 — one site, not the run
                    log.exception("%s auto sign-in crashed", site)
                    result = LoginResult(site, False, "failed",
                                         credentials.scrub(f"{type(exc).__name__}: {exc}"[:200]))
                results.append(result)
        finally:
            browser.close_context(context)
    if allow_human:
        for index, result in enumerate(results):
            if result.ok or not result.needs_human:
                continue
            # Try the automatic sign-in once more in a real browser before
            # asking him for anything. Skipped when the attempt stopped for a
            # reason a second browser cannot change: no saved details to use,
            # or a genuine challenge (a two-step prompt, a visible CAPTCHA)
            # that must reach a person rather than be retried at them.
            if result.how != "skipped" and "captcha" not in result.message.lower():
                retried = retry_in_a_real_window(result.site)
                if retried.ok:
                    results[index] = retried
                    continue
                result = retried
            results[index] = hand_to_human(result.site)
    return results
