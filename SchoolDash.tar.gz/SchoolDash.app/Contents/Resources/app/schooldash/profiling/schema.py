"""The single source of truth for the profile shape.

PROFILE_SCHEMA is the JSON Schema handed verbatim to the model (Claude Code's
--json-schema and Ollama's format both take it). validate() is the hand-rolled
runtime validator — no jsonschema dependency — and also enforces the rules a
schema cannot express, like the line-prefix/column-scope separation.
"""

DATE_STYLES = ["day_n", "absolute", "month_heading", "weekday_letter"]
HOMEWORK_SOURCES = ["doc", "canvas", "both", "none"]

PROFILE_SCHEMA = {
    "type": "object",
    "properties": {
        "profile_version": {"type": "integer"},
        "course_key": {"type": "string"},
        "course_raw": {"type": "string"},
        "display_name": {"type": "string"},
        "short_name": {"type": "string"},
        "teacher": {"type": ["string", "null"]},
        "course_type": {"type": "string", "enum": ["academic", "club", "community", "free"]},
        "canvas_course_id": {"type": ["string", "null"]},
        "canvas_url": {"type": ["string", "null"]},
        "meeting": {
            "type": "object",
            "properties": {
                "meets_per_block": {"type": ["integer", "null"]},
                "typical_room": {"type": ["string", "null"]},
                "typical_start": {"type": ["string", "null"]},
                "period": {"type": ["integer", "null"]},
            },
        },
        "homework_source": {"type": "string", "enum": HOMEWORK_SOURCES},
        "verified_zero": {"type": "boolean"},
        "verified_zero_reason": {"type": ["string", "null"]},
        "doc": {
            "type": ["object", "null"],
            "properties": {
                "file_id": {"type": ["string", "null"]},
                "kind": {"type": ["string", "null"]},
                "url": {"type": ["string", "null"]},
                "fingerprint": {"type": ["string", "null"]},
                "fetched_at": {"type": ["string", "null"]},
                "candidates": {"type": "array"},
            },
        },
        "layout": {
            "type": "object",
            "properties": {
                "shape": {"type": ["string", "null"]},
                "date_styles": {
                    "type": "array",
                    "items": {"type": "string", "enum": DATE_STYLES},
                },
                "date_column_headers": {"type": ["array", "null"],
                                        "items": {"type": "string"}},
                "due_column_headers": {"type": ["array", "null"],
                                       "items": {"type": "string"}},
                # Columns whose work is SET at that class and wanted at the
                # next one — "HOMEWORK", "THE WORK". Distinct from
                # due_column_headers, which means due THAT day. [MEASURED]
                # 2026-09-02: conflating the two dated every Honors Algebra
                # item exactly one class early.
                "assigned_column_headers": {"type": ["array", "null"],
                                            "items": {"type": "string"}},
                "skip_column_headers": {"type": ["array", "null"],
                                        "items": {"type": "string"}},
                "block_heading_pattern": {"type": ["string", "null"]},
                "row_is_item": {"type": ["string", "null"]},
                "bullet_split": {"type": "boolean"},
                "snap_absolute_to_meeting": {"type": "boolean"},
                "notes": {"type": ["string", "null"]},
            },
        },
        "line_prefixes": {
            "type": "object",
            "properties": {
                "next_meeting": {"type": ["array", "null"], "items": {"type": "string"}},
                "same_meeting": {"type": ["array", "null"], "items": {"type": "string"}},
                "skip": {"type": ["array", "null"], "items": {"type": "string"}},
            },
        },
        "notation": {"type": "object"},
        "quirks": {"type": "array", "items": {"type": "string"}},
        "expected_items_per_window": {
            "type": ["array", "null"], "items": {"type": "integer"},
            "minItems": 2, "maxItems": 2,
        },
        "observed_items_last_run": {"type": ["integer", "null"]},
        "locked": {"type": "boolean"},
        "learned_at": {"type": ["string", "null"]},
        "learned_by": {"type": ["string", "null"]},
        # True when the profile was copied out of a shipped bundle rather than
        # learned on this machine. See store.seed_missing.
        "seeded_from_bundle": {"type": ["boolean", "null"]},
        "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
    },
    "required": ["course_key", "course_raw", "display_name", "homework_source",
                 "layout", "confidence"],
    "additionalProperties": True,
}

# What the model is asked to produce for one course (a subset — the pipeline
# fills in the mechanical fields itself).
MODEL_OUTPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "layout": PROFILE_SCHEMA["properties"]["layout"],
        "line_prefixes": PROFILE_SCHEMA["properties"]["line_prefixes"],
        "notation": {
            "type": "object",
            "description": "teacher jargon -> meaning, e.g. APCR",
            "additionalProperties": {"type": "string"},
        },
        "quirks": {"type": "array", "items": {"type": "string"}},
        "verified_zero": {"type": "boolean"},
        "verified_zero_reason": {"type": ["string", "null"]},
        "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
    },
    "required": ["layout", "line_prefixes", "quirks", "confidence"],
    "additionalProperties": False,
}


def validate(raw: dict) -> list[str]:
    """Human-readable problems; empty list = valid."""
    errors: list[str] = []
    if not isinstance(raw, dict):
        return ["profile is not a JSON object"]
    for key in PROFILE_SCHEMA["required"]:
        if key not in raw:
            errors.append(f"missing required field: {key}")
    if raw.get("homework_source") not in HOMEWORK_SOURCES:
        errors.append(f"homework_source must be one of {HOMEWORK_SOURCES}")
    layout = raw.get("layout") or {}
    for style in layout.get("date_styles") or []:
        if style not in DATE_STYLES:
            errors.append(f"unknown date style: {style}")
    confidence = raw.get("confidence")
    if not isinstance(confidence, (int, float)) or not 0.0 <= confidence <= 1.0:
        errors.append("confidence must be a float 0.0–1.0 "
                      "(items use high/medium/low; profiles use a float — "
                      "the two vocabularies never mix)")

    # The line-prefix / column-scope separation (spec §9.1): a skip PREFIX that
    # is a substring of a due COLUMN header would silence that column — exactly
    # the IN CLASS/HOMEWORK bug. Case-insensitive raw substring: 'Plan:' is not
    # inside 'What is the Plan?' (the colon matters), but 'Plan' is.
    # A header may name exactly one role. Nothing stopped a profile — including
    # one a model writes during a relearn on a classmate's Mac — from listing
    # the same column as both due and assigned, and the reader resolved that
    # tie silently. "Due that day" and "set that day, due next" are a whole
    # class meeting apart; a profile asserting both is wrong, not ambiguous,
    # and must not reach the extractor (COUNT 27).
    role_lists = (("due_column_headers", layout.get("due_column_headers") or []),
                  ("assigned_column_headers",
                   layout.get("assigned_column_headers") or []),
                  ("skip_column_headers", layout.get("skip_column_headers") or []),
                  ("date_column_headers", layout.get("date_column_headers") or []))
    for i, (first_name, first) in enumerate(role_lists):
        for second_name, second in role_lists[i + 1:]:
            shared = sorted({h.strip().lower() for h in first}
                            & {h.strip().lower() for h in second})
            for header in shared:
                original = next((h for h in first
                                 if h.strip().lower() == header), header)
                errors.append(
                    f"column header {original!r} is in both {first_name} and "
                    f"{second_name} — one header, one role: they mean dates a "
                    "class meeting apart, so pick the one the column really is")

    prefixes = raw.get("line_prefixes") or {}
    due_headers = ((layout.get("due_column_headers") or [])
                   + (layout.get("assigned_column_headers") or []))
    for prefix in prefixes.get("skip") or []:
        for header in due_headers:
            if prefix.strip().lower() in header.lower():
                errors.append(
                    f"line_prefixes.skip entry {prefix!r} appears inside due "
                    f"column header {header!r} — a line prefix must never act "
                    "as a column rule; rename one of them")
    return errors
