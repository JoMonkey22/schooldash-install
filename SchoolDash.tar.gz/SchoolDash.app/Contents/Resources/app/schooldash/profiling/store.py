"""Read/write/validate class profiles. Profiles are DATA (data/profiles/);
this module is code. A profile that fails validation is refused with a clear
message, never silently patched. Saves rotate the prior version into
data/profiles/.history so a bad relearn is reversible.
"""

import json
import time
from pathlib import Path

from schooldash import paths
from schooldash.logging_setup import get
from schooldash.models import Profile
from schooldash.profiling import schema

log = get("profiles")


class ProfileError(RuntimeError):
    pass


def _directory(directory: Path | None = None) -> Path:
    return Path(directory) if directory else paths.profiles_dir()


def load_one(path: Path) -> Profile:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except ValueError as exc:
        raise ProfileError(f"{path.name} is not valid JSON: {exc}") from exc
    errors = schema.validate(raw)
    if errors:
        raise ProfileError(f"{path.name} refused:\n  - " + "\n  - ".join(errors))
    return Profile(course_key=raw["course_key"], raw=raw)


def load_all(directory: Path | None = None) -> tuple[dict[str, Profile], list[str]]:
    """{course_key: Profile}, problems. A broken profile is reported, never
    silently skipped."""
    directory = _directory(directory)
    profiles: dict[str, Profile] = {}
    problems: list[str] = []
    if not directory.exists():
        return profiles, problems
    for path in sorted(directory.glob("*.json")):
        try:
            profile = load_one(path)
        except ProfileError as exc:
            problems.append(str(exc))
            continue
        profiles[profile.course_key] = profile
    return profiles, problems


def save(raw: dict, directory: Path | None = None) -> Path:
    errors = schema.validate(raw)
    if errors:
        raise ProfileError("refusing to save an invalid profile:\n  - "
                           + "\n  - ".join(errors))
    directory = _directory(directory)
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / f"{raw['course_key']}.json"
    if path.exists():
        history = directory / ".history"
        history.mkdir(exist_ok=True)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        (history / f"{raw['course_key']}-{stamp}.json").write_text(
            path.read_text(encoding="utf-8"), encoding="utf-8")
    path.write_text(json.dumps(raw, indent=2, ensure_ascii=False), encoding="utf-8")
    log.info("profile saved: %s", path.name)
    return path


def seed_missing(source: Path | None = None,
                 directory: Path | None = None,
                 allowed_keys=None) -> tuple[list[str], list[str]]:
    """Copy shipped starter profiles in for courses that have none yet.

    A profile describes the *teacher's doc* — its table shape, how that
    teacher writes dates, the quirks — so it is the same for everyone in the
    class. Shipping the ones already learned is what lets a new person get
    their doc homework without an AI provider of their own: heuristics read
    table-shaped docs fine but produce almost nothing for prose-shaped ones.

    `allowed_keys` is the set of courses this person is actually in. Without
    it every shipped profile was copied in regardless, and since stage 3 of
    the pipeline is profile-driven, a classmate's dashboard filled up with the
    courses — and the homework — of whoever built the bundle. [MEASURED]
    2026-08-28: a classmate saw their own grades beside the first user's 13 classes.
    Pass the person's own enrolment (class feed + Canvas homepages); pass None
    only when enrolment genuinely is not known yet.

    Never overwrites: an existing profile is the user's own, possibly
    hand-edited and locked. Returns (seeded keys, problems).
    """
    source = Path(source) if source else paths.project_root() / "seed-profiles"
    directory = _directory(directory)
    seeded: list[str] = []
    problems: list[str] = []
    if not source.exists():
        return seeded, problems
    directory.mkdir(parents=True, exist_ok=True)
    for path in sorted(source.glob("*.json")):
        target = directory / path.name
        if target.exists():
            continue
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            errors = schema.validate(raw)
            if errors:
                raise ProfileError(f"{path.name} refused:\n  - "
                                   + "\n  - ".join(errors))
        except (ValueError, ProfileError) as exc:
            problems.append(f"starter profile {path.name}: {exc}")
            continue
        if allowed_keys is not None and raw.get("course_key") not in allowed_keys:
            continue
        # counts from whoever's machine learned it say nothing about this one
        raw["observed_items_last_run"] = None
        raw["locked"] = False
        # Marks it as arriving from the bundle rather than being learned here.
        # The pipeline uses this to refuse to fetch a stranger's course doc on
        # an install that was already seeded too widely — a user's own profile
        # is never suppressed, only one that came from someone else's machine.
        raw["seeded_from_bundle"] = True
        target.write_text(json.dumps(raw, indent=2, ensure_ascii=False),
                          encoding="utf-8")
        seeded.append(raw["course_key"])
    if seeded:
        log.info("seeded %d starter profile(s): %s", len(seeded), ", ".join(seeded))
    return seeded, problems


def cli_profiles() -> int:
    profiles, problems = load_all()
    if not profiles and not problems:
        print("no profiles yet — run: python run.py setup --profile-all")
        return 0
    print(f"{'COURSE':<42} {'HOMEWORK':<8} {'DATE STYLES':<24} {'CONF':<5} LOCKED")
    for key, profile in sorted(profiles.items()):
        styles = ",".join(profile.get("layout", "date_styles", default=[]) or []) or "—"
        locked = "yes" if profile.get("locked") else ""
        zero = ""
        if profile.get("verified_zero"):
            zero = f"  (verified zero: {profile.get('verified_zero_reason') or '?'})"
        print(f"{profile.get('display_name') or key:<42} "
              f"{profile.get('homework_source'):<8} {styles:<24} "
              f"{profile.get('confidence'):<5} {locked}{zero}")
    for problem in problems:
        print(f"  ! {problem}")
    return 0
