"""The JSON + SSE API (spec §11). Real status codes; on failure the body is
{"error": {"code", "message", "fix"}} where fix is the one line the student can act
on. Refresh is non-blocking: a background thread, a lock so two can't overlap,
SSE progress, and the previous cache keeps serving meanwhile."""

import json
import threading
import time
import subprocess
import sys
import uuid
from flask import Blueprint, Response, jsonify, request

from schooldash import config, db, paths, pipeline, timezones
from schooldash.logging_setup import get, last_error_lines

log = get("api")
api = Blueprint("api", __name__)

_refresh_lock = threading.Lock()
_runs: dict[str, dict] = {}
_chat_turns: dict[str, dict] = {}


def _error(code: str, message: str, fix: str, status: int = 400):
    return jsonify({"error": {"code": code, "message": message,
                              "fix": paths.runnable(fix)}}), status


# Endpoints reachable before signing in: the gate itself, and the health probe
# the port check uses to tell "SchoolDash is already serving" from "something
# else has this port".
_OPEN_ENDPOINTS = {"api.get_session", "api.post_session", "api.delete_session",
                   # The Chrome bridge carries its own token instead. An
                   # extension has no account and cannot have one; see the
                   # bridge section below.
                   "api.post_bridge_capture", "api.get_bridge_status",
                   "api.get_health", "api.post_session_refresh",
                   "api.post_session_redeem",
                   # first-run setup happens before anyone has an account
                   "api.get_setup_status", "api.post_setup_mark",
                   "api.get_credentials", "api.put_credentials",
                   "api.delete_credentials", "api.post_login", "api.get_login",
                   "api.post_setup_learn", "api.post_setup_reminders",
                   "api.get_job", "api.post_courses_detect", "api.get_courses",
                   "api.get_course", "api.put_course", "api.post_material",
                   "api.delete_material", "api.get_textbook_search"}
# Deliberately NOT open: /api/state, /api/refresh, chat. The board itself stays
# behind the account gate when one is configured; only the setup wizard's own
# calls run before an account exists.


@api.before_request
def _require_account():
    """The account gate. Off entirely when no account server is configured, so
    a solo install is unaffected."""
    from schooldash import account
    if request.method == "OPTIONS" or request.endpoint in _OPEN_ENDPOINTS:
        return None
    if not account.required():
        return None
    if account.current() is None:
        return _error("signed_out", "sign in to use SchoolDash",
                      "sign in on the dashboard", 401)
    # Signed in but not paid up. A separate status from 401 on purpose: the page
    # must not throw someone back to a login form they have already completed.
    #
    # Deliberately fail-open in one direction only — the entitlement is read
    # from the cached, server-signed token, so a dead network keeps a paid-up
    # student working (which is the point of caching it) while a lapsed one
    # stays lapsed.
    if not account.entitled():
        sub = account.subscription()
        price = sub.get("price") or {}
        return _error(
            "subscription_needed",
            f"Your SchoolDash trial has ended. It is "
            f"${price.get('amount', '5.99')} a month to keep using it.",
            "open the dashboard to see how to subscribe", 402)
    return None


@api.get("/session")
def get_session():
    from schooldash import account
    return jsonify(account.status())


@api.post("/session")
def post_session():
    from schooldash import account
    body = request.get_json(silent=True) or {}
    email = (body.get("email") or "").strip()
    password = body.get("password") or ""
    if not email or not password:
        return _error("bad_request", "email and password are required",
                      "fill both boxes", 400)
    action = account.sign_up if body.get("create") else account.sign_in
    try:
        session = action(email, password)
    except account.AccountError as exc:
        status = 401 if exc.code == "bad_credentials" else 400
        if exc.code in ("offline", "server_error"):
            status = 503
        if exc.code == "too_many_attempts":
            status = 429
        return _error(exc.code, str(exc), "check the details and try again",
                      status)
    return jsonify({"email": session["email"], "signed_in": True})


@api.delete("/session")
def delete_session():
    from schooldash import account
    account.sign_out()
    return jsonify({"signed_in": False})


_asset_version_cache: dict = {"key": None, "value": ""}


def _asset_version() -> str:
    """A short digest of the front-end assets, recomputed only when they change.

    Keyed on (size, mtime) rather than content so a page load never re-hashes
    the files; the digest itself is what makes a changed byte visible.
    """
    import hashlib

    static = paths.project_root() / "schooldash" / "web" / "static"
    files = [f for f in (static / "app.js", static / "app.css", static / "views.js")
             if f.exists()]
    if not files:
        return ""
    try:
        key = tuple((f.stat().st_size, f.stat().st_mtime_ns) for f in files)
    except OSError:
        return ""
    if _asset_version_cache["key"] != key:
        digest = hashlib.sha1()
        for f in files:
            try:
                digest.update(f.read_bytes())
            except OSError:
                return ""
        _asset_version_cache["key"] = key
        _asset_version_cache["value"] = digest.hexdigest()[:12]
    return _asset_version_cache["value"]


def _overlay_done(state: dict) -> dict:  # kept for callers inside this module
    overlaid = pipeline.load_state_overlaid()
    return overlaid if overlaid is not None else state


@api.get("/state")
def get_state():
    state = pipeline.load_state()
    if not state:
        return jsonify({"empty": True,
                        "message": "no data yet — press Refresh (the first "
                                   "pull takes ~10–20 seconds)",
                        "items": [], "meetings_today": [], "profiles": [],
                        "warnings": [], "errors": [], "diagnostics": {}})
    state = _overlay_done(state)
    cfg = config.load()
    state["stale_after_hours"] = cfg["server"]["stale_after_hours"]
    state["now"] = timezones.to_local(
        __import__("datetime").datetime.now(timezones.zone())).isoformat()
    state["low_priority"] = cfg["scoring"]["low_priority"]
    try:
        from schooldash.ai import detect
        state["provider"] = detect.describe()[0]
        # Not just the name: whether it is the one that was asked for. A silent
        # demotion is a real drop in answer quality and belongs on screen.
        state["provider_status"] = detect.status("chat")
    except Exception:  # noqa: BLE001
        state["provider"] = "unknown"
        state["provider_status"] = {"active": "unknown", "degraded": True,
                                    "configured": "unknown", "skipped": [],
                                    "model": ""}
    # Which build is being served. A page open since this morning has no way to
    # know the app changed underneath it: it keeps rendering the JS it loaded,
    # so new features are simply absent and — worse — the numbers on screen are
    # whatever was true when the tab was opened. [MEASURED] 2026-09-01: a tab
    # open since 10:14 still showed 93.90% while the data said 92.33%, and the
    # clickable grades added in between were not there at all. The page compares
    # this against the value it first saw and offers a reload.
    state["app_version"] = _asset_version()
    try:
        from schooldash import account
        state["subscription"] = account.subscription()
    except Exception:  # noqa: BLE001 — the board must render regardless
        state["subscription"] = {}
    # What is left of this month's allowance. Sent even when nothing is
    # metered, with `metered: false`, so Settings can say "not limited"
    # instead of showing a bar that means nothing.
    try:
        from schooldash import allowance
        state["allowance"] = allowance.status()
    except Exception:  # noqa: BLE001 — never the board
        state["allowance"] = {}
    # What the Chrome bridge is holding, for Settings. Account-gated with the
    # rest of the page; the extension has its own token-gated route. Its own
    # try, not shared with the allowance above: one of these failing must not
    # blank the other, which is the same lesson as render()'s fault isolation.
    try:
        from schooldash import bridge
        state["bridge"] = bridge.status()
    except Exception:  # noqa: BLE001
        state["bridge"] = {}
    # Where a grade came from, so clicking one can open it at the source.
    state["veracross_portal"] = (cfg.get("veracross") or {}).get("portal") or ""
    state["last_errors"] = last_error_lines(5)
    return jsonify(state)


# A sign-in the student can start with a tap.
#
# Why this exists: every session error told them to paste a command. Once the
# command named the real interpreter it became ~150 characters with two quoted
# paths, and pasting that into Terminal is exactly what failed in practice —
# it wraps, bash receives a fragment, and the answer is "command not found".
# Handing a terminal-averse teenager a long command was never the right shape.
# The server already spawns browsers for refresh, so it can spawn this one.
#
# This does not automate a login: it opens the sign-in window and the person
# (or the browser's existing Google session) completes it. No password is
# requested, handled, or stored — spec §5.1 is intact.
_login_lock = threading.Lock()
_logins: dict = {}

LOGIN_KINDS = {
    "canvas": ([], "Canvas"),
    "veracross": (["--veracross"], "Veracross"),
    "all": (["--all"], "Canvas and Veracross"),
}


@api.post("/login")
def post_login():
    body = request.get_json(silent=True) or {}
    kind = (body.get("kind") or "canvas").lower()
    if kind not in LOGIN_KINDS:
        return _error("bad_request", f"unknown sign-in {kind!r}",
                      "ask for canvas, veracross or all", 400)
    extra, label = LOGIN_KINDS[kind]
    # `auto`: use the details saved in Settings (schooldash/autologin.py) and
    # only open a window if a step needs a person. The subprocess ends with a
    # JSON line describing each site's outcome, which the page renders.
    auto = bool(body.get("auto")) or kind == "all"
    if auto:
        extra = [*extra, "--auto", "--json"]

    if not _login_lock.acquire(blocking=False):
        # Pressing again is what someone does when nothing appeared to happen,
        # so it must DO something: lift the window that is already open, and
        # name it. [MEASURED] 2026-09-06 he pressed it repeatedly while a
        # sign-in window sat behind the app window, unraised because the
        # activate call named an application that does not exist.
        from schooldash import browser
        window = "the browser"
        try:
            window = browser.expected_app_name()
            browser.raise_app(window)
        except Exception as exc:  # noqa: BLE001 — cosmetic
            log.debug("could not raise the sign-in window: %s", exc)
        running = next((jid for jid, rec in _logins.items() if not rec["done"]), None)
        return jsonify({"started": False, "already_running": True,
                        "job_id": running, "window": window,
                        "message": f"the sign-in window is already open — it is "
                                   f"called \u201c{window}\u201d. Finish signing "
                                   f"in there and this page will notice."}), 202
    job_id = uuid.uuid4().hex[:12]
    record = {"done": False, "ok": None, "output": "", "label": label,
              "results": [], "auto": auto, "started": time.time()}
    # Same pruning as the job table, for the same reason.
    for stale in sorted((r.get("started", 0), jid) for jid, r in _logins.items()
                        if r["done"])[:-4]:
        _logins.pop(stale[1], None)
    _logins[job_id] = record

    # A list, not a shell string: the paths contain spaces, and the whole point
    # is that nobody has to quote them by hand.
    command = [sys.executable, str(paths.project_root() / "run.py"), "login",
               *extra]

    def work():
        try:
            done = subprocess.run(command, capture_output=True, text=True,
                                  timeout=2400, shell=False)
            stdout = done.stdout or ""
            for line in stdout.splitlines():
                if line.startswith("JSON:"):
                    try:
                        record["results"] = json.loads(line[5:])
                    except ValueError:
                        pass
            record["output"] = "\n".join(l for l in stdout.splitlines()
                                         if not l.startswith("JSON:"))[-800:]
            record["ok"] = done.returncode == 0
            log.info("%s sign-in finished rc=%s", label, done.returncode)
        except Exception as exc:  # noqa: BLE001 — surface, never a dead thread
            log.exception("%s sign-in failed", label)
            record["output"] = str(exc)
            record["ok"] = False
        finally:
            record["done"] = True
            _login_lock.release()

    threading.Thread(target=work, daemon=True).start()
    try:
        from schooldash import browser
        window = browser.expected_app_name()
    except Exception:  # noqa: BLE001
        window = "the browser"
    return jsonify({"started": True, "job_id": job_id, "label": label,
                    "window": window,
                    "message": f"Signing in to {label}. If a window opens it is "
                               f"called \u201c{window}\u201d — finish there."})


@api.get("/login/<job_id>")
def get_login(job_id):
    record = _logins.get(job_id)
    if not record:
        return _error("no_such_job", "that sign-in is not running",
                      "start it again", 404)
    return jsonify({"done": record["done"], "ok": record["ok"],
                    "label": record["label"], "auto": record.get("auto", False),
                    "results": record.get("results") or [],
                    "output": record["output"] if record["done"] else ""})


@api.post("/session/refresh")
def post_session_refresh():
    """Re-ask the account server where this subscription stands.

    Open to the gate on purpose: the person calling it is signed in and locked
    out, and this is the one action that can unlock them. Without it a payment
    would not register until the cached 30-day token expired.
    """
    from schooldash import account
    return jsonify({"subscription": account.refresh_subscription()})


@api.post("/session/redeem")
def post_session_redeem():
    """Redeem a free-access code. Open to the gate, like the refresh above: the
    caller is signed in and locked out, and this is one of the two things that
    can unlock them."""
    from schooldash import account
    code = ((request.get_json(silent=True) or {}).get("code") or "").strip()
    if not code:
        return _error("bad_request", "type the code first", "", 400)
    try:
        return jsonify(account.redeem(code))
    except account.AccountError as exc:
        status = 429 if exc.code == "too_many_attempts" else 400
        return _error(exc.code, str(exc), "", status)


@api.post("/refresh")
def post_refresh():
    # Providers are cached for the life of the process, so fixing config.json
    # used to need a restart nobody knew to perform. Refresh is the one button
    # a person already presses when something looks wrong.
    try:
        from schooldash.ai import detect
        detect.reset_cache()
    except Exception:  # noqa: BLE001 — never block a refresh over this
        pass
    if not _refresh_lock.acquire(blocking=False):
        running = next((rid for rid, r in _runs.items() if not r["done"]), None)
        return _error("refresh_running", "a refresh is already running",
                      "wait for it to finish", 409) if not running else (
            jsonify({"run_id": running, "already_running": True}), 202)
    run_id = uuid.uuid4().hex[:12]
    record = {"events": [], "done": False}
    _runs[run_id] = record

    body = request.get_json(silent=True) or {}

    def emit(stage, message, level, course):
        record["events"].append({"stage": stage, "message": message,
                                 "level": level, "course": course})

    def work():
        try:
            pipeline.refresh(pipeline.RefreshOptions(
                docs_only=bool(body.get("docs_only")),
                # `.get(key)` with no default reads a MISSING key as False,
                # which quietly turned this off for every refresh the app's
                # own button makes — it posts "{}". [MEASURED] 2026-09-03:
                # AI Frontiers and Spanish 1 keep their homework in private
                # Google Docs, so pressing Refresh in the app read less than
                # `run.py refresh` did and both classes lost their doc items
                # without anything on screen saying so. The dataclass default
                # is True; only an explicit false may turn it off.
                include_private_docs=bool(body.get("include_private_docs", True)),
                emit=emit))
        except pipeline.AlreadyRunning as busy:
            # Another PROCESS holds the browser profile — the scheduled
            # refresh, a terminal, or a second copy of the app. _refresh_lock
            # above only sees this process, which is COUNT 24. This is a fact
            # about timing, not a failure worth a stack trace or a red banner.
            log.info("refresh skipped: %s", busy)
            record["events"].append({
                "stage": "refresh",
                "message": f"a refresh is already running ({busy.holder or 'another window'}) "
                           "— nothing was changed. Try again when it finishes.",
                "level": "warning", "course": None})
        except Exception as exc:  # noqa: BLE001 — surface, never a dead thread
            log.exception("refresh failed")
            record["events"].append({"stage": "error", "message": str(exc),
                                     "level": "error", "course": None})
        finally:
            record["done"] = True
            _refresh_lock.release()

    threading.Thread(target=work, daemon=True).start()
    return jsonify({"run_id": run_id})


@api.get("/refresh/<run_id>/events")
def refresh_events(run_id):
    record = _runs.get(run_id)
    if not record:
        return _error("no_such_run", f"unknown run {run_id}", "start a refresh", 404)

    def stream():
        sent = 0
        while True:
            while sent < len(record["events"]):
                yield f"data: {json.dumps(record['events'][sent])}\n\n"
                sent += 1
            if record["done"]:
                yield 'data: {"stage": "done"}\n\n'
                return
            time.sleep(0.3)

    return Response(stream(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-store"})


@api.get("/runs")
def get_runs():
    conn = db.connect()
    runs = db.list_runs(conn)
    conn.close()
    return jsonify({"runs": runs})


@api.post("/discover")
def post_discover():
    import contextlib
    import io
    from schooldash.docs import discover
    buffer = io.StringIO()
    try:
        with contextlib.redirect_stdout(buffer):
            code = discover.cli_discover()
    except Exception as exc:  # noqa: BLE001
        return _error("discover_failed", str(exc), "python run.py login", 502)
    return jsonify({"ok": code == 0, "report": buffer.getvalue()})


@api.post("/done")
def post_done():
    body = request.get_json(silent=True) or {}
    item_id = body.get("item_id")
    if not item_id:
        return _error("bad_request", "item_id is required", "pass item_id", 400)
    conn = db.connect()
    db.set_done(conn, item_id, bool(body.get("done", True)))
    conn.close()
    return jsonify({"ok": True, "item_id": item_id,
                    "done": bool(body.get("done", True))})


@api.post("/tasks")
def post_task():
    from schooldash import tasks as tasks_mod
    body = request.get_json(silent=True) or {}
    title = (body.get("title") or "").strip()
    if not title:
        return _error("bad_request", "title is required", "give the task a name", 400)
    conn = db.connect()
    try:
        stored = tasks_mod.add(conn, title=title,
                               due_date=tasks_mod.normalize_due(body.get("due_date")),
                               course=body.get("course"),
                               section=body.get("section"),
                               notes=body.get("notes"),
                               category=body.get("category"))
    finally:
        conn.close()
    return jsonify({"ok": True, "task": stored})


@api.delete("/tasks/<item_id>")
def delete_task(item_id):
    conn = db.connect()
    removed = db.archive_custom_task(conn, item_id)
    db.set_done(conn, item_id, False)
    conn.close()
    if not removed:
        return _error("no_such_task", f"no custom task {item_id}",
                      "only tasks you added can be removed", 404)
    return jsonify({"ok": True})


@api.get("/profiles")
def get_profiles():
    from schooldash.profiling import store
    profiles, problems = store.load_all()
    return jsonify({"profiles": [p.raw for p in profiles.values()],
                    "problems": problems})


@api.get("/profiles/<course_key>")
def get_profile(course_key):
    from schooldash.profiling import store
    profiles, _ = store.load_all()
    if course_key not in profiles:
        return _error("no_such_profile", f"no profile for {course_key}",
                      "python run.py setup --profile-all", 404)
    return jsonify(profiles[course_key].raw)


@api.put("/profiles/<course_key>")
def put_profile(course_key):
    from schooldash.profiling import schema, store
    raw = request.get_json(silent=True)
    if not isinstance(raw, dict):
        return _error("bad_json", "the body must be the profile JSON object",
                      "fix the JSON", 400)
    raw["course_key"] = course_key
    raw["locked"] = True   # a hand edit is never overwritten automatically
    errors = schema.validate(raw)
    if errors:
        return _error("invalid_profile", "; ".join(errors),
                      "fix the listed fields", 422)
    store.save(raw)
    return jsonify({"ok": True, "locked": True})


@api.post("/profiles/<course_key>/relearn")
def relearn_profile(course_key):
    import contextlib
    import io
    from schooldash.profiling import builder
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        code = builder.cli_profile(course=course_key, relearn=True)
    return jsonify({"ok": code == 0, "report": buffer.getvalue()})


@api.get("/item/<item_id>")
def get_item(item_id):
    state = pipeline.load_state()
    if not state:
        return _error("no_state", "no cached state", "python run.py refresh", 404)
    matches = [i for i in state["items"] if i["item_id"] == item_id]
    if not matches:
        return _error("no_such_item", f"no item {item_id} in the last refresh",
                      "refresh and retry", 404)
    return jsonify(matches[0])


@api.get("/health")
def get_health():
    """Cache-only — no network calls, ever. session_valid is the cached verdict
    from the last run; session_checked_at says when that was."""
    state = pipeline.load_state() or {}
    stale_hours = None
    if state.get("generated_at"):
        generated = timezones.to_local(state["generated_at"])
        now = __import__("datetime").datetime.now(timezones.zone())
        stale_hours = round((now - generated).total_seconds() / 3600, 1)
    try:
        from schooldash.ai import detect
        provider = detect.describe()[0]
    except Exception:  # noqa: BLE001
        provider = "unknown"
    from schooldash import __version__
    return jsonify({
        "ok": bool(state) and not state.get("errors"),
        "provider": provider,
        "session_valid": state.get("session_ok"),
        "session_checked_at": state.get("generated_at"),
        "last_run": (state.get("last_run") or {}).get("started"),
        "stale_hours": stale_hours,
        "warnings": state.get("warnings", []),
        "version": __version__,
    })


# ---- first-run setup ---------------------------------------------------------

@api.get("/setup/status")
def get_setup_status():
    """Where setup stands. Disk-only, so the setup page can poll it."""
    from schooldash import onboarding
    return jsonify(onboarding.status())


@api.post("/setup/mark")
def post_setup_mark():
    from schooldash import onboarding
    body = request.get_json(silent=True) or {}
    key = (body.get("key") or "").strip()
    if key not in ("completed_at", "skipped_accounts", "classes_seen"):
        return _error("bad_request", f"unknown setup milestone {key!r}", "", 400)
    return jsonify(onboarding.mark(key, body.get("value", True)))


@api.post("/setup/learn")
def post_setup_learn():
    """Learn the class profiles that do not exist yet, as a job.

    Calls builder.learn_missing, which takes an `emit` callback — the older
    path redirected sys.stdout, which is process-wide and would have captured
    every other thread's output for the minutes a learn takes.
    """
    def work(say):
        from schooldash.profiling import builder
        return builder.learn_missing(emit=say)
    return jsonify(_start_job("learn", work))


@api.post("/setup/reminders")
def post_setup_reminders():
    """Install the launchd agents: reminders at 07:00/17:00, the half-hourly
    refresh, and the Veracross keep-alive."""
    import contextlib
    import io
    if sys.platform != "darwin":
        return _error("not_mac", "reminders are a macOS feature", "", 400)
    from schooldash import schedule_mac
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        code = schedule_mac.install()
    lines = [l for l in buffer.getvalue().splitlines() if l.strip()]
    return jsonify({"ok": code == 0, "message": lines[0] if lines else "scheduled",
                    "report": buffer.getvalue()})


# ---- saved sign-ins ------------------------------------------------------------
#
# The details SchoolDash signs back in with (schooldash/credentials.py). GET
# returns presence and usernames only; the secret itself never travels back to
# the page. PUT stores; DELETE forgets.

@api.get("/credentials")
def get_credentials():
    from schooldash import credentials
    return jsonify({"credentials": credentials.status()})


@api.put("/credentials")
def put_credentials():
    from schooldash import credentials
    body = request.get_json(silent=True) or {}
    saved = {}
    try:
        google = body.get("google")
        if isinstance(google, dict):
            saved["google"] = credentials.set(
                "google", email=google.get("email", ""),
                password=google.get("password", ""))
        veracross = body.get("veracross")
        if isinstance(veracross, dict):
            saved["veracross"] = credentials.set(
                "veracross", username=veracross.get("username", ""),
                password=veracross.get("password", ""),
                use_google=bool(veracross.get("use_google")))
    except ValueError as exc:
        return _error("bad_request", str(exc), "", 400)
    return jsonify({"saved": saved, "credentials": credentials.status()})


@api.delete("/credentials")
def delete_credentials():
    from schooldash import credentials
    site = request.args.get("site") or None
    credentials.clear(site)
    return jsonify({"credentials": credentials.status()})


# ---- background jobs -----------------------------------------------------------
#
# Scanning every course or learning a profile takes tens of seconds and must
# not hold an HTTP request open. One small job table: start returns an id, the
# page polls for progress lines and the final result.

# Background jobs, at most one at a time PER KIND.
#
# [PROVEN] tests/test_prosecution.py: a single shared lock refused an
# ⚡ Accelerate whenever a class scan was running — and refused it with the
# SCAN's job id. The page polls whatever id it is handed and renders the result
# as its own, so a course-detection result would have been drawn into the study
# guide panel. Two unrelated features must not share one lock or one id space.
_jobs: dict[str, dict] = {}
_job_locks: dict[str, threading.Lock] = {}
_jobs_guard = threading.Lock()

# Finished jobs are remembered so a page that polls a moment late still gets its
# result — but not forever. The server runs for weeks and an Accelerate result
# is a whole study guide; [PROVEN] nothing ever pruned this table.
MAX_REMEMBERED_JOBS = 24


def _prune_jobs() -> None:
    """Drop the oldest FINISHED jobs once the table is over its cap. A running
    job is never dropped, whatever its age."""
    finished = sorted((record["started"], job_id)
                      for job_id, record in _jobs.items() if record["done"])
    while len(_jobs) > MAX_REMEMBERED_JOBS and finished:
        _, job_id = finished.pop(0)
        _jobs.pop(job_id, None)


def _start_job(kind: str, work) -> dict:
    """Run `work(say)` on a thread; `say(line)` appends a progress line."""
    with _jobs_guard:
        lock = _job_locks.setdefault(kind, threading.Lock())
    if not lock.acquire(blocking=False):
        running = next((job_id for job_id, record in _jobs.items()
                        if record["kind"] == kind and not record["done"]), None)
        return {"started": False, "job_id": running, "kind": kind,
                "already_running": True}
    job_id = uuid.uuid4().hex[:12]
    record = {"kind": kind, "done": False, "ok": None, "lines": [], "result": None,
              "error": None, "started": time.time()}
    with _jobs_guard:
        _jobs[job_id] = record
        _prune_jobs()

    def say(line):
        record["lines"].append(str(line))

    def run():
        try:
            record["result"] = work(say)
            record["ok"] = True
        except Exception as exc:  # noqa: BLE001 — surface, never a dead thread
            log.exception("%s job failed", kind)
            record["error"] = str(exc)[:300]
            record["ok"] = False
        finally:
            record["done"] = True
            lock.release()
    threading.Thread(target=run, daemon=True).start()
    return {"started": True, "job_id": job_id, "kind": kind}


@api.get("/jobs/<job_id>")
def get_job(job_id):
    record = _jobs.get(job_id)
    if not record:
        # Either it never existed or it finished long enough ago to have been
        # pruned. The page needs to tell those apart from "still working".
        return _error("no_such_job", "that job is not running any more",
                      "start it again", 404)
    return jsonify({"kind": record["kind"], "done": record["done"], "ok": record["ok"],
                    "lines": record["lines"], "result": record["result"] if record["done"] else None,
                    "error": record["error"]})


# ---- classes: materials, notes, textbooks --------------------------------------

@api.get("/courses")
def get_courses():
    """Every class on file, each flagged with whether it is running now.

    The flag is computed here rather than in the page because it needs the
    class feed: the current session is READ from the courses that actually
    have meetings this week (courses.current_sessions), never guessed from
    the month. The page still receives the others — a list that quietly drops
    a class would be exactly the silent hiding the spec forbids — and shows
    them behind one line saying how many and from when.
    """
    from schooldash import courses
    records = courses.load_all()
    live = set()
    try:
        state = pipeline.load_state() or {}
        for meetings in (state.get("schedule") or {}).values():
            for meeting in meetings or []:
                if meeting.get("course_key"):
                    live.add(meeting["course_key"])
    except Exception as exc:  # noqa: BLE001 — a missing feed is not an error here
        log.debug("no schedule to date the terms from: %s", exc)
    sessions = courses.current_sessions(records, live)
    for record in records.values():
        record["current"] = courses.is_current(record, sessions)
    return jsonify({"courses": [records[k] for k in sorted(records)],
                    "current_sessions": sorted(sessions),
                    "summaries": {k: courses.summary(r) for k, r in records.items()}})


@api.get("/courses/<course_key>")
def get_course(course_key):
    from schooldash import courses
    record = courses.load(course_key)
    if not record:
        return _error("no_such_course", f"no record for {course_key}",
                      "run Detect materials first", 404)
    return jsonify(record)


@api.put("/courses/<course_key>")
def put_course(course_key):
    from schooldash import courses
    patch = request.get_json(silent=True)
    if not isinstance(patch, dict):
        return _error("bad_json", "the body must be a JSON object", "", 400)
    return jsonify(courses.update(course_key, patch))


@api.post("/courses/<course_key>/materials")
def post_material(course_key):
    from schooldash import courses
    body = request.get_json(silent=True) or {}
    title = (body.get("title") or "").strip()
    url = (body.get("url") or "").strip()
    if not title and not url:
        return _error("bad_request", "give the link a name or a URL", "", 400)
    record = courses.add_material(course_key, title or url, url or None,
                                  kind=body.get("kind") or "other",
                                  notes=body.get("notes") or "", isbn=body.get("isbn"))
    return jsonify(record)


@api.delete("/courses/<course_key>/materials/<material_id>")
def delete_material(course_key, material_id):
    from schooldash import courses
    record = courses.remove_material(course_key, material_id)
    if record is None:
        return _error("no_such_material", "that link is not on this class", "", 404)
    return jsonify(record)


@api.post("/courses/detect")
def post_courses_detect():
    """Scan Canvas (and the cached course docs) for every class's materials.
    Needs the browser session; runs as a job."""
    from schooldash import courses
    body = request.get_json(silent=True) or {}
    only = (body.get("course_key") or "").strip() or None

    def work(say):
        from playwright.sync_api import sync_playwright
        from schooldash import autologin, browser, credentials
        with sync_playwright() as pw:
            context = browser.open_context(pw, headless=True)
            try:
                if not browser.whoami(context):
                    if credentials.has("google"):
                        say("Canvas session expired — signing back in")
                        fixed = autologin.canvas(context)
                        if not fixed.ok:
                            raise RuntimeError(fixed.message)
                    else:
                        raise RuntimeError("the Canvas session is expired — sign in first")
                results = courses.detect_all(context, only=only, emit=say)
            finally:
                browser.close_context(context)
        say(f"done — {len(results)} class(es) scanned")
        return {"courses": sorted(results),
                "summaries": {k: courses.summary(r) for k, r in results.items()}}
    return jsonify(_start_job("detect", work))


@api.get("/textbooks/search")
def get_textbook_search():
    from schooldash import textbooks
    query = (request.args.get("q") or "").strip()
    if not query:
        return _error("bad_request", "type a title, author or ISBN", "", 400)
    return jsonify(textbooks.search(query))


# ---- accelerate an assignment ---------------------------------------------------

@api.get("/accelerate/<item_id>")
def get_accelerate(item_id):
    from schooldash import accelerate
    saved = accelerate.cached(item_id)
    if not saved:
        return _error("no_guide", "no guide has been made for this item yet",
                      "press Accelerate", 404)
    return jsonify(saved)


@api.post("/accelerate/<item_id>")
def post_accelerate(item_id):
    from schooldash import accelerate
    body = request.get_json(silent=True) or {}
    force = bool(body.get("force"))

    def work(say):
        return accelerate.generate(item_id, force=force, emit=say)
    return jsonify(_start_job("accelerate", work))


@api.delete("/accelerate/<item_id>")
def delete_accelerate(item_id):
    conn = db.connect()
    db.acceleration_delete(conn, item_id)
    conn.close()
    return jsonify({"ok": True})


# ---- the Chrome bridge --------------------------------------------------------
#
# *"make it also a crome extetion that connects to the app so that it is easier
# for the AI to read it though the extention"*
#
# Pages fetched by an extension in a browser already signed in to Canvas and
# Veracross, handed to the same parsers the refresh uses. See bridge.py for why
# this is worth having at all.
#
# **These four endpoints sit OUTSIDE the account gate and inside a token
# gate.** An extension has no SchoolDash account and cannot get one — it is a
# browser, not a person — so the account check would refuse every capture. The
# bridge token replaces it: minted by the app, shown once in Settings, pasted
# in by hand, compared in constant time. Loopback is not a permission; anything
# on this Mac can reach 127.0.0.1, so the token is the actual gate.
#
# No CORS headers anywhere, deliberately. An extension service worker holding
# `host_permissions` for 127.0.0.1 is not subject to CORS, so the app needs to
# allow nothing — and a web page therefore still cannot reach these at all,
# whatever token it guessed.


def _bridge_error(exc):
    return _error("bridge", exc.message, exc.fix, exc.status)


@api.get("/bridge/status")
def get_bridge_status():
    """For the extension. Token required, always — this endpoint is outside
    the account gate, so nothing else stands in front of it.

    Settings does NOT call this: it reads the same figures out of
    `/api/state`, which is account-gated like the rest of the page. Two
    callers with two different gates on one endpoint is how an exemption
    written for one of them ends up covering the other.
    """
    from schooldash import bridge
    try:
        bridge.check_token(request.headers.get("X-SchoolDash-Token"))
    except bridge.BridgeError as exc:
        return _bridge_error(exc)
    out = bridge.status()
    # The list of pages to fetch travels WITH the status, so the extension
    # needs exactly one token-gated endpoint and never touches /api/state —
    # which is account-gated and would refuse a browser, correctly.
    try:
        out["wanted"] = bridge.wanted()
    except Exception as exc:  # noqa: BLE001 — an empty list is a fine answer
        out["wanted"] = []
        out["wanted_error"] = str(exc)[:160]
    return jsonify(out)


@api.post("/bridge/capture")
def post_bridge_capture():
    from schooldash import bridge
    try:
        bridge.check_token(request.headers.get("X-SchoolDash-Token"))
    except bridge.BridgeError as exc:
        return _bridge_error(exc)
    body = request.get_json(silent=True) or {}
    try:
        saved = bridge.store(str(body.get("kind") or ""),
                             str(body.get("key") or ""),
                             body.get("body") or "",
                             str(body.get("url") or ""))
    except bridge.BridgeError as exc:
        return _bridge_error(exc)
    return jsonify({"ok": True, "saved": saved})


@api.post("/bridge/reveal")
def post_bridge_reveal():
    """Open Finder on the extension folder.

    The point of the whole feature is that nobody has to handle a folder path.
    Chrome's "Load unpacked" opens a native picker, and a picker with the right
    folder already showing in Finder beside it is the difference between one
    click and a typed path. The path is computed here and never comes from the
    request — `open` is given a folder this app owns, or nothing.
    """
    from schooldash import bridge
    where = bridge.extension()
    if not where["present"]:
        return _error("no_extension",
                      "this build does not carry the Chrome extension",
                      "download it from the install page", 404)
    if sys.platform != "darwin":
        return jsonify({"ok": False, "folder": where["folder"],
                        "message": "open this folder yourself"})
    import subprocess
    # The return code is checked, and `ok` is the truth about what happened.
    # [PROSECUTION 2026-09-11, COUNT 6 — found in this same pass] the first
    # version passed `check=False` and then returned `ok: True` regardless, so
    # a failed `open` would still have turned the button into "Finder is
    # showing it" with no Finder anywhere. A button that lies about a side
    # effect is worse than one that does nothing.
    try:
        done = subprocess.run(["open", "-R", where["folder"]],
                              capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError) as exc:
        return _error("reveal_failed", f"could not open Finder: {exc}",
                      "copy the path instead", 500)
    if done.returncode != 0:
        return _error("reveal_failed",
                      (done.stderr or "Finder would not open that folder").strip()[:200],
                      "copy the path instead", 500)
    return jsonify({"ok": True, "folder": where["folder"]})


@api.post("/bridge/pair")
def post_bridge_pair():
    """Mint or re-show the pairing code. Page-side only: the extension can
    never ask for a token, it can only be given one."""
    from schooldash import bridge
    return jsonify({"ok": True, "token": bridge.token()})


@api.delete("/bridge/pair")
def delete_bridge_pair():
    from schooldash import bridge
    bridge.forget_token()
    gone = bridge.clear()
    return jsonify({"ok": True, "captures_removed": gone})


# ---- a photo of finished work, checked ----------------------------------------
#
# *"add a thing in asgnments where you can click on the assginment and take a
# photo of your assignment or uplod the assghinment had the ai will check it"*
#
# The bytes arrive as the raw request body, not multipart: the page has already
# drawn the photo onto a canvas to shrink and re-encode it, so there is one
# image and no form to parse. `schooldash/work.py` owns every path decision —
# no route here joins a caller's string onto a directory.


def _work_error(exc):
    return _error("bad_photo", exc.message, exc.fix, 400)


@api.get("/work/<item_id>")
def get_work(item_id):
    from schooldash import work
    try:
        return jsonify({"pages": work.pages(item_id),
                        "check": work.saved_check(item_id)})
    except work.WorkError as exc:
        return _work_error(exc)


@api.post("/work/<item_id>")
def post_work(item_id):
    from schooldash import work
    data = request.get_data(cache=False)
    try:
        saved = work.save(item_id, data)
    except work.WorkError as exc:
        return _work_error(exc)
    return jsonify({"ok": True, "page": saved, "pages": work.pages(item_id)})


@api.get("/work/<item_id>/photo/<name>")
def get_work_photo(item_id, name):
    from schooldash import work
    try:
        data, media = work.read(item_id, name)
    except work.WorkError as exc:
        return _error("no_photo", exc.message, exc.fix, 404)
    # Loopback only, and never cached by anything in between: it is a picture
    # of his homework with his handwriting on it.
    return Response(data, mimetype=media, headers={
        "Cache-Control": "no-store, private",
        "Content-Disposition": f"inline; filename={name}"})


@api.delete("/work/<item_id>/photo/<name>")
def delete_work_photo(item_id, name):
    from schooldash import work
    try:
        work.delete(item_id, name)
    except work.WorkError as exc:
        return _work_error(exc)
    return jsonify({"ok": True, "pages": work.pages(item_id)})


@api.delete("/work/<item_id>")
def delete_work(item_id):
    from schooldash import work
    try:
        gone = work.clear(item_id)
    except work.WorkError as exc:
        return _work_error(exc)
    return jsonify({"ok": True, "removed": gone, "pages": []})


@api.post("/work/<item_id>/check")
def post_work_check(item_id):
    """Synchronous: measured at ~7s for one page on haiku, which is a spinner
    rather than a job with progress lines."""
    from schooldash import workcheck
    result = workcheck.run(item_id)
    if not result.get("ok"):
        return _error("check_failed", result.get("message", "the check failed"),
                      result.get("fix", ""), 502)
    return jsonify(result)


# ---- updating the app ---------------------------------------------------------
#
# *"i need an update button to pop up when there is an update to the app"*.
# GET is a cached read and never blocks a page; POST does the swap as a job so
# the progress lines land in the same strip a refresh uses; the restart hands
# the port to the new build. Nothing here runs on its own.

@api.get("/update")
def get_update():
    from schooldash import update
    force = request.args.get("force") in ("1", "true", "yes")
    try:
        return jsonify(update.status(force=force))
    except Exception as exc:  # noqa: BLE001 — an update check may never break the app
        log.warning("update status failed: %s", exc)
        return jsonify({"current": update.current_version(), "available": False,
                        "error": str(exc)[:120], "can_install": False})


@api.post("/update")
def post_update():
    from schooldash import update
    body = request.get_json(silent=True) or {}
    force = bool(body.get("force"))

    def work(say):
        return update.install(emit=say, force=force)
    return jsonify(_start_job("update", work))


@api.post("/update/restart")
def post_update_restart():
    """Start a server on the new build and stand down.

    The app window is a separate process pointed at 127.0.0.1, so it stays
    open and reconnects; the page polls /api/health until the new version
    answers.
    """
    from schooldash import update
    try:
        out = update.restart_server()
    except Exception as exc:  # noqa: BLE001
        return _error("restart_failed", f"could not start the new version: {exc}",
                      "quit SchoolDash and open it again", 500)
    update.exit_soon(1.0)
    return jsonify(out)


# ---- chat --------------------------------------------------------------------

@api.post("/chat")
def post_chat():
    from schooldash.ai import chat as chat_mod
    body = request.get_json(silent=True) or {}
    message = (body.get("message") or "").strip()
    if not message:
        return _error("bad_request", "message is required", "type a question", 400)
    state = pipeline.load_state()
    if not state:
        return _error("no_state", "no data to chat about yet",
                      "press Refresh first", 409)
    state = _overlay_done(state)

    if body.get("stream"):
        turn_id = uuid.uuid4().hex[:12]
        _chat_turns[turn_id] = {"message": message,
                                "session_id": body.get("session_id"),
                                "item_id": body.get("item_id"),
                                "state": state}
        return jsonify({"turn_id": turn_id})

    try:
        # the action-capable turn: an answer plus (optionally) a verified
        # add-task or mark-done, in one structured call
        result = chat_mod.answer_action(message, state,
                                        session_id=body.get("session_id"),
                                        item_id=body.get("item_id"))
    except Exception as exc:  # noqa: BLE001
        # Written for the person who will read it. "check the AI provider
        # (run.py health)" is addressed to a developer, and the reader is a
        # terminal-averse student — the project's own skill file says so in its
        # third paragraph. The technical detail is kept, but as detail.
        log.warning("chat failed: %s", exc)
        return _error("chat_failed",
                      "Chat could not answer just now. Your assignments, "
                      "schedule and grades on this page are unaffected — only "
                      "chat needs the AI.",
                      "Press Refresh and ask again. If it keeps happening, "
                      "show someone this: " + str(exc)[:160], 502)
    # Kept so the conversation survives a reload. Recorded after the answer
    # exists, and never allowed to break a reply that already worked.
    try:
        conn = db.connect()
        try:
            db.chat_message_add(conn, "user", message,
                                {"item_id": body.get("item_id")})
            db.chat_message_add(conn, "assistant", result.get("answer") or "", {
                "grounded": result.get("grounded"),
                "cited": result.get("cited") or [],
                "provider": result.get("provider"),
                "confidence": result.get("confidence"),
            })
        finally:
            conn.close()
    except Exception as exc:  # noqa: BLE001 — history is not worth an error
        log.warning("could not record the chat turn: %s", exc)
    return jsonify(result)


@api.get("/chat/history")
def chat_history():
    """Previous questions and answers, oldest first.

    *"add previues chat memoreie to the chat page"* — the conversation used to
    live only in the page, so reopening the app showed an empty box even
    though every answer had been given minutes earlier.
    """
    limit = request.args.get("limit", type=int) or 60
    conn = db.connect()
    try:
        return jsonify({"messages": db.chat_history(conn, min(limit, 200))})
    finally:
        conn.close()


@api.delete("/chat/history")
def chat_history_clear():
    conn = db.connect()
    try:
        return jsonify({"cleared": db.chat_history_clear(conn)})
    finally:
        conn.close()


@api.get("/chat/payload")
def chat_payload():
    """'Show what it was given' — the exact grounded payload, no secrets in it."""
    from schooldash.ai import chat as chat_mod
    state = pipeline.load_state()
    if not state:
        return _error("no_state", "no data yet", "press Refresh first", 409)
    state = _overlay_done(state)
    return jsonify({"payload": chat_mod.build_payload(
        state, request.args.get("item_id"))})


@api.get("/chat/<turn_id>/stream")
def chat_stream(turn_id):
    from schooldash.ai import chat as chat_mod
    turn = _chat_turns.pop(turn_id, None)
    if not turn:
        return _error("no_such_turn", f"unknown turn {turn_id}",
                      "POST /api/chat with stream:true first", 404)

    def stream():
        try:
            for event in chat_mod.answer_streaming(
                    turn["message"], turn["state"],
                    session_id=turn.get("session_id"),
                    item_id=turn.get("item_id")):
                yield f"data: {json.dumps(event)}\n\n"
        except Exception as exc:  # noqa: BLE001
            yield f'data: {json.dumps({"type": "error", "message": str(exc)})}\n\n'

    return Response(stream(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-store"})
