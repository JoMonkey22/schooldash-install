"""GET / — the one page. All data arrives via /api/state; the template is the
shell. Static files come only from web/static/ (Flask's static route); there
is no other file-serving route, so /config.json and traversal variants 404.

The three extra routes below are named single files, not a directory server:
the manifest and the service worker have to answer from the origin root or
Chrome scopes the installed app to /static/ and refuses to control the page.
"""

from flask import Blueprint, current_app, render_template, send_from_directory

page = Blueprint("page", __name__)


def _static(filename: str, mimetype: str):
    return send_from_directory(current_app.static_folder, filename,
                               mimetype=mimetype)


@page.get("/")
def dashboard():
    return render_template("dashboard.html")


# The same shell: views.js reads the path and opens that section. Real paths
# rather than #fragments so the launcher can open the setup wizard directly and
# a bookmark to /classes works.
# Every view in views.js needs a route here, or reloading the page a student
# is standing on answers 404. [MEASURED] 2026-09-03: adding Chat, Upcoming,
# Done and Grades to the nav without adding them here meant /grades — a path
# the app itself pushes into history — was Not Found on refresh.
@page.get("/setup")
@page.get("/classes")
@page.get("/settings")
@page.get("/chat")
@page.get("/upcoming")
@page.get("/done")
@page.get("/grades")
# 0.18: the centre of the one screen is a pane, and these are its names.
@page.get("/item")
@page.get("/grade")
@page.get("/accel")
@page.get("/add")
def dashboard_view():
    return render_template("dashboard.html")


@page.get("/manifest.webmanifest")
def manifest():
    return _static("manifest.webmanifest", "application/manifest+json")


@page.get("/sw.js")
def service_worker():
    # Served from the root so its default scope is the whole origin.
    response = _static("sw.js", "text/javascript")
    response.headers["Cache-Control"] = "no-cache"
    return response


@page.get("/favicon.ico")
def favicon():
    return _static("brand/icon-192.png", "image/png")
