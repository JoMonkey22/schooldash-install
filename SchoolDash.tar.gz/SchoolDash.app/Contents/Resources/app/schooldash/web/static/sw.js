/* SchoolDash service worker — the app shell only.
 *
 * Deliberately narrow: this app renders live, logged-in school data, so
 * NOTHING under /api/ is ever cached. A stale assignment list is worse than
 * no list. The cache exists for two reasons only:
 *   1. Chrome requires a fetch handler before it will offer "Install".
 *   2. If the local server isn't running, the shell can still load and say so
 *      instead of showing Chrome's dinosaur.
 *
 * Bump SHELL_VERSION whenever the shell assets change.
 */

const SHELL_VERSION = "v6";
const SHELL_CACHE = `schooldash-shell-${SHELL_VERSION}`;

const SHELL_ASSETS = [
  "/",
  "/static/app.css",
  "/static/app.js",
  /* [MEASURED] 2026-09-02: views.js arrived with the Board/Classes/Settings
     tabs in 0.12 and was never added here, so the offline shell loaded an
     app.js whose tab handlers live in a file that was not there. Network-first
     means this only bites with the server down — which is exactly when the
     offline shell is the only thing running. */
  "/static/views.js",
  "/static/brand/icon.svg",
  "/static/brand/icon-192.png",
  "/static/brand/icon-512.png",
  "/manifest.webmanifest",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(SHELL_CACHE)
      // addAll is all-or-nothing; a single 404 would abort the install and
      // leave the app permanently uninstallable, so add them individually.
      .then((cache) =>
        Promise.all(
          SHELL_ASSETS.map((url) =>
            cache.add(url).catch((err) => {
              console.warn("[sw] could not precache", url, err);
            }),
          ),
        ),
      )
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((names) =>
        Promise.all(
          names
            .filter((n) => n.startsWith("schooldash-shell-") && n !== SHELL_CACHE)
            .map((n) => caches.delete(n)),
        ),
      )
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  // Live data: never cached, never served stale. Let it fail honestly.
  if (url.pathname.startsWith("/api/")) return;

  // Navigations: network first so a restarted server always wins, with the
  // cached shell as the offline fallback.
  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone();
          caches.open(SHELL_CACHE).then((c) => c.put("/", copy));
          return response;
        })
        .catch(() =>
          caches.match("/").then((cached) => cached || offlineResponse()),
        ),
    );
    return;
  }

  // Static assets: network first as well. The server is on this machine, so
  // the cache saves no measurable time — serving cache-first would only mean
  // an edited stylesheet needs two reloads to show up.
  event.respondWith(
    fetch(request)
      .then((response) => {
        if (response && response.ok) {
          const copy = response.clone();
          caches.open(SHELL_CACHE).then((c) => c.put(request, copy));
        }
        return response;
      })
      .catch(() => caches.match(request)),
  );
});

function offlineResponse() {
  return new Response(
    `<!doctype html><meta charset="utf-8">
     <title>SchoolDash isn't running</title>
     <style>
       :root { color-scheme: light dark; }
       body { font: 16px/1.5 system-ui, sans-serif; margin: 0;
              min-height: 100dvh; display: grid; place-items: center;
              text-align: center; padding: 24px;
              background: light-dark(#F5F7FB, #0D1220);
              color: light-dark(#14192B, #E6EAF4); }
       h1 { font-size: 1.25rem; margin: 0 0 8px; }
       p { margin: 0; opacity: .75; max-width: 34ch; }
     </style>
     <div>
       <h1>SchoolDash isn't running</h1>
       <p>Open SchoolDash from your Dock or Applications folder, then come
          back to this window and reload.</p>
     </div>`,
    { headers: { "Content-Type": "text/html; charset=utf-8" }, status: 503 },
  );
}
