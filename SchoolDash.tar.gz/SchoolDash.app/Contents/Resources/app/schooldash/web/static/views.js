/* The panes beyond the board: first-run Setup, Classes, Settings, the grade
   page, the Accelerate guide — plus the chat extras (dictation, "teacher
   said") and the ⌘K jump palette.

   A second file on purpose. app.js is the board and is also inlined into the
   published read-only snapshot; none of this belongs there (a snapshot has no
   server to set up, no classes to edit, no model to call, and never carries
   grades). Everything here talks to the local API and reuses app.js's
   globals: STATE, $, esc, loadState, refresh, niceDate, shortCourse,
   showPane, savePrefs, getPrefs and the helpers on window.SD. */
"use strict";

(function () {
  if (typeof window.SNAPSHOT === "object" && window.SNAPSHOT !== null) return;

  /* Every name here is a path the page can stand on, so routes_page.py must
     answer each one (tests/test_web.py checks). "grades" is the old page's
     name, kept so a bookmark still lands somewhere sensible. */
  const VIEWS = ["chat", "item", "grade", "grades", "accel", "done", "add",
                 "classes", "settings", "setup"];
  let CURRENT = "chat";
  let SETUP = null;            // /api/setup/status
  let SETUP_STEP = null;       // which wizard step is on screen
  let COURSES = {};            // course_key -> record
  let SUMMARIES = {};          // course_key -> summary
  let SELECTED_COURSE = null;
  let ACCEL_ITEM = null;
  let GRADE_KEY = null;
  const SD = window.SD || {};

  /* Where the extension and the app are downloaded from. One constant, so the
     page, the README and the install site cannot drift apart. */
  const SITE_URL = "https://jomonkey22.github.io/schooldash-install/";
  const EXT_URL = SITE_URL + "#chrome";

  /* ---------------- small helpers ---------------- */
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function api(path, options) {
    const res = await fetch(path, options);
    let body = {};
    try { body = await res.json(); } catch (e) { /* no body */ }
    if (!res.ok || body.error) {
      const err = new Error((body.error || {}).message || `HTTP ${res.status}`);
      err.status = res.status; err.body = body;
      throw err;
    }
    return body;
  }
  const post = (path, data) => api(path, { method: "POST",
    headers: { "Content-Type": "application/json" }, body: JSON.stringify(data || {}) });
  const put = (path, data) => api(path, { method: "PUT",
    headers: { "Content-Type": "application/json" }, body: JSON.stringify(data || {}) });
  const del = (path) => api(path, { method: "DELETE" });

  /* Poll a background job (routes_api._start_job) until it finishes, reporting
     each new progress line. Bounded on purpose: `for(;;)` left the page polling
     for the rest of the day behind a spinner if a job's thread ever hung. */
  const JOB_POLL_MS = 1500;
  const JOB_MAX_WAIT_MS = 30 * 60 * 1000;

  async function pollJob(started, onLine) {
    if (!started.started && !(started.already_running && started.job_id)) {
      throw new Error("could not start — something else may be running");
    }
    if (!started.started) {
      onLine && onLine("(one of these was already running — following it)");
    }
    let seen = 0;
    const deadline = Date.now() + JOB_MAX_WAIT_MS;
    while (Date.now() < deadline) {
      await sleep(JOB_POLL_MS);
      const job = await api(`/api/jobs/${started.job_id}`);
      for (; seen < job.lines.length; seen++) onLine && onLine(job.lines[seen]);
      if (job.done) {
        if (job.ok) return job.result;
        throw new Error(job.error || "the job failed");
      }
    }
    throw new Error("this took too long and was given up on — the work may "
      + "still finish in the background; press Refresh in a minute to see");
  }

  /* Start a sign-in (POST /api/login) and wait for it. A human step can take
     minutes, so this waits up to 40. */
  async function runLogin(kind, onNote) {
    const started = await post("/api/login", { kind, auto: true });
    if (!started.started) {
      onNote && onNote(started.message || "a sign-in is already running");
      return { ok: false, results: [], busy: true };
    }
    onNote && onNote("signing in… (a window only appears if a step needs you)");
    for (let n = 0; n < 800; n++) {
      await sleep(3000);
      const status = await api(`/api/login/${started.job_id}`);
      if (status.done) return status;
    }
    return { ok: false, results: [], output: "still waiting" };
  }

  function siteResultHtml(result) {
    const dot = result.ok ? "ok-dot" : (result.needs_human ? "warn-dot" : "bad-dot");
    const how = { already: "already signed in", auto: "signed in automatically",
                  human: "finished by you", failed: "did not finish",
                  skipped: "skipped" }[result.how] || result.how;
    return `<div class="site-result"><span class="sr-name ${dot}">${esc(
      result.site === "canvas" ? "Canvas" : "Veracross")}</span>
      <span><strong>${esc(how)}</strong> — ${esc(result.message)}${result.detail
        ? `<span class="muted"> (${esc(result.detail)})</span>` : ""}</span></div>`;
  }

  /* ---------------- views ----------------
     showView is the URL-aware wrapper around app.js's showPane: the pane
     changes, the address bar follows for the pages worth bookmarking, and a
     pane that needs data asks for it. */
  const PUSHABLE = new Set(["chat", "classes", "settings", "setup", "done"]);
  function showView(name, push) {
    if (!VIEWS.includes(name)) name = "chat";
    if (name === "grades") name = "chat";
    if (["item", "grade", "accel"].includes(name) && push !== false) {
      // contextual panes are opened by their own functions, never by path
      name = "chat";
    }
    CURRENT = name;
    /* A path is deliberate navigation, so in the simple layout it moves the
       PAGE rather than only the centre pane — otherwise /classes would render
       into a column that layout keeps hidden.

       `push === false` is the initial route and the back button, and "/" maps
       to "chat" there. [MEASURED] 2026-09-10: that made boot overwrite the
       saved page, so the app always opened on Chat no matter which page he
       had left it on. In this layout "/" means home, and home is the page he
       was last on. */
    const simple = window.isSimple && window.isSimple() && window.showTab;
    if (simple && name === "chat" && push === false) {
      window.showTab((window.getPrefs() || {}).tab || "todo");
    } else if (simple && ["chat", "classes", "done", "settings"].includes(name)) {
      window.showTab(name);
    } else {
      window.showPane(name);
    }
    if (push !== false && PUSHABLE.has(name)) {
      const path = name === "chat" ? "/" : `/${name}`;
      if (location.pathname !== path) history.pushState({ view: name }, "", path);
    }
  }
  window.showView = showView;
  window.onPaneShown = function (name) {
    CURRENT = name;
    $("#banners").hidden = name === "setup";
    if (name === "classes") renderClasses();
    if (name === "settings") renderSettings();
    if (name === "setup") renderSetup();
    if (name === "chat" || name === "done") {
      if (PUSHABLE.has(name)) {
        const path = name === "chat" ? "/" : `/${name}`;
        if (location.pathname !== path && !location.pathname.startsWith("/setup")) {
          history.replaceState({ view: name }, "", path);
        }
      }
    }
  };

  document.querySelectorAll("#view-nav button").forEach((b) =>
    b.addEventListener("click", () => showView(b.dataset.view)));
  window.addEventListener("popstate", () => {
    showView(location.pathname.replace("/", "") || "chat", false);
  });

  /* ---------------- setup status + banner ---------------- */
  const setupBanner = document.createElement("div");
  setupBanner.id = "setup-banner";
  const banners = $("#banners");
  banners.parentNode.insertBefore(setupBanner, banners);

  async function refreshSetup() {
    try { SETUP = await api("/api/setup/status"); } catch (e) { return SETUP; }
    renderSetupBanner();
    return SETUP;
  }

  /* Steps come from the server (schooldash/onboarding.py). Address them by
     key: positional indexing silently checked the wrong thing the moment a
     step was added or reordered. */
  function step(key) {
    return ((SETUP && SETUP.steps) || []).find((s) => s.key === key) || {};
  }

  function renderSetupBanner() {
    if (!SETUP || CURRENT === "setup") { setupBanner.innerHTML = ""; return; }
    if (SETUP.complete) { setupBanner.innerHTML = ""; return; }
    const pending = SETUP.steps.filter((s) => !s.done).map((s) => s.title.toLowerCase());
    setupBanner.innerHTML = `<div class="banner warn">SchoolDash is not fully set up yet
      (${esc(pending.join(", "))}).
      <a class="banner-link" href="/setup" data-view="setup">Finish setting up →</a></div>`;
    setupBanner.querySelector("a").addEventListener("click", (ev) => {
      ev.preventDefault(); showView("setup");
    });
  }

  /* ---------------- the accounts form (Settings + Setup share it) ---------------- */
  function accountsForm(host, options) {
    options = options || {};
    const creds = (SETUP && SETUP.credentials) || {};
    const google = creds.google || {};
    const vx = creds.veracross || {};
    const sameAsGoogle = vx.configured ? !!vx.use_google : true;
    host.innerHTML = `
      <form class="accounts-form">
        <label class="field">School Google email
          <input name="google_email" type="email" autocomplete="username"
                 value="${esc(google.username || "")}" placeholder="your school email" required>
        </label>
        <label class="field">Google password
          <input name="google_password" type="password" autocomplete="current-password"
                 placeholder="${google.has_password ? "(saved — leave blank to keep it)" : ""}">
        </label>
        <label class="check"><input type="checkbox" name="vx_same" ${sameAsGoogle ? "checked" : ""}>
          Veracross uses the same email and password</label>
        <div class="vx-own" ${sameAsGoogle ? "hidden" : ""}>
          <div class="field-row">
            <label class="field">Veracross username
              <input name="vx_username" type="text" autocomplete="off"
                     value="${esc(vx.use_google ? "" : (vx.username || ""))}">
            </label>
            <label class="field">Veracross password
              <input name="vx_password" type="password" autocomplete="off"
                     placeholder="${vx.has_password && !vx.use_google ? "(saved)" : ""}">
            </label>
          </div>
        </div>
        <label class="check"><input type="checkbox" name="show"> show passwords while typing</label>
        <div class="row-actions">
          <button type="submit" class="primary">${esc(options.saveLabel || "Save")}</button>
          <button type="button" class="ghost af-test" ${google.configured ? "" : "disabled"}>Test the sign-in</button>
          ${google.configured ? `<button type="button" class="ghost af-forget">Forget these</button>` : ""}
          ${options.allowSkip ? `<button type="button" class="ghost af-skip">Skip for now</button>` : ""}
        </div>
        <p class="note af-note"></p>
        <div class="af-results"></div>
      </form>`;
    const form = host.querySelector("form");
    const note = form.querySelector(".af-note");
    const say = (text, cls) => { note.textContent = text; note.className = "note af-note " + (cls || ""); };
    form.querySelector('[name="vx_same"]').addEventListener("change", (ev) => {
      form.querySelector(".vx-own").hidden = ev.target.checked;
    });
    form.querySelector('[name="show"]').addEventListener("change", (ev) => {
      form.querySelectorAll('input[type="password"], input[data-pw]').forEach((i) => {
        i.type = ev.target.checked ? "text" : "password"; i.dataset.pw = "1";
      });
    });
    form.addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const same = form.querySelector('[name="vx_same"]').checked;
      const body = {
        google: { email: form.google_email.value.trim(), password: form.google_password.value },
        veracross: same ? { use_google: true }
          : { username: form.vx_username.value.trim(), password: form.vx_password.value,
              use_google: false },
      };
      if (!body.google.email) { say("the email is needed", "bad"); return; }
      if (!body.google.password && !google.has_password) { say("the password is needed", "bad"); return; }
      const btn = form.querySelector('button[type="submit"]');
      btn.disabled = true;
      try {
        await put("/api/credentials", body);
        say("saved on this Mac", "ok");
        form.google_password.value = "";
        await refreshSetup();
        options.onSaved && options.onSaved();
      } catch (err) {
        say("could not save: " + err.message, "bad");
      }
      btn.disabled = false;
    });
    const test = form.querySelector(".af-test");
    test.addEventListener("click", async () => {
      test.disabled = true;
      const results = form.querySelector(".af-results");
      results.innerHTML = "";
      say("signing in to Canvas and Veracross with the saved details…");
      try {
        const out = await runLogin("all", (t) => say(t));
        results.innerHTML = (out.results || []).map(siteResultHtml).join("")
          || `<div class="muted">${esc(out.output || "no result came back")}</div>`;
        say(out.ok ? "both signed in" : "not everything signed in — see below", out.ok ? "ok" : "bad");
        await refreshSetup();
        options.onTested && options.onTested(out);
      } catch (err) {
        say("could not run it: " + err.message, "bad");
      }
      test.disabled = false;
    });
    const forget = form.querySelector(".af-forget");
    if (forget) forget.addEventListener("click", async () => {
      await del("/api/credentials");
      await refreshSetup();
      accountsForm(host, options);
    });
    const skip = form.querySelector(".af-skip");
    if (skip) skip.addEventListener("click", async () => {
      await post("/api/setup/mark", { key: "skipped_accounts" });
      await refreshSetup();
      options.onSkipped && options.onSkipped();
    });
  }

  /* ---------------- SETUP wizard ---------------- */
  async function renderSetup() {
    if (!SETUP) await refreshSetup();
    if (!SETUP) { $("#setup-body").innerHTML = "<p>SchoolDash is not answering.</p>"; return; }
    renderSetupBanner();
    if (!SETUP_STEP) SETUP_STEP = SETUP.next || "first_refresh";
    const steps = SETUP.steps;
    $("#setup-steps").innerHTML = steps.map((s, i) => `
      <button type="button" class="setup-step${s.done ? " done" : ""}${s.key === SETUP_STEP ? " active" : ""}"
              data-step="${esc(s.key)}">
        <span class="ss-n">${s.done ? "✓" : i + 1}</span><strong>${esc(s.title)}</strong>
        <span class="ss-sum">${esc(s.summary)}</span></button>`).join("")
      + `<button type="button" class="setup-step" data-step="board"><span class="ss-n">→</span>
         <strong>Open the board</strong><span class="ss-sum">${SETUP.complete ? "setup is complete" : "you can come back any time"}</span></button>`;
    $("#setup-steps").querySelectorAll(".setup-step").forEach((b) =>
      b.addEventListener("click", () => {
        if (b.dataset.step === "board") { showView("chat"); return; }
        SETUP_STEP = b.dataset.step; renderSetup();
      }));
    const body = $("#setup-body");
    const render = { accounts: stepAccounts, connect: stepConnect, classes: stepClasses,
                     first_refresh: stepFinish }[SETUP_STEP] || stepAccounts;
    render(body);
  }

  function next(step) { SETUP_STEP = step; renderSetup(); }

  function stepAccounts(body) {
    body.innerHTML = `<h2>Welcome to SchoolDash</h2>
      <p class="lede">One screen with everything you actually have to do — Canvas assignments,
      the homework teachers type into their docs, your schedule and grades — all on this Mac.</p>
      <p>First, your school sign-ins. Canvas and Veracross at your school log in with your
      <strong>school Google account</strong>. Save it here and SchoolDash signs in for you —
      the first time, and every time a session runs out later — instead of asking you to.</p>
      <p class="muted">Kept in a file only you can read, on this Mac. Never sent anywhere except
      the sign-in pages themselves. If Google asks for a phone tap or a code, a window opens for
      you to do that one step.</p>
      <div id="setup-accounts-host"></div>`;
    accountsForm($("#setup-accounts-host"), {
      saveLabel: "Save and continue", allowSkip: true,
      onSaved: () => next("connect"), onSkipped: () => next("connect") });
  }

  function stepConnect(body) {
    const c = SETUP.canvas, v = SETUP.veracross, creds = SETUP.credentials || {};
    body.innerHTML = `<h2>Connect Canvas and Veracross</h2>
      <p class="lede">SchoolDash signs in, finds your class-schedule feed, and checks it can read your grades.</p>
      <dl class="kv-list">
        <dt>Canvas</dt><dd class="${c.signed_in ? "ok-dot" : "bad-dot"}">${c.signed_in
          ? `signed in${c.name ? " as " + esc(c.name) : ""}` : "not connected yet"}</dd>
        <dt>Class schedule</dt><dd class="${v.class_feed ? "ok-dot" : "bad-dot"}">${v.class_feed
          ? `feed saved${v.meetings ? ` — ${v.meetings} class meetings` : ""}` : "feed not found yet"}</dd>
        <dt>Grades</dt><dd class="${v.grades ? "ok-dot" : "warn-dot"}">${v.grades
          ? `${v.grades} courses read` : "not read yet (happens on the first pull)"}</dd>
      </dl>
      <div class="setup-actions">
        <button type="button" class="primary" id="connect-go">${(creds.google || {}).configured
          ? "Connect now" : "Open the sign-in windows"}</button>
        <button type="button" class="ghost" id="connect-next">Next: your classes →</button>
      </div>
      <p class="note" id="connect-note">${(creds.google || {}).configured ? ""
        : "No saved sign-in, so a browser window will open for each site — finish signing in there. Tick \"Stay signed in\" on Canvas."}</p>
      <div id="connect-results"></div>`;
    $("#connect-next").addEventListener("click", () => next("classes"));
    $("#connect-go").addEventListener("click", async () => {
      const btn = $("#connect-go"); btn.disabled = true;
      const note = $("#connect-note");
      try {
        const out = await runLogin("all", (t) => { note.textContent = t; });
        $("#connect-results").innerHTML = (out.results || []).map(siteResultHtml).join("")
          || `<div class="muted">${esc(out.output || "")}</div>`;
        note.textContent = out.ok ? "connected — pulling your first data…" : "not everything connected; you can retry, or continue and fix it later";
        if (out.ok) {
          await refresh();          // app.js: the first pull, with the progress strip
          await refreshSetup();
          next("classes");
          return;
        }
        await refreshSetup();
        renderSetup();
      } catch (err) {
        note.textContent = "could not start: " + err.message;
      }
      btn.disabled = false;
    });
  }

  function stepClasses(body) {
    body.innerHTML = `<h2>Your classes</h2>
      <p class="lede">For each class SchoolDash finds the textbook, syllabus, the teacher's homework
      doc and the tools it uses, and learns how that teacher writes homework. Check each one,
      fix anything wrong, add what it missed.</p>
      <div class="setup-actions">
        <button type="button" class="primary" id="classes-learn">Detect materials and learn my classes</button>
        <button type="button" class="ghost" id="classes-next">Next: finish →</button>
      </div>
      <div id="setup-classes-progress" class="progress" hidden></div>
      <div id="setup-classes-grid" class="classes-grid" style="margin-top:14px"></div>
      <aside id="setup-class-detail" class="class-detail" hidden style="margin-top:14px"></aside>`;
    $("#classes-next").addEventListener("click", async () => {
      await post("/api/setup/mark", { key: "classes_seen" });
      await refreshSetup();
      next("first_refresh");
    });
    $("#classes-learn").addEventListener("click", () => learnClasses(
      $("#setup-classes-progress"), $("#classes-learn"),
      () => renderClassGrid($("#setup-classes-grid"), $("#setup-class-detail"))));
    loadCourses().then(() => renderClassGrid($("#setup-classes-grid"), $("#setup-class-detail")));
  }

  /* Detect materials for every class, then learn the profiles nobody has
     learned yet. Two jobs, run in sequence, one progress strip. */
  async function learnClasses(progress, button, onDone) {
    button.disabled = true;
    progress.hidden = false; progress.innerHTML = "";
    const line = (t) => { const d = document.createElement("div"); d.textContent = t;
      progress.appendChild(d); progress.scrollTop = progress.scrollHeight; };
    try {
      line("[materials] scanning your Canvas courses…");
      await pollJob(await post("/api/courses/detect", {}), (t) => line("[materials] " + t));
      await loadCourses();
      onDone && onDone();
      line("[learn] learning how each teacher posts homework…");
      await pollJob(await post("/api/setup/learn", {}), (t) => line("[learn] " + t));
      line("done");
      await refreshSetup();
      await loadState();
    } catch (err) {
      line("stopped: " + err.message);
    }
    button.disabled = false;
    setTimeout(() => { progress.hidden = true; }, 6000);
  }

  function stepFinish(body) {
    const first = step("first_refresh");
    const done = !!first.done;
    body.innerHTML = `<h2>${done ? "You're set" : "Almost there"}</h2>
      <p class="lede">${done
        ? `Your board has ${esc(first.summary || "your work on it")}. From here on SchoolDash refreshes itself every half hour while your Mac is awake.`
        : "One first pull of your homework, schedule and grades, and the board is live."}</p>
      <div class="setup-actions">
        ${done ? "" : `<button type="button" class="primary" id="finish-pull">Pull my homework now</button>`}
        <button type="button" class="ghost" id="finish-reminders">Turn on reminders (7am &amp; 5pm)</button>
        <button type="button" class="primary" id="finish-open">${done ? "Open my board" : "Open the board anyway"}</button>
      </div>
      <p class="note" id="finish-note"></p>
      <p class="muted">You can change any of this later under <strong>Settings</strong> and <strong>Classes</strong>.</p>`;
    const note = $("#finish-note");
    const pull = $("#finish-pull");
    if (pull) pull.addEventListener("click", async () => {
      pull.disabled = true; note.textContent = "pulling…";
      await refresh(); await refreshSetup(); renderSetup();
    });
    $("#finish-reminders").addEventListener("click", async () => {
      const b = $("#finish-reminders"); b.disabled = true;
      try {
        const out = await post("/api/setup/reminders", {});
        note.textContent = out.message || "reminders scheduled";
      } catch (err) { note.textContent = "could not schedule: " + err.message; }
    });
    $("#finish-open").addEventListener("click", async () => {
      await post("/api/setup/mark", { key: "completed_at" });
      await refreshSetup();
      showView("chat");
    });
  }

  /* ---------------- CLASSES ---------------- */
  async function loadCourses() {
    try {
      const out = await api("/api/courses");
      COURSES = {}; for (const c of out.courses) COURSES[c.course_key] = c;
      SUMMARIES = out.summaries || {};
    } catch (e) { /* keep what we have */ }
    return COURSES;
  }

  function courseName(key) {
    const c = COURSES[key];
    if (c) return c.display_name || key;
    const g = (STATE && STATE.grades || []).find((x) => x.course_key === key);
    if (g) return g.display_name || key;
    const p = (STATE && STATE.profiles || []).find((x) => x.course_key === key);
    if (p) return p.display_name || p.course_raw || key;
    const i = (STATE && STATE.items || []).find((x) => x.course_key === key);
    return i ? i.course : key;
  }

  /* Every class we know about: records, plus profiles with no record yet. */
  function allCourseKeys() {
    const keys = new Set(Object.keys(COURSES));
    for (const p of (STATE && STATE.profiles) || []) keys.add(p.course_key);
    return [...keys].sort((a, b) => courseName(a).localeCompare(courseName(b)));
  }

  /* *"in classes only have the current semesters grade"*. The server flags
     each record with `current`, worked out from the session the classes that
     actually meet this week belong to. A class with no record yet (a profile
     the detector has not scanned) has nothing to judge, so it counts as
     current rather than being hidden. */
  const isCurrentKey = (key) => {
    const record = COURSES[key];
    return !record || record.current !== false;
  };
  const termOf = (key) => (COURSES[key] || {}).term || "another term";

  function visibleMaterials(record) {
    return (record.materials || []).filter((m) => !m.hidden);
  }

  function classCardHtml(key) {
    const record = COURSES[key];
    const profile = ((STATE && STATE.profiles) || []).find((p) => p.course_key === key) || {};
    const materials = record ? visibleMaterials(record) : [];
    const has = (kind) => materials.some((m) => m.kind === kind);
    const chips = [];
    chips.push(`<span class="cc-chip ${has("textbook") ? "have" : (has("textbook_mention") ? "" : "miss")}">${
      has("textbook") ? "textbook ✓" : has("textbook_mention") ? "textbook named" : "no textbook"}</span>`);
    chips.push(`<span class="cc-chip ${has("syllabus") ? "have" : ""}">${has("syllabus") ? "syllabus ✓" : "no syllabus"}</span>`);
    if (has("schedule_doc") || profile.homework_source === "doc" || profile.homework_source === "both")
      chips.push(`<span class="cc-chip have">homework doc</span>`);
    else if (profile.homework_source === "canvas") chips.push(`<span class="cc-chip">Canvas only</span>`);
    if (profile.learned_by) chips.push(`<span class="cc-chip">${
      profile.learned_by === "heuristic" ? "format not learned" : "format learned"}</span>`);
    if (materials.length) chips.push(`<span class="cc-chip">${materials.length} link${materials.length === 1 ? "" : "s"}</span>`);
    if (record && record.reviewed_at) chips.push(`<span class="cc-chip have">reviewed ✓</span>`);
    const teacher = (record && record.teacher) || profile.teacher || "";
    const room = (record && record.room) || (profile.meeting || {}).typical_room || "";
    return `<button type="button" class="class-card${SELECTED_COURSE === key ? " selected" : ""}" data-key="${esc(key)}"
        style="border-left: 3px solid ${esc(SD.classColor ? SD.classColor(key) : "transparent")}">
      <div class="cc-name">${esc(shortCourse(courseName(key)))}</div>
      <div class="cc-sub">${esc([teacher, room ? "room " + room : ""].filter(Boolean).join(" · ") || " ")}</div>
      <div class="cc-chips">${chips.join("")}</div></button>`;
  }

  function renderClassGrid(grid, detailHost) {
    const all = allCourseKeys();
    const keys = all.filter(isCurrentKey);
    const others = all.filter((k) => !isCurrentKey(k));
    /* Nothing is hidden silently (spec §5.2): the classes from another term
       are one click away and the line says which term each belongs to. */
    const byTerm = new Map();
    for (const key of others) {
      const term = termOf(key);
      if (!byTerm.has(term)) byTerm.set(term, []);
      byTerm.get(term).push(key);
    }
    grid.innerHTML = (keys.length ? keys.map(classCardHtml).join("")
      : `<div class="empty-note">no classes known yet — connect Canvas and Veracross first, then press Detect materials</div>`)
      + (others.length ? `<details class="other-terms"><summary>${others.length} class${
          others.length === 1 ? "" : "es"} from another term — ${[...byTerm.entries()]
            .map(([term, list]) => `${list.length} in ${esc(term)}`).join(", ")}</summary>
          <div class="classes-grid">${others.map(classCardHtml).join("")}</div></details>` : "");
    grid.querySelectorAll(".class-card").forEach((b) => b.addEventListener("click", () => {
      SELECTED_COURSE = b.dataset.key;
      grid.querySelectorAll(".class-card").forEach((x) => x.classList.toggle("selected", x === b));
      renderClassDetail(detailHost);
      detailHost.scrollIntoView({ block: "nearest" });
    }));
  }

  async function renderClasses() {
    await loadCourses();
    /* Counted from the list the GRID draws — records plus profiles with no
       record yet — not from COURSES alone. Two different lists meant the
       sentence could say "12 classes this semester" above thirteen cards. */
    const all = allCourseKeys();
    const live = all.filter(isCurrentKey).length;
    const past = all.length - live;
    $("#classes-sub").textContent = all.length
      ? `${live} class${live === 1 ? "" : "es"} this semester. Click one to review it.`
        + (past ? ` ${past} from another term ${past === 1 ? "is" : "are"} listed at the bottom.` : "")
      : "Nothing detected yet — press Detect materials (needs Canvas signed in).";
    renderClassGrid($("#classes-grid"), $("#class-detail"));
    if (SELECTED_COURSE) renderClassDetail($("#class-detail"));
    const btn = $("#classes-detect");
    btn.onclick = () => learnClasses($("#classes-progress"), btn,
      () => renderClassGrid($("#classes-grid"), $("#class-detail")));
  }

  const KIND_ORDER = ["textbook", "textbook_mention", "syllabus", "schedule_doc", "tool",
                      "resource", "video", "canvas", "website", "other"];
  const KIND_LABEL = { textbook: "Textbook", textbook_mention: "Textbook named, no link yet",
    syllabus: "Syllabus", schedule_doc: "Teacher's homework doc", tool: "Tools", resource: "Docs & files",
    video: "Videos", canvas: "Canvas pages", website: "Websites", other: "Other" };

  function materialRow(m) {
    const title = m.title || m.url || "(untitled)";
    const titleHtml = m.url
      ? `<a href="${esc(m.url)}" target="_blank" rel="noopener">${esc(title)}</a>` : esc(title);
    const meta = [(m.sources || []).join(", ")].filter(Boolean).join(" · ");
    return `<div class="mat${m.confirmed ? " confirmed" : ""}${m.kind === "textbook_mention" ? " mention" : ""}" data-id="${esc(m.id)}">
      <input type="checkbox" class="mat-ok" title="this is right" ${m.confirmed ? "checked" : ""}>
      <div><div class="mat-title">${titleHtml}</div>
        <div class="mat-meta">${esc(meta)}${m.notes ? ` · <em>${esc(m.notes)}</em>` : ""}</div></div>
      <div class="mat-actions">
        ${m.kind === "textbook_mention" ? `<button type="button" class="mat-find" title="look this book up">find</button>` : ""}
        <button type="button" class="mat-edit" title="rename or re-file">✎</button>
        <button type="button" class="mat-hide" title="not useful — hide it">×</button>
      </div></div>`;
  }

  /* Drawn into TWO hosts — #class-detail and the wizard's #setup-class-detail
     — with the same element ids, so every lookup is scoped to `host`. */
  async function renderClassDetail(host) {
    const key = SELECTED_COURSE;
    if (!key) { host.hidden = true; return; }
    host.hidden = false;
    const at = (sel) => host.querySelector(sel);
    let record = COURSES[key];
    const profile = ((STATE && STATE.profiles) || []).find((p) => p.course_key === key) || {};
    if (!record) {
      record = { course_key: key, display_name: courseName(key), teacher: profile.teacher,
                 room: (profile.meeting || {}).typical_room, canvas_url: profile.canvas_url,
                 materials: [], notes: "", announcements: [] };
    }
    const groups = {};
    for (const m of visibleMaterials(record)) (groups[m.kind] = groups[m.kind] || []).push(m);
    const hidden = (record.materials || []).filter((m) => m.hidden);
    const sections = KIND_ORDER.filter((k) => groups[k]).map((k) =>
      `<div class="cd-section"><h4>${esc(KIND_LABEL[k] || k)}</h4>${groups[k].map(materialRow).join("")}</div>`).join("");
    host.innerHTML = `
      <div class="cd-head"><div><h3>${esc(record.display_name || courseName(key))}</h3>
        <div class="cd-sub">${esc([record.teacher, record.room ? "room " + record.room : "",
          record.term].filter(Boolean).join(" · "))}
          ${record.canvas_url ? ` · <a href="${esc(record.canvas_url)}" target="_blank" rel="noopener">Canvas</a>` : ""}
          · <a href="#" class="cd-grades">grades</a></div></div>
        <button type="button" class="fold-btn" id="cd-close" aria-label="close">×</button></div>
      ${sections || `<div class="empty-note">nothing detected for this class yet</div>`}
      <div class="cd-section"><h4>Find the textbook</h4>
        <form id="cd-find" class="cd-add-row"><input type="text" placeholder="title, author or ISBN" required>
          <button type="submit" class="ghost">Search</button></form>
        <div id="cd-find-results"></div></div>
      <div class="cd-section"><h4>Add a link</h4>
        <form id="cd-add">
          <input type="text" name="title" placeholder="what is it? e.g. Class Quizlet" maxlength="160" class="cd-input">
          <div class="cd-add-row" style="margin-top:6px"><input type="url" name="url" placeholder="https://…">
            <select name="kind"><option value="other">work it out</option><option value="textbook">textbook</option>
              <option value="syllabus">syllabus</option><option value="tool">tool</option><option value="resource">doc/file</option>
              <option value="video">video</option><option value="website">website</option></select></div>
          <div class="add-actions" style="margin-top:6px"><button type="submit" class="primary">Add</button></div></form></div>
      <div class="cd-section"><h4>Your notes about this class</h4>
        <textarea id="cd-notes" class="field" placeholder="e.g. quizzes every Friday · he checks homework at the door · textbook login is my school email">${esc(record.notes || "")}</textarea>
        <p class="note" id="cd-notes-note"></p></div>
      ${(record.announcements || []).length ? `<div class="cd-section"><h4>Recent announcements</h4>${
        record.announcements.slice(0, 5).map((a) => `<div class="ann"><a href="${esc(a.url || "#")}" target="_blank" rel="noopener">${esc(a.title)}</a>
          <span class="ann-when">${esc((a.posted_at || "").slice(0, 10))}</span>
          <div class="ann-text">${esc((a.text || "").slice(0, 220))}</div></div>`).join("")}</div>` : ""}
      <div class="cd-section"><h4>How homework is read</h4>
        <div class="muted">${esc(profile.homework_source === "doc" || profile.homework_source === "both"
          ? "from the teacher's doc" + (profile.learned_by === "heuristic" ? " — format NOT learned yet (heuristics only)" : ` — learned by ${profile.learned_by || "?"}`)
          : profile.homework_source === "canvas" ? "from Canvas assignments" : profile.homework_source === "none"
          ? "no homework expected (" + (profile.verified_zero_reason || "not academic") + ")" : "unknown — learn the class first")}
          ${profile.confidence != null ? ` · confidence ${Math.round(profile.confidence * 100)}%` : ""}</div>
        <div class="row-actions">
          <button type="button" class="ghost" id="cd-relearn">Relearn the format</button>
          <button type="button" class="ghost" id="cd-rescan">Rescan materials</button>
          <button type="button" class="primary" id="cd-reviewed">${record.reviewed_at ? "Reviewed ✓ — mark again" : "Mark as reviewed"}</button>
        </div><p class="note" id="cd-note"></p></div>
      ${hidden.length ? `<details class="cd-section"><summary class="muted">${hidden.length} hidden link(s)</summary>${
        hidden.map((m) => `<div class="mat"><span></span><div class="mat-title">${esc(m.title || m.url)}</div>
          <div class="mat-actions"><button type="button" class="mat-unhide" data-id="${esc(m.id)}">restore</button></div></div>`).join("")}</details>` : ""}`;

    const note = at("#cd-note");
    const say = (t, cls) => { note.textContent = t; note.className = "note " + (cls || ""); };
    const reload = async () => { await loadCourses(); renderClassDetail(host);
      const grid = host.id === "class-detail" ? $("#classes-grid") : $("#setup-classes-grid");
      if (grid) renderClassGrid(grid, host); };
    at("#cd-close").addEventListener("click", () => { SELECTED_COURSE = null; host.hidden = true;
      document.querySelectorAll(".class-card").forEach((x) => x.classList.remove("selected")); });
    at(".cd-grades").addEventListener("click", (ev) => { ev.preventDefault(); openGradePane(key); });

    host.querySelectorAll(".mat").forEach((row) => {
      const id = row.dataset.id;
      if (!id) return;
      const ok = row.querySelector(".mat-ok");
      if (ok) ok.addEventListener("change", async () => {
        await put(`/api/courses/${key}`, { materials: [{ id, confirmed: ok.checked }] }); reload(); });
      const hide = row.querySelector(".mat-hide");
      if (hide) hide.addEventListener("click", async () => {
        await del(`/api/courses/${key}/materials/${id}`); reload(); });
      const edit = row.querySelector(".mat-edit");
      if (edit) edit.addEventListener("click", async () => {
        const m = (record.materials || []).find((x) => x.id === id) || {};
        const title = prompt("Name for this link:", m.title || "");
        if (title === null) return;
        const kind = prompt("File it as (textbook, syllabus, tool, resource, video, website, other):", m.kind || "other");
        if (kind === null) return;
        await put(`/api/courses/${key}`, { materials: [{ id, title, kind: kind.trim() }] }); reload(); });
      const find = row.querySelector(".mat-find");
      if (find) find.addEventListener("click", () => {
        const m = (record.materials || []).find((x) => x.id === id) || {};
        const input = at("#cd-find input"); input.value = m.isbn || m.title || "";
        at("#cd-find").requestSubmit(); });
    });
    host.querySelectorAll(".mat-unhide").forEach((b) => b.addEventListener("click", async () => {
      await put(`/api/courses/${key}`, { materials: [{ id: b.dataset.id, hidden: false }] }); reload(); }));

    at("#cd-find").addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const q = at("#cd-find input").value.trim();
      const out = at("#cd-find-results");
      out.innerHTML = `<div class="muted">searching…</div>`;
      try {
        const res = await api(`/api/textbooks/search?q=${encodeURIComponent(q)}`);
        const links = `<a href="${esc(res.search_links.google_books)}" target="_blank" rel="noopener">Google Books</a>,
          <a href="${esc(res.search_links.open_library)}" target="_blank" rel="noopener">Open Library</a> or
          <a href="${esc(res.search_links.internet_archive)}" target="_blank" rel="noopener">the Internet Archive</a>`;
        const down = (res.unavailable || []).length
          ? `<div class="muted">${esc(res.unavailable.join(" and "))} did not answer just now,
             so this list may be short. Searching by hand still works: ${links}.</div>` : "";
        if (!res.results.length) {
          out.innerHTML = down || `<div class="muted">nothing matched${res.isbn
            ? ` ISBN ${esc(res.isbn)}` : ""} in any catalogue. Try on ${links}.</div>`;
          return;
        }
        out.innerHTML = down + res.results.slice(0, 8).map((r, i) => `<div class="tb-result">
          ${r.cover ? `<img src="${esc(r.cover)}" alt="">` : "<span></span>"}
          <div><strong>${esc(r.title)}</strong>${r.subtitle ? `: ${esc(r.subtitle)}` : ""}
            <div class="muted">${esc([r.authors.slice(0, 2).join(", "), r.publisher, r.year].filter(Boolean).join(" · "))}
              ${r.isbn13 ? ` · ISBN ${esc(r.isbn13)}` : ""}</div>
            ${r.free_url ? `<div class="tb-free">free/borrowable copy: <a href="${esc(r.free_url)}" target="_blank" rel="noopener">open</a></div>` : ""}
            ${r.preview_url ? `<a class="muted" href="${esc(r.preview_url)}" target="_blank" rel="noopener">preview</a>` : ""}</div>
          <button type="button" class="ghost tb-save" data-i="${i}">Bookmark</button></div>`).join("");
        out.querySelectorAll(".tb-save").forEach((b) => b.addEventListener("click", async () => {
          const r = res.results[Number(b.dataset.i)];
          b.disabled = true;
          await post(`/api/courses/${key}/materials`, {
            title: r.title + (r.authors.length ? ` — ${r.authors[0]}` : ""),
            url: r.free_url || r.catalog_url || r.preview_url, kind: "textbook", isbn: r.isbn13,
            notes: r.free_url ? "free/borrowable copy" : (r.source || "").replace("_", " ") });
          reload();
        }));
      } catch (err) { out.innerHTML = `<div class="muted">search failed: ${esc(err.message)}</div>`; }
    });

    at("#cd-add").addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const f = ev.target;
      if (!f.title.value.trim() && !f.url.value.trim()) return;
      await post(`/api/courses/${key}/materials`, { title: f.title.value.trim(), url: f.url.value.trim(), kind: f.kind.value });
      reload();
    });
    const notes = at("#cd-notes");
    notes.addEventListener("blur", async () => {
      if (notes.value === (record.notes || "")) return;
      await put(`/api/courses/${key}`, { notes: notes.value });
      at("#cd-notes-note").textContent = "saved"; at("#cd-notes-note").className = "note ok";
      await loadCourses();
    });
    at("#cd-reviewed").addEventListener("click", async () => {
      await put(`/api/courses/${key}`, { reviewed: true }); say("marked as reviewed", "ok"); reload(); await refreshSetup(); });
    at("#cd-rescan").addEventListener("click", async () => {
      const b = at("#cd-rescan"); b.disabled = true; say("rescanning…");
      try { await pollJob(await post("/api/courses/detect", { course_key: key }), (t) => say(t)); say("rescanned", "ok"); reload(); }
      catch (err) { say("could not rescan: " + err.message, "bad"); }
      b.disabled = false; });
    at("#cd-relearn").addEventListener("click", async () => {
      const b = at("#cd-relearn"); b.disabled = true; say("relearning how this teacher writes homework (one model call)…");
      try { const out = await post(`/api/profiles/${key}/relearn`, {}); say(out.ok ? "relearned — refresh to see the effect" : (out.report || "").slice(-200), out.ok ? "ok" : "bad"); await loadState(); }
      catch (err) { say("could not relearn: " + err.message, "bad"); }
      b.disabled = false; });
  }

  /* Chips for the item pane: the class's textbook and syllabus. */
  window.courseMaterialsHtml = function (courseKey) {
    const s = SUMMARIES[courseKey];
    if (!s) return "";
    const chips = [];
    for (const t of (s.textbooks || []).slice(0, 2))
      chips.push(`<a class="linkbtn" href="${esc(t.url)}" target="_blank" rel="noopener" title="${esc(t.title)}">📘 ${esc((t.title || "Textbook").slice(0, 28))}</a>`);
    for (const t of (s.syllabus || []).slice(0, 1))
      chips.push(`<a class="linkbtn" href="${esc(t.url)}" target="_blank" rel="noopener">📄 Syllabus</a>`);
    chips.push(`<a class="linkbtn" href="/classes" data-class="${esc(courseKey)}">🏫 Class setup</a>`);
    return `<div class="detail-materials">${chips.join("")}</div>`;
  };
  document.addEventListener("click", (ev) => {
    const a = ev.target.closest("a[data-class]");
    if (!a) return;
    ev.preventDefault();
    SELECTED_COURSE = a.dataset.class;
    showView("classes");
  });

  /* ---------------- the GRADE pane ----------------
     *"when you click on a class in the grade panel, it should open the grade
     details in the middle and in an easy to comprehend way show all your
     grades and have something to show the % of your grade each assignment is
     bc some are weighted. section them based on their category too."*

     Columns, one per kind of work, each mark with its score and its share of
     the grade. Where the share comes from is said out loud, because it is
     the only part that can be wrong:
       veracross — the gradebook of record: Veracross's own category weights,
                   which reproduce the report-card percentage exactly.
       canvas    — Canvas group weights. Kept for a school where Canvas is
                   the gradebook; not used here.
       syllabus  — weights the student typed in from the syllabus; by kind.
       points    — a mark's share is its points over all points marked so far.
     Since 0.18.6.0 the marks and the weights both come from Veracross —
     *"i want the grades and assignment grades to only be pulled from
     veracross not canvas because how the classes are weighted is only in
     veracross"* — so on this school's data these numbers ARE the
     report-card grade rather than a second opinion on it. [MEASURED]
     2026-09-09: Canvas held 0 scores and 0 weights across all ten courses.
     What it never does: claim a kind is "dragging the grade down". */
  function scoresFor(key) {
    return ((STATE && STATE.scores) || []).filter((s) => s.course_key === key);
  }
  /* `extra` is a hypothetical mark — the what-if calculator's whole
     mechanism. It goes through this function rather than a formula of its
     own, because a projection that disagreed with the columns above it would
     be worse than no projection at all. */
  function gradeShares(key, extra) {
    /* COPIES of the marks, not the objects in STATE. `_share` and `_earned`
       are written onto each mark below, and the what-if calculator runs this
       whole function again with a hypothetical mark in the pool — which
       recomputes every real mark's share against an inflated total. Writing
       that back into STATE means the next thing to read `_share` (the columns,
       on any later paint) shows a share that includes an assignment nobody
       has been set. Nothing outside this function may see those fields. */
    const scores = scoresFor(key).filter((s) => !s.omit).map((s) => ({ ...s }));
    if (extra) scores.push({ ...extra });
    const book = ((STATE && STATE.gradebook) || {})[key] || {};
    const manual = ((SUMMARIES[key] || {}).weights) || null;
    const groups = [];
    let mode = "points";
    const pool = (list) => list.reduce((t, m) => t + (m.possible || 0), 0);

    if (book.source === "veracross" && (book.groups || []).length) {
      /* Veracross gives the categories in BOTH weighting methods, so the
         columns come from the gradebook rather than from guessing a kind off
         each title. `method === "type"` carries real weights; "points" has
         none and falls through to the points arithmetic below, which is the
         same sum Veracross does. Keyed as strings: these ids are name slugs
         ("class-participation"), not Canvas's numbers. */
      mode = book.method === "type" ? "veracross" : "points";
      const byGroup = new Map((book.groups || []).map((g) => [String(g.id),
        { key: String(g.id), name: g.name || "group", weight: g.weight, marks: [] }]));
      const other = { key: "other", name: "other", weight: 0, marks: [] };
      for (const s of scores) {
        const g = byGroup.get(String(s.group_id));
        (g ? g.marks : other.marks).push(s);
      }
      for (const g of byGroup.values()) groups.push(g);
      if (other.marks.length) groups.push(other);
    } else if (book.weighted && (book.groups || []).length) {
      mode = "canvas";
      const byGroup = new Map((book.groups || []).map((g) => [g.id, { key: String(g.id), name: g.name || "group",
                                                                     weight: g.weight, marks: [] }]));
      const other = { key: "other", name: "other", weight: 0, marks: [] };
      for (const s of scores) {
        const g = byGroup.get(s.group_id);
        (g ? g.marks : other.marks).push(s);
      }
      for (const g of byGroup.values()) groups.push(g);
      if (other.marks.length) groups.push(other);
    } else {
      const byKind = new Map();
      for (const s of scores) {
        const kind = s.category || "other";
        if (!byKind.has(kind)) byKind.set(kind, { key: kind, name: SD.kindName ? SD.kindName(kind) : kind, weight: null, marks: [] });
        byKind.get(kind).marks.push(s);
      }
      const order = (SD.GRADE_KINDS || []);
      groups.push(...[...byKind.values()].sort((a, b) => order.indexOf(a.key) - order.indexOf(b.key)));
      if (manual && Object.keys(manual).length) {
        mode = "syllabus";
        for (const g of groups) g.weight = manual[g.key] != null ? Number(manual[g.key]) : 0;
        for (const kind of Object.keys(manual)) {
          if (!byKind.has(kind) && Number(manual[kind]) > 0) {
            groups.push({ key: kind, name: SD.kindName ? SD.kindName(kind) : kind, weight: Number(manual[kind]), marks: [] });
          }
        }
      }
    }
    /* Canvas's rule: groups with no marks yet do not count yet — the weights
       of the groups that do have marks are scaled to 100 between them. */
    if (mode === "points") {
      const total = pool(scores);
      for (const g of groups) {
        g.effective = total ? pool(g.marks) / total * 100 : 0;
        for (const m of g.marks) {
          m._share = total ? (m.possible / total) * 100 : 0;
          // `possible` is never 0 from Canvas (scores_from_assignments skips
          // those), but a hypothetical mark comes from a text box. One
          // division by zero here is NaN, and NaN propagates through the sum
          // to make the WHOLE class grade "NaN%".
          m._earned = m.possible ? m._share * (m.score / m.possible) : 0;
        }
      }
    } else {
      const live = groups.filter((g) => g.marks.length && (g.weight || 0) > 0);
      const sum = live.reduce((t, g) => t + g.weight, 0);
      for (const g of groups) {
        g.effective = g.marks.length && sum ? g.weight / sum * 100 : 0;
        const p = pool(g.marks);
        for (const m of g.marks) {
          m._share = p ? (m.possible / p) * g.effective : 0;
          m._earned = m.possible ? m._share * (m.score / m.possible) : 0;
        }
      }
    }
    const earned = groups.reduce((t, g) => t + g.marks.reduce((u, m) => u + m._earned, 0), 0);
    /* `source` is for the WORDS, `mode` is for the arithmetic. A Veracross
       points-weighted class computes exactly like a points class and must not
       be described like one ("no weights are known" is false — points ARE the
       weighting the teacher chose). */
    return { mode, groups, earned, book, manual, count: scores.length,
             source: book.source || (book.weighted ? "canvas" : "") };
  }

  /* ---------------- what if I get… ----------------
     *"a grade calculator for a hypothetical assignment where I enter the
     grade and the category. Then it would tell me what my grade in the class
     would be if I got a 9/10 or a 10/10"*.

     Two honesty rules, both load-bearing:

     * It projects the number CANVAS's marks come to, not the report-card
       grade. Those two already disagree in six of his seven graded classes
       (the pane says so above), and a calculator that implied it was moving
       the Veracross grade would be inventing a grade fact.
     * With nothing marked yet there is nothing to project from, and it says
       that instead of showing a number.
   */
  function projectedPercent(key, groupKey, score, possible) {
    const shares = gradeShares(key);
    const extra = { score, possible, omit: false, title: "what if" };
    if (shares.source === "veracross") {
      /* Grouped by `group_id` in BOTH Veracross modes, so the hypothetical
         mark has to carry one or it lands in "other" — where, in a
         points class, it would still be counted (right answer, wrong column)
         and in a weighted class would be given weight 0 and silently ignored,
         making every projection read "no change". */
      extra.group_id = String(groupKey);
      extra.category = groupKey;
    } else if (shares.mode === "canvas") {
      const asNumber = Number(groupKey);
      extra.group_id = Number.isNaN(asNumber) ? groupKey : asNumber;
      extra.category = "other";
    } else {
      extra.category = groupKey;
    }
    return gradeShares(key, extra).earned;
  }

  /* The scores worth showing for a mark out of `possible`. Whole marks when
     the assignment is small (his example is out of 10, and "9/10" is the
     question people actually ask); percentage steps when it is not. */
  function whatIfScores(possible) {
    if (!(possible > 0)) return [];
    if (possible <= 25 && Number.isInteger(possible)) {
      const out = [];
      for (let n = possible; n >= 0 && out.length < 5; n--) out.push(n);
      return out;
    }
    // Deduped: rounding to one decimal turns 0.5/0.45/0.4 into 0.5/0.5/0.4,
    // and two identical rows in a table of outcomes reads as a bug.
    const steps = [1, 0.9, 0.8, 0.7, 0.6]
      .map((f) => Math.round(possible * f * 10) / 10);
    return [...new Set(steps)];
  }

  function whatIfHtml(key, state) {
    const shares = gradeShares(key);
    if (!shares.count) {
      return `<div class="whatif"><h4 class="gd-h">What if I get…</h4>
        <p class="gd-none">Nothing is marked for this class yet, so there is no
        grade to work forward from.</p></div>`;
    }
    // Only groups that can actually move the number: in a weighted class a
    // group worth 0% cannot, and offering it would produce a row of zeros.
    const pickable = shares.groups.filter(
      (g) => shares.mode === "points" || (g.weight || 0) > 0 || g.marks.length);
    const canMove = (g) => shares.mode === "points" || (g.weight || 0) > 0;
    const chosen = state.group && pickable.some((g) => g.key === state.group)
      ? state.group
      : (pickable.find((g) => g.marks.length && canMove(g))
         || pickable.find(canMove) || pickable[0] || {}).key;
    const possible = Number(state.possible) > 0 ? Number(state.possible) : 10;
    const base = shares.earned;
    const rows = whatIfScores(possible).map((score) => {
      const after = projectedPercent(key, chosen, score, possible);
      const delta = after - base;
      return `<tr${state.score !== "" && Number(state.score) === score ? ' class="wi-picked"' : ""}>
        <td class="wi-mark">${esc(SD.trimNum(score))}/${esc(SD.trimNum(possible))}</td>
        <td class="wi-pct"><span class="pg-chip band-${SD.gradeBand(after)}">${after.toFixed(2)}%</span></td>
        <td class="wi-delta ${delta >= 0.005 ? "up" : delta <= -0.005 ? "down" : ""}">${
          Math.abs(delta) < 0.005 ? "no change"
            : (delta > 0 ? "+" : "\u2212") + Math.abs(delta).toFixed(2)}</td></tr>`;
    }).join("");
    const exact = state.score !== "" && Number(state.score) >= 0
      ? projectedPercent(key, chosen, Number(state.score), possible) : null;
    return `<div class="whatif">
      <h4 class="gd-h">What if I get… <span class="muted">a mark you have not been given yet</span></h4>
      <div class="wi-form">
        <label>Out of<input type="number" id="wi-possible" min="0.5" step="0.5" value="${esc(String(possible))}"></label>
        <label>Counts as<select id="wi-group" ${shares.mode === "points" ? "disabled" : ""}>${pickable.map((g) =>
          `<option value="${esc(g.key)}" ${g.key === chosen ? "selected" : ""}>${esc(g.name)}${
            shares.mode === "points" ? ""
              : g.weight ? ` — ${g.weight}%`
              : " — 0%, does not count"}</option>`).join("")}</select></label>
        <label>My score<input type="number" id="wi-score" min="0" step="0.5"
          placeholder="optional" value="${esc(String(state.score))}"></label>
      </div>
      ${rows ? `<table class="wi-table"><tbody>${rows}</tbody></table>`
             : `<p class="gd-none">Put in how many points the assignment is out of.</p>`}
      ${exact !== null ? `<p class="wi-exact">With <b>${esc(SD.trimNum(Number(state.score)))}/${esc(SD.trimNum(possible))}</b>
        this class comes to <b>${exact.toFixed(2)}%</b>.</p>` : ""}
      ${shares.mode !== "points" ? "" : shares.source === "veracross"
        ? `<p class="wi-why">Where it counts makes no difference in this class —
        your teacher weights it <b>by points</b>, so every point is worth the
        same wherever it sits and the answer is just points over points.</p>`
        : `<p class="wi-why">Where it counts makes no
        difference in this class — no weights are known, so every point is worth
        the same and the answer is just points over points. Type your syllabus
        weights in above and this will follow them.</p>`}
      <p class="wi-note">Worked out from the ${shares.count} mark${shares.count === 1 ? "" : "s"}
        in this class's gradebook, using the same weighting as the columns above
        (${esc(shares.source === "veracross"
                ? (shares.mode === "veracross"
                   ? "Veracross's own category weights"
                   : "points, which is how this class is weighted")
                : {canvas: "Canvas's own group weights",
                   syllabus: "the weights you typed in",
                   points: "points, since no weights are known"}[shares.mode])}).
        ${shares.source === "veracross"
          ? `These are Veracross's marks and Veracross's weights, so this is your
             <b>report-card</b> grade${shares.book && shares.book.renormalised
               ? ` — as long as the weights hold. Veracross scales them across the
                   kinds of work that have marks so far, so they shift on their own
                   when a category gets its first assignment`
               : ""}.`
          : `It is what <b>Canvas's</b> total would become — the report-card grade is
             Veracross's and can differ.`}</p>
    </div>`;
  }

  function weightsFormHtml(key) {
    const kinds = SD.GRADE_KINDS || [];
    const manual = ((SUMMARIES[key] || {}).weights) || {};
    const present = new Set(scoresFor(key).map((s) => s.category || "other"));
    const shown = kinds.filter((k) => present.has(k) || manual[k] != null);
    for (const k of ["test", "quiz", "problem_set", "project"]) if (!shown.includes(k)) shown.push(k);
    return `<form class="weights-form" id="weights-form">
      ${shown.map((k) => `<label>${esc(SD.kindName ? SD.kindName(k) : k)} %
        <input type="number" min="0" max="100" step="1" name="${esc(k)}" value="${esc(manual[k] != null ? manual[k] : "")}" placeholder="—"></label>`).join("")}
      <div class="wf-actions">
        <button type="submit" class="primary">Save weights</button>
        <button type="button" class="ghost" id="weights-clear">Clear</button>
        <button type="button" class="ghost" id="weights-cancel">Cancel</button>
        <span class="wf-sum" id="weights-sum"></span>
      </div></form>`;
  }

  function markRow(m) {
    const band = SD.gradeBand ? SD.gradeBand(m.percent) : "none";
    const lost = m._share - m._earned;
    return `<div class="gb-mark">
      <span class="gb-title">${m.url ? `<a href="${esc(m.url)}" target="_blank" rel="noopener">${esc(m.title)}</a>` : esc(m.title)}</span>
      <span class="pg-chip gb-pctchip band-${band}">${m.percent.toFixed(0)}%</span>
      <span class="gb-raw">${esc(SD.trimNum(m.score))}/${esc(SD.trimNum(m.possible))}${m.graded_at ? ` · ${esc(niceDate(m.graded_at.slice(0, 10)))}` : ""}</span>
      <span class="gb-share${lost >= 0.5 ? " lost" : ""}" title="how much of the class grade this one mark carries${lost >= 0.05 ? `, and how much of that was lost` : ""}">${m._share.toFixed(1)}% of grade${lost >= 0.05 ? ` · −${lost.toFixed(1)}` : ""}</span>
    </div>`;
  }

  function strengthsHtml(key) {
    const scores = scoresFor(key);
    if (!scores.length) {
      return `<p class="gd-none">No marked work for this class yet, so there is nothing to compare.</p>`;
    }
    const groups = new Map();
    for (const mark of scores) {
      const kind = mark.category || "other";
      if (!groups.has(kind)) groups.set(kind, []);
      groups.get(kind).push(mark);
    }
    const MIN = SD.STRENGTH_MIN_MARKS || 2;
    const rows = [...groups.entries()].map(([kind, marks]) => {
      const mean = marks.reduce((t, m) => t + m.percent, 0) / marks.length;
      return { kind, marks, mean, zeros: marks.filter(m => m.percent === 0).length };
    }).sort((a, b) => a.mean - b.mean);
    const ranked = rows.filter(r => r.marks.length >= MIN);
    const worst = ranked[0];
    const best = ranked[ranked.length - 1];
    const zeros = rows.reduce((t, r) => t + r.zeros, 0);
    const name = SD.kindName || ((k) => k);
    let summary = "";
    if (best && worst && best !== worst) {
      summary = `Your <strong>${esc(name(best.kind))}</strong> come out highest
        (${best.mean.toFixed(0)}% over ${best.marks.length}), and your
        <strong>${esc(name(worst.kind))}</strong> lowest
        (${worst.mean.toFixed(0)}% over ${worst.marks.length}).`;
    } else if (best) {
      summary = `Only <strong>${esc(name(best.kind))}</strong> have enough marks
        to compare — ${best.mean.toFixed(0)}% over ${best.marks.length}.`;
    } else {
      summary = `Not enough marked work yet to compare kinds — a single score is
        an anecdote, so nothing is called a strength or a weakness until there are ${MIN}.`;
    }
    return `<div class="gd-strengths">
      <p class="gd-summary">${summary}</p>
      ${zeros ? `<p class="gd-warn">${zeros} of these scored 0. A piece of work never handed in looks
        the same here as one marked badly — worth checking which it was before reading anything
        into the average.</p>` : ""}
    </div>`;
  }

  function openGradePane(courseKey) {
    if (!courseKey) return;
    GRADE_KEY = courseKey;
    if (window.selectClass) window.selectClass(courseKey);
    window.showPane("grade");
    renderGradePane(courseKey);
    if (!SUMMARIES[courseKey] && !Object.keys(SUMMARIES).length) {
      loadCourses().then(() => { if (GRADE_KEY === courseKey) renderGradePane(courseKey); });
    }
  }
  window.openGradePane = openGradePane;

  /* What the calculator's boxes currently hold, per class. Kept outside the
     render so a keystroke does not reset the other two boxes — the pane
     re-renders on every refresh. */
  const WHATIF = {};
  function whatIfState(key) {
    if (!WHATIF[key]) WHATIF[key] = { possible: 10, group: "", score: "" };
    return WHATIF[key];
  }

  function renderGradePane(courseKey, editing) {
    const body = $("#grade-detail-body");
    const title = $("#grade-detail-title");
    const actions = $("#grade-detail-actions");
    if (!body || !title || courseKey !== GRADE_KEY) return;
    const grade = ((STATE && STATE.grades) || []).find((g) => g.course_key === courseKey);
    const name = shortCourse(grade ? grade.display_name : courseName(courseKey));
    const today = (STATE && STATE.today) || new Date().toISOString().slice(0, 10);
    const mine = ((STATE && STATE.items) || []).filter((i) => i.course_key === courseKey);
    const open = mine.filter((i) => !i.done).sort((a, b) => (a.due_date || "9999") < (b.due_date || "9999") ? -1 : 1);
    const overdue = open.filter((i) => i.due_date && i.due_date < today && !(SD.isPastAssessment && SD.isPastAssessment(i, today)));
    const shares = gradeShares(courseKey);
    const pct = grade && grade.graded && grade.percent != null ? grade.percent : null;
    title.textContent = name;
    actions.innerHTML = `${grade && grade.detail_url
      ? `<a class="linkbtn" href="${esc(grade.detail_url)}" target="_blank" rel="noopener" title="the real gradebook">Veracross ↗</a>` : ""}
      <button type="button" class="mini-btn" id="gd-ask" style="border-color:var(--line)">ask what to work on</button>`;

    const vc = shares.source === "veracross";
    const modeLine = vc
      ? (shares.mode === "veracross"
         ? `<b>Weighted the way your teacher weights this class</b> — ${shares.groups
              .filter((g) => (g.weight || 0) > 0)
              .map((g) => `${esc(g.name)} ${g.weight}%`).join(" · ")
            } — straight from Veracross, the gradebook your report card comes from.${
              shares.book.renormalised ? ` These are the weights <b>as they stand now</b>:
              Veracross spreads them across the kinds of work that have marks so far, so
              they move on their own when a new kind gets its first assignment.` : ""}`
         : `<b>Weighted by points</b> — this class has categories but no percentages,
            so every point counts the same wherever it sits and a mark's share is simply
            its points over all the points marked so far. That is Veracross's own rule
            for this class, not a guess.`)
      : {
      canvas: `<b>Weighted the way Canvas weights this class</b> — each column's weight comes from Canvas's own assignment groups, so a mark's share of the grade is exact for what Canvas holds.`,
      syllabus: `<b>Weighted by the percentages you typed in from the syllabus</b> — columns are kinds of work, and a mark's share is worked out from those.`,
      points: `<b>No weights are known for this class</b> — Canvas adds points straight up here, or has not said. A mark's share is its points over everything marked so far. If the syllabus weights kinds of work, type them in and the shares will follow it.`,
    }[shares.mode];
    /* Does our own arithmetic reproduce the grade Veracross prints? This
       replaced a Canvas-vs-Veracross comparison that no longer means
       anything now that both halves come from the same gradebook — but the
       check itself is worth more than the old one, because it is the page
       auditing ITSELF. If a mark failed to read, or a "Complete" row was
       mishandled, this is where it shows up, and it must never be silently
       reconciled by trusting one number over the other. */
    let agree = "";
    if (vc && pct != null && shares.count) {
      const gap = Math.abs(pct - shares.earned);
      agree = gap <= 0.05
        ? `<div class="gd-note ok">The ${shares.count} mark${shares.count === 1 ? "" : "s"}
             below add up to <b>${shares.earned.toFixed(2)}%</b> — the same as the grade
             Veracross shows, so this is the whole story of the grade so far.</div>`
        : `<div class="gd-note warn">Veracross shows <b>${pct.toFixed(2)}%</b> but the marks
             below add up to <b>${shares.earned.toFixed(2)}%</b>. Something is not being read
             correctly, so trust the ${pct.toFixed(2)}% and treat the shares below as
             approximate${shares.groups.some((g) => g.marks.some((m) => m.check))
               ? ` — a mark with no number in its Score column is the usual cause` : ""}.</div>`;
    }
    const flagged = shares.groups.flatMap((g) => g.marks.filter((m) => m.check));
    if (flagged.length) {
      /* [MEASURED] 2026-09-09: Honors Biology's "Notes Ch 2.3" says
         **Complete** and scores 0.00 out of 10. It is inside the 50%-weighted
         Classwork column, and on its own it costs that class about five
         percentage points. It is not our place to decide whether the teacher
         meant nothing by it — only to make sure he can see it. */
      agree += `<div class="gd-note warn">${flagged.length === 1 ? "One mark counts" :
        flagged.length + " marks count"} points against you without a score:
        ${flagged.slice(0, 3).map((m) => `<b>${esc(m.title)}</b> reads
        &ldquo;${esc(m.score_text)}&rdquo; and scores ${esc(SD.trimNum(m.score || 0))} of
        ${esc(SD.trimNum(m.possible))}`).join("; ")}. That may just be a mark your teacher
        has not entered yet — worth asking.</div>`;
    }
    /* *"make the grade page look like it does in canvas"*.
       Canvas's course Grades page is a TABLE — Name, Due, Score, Out of — with
       the assignment groups and the total in a box beside it. That is what
       this is now. The five columns of stacked cards it replaced were his own
       earlier request and they read worse: a mark's date, score and share were
       three lines in a narrow card, and you could not compare two rows without
       moving your eyes sideways across a scrolling strip.

       Two columns are kept that Canvas does not have, because they are the
       reason this page exists: **share of grade** (what this one mark is worth
       out of the whole class) and the category weight on each group header.
       Canvas cannot show either at this school — it has no weights and no
       scores here at all. */
    const cols = shares.groups.filter((g) => g.marks.length || (g.weight || 0) > 0);
    const dueOf = (m) => m.due || (m.due_at ? niceDate(String(m.due_at).slice(0, 10)) : "");
    const rowsFor = (g) => g.marks.slice()
      .sort((x, y) => String(x.due || x.due_at || "").localeCompare(String(y.due || y.due_at || "")))
      .map((m) => {
        const band = SD.gradeBand ? SD.gradeBand(m.percent) : "none";
        const lost = m._share - m._earned;
        return `<tr class="gt-row${m.check ? " gt-check" : ""}">
          <td class="gt-name">${m.url
            ? `<a href="${esc(m.url)}" target="_blank" rel="noopener">${esc(m.title)}</a>`
            : esc(m.title)}${m.check
            ? `<span class="gt-flag" title="this reads &ldquo;${esc(m.score_text || "")}&rdquo; and still counts ${esc(SD.trimNum(m.possible))} points against you \u2014 it may just not be entered yet">check</span>`
            : ""}</td>
          <td class="gt-due">${esc(dueOf(m))}</td>
          <td class="gt-score">${esc(SD.trimNum(m.score))}<span class="gt-of">/${esc(SD.trimNum(m.possible))}</span></td>
          <td class="gt-pct"><span class="pg-chip band-${band}">${m.percent.toFixed(0)}%</span></td>
          <td class="gt-share${lost >= 0.5 ? " lost" : ""}"
              title="how much of the whole class grade this one mark carries${lost >= 0.05 ? ", and how much of that was lost" : ""}">${
            m._share.toFixed(1)}%${lost >= 0.05 ? ` <small>\u2212${lost.toFixed(1)}</small>` : ""}</td>
        </tr>`;
      }).join("");
    const colHtml = `<table class="gtable">
      <thead><tr>
        <th class="gt-name">Assignment</th>
        <th class="gt-due">Due</th>
        <th class="gt-score">Score</th>
        <th class="gt-pct">Grade</th>
        <th class="gt-share" title="what this mark is worth out of the whole class grade">Of class</th>
      </tr></thead>
      ${cols.map((g) => {
        const mean = g.marks.length ? g.marks.reduce((t, m) => t + m.percent, 0) / g.marks.length : null;
        const earned = g.marks.reduce((t, m) => t + (m.score || 0), 0);
        const possible = g.marks.reduce((t, m) => t + (m.possible || 0), 0);
        return `<tbody class="gt-group">
          <tr class="gt-head">
            <th class="gt-name" colspan="2">${esc(g.name)}
              <span class="gt-w">${shares.mode === "points"
                ? `${g.effective.toFixed(0)}% of the points so far`
                : `${(g.weight || 0).toFixed(0)}% of the grade${g.marks.length && Math.abs(g.effective - g.weight) > 0.5
                    ? ` (${g.effective.toFixed(0)}% for now)` : ""}`}</span></th>
            <th class="gt-score">${g.marks.length
              ? `${esc(SD.trimNum(earned))}<span class="gt-of">/${esc(SD.trimNum(possible))}</span>` : ""}</th>
            <th class="gt-pct">${mean != null
              ? `<span class="pg-chip band-${SD.gradeBand(mean)}">${mean.toFixed(0)}%</span>` : ""}</th>
            <th class="gt-share">${g.marks.length
              ? `${g.marks.reduce((t, m) => t + m._share, 0).toFixed(0)}%` : ""}</th>
          </tr>
          ${g.marks.length ? rowsFor(g)
            : `<tr class="gt-row gt-empty"><td colspan="5">nothing marked in here yet \u2014 it does not count yet</td></tr>`}
        </tbody>`;
      }).join("")}
    </table>`;

    body.innerHTML = `
      <div class="gd-top">
        <span class="gd-letter band-${SD.gradeBand(pct)}" style="background:none">${esc((grade && grade.letter) || "—")}</span>
        <span class="gd-pct">${pct != null ? esc(pct.toFixed(2)) + "%" : "not graded yet"}</span>
        <span class="gd-sub">${shares.count ? `${shares.count} marked` : "nothing marked yet"}${open.length ? ` · ${open.length} open` : ""}${overdue.length ? ` · <span style="color:var(--danger)">${overdue.length} overdue</span>` : ""}</span>
      </div>
      ${grade && grade.graded === false ? `<div class="gd-note">Veracross has not graded this class yet, so there is no percentage.</div>` : ""}
      ${STATE && STATE.scores_stale ? `<div class="stale-note">marks from ${esc((STATE.scores_stale.as_of || "").slice(0, 10))} — ${esc(STATE.scores_stale.reason || "the gradebook could not be read")}</div>` : ""}
      ${agree}
      <div class="gd-weights"><span>${modeLine}</span>
        ${shares.mode === "canvas" || vc ? "" : `<button type="button" class="mini-btn" id="gd-weights-edit">${shares.manual && Object.keys(shares.manual).length ? "edit syllabus weights" : "set weights from the syllabus"}</button>`}</div>
      ${editing && shares.mode !== "canvas" && !vc ? weightsFormHtml(courseKey) : ""}
      ${cols.length ? `<div class="gb-cols">${colHtml}</div>` : `<p class="gd-none">No marked work for this class yet.</p>`}
      ${shares.count && shares.mode !== "points" ? `<p class="gd-sub" style="margin:2px 0 8px">The shares add up to <b>${shares.earned.toFixed(1)}%</b> earned of the ${shares.groups.filter(g => g.marks.length).reduce((t, g) => t + g.effective, 0).toFixed(0)}% counted so far.</p>` : ""}
      ${shares.count && shares.mode === "points" ? `<p class="gd-sub" style="margin:2px 0 8px">By points alone the marks come to <b>${shares.earned.toFixed(1)}%</b>.</p>` : ""}
      ${whatIfHtml(courseKey, whatIfState(courseKey))}
      <h4 class="gd-h">What you are good at, and what you are not</h4>
      ${strengthsHtml(courseKey)}
      ${open.length ? `<h4 class="gd-h">Open in this class <span class="muted">${open.length}</span></h4>
        <div class="gd-open-rows">${open.slice(0, 12).map((i) => SD.rowHtml(i, "sibling")).join("")}</div>` : ""}
    `;
    body.querySelectorAll(".row-open").forEach((b) => b.addEventListener("click", () => window.openDetail(b.dataset.id)));
    body.querySelectorAll(".row-accel").forEach((b) => b.addEventListener("click", (ev) => {
      ev.stopPropagation();
      const it = (STATE.items || []).find((i) => i.item_id === b.dataset.id);
      if (it) openAccelerate(it.item_id, it.title);
    }));
    body.querySelectorAll(".tick").forEach((t) => t.addEventListener("click", () => window.toggleDone(t.dataset.id, t.checked)));
    const ask = $("#gd-ask");
    if (ask) ask.addEventListener("click", () => {
      const input = $("#chat-input");
      const form = $("#chat-form");
      if (!input || !form) return;
      window.setChatContext({ label: name, sticky: true });
      input.value = `from the work on my board, what should I focus on to bring this grade up, and what is still outstanding?`;
      form.dispatchEvent(new Event("submit", { cancelable: true }));
    });
    const edit = $("#gd-weights-edit");
    if (edit) edit.addEventListener("click", () => renderGradePane(courseKey, !editing));
    /* The calculator redraws only its own block, so the pane does not jump
       and the box being typed in keeps focus. */
    const wi = whatIfState(courseKey);
    const rewire = (field, prop, cast) => {
      const el = $(field);
      if (!el) return;
      el.addEventListener("input", () => {
        wi[prop] = cast ? cast(el.value) : el.value;
        const host = body.querySelector(".whatif");
        if (!host) return;
        const at = document.activeElement && document.activeElement.id;
        const caret = el.selectionStart;
        host.outerHTML = whatIfHtml(courseKey, wi);
        rewireAll();
        const again = at && $("#" + at);
        if (again) {
          again.focus();
          try { again.setSelectionRange(caret, caret); } catch (e) { /* number inputs */ }
        }
      });
    };
    function rewireAll() {
      rewire("#wi-possible", "possible", (v) => v);
      rewire("#wi-score", "score", (v) => v);
      const g = $("#wi-group");
      if (g) g.addEventListener("change", () => {
        wi.group = g.value;
        const host = body.querySelector(".whatif");
        if (host) { host.outerHTML = whatIfHtml(courseKey, wi); rewireAll(); }
      });
    }
    rewireAll();
    const form = $("#weights-form");
    if (form) {
      const sum = $("#weights-sum");
      const total = () => {
        const t = [...form.querySelectorAll("input")].reduce((s, i) => s + (Number(i.value) || 0), 0);
        sum.textContent = t ? `adds up to ${t}%` : "";
        sum.classList.toggle("bad", t > 0 && Math.abs(t - 100) > 0.5);
      };
      form.addEventListener("input", total); total();
      form.addEventListener("submit", async (ev) => {
        ev.preventDefault();
        const weights = {};
        for (const i of form.querySelectorAll("input")) if (i.value !== "") weights[i.name] = Number(i.value);
        await put(`/api/courses/${courseKey}`, { weights });
        await loadCourses();
        renderGradePane(courseKey, false);
      });
      $("#weights-clear").addEventListener("click", async () => {
        await put(`/api/courses/${courseKey}`, { weights: null });
        await loadCourses();
        renderGradePane(courseKey, false);
      });
      $("#weights-cancel").addEventListener("click", () => renderGradePane(courseKey, false));
    }
    if (window.setChatContext && window.currentPane && window.currentPane() === "grade") {
      window.setChatContext({ label: name });
    }
  }
  window.renderGradePane = (key) => renderGradePane(key, false);

  /* ---------------- SETTINGS ---------------- */
  const THEMES = [
    ["system", "System", "linear-gradient(90deg,#fff 50%,#0D1220 50%)"],
    ["light", "Light", "#FFFFFF"],
    ["offwhite", "Off-white", "#F3EFE7"],
    ["dark", "Dark", "#0D1220"],
  ];
  const ACCENTS = ["#2563EB", "#4F46E5", "#7C3AED", "#DB2777", "#DC2626", "#EA580C",
                   "#D97706", "#16A34A", "#0D9488", "#0891B2", "#475569", "#111827"];
  const FONTS = [["modern", "Modern"], ["system", "System"], ["rounded", "Rounded"],
                 ["serif", "Serif"], ["mono", "Mono"]];

  function renderAppearance() {
    const host = $("#appearance-host");
    if (!host) return;
    const p = window.getPrefs();
    const custom = !ACCENTS.some((a) => a.toLowerCase() === (p.accent || "").toLowerCase());
    host.innerHTML = `
      <div class="pref"><div class="pref-label">Theme</div>
        <div class="pref-row">${THEMES.map(([k, label, swatch]) => `<button type="button" class="pref-opt theme-opt${p.theme === k ? " active" : ""}" data-theme-opt="${k}">
          <span class="theme-swatch" style="background:${swatch}"></span>${label}</button>`).join("")}</div></div>
      <div class="pref"><div class="pref-label">Accent colour</div>
        <div class="swatches">${ACCENTS.map((a) => `<button type="button" class="swatch${(p.accent || "").toLowerCase() === a.toLowerCase() ? " active" : ""}"
            style="background:${esc(a)}" data-accent="${esc(a)}" title="${esc(a)}" aria-label="accent ${esc(a)}"></button>`).join("")}
          <span class="accent-custom" title="any colour — the wheel opens the system picker">
            <input type="color" id="accent-picker" value="${esc(p.accent || "#2563EB")}" aria-label="pick any accent colour">
            <input type="text" id="accent-hex" value="${esc(p.accent || "#2563EB")}" maxlength="7" spellcheck="false" aria-label="accent as hex">
            ${custom ? `<span class="muted">custom</span>` : ""}</span></div></div>
      <div class="pref"><div class="pref-label">Font set</div>
        <div class="pref-row">${FONTS.map(([k, label]) => `<button type="button" class="pref-opt font-opt${p.font === k ? " active" : ""}" data-font="${k}">${label}</button>`).join("")}</div></div>
      <div class="pref"><div class="pref-label">Text size</div>
        <div class="pref-range"><input type="range" id="text-size" min="12" max="17" step="0.5" value="${esc(p.textSize)}"><output id="text-size-out">${esc(p.textSize)}px</output></div></div>
      <div class="pref"><div class="pref-label">Density</div>
        <div class="pref-row">${[["compact", "Compact"], ["normal", "Normal"], ["roomy", "Roomy"]].map(([k, label]) =>
          `<button type="button" class="pref-opt${p.density === k ? " active" : ""}" data-density="${k}">${label}</button>`).join("")}</div></div>
      <div class="pref"><div class="pref-label">Motion</div>
        <div class="pref-row">${[["on", "Animations on"], ["off", "Reduce motion"]].map(([k, label]) =>
          `<button type="button" class="pref-opt${p.motion === k ? " active" : ""}" data-motion="${k}">${label}</button>`).join("")}</div></div>
      <div class="pref"><button type="button" class="ghost" id="prefs-reset">Reset appearance and layout</button></div>`;
    host.querySelectorAll("[data-theme-opt]").forEach((b) => b.addEventListener("click", () => { window.savePrefs({ theme: b.dataset.themeOpt }); renderAppearance(); }));
    host.querySelectorAll("[data-accent]").forEach((b) => b.addEventListener("click", () => { window.savePrefs({ accent: b.dataset.accent }); renderAppearance(); }));
    const picker = $("#accent-picker"), hex = $("#accent-hex");
    picker.addEventListener("input", () => { hex.value = picker.value; window.savePrefs({ accent: picker.value }); });
    picker.addEventListener("change", () => renderAppearance());
    hex.addEventListener("change", () => {
      let v = hex.value.trim();
      if (/^[0-9a-fA-F]{6}$/.test(v)) v = "#" + v;
      if (/^#[0-9a-fA-F]{6}$/.test(v)) { window.savePrefs({ accent: v.toUpperCase() }); renderAppearance(); }
      else hex.value = window.getPrefs().accent;
    });
    host.querySelectorAll("[data-font]").forEach((b) => b.addEventListener("click", () => { window.savePrefs({ font: b.dataset.font }); renderAppearance(); }));
    host.querySelectorAll("[data-density]").forEach((b) => b.addEventListener("click", () => { window.savePrefs({ density: b.dataset.density }); renderAppearance(); }));
    host.querySelectorAll("[data-motion]").forEach((b) => b.addEventListener("click", () => { window.savePrefs({ motion: b.dataset.motion }); renderAppearance(); }));
    const size = $("#text-size"), out = $("#text-size-out");
    size.addEventListener("input", () => { out.textContent = `${size.value}px`; window.savePrefs({ textSize: Number(size.value) }); });
    $("#prefs-reset").addEventListener("click", () => {
      try { localStorage.removeItem("schooldash.prefs"); localStorage.removeItem("schooldash.panels"); localStorage.removeItem("schooldash.theme"); } catch (e) { /* ok */ }
      location.reload();
    });
  }
  window.renderAppearance = renderAppearance;

  /* ---------------- which layout ----------------
     The chooser on the first run is the same choice as this, so they must not
     be able to disagree: both write `layout` through savePrefs and both read
     it back from getPrefs. Switching here re-renders the whole board rather
     than reloading the page — the layout is CSS plus one attribute, so a
     reload would only lose the scroll position. */
  const LAYOUTS = [
    ["dash", "Dashboard", "Everything on one screen: grades and calendar on the left, "
      + "all your work on the right, chat in the middle. Nothing to click for, more to read."],
    ["simple", "Simple", "One page at a time, with tabs across the top \u2014 Today, Tests, "
      + "Personal, Grades, Calendar, Chat, Classes, Done, Settings. Easier to read, "
      + "one tap to move."],
  ];
  function renderLayoutPrefs() {
    const host = $("#layout-host");
    if (!host) return;
    const p = window.getPrefs();
    host.innerHTML = `
      <div class="pref"><div class="pref-label">How it looks</div>
        <div class="lp-options lp-inline">${LAYOUTS.map(([k, label, desc]) => `
          <button type="button" class="lp-opt${p.layout === k ? " active" : ""}" data-layout-opt="${k}">
            <span class="lp-mini ${k === "dash" ? "lp-mini-dash" : "lp-mini-simple"}" aria-hidden="true">${
              k === "dash"
                ? `<span class="lp-m-side"></span><span class="lp-m-mid"></span><span class="lp-m-side"></span>`
                : `<span class="lp-m-tabs"><i></i><i></i><i></i><i></i></span><span class="lp-m-page"></span>`
            }</span>
            <b>${esc(label)}</b><span class="lp-desc">${esc(desc)}</span></button>`).join("")}</div></div>
      <p class="muted">The two show the same data from the same place \u2014 they are two ways of
        arranging one app, not two apps. Anything you tick off, add or ask in one is
        already there in the other.</p>`;
    host.querySelectorAll("[data-layout-opt]").forEach((b) => b.addEventListener("click", () => {
      window.savePrefs({ layout: b.dataset.layoutOpt });
      renderLayoutPrefs();
      if (window.render) window.render();
    }));
  }
  window.renderLayoutPrefs = renderLayoutPrefs;

  function renderBoardPrefs() {
    const host = $("#board-prefs-host");
    if (!host) return;
    const p = window.getPrefs();
    const opts = (name, pairs, current) => `<div class="pref-row">${pairs.map(([k, label]) =>
      `<button type="button" class="pref-opt${current === k ? " active" : ""}" data-pref="${esc(name)}" data-value="${esc(String(k))}">${esc(label)}</button>`).join("")}</div>`;
    host.innerHTML = `
      <div class="pref"><div class="pref-label">Grades order</div>${opts("gradeSort", [["low", "Lowest first"], ["name", "A to Z"]], p.gradeSort)}</div>
      <div class="pref"><div class="pref-label">Assignments order</div>${opts("assignSort", [["smart", "Smart"], ["due", "By date"], ["class", "By class"], ["time", "Longest first"]], p.assignSort)}
        <p class="muted" style="margin:4px 0 0">Smart is the board's own ranking: how soon it is due, what kind of work it is, how many points, and a nudge for classes with a lower grade — longer work first when two tie.</p></div>
      <div class="pref"><div class="pref-label">Calendar opens as</div>${opts("calendar", [["day", "Day"], ["week", "Week"]], p.calendar)}</div>
      <div class="pref"><div class="pref-label">Week view</div>${opts("showWeekends", [[false, "Weekdays"], [true, "Include weekends"]], !!p.showWeekends)}</div>
      <div class="pref"><div class="pref-label">Keyboard</div>
        <p class="muted" style="margin:0"><b>⌘K</b> jump anywhere · <b>/</b> type in chat · <b>Esc</b> back to chat · <b>[</b> <b>]</b> hide a side · <b>r</b> refresh</p></div>`;
    host.querySelectorAll("[data-pref]").forEach((b) => b.addEventListener("click", () => {
      let v = b.dataset.value;
      if (v === "true") v = true; else if (v === "false") v = false;
      window.savePrefs({ [b.dataset.pref]: v });
      renderBoardPrefs();
      if (window.render) window.render();
    }));
  }

  async function renderSettings() {
    renderLayoutPrefs();
    renderAppearance();
    renderBoardPrefs();
    await refreshSetup();
    accountsForm($("#accounts-form-host"), { saveLabel: "Save" });
    const s = SETUP || {};
    const c = s.canvas || {}, v = s.veracross || {};
    $("#connections-body").innerHTML = `
      <dt>Canvas</dt><dd class="${c.signed_in ? "ok-dot" : "bad-dot"}">${c.signed_in ? `signed in${c.name ? " as " + esc(c.name) : ""}` : "not signed in"}
        ${c.checked_at ? `<span class="muted"> (checked ${esc(c.checked_at.slice(0, 16).replace("T", " "))})</span>` : ""}</dd>
      <dt>Veracross</dt><dd class="${v.signed_in ? "ok-dot" : "warn-dot"}">${v.signed_in ? "signed in" : "not signed in or not checked yet"}</dd>
      <dt>Class schedule</dt><dd class="${v.class_feed ? "ok-dot" : "bad-dot"}">${v.class_feed ? `${v.meetings} class meetings on file` : "no feed saved"}</dd>
      <dt>Grades</dt><dd>${v.grades ? `${v.grades} courses` : "none read yet"}</dd>
      <dt>Classes</dt><dd>${(s.profiles || {}).count || 0} profiles${(s.profiles || {}).heuristic ? ` (${s.profiles.heuristic} unlearned)` : ""} · ${(s.courses || {}).reviewed || 0}/${(s.courses || {}).count || 0} reviewed</dd>`;
    const note = $("#settings-connect-note");
    $("#settings-connect").onclick = async () => {
      const b = $("#settings-connect"); b.disabled = true;
      try {
        const out = await runLogin("all", (t) => { note.textContent = t; });
        note.innerHTML = (out.results || []).map(siteResultHtml).join("") || esc(out.output || "");
        await refresh(); renderSettings();
      } catch (err) { note.textContent = "could not start: " + err.message; }
      b.disabled = false;
    };
    $("#settings-refresh").onclick = async () => { await refresh(); renderSettings(); };
    $("#settings-reminders").onclick = async () => {
      const b = $("#settings-reminders"); b.disabled = true;
      try { const out = await post("/api/setup/reminders", {}); note.textContent = out.message || "reminders scheduled (7am & 5pm, refresh every 30 min)"; }
      catch (err) { note.textContent = "could not schedule: " + err.message; }
      b.disabled = false;
    };
    let health = {};
    try { health = await api("/api/health"); } catch (e) { /* fine */ }
    const ps = (STATE && STATE.provider_status) || {};
    const upd = window.updateStatus && window.updateStatus();
    const updLine = !upd ? "not checked yet"
      : upd.available ? `<b>${esc(upd.latest)} is available</b>${upd.notes ? ` — ${esc(upd.notes)}` : ""}`
      : upd.error ? `could not check just now (${esc(upd.error)})`
      : upd.latest ? `up to date (latest published is ${esc(upd.latest)})`
      : "no published version to compare with yet";
    $("#app-body").innerHTML = `
      <dt>Version</dt><dd>${esc(health.version || "?")}
        <div class="muted" id="update-line">${updLine}</div>
        <div class="row-actions">
          <button type="button" class="ghost" id="update-check">Check for updates</button>
          ${upd && upd.available && upd.can_install
            ? `<button type="button" class="primary" id="update-now">Update to ${esc(upd.latest)}</button>` : ""}
        </div>
        <p class="note" id="update-settings-note"></p></dd>
      <dt>AI</dt><dd>${esc(health.provider || "none")}${ps.model ? ` (${esc(ps.model)})` : ""}${ps.degraded ? ` <span class="warn-dot">fallback</span>` : ""}
        <div class="muted">Chat, learning a teacher's doc and Accelerate use it. Install Claude Code to turn it on; everything else works without.</div></dd>
      <dt>Data lives in</dt><dd><code>${esc(s.data_home || "")}</code></dd>
      <dt>Last pull</dt><dd>${esc(health.last_run || "never")}${health.stale_hours != null ? ` (${health.stale_hours} h ago)` : ""}</dd>
      <dt>Refreshes</dt><dd>every 30 min 06:00–21:30 while awake; Veracross kept alive every 20 min</dd>`;
    try {
      const acct = await api("/api/session");
      const sub = acct.subscription || {};
      const allow = (STATE && STATE.allowance) || {};
      const kinds = allow.kinds || {};
      const line = (label, k) => {
        const row = kinds[k];
        if (!row || !allow.metered) return "";
        /* An unlimited allowance is `included: 0`, which read as
           "3 of 0 used this month · 0 left" — i.e. exhausted, on the plan
           where it is limitless. */
        if (row.unlimited) {
          return `<dt>${esc(label)}</dt><dd>${row.used} this month · not limited on this plan</dd>`;
        }
        return `<dt>${esc(label)}</dt><dd>${row.used} of ${row.included} used this month`
             + (row.exhausted ? ` · <span class="warn-dot">used up until the 1st</span>` : ` · ${row.left} left`)
             + `</dd>`;
      };
      const usage = allow.metered
        ? `${line("Chat", "chat")}${line("Study guides", "accelerate")}${line("Classes learned", "profiles")}`
        : `<dt>Usage</dt><dd>not limited — the model runs on your own Claude access, so nothing is counted</dd>`;
      /* What Free actually is, said where someone on it will look. Without
         this a lapsed account sees "Plan: Free" and no idea what that buys —
         and the half of the app that has no allowance at all is the half
         worth knowing about. */
      const free = (sub.plan === "free" && allow.metered)
        ? `<dt>On Free</dt><dd>${(kinds.chat || {}).included || 0} chat questions that need the
             assistant, ${(kinds.accelerate || {}).included || 0} study guides a month, and
             every class learned from its teacher's document. Resets on the 1st.
             <br>The board, its dates, your schedule, grades, links and ticking work off
             have no limit and never will — they need no AI.</dd>` : "";
      $("#account-body").innerHTML = acct.configured
        ? `<dt>Status</dt><dd>${acct.signed_in ? `signed in as ${esc(acct.email)} · ${esc(sub.state || "")}${sub.days_left != null ? ` (${sub.days_left} days left)` : ""}` : "not signed in"}</dd>
           <dt>Plan</dt><dd>${esc(sub.plan_name || "Basic")}${sub.price && sub.plan !== "free" ? ` · $${esc(sub.price.amount)} a month` : ""}</dd>
           ${free}
           ${usage}
           <dt>Required</dt><dd>${acct.required ? "yes — the board asks for it" : "no — optional on this install"}</dd>
           ${acct.signed_in ? `<dt></dt><dd><button type="button" class="ghost" id="acct-out">Sign out</button></dd>` : ""}`
        : `<dt>Status</dt><dd>no account server configured — this is a solo install; nothing leaves this Mac</dd>`;
      const out = $("#acct-out");
      if (out) out.onclick = async () => { await del("/api/session"); renderSettings(); };
      const check = $("#update-check");
      if (check) check.onclick = async () => {
        check.disabled = true;
        $("#update-line").textContent = "checking…";
        await window.checkUpdate(true);
        renderSettings();
        if (window.render) window.render();
      };
      const now = $("#update-now");
      if (now) now.onclick = () => window.runUpdateFromSettings(now, $("#update-settings-note"));
    } catch (e) { $("#account-body").innerHTML = `<dt>Status</dt><dd>unknown</dd>`; }
    try { await renderChrome(); } catch (e) { /* its own card, its own failure */ }
  }

  /* ---------------- CONNECT CHROME ----------------
     Three numbered steps, each with a button that does the fiddly half.

     The extension ships INSIDE the app (paths.chrome_extension_dir), so there
     is nothing to download, nothing to unzip, and nothing in Downloads to
     delete by accident — which would silently break the extension later,
     because Chrome remembers the folder it was loaded from. Step 2 opens
     Finder on that folder; step 1 copies the chrome:// URL, which cannot be
     opened by a link from a web page at all.

     The pairing code is not fetched until it is asked for: minting it is a
     decision, and a secret sitting in a page nobody asked for is a secret
     that ends up in a screenshot. */
  async function renderChrome() {
    const host = $("#chrome-body");
    if (!host) return;
    const bridge = (STATE && STATE.bridge) || {};
    const ext = bridge.extension || {};
    const held = Object.values(bridge.held || {})
      .reduce((total, rows) => total + rows.length, 0);

    host.innerHTML = `
      <p class="muted cx-lead">SchoolDash normally signs in to Canvas and
        Veracross itself, in a browser of its own. The Chrome you are already
        signed in to can hand those pages over instead — no sign-in, no
        session to keep alive, nothing typed.</p>

      <ol class="cx-steps">
        <li><b>Open Chrome's extensions page.</b> Paste this into Chrome's
          address bar — a link cannot open it.
          <div class="cx-row"><code id="cx-url">chrome://extensions</code>
            <button type="button" class="ghost" id="cx-copy-url">Copy</button></div>
          Turn on <b>Developer mode</b> (top right).</li>

        <li><b>Click “Load unpacked” and pick this folder.</b>
          ${ext.present ? `<div class="cx-row">
              <button type="button" class="primary" id="cx-reveal">Show me the folder</button>
              <span class="muted">it is already on this Mac — nothing to download</span>
            </div>
            <code class="cx-path" id="cx-path">${esc(ext.folder)}</code>
            <button type="button" class="ghost" id="cx-copy-path">Copy the path</button>`
          : `<div class="cx-row">
              <a class="linkbtn" href="${esc(EXT_URL)}" target="_blank" rel="noopener">Download it</a>
              <span class="muted">this build does not carry it — unzip it and pick that folder</span>
            </div>`}</li>

        <li><b>Pair it.</b> Click the SchoolDash icon in Chrome's toolbar and
          paste this code.
          <div class="cx-row">
            <button type="button" class="ghost" id="cx-pair">${bridge.paired
              ? "Show the pairing code" : "Create a pairing code"}</button>
            ${bridge.paired ? `<button type="button" class="ghost" id="cx-unpair">Unpair</button>` : ""}
          </div>
          <div id="cx-code" class="cx-code" hidden></div></li>
      </ol>

      <p class="muted cx-note">${
        held ? `Working. ${held} page${held === 1 ? "" : "s"} handed over; each
                counts as current for ${esc(String(bridge.fresh_minutes || 240))}
                minutes, and after that SchoolDash fetches it itself as before.`
        : bridge.paired
        ? `A code exists. Nothing has been handed over yet — once the extension
           has it, press <b>Send my pages now</b> there. Until then SchoolDash
           keeps signing in for itself, exactly as before.`
        : "Not set up yet. Nothing changes until you do this — the app keeps "
          + "signing in for itself."
      }</p>`;

    const copyTo = (button, text, done) => {
      if (!button) return;
      button.onclick = async () => {
        try {
          await navigator.clipboard.writeText(text);
          button.textContent = done;
        } catch (e) {
          /* Clipboard access gets refused often enough to need a real answer
             — an insecure origin, a stale gesture, a locked-down profile. */
          button.textContent = "select it and press ⌘C";
        }
      };
    };
    copyTo($("#cx-copy-url"), "chrome://extensions", "Copied");
    copyTo($("#cx-copy-path"), ext.folder || "", "Copied");

    const reveal = $("#cx-reveal");
    if (reveal) reveal.onclick = async () => {
      reveal.disabled = true;
      try {
        await post("/api/bridge/reveal", {});
        reveal.textContent = "Finder is showing it";
      } catch (err) {
        reveal.textContent = "copy the path instead";
      } finally { reveal.disabled = false; }
    };

    const pair = $("#cx-pair");
    if (pair) pair.onclick = async () => {
      pair.disabled = true;
      try {
        const out = await post("/api/bridge/pair", {});
        const box = $("#cx-code");
        box.hidden = false;
        box.innerHTML = `<code>${esc(out.token || "")}</code>
          <button type="button" class="ghost" id="cx-copy-code">Copy</button>
          <span class="muted">Paste this into the extension. It is only for
            this Mac — treat it like a password.</span>`;
        copyTo($("#cx-copy-code"), out.token || "", "Copied");
        /* The note was drawn from STATE, fetched before the code existed, so
           it said "not set up yet" underneath a code. Re-read, then rewrite
           just the note: a full redraw would take the code off screen, and it
           is only shown when asked for. */
        try { await loadState(); } catch (e) { /* the note can wait */ }
        const note = $(".cx-note");
        if (note) {
          note.innerHTML = `A code exists. Nothing has been handed over yet —
            paste it into the extension and press <b>Send my pages now</b>.`;
        }
      } finally { pair.disabled = false; }
    };

    const unpair = $("#cx-unpair");
    if (unpair) unpair.onclick = async () => {
      if (unpair.dataset.armed !== "yes") {
        unpair.dataset.armed = "yes";
        unpair.textContent = "Really unpair?";
        return;
      }
      await del("/api/bridge/pair");
      await loadState();
      renderChrome();
    };
  }

  /* ---------------- ACCELERATE ---------------- */
  function md(text) {
    /* A small Markdown renderer. Escapes everything first, so model output can
       never inject markup; then headings, lists, tables, fences, quotes,
       bold/italic/code and http links. */
    const lines = String(text || "").replace(/\r/g, "").split("\n");
    let html = "", i = 0;
    const inline = (s) => esc(s)
      .replace(/`([^`]+)`/g, "<code>$1</code>")
      .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
      .replace(/(^|[\s(])\*([^*\n]+)\*/g, "$1<em>$2</em>")
      .replace(/(^|[\s(])_([^_\n]+)_/g, "$1<em>$2</em>")
      .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
    while (i < lines.length) {
      const line = lines[i];
      if (/^\s*```/.test(line)) {
        const buf = []; i++;
        while (i < lines.length && !/^\s*```/.test(lines[i])) buf.push(lines[i++]);
        i++; html += `<pre><code>${esc(buf.join("\n"))}</code></pre>`; continue;
      }
      const h = line.match(/^\s*(#{1,4})\s+(.*)$/);
      if (h) { const lvl = Math.min(h[1].length + 1, 4); html += `<h${lvl}>${inline(h[2])}</h${lvl}>`; i++; continue; }
      if (/^\s*\|.*\|\s*$/.test(line) && i + 1 < lines.length && /^\s*\|[\s:|-]+\|\s*$/.test(lines[i + 1])) {
        const cells = (l) => l.trim().replace(/^\||\|$/g, "").split("|").map((c) => c.trim());
        const head = cells(line); i += 2;
        let rows = "";
        while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) rows += `<tr>${cells(lines[i++]).map((c) => `<td>${inline(c)}</td>`).join("")}</tr>`;
        html += `<table><thead><tr>${head.map((c) => `<th>${inline(c)}</th>`).join("")}</tr></thead><tbody>${rows}</tbody></table>`; continue;
      }
      if (/^\s*[-*+]\s+/.test(line)) {
        let items = "";
        while (i < lines.length && /^\s*[-*+]\s+/.test(lines[i])) items += `<li>${inline(lines[i++].replace(/^\s*[-*+]\s+/, ""))}</li>`;
        html += `<ul>${items}</ul>`; continue;
      }
      if (/^\s*\d+[.)]\s+/.test(line)) {
        let items = "";
        while (i < lines.length && /^\s*\d+[.)]\s+/.test(lines[i])) items += `<li>${inline(lines[i++].replace(/^\s*\d+[.)]\s+/, ""))}</li>`;
        html += `<ol>${items}</ol>`; continue;
      }
      if (/^\s*>\s?/.test(line)) {
        let buf = [];
        while (i < lines.length && /^\s*>\s?/.test(lines[i])) buf.push(lines[i++].replace(/^\s*>\s?/, ""));
        html += `<blockquote>${inline(buf.join(" "))}</blockquote>`; continue;
      }
      if (!line.trim()) { i++; continue; }
      let buf = [];
      while (i < lines.length && lines[i].trim() && !/^\s*(#{1,4}\s|[-*+]\s|\d+[.)]\s|>|\||```)/.test(lines[i])) buf.push(lines[i++]);
      if (buf.length) html += `<p>${inline(buf.join(" "))}</p>`; else i++;
    }
    return html;
  }
  window.renderMarkdown = md;

  let mermaidLoading = null;
  function loadMermaid() {
    if (window.mermaid) return Promise.resolve(window.mermaid);
    if (mermaidLoading) return mermaidLoading;
    mermaidLoading = new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = "https://cdnjs.cloudflare.com/ajax/libs/mermaid/11.4.1/mermaid.min.js";
      s.onload = () => resolve(window.mermaid);
      s.onerror = () => reject(new Error("mermaid did not load (offline?)"));
      document.head.appendChild(s);
    });
    return mermaidLoading;
  }

  async function drawVisuals(container) {
    const nodes = [...container.querySelectorAll(".mermaid[data-src]")];
    if (!nodes.length) return;
    try {
      const mermaid = await loadMermaid();
      const dark = document.documentElement.getAttribute("data-theme") === "dark"
        || (!document.documentElement.getAttribute("data-theme")
            && window.matchMedia("(prefers-color-scheme: dark)").matches);
      mermaid.initialize({ startOnLoad: false, theme: dark ? "dark" : "neutral", securityLevel: "strict" });
      for (const node of nodes) {
        node.textContent = node.dataset.src;
        node.removeAttribute("data-processed");
      }
      await mermaid.run({ nodes });
    } catch (err) {
      for (const node of nodes) {
        const pre = document.createElement("pre");
        pre.textContent = node.dataset.src;
        node.replaceWith(pre);
      }
    }
  }

  function accelHtml(saved) {
    const r = saved.result || {};
    const kindLabel = { reading: "reading", problem_set: "problem set", writing: "writing",
      test_prep: "test prep", project: "project", lab: "lab", discussion: "discussion", other: "assignment" }[r.kind] || r.kind;
    const visuals = (r.visuals || []).map((v, i) => {
      if (v.kind === "mermaid") return `<div class="visual"><div class="vis-title">${esc(v.title)}</div>
        <div class="mermaid" id="vis-${i}" data-src="${esc(v.code)}"></div></div>`;
      if (v.kind === "table") return `<div class="visual"><div class="vis-title">${esc(v.title)}</div><div class="md">${md(v.code)}</div></div>`;
      return `<div class="visual"><div class="vis-title">${esc(v.title)}</div><pre>${esc(v.code)}</pre></div>`;
    }).join("");
    const practice = (r.practice || []).map((p) => `<div class="practice"><div class="pr-prompt">${esc(p.prompt)}</div>
      ${p.hint ? `<details><summary>hint</summary><div>${esc(p.hint)}</div></details>` : ""}
      ${p.answer ? `<details><summary>answer / worked pattern</summary><div class="md">${md(p.answer)}</div></details>` : ""}</div>`).join("");
    const terms = (r.key_terms || []).map((t) => `<div class="term"><b>${esc(t.term)}</b><span>${esc(t.meaning)}</span></div>`).join("");
    const tabs = [
      ["guide", "Guide", `<div class="md">${md(r.guide_markdown)}</div>${visuals}`],
      ["practice", r.kind === "problem_set" ? "How to do the problems" : "Check yourself", practice || `<div class="muted">nothing here</div>`],
      ["terms", "Key terms", terms || `<div class="muted">none</div>`],
      ["watch", "Watch out", (r.watch_out || []).length ? `<ul>${r.watch_out.map((w) => `<li>${esc(w)}</li>`).join("")}</ul>` : `<div class="muted">none</div>`],
    ];
    const minutes = Number(r.time_estimate_minutes) > 0
      ? ` · about ${esc(String(r.time_estimate_minutes))} min` : "";
    return `<div class="accel-kicker">${esc(kindLabel)}${minutes}</div>
      <div class="accel-headline">${esc(r.headline || "")}</div>
      <ul class="accel-tldr">${(r.tldr || []).map((t) => `<li>${esc(t)}</li>`).join("")}</ul>
      ${(r.not_available || []).length ? `<div class="accel-warn">Could not read: ${esc(r.not_available.join("; "))}. The parts that depend on it are general, not from the material.</div>` : ""}
      <div class="accel-tabs">${tabs.map(([k, label], i) => `<button type="button" data-tab="${k}" class="${i === 0 ? "active" : ""}">${esc(label)}</button>`).join("")}</div>
      ${tabs.map(([k, , body], i) => `<div class="accel-tab" data-tab="${k}" ${i === 0 ? "" : "hidden"}>${body}</div>`).join("")}
      <div class="accel-foot">Read: ${esc((r.sources_used || []).join("; ") || "nothing linked — from the title and class only")}.
        Written ${esc((r.generated_at || saved.created || "").slice(0, 16).replace("T", " "))} by ${esc(saved.provider || "the AI")}.
        Checks the material, not your teacher — when they disagree, the teacher wins.</div>`;
  }

  async function openAccelerate(itemId, title) {
    ACCEL_ITEM = itemId;
    const body = $("#accel-body");
    window.showPane("accel");
    $("#accel-title").textContent = "⚡ " + (title || "Accelerated").slice(0, 60);
    body.innerHTML = `<div class="accel-status">looking for a saved guide…</div>`;
    const item = (STATE.items || []).find((i) => i.item_id === itemId);
    if (item && window.setChatContext) window.setChatContext({ itemId, label: item.title.slice(0, 50) });
    let saved = null;
    try { saved = await api(`/api/accelerate/${itemId}`); } catch (e) { saved = null; }
    if (ACCEL_ITEM !== itemId) return;
    if (saved) { body.innerHTML = accelHtml(saved); wireAccel(body); return; }
    await generateAccel(itemId, false);
  }
  window.openAccelerate = openAccelerate;

  async function generateAccel(itemId, force) {
    const body = $("#accel-body");
    body.innerHTML = `<div class="accel-status">reading the assignment and writing your guide — usually 30–90 seconds
      <div class="lines"></div></div>`;
    const lines = body.querySelector(".lines");
    try {
      const saved = await pollJob(await post(`/api/accelerate/${itemId}`, { force }),
        (t) => { lines.textContent += t + "\n"; });
      if (ACCEL_ITEM !== itemId) return;
      body.innerHTML = accelHtml(saved);
      wireAccel(body);
    } catch (err) {
      body.innerHTML = `<div class="accel-warn">${esc(err.message)}</div>
        <button type="button" class="ghost" id="accel-retry">Try again</button>`;
      $("#accel-retry").onclick = () => generateAccel(itemId, true);
    }
  }

  function wireAccel(body) {
    body.querySelectorAll(".accel-tabs button").forEach((b) => b.addEventListener("click", () => {
      body.querySelectorAll(".accel-tabs button").forEach((x) => x.classList.toggle("active", x === b));
      body.querySelectorAll(".accel-tab").forEach((t) => { t.hidden = t.dataset.tab !== b.dataset.tab; });
      drawVisuals(body);
    }));
    drawVisuals(body);
  }
  $("#accel-close").addEventListener("click", () => {
    const back = ACCEL_ITEM;
    ACCEL_ITEM = null;
    if (back && (STATE.items || []).some((i) => i.item_id === back)) window.openDetail(back);
    else window.showPane("chat");
  });
  $("#accel-regenerate").addEventListener("click", () => { if (ACCEL_ITEM) generateAccel(ACCEL_ITEM, true); });

  /* ---------------- chat extras ---------------- */
  const input = $("#chat-input");
  document.querySelectorAll(".chat-chips .chip-btn[data-fill]").forEach((b) =>
    b.addEventListener("click", () => { input.value = b.dataset.fill; input.focus(); }));
  const teacher = $("#chat-teacher");
  if (teacher) teacher.addEventListener("click", () => {
    input.value = "Teacher said: ";
    input.placeholder = "e.g. Teacher said: read chapter 4 by Friday";
    input.focus();
  });
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const mic = $("#chat-mic");
  if (mic && Recognition) {
    mic.hidden = false;
    let rec = null;
    mic.addEventListener("click", () => {
      if (rec) { rec.stop(); return; }
      rec = new Recognition();
      rec.lang = "en-US"; rec.interimResults = true; rec.continuous = false;
      const base = input.value ? input.value.replace(/\s*$/, " ") : "";
      mic.classList.add("listening"); mic.textContent = "■";
      rec.onresult = (ev) => {
        let text = "";
        for (const res of ev.results) text += res[0].transcript;
        input.value = base + text;
      };
      rec.onerror = () => { input.placeholder = "the microphone did not work — type instead"; };
      rec.onend = () => { mic.classList.remove("listening"); mic.textContent = "🎙"; rec = null; input.focus(); };
      rec.start();
    });
  }

  /* ---------------- the jump palette (⌘K) ----------------
     Type a few letters, land on an assignment, a class or a page. Every
     entry is something already on the screen; the palette only saves the
     hunt. */
  const palette = $("#palette");
  const pInput = $("#palette-input");
  const pList = $("#palette-list");
  let pIndex = 0;
  function paletteEntries(q) {
    q = q.trim().toLowerCase();
    const entries = [];
    const pages = [["chat", "Chat", "page"], ["classes", "Classes", "page"], ["done", "Done", "page"],
                   ["settings", "Settings", "page"], ["add", "Add something", "page"]];
    for (const [key, label] of pages) entries.push({ kind: "page", label, sub: "", key, icon: "▸" });
    entries.push({ kind: "action", label: "Refresh", sub: "pull Canvas, docs and grades now", icon: "⟳", run: () => refresh() });
    entries.push({ kind: "action", label: "Toggle night mode", sub: "", icon: "◐", run: () => $("#theme-toggle").click() });
    for (const g of (STATE && STATE.grades) || []) {
      entries.push({ kind: "class", label: shortCourse(g.display_name), icon: "◔",
        sub: g.graded && g.percent != null ? `${g.letter || ""} ${g.percent.toFixed(1)}%` : "not graded yet",
        run: () => openGradePane(g.course_key) });
    }
    for (const i of (STATE && STATE.items) || []) {
      if (i.done) continue;
      entries.push({ kind: "item", label: i.title, icon: "•",
        sub: `${shortCourse(i.course)} · ${i.due_date ? SD.relDays(i.due_date, STATE.today) : "no date"}`,
        run: () => window.openDetail(i.item_id) });
    }
    if (!q) return entries.slice(0, 14);
    const score = (e) => {
      const t = (e.label + " " + e.sub).toLowerCase();
      if (t.startsWith(q)) return 3;
      if (t.includes(q)) return 2;
      return q.split(/\s+/).every((w) => t.includes(w)) ? 1 : 0;
    };
    return entries.map((e) => [score(e), e]).filter(([s]) => s > 0).sort((a, b) => b[0] - a[0]).map(([, e]) => e).slice(0, 14);
  }
  function renderPalette() {
    const entries = paletteEntries(pInput.value);
    pIndex = Math.max(0, Math.min(pIndex, entries.length - 1));
    pList.innerHTML = entries.length ? entries.map((e, i) => `<button type="button" class="palette-row${i === pIndex ? " active" : ""}" data-i="${i}">
      <span>${esc(e.icon)}</span><span>${esc(e.label)}${e.sub ? ` <small>${esc(e.sub)}</small>` : ""}</span><span class="pr-kind">${esc(e.kind)}</span></button>`).join("")
      : `<div class="empty-note">nothing matches</div>`;
    pList.querySelectorAll(".palette-row").forEach((b) => b.addEventListener("click", () => pick(entries[Number(b.dataset.i)])));
    pList._entries = entries;
  }
  function pick(entry) {
    closePalette();
    if (!entry) return;
    if (entry.run) entry.run();
    else if (entry.kind === "page") showView(entry.key);
  }
  function openPalette() {
    if (!palette) return;
    palette.hidden = false; pInput.value = ""; pIndex = 0; renderPalette(); pInput.focus();
  }
  function closePalette() { if (palette) palette.hidden = true; }
  if (palette) {
    $("#palette-open").addEventListener("click", openPalette);
    palette.addEventListener("click", (ev) => { if (ev.target === palette) closePalette(); });
    pInput.addEventListener("input", () => { pIndex = 0; renderPalette(); });
    pInput.addEventListener("keydown", (ev) => {
      const entries = pList._entries || [];
      if (ev.key === "ArrowDown") { ev.preventDefault(); pIndex = Math.min(pIndex + 1, entries.length - 1); renderPalette(); }
      else if (ev.key === "ArrowUp") { ev.preventDefault(); pIndex = Math.max(pIndex - 1, 0); renderPalette(); }
      else if (ev.key === "Enter") { ev.preventDefault(); pick(entries[pIndex]); }
      else if (ev.key === "Escape") { ev.preventDefault(); closePalette(); }
    });
    document.addEventListener("keydown", (ev) => {
      if ((ev.metaKey || ev.ctrlKey) && ev.key.toLowerCase() === "k") { ev.preventDefault(); palette.hidden ? openPalette() : closePalette(); }
    });
  }

  /* ---------------- boot ---------------- */
  const initial = location.pathname.replace("/", "") || "chat";
  refreshSetup().then(() => {
    if (initial === "chat" && SETUP && !SETUP.complete
        && !step("accounts").done && !step("connect").done) {
      // a brand-new install: open the wizard straight away
      showView("setup", false); history.replaceState({ view: "setup" }, "", "/setup");
    }
  });
  showView(VIEWS.includes(initial) ? initial : "chat", false);
  loadCourses();
  setInterval(() => { if (!document.hidden && CURRENT === "chat") refreshSetup(); }, 120000);
})();
