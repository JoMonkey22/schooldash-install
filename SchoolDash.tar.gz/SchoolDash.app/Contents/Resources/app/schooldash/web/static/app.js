/* SchoolDash client — the board. Two modes, one file:
   - local (Flask): live /api/state, chat with actions, Refresh with SSE
   - remote (published snapshot): window.SNAPSHOT embedded, read-only —
     ticks are kept in this browser only and say so.

   0.18: one screen. Left — grades, focus, calendar. Centre — a pane: the
   conversation by default, or whatever was clicked on a side. Right —
   assignments, tests & quizzes, personal work. The chat input is docked under
   the centre pane and never leaves. views.js adds the panes that need a
   server (classes, settings, setup, the study guide, the grade page). */
"use strict";

const $ = (sel) => document.querySelector(sel);
const REMOTE = typeof window.SNAPSHOT === "object" && window.SNAPSHOT !== null;
const REDUCED = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
let STATE = null;
let CHAT_SESSION = null;
let SELECTED = null;
let SELECTED_CLASS = null;
let SCHED_OFFSET = 0;
let CAL_MODE = "day";
let PANE = "chat";
// The build this page loaded with. Captured once, then compared on every poll:
// a tab left open across an update keeps rendering its original JS.
let APP_VERSION_SEEN = null;

/* Escape for HTML — including quotes, which is the whole point.
   [PROVEN] tests/test_prosecution.py: this used to set textContent on a
   throw-away <div> and read back innerHTML, which escapes & < > and leaves "
   and ' untouched. That is correct for element content and wrong for an
   attribute, and dozens of attributes across this file and views.js
   interpolate it: href, src, title, value, data-id. Every one of those values
   comes from outside — a teacher's Google Doc, a Canvas page, a book
   catalogue. Escaping all five is safe in element content too. */
const HTML_ESCAPES = { "&": "&amp;", "<": "&lt;", ">": "&gt;",
                       '"': "&quot;", "'": "&#39;" };
function esc(text) {
  return text == null ? "" : String(text).replace(/[&<>"']/g,
                                                  (ch) => HTML_ESCAPES[ch]);
}
/* [MEASURED] 2026-09-02: on a brand-new install `/api/state` carries no
   `today` at all, so isoPlus(null, 1) built an Invalid Date and toISOString()
   threw inside render(). The browser's own date is the honest fallback.
   Local, not UTC: toISOString() would roll over to tomorrow for anyone west of
   Greenwich after their afternoon. */
function localIso() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`
       + `-${String(d.getDate()).padStart(2, "0")}`;
}
function todayIso() { return (STATE && STATE.today) || localIso(); }
function isoPlus(iso, days) {
  const d = new Date((iso || localIso()) + "T12:00:00");
  if (Number.isNaN(d.getTime())) return localIso();
  d.setDate(d.getDate() + days);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`
       + `-${String(d.getDate()).padStart(2, "0")}`;
}
function niceDate(iso, withYear) {
  if (!iso) return "no date";
  const d = new Date(iso + "T12:00:00");
  return d.toLocaleDateString(undefined, { weekday: "short", month: "short",
    day: "numeric", ...(withYear ? { year: "numeric" } : {}) });
}
function dueLabel(item) {
  if (!item.due_date) return "undated";
  let label = niceDate(item.due_date);
  if (item.due && !item.all_day) {
    const t = item.due.slice(11, 16);
    if (t && t !== "23:59") label += " " + t;
  }
  return label;
}
function daysUntil(iso, today) {
  if (!iso) return null;
  const a = new Date(iso + "T12:00:00");
  const b = new Date(today + "T12:00:00");
  if (Number.isNaN(a) || Number.isNaN(b)) return null;
  return Math.round((a - b) / 86400000);
}
/* "in 3 days", "tomorrow", "today", "2 days ago" — the same words everywhere. */
function relDays(iso, today) {
  const n = daysUntil(iso, today);
  if (n === null) return "no date";
  if (n === 0) return "today";
  if (n === 1) return "tomorrow";
  if (n === -1) return "yesterday";
  if (n < 0) return `${-n} days ago`;
  return `in ${n} days`;
}
function minutesLabel(minutes) {
  minutes = Math.round(minutes / 5) * 5;
  if (minutes <= 0) return "";
  if (minutes < 60) return `~${minutes}m`;
  const h = Math.floor(minutes / 60), m = minutes % 60;
  return m ? `~${h}h ${m}m` : `~${h}h`;
}
/* Data kept from an earlier refresh, because the source could not be read
   this time. One sentence, shared by every panel that can show carried data. */
function staleNoteHtml(stale, fallbackReason) {
  if (!stale) return "";
  const day = (stale.as_of || "").slice(0, 10);
  const when = day ? niceDate(day) : "an earlier refresh";
  const why = stale.reason || fallbackReason;
  return `<div class="stale-note" title="${esc(`Kept from ${when}: ${why}. Press Refresh to try again.`)}">`
       + `from ${esc(when)} — ${esc(why)}</div>`;
}

function shortCourse(name) {
  return (name || "").split("-")[0].replace("Advanced Placement", "AP").trim();
}
/* Shorter still, for a row's sub-line: the part before a colon, and never
   more than two words past 18 characters. "AI Frontiers: Applications &
   Innovation" took three lines of a 296px column as a chip. */
function nick(name) {
  let short = shortCourse(name).split(":")[0].trim();
  if (short.length > 18) short = short.split(/\s+/).slice(0, 2).join(" ");
  return short;
}
/* A stable colour per class, from its key, so the same class is the same
   colour on a row, a meeting and a grade bar. Hue only — the lightness comes
   from the theme, so it reads on paper and in the dark. */
function classColor(key) {
  let h = 0;
  for (const ch of String(key || "")) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return `hsl(${h % 360} 55% 52%)`;
}
function classStyle(key) { return `style="--class-color: ${esc(classColor(key))}"`; }

/* ---------------- preferences ----------------
   Appearance and layout, kept on this Mac. The inline script in the page head
   applies the same keys before first paint; this is the copy that runs when
   something changes while the page is open. */
const PREF_DEFAULTS = {
  theme: "system", accent: "#2563EB", font: "modern", density: "normal",
  textSize: 14, motion: "on", gradeSort: "low", calendar: "day", assignSort: "smart",
  showWeekends: false, leftWidth: 248, rightWidth: 296, hideLeft: false, hideRight: false,
  /* layout is deliberately NOT defaulted: undefined means "never chosen",
     which is what makes the chooser appear once instead of every run. */
  layout: undefined, tab: "todo",
};
let PREFS = { ...PREF_DEFAULTS };
function loadPrefs() {
  try {
    const stored = JSON.parse(localStorage.getItem("schooldash.prefs")) || {};
    PREFS = { ...PREF_DEFAULTS, ...stored };
    if (!stored.theme) {
      const old = localStorage.getItem("schooldash.theme");
      if (old === "dark" || old === "light") PREFS.theme = old;
    }
  } catch (e) { PREFS = { ...PREF_DEFAULTS }; }
  return PREFS;
}
function savePrefs(patch) {
  Object.assign(PREFS, patch || {});
  try { localStorage.setItem("schooldash.prefs", JSON.stringify(PREFS)); } catch (e) { /* private mode */ }
  applyPrefs();
}
/* Black or white text on the accent, by luminance — the one derived colour
   CSS color-mix cannot decide on its own. */
function onColor(hex) {
  const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex || "");
  if (!m) return "#FFFFFF";
  const [r, g, b] = [m[1], m[2], m[3]].map((x) => parseInt(x, 16) / 255)
    .map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4));
  const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  return lum > 0.45 ? "#14192B" : "#FFFFFF";
}
function applyPrefs() {
  const root = document.documentElement;
  const theme = PREFS.theme;
  if (theme === "dark" || theme === "light" || theme === "offwhite") root.setAttribute("data-theme", theme);
  else root.removeAttribute("data-theme");
  const meta = document.querySelector('meta[name="color-scheme"]');
  if (meta) meta.content = theme === "dark" ? "dark" : theme === "system" ? "light dark" : "light";
  if (PREFS.font && PREFS.font !== "modern") root.setAttribute("data-font", PREFS.font);
  else root.removeAttribute("data-font");
  if (PREFS.density && PREFS.density !== "normal") root.setAttribute("data-density", PREFS.density);
  else root.removeAttribute("data-density");
  root.style.setProperty("--text-size", `${Number(PREFS.textSize) || 14}px`);
  if (/^#[0-9a-fA-F]{6}$/.test(PREFS.accent || "")) {
    root.style.setProperty("--accent", PREFS.accent);
    root.style.setProperty("--on-brand", onColor(PREFS.accent));
  } else {
    root.style.removeProperty("--accent");
    root.style.removeProperty("--on-brand");
  }
  if (PREFS.motion === "off") root.setAttribute("data-motion", "off");
  else root.removeAttribute("data-motion");
  root.style.setProperty("--left-w", `${Math.max(180, Math.min(440, Number(PREFS.leftWidth) || 248))}px`);
  root.style.setProperty("--right-w", `${Math.max(200, Math.min(480, Number(PREFS.rightWidth) || 296))}px`);
  root.classList.toggle("hide-left", !!PREFS.hideLeft);
  root.classList.toggle("hide-right", !!PREFS.hideRight);
  const tc = document.querySelector('meta[name="theme-color"]');
  if (tc && PREFS.accent) tc.content = PREFS.accent;
  applyLayout();
}

/* ---------------- the two layouts ----------------
   *"make 2 versions of the app, you would pick witch one in start … a
   simpler looking more tabs and less info on one screen at one time"*

   `dash` is the 0.18 board. `simple` shows one page at a time behind a tab
   strip. The panels are NOT rebuilt for it: the same boxes are shown one at a
   time, so every renderer serves both and the two can never disagree about
   the data. See the LAYOUT block in app.css. */
/* FIVE pages, named for what he would be looking for, not for the buckets the
   data happens to sit in. The first cut had nine and he was right that it was
   not simple. Two things were actually wrong, not just crowded:

   1. **"Today" and "Tests" showed the same items.** sections() puts every
      assessment in `tomorrow`/`later` AND in `upcoming` — the Tests strip
      exists to NAME what is coming without repeating the row. As two tabs
      that became the same test on two pages with nothing to say which was
      real. So there is no Tests page: To do holds every piece of work,
      homework and tests together, already sectioned OVERDUE / TODAY /
      TOMORROW, which is the order he would read them in anyway.
   2. **Settings sat next to his homework** as an equal, and Personal had
      nothing in it. Rare things do not belong in the same row as the reason
      the app exists; they are behind More, which is one obvious tap.

   `hidden: true` keeps a page out of the strip while still making it a real
   page — same showTab, same back behaviour, one list driving all of it. */
const SIMPLE_TABS = [
  { key: "todo", label: "To do", icon: "\u{1F4CB}",
    parts: [{ col: "#col-right", panel: "tomorrow" }] },
  { key: "grades", label: "Grades", icon: "\u{1F4CA}",
    parts: [{ col: "#col-left", panel: "grades" }] },
  /* The one page with two boxes, because he asked for it: *"make the calendar
     look like a calendar and on the right side have the assignments that are
     due today or tomorrow"*. `aside: true` puts the second one beside the
     first rather than under it. */
  { key: "calendar", label: "Calendar", icon: "\u{1F4C5}",
    parts: [{ col: "#col-left", panel: "schedule" },
            { col: "#col-right", panel: "duesoon", aside: true }] },
  { key: "chat", label: "Chat", icon: "\u{1F4AC}",
    parts: [{ col: "#col-center", pane: "chat" }] },
  { key: "more", label: "More", icon: "\u22EF",
    parts: [{ col: "#col-center", pane: "more" }] },
  // Reached from More. Real pages, just not in the strip.
  { key: "classes", label: "Classes", icon: "\u{1F4DA}", hidden: true,
    blurb: "Textbooks, syllabi and the documents your teachers post work in",
    parts: [{ col: "#col-center", pane: "classes" }] },
  { key: "personal", label: "Personal", icon: "\u{1F3AF}", hidden: true,
    blurb: "Goals, practices, club things and makeup work \u2014 whatever is not homework",
    parts: [{ col: "#col-right", panel: "personal" }] },
  { key: "done", label: "Done", icon: "\u2714\uFE0F", hidden: true,
    blurb: "Everything you have handed in or ticked off",
    parts: [{ col: "#col-center", pane: "done" }] },
  { key: "settings", label: "Settings", icon: "\u2699\uFE0F", hidden: true,
    blurb: "How it looks, your sign-ins, reminders",
    parts: [{ col: "#col-center", pane: "settings" }] },
];
const TAB_KEYS = SIMPLE_TABS.map((t) => t.key);
/* True only while showTab is resetting the centre; see showTab. */
let TAB_SWITCHING = false;
function isSimple() { return PREFS.layout === "simple"; }
window.isSimple = isSimple;

function applyLayout() {
  const root = document.documentElement;
  const chosen = PREFS.layout === "simple" || PREFS.layout === "dash";
  root.setAttribute("data-layout", chosen ? PREFS.layout : "unchosen");
  const pick = $("#layout-pick");
  if (pick) pick.hidden = chosen;
  const bar = $("#tab-bar");
  if (bar) bar.hidden = PREFS.layout !== "simple";
  // Folded/grown mean different things in the two layouts, so the saved
  // states have to be re-read whenever the layout changes.
  try { applyPanelStates(); } catch (e) { /* before the panels exist */ }
  try { placeBrief(); } catch (e) { /* before the panels exist */ }
  if (PREFS.layout === "simple") showTab(PREFS.tab, { fromPrefs: true });
  else {
    // Leaving simple mode must not leave a column hidden behind it.
    document.querySelectorAll(".tab-on").forEach((el) => el.classList.remove("tab-on"));
    document.querySelectorAll(".tab-main").forEach((el) => el.classList.remove("tab-main"));
    applyPageHeadings(null);
    root.removeAttribute("data-tab");
  }
}

/* Which tab a centre pane belongs to, so opening an assignment from Today
   lights up the right tab instead of none. Panes with no tab of their own
   (item, grade, accel, add, setup) are reached BY doing something, and the
   strip keeps showing where you came from. */
function tabForPane(pane) {
  const hit = SIMPLE_TABS.find((t) => t.parts.some((part) => part.pane === pane));
  return hit ? hit.key : null;
}

/* A page is headed by the name on its tab. [MEASURED] 2026-09-10: tapping
   "To do" opened a box headed "Assignments", and the tab strip and the page
   heading disagreeing about what a page is called is exactly the confusion
   this layout exists to remove. The dashboard keeps the template's own
   headings, where several boxes share one screen and "Assignments" says more
   than "To do" would. The original is remembered on the element the first
   time it is changed, so switching back restores it rather than guessing. */
/* Where the brief lives. It is the counts, the one thing to start with and
   the reason it is first — and in the simple layout it sat on top of the
   *conversation*, which is two unrelated things on one page and left the chat
   log 173px tall on his 605px screen. "What should I do first" is answered on
   the page that lists what there is to do, so in the simple layout the brief
   moves to the top of the To-do box and the Chat page becomes only chat.

   It is moved rather than copied: one node, so `renderHero` keeps finding
   `#hero-body` by id wherever it is, and there is never a second stale copy.
   It is inserted BEFORE the To-do box's `.panel-body`, because `renderPanels`
   rewrites that body's innerHTML on every refresh and would wipe a child. */
function placeBrief() {
  const brief = $("#hero-panel");
  if (!brief) return;
  const target = isSimple()
    ? document.querySelector('.panel[data-panel="tomorrow"]')
    : document.querySelector("#chat-panel .panel-body");
  if (!target) return;
  const before = isSimple()
    ? target.querySelector(".panel-body")
    : target.firstElementChild;
  if (brief.parentElement === target && brief.nextElementSibling === before) return;
  target.insertBefore(brief, before);
  brief.classList.toggle("on-todo", isSimple());
}

function applyPageHeadings(tab) {
  document.querySelectorAll(".col.side .panel > header > h2").forEach((h) => {
    if (h.dataset.deskName === undefined) h.dataset.deskName = h.textContent;
    h.textContent = h.dataset.deskName;
  });
  if (!tab) return;
  const main = tab.parts.find((part) => part.panel && !part.aside);
  if (!main) return;
  const head = document.querySelector(
    `.panel[data-panel="${main.panel}"] > header > h2`);
  if (head) head.textContent = tab.label;
}

function showTab(key, opts) {
  if (!isSimple()) return;
  if (!TAB_KEYS.includes(key)) key = "todo";
  const tab = SIMPLE_TABS.find((t) => t.key === key);
  document.documentElement.setAttribute("data-tab", key);
  if (!opts || !opts.fromPrefs) savePrefs({ tab: key });
  else PREFS.tab = key;

  /* Route through showPane FIRST, even for a tab that shows no pane at all.
     [MEASURED] 2026-09-10: without this, tapping an assignment on Today and
     pressing back left `SELECTED` set and `#pane-item` open behind the page.
     Nothing looked wrong until the next refresh, when render() called
     renderDetail(SELECTED) -> showPane("item"), which pulled the CENTRE column
     back in front and left Today showing an assignment nobody had asked for.
     Clearing the centre is part of changing page, not an afterthought.
     TAB_SWITCHING stops showPane's own simple-layout block from fighting the
     column marking that comes after it. */
  const centre = tab.parts.find((part) => part.pane);
  TAB_SWITCHING = true;
  try { showPane(centre ? centre.pane : "chat"); }
  finally { TAB_SWITCHING = false; }

  const wanted = new Map(tab.parts.map((part) => [part.col, part]));
  for (const sel of ["#col-left", "#col-center", "#col-right"]) {
    const col = document.querySelector(sel);
    if (!col) continue;
    const part = wanted.get(sel);
    col.classList.toggle("tab-on", !!part);
    col.classList.toggle("tab-aside", !!(part && part.aside));
  }
  const board = document.querySelector(".board");
  if (board) board.classList.toggle("tab-split", tab.parts.some((part) => part.aside));
  // Inside a side column, only the panels this tab actually names.
  const panels = new Set(tab.parts.map((part) => part.panel).filter(Boolean));
  const main = tab.parts.find((part) => part.panel && !part.aside);
  document.querySelectorAll(".col.side .panel").forEach((el) => {
    el.classList.toggle("tab-on", panels.has(el.dataset.panel));
    // The page's own box, as opposed to something beside it. Its count is
    // already on its tab, so the header does not repeat it.
    el.classList.toggle("tab-main", !!main && main.panel === el.dataset.panel);
  });
  applyPageHeadings(tab);
  renderTabs();
}
window.showTab = showTab;

/* The strip is built from SIMPLE_TABS, with the same counts the panel headers
   show — the number is the reason to open a page, so hiding it here would
   make the layout that shows less also tell you less. */
function renderTabs() {
  const bar = $("#tab-bar");
  if (!bar || !isSimple()) return;
  /* A page reached from More still lights More up, so the strip always shows
     where you are — five tabs and none of them active is the state that makes
     a tabbed app feel broken. */
  const here = SIMPLE_TABS.find((t) => t.key === PREFS.tab);
  const open = here && here.hidden ? "more" : PREFS.tab;
  bar.innerHTML = SIMPLE_TABS.filter((t) => !t.hidden).map((t) => {
    const n = tabCount(t.key);
    return `<button type="button" data-tab="${esc(t.key)}"${t.key === open ? ' class="active"' : ""}>`
      + `<span class="tab-i" aria-hidden="true">${t.icon}</span>${esc(t.label)}`
      + `<span class="tab-n">${n ? esc(String(n)) : ""}</span></button>`;
  }).join("");
  renderMore();
}

/* The More page: the four things that are not why you opened the app. Built
   from the same list, so a page can never be unreachable — if it is hidden
   from the strip it is here. */
function renderMore() {
  const host = $("#more-list");
  if (!host) return;
  host.innerHTML = SIMPLE_TABS.filter((t) => t.hidden).map((t) => {
    const n = tabCount(t.key);
    return `<button type="button" class="more-row" data-tab="${esc(t.key)}">
      <span class="more-i" aria-hidden="true">${t.icon}</span>
      <span class="more-t"><b>${esc(t.label)}</b><span class="more-b">${esc(t.blurb || "")}</span></span>
      ${n ? `<span class="more-n">${esc(String(n))}</span>` : ""}
      <span class="more-go" aria-hidden="true">\u203A</span></button>`;
  }).join("");
}

/* The number on a tab is the number in that panel's own header. It is read
   from sections() — the same bucketing the panels are filled from — because a
   second filter here would eventually disagree with the box it labels, and a
   count that contradicts the list under it is worse than no count. */
function tabCount(key) {
  if (!STATE || !STATE.items) return 0;
  let out;
  try { out = sections().out; } catch (e) { return 0; }
  if (key === "todo") return out.tomorrow.open.length + out.later.open.length;
  if (key === "personal") return out.personal.open.length;
  if (key === "grades") return ((STATE.grades) || []).filter((g) => g.graded).length;
  if (key === "done") return (STATE.items || []).filter((i) => i.done).length;
  return 0;
}
window.savePrefs = savePrefs;
window.getPrefs = () => PREFS;

/* ---------------- local tick overlay (remote mode) ---------------- */
const localTicks = {
  key: "schooldash.remote.done",
  load() { try { return JSON.parse(localStorage.getItem(this.key)) || {}; }
           catch (e) { return {}; } },
  set(id, done) { const t = this.load(); if (done) t[id] = 1; else delete t[id];
    localStorage.setItem(this.key, JSON.stringify(t)); },
};

/* ---------------- boot ---------------- */
async function loadState() {
  if (REMOTE) {
    STATE = window.SNAPSHOT;
    const ticks = localTicks.load();
    for (const item of STATE.items || []) {
      if (ticks[item.item_id]) item.done = true;
    }
  } else {
    const response = await fetch("/api/state");
    if (response.status === 401) { showGate(); return; }
    // 402, not 401: they are signed in, so throwing them back to a login form
    // would be answering a question they have already answered.
    if (response.status === 402) {
      const body = await response.json().catch(() => ({}));
      showPaywall((body.error || {}).message || "");
      return;
    }
    STATE = await response.json();
  }
  if (!APP_VERSION_SEEN && STATE && STATE.app_version) {
    APP_VERSION_SEEN = STATE.app_version;
  }
  render();
}

/* Every box drawn independently, and a box that fails SAYS SO.

   [MEASURED] 2026-09-10. He sent a screenshot of the Grades page: the panel
   header showed "7/10 · low first" and the body below it was completely
   empty — and the page had no footer either. That second detail is the whole
   diagnosis. These calls used to be eight bare statements in a row, so the
   first one to throw took every one after it with it, silently: grades blank,
   focus blank, the hero gone, the footer never written, and no error anywhere
   a person could see. The data was fine and the same state rendered correctly
   in another browser, which is the worst version of this bug — nothing to
   look at and nothing to read.

   So: each renderer is its own attempt, the failures are collected, and they
   are put on screen with the name of the box and the message. A panel that
   cannot draw is a bug worth reporting; a page that goes blank without
   telling anyone is a bug that cannot be reported at all. */
function render() {
  const steps = [
    ["the top line", renderHead],
    ["the notices", renderBanners],
    ["your work", renderPanels],
    ["the calendar", renderSchedule],
    ["your grades", renderGrades],
    ["Focus on", renderFocus],
    ["what to start with", renderHero],
    ["the class list", fillCourseList],
  ];
  const broke = [];
  for (const [what, fn] of steps) {
    try {
      fn();
    } catch (err) {   // noqa — the point is that one box cannot take the rest
      broke.push([what, err]);
      console.error(`SchoolDash: could not draw ${what}`, err);
    }
  }
  if (SELECTED) {
    try { renderDetail(SELECTED); } catch (err) { broke.push(["that assignment", err]); }
  }
  if (SELECTED_CLASS && window.renderGradePane) {
    try { window.renderGradePane(SELECTED_CLASS); } catch (err) { broke.push(["that class", err]); }
  }
  try { renderTabs(); } catch (err) { broke.push(["the tabs", err]); }
  try { renderFooter(); } catch (err) { console.error("SchoolDash: footer", err); }
  reportRenderFailures(broke);
}

/* Named, appended, and never thrown from — this is the last thing standing
   between a blank box and a silent one. */
function reportRenderFailures(broke) {
  const box = $("#banners");
  if (!box) return;
  if (!broke.length) return;
  const seen = new Set();
  const lines = broke.filter(([what]) => !seen.has(what) && seen.add(what)).map(([what, err]) => {
    const message = String((err && (err.message || err)) || "unknown").slice(0, 160);
    return `<div>${esc(what)} — <code>${esc(message)}</code></div>`;
  }).join("");
  try {
    box.innerHTML += `<div class="banner warn"><div><b>Part of this page could not be
      drawn.</b> Everything else still works, and the data itself is fine — this is a
      fault in the app, not in your grades or your homework.
      ${lines}
      <span class="muted">Press Refresh, and if it keeps happening send this message.</span>
      </div></div>`;
  } catch (err) { /* a broken banner must not be the thing that breaks */ }
}
window.render = render;

/* The one place the board makes a promise about itself, so it has to be true:
   "N open item(s) — nothing is hidden", or the trimmed total when anything was
   left off. Spec §5.2: a trimmed list states its true total. */
function renderFooter() {
  $("#footer").textContent = REMOTE
    ? "read-only snapshot — checkmarks here stay on this device; the real Done button lives on your PC"
    : footerLine();
}
function footerLine() {
  const open = (STATE.items || []).filter(i => !i.done).length;
  const trimmed = STATE.trimmed || {};
  const parts = [];
  if (trimmed.past) {
    parts.push(`${trimmed.past} older than ${trimmed.grace_days || 3} days`);
  }
  if (trimmed.undated) {
    parts.push(`${trimmed.undated} undated for over `
             + `${Math.round((trimmed.undated_days || 14) / 7)} weeks`);
  }
  if (!parts.length) return `${open} open item(s) — nothing is hidden`;
  return `${open} open item(s) · not shown: ${parts.join(", ")}`
       + " — nothing is deleted";
}

function renderHead() {
  const today = new Date(todayIso() + "T12:00:00");
  $("#today-line").textContent = today.toLocaleDateString(undefined,
    { weekday: "short", month: "short", day: "numeric" })
    + (STATE.block_label ? " · " + STATE.block_label.replace("school day", "day") : "");
  $("#freshness").textContent = STATE.generated_at
    ? "data " + STATE.generated_at.slice(5, 16).replace("T", " ") : "no data";
  const chip = $("#provider-chip");
  if (REMOTE) { chip.hidden = true; $("#refresh").hidden = true; }
  else {
    const status = STATE.provider_status || {};
    const provider = STATE.provider || "none";
    const off = provider === "null" || provider === "none";
    // A demotion is a change in who is answering, so it shows rather than
    // sitting in a log file.
    chip.classList.toggle("chip-warn", !!status.degraded && !off);
    if (status.degraded && !off) {
      chip.title = `Asked for ${status.configured}, actually using `
        + `${status.active}${status.model ? " (" + status.model + ")" : ""}.`
        + (status.skipped && status.skipped.length
           ? " Skipped: " + status.skipped.join(", ") : "")
        + " Answers may be weaker than usual.";
    }
    chip.textContent = off ? "AI: off"
      : (status.degraded ? "AI: " + provider + " (fallback)" : "AI: " + provider);
    chip.title = off
      ? "No AI provider. Assignments and course docs still work — only chat needs one."
      : "AI provider";
    if (off) limitChat();
  }
}

/* No AI installed no longer means no chat: questions about the student's own
   homework and schedule are lookups over data already on the Mac. The box
   stays usable; only the hint changes. */
function limitChat() {
  const hint = $("#chat-hint");
  if (hint) {
    hint.textContent = "no AI on this Mac — I can still answer about your own "
      + "homework, schedule, rooms and grades";
  }
  const input = $("#chat-input");
  if (input) input.placeholder = "what's due tomorrow?";
}

function renderBanners() {
  const box = $("#banners");
  box.innerHTML = "";
  if (STATE.empty) {
    box.innerHTML = `<div class="banner warn">${esc(STATE.message || "no data yet")}</div>`;
    return;
  }
  if (STATE.generated_at) {
    const age = (Date.now() - new Date(STATE.generated_at).getTime()) / 3600000;
    const limit = STATE.stale_after_hours || 18;
    if (age > limit) {
      box.innerHTML += `<div class="banner warn">this data is ${age.toFixed(0)} hours old`
        + (REMOTE ? " — the next scheduled update will replace it"
                  : " — press Refresh") + `</div>`;
    }
  }
  // A subscription that is about to end should never be a surprise. Only the
  // last few days say anything — a fortnight of countdown is nagging.
  const sub = STATE.subscription || {};
  const left = sub.days_left;
  if (!REMOTE && typeof left === "number" && left <= 3
      && (sub.state === "trial" || sub.state === "paid")) {
    const what = sub.state === "trial" ? "free trial" : "subscription";
    const when = left <= 0 ? "today" : left === 1 ? "tomorrow" : `in ${left} days`;
    const price = (sub.price || {}).amount || "5.99";
    box.innerHTML += `<div class="banner warn">your ${esc(what)} ends
      ${esc(when)} — $${esc(price)} a month to keep it${sub.pay_to
        ? `, on Venmo to <strong>${esc(sub.pay_to)}</strong>` : ""}.
      Your homework stays on this Mac either way.</div>`;
  }
  /* On Free, and out of something. Only when an allowance is actually used
     up — being on the free plan is a status, not a problem, and a permanent
     "you could pay us" strip is the nagging this file already refuses to do
     for a trial that has a fortnight left. The refusal itself appears inside
     chat, which is easy to miss if the last thing you pressed was Accelerate,
     so it is said here too. */
  const allow = (STATE.allowance || {});
  if (!REMOTE && sub.plan === "free" && allow.metered) {
    const spent = Object.entries(allow.kinds || {})
      .filter(([, row]) => row && row.exhausted)
      .map(([kind]) => ({ chat: "chat questions", accelerate: "study guides",
                          profiles: "new classes to learn" })[kind] || kind);
    if (spent.length) {
      box.innerHTML += `<div class="banner warn">You have used this month's
        ${esc(spent.join(" and "))} on Free. It resets on the 1st, and
        <strong>Basic is $4.99 a month for five times as much</strong>.
        Your board, dates, schedule and grades are not limited and keep
        working.</div>`;
    }
  }
  // A new version of SchoolDash itself is published. Distinct from the reload
  // banner below: that one means this TAB is behind the running server; this
  // one means the app on disk is behind what has been released.
  if (UPDATE && UPDATE.available && !REMOTE) {
    box.innerHTML += `<div class="banner update" id="update-banner">
      <div class="banner-head"><span>SchoolDash ${esc(UPDATE.latest)} is available</span>
        <span class="muted">you have ${esc(UPDATE.current)}</span></div>
      ${UPDATE.notes ? `<div class="banner-fix">${esc(UPDATE.notes)}</div>` : ""}
      <div class="banner-fix">
        ${UPDATE.can_install
          ? `<button type="button" class="banner-signin update-go" id="update-go">Update now</button>`
          : `<span class="muted">${esc(UPDATE.why_not || "update it the way it was installed")}</span>`}
        <button type="button" class="mini-btn" id="update-later">Not now</button>
        <span class="banner-signin-note" id="update-note"></span>
      </div></div>`;
  }
  if (APP_VERSION_SEEN && STATE.app_version
      && STATE.app_version !== APP_VERSION_SEEN) {
    /* Say what it will look like, not just what happened. [MEASURED]
       2026-09-10: he reported "my grades are not popping up in the grades
       page" while this banner was on screen — the Grades page really was
       blank, because his page was running the previous build. A notice that
       names the SYMPTOM gets read; "has been updated" sounds like news. */
    box.innerHTML += `<div class="banner warn">SchoolDash has been updated, and this
      page is still running the old version — pages may look empty or behave oddly
      until you reload.
      <button type="button" class="banner-signin" id="reload-now">Reload now</button></div>`;
  }
  if (STATE.kept_previous) {
    const when = (STATE.last_attempt || "").slice(5, 16).replace("T", " ");
    box.innerHTML += `<div class="banner warn">this is your last good data —
      the update${when ? " at " + esc(when) : ""} could not reach anything, so
      nothing was overwritten. Press Refresh when you are back online.</div>`;
  }
  for (const err of STATE.errors || []) {
    const message = String(err.message || "")
      .replace(/\s*(?:[—-]\s*)?fix:.*$/i, "").trim();
    const fix = REMOTE ? "" : String(err.fix || "").trim();
    // A session error gets a BUTTON, not a command: the ~150-character command
    // is what actually failed on paste. It is kept, folded away.
    const signIn = SIGN_IN_FOR[err.code];
    box.innerHTML += `<div class="banner error" data-code="${esc(err.code)}">
      <div class="banner-head"><span class="banner-code">${esc(err.code)}</span>
        <span>${esc(message || err.message || "something went wrong")}</span></div>
      ${signIn && !REMOTE ? `<div class="banner-fix">
          <button type="button" class="banner-signin" data-kind="${signIn.kind}">
            ${esc(signIn.label)}</button>
          <span class="banner-signin-note"></span>
        </div>` : ""}
      ${fix ? `<details class="banner-cmd"><summary>or do it in Terminal</summary>
        <code>${esc(fix)}</code></details>` : ""}</div>`;
  }
  wireSignInButtons();
  wireUpdateButton();
  const reloadBtn = $("#reload-now");
  if (reloadBtn) reloadBtn.addEventListener("click", () => location.reload());
}

/* ---------------- updating the app ----------------
   The check is a cached read on the server, so this costs nothing on a page
   load; the banner only appears when a NEWER version is actually published.
   Dismissing hides that version until a newer one turns up — a banner that
   comes back every minute is one nobody reads. */
let UPDATE = null;
let UPDATE_DISMISSED = "";
try { UPDATE_DISMISSED = localStorage.getItem("schooldash.update.dismissed") || ""; }
catch (e) { /* private mode */ }

async function checkUpdate(force) {
  if (REMOTE) return null;
  try {
    const res = await fetch(`/api/update${force ? "?force=1" : ""}`);
    const out = await res.json();
    if (out && out.available && out.latest === UPDATE_DISMISSED && !force) {
      out.available = false;      // he said not now, and it is the same version
    }
    UPDATE = out;
    return out;
  } catch (e) {
    return null;                  // offline is not news
  }
}
window.checkUpdate = checkUpdate;
window.updateStatus = () => UPDATE;

function wireUpdateButton() {
  const later = $("#update-later");
  if (later) later.addEventListener("click", () => {
    try {
      if (UPDATE && UPDATE.latest) localStorage.setItem("schooldash.update.dismissed", UPDATE.latest);
      UPDATE_DISMISSED = (UPDATE || {}).latest || "";
    } catch (e) { /* fine */ }
    if (UPDATE) UPDATE.available = false;
    renderBanners();
  });
  const go = $("#update-go");
  if (go) go.addEventListener("click", () => runUpdate(go, $("#update-note")));
}

/* Download, swap, restart — with every step on screen, because this replaces
   the app someone is looking at and a silent minute would read as a hang. */
async function runUpdate(button, note) {
  const say = (text) => { if (note) note.textContent = " " + text; };
  button.disabled = true;
  say("downloading…");
  try {
    const started = await (await fetch("/api/update", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })).json();
    if (started.error) throw new Error(started.error.message);
    if (!started.job_id) throw new Error("could not start the update");
    let seen = 0, result = null;
    for (let n = 0; n < 400; n++) {
      await new Promise((r) => setTimeout(r, 1200));
      const job = await (await fetch(`/api/jobs/${started.job_id}`)).json();
      for (; seen < (job.lines || []).length; seen++) say(job.lines[seen]);
      if (job.done) {
        if (!job.ok) throw new Error(job.error || "the update did not finish");
        result = job.result;
        break;
      }
    }
    if (!result) throw new Error("the update is taking too long — try again later");
    say(`installed ${result.installed} — restarting…`);
    // The server is about to be replaced by one running the new code. It
    // answers this call and then exits, so a failure to reach it afterwards
    // is expected rather than an error.
    try {
      await fetch("/api/update/restart", { method: "POST" });
    } catch (e) { /* it went away, which is the point */ }
    for (let n = 0; n < 60; n++) {
      await new Promise((r) => setTimeout(r, 1000));
      try {
        const health = await fetch("/api/health", { cache: "no-store" });
        const body = await health.json();
        if (body.version === result.installed) { location.reload(); return; }
      } catch (e) { /* still down */ }
    }
    say("the new version is installed — quit SchoolDash and open it again to finish");
    button.disabled = false;
  } catch (err) {
    say("could not update: " + err.message);
    button.disabled = false;
  }
}

window.runUpdateFromSettings = (button, note) => runUpdate(button, note);

/* Which errors a person can clear themselves, and what the button says. */
const SIGN_IN_FOR = {
  canvas_session: { kind: "canvas", label: "Sign in to Canvas" },
  veracross_grades: { kind: "veracross", label: "Sign in to Veracross" },
  class_feed: { kind: "veracross", label: "Sign in to Veracross" },
};

function wireSignInButtons() {
  document.querySelectorAll(".banner-signin[data-kind]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const note = btn.parentElement.querySelector(".banner-signin-note");
      btn.disabled = true;
      const say = (text) => { if (note) note.textContent = " " + text; };
      say("opening the sign-in window…");
      try {
        const res = await fetch("/api/login", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ kind: btn.dataset.kind, auto: true }),
        });
        const out = await res.json();
        if (out.error) throw new Error(out.error.message);
        // "already running" is not a dead end: a window IS open, the server
        // has just raised it, and the job it belongs to is still worth
        // following — otherwise pressing twice loses the sign-in in progress.
        if (!out.started) {
          say(out.message || "a sign-in is already running");
          if (!out.job_id) { btn.disabled = false; return; }
        } else {
          say(out.window
            ? `signing in… if a window opens it is called “${out.window}”`
            : "signing in… a window opens only if a step needs you");
        }
        for (let n = 0; n < 800; n++) {
          await new Promise((r) => setTimeout(r, 3000));
          const check = await fetch(`/api/login/${out.job_id}`);
          const status = await check.json();
          if (!status.done) continue;
          if (status.ok) {
            say("signed in — refreshing…");
            await refresh();
          } else {
            const why = (status.results || []).filter((r) => !r.ok).map((r) => r.message).join("; ");
            say("that did not finish" + (why ? ": " + why : ".") + " Check Settings → your sign-ins, or try again.");
            btn.disabled = false;
          }
          return;
        }
        say("still waiting — finish the sign-in in the other window");
        btn.disabled = false;
      } catch (err) {
        say("could not start it: " + err.message);
        btn.disabled = false;
      }
    });
  });
}

/* ---------------- adding work that is not in Canvas ----------------
   A form, not a chat message: it needs no AI. It lives in its own pane and
   outside every .panel-body, because fillPanel() overwrites those. */
function fillCourseList() {
  const list = $("#add-course-list");
  if (!list) return;
  const names = new Set();
  for (const g of STATE.grades || []) names.add(shortCourse(g.display_name));
  for (const p of STATE.profiles || []) names.add(shortCourse(p.display_name || p.course_raw));
  for (const i of STATE.items || []) names.add(shortCourse(i.course));
  names.delete(""); names.delete("Personal");
  list.innerHTML = [...names].sort().map((n) => `<option value="${esc(n)}">`).join("");
}

function openAdd(section) {
  const form = $("#add-form");
  if (!form) return;
  showPane("add");
  const sel = $("#add-section");
  if (sel && section !== undefined) sel.value = section || "";
  const title = $("#add-title");
  if (title) title.focus();
}
window.openAdd = openAdd;

function wireAddForm() {
  const open = $("#add-open");
  const form = $("#add-form");
  if (!open || !form) return;
  const note = $("#add-note");
  const title = $("#add-title");
  open.addEventListener("click", () => openAdd(""));
  const personal = $("#personal-add");
  if (personal) personal.addEventListener("click", () => openAdd("goals"));
  const cancel = $("#add-cancel");
  if (cancel) cancel.addEventListener("click", () => { form.reset(); showPane("chat"); });

  form.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const body = {
      title: title.value.trim(),
      due_date: $("#add-due").value || null,
      category: $("#add-category").value || null,
      course: $("#add-course").value.trim() || null,
      section: ($("#add-section") || {}).value || null,
      notes: (($("#add-notes") || {}).value || "").trim() || null,
    };
    if (!body.title) { title.focus(); return; }
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true; button.textContent = "Adding…";
    note.hidden = true;
    try {
      const res = await fetch("/api/tasks", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const out = await res.json();
      if (out.error) throw new Error(out.error.message);
      form.reset();
      note.hidden = false;
      // Say what it was filed as: the type decides whether this becomes a
      // study reminder, and a silent guess is one the person cannot correct.
      const filed = (out.task || {}).category;
      note.textContent = `Added${filed ? ` as a ${filed.replace("_", " ")}` : ""}. Add another, or press ‹ to go back.`;
      await loadState();
    } catch (err) {
      note.hidden = false;
      note.textContent = "could not add it: " + err.message;
    }
    button.disabled = false; button.textContent = "Add it";
  });
}

/* ---------------- study nudges ----------------
   A quiz is not homework you hand in; it is homework you must have done
   BEFORE the day. This is a hint attached to a real item, never a new one:
   inventing a "study for X" task would be inventing an assignment. */
const STUDY_LEAD_DAYS = { test: 3, quiz: 2, project: 3, essay: 2 };

function studyHint(item, today) {
  const lead = STUDY_LEAD_DAYS[item.category];
  if (!lead || item.done) return null;
  const days = daysUntil(item.due_date, today);
  if (days === null || days < 0 || days > lead) return null;
  const what = item.category === "quiz" ? "quiz"
    : item.category === "test" ? "test" : item.category;
  if (days === 0) return `${what} is today`;
  if (days === 1) return `${what} tomorrow — study tonight`;
  return `${what} in ${days} days — start studying`;
}

/* The most urgent thing to revise, if anything. Drives one line in the brief. */
function nextStudy(state) {
  const today = state.today;
  let best = null;
  for (const item of state.items || []) {
    const hint = studyHint(item, today);
    if (!hint) continue;
    const days = daysUntil(item.due_date, today);
    if (best === null || days < best.days) best = { item, hint, days };
  }
  return best;
}

/* ---------------- section logic ---------------- */
function clubCourseKeys() {
  const keys = new Set();
  for (const p of STATE.profiles || []) {
    if (["club", "community"].includes(p.course_type)) keys.add(p.course_key);
  }
  return keys;
}
const HEAVY = new Set(["test", "project", "essay", "quiz"]);
/* A test or a quiz is an event, not something handed in, so once it is past
   there is nothing to be late for. It stays on the board — labelled as past —
   and stops inflating the overdue count. */
const ASSESSMENTS = new Set(["test", "quiz"]);
function isPastAssessment(item, today) {
  return ASSESSMENTS.has(item.category) && !!item.due_date
    && item.due_date < today && !item.done;
}
/* Personal work: a goal, a practice, makeup, a club — anything the student
   filed somewhere other than "school work" when adding it. Homework never
   lands here by accident: only an explicit section flag qualifies. */
const PERSONAL_SECTIONS = { goals: "Goals", practice: "Practice", makeup: "Makeup work",
                            clubs: "Clubs", personal: "Personal" };
function personalSection(item) {
  for (const flag of item.flags || []) {
    if (flag.startsWith("section:")) return flag.slice(8);
    if (flag === "clubs" && item.source === "custom") return "clubs";
  }
  return null;
}

function sections() {
  const today = todayIso();
  const tomorrow = isoPlus(today, 1);
  const clubs = clubCourseKeys();
  const isClub = (i) => clubs.has(i.course_key)
    || (i.flags || []).includes("clubs");
  const items = STATE.items || [];
  const out = {
    tomorrow: { open: [], done: [] },
    later: { open: [], done: [] },
    upcoming: { open: [], done: [] },
    clubs: { open: [], done: [] },
    personal: { open: [], done: [] },
  };
  /* One item, one place. An assessment lives in exactly one time bucket, and
     "upcoming" is built from the same objects for a strip that NAMES what is
     coming without repeating the row. */
  for (const i of items) {
    if (personalSection(i)) {
      (i.done ? out.personal.done : out.personal.open).push(i);
      continue;
    }
    const d = i.due_date;
    const when = (d && d <= tomorrow) ? "tomorrow" : "later";
    const names = [when];
    if (isClub(i)) names.push("clubs");
    for (const name of names) {
      (i.done ? out[name].done : out[name].open).push(i);
    }
    if (HEAVY.has(i.category) && !i.done && (!d || d >= today)) {
      out.upcoming.open.push(i);
    }
  }
  out.upcoming.open.sort((a, b) => (a.due_date || "9999") < (b.due_date || "9999") ? -1 : 1);
  out.clubs.open.sort((a, b) => (a.due_date || "9999") < (b.due_date || "9999") ? -1 : 1);
  return { out, today, tomorrow };
}

function rowHtml(item, context, firstId) {
  const today = todayIso();
  const past = isPastAssessment(item, today);
  const overdue = item.due_date && item.due_date < today && !item.done && !past;
  const tags = [];
  if (overdue) tags.push(`<span class="tag overdue">overdue</span>`);
  if (past) tags.push(`<span class="tag was">was ${esc(niceDate(item.due_date))}</span>`);
  if (HEAVY.has(item.category) && context !== "upcoming")
    tags.push(`<span class="tag ${esc(item.category)}">${esc(item.category)}</span>`);
  if (context === "upcoming")
    tags.push(`<span class="tag ${esc(item.category)}">${esc(item.category)}</span>`);
  if (item.source === "custom" && context !== "personal") tags.push(`<span class="tag custom">yours</span>`);
  const study = studyHint(item, today);
  if (study) tags.push(`<span class="tag study">${esc(study)}</span>`);
  /* The one to start with, marked on the row rather than shown again above
     it. [MEASURED] 2026-09-10: the simple layout put a "START HERE" card at
     the top of the To-do page and the same assignment appeared as a row a
     hundred pixels below — one title, twice, on the page whose whole purpose
     was to stop showing things twice. The recommendation belongs on the thing
     it recommends: same tick box, same tap, and the reason underneath it. */
  const first = !!firstId && item.item_id === firstId && !item.done;
  if (first) tags.unshift(`<span class="tag first">start here</span>`);
  const why = first ? focusWhy(item) : "";
  /* A checkbox beside a real <button>, not a div pretending to be one.
     [PROVEN] tests/test_prosecution.py: role="button" wrapped around an
     <input> is invalid, the row had no accessible name, and every checkbox
     said the same word. A real button brings Enter and Space for free. */
  const label = item.title || "this item";
  const due = context === "personal" && !item.due_date ? "" : dueLabel(item);
  const course = context === "personal" && shortCourse(item.course) === "Personal" ? "" : nick(item.course);
  return `<div class="row${item.done ? " done-row" : ""}${overdue ? " is-overdue" : ""}${first ? " is-first" : ""}${SELECTED === item.item_id ? " selected" : ""}" ${classStyle(item.course_key)}>
    <input type="checkbox" class="tick" ${item.done ? "checked" : ""}
           aria-label="Mark ${esc(label)} done" data-id="${esc(item.item_id)}">
    <button type="button" class="row-open" data-id="${esc(item.item_id)}">
      <span class="row-title">${esc(item.title)}</span>
      <span class="row-sub">${due ? `<span>${esc(due)}</span>` : ""}
        ${course ? `<span class="row-course">${esc(course)}</span>` : ""}
        ${item.est_label ? `<span>${esc(item.est_label)}</span>` : ""}
        ${item.points ? `<span>${esc(item.points)} pts</span>` : ""}${tags.join("")}</span>
      ${why ? `<span class="row-why">${why}</span>` : ""}
    </button>
    ${REMOTE || item.done ? "" : `<button type="button" class="row-accel" data-id="${esc(item.item_id)}"
       title="Accelerate: a study guide from the actual material" aria-label="Accelerate ${esc(label)}">⚡</button>`}</div>`;
}

function listHtml(groups, context, firstId) {
  let html = "";
  for (const [label, list, meta, urgent] of groups) {
    if (!list.length) continue;
    if (label) html += `<div class="group-label${urgent ? " urgent" : ""}">${esc(label)}
      <span class="gl-meta">${esc(meta || "")}</span></div>`;
    html += list.map(i => rowHtml(i, context, firstId)).join("");
  }
  return html || `<div class="empty-note">nothing here — enjoy it ✓</div>`;
}

/* How the Assignments box is ordered. "smart" is the pipeline's ranking —
   urgency, kind, points, the grade nudge — inside due-date sections, with
   longer work first when two things tie; the others are for when he wants a
   different question answered. */
const SORT_MODES = ["smart", "due", "class", "time"];
const SORT_LABEL = { smart: "smart", due: "by date", class: "by class", time: "longest first" };

function renderPanels() {
  const { out, today, tomorrow } = sections();
  const open = [...out.tomorrow.open, ...out.later.open];
  const bySmart = (a, b) => (b.score || 0) - (a.score || 0)
    || (b.est_minutes || 0) - (a.est_minutes || 0) || String(a.title).localeCompare(b.title);
  const byDate = (a, b) => (a.due_date || "9999") === (b.due_date || "9999")
    ? bySmart(a, b) : ((a.due_date || "9999") < (b.due_date || "9999") ? -1 : 1);
  const byTime = (a, b) => (b.est_minutes || 0) - (a.est_minutes || 0) || bySmart(a, b);
  const est = (list) => minutesLabel(list.reduce((s, i) => s + (i.est_minutes || 0), 0));
  const meta = (list) => [list.length, est(list)].filter(Boolean).join(" · ");
  const mode = SORT_MODES.includes(PREFS.assignSort) ? PREFS.assignSort : "smart";
  const sortBtn = $("#assign-sort");
  // A bare word ("smart") does not read as something you can press. The
  // sort glyph says it is a control and what kind.
  if (sortBtn) sortBtn.textContent = "\u21C5 " + SORT_LABEL[mode];
  /* Only the simple layout marks it, and only in the To-do list. On the
     dashboard the brief's card sits in a different column from Assignments,
     where a callout is not a repetition of the row beside it. */
  const firstId = isSimple() ? ((currentFocus() || {}).item_id || null) : null;

  let assignHtml = "";
  if (mode === "class") {
    /* One dropdown per class, headed by the nearest thing due. <details>
       rather than a click handler: keyboard support and the open state come
       free, and which classes are open is remembered because render() runs on
       every refresh. */
    const groups = new Map();
    for (const item of [...open].sort(byDate)) {
      const name = shortCourse(item.course) || "no class";
      if (!groups.has(name)) groups.set(name, []);
      groups.get(name).push(item);
    }
    const soonest = (list) => list.reduce(
      (best, i) => (i.due_date && (!best || i.due_date < best)) ? i.due_date : best, null);
    const ordered = [...groups.entries()].sort((a, b) => {
      const da = soonest(a[1]) || "9999", db = soonest(b[1]) || "9999";
      return da === db ? a[0].localeCompare(b[0]) : (da < db ? -1 : 1);
    });
    const openClasses = classesOpen();
    assignHtml = ordered.map(([name, items]) => {
      const next = items.find(i => i.due_date) || items[0];
      const when = next && next.due_date ? relDays(next.due_date, today) : "no date yet";
      return `<details class="class-group" data-class="${esc(name)}" ${openClasses.has(name) ? "open" : ""}>
        <summary ${classStyle(items[0].course_key)}>
          <span class="cg-name" title="${esc(name)}">${esc(name)}</span>
          <span class="cg-next">${next ? esc(next.title) : ""}</span>
          <span class="cg-when">${esc(when)}</span>
          <span class="cg-count">${items.length}</span>
        </summary>
        <div class="cg-rows">${listHtml([["", items]], "upcoming", firstId)}</div>
      </details>`;
    }).join("") || `<div class="empty-note">nothing open — enjoy it ✓</div>`;
  } else if (mode === "due") {
    assignHtml = listHtml([["", [...open].sort(byDate)]], "due", firstId);
  } else {
    const within = (a, b) => (mode === "time" ? byTime : bySmart)(a, b);
    const week = isoPlus(today, 7);
    const past = open.filter(i => isPastAssessment(i, today));
    const live = open.filter(i => !isPastAssessment(i, today));
    const pick = (test) => live.filter(test).sort(within);
    const overdue = pick(i => i.due_date && i.due_date < today);
    const todayL = pick(i => i.due_date === today);
    const tomorrowL = pick(i => i.due_date === tomorrow);
    const weekL = pick(i => i.due_date && i.due_date > tomorrow && i.due_date <= week);
    const laterL = pick(i => i.due_date && i.due_date > week);
    const undated = pick(i => !i.due_date);
    assignHtml = listHtml([
      ["overdue", overdue, meta(overdue), true],
      ["today", todayL, meta(todayL)],
      ["tomorrow", tomorrowL, meta(tomorrowL)],
      ["this week", weekL, meta(weekL)],
      ["later", laterL, meta(laterL)],
      ["no date", undated, meta(undated)],
      ["already happened", past.sort(byDate), "make-up?"],
    ], "due", firstId);
  }
  const doneCount = (STATE.items || []).filter(i => i.done && !personalSection(i)).length;
  const tonight = open.filter(i => i.due_date && i.due_date <= tomorrow && !isPastAssessment(i, today));
  const tonightMin = tonight.reduce((s, i) => s + (i.est_minutes || 0), 0);
  assignHtml += `<div class="panel-foot">
      <span>${tonight.length ? `by tomorrow: ${tonight.length} · ${esc(minutesLabel(tonightMin) || "~0m")}` : "nothing due by tomorrow ✓"}</span>
      ${doneCount ? `<button type="button" class="mini-btn" data-pane="done">${doneCount} done ›</button>` : ""}
    </div>`;
  fillPanel("tomorrow", assignHtml, open.length, []);
  /* Whether the card at the top of the page may be hidden: only when the row
     it would have duplicated is really on this list. A club or a personal
     item can be the pick and not appear in Assignments at all, and hiding the
     card unconditionally would have deleted the recommendation instead of
     moving it. Set as a class on <body> so the two renderers can run in
     either order — CSS is applied after both. */
  document.body.classList.toggle("first-on-row",
    !!firstId && open.some((i) => i.item_id === firstId && !i.done));

  /* "Due now" — the Calendar page's side list. Same rows, same sections, same
     sections() buckets as Assignments: `out.tomorrow` IS overdue + today +
     tomorrow, so this is that bucket and not a fourth definition of "soon". */
  const soonOverdue = out.tomorrow.open.filter((i) => i.due_date && i.due_date < today
    && !isPastAssessment(i, today)).sort(bySmart);
  const soonToday = out.tomorrow.open.filter((i) => i.due_date === today).sort(bySmart);
  const soonTomorrow = out.tomorrow.open.filter((i) => i.due_date === tomorrow).sort(bySmart);
  const soonCount = soonOverdue.length + soonToday.length + soonTomorrow.length;
  fillPanel("duesoon", soonCount ? listHtml([
    ["overdue", soonOverdue, meta(soonOverdue), true],
    ["today", soonToday, meta(soonToday)],
    ["tomorrow", soonTomorrow, meta(soonTomorrow)],
  ], "due", firstId) : `<div class="empty-note">nothing due today or tomorrow \u2713</div>`,
    soonCount, []);

  /* Tests & quizzes: what is coming, how many days there are to prepare, and
     a Study button that writes the guide. The row itself lives in
     Assignments, one click away; this strip names it without repeating it. */
  const ahead = out.upcoming.open;
  fillPanel("upcoming", ahead.length
    ? `<div class="ahead">` + ahead.map(i => {
        const days = daysUntil(i.due_date, today);
        const soon = days !== null && days <= 2;
        return `<div class="ahead-row" ${classStyle(i.course_key)}>
          <span class="ahead-when${soon ? " soon" : ""}"><b>${esc(i.due_date ? relDays(i.due_date, today) : "no date")}</b>${esc(i.due_date ? niceDate(i.due_date) : "")}</span>
          <button type="button" class="row-open ahead-what" data-id="${esc(i.item_id)}">${esc(i.title)}
            <small>${esc(nick(i.course))}${i.points ? ` · ${esc(i.points)} pts` : ""}</small></button>
          <span class="tag ${esc(i.category)}">${esc(i.category)}</span>
          ${REMOTE ? "" : `<button type="button" class="ahead-study row-accel-btn" data-id="${esc(i.item_id)}" title="Accelerate: a study guide for this">⚡</button>`}
        </div>`;
      }).join("") + `</div>`
    : `<div class="empty-note">nothing big coming up ✓</div>`,
    out.upcoming.open.length, out.upcoming.done);
  fillPanel("clubs", listHtml([["", out.clubs.open]], "clubs"),
            out.clubs.open.length, out.clubs.done);

  /* Personal: goals, practices, makeup, clubs — grouped by where he filed
     them. Empty is not an error; it is an invitation. */
  const personalGroups = new Map();
  for (const i of [...out.personal.open].sort(byDate)) {
    const key = personalSection(i) || "personal";
    if (!personalGroups.has(key)) personalGroups.set(key, []);
    personalGroups.get(key).push(i);
  }
  fillPanel("personal", personalGroups.size
    ? listHtml([...personalGroups.entries()].map(([k, list]) => [PERSONAL_SECTIONS[k] || k, list, meta(list)]), "personal")
    : `<div class="empty-note">nothing here yet — a goal, a practice, makeup work, a club.
       ${REMOTE ? "" : `<button type="button" class="mini-btn" data-add="goals">+ add one</button>`}</div>`,
    out.personal.open.length, out.personal.done);

  /* The Done pane: Canvas knows what was handed in, so those arrive without
     him ticking anything. Newest first. */
  const finished = (STATE.items || []).filter(i => i.done);
  finished.sort((a, b) => (b.due_date || "") < (a.due_date || "") ? -1 : 1);
  const byWho = (list, submitted) => list.filter(i => !!i.submitted === submitted);
  fillPanel("done", finished.length
    ? listHtml([
        ["handed in on Canvas", byWho(finished, true), String(byWho(finished, true).length)],
        ["ticked off here", byWho(finished, false), String(byWho(finished, false).length)],
      ], "done")
    : `<div class="empty-note">nothing finished yet — tick something off, or
       hand it in on Canvas and it will appear here</div>`,
    finished.length, []);

  document.querySelectorAll(".class-group").forEach((group) =>
    group.addEventListener("toggle", () => {
      const openSet = classesOpen();
      if (group.open) openSet.add(group.dataset.class);
      else openSet.delete(group.dataset.class);
      try {
        localStorage.setItem("schooldash.classes", JSON.stringify([...openSet]));
      } catch (e) { /* a private window is not a reason to break the page */ }
    }));
  document.querySelectorAll(".row-open").forEach((openBtn) => {
    openBtn.addEventListener("click", () => openDetail(openBtn.dataset.id));
  });
  document.querySelectorAll(".row-accel, .row-accel-btn").forEach((btn) => {
    btn.addEventListener("click", (ev) => {
      ev.stopPropagation();
      const item = (STATE.items || []).find(i => i.item_id === btn.dataset.id);
      if (item && window.openAccelerate) window.openAccelerate(item.item_id, item.title);
    });
  });
  document.querySelectorAll(".tick").forEach((tick) => {
    tick.addEventListener("click", (ev) => {
      ev.stopPropagation();
      toggleDone(tick.dataset.id, tick.checked);
    });
  });
  document.querySelectorAll("[data-pane]").forEach((b) =>
    b.addEventListener("click", () => {
      // "12 done >" and friends: a real move to another page in the simple
      // layout, where showPane alone would draw into a hidden column.
      if (isSimple() && TAB_KEYS.includes(b.dataset.pane)) showTab(b.dataset.pane);
      else showPane(b.dataset.pane);
    }));
  document.querySelectorAll("[data-add]").forEach((b) =>
    b.addEventListener("click", () => openAdd(b.dataset.add)));
}

/* How much of a column's spare height each box earns per item it holds. */
const PANEL_WEIGHT = { tomorrow: 3, upcoming: 3, personal: 1.2, grades: 1.3, focus: 1, schedule: 1.5 };

/* Which class dropdowns are open, remembered across refreshes. */
function classesOpen() {
  try {
    return new Set(JSON.parse(localStorage.getItem("schooldash.classes")) || []);
  } catch (e) {
    return new Set();
  }
}

function fillPanel(name, html, openCount, doneList) {
  const panel = document.querySelector(`[data-panel="${name}"]`);
  /* A panel that is not on the page any more is not an error: the bucket
     behind it may still be computed for a count elsewhere. Without this
     guard, retiring a panel throws here and blanks the whole app. */
  if (!panel) return;
  const body = panel.querySelector(".panel-body");
  const badge = panel.querySelector(".count");
  if (badge) {
    badge.textContent = String(openCount);
    badge.classList.toggle("zero", openCount === 0);
  }
  panel.classList.toggle("is-empty",
    openCount === 0 && !(doneList && doneList.length) && name !== "tomorrow");
  // Share out the column's spare height by content, sublinear, weighted by
  // urgency: what is due now beats how much is queued behind it.
  panel.style.setProperty(
    "--grow",
    (PANEL_WEIGHT[name] || 1) * (1 + Math.sqrt(Math.min(openCount, 36))));
  let doneHtml = "";
  if (doneList && doneList.length) {
    doneHtml = `<details class="done-group"><summary>done (${doneList.length})</summary>
      ${doneList.map(i => rowHtml(i, "due")).join("")}</details>`;
  }
  if (body) body.innerHTML = html + doneHtml;
}

/* ---------------- calendar ----------------
   Day: the timetable for one day, each class with what is due for it that
   day. Week: five (or seven) columns of the same. Both read the same
   `schedule` map from the class feed; nothing here is invented. */
function dueOn(day) {
  return (STATE.items || []).filter(i => i.due_date === day && !personalSection(i));
}
function mondayOf(iso) {
  const d = new Date(iso + "T12:00:00");
  const back = (d.getDay() + 6) % 7;
  return isoPlus(iso, -back);
}
/* The 1st of the month `offset` months from today, as an ISO date. Built from
   the parts rather than by adding days, because months are 28-31 days long and
   "a month from the 31st" has no answer worth guessing. */
function monthStart(todayIso, offset) {
  const d = new Date(todayIso + "T12:00:00");
  const m = new Date(d.getFullYear(), d.getMonth() + (offset || 0), 1, 12);
  return `${m.getFullYear()}-${String(m.getMonth() + 1).padStart(2, "0")}-01`;
}

function renderSchedule() {
  const today = todayIso();
  const list = $("#schedule-list");
  const label = $("#day-label");
  if (!list || !label) return;
  document.querySelectorAll("[data-cal]").forEach((b) => b.classList.toggle("active", b.dataset.cal === CAL_MODE));
  const schedule = STATE.schedule || {};
  const now = STATE.now ? STATE.now.slice(11, 16) : "";
  const stale = staleNoteHtml(STATE.schedule_stale, "the last refresh could not read the class feed");
  const schedPanel = document.querySelector('[data-panel="schedule"]');

  if (CAL_MODE === "month") {
    /* *"make the calendar look like a calendar"* — a real grid, seven columns,
       weeks as rows. The day and week views are lists, which is right for the
       248px-wide dashboard column but is not what anyone means by a calendar.
       Month only earns its keep on a page that is the whole width, so the
       simple layout defaults to it and the dashboard keeps Day.

       SCHED_OFFSET counts MONTHS here, the way it counts days in Day and
       weeks in Week — the same three arrows drive all three. */
    const base = monthStart(today, SCHED_OFFSET);
    const first = new Date(base + "T12:00:00");
    label.textContent = first.toLocaleDateString(undefined, { month: "long", year: "numeric" })
      + (SCHED_OFFSET === 0 ? " · this month" : "");
    // Monday-first, and the grid always starts on the Monday on or before the
    // 1st so the columns line up with the weekday headings.
    const gridStart = mondayOf(base);
    const cells = [];
    for (let n = 0; n < 42; n++) {
      const iso = isoPlus(gridStart, n);
      if (n >= 35 && iso.slice(0, 7) !== base.slice(0, 7)) break;   // no empty 6th row
      cells.push(iso);
    }
    const names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    list.innerHTML = stale
      + `<div class="cal-head">${names.map((n) => `<span>${n}</span>`).join("")}</div>`
      + `<div class="cal-grid">` + cells.map((iso) => {
        const meetings = schedule[iso] || (iso === today ? STATE.meetings_today : null) || [];
        const dues = dueOn(iso).filter((i) => !i.done);
        const outside = iso.slice(0, 7) !== base.slice(0, 7);
        const d = new Date(iso + "T12:00:00");
        return `<button type="button" class="cal-cell${iso === today ? " today" : ""}${outside ? " outside" : ""}"
            data-day="${esc(iso)}" title="${esc(niceDate(iso))} — ${meetings.length} class(es), ${dues.length} due">
          <span class="cal-n">${d.getDate()}</span>
          ${dues.length ? `<span class="cal-due">${dues.length}</span>` : ""}
          <span class="cal-dots">${meetings.slice(0, 6).map((m) =>
            `<i ${classStyle(m.course_key)}></i>`).join("")}</span>
          ${dues.slice(0, 2).map((i) => `<span class="cal-item ${esc(i.category)}"
             ${classStyle(i.course_key)}>${esc(i.title)}</span>`).join("")}
          ${dues.length > 2 ? `<span class="cal-more">+${dues.length - 2} more</span>` : ""}
        </button>`;
      }).join("") + `</div>`;
    if (schedPanel) {
      const inMonth = cells.filter((c) => c.slice(0, 7) === base.slice(0, 7));
      const total = inMonth.reduce((sum, c) => sum + (schedule[c] || []).length, 0);
      schedPanel.querySelector(".schedule-day").textContent = String(total);
      schedPanel.classList.toggle("is-empty", false);
      schedPanel.style.setProperty("--grow", PANEL_WEIGHT.schedule * (1 + Math.sqrt(8)));
    }
    // Tapping a day opens that day, which is the whole point of a month view.
    list.querySelectorAll(".cal-cell").forEach((b) => b.addEventListener("click", () => {
      CAL_MODE = "day";
      SCHED_OFFSET = daysUntil(b.dataset.day, today);
      renderSchedule();
    }));
  } else if (CAL_MODE === "week") {
    const monday = mondayOf(isoPlus(today, SCHED_OFFSET * 7));
    const days = [];
    for (let n = 0; n < 7; n++) days.push(isoPlus(monday, n));
    const shown = days.filter((d, n) => n < 5 || PREFS.showWeekends
      || (schedule[d] || []).length || dueOn(d).length);
    const md = (iso) => new Date(iso + "T12:00:00").toLocaleDateString(undefined, { month: "short", day: "numeric" });
    label.textContent = `${md(monday)} – ${md(shown[shown.length - 1])}` + (SCHED_OFFSET === 0 ? " · this week" : "");
    list.innerHTML = stale + `<div class="week">` + shown.map((day) => {
      const meetings = schedule[day] || (day === today ? STATE.meetings_today : null) || [];
      const dues = dueOn(day);
      const d = new Date(day + "T12:00:00");
      return `<div class="week-day">
        <button type="button" class="week-head${day === today ? " today" : ""}" data-day="${esc(day)}"
                title="open this day">${esc(d.toLocaleDateString(undefined, { weekday: "short" }))}<b>${d.getDate()}</b></button>
        ${meetings.map((m) => `<button type="button" class="week-meet" data-course="${esc(m.course_key)}"
            ${classStyle(m.course_key)} title="${esc(shortCourse(m.course_raw))}${m.room ? " · " + esc(m.room) : ""}">${esc(nick(m.course_raw))}
            <small>${esc((m.start || "").slice(11, 16))}</small></button>`).join("")}
        ${dues.map((i) => `<button type="button" class="week-due ${esc(i.category)}${i.done ? " done-row" : ""}"
            data-id="${esc(i.item_id)}" title="${esc(i.title)} · ${esc(shortCourse(i.course))}">${esc(i.title)}</button>`).join("")}
        ${!meetings.length && !dues.length ? `<div class="week-none">—</div>` : ""}
      </div>`;
    }).join("") + `</div>`;
    const total = shown.reduce((s, d) => s + (schedule[d] || []).length, 0);
    if (schedPanel) {
      schedPanel.querySelector(".schedule-day").textContent = String(total);
      schedPanel.classList.toggle("is-empty", false);
      schedPanel.style.setProperty("--grow", PANEL_WEIGHT.schedule * (1 + Math.sqrt(6)));
    }
    list.querySelectorAll(".week-head").forEach((b) => b.addEventListener("click", () => {
      CAL_MODE = "day";
      SCHED_OFFSET = daysUntil(b.dataset.day, today);
      renderSchedule();
    }));
  } else {
    const day = isoPlus(today, SCHED_OFFSET);
    label.textContent = niceDate(day) + (SCHED_OFFSET === 0 ? " (today)" : SCHED_OFFSET === 1 ? " (tomorrow)" : "");
    const meetings = schedule[day] || (SCHED_OFFSET === 0 ? STATE.meetings_today : null) || [];
    const dues = dueOn(day);
    const dueFor = (key) => dues.filter(i => i.course_key === key && !i.done);
    list.innerHTML = stale + (meetings.length ? meetings.map((m) => {
      const start = (m.start || "").slice(11, 16);
      const end = (m.end || "").slice(11, 16);
      const current = SCHED_OFFSET === 0 && start && now >= start && now <= end;
      const past = SCHED_OFFSET === 0 && end && now > end;
      const due = dueFor(m.course_key);
      return `<button type="button" class="meeting${current ? " now" : ""}${past ? " past" : ""}" data-course="${esc(m.course_key)}"
          ${classStyle(m.course_key)} title="open ${esc(shortCourse(m.course_raw))}">
        <span class="when">${esc(start)}–${esc(end)}</span>
        <span class="what">${esc(nick(m.course_raw))}</span>
        <span class="where">${esc(m.room || "")}</span>
        ${due.length ? `<span class="due-badge">${due.length} due: ${esc(due.map(i => i.title).join(" · ").slice(0, 70))}</span>` : ""}</button>`;
    }).join("") : `<div class="empty-note">no classes ${SCHED_OFFSET === 0 ? "today" : "that day"}</div>`);
    const other = dues.filter(i => !meetings.some(m => m.course_key === i.course_key) && !i.done);
    if (other.length) {
      list.innerHTML += `<div class="group-label">also due</div>` + other.map(i =>
        `<button type="button" class="week-due ${esc(i.category)}" data-id="${esc(i.item_id)}" style="width:100%;font-size:.7rem;padding:3px 6px">${esc(i.title)} · ${esc(shortCourse(i.course))}</button>`).join("");
    }
    if (schedPanel) {
      schedPanel.querySelector(".schedule-day").textContent = String(meetings.length);
      schedPanel.classList.toggle("is-empty", meetings.length === 0 && !dues.length);
      // Earns height like the other boxes; without this it sat at the floor
      // showing one class of five.
      schedPanel.style.setProperty("--grow",
        PANEL_WEIGHT.schedule * (1 + Math.sqrt(Math.max(3, meetings.length + other.length))));
    }
  }
  list.querySelectorAll("[data-course]").forEach((b) => b.addEventListener("click", () => {
    if (window.openGradePane) window.openGradePane(b.dataset.course);
  }));
  list.querySelectorAll(".week-due").forEach((b) => b.addEventListener("click", () => openDetail(b.dataset.id)));
}
function setCalMode(mode) {
  CAL_MODE = ["week", "month"].includes(mode) ? mode : "day";
  SCHED_OFFSET = 0;
  savePrefs({ calendar: CAL_MODE });
  renderSchedule();
}

/* ---------------- grades (sidebar) ----------------
   Read from the Veracross portal. Two things this must never do: show an
   ungraded course as 0% (the portal reports exactly that), or compute a GPA
   (needs the school's scale and credit weights, which it does not publish). */
function gradeBand(percent) {
  if (percent == null) return "none";
  return percent >= 90 ? "a" : percent >= 80 ? "b" : percent >= 70 ? "c" : "d";
}
function renderGrades() {
  const panel = document.querySelector('[data-panel="grades"]');
  if (!panel) return;
  const grades = STATE.grades || [];
  const summary = STATE.grades_summary || {};
  const list = $("#grades-list");
  const badge = panel.querySelector(".grades-count");
  const sortBtn = $("#grades-sort");
  if (sortBtn) sortBtn.textContent = PREFS.gradeSort === "name" ? "\u21C5 a–z" : "\u21C5 lowest first";

  if (REMOTE) {
    panel.classList.add("is-empty");
    if (badge) badge.textContent = "";
    list.innerHTML = `<div class="empty-note">grades stay on your Mac — they are not part of this shared snapshot</div>`;
    return;
  }
  if (!grades.length) {
    panel.classList.add("is-empty");
    if (badge) badge.textContent = "";
    // "press Refresh" is only true when a refresh could actually help.
    const dead = (STATE.errors || []).find(e => e.code === "veracross_grades");
    const tried = (STATE.warnings || []).some(w => String(w).startsWith("grades:"));
    list.innerHTML = dead
      ? `<div class="empty-note">Veracross needs signing in again — grades cannot
         load until then. Refreshing will not fix it; see the banner above.</div>`
      : tried
      ? `<div class="empty-note">could not read your grades on the last refresh —
         the school portal did not load. Press Refresh to try again.</div>`
      : `<div class="empty-note">no grades read yet — press Refresh</div>`;
    return;
  }
  panel.classList.remove("is-empty");
  /* Height in proportion to how many courses there are, like the homework
     panels: ten rows must not be squeezed to two and a half. */
  panel.style.setProperty("--grow", (PANEL_WEIGHT.grades || 1) * (1 + Math.sqrt(Math.min(grades.length, 16))));
  if (badge) badge.textContent = `${summary.graded || 0}/${summary.courses || grades.length}`;

  const scored = grades.filter(g => g.graded && g.percent != null);
  const pending = grades.filter(g => !g.graded || g.percent == null);
  scored.sort(PREFS.gradeSort === "name"
    ? (a, b) => shortCourse(a.display_name).localeCompare(shortCourse(b.display_name))
    : (a, b) => a.percent - b.percent);
  const openCount = (key) => (STATE.items || []).filter(i => i.course_key === key && !i.done).length;
  // Where a grade came from, so it can be opened at the source. The portal
  // gives a per-course link on some schools' pages and none on others, so this
  // falls back to the portal front page rather than a dead link.
  const portal = STATE.veracross_portal || "";
  const linkFor = (g) => g.detail_url || portal || "";
  const ext = (g) => linkFor(g)
    ? `<a class="grade-ext" href="${esc(linkFor(g))}" target="_blank" rel="noopener"
        title="open ${esc(shortCourse(g.display_name))} in Veracross" aria-label="open in Veracross">↗</a>` : "";
  const row = (g) => {
    const open = openCount(g.course_key);
    return `<div class="grade-row${SELECTED_CLASS === g.course_key ? " selected" : ""}" ${classStyle(g.course_key)}>
      <button type="button" class="grade-open" data-course="${esc(g.course_key)}"
        title="${esc(shortCourse(g.display_name))}${open ? ` · ${open} open` : ""} — every mark, and what each is worth">
        <span class="grade-course">${esc(nick(g.display_name))}</span>
        <span class="grade-letter band-${gradeBand(g.percent)}">${esc(g.letter || "")}</span>
        <span class="grade-pct">${esc(g.percent.toFixed(1))}%</span>
        <span class="grade-bar"><i style="width:${Math.max(2, Math.min(100, g.percent))}%"></i></span>
        <span class="grade-go" aria-hidden="true">\u203A</span>
      </button>${ext(g)}</div>`;
  };
  const pendingRow = (g) => `<div class="grade-row pending" ${classStyle(g.course_key)}>
      <button type="button" class="grade-open" data-course="${esc(g.course_key)}">
        <span class="grade-course">${esc(nick(g.display_name))}</span>
        <span class="grade-none">not graded yet</span></button>${ext(g)}</div>`;
  const mean = scored.length ? scored.reduce((t, g) => t + g.percent, 0) / scored.length : null;
  list.innerHTML =
    staleNoteHtml(STATE.grades_stale, "the last refresh could not read them") +
    scored.map(row).join("") +
    (pending.length ? `<details class="grade-pending"><summary>${pending.length} not graded yet</summary>${pending.map(pendingRow).join("")}</details>` : "") +
    (mean !== null && scored.length > 1
      ? `<div class="grade-summary-line" title="a plain average of the class percentages — not a GPA, which needs the school's scale and credit weights">avg ${mean.toFixed(1)}% · lowest ${scored[0] && PREFS.gradeSort !== "name" ? esc(shortCourse(scored[0].display_name)) : esc(shortCourse(scored.slice().sort((a, b) => a.percent - b.percent)[0].display_name))}</div>`
      : "");
  list.querySelectorAll(".grade-open").forEach((b) => b.addEventListener("click", () => {
    if (window.openGradePane) window.openGradePane(b.dataset.course);
  }));
}

/* ---------------- focus ----------------
   What deserves attention, worked out from the marks and the board — never a
   guess. Each line names its evidence, and each opens the class it is about.
   Rules kept from the strengths summary: two marks minimum before a kind is
   called weak, zeros flagged rather than averaged, and nothing here claims a
   kind is "dragging the grade down" — that needs weights. */
function focusAreas() {
  const today = todayIso();
  const items = (STATE.items || []).filter(i => !i.done && !personalSection(i));
  const grades = (STATE.grades || []).filter(g => g.graded && g.percent != null);
  const gradeOf = (key) => grades.find(g => g.course_key === key);
  const nameOf = (key) => {
    const g = (STATE.grades || []).find(x => x.course_key === key);
    const i = (STATE.items || []).find(x => x.course_key === key);
    const p = (STATE.profiles || []).find(x => x.course_key === key);
    return shortCourse((g && g.display_name) || (i && i.course) || (p && (p.display_name || p.course_raw)) || key);
  };
  const out = [];
  // 1. overdue work, by class
  const overdueBy = new Map();
  for (const i of items) {
    if (i.due_date && i.due_date < today && !isPastAssessment(i, today)) {
      overdueBy.set(i.course_key, (overdueBy.get(i.course_key) || 0) + 1);
    }
  }
  for (const [key, n] of [...overdueBy.entries()].sort((a, b) => b[1] - a[1])) {
    out.push({ icon: "!", urgent: true, course: key, weight: 100 + n,
               text: `${n} overdue in ${nameOf(key)}`, sub: "past its date and not ticked off" });
  }
  // 2. a weak kind of work, from real marks
  const byCourseKind = new Map();
  for (const s of STATE.scores || []) {
    const k = `${s.course_key}|${s.category || "other"}`;
    if (!byCourseKind.has(k)) byCourseKind.set(k, []);
    byCourseKind.get(k).push(s);
  }
  const weak = [];
  for (const [k, marks] of byCourseKind) {
    if (marks.length < STRENGTH_MIN_MARKS) continue;
    const [course, kind] = k.split("|");
    const nonzero = marks.filter(m => m.percent > 0);
    const mean = marks.reduce((t, m) => t + m.percent, 0) / marks.length;
    const zeros = marks.length - nonzero.length;
    if (mean < 80) weak.push({ course, kind, mean, n: marks.length, zeros });
  }
  weak.sort((a, b) => a.mean - b.mean);
  for (const w of weak.slice(0, 3)) {
    out.push({ icon: "◔", course: w.course, weight: 80 - w.mean,
               text: `${nameOf(w.course)} · ${kindName(w.kind)} average ${w.mean.toFixed(0)}%`,
               sub: `over ${w.n} marks${w.zeros ? ` · ${w.zeros} scored 0 — missed, or not graded?` : ""}` });
  }
  // 3. a test or quiz soon in a class under 90
  for (const i of items) {
    if (!HEAVY.has(i.category) || !i.due_date) continue;
    const days = daysUntil(i.due_date, today);
    if (days === null || days < 0 || days > 7) continue;
    const g = gradeOf(i.course_key);
    if (!g || g.percent >= 90) continue;
    out.push({ icon: "◆", item: i.item_id, course: i.course_key, weight: 60 - days,
               text: `${i.category} ${relDays(i.due_date, today)} in ${nameOf(i.course_key)}`,
               sub: `${i.title.slice(0, 60)} · class at ${g.percent.toFixed(1)}%` });
  }
  // 4. the lowest graded class with work open
  const lowest = grades.filter(g => items.some(i => i.course_key === g.course_key))
    .sort((a, b) => a.percent - b.percent)[0];
  if (lowest && lowest.percent < 93 && !out.some(o => o.course === lowest.course_key)) {
    const n = items.filter(i => i.course_key === lowest.course_key).length;
    out.push({ icon: "▽", course: lowest.course_key, weight: 40,
               text: `${nameOf(lowest.course_key)} is your lowest at ${lowest.percent.toFixed(1)}%`,
               sub: `${n} thing${n === 1 ? "" : "s"} open there — the board already ranks them higher` });
  }
  out.sort((a, b) => b.weight - a.weight);
  return out.slice(0, 6);
}
function renderFocus() {
  const panel = document.querySelector('[data-panel="focus"]');
  const list = $("#focus-list");
  if (!panel || !list) return;
  const areas = REMOTE ? [] : focusAreas();
  const badge = panel.querySelector(".focus-count");
  if (badge) { badge.textContent = String(areas.length); badge.classList.toggle("zero", !areas.length); }
  panel.classList.toggle("is-empty", !areas.length);
  panel.style.setProperty("--grow", (PANEL_WEIGHT.focus || 1) * (1 + Math.sqrt(areas.length)));
  list.innerHTML = areas.length ? areas.map((a) => `
    <button type="button" class="focus-row${a.urgent ? " urgent" : ""}" data-course="${esc(a.course || "")}" data-item="${esc(a.item || "")}"
            title="${esc(a.sub || a.text)}">
      <span class="focus-icon">${esc(a.icon)}</span>
      <span class="focus-text">${esc(a.text)}${a.sub ? `<small>${esc(a.sub)}</small>` : ""}</span></button>`).join("")
    : `<div class="empty-note">nothing stands out — keep going ✓</div>`;
  list.querySelectorAll(".focus-row").forEach((b) => b.addEventListener("click", () => {
    if (b.dataset.item) openDetail(b.dataset.item);
    else if (b.dataset.course && window.openGradePane) window.openGradePane(b.dataset.course);
  }));
}

/* Shared with the grade pane in views.js. */
const STRENGTH_MIN_MARKS = 2;
const GRADE_KINDS = ["test", "quiz", "project", "essay", "problem_set",
                     "reading", "discussion", "other"];
/* "quiz" pluralises to "quizzes", not "quizs". He calls problem sets,
   worksheets and notes "homework", so that is the word the grade page uses. */
const PLURALS = { quiz: "quizzes", essay: "essays", test: "tests",
                  project: "projects", reading: "readings",
                  problem_set: "homework", discussion: "discussions",
                  assignment: "assignments", other: "other work" };
const kindName = (kind) => PLURALS[kind]
  || String(kind).replace("_", " ") + (String(kind).endsWith("s") ? "" : "s");
/* 18 rather than 18.0, but 17.5 stays 17.5 — points are sometimes halves. */
const trimNum = (n) => Number(n).toFixed(2).replace(/\.?0+$/, "");
window.SD = { gradeBand, kindName, trimNum, STRENGTH_MIN_MARKS, GRADE_KINDS, classColor,
              relDays, minutesLabel, isPastAssessment, personalSection, rowHtml, studyHint };

/* ---------------- the brief ----------------
   The top of the conversation answers one question — "what do I do first?" —
   with a single item. The pick is whatever the pipeline ranked highest
   (scoring.py); never a second opinion computed here. */
function focusItem(open) {
  let best = null;
  for (const item of open) {
    if (!best || (item.score || 0) > (best.score || 0)) best = item;
  }
  return best;
}

/* Canvas names a link after the assignment, so link.text is usually the item
   title character-for-character. The label says where the link goes instead. */
const LINK_LABELS = {
  canvas: "Open in Canvas",
  assignment: "Open the assignment",
  google_doc: "Open the Doc",
  google_form: "Open the Form",
  google_slides: "Open the Slides",
  ap_classroom: "AP Classroom",
};
function linkLabel(link, item) {
  const text = (link.text || "").trim();
  const title = (item.title || "").trim();
  const dup = text && title
    && text.toLowerCase().replace(/\s+/g, " ") === title.toLowerCase().replace(/\s+/g, " ");
  if (link.courseWide && LINK_LABELS[link.kind]) return LINK_LABELS[link.kind];
  if (!text || dup) return LINK_LABELS[link.kind] || "Open link";
  return text;
}

/* Why this one is first, in words, when the ranking used the class's grade to
   decide. Shared by the brief's card and by the To-do row, so the two can
   never give different reasons for the same choice. The percentage is read
   from the same place the Grades list reads it — the card cannot claim a mark
   the board does not hold. Empty when the grade played no part. */
function focusWhy(item) {
  if (!item) return "";
  const classGrade = (STATE.grades || []).find(
    g => g.course_key === item.course_key && g.graded && g.percent != null);
  if (!classGrade || !/weaker class|behind in/.test(item.reason || "")) return "";
  return `first because ${esc(shortCourse(item.course))} is your `
    + `lowest graded class with work due — ${esc(classGrade.percent.toFixed(1))}%`;
}

/* The one thing to start with. One function, so the brief and the To-do list
   cannot disagree: they used to call focusItem() with differently filtered
   lists, which was two answers waiting to happen. */
function currentFocus() {
  return focusItem((STATE.items || []).filter((i) => !i.done && !personalSection(i)));
}

function focusCardHtml(item, today) {
  if (!item) {
    return `<div class="focus-card is-clear">
      <div class="focus-kicker">nothing open</div>
      <div class="focus-title">All caught up ✓</div>
      <div class="focus-sub">every item on the board is ticked off.</div></div>`;
  }
  const past = isPastAssessment(item, today);
  const overdue = item.due_date && item.due_date < today && !past;
  const bits = [dueLabel(item), shortCourse(item.course)];
  if (item.est_label) bits.push(item.est_label);
  /* Why this one, when the class's grade is part of the answer. The grade is
     read from the same place the Grades list reads it, so the card cannot
     claim a mark the board does not hold. */
  const why = focusWhy(item);
  const link = (item.links || [])[0];
  return `<div class="focus-card${overdue ? " is-overdue" : ""}">
    <div class="focus-kicker">${past ? "this one has already happened"
      : overdue ? "overdue — start here" : "start here"}</div>
    <div class="focus-title">${esc(item.title)}</div>
    <div class="focus-sub">${bits.map(esc).join(" · ")}</div>
    ${why ? `<div class="focus-why">${why}</div>` : ""}
    ${item.date_note ? `<div class="focus-note">${esc(item.date_note)}</div>` : ""}
    <div class="focus-actions">
      <button class="focus-open" type="button">Details</button>
      ${link ? `<a class="linkbtn ${esc(link.kind || "")}" href="${esc(link.url)}" target="_blank" rel="noopener">${esc(linkLabel(link, item))}</a>` : ""}
      ${REMOTE ? "" : `<button class="focus-done primary" type="button">Mark done</button>`}
    </div></div>`;
}

function renderHero() {
  const host = $("#hero-body");
  if (!host) return;
  const { out, today, tomorrow } = sections();
  const dueTomorrow = out.tomorrow.open.filter(i => i.due_date === tomorrow).length;
  const overdue = out.tomorrow.open.filter(
    i => i.due_date < today && !isPastAssessment(i, today)).length;
  const tests = out.upcoming.open.filter(i => ["test", "quiz"].includes(i.category)).length;
  const totalMinutes = out.tomorrow.open.filter(i => !isPastAssessment(i, today))
    .reduce((s, i) => s + (i.est_minutes || 0), 0);
  const nowMeetings = (STATE.meetings_today || []);
  const nowStr = STATE.now ? STATE.now.slice(11, 16) : "";
  const next = nowMeetings.find(m => (m.start || "").slice(11, 16) > nowStr);
  const focus = currentFocus();

  /* One line, not three tiles: a count of zero is good news and reads better
     as an absence than as a number. */
  const counts = [
    overdue ? `<b class="tone-urgent">${overdue}</b> overdue` : "",
    dueTomorrow ? `<b>${dueTomorrow}</b> due tomorrow` : "",
    tests ? `<b>${tests}</b> test${tests === 1 ? "" : "s"} &amp; quizzes ahead` : "",
    totalMinutes ? `<b>${esc(minutesLabel(totalMinutes))}</b> by tomorrow` : "",
  ].filter(Boolean);
  if (next) {
    counts.push(`next <b>${esc(nick(next.course_raw))}</b> ${esc((next.start || "").slice(11, 16))}${next.room ? " · " + esc(next.room) : ""}`);
  }
  // The nudge names the most urgent thing to revise — unless that is already
  // the card above it, in which case saying it twice is just noise.
  const soon = nextStudy(STATE);
  const nudge = soon && (!focus || soon.item.item_id !== focus.item_id)
    ? `<div class="study-nudge">📚 <strong>${esc(nick(soon.item.course))}</strong>
        ${esc(soon.hint)} — ${esc(soon.item.title)}</div>` : "";
  host.innerHTML = `
    <div class="hero-line">${counts.length
      ? counts.join(`<span class="dot">·</span>`)
      : "nothing overdue, nothing due tomorrow \u2713"}</div>
    ${focusCardHtml(focus, today)}
    ${nudge}`;

  if (focus) {
    const card = host.querySelector(".focus-card");
    const details = card && card.querySelector(".focus-open");
    if (details) details.addEventListener("click", () => openDetail(focus.item_id));
    const done = card && card.querySelector(".focus-done");
    if (done) done.addEventListener("click", () => toggleDone(focus.item_id, true));
  }
}

/* ---------------- panes ----------------
   One pane shows at a time in the centre. Everything that opens something —
   a row, a grade, a meeting, a focus line — comes through here. */
const PANES = ["chat", "item", "grade", "accel", "done", "add", "more", "classes", "settings", "setup"];
function paneElement(name) {
  return document.getElementById(["classes", "settings", "setup"].includes(name) ? `view-${name}` : `pane-${name}`);
}
function showPane(name) {
  if (!PANES.includes(name)) name = "chat";
  if (REMOTE && !["chat", "item", "done"].includes(name)) name = "chat";
  PANE = name;
  for (const p of PANES) {
    const el = paneElement(p);
    if (el) el.hidden = p !== name;
  }
  document.querySelectorAll("#view-nav button").forEach((b) =>
    b.classList.toggle("active", b.dataset.view === name));
  const dockBtn = $("#dock-chat");
  if (dockBtn) dockBtn.hidden = name === "chat";
  if (name === "chat") {
    setChatContext(null);
    if (SELECTED) { SELECTED = null; renderPanels(); }
    if (SELECTED_CLASS) { SELECTED_CLASS = null; renderGrades(); }
    const log = $("#chat-log");
    if (log) log.scrollTop = log.scrollHeight;
  }
  if (name !== "item" && SELECTED) { SELECTED = null; renderPanels(); }
  if (name !== "grade" && SELECTED_CLASS) { SELECTED_CLASS = null; renderGrades(); }
  // Settings is not "about" the assignment that was open a moment ago. Only
  // the panes that set a context of their own keep one.
  if (!["item", "grade", "accel"].includes(name) && CHAT_CONTEXT && !CHAT_CONTEXT.sticky) setChatContext(null);
  document.body.classList.toggle("setup-mode", name === "setup");
  /* In the simple layout the centre column is hidden unless its tab is open,
     so a pane opened by DOING something — tapping an assignment on Today,
     tapping a class on Grades — would render into a hidden column and look
     like nothing happened. Bring the centre forward, and light up the tab
     this pane belongs to when it has one. */
  /* In the simple layout the visible column must always match the open page.
     showPane may only take the screen when it is opening something that HAS no
     page of its own — an assignment, a class grade, the study guide, the add
     form — or when it is the current page's own pane.

     [MEASURED] 2026-09-10: it used to take the screen and adopt the pane's tab
     unconditionally, and `showPane("chat")` is the reset target used all over
     the app — including once during boot. So the app opened on Chat however
     the saved page was set, and the To-do list he had left open was replaced
     by the conversation. Deliberate navigation to a page goes through
     showTab(), which is the only thing allowed to change which page is open. */
  if (isSimple() && !TAB_SWITCHING) {
    const owner = tabForPane(name);
    const isDetail = !owner;
    if (isDetail || owner === PREFS.tab) {
      for (const sel of ["#col-left", "#col-center", "#col-right"]) {
        const col = document.querySelector(sel);
        if (col) col.classList.toggle("tab-on", sel === "#col-center");
      }
      document.documentElement.setAttribute("data-tab", PREFS.tab);
      renderTabs();
    }
  }
  if (window.onPaneShown) window.onPaneShown(name);
}
window.showPane = showPane;
window.currentPane = () => PANE;
/* The grade pane (views.js) owns which class is open; the sidebar row just
   has to light up and the item selection has to clear. */
window.selectClass = (key) => {
  SELECTED_CLASS = key || null;
  SELECTED = null;
  renderGrades();
  renderPanels();
};

function openDetail(itemId) {
  SELECTED = itemId;
  SELECTED_CLASS = null;
  renderDetail(itemId);
  renderPanels();
  renderGrades();
}
window.openDetail = openDetail;

function renderDetail(itemId) {
  const item = (STATE.items || []).find(i => i.item_id === itemId);
  if (!item) { closeDetail(); return; }
  showPane("item");
  SELECTED = itemId;
  // The course, not the word "Details": which class this belongs to is the
  // thing that orients you.
  $("#detail-title").textContent = shortCourse(item.course) || "Details";
  const profile = (STATE.profiles || []).find(p => p.course_key === item.course_key);
  const perCourse = ((STATE.diagnostics || {}).per_course || {})[item.course_key] || {};
  const resources = [...(item.links || [])];
  const seen = new Set(resources.map(l => l.url));
  for (const link of (perCourse.course_links || [])) {
    if (!seen.has(link.url) && ["ap_classroom", "google_doc", "canvas"].includes(link.kind)) {
      resources.push({ ...link, courseWide: true });
      seen.add(link.url);
    }
  }
  if (profile && profile.canvas_url && !seen.has(profile.canvas_url)) {
    resources.push({ url: profile.canvas_url, text: "Canvas course page",
                     kind: "canvas", courseWide: true });
  }
  // [MEASURED] 2026-09-04: the course links and the profile both offered the
  // Canvas course page, so "Open in Canvas ·course" was drawn twice. One label,
  // one button.
  const seenLabels = new Set();
  const linkBtns = resources.map((l) => {
    const label = l.kind === "ap_classroom" ? "AP Classroom"
      : (l.courseWide ? linkLabel(l, item) : (l.text || l.kind)).slice(0, 34);
    const key = `${label}|${l.courseWide ? "c" : "i"}`;
    if (seenLabels.has(key)) return "";
    seenLabels.add(key);
    return `<a class="linkbtn ${esc(l.kind)}" target="_blank" rel="noopener" href="${esc(l.url)}"
       >${esc(label)}${l.courseWide ? " ·course" : ""}</a>`;
  }).join("");
  /* One copy of the sentence, not two: a doc item's title is the sentence
     trimmed to 110 characters and its detail is the SAME sentence in full.
     When the detail is just the untruncated title, it BECOMES the title. */
  const trimmed = (item.title || "").replace(/…$/, "").trim();
  const detailIsFullerTitle = !!item.detail && !!trimmed
    && item.detail.length > (item.title || "").length
    && item.detail.includes(trimmed);
  const headline = detailIsFullerTitle ? item.detail : item.title;
  const extraText = item.detail && item.detail !== item.title && !detailIsFullerTitle
    ? item.detail : "";
  const today = todayIso();
  const grade = (STATE.grades || []).find(g => g.course_key === item.course_key && g.graded && g.percent != null);
  const siblings = (STATE.items || []).filter(i => i.course_key === item.course_key && i.item_id !== item.item_id && !i.done)
    .sort((a, b) => (a.due_date || "9999") < (b.due_date || "9999") ? -1 : 1).slice(0, 6);
  /* When it is due comes FIRST, then how that date was worked out, then the
     assignment's own words. The sentence can be long and is free to scroll;
     the date cannot afford to. */
  $("#detail-body").innerHTML = `
    <div class="detail-course"><span class="chip" ${classStyle(item.course_key)}>${esc(nick(item.course))}</span>
      <span class="tag ${esc(item.category)}">${esc(item.category)}</span>
      ${grade ? `<span class="grade-letter band-${gradeBand(grade.percent)}" title="your grade in this class">${esc(grade.letter || "")} ${esc(grade.percent.toFixed(1))}%</span>` : ""}
      <span class="kv">${esc(item.kind || item.source)}${item.points != null ? ` · ${esc(item.points)} pts` : ""}${item.est_label ? ` · ${esc(item.est_label)}` : ""}</span></div>
    <div class="due-line detail-due">${esc(dueLabel(item))}${item.due_date ? ` <span class="kv">· ${esc(relDays(item.due_date, today))}</span>` : ""}</div>
    <div class="note-line">${esc(item.date_note)}${item.confidence !== "high" ? ` (confidence: ${esc(item.confidence)})` : ""}</div>
    <div class="due-line detail-headline">${esc(headline)}</div>
    ${extraText ? `<div class="full-text">${esc(extraText)}</div>` : ""}
    ${linkBtns ? `<div class="linkbtns">${linkBtns}</div>`
      : `<div class="kv">no links in this entry</div>`}
    ${REMOTE ? "" : `<div class="detail-section work-section">
      <h4>Check my work</h4>
      <div id="work-body" class="wc-body"></div>
    </div>`}
    ${item.raw_cell && item.raw_cell !== item.detail
      ? `<details><summary class="kv">exactly what the doc said</summary>
         <div class="full-text">${esc(item.raw_cell)}</div></details>` : ""}
    ${!REMOTE && window.courseMaterialsHtml ? window.courseMaterialsHtml(item.course_key) : ""}
    ${siblings.length ? `<div class="detail-section"><h4>also open in ${esc(shortCourse(item.course))}</h4>
      ${siblings.map(i => rowHtml(i, "sibling")).join("")}</div>` : ""}
    <div class="detail-actions">
      <button id="detail-done" class="primary">${item.done ? "Undo done" : "Mark done"}</button>
      ${REMOTE || item.done ? "" : `<button id="detail-accel" class="accel-btn"
          title="a condensed version, the key ideas, and how to do the work — from the actual material">⚡ Accelerate</button>`}
      ${REMOTE ? "" : `<button id="detail-ask" class="ghost">Ask about this</button>`}
      ${grade || !REMOTE ? `<button id="detail-class" class="ghost">Class grades</button>` : ""}
      ${item.source === "custom" && !REMOTE
        ? `<button id="detail-delete" class="ghost">Remove</button>` : ""}
    </div>`;
  $("#detail-done").onclick = () => toggleDone(item.item_id, !item.done);
  const accel = $("#detail-accel");
  if (accel) accel.onclick = () => {
    if (window.openAccelerate) window.openAccelerate(item.item_id, item.title);
  };
  const ask = $("#detail-ask");
  if (ask) ask.onclick = () => {
    setChatContext({ itemId: item.item_id, label: item.title.slice(0, 50), sticky: true });
    const input = $("#chat-input");
    input.placeholder = `ask about “${item.title.slice(0, 40)}”…`;
    input.focus();
  };
  const cls = $("#detail-class");
  if (cls) cls.onclick = () => { if (window.openGradePane) window.openGradePane(item.course_key); };
  const del = $("#detail-delete");
  if (del) del.onclick = async () => {
    await fetch(`/api/tasks/${item.item_id}`, { method: "DELETE" });
    closeDetail();
    await loadState();
  };
  $("#detail-body").querySelectorAll(".row-open").forEach((b) =>
    b.addEventListener("click", () => openDetail(b.dataset.id)));
  $("#detail-body").querySelectorAll(".row-accel").forEach((b) =>
    b.addEventListener("click", () => {
      const sib = (STATE.items || []).find(i => i.item_id === b.dataset.id);
      if (sib && window.openAccelerate) window.openAccelerate(sib.item_id, sib.title);
    }));
  $("#detail-body").querySelectorAll(".tick").forEach((tick) =>
    tick.addEventListener("click", () => toggleDone(tick.dataset.id, tick.checked)));
  /* The photo box, after the rest of the pane exists: it fetches its own
     pages, so it must not be built before its host element is in the DOM. */
  if (!REMOTE && window.mountWorkCheck) window.mountWorkCheck(item.item_id);
  if (!REMOTE) setChatContext({ itemId: item.item_id, label: item.title.slice(0, 50) });
}

function closeDetail() {
  SELECTED = null;
  // A live camera preview must not survive the pane that opened it — the
  // green light staying on after you leave is alarming and correct to fix.
  if (window.unmountWorkCheck) window.unmountWorkCheck();
  /* Back goes to the page it was opened FROM in the simple layout. Sending
     someone to the chat because they closed an assignment they tapped on
     Today throws away where they were — and the three back buttons in the
     app must not disagree about what back means. */
  if (isSimple()) showTab(PREFS.tab && PREFS.tab !== "chat" ? PREFS.tab : "todo");
  else showPane("chat");
  renderPanels();
}

/* ---------------- done ---------------- */
async function toggleDone(itemId, done) {
  if (REMOTE) {
    localTicks.set(itemId, done);
    const item = (STATE.items || []).find(i => i.item_id === itemId);
    if (item) item.done = done;
    render();
    return;
  }
  await fetch("/api/done", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ item_id: itemId, done }),
  });
  await loadState();
}
window.toggleDone = toggleDone;

/* ---------------- chat ---------------- */
/* What the next question is about. Set while an item or a class is open in
   the pane; the dock shows it so nothing is sent with a hidden context. */
let CHAT_CONTEXT = null;
function setChatContext(ctx) {
  CHAT_CONTEXT = ctx;
  const box = $("#chat-context");
  const name = $("#chat-context-name");
  const input = $("#chat-input");
  if (!box || !name) return;
  box.hidden = !ctx;
  if (ctx) name.textContent = ctx.label;
  if (input) {
    if (ctx) input.placeholder = `ask about “${ctx.label.slice(0, 36)}”…`;
    else if (!(STATE && (STATE.provider === "null" || STATE.provider === "none"))) {
      input.placeholder = "what should I do first tonight?";
    }
  }
}
window.setChatContext = setChatContext;

/* An answer's citations are for the app, not for him. [MEASURED] 2026-09-10:
   a lookup answer read `• Quiz 3 [0dd4d1d0b4aecbba] — Thu 03 Sep` on his
   screen. That id is what `grounding.py` checks the answer against, and the
   check has already run by the time a bubble renders — so the id rides in on
   the text and goes out as the thing it names: a tap that opens the
   assignment. Stripping it and dropping it would have been easier and worse,
   because a line that names your homework should be able to open it.

   Only an id the board actually holds becomes a button; an id that matches
   nothing is removed rather than offered, so a tap can never dead-end. */
function chatHtml(text) {
  const cite = /\s*\[([0-9a-f]{8,40})\]/g;
  /* STATE is null until the first load lands, and the saved conversation is
     replayed at boot — so this runs with no board at all. [MEASURED]
     2026-09-10: reading STATE.items there threw, loadChatHistory swallowed it,
     and every earlier question vanished from the log. With no board, no line
     gets a button; the text still reads correctly, which is the part that
     matters. */
  const known = new Set(((STATE || {}).items || []).map((i) => i.item_id));
  return String(text == null ? "" : text).split("\n").map((line) => {
    const ids = [...line.matchAll(cite)].map((m) => m[1]).filter((id) => known.has(id));
    const body = esc(line.replace(cite, ""));
    const go = ids.length === 1
      ? ` <button type="button" class="cite" data-item="${esc(ids[0])}"
          title="open this assignment">open \u203A</button>` : "";
    return `<div class="chat-line">${body}${go}</div>`;
  }).join("");
}

/* One handler for every bubble there will ever be, wired once. */
function wireChatCites() {
  const log = $("#chat-log");
  if (!log) return;
  log.addEventListener("click", (event) => {
    const button = event.target.closest(".cite");
    if (button && button.dataset.item) openDetail(button.dataset.item);
  });
}

/* Previous questions, replayed on load. Stored on their own Mac
   (db.chat_messages), trimmed to the last 200 rather than kept forever. */
async function loadChatHistory() {
  const logBox = $("#chat-log");
  if (!logBox || REMOTE) return;
  try {
    const res = await fetch("/api/chat/history?limit=40");
    const out = await res.json();
    const messages = out.messages || [];
    if (!messages.length) { showChatEmpty(); return; }
    const parts = [`<div class="chat-earlier">earlier questions</div>`];
    for (const message of messages) {
      const when = (message.at || "").slice(11, 16);
      if (message.role === "user") {
        parts.push(`<div class="msg user">${esc(message.text)}</div>`);
      } else {
        const grounded = (message.meta || {}).grounded;
        parts.push(`<div class="msg assistant">${chatHtml(message.text)}`
          + (grounded === false
              ? `<div class="grounding warn">was not fully checked</div>` : "")
          + (when ? `<div class="msg-when">${esc(when)}</div>` : "")
          + `</div>`);
      }
    }
    logBox.insertAdjacentHTML("afterbegin", parts.join(""));
    logBox.scrollTop = logBox.scrollHeight;
  } catch (err) {
    /* no history is not an error worth a message in the log */
  }
}
function showChatEmpty() {
  const logBox = $("#chat-log");
  if (!logBox || logBox.children.length) return;
  logBox.innerHTML = `<div class="chat-empty">Ask anything about your work — <b>what should I do first?</b>,
    <b>how do I bring up Biology?</b>, <b>what room is Spanish in?</b> — or tell me something a
    teacher said and I will offer to add it. Click an assignment or a class on either side and
    ask about that.</div>`;
}

function wireChatClear() {
  const button = $("#chat-clear");
  if (!button) return;
  button.addEventListener("click", async () => {
    button.disabled = true;
    try {
      await fetch("/api/chat/history", { method: "DELETE" });
      const logBox = $("#chat-log");
      if (logBox) { logBox.innerHTML = ""; showChatEmpty(); }
    } finally {
      button.disabled = false;
    }
  });
}

async function sendChat(event) {
  event.preventDefault();
  const input = $("#chat-input");
  let message = input.value.trim();
  if (!message) return;
  const ctx = CHAT_CONTEXT;
  const itemId = (ctx && ctx.itemId) || input.dataset.itemId || null;
  if (ctx && !ctx.itemId && ctx.label && !message.toLowerCase().includes(ctx.label.toLowerCase())) {
    // A class context has no id the API knows; it rides in the sentence, in
    // the open, so what was sent is exactly what is shown.
    message = `About ${ctx.label}: ${message}`;
  }
  input.value = ""; delete input.dataset.itemId;
  setChatContext(null);
  showPane("chat");
  const logBox = $("#chat-log");
  const empty = logBox.querySelector(".chat-empty");
  if (empty) empty.remove();
  logBox.insertAdjacentHTML("beforeend", `<div class="msg user">${esc(message)}</div>`);
  const bubble = document.createElement("div");
  bubble.className = "msg assistant pending";
  bubble.textContent = "thinking";
  logBox.appendChild(bubble);
  logBox.scrollTop = logBox.scrollHeight;
  try {
    const res = await fetch("/api/chat", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, session_id: CHAT_SESSION, item_id: itemId }),
    });
    const out = await res.json();
    bubble.classList.remove("pending");
    if (out.error) {
      bubble.textContent = out.error.message + " — fix: " + out.error.fix;
      return;
    }
    CHAT_SESSION = out.session_id || CHAT_SESSION;
    bubble.innerHTML = chatHtml(out.answer);
    // Three outcomes, three stamps: an answer nothing could check says so,
    // rather than earning the green tick by making no checkable claim.
    const stamp = document.createElement("div");
    if (out.mode === "quickadd") {
      stamp.className = "grounding ok";
      stamp.textContent = "✓ read straight from what you typed — check it, then tap Add";
      bubble.appendChild(stamp);
      if ((out.action || {}).proposed) renderTaskProposal(bubble, out.action);
      logBox.scrollTop = logBox.scrollHeight;
      return;
    }
    if (out.mode === "lookup" && !(out.violations || []).length) {
      stamp.className = "grounding ok";
      stamp.textContent = out.verified
        ? `✓ ${out.verified} claim${out.verified === 1 ? "" : "s"} read straight from your data`
        : "✓ read straight from your data";
      stamp.title = "Worked out from the homework and schedule on this Mac. "
        + "No AI was involved, so there is nothing here that could be invented.";
      bubble.appendChild(stamp);
      const action0 = out.action || {};
      if (action0.proposed) renderTaskProposal(bubble, action0);
      logBox.scrollTop = logBox.scrollHeight;
      return;
    }
    const level = out.confidence
      || (out.grounded ? (out.verified ? "verified" : "unverified") : "failed");
    if (level === "failed") {
      stamp.className = "grounding warn-mark";
      stamp.textContent = "⚠ mentioned something not in your data: "
        + (out.violations || []).join("; ");
    } else if (level === "verified") {
      const n = out.verified || 0;
      stamp.className = "grounding ok";
      stamp.textContent = `✓ ${n} claim${n === 1 ? "" : "s"} checked against your data`;
      if (out.checked && out.checked.length) stamp.title = out.checked.join("\n");
    } else {
      stamp.className = "grounding unverified";
      stamp.textContent = "no verifiable claims in this answer — read it carefully";
      stamp.title = "Nothing here quoted an assignment id, room, time or grade, "
        + "so there was nothing to check against your data.";
    }
    bubble.appendChild(stamp);
    const action = out.action || {};
    // A proposed task is not homework yet. Nothing is written until tapped.
    if (action.proposed) renderTaskProposal(bubble, action);
    if (action.added || action.marked_done) await loadState();
  } catch (err) {
    bubble.classList.remove("pending");
    bubble.textContent = "chat failed: " + err.message;
  }
  logBox.scrollTop = logBox.scrollHeight;
}

/* ---------------- a proposed task, awaiting one tap ---------------- */
function renderTaskProposal(bubble, action) {
  const task = action.proposed || {};
  const box = document.createElement("div");
  box.className = "proposal";
  const when = task.due_date ? niceDate(task.due_date) : "no date";
  const categories = ["", "assignment", "quiz", "test", "project", "essay", "reading",
                      "problem_set", "discussion"];
  box.innerHTML = `
    <div class="proposal-head">Add this to your list?</div>
    <div class="proposal-edit">
      <input type="text" class="pe-title" maxlength="110" value="${esc(task.title)}" aria-label="title">
      <div class="pe-row">
        <input type="date" class="pe-due" value="${esc(task.due_date || "")}" aria-label="due date">
        <select class="pe-cat" aria-label="type">${categories.map((c) =>
          `<option value="${esc(c)}" ${(task.category || "") === c ? "selected" : ""}>${
            c ? c.replace("_", " ") : "what kind?"}</option>`).join("")}</select>
      </div>
      <input type="text" class="pe-course" maxlength="60" value="${esc(task.course || "")}"
             placeholder="which class? (optional)" aria-label="class">
    </div>
    <div class="proposal-sub">${esc(when)}${task.course ? " · " + esc(task.course) : ""}${
      task.section ? " · " + esc(task.section) : ""}</div>
    ${action.date_dropped
      ? `<div class="proposal-note">I left the date off on purpose — you did not
         say one, and ${esc(action.date_dropped)} would have been my guess.</div>`
      : ""}
    <div class="proposal-actions">
      <button type="button" class="primary proposal-yes">Add it</button>
      <button type="button" class="proposal-no">No thanks</button>
    </div>`;
  bubble.appendChild(box);

  box.querySelector(".proposal-no").addEventListener("click", () => {
    box.innerHTML = `<div class="proposal-note">Not added.</div>`;
  });
  box.querySelector(".proposal-yes").addEventListener("click", async () => {
    const yes = box.querySelector(".proposal-yes");
    yes.disabled = true; yes.textContent = "Adding…";
    try {
      const edited = {
        ...task,
        title: (box.querySelector(".pe-title") || {}).value || task.title,
        due_date: (box.querySelector(".pe-due") || {}).value || null,
        category: (box.querySelector(".pe-cat") || {}).value || task.category || null,
        course: ((box.querySelector(".pe-course") || {}).value || "").trim() || null,
      };
      const res = await fetch("/api/tasks", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(edited),
      });
      const out = await res.json();
      if (out.error) throw new Error(out.error.message);
      const id = (out.task || {}).item_id;
      box.innerHTML = `<div class="proposal-note">✚ Added.</div>`;
      if (id) {
        const undo = document.createElement("button");
        undo.type = "button"; undo.className = "proposal-undo"; undo.textContent = "Undo";
        undo.addEventListener("click", async () => {
          undo.disabled = true;
          await fetch(`/api/tasks/${encodeURIComponent(id)}`, { method: "DELETE" });
          box.innerHTML = `<div class="proposal-note">Removed again.</div>`;
          await loadState();
        });
        box.appendChild(undo);
      }
      await loadState();
    } catch (err) {
      box.innerHTML = `<div class="proposal-note">could not add it: ${esc(err.message)}</div>`;
    }
  });
}

/* ---------------- auto-refresh ----------------
   Re-read /api/state every 60s so a scheduled refresh appears on a page that
   has been open all day; trigger a real refresh when the data is stale AND the
   page is visible. document.hidden gates both. */
const POLL_MS = 60 * 1000;
const AUTO_REFRESH_AFTER_MINUTES = 35;   // just past the 30-minute schedule
let LAST_AUTO_REFRESH = 0;

function dataAgeMinutes() {
  if (!STATE || !STATE.generated_at) return Infinity;
  const at = new Date(STATE.generated_at).getTime();
  if (Number.isNaN(at)) return Infinity;
  return (Date.now() - at) / 60000;
}

async function autoTick() {
  if (REMOTE || document.hidden) return;
  try {
    await loadState();
  } catch (e) { return; }          // offline: try again on the next tick
  const btn = $("#refresh");
  if (!btn || btn.disabled) return;
  const sinceOurs = (Date.now() - LAST_AUTO_REFRESH) / 60000;
  if (dataAgeMinutes() > AUTO_REFRESH_AFTER_MINUTES && sinceOurs > 10) {
    LAST_AUTO_REFRESH = Date.now();
    await refresh();
  }
}

function startAutoRefresh() {
  if (REMOTE) return;             // the published snapshot has no server
  setInterval(autoTick, POLL_MS);
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) autoTick();
  });
}

/* ---------------- refresh (local only) ---------------- */
async function refresh() {
  const btn = $("#refresh");
  btn.disabled = true; btn.textContent = "Refreshing…";
  const progress = $("#progress");
  progress.hidden = false; progress.innerHTML = "";
  try {
    const res = await fetch("/api/refresh", { method: "POST",
      headers: { "Content-Type": "application/json" }, body: "{}" });
    const out = await res.json();
    if (!out.error) {
      await new Promise((resolve) => {
        const source = new EventSource(`/api/refresh/${out.run_id}/events`);
        source.onmessage = (event) => {
          const data = JSON.parse(event.data);
          if (data.stage === "done") { source.close(); resolve(); return; }
          const line = document.createElement("div");
          line.textContent = `[${data.stage}] ${data.course ? data.course + ": " : ""}${data.message}`;
          progress.appendChild(line);
          if (!REDUCED) progress.scrollTop = progress.scrollHeight;
        };
        source.onerror = () => { source.close(); resolve(); };
      });
    }
  } finally {
    btn.disabled = false; btn.textContent = "Refresh";
    setTimeout(() => { progress.hidden = true; }, 4000);
    await loadState();
  }
}
window.refresh = refresh;

/* ---------------- panel fold/grow ---------------- */
function panelStates() {
  try { return JSON.parse(localStorage.getItem("schooldash.panels")) || {}; }
  catch (e) { return {}; }
}
function applyPanelStates() {
  const states = panelStates();
  /* Folded and grown are DASHBOARD states. In the simple layout a panel IS a
     page: there is nothing beside it to give room to, and both buttons are
     hidden — so applying a state saved months ago in the dashboard is not a
     preference being honoured, it is a page that cannot be opened.

     [MEASURED] 2026-09-10, and it took four rounds to find because it lives in
     localStorage and so reproduced on his machine and nowhere else. He had
     collapsed the Grades box in the dashboard at some point. On the simple
     layout's Grades page that left `.panel.collapsed` with its body
     `display: none`, while `.panel.tab-on { flex: 1 1 auto }` stretched it to
     fill the page — a full-height panel with a heading, a live "7/10" count,
     nine grade rows in the DOM at zero height, and no fold button to press.
     Nothing threw, nothing logged, and the data was perfect. */
  const simple = typeof isSimple === "function" && isSimple();
  document.querySelectorAll(".panel[data-panel]").forEach((panel) => {
    const name = panel.dataset.panel;
    panel.classList.toggle("collapsed", !simple && states[name] === "collapsed");
    panel.classList.toggle("grown", !simple && states[name] === "grown");
    const fold = panel.querySelector(".fold-btn");
    if (fold) fold.textContent = states[name] === "collapsed" ? "▸" : "▾";
  });
}
/* Kept as a no-op guard: the element may linger in a cached page after an
   upgrade, and a missing element must never stop the script. */
function wireQuickAsk() {
  const form = document.getElementById("ask-quick");
  const input = document.getElementById("ask-input");
  const chatInput = document.getElementById("chat-input");
  const chatForm = document.getElementById("chat-form");
  if (!form || !input || !chatInput || !chatForm) return;
  form.addEventListener("submit", (ev) => {
    ev.preventDefault();
    const question = input.value.trim();
    if (!question) return;
    input.value = "";
    chatInput.value = question;
    chatForm.dispatchEvent(new Event("submit", { cancelable: true }));
  });
}

function wirePanels() {
  /* Not every panel has the fold/grow controls. [MEASURED] 2026-09-03: one
     missing button, unguarded, took out the whole board at startup. */
  const on = (panel, selector, handler) => {
    const button = panel.querySelector(selector);
    if (button) button.addEventListener("click", handler);
  };
  document.querySelectorAll(".panel[data-panel]").forEach((panel) => {
    const name = panel.dataset.panel;
    const set = (value) => {
      const states = panelStates();
      states[name] = states[name] === value ? "normal" : value;
      localStorage.setItem("schooldash.panels", JSON.stringify(states));
      applyPanelStates();
    };
    on(panel, ".fold-btn", () => set("collapsed"));
    on(panel, ".grow-btn", () => set("grown"));
  });
}

/* ---------------- resizable columns, hideable sides ---------------- */
function wireResizers() {
  document.querySelectorAll(".resizer").forEach((bar) => {
    const side = bar.dataset.side;
    bar.addEventListener("dblclick", () => savePrefs(side === "left"
      ? { leftWidth: PREF_DEFAULTS.leftWidth } : { rightWidth: PREF_DEFAULTS.rightWidth }));
    bar.addEventListener("pointerdown", (ev) => {
      ev.preventDefault();
      const startX = ev.clientX;
      const start = side === "left" ? PREFS.leftWidth : PREFS.rightWidth;
      bar.classList.add("dragging");
      document.body.classList.add("resizing");
      const move = (e) => {
        const delta = side === "left" ? e.clientX - startX : startX - e.clientX;
        const width = Math.round(Math.max(180, Math.min(480, start + delta)));
        document.documentElement.style.setProperty(side === "left" ? "--left-w" : "--right-w", `${width}px`);
        bar.dataset.width = width;
      };
      const up = () => {
        window.removeEventListener("pointermove", move);
        window.removeEventListener("pointerup", up);
        bar.classList.remove("dragging");
        document.body.classList.remove("resizing");
        if (bar.dataset.width) savePrefs(side === "left"
          ? { leftWidth: Number(bar.dataset.width) } : { rightWidth: Number(bar.dataset.width) });
        delete bar.dataset.width;
      };
      window.addEventListener("pointermove", move);
      window.addEventListener("pointerup", up);
    });
  });
  const tl = $("#toggle-left"), tr = $("#toggle-right");
  if (tl) tl.onclick = () => savePrefs({ hideLeft: !PREFS.hideLeft });
  if (tr) tr.onclick = () => savePrefs({ hideRight: !PREFS.hideRight });
}

/* ---------------- wiring ---------------- */
loadPrefs();
applyPrefs();
$("#refresh").onclick = refresh;
$("#theme-toggle").onclick = () => {
  const root = document.documentElement;
  // With nothing pinned the page follows the system, so read what is actually
  // on screen — otherwise the first click is a no-op for anyone already dark.
  const showing = root.getAttribute("data-theme")
    || (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
  const next = showing === "dark" ? (PREFS.lightChoice || "light") : "dark";
  if (showing !== "dark") PREFS.lightChoice = showing;
  savePrefs({ theme: next });
  if (window.renderAppearance) window.renderAppearance();
};
const detailClose = $("#detail-close");
if (detailClose) detailClose.onclick = closeDetail;
/* Back means "the page I came from" in the simple layout, and the chat in the
   dashboard. Sending someone from an assignment to the chat when they tapped
   it on the Today tab loses their place for no reason. */
document.querySelectorAll("[data-back]").forEach((b) => b.addEventListener("click", () => {
  if (isSimple()) { showTab(PREFS.tab === "chat" ? "todo" : PREFS.tab); return; }
  showPane("chat");
}));
/* One listener on the strip rather than one per button: renderTabs() rewrites
   its innerHTML on every refresh, which would drop per-button handlers. */
/* One listener each, delegated: both are rewritten on every refresh, which
   would drop per-button handlers. */
const tabBar = $("#tab-bar");
if (tabBar) tabBar.addEventListener("click", (ev) => {
  const btn = ev.target.closest("button[data-tab]");
  if (btn) showTab(btn.dataset.tab);
});
const moreList = $("#more-list");
if (moreList) moreList.addEventListener("click", (ev) => {
  const btn = ev.target.closest("button[data-tab]");
  if (btn) showTab(btn.dataset.tab);
});
document.querySelectorAll("#layout-pick .lp-opt").forEach((b) => b.addEventListener("click", () => {
  savePrefs({ layout: b.dataset.layout, tab: PREFS.tab || "today" });
  if (window.renderLayoutPrefs) window.renderLayoutPrefs();
  render();
}));
const dockChat = $("#dock-chat");
if (dockChat) dockChat.onclick = () => showPane("chat");
const ctxClear = $("#chat-context-clear");
if (ctxClear) ctxClear.onclick = () => setChatContext(null);
document.addEventListener("keydown", (ev) => {
  const typing = ["INPUT", "TEXTAREA", "SELECT"].includes((ev.target || {}).tagName)
    || (ev.target && ev.target.isContentEditable);
  if (ev.key === "Escape") {
    const palette = $("#palette");
    if (palette && !palette.hidden) return;   // the palette closes itself
    if (isSimple()) {
      // Esc backs out of a detail to the page it was opened from.
      if (!tabForPane(PANE)) { showTab(PREFS.tab); return; }
      if (CHAT_CONTEXT) setChatContext(null);
      return;
    }
    if (PANE !== "chat") { showPane("chat"); return; }
    if (CHAT_CONTEXT) setChatContext(null);
  }
  if (typing || ev.metaKey || ev.ctrlKey || ev.altKey) return;
  if (ev.key === "/") { ev.preventDefault(); const i = $("#chat-input"); if (i) i.focus(); }
  // There are no sides to hide in the simple layout; the same keys step
  // through its pages instead of doing nothing.
  if (ev.key === "[") {
    if (isSimple()) showTab(TAB_KEYS[(TAB_KEYS.indexOf(PREFS.tab) - 1 + TAB_KEYS.length) % TAB_KEYS.length]);
    else savePrefs({ hideLeft: !PREFS.hideLeft });
  }
  if (ev.key === "]") {
    if (isSimple()) showTab(TAB_KEYS[(TAB_KEYS.indexOf(PREFS.tab) + 1) % TAB_KEYS.length]);
    else savePrefs({ hideRight: !PREFS.hideRight });
  }
  if (ev.key === "r" && !REMOTE) refresh();
});
$("#day-prev").onclick = () => { SCHED_OFFSET -= 1; renderSchedule(); };
$("#day-next").onclick = () => { SCHED_OFFSET += 1; renderSchedule(); };
$("#day-today").onclick = () => { SCHED_OFFSET = 0; renderSchedule(); };
document.querySelectorAll("[data-cal]").forEach((b) => b.addEventListener("click", () => setCalMode(b.dataset.cal)));
/* The simple layout's Calendar page is the full width of the window, so a
   month grid fits and is what "calendar" means; the dashboard's 248px column
   cannot hold one, so it keeps Day unless he says otherwise. */
CAL_MODE = ["week", "month"].includes(PREFS.calendar) ? PREFS.calendar
  : (PREFS.layout === "simple" ? "month" : "day");
const gradesSort = $("#grades-sort");
if (gradesSort) gradesSort.onclick = () => { savePrefs({ gradeSort: PREFS.gradeSort === "name" ? "low" : "name" }); renderGrades(); };
const assignSort = $("#assign-sort");
if (assignSort) assignSort.onclick = () => {
  const next = SORT_MODES[(SORT_MODES.indexOf(PREFS.assignSort) + 1) % SORT_MODES.length];
  savePrefs({ assignSort: next }); renderPanels();
};
if (REMOTE) {
  const dock = $("#chat-dock");
  if (dock) dock.innerHTML =
    `<span class="muted">chat and live refresh run on your PC — this page is
     the anywhere-view, updated on the schedule</span>`;
  const hint = $("#chat-hint");
  if (hint) hint.textContent = "";
  document.querySelectorAll("#view-nav, .resizer, #toggle-left, #toggle-right, #palette-open").forEach((el) => { el.hidden = true; });
} else {
  $("#chat-form").onsubmit = sendChat;
}
/* ---------------- the account gate ----------------
   Shown only when the server says 401. A solo install with no account server
   configured never sees it, because the gate is off server-side. */
let GATE_CREATING = false;

/* ---------------- the paywall ----------------
   Shown when the trial has run out. Say the price and the exact thing to do
   next, in one screen; never pretend the money moves through this app. */
function showPaywall(message) {
  const gate = $("#gate");
  if (!gate) return;
  gate.hidden = false;
  const sub = (STATE && STATE.subscription) || {};
  const price = sub.price || { amount: "5.99", currency: "USD", period: "month" };
  const payTo = sub.pay_to || "";
  const email = sub.email || "";
  gate.innerHTML = `
    <div class="gate-card paywall">
      <img src="/static/brand/icon.svg" alt="" width="52" height="52" class="gate-mark">
      <h2>Your free trial has ended</h2>
      <p class="muted">${esc(message
        || `SchoolDash is $${price.amount} a ${price.period} after the trial.`)}</p>
      <div class="paywall-price">$${esc(price.amount)}<span>/${esc(price.period)}</span></div>
      <ol class="paywall-steps">
        ${payTo
          ? `<li>Send <strong>$${esc(price.amount)}</strong> on Venmo to
               <strong>${esc(payTo)}</strong></li>`
          : `<li>Ask whoever gave you SchoolDash how to pay them</li>`}
        <li>Put your sign-in email in the note:
            <code>${esc(email || "your email")}</code></li>
        <li>Press the button below once it is sent</li>
      </ol>
      <button type="button" class="primary" id="paywall-check">I've paid — check now</button>
      <div class="paywall-code">
        <label for="paywall-code-input">Got a code?</label>
        <div class="paywall-code-row">
          <input id="paywall-code-input" type="text" autocomplete="off"
                 spellcheck="false" placeholder="type it here">
          <button type="button" id="paywall-redeem">Use code</button>
        </div>
      </div>
      <p class="gate-error" id="paywall-note" hidden></p>
      <button type="button" class="ghost" id="paywall-signout">Sign out</button>
      <p class="muted paywall-small">Your homework, grades and schedule are still
        on this Mac and nothing has been deleted. Paying unlocks the page again.</p>
    </div>`;

  $("#paywall-signout").addEventListener("click", async () => {
    await fetch("/api/session", { method: "DELETE" });
    location.reload();
  });

  const redeemBtn = $("#paywall-redeem");
  const codeInput = $("#paywall-code-input");
  const useCode = async () => {
    const note = $("#paywall-note");
    const code = (codeInput.value || "").trim();
    if (!code) { codeInput.focus(); return; }
    redeemBtn.disabled = true; redeemBtn.textContent = "Checking…";
    note.hidden = true;
    try {
      const res = await fetch("/api/session/redeem", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code }),
      });
      const out = await res.json();
      if (out.error) throw new Error(out.error.message);
      if (((out.subscription) || {}).state === "paid") { location.reload(); return; }
      throw new Error("that code did not unlock anything");
    } catch (err) {
      note.hidden = false;
      note.textContent = err.message;
    }
    redeemBtn.disabled = false; redeemBtn.textContent = "Use code";
  };
  redeemBtn.addEventListener("click", useCode);
  codeInput.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter") { ev.preventDefault(); useCode(); }
  });

  $("#paywall-check").addEventListener("click", async () => {
    const btn = $("#paywall-check");
    const note = $("#paywall-note");
    btn.disabled = true; btn.textContent = "Checking…";
    note.hidden = true;
    try {
      const res = await fetch("/api/session/refresh", { method: "POST" });
      const out = await res.json();
      const state = ((out.subscription) || {}).state;
      if (state === "paid" || state === "trial") { location.reload(); return; }
      note.hidden = false;
      note.textContent = "Not showing as paid yet. It is switched on by hand, "
        + "so give it a little while, then check again.";
    } catch (err) {
      note.hidden = false;
      note.textContent = "Could not reach the account server — check your internet.";
    }
    btn.disabled = false; btn.textContent = "I've paid — check now";
  });
}

function showGate() {
  const gate = $("#gate");
  if (!gate || !gate.hidden) return;
  gate.hidden = false;
  $("#gate-email").focus();
}

function setGateMode(creating) {
  GATE_CREATING = creating;
  $("#gate-title").textContent = creating
    ? "Create your SchoolDash account" : "Sign in to SchoolDash";
  $("#gate-submit").textContent = creating ? "Create account" : "Sign in";
  $("#gate-toggle").textContent = creating
    ? "I already have an account" : "Create an account instead";
  $("#gate-password").setAttribute(
    "autocomplete", creating ? "new-password" : "current-password");
  $("#gate-error").hidden = true;
}

function gateError(message) {
  const box = $("#gate-error");
  box.textContent = message;
  box.hidden = false;
}

if (!REMOTE) {
  $("#gate-toggle").onclick = () => setGateMode(!GATE_CREATING);
  $("#gate-form").onsubmit = async (ev) => {
    ev.preventDefault();
    const button = $("#gate-submit");
    button.disabled = true;
    $("#gate-error").hidden = true;
    try {
      const response = await fetch("/api/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: $("#gate-email").value.trim(),
          password: $("#gate-password").value,
          create: GATE_CREATING,
        }),
      });
      const body = await response.json();
      if (!response.ok) {
        gateError(body.error?.message || "that did not work");
        return;
      }
      $("#gate").hidden = true;
      $("#gate-password").value = "";
      await loadState();
    } catch (err) {
      gateError("could not reach SchoolDash — is it still running?");
    } finally {
      button.disabled = false;
    }
  };
}

(() => {
  const close = document.getElementById("grade-detail-close");
  // The third back button. All three mean "the page I came from" now.
  if (close) close.addEventListener("click", () => {
    if (isSimple()) showTab(PREFS.tab && PREFS.tab !== "chat" ? PREFS.tab : "grades");
    else showPane("chat");
  });
})();

/* After the board has painted, not before it: an update is never more urgent
   than the homework, and the check must not delay the first render. */
if (!REMOTE) {
  setTimeout(() => { checkUpdate(false).then((out) => { if (out) renderBanners(); }); }, 2500);
  setInterval(() => { checkUpdate(false).then((out) => { if (out) renderBanners(); }); }, 6 * 3600 * 1000);
}

wirePanels();
wireQuickAsk();
wireChatClear();
wireChatCites();
applyPanelStates();
wireAddForm();
wireResizers();
startAutoRefresh();
/* The saved conversation is replayed AFTER the board, not beside it: a line
   in an old answer becomes a tap that opens the assignment it names, and it
   can only do that once the board is loaded and there is something to check
   the id against. The board is what he came for, so it still goes first. */
loadState().finally(loadChatHistory);

/* ---------------- installing as an app ----------------
   Only on the live local server: the published snapshot does not own its
   origin, so a root-scoped worker there is wrong. */
if (!REMOTE && "serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch((err) => {
      console.warn("[schooldash] service worker did not register", err);
    });
  });
}

if (!REMOTE) {
  const installBtn = $("#install");
  let deferredPrompt = null;
  window.addEventListener("beforeinstallprompt", (ev) => {
    ev.preventDefault();
    deferredPrompt = ev;
    installBtn.hidden = false;
  });
  installBtn.onclick = async () => {
    if (!deferredPrompt) return;
    installBtn.disabled = true;
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    deferredPrompt = null;
    installBtn.hidden = true;
    installBtn.disabled = false;
  };
  window.addEventListener("appinstalled", () => {
    deferredPrompt = null;
    installBtn.hidden = true;
  });
}
