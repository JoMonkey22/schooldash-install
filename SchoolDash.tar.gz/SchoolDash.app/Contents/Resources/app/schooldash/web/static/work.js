/* Check my work — photograph or upload a finished assignment and have the
   model read it.

   *"add a thing in asgnments where you can click on the assginment and take a
   photo of your assignment or uplod the assghinment had the ai will check it"*

   Four ways in, because the right one depends on where the work is:

     Take a photo   the Mac's own camera, for paper. getUserMedia, previewed
                    live, captured to a canvas. On an iPad or a phone the file
                    input's `capture` attribute opens the rear camera instead
                    and this button is not needed.
     Choose a file  a file picker; on iOS this is also the camera roll.
     Drag           a file dropped anywhere on the box.
     Paste          Cmd+V while the box is open — the fastest route by far for
                    work that is already on the screen, because Cmd+Shift+4
                    puts a screenshot straight on the clipboard.

   Every route ends in the same place: `shrink()` draws the image on a canvas
   at no more than 1600px on its long edge and re-encodes it as JPEG. That is
   what makes HEIC from an iPhone work (the browser decodes it, we re-encode),
   what keeps an 8 MB photo down to about 200 KB, and what means the server
   only ever stores one format.

   The photo leaves the Mac. That is the one thing about this feature that is
   not like the rest of the app, so the panel says so in words, every time,
   and the first check asks before it sends. */

(function () {
  const $ = (sel, root) => (root || document).querySelector(sel);
  const esc = (text) => String(text == null ? "" : text)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

  const MAX_EDGE = 1600;
  const CONSENT = "schooldash.workSendOk";
  let CAMERA = null;              // the live MediaStream, while previewing

  /* ---------- one shape for every route in ---------- */

  /* Re-encode through a canvas. Returns a Blob, always image/jpeg.
     createImageBitmap decodes HEIC on Safari where the tag would not, and is
     the reason an iPhone photo works without a converter on the server. */
  async function shrink(file) {
    let bitmap;
    try {
      bitmap = await createImageBitmap(file);
    } catch (err) {
      throw new Error("that file could not be read as an image");
    }
    const scale = Math.min(1, MAX_EDGE / Math.max(bitmap.width, bitmap.height));
    const width = Math.max(1, Math.round(bitmap.width * scale));
    const height = Math.max(1, Math.round(bitmap.height * scale));
    const canvas = document.createElement("canvas");
    canvas.width = width; canvas.height = height;
    canvas.getContext("2d").drawImage(bitmap, 0, 0, width, height);
    bitmap.close && bitmap.close();
    return await new Promise((resolve, reject) =>
      canvas.toBlob((blob) => blob ? resolve(blob)
        : reject(new Error("the photo could not be encoded")), "image/jpeg", 0.82));
  }

  async function upload(itemId, blob) {
    const res = await fetch(`/api/work/${encodeURIComponent(itemId)}`, {
      method: "POST", headers: { "Content-Type": "image/jpeg" }, body: blob });
    const out = await res.json();
    if (out.error) throw new Error(out.error.message
      + (out.error.fix ? ` — ${out.error.fix}` : ""));
    return out;
  }

  async function addFiles(itemId, files) {
    const list = [...(files || [])].filter((f) => f && f.size);
    if (!list.length) return;
    say(`adding ${list.length === 1 ? "the photo" : list.length + " photos"}…`);
    for (const file of list) {
      try {
        await upload(itemId, await shrink(file));
      } catch (err) {
        say(err.message, true);
        await refresh(itemId);
        return;
      }
    }
    say("");
    await refresh(itemId);
  }

  /* ---------- the Mac's camera ---------- */

  async function openCamera(itemId) {
    const shell = $("#work-camera");
    if (!shell) return;
    try {
      CAMERA = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: "environment" },
                 width: { ideal: 1920 }, height: { ideal: 1440 } },
        audio: false });
    } catch (err) {
      /* Refused, or there is no camera. Both are ordinary — the file picker
         and paste are still there, so this says so and stops. */
      say(err && err.name === "NotAllowedError"
        ? "the camera was not allowed — use Choose file, or drag the photo in"
        : "no camera was available — use Choose file, or drag the photo in", true);
      return;
    }
    shell.hidden = false;
    const video = $("#work-video");
    video.srcObject = CAMERA;
    await video.play().catch(() => {});
  }

  function closeCamera() {
    const shell = $("#work-camera");
    if (shell) shell.hidden = true;
    if (CAMERA) {
      CAMERA.getTracks().forEach((track) => track.stop());
      CAMERA = null;
    }
    const video = $("#work-video");
    if (video) video.srcObject = null;
  }

  async function snap(itemId) {
    const video = $("#work-video");
    if (!video || !video.videoWidth) return;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth; canvas.height = video.videoHeight;
    canvas.getContext("2d").drawImage(video, 0, 0);
    closeCamera();
    const blob = await new Promise((resolve) =>
      canvas.toBlob(resolve, "image/jpeg", 0.9));
    if (blob) await addFiles(itemId, [blob]);
  }

  /* ---------- the check ---------- */

  async function runCheck(itemId) {
    const button = $("#work-check");
    if (button) { button.disabled = true; button.textContent = "reading it…"; }
    say("reading the photo — this takes a few seconds…");
    try {
      const res = await fetch(`/api/work/${encodeURIComponent(itemId)}/check`,
                              { method: "POST" });
      const out = await res.json();
      if (out.error) { say(out.error.message, true); return; }
      say("");
      await refresh(itemId, out);
    } catch (err) {
      say("the check could not run: " + err.message, true);
    } finally {
      if (button) { button.disabled = false; button.textContent = "Check my work"; }
    }
  }

  /* The photo goes to Anthropic, which is not true of anything else on this
     board — so it is asked, once, before the first send.

     Inline rather than `window.confirm`: there is not one native dialog
     anywhere else in this app, and inside its own window a system alert reads
     as an error rather than a question. This is also the only way the wording
     can be the app's own. */
  function consentGiven() {
    try { return localStorage.getItem(CONSENT) === "yes"; } catch (e) { return false; }
  }

  function rememberConsent() {
    try { localStorage.setItem(CONSENT, "yes"); } catch (e) { /* private window */ }
  }

  function askConsent(itemId) {
    const host = $("#work-ask");
    if (!host) return;
    host.hidden = false;
    host.innerHTML = `
      <p>To check it, the photo is <b>sent to Anthropic</b> to be read — the
         same place your chat questions go. Nowhere else, and SchoolDash keeps
         it only on this Mac.</p>
      <div class="wc-actions">
        <button type="button" class="primary" id="work-ask-yes">Send the photo</button>
        <button type="button" class="ghost" id="work-ask-no">Not now</button>
      </div>`;
    $("#work-ask-yes").onclick = () => {
      rememberConsent();
      host.hidden = true; host.innerHTML = "";
      runCheck(itemId);
    };
    $("#work-ask-no").onclick = () => {
      host.hidden = true; host.innerHTML = "";
      say("nothing was sent.");
    };
  }

  /* ---------- rendering ---------- */

  function say(message, bad) {
    const note = $("#work-note");
    if (!note) return;
    note.textContent = message || "";
    note.classList.toggle("bad", !!bad);
    note.hidden = !message;
  }

  const VERDICT = { RIGHT: "✓", WRONG: "✗", UNSURE: "?" };

  function checkHtml(check) {
    if (!check) return "";
    const when = (check.at || "").slice(11, 16);
    const rows = (check.verdicts || []).map((v) => `
      <div class="wc-row wc-${esc(v.verdict.toLowerCase())}">
        <span class="wc-mark" aria-hidden="true">${VERDICT[v.verdict] || "·"}</span>
        <span class="wc-label">${esc(v.label)}</span>
        <span class="wc-why">${esc(v.why)}</span></div>`).join("");
    /* Anything the line format did not cover is shown, not dropped: a regex
       missing a line must never be the reason he does not see what it said. */
    const stray = (check.stray || []).filter((s) => s.length > 1);
    /* Nothing readable is its own answer — the photo needs retaking. Saying
       "what the model said" over an empty list would bury the one sentence
       that matters. */
    const headline = check.summary
      || (check.unreadable ? "it could not read the work" : "what the model said");
    return `<div class="wc-result${check.unreadable ? " wc-blank" : ""}">
      <div class="wc-head">
        <b>${esc(headline)}</b>
        <span class="kv">${esc(check.model || check.provider || "AI")}${when ? ` · ${esc(when)}` : ""}</span>
      </div>
      ${rows}
      ${check.notes ? `<div class="wc-notes">${esc(check.notes)}</div>` : ""}
      ${check.unreadable ? `<div class="wc-retake kv">Try again with the page
        filling the frame, in good light, straight on. Nothing was guessed at:
        it only judges what it can actually see.</div>` : ""}
      ${stray.length ? `<details class="wc-stray"><summary class="kv">the rest of the reply</summary>
        <div class="full-text">${esc(stray.join("\n"))}</div></details>` : ""}
      <div class="wc-caveat">A second opinion from ${esc(check.model || "an AI")} reading a
        photo — <b>not a grade</b>, not your teacher's answer key, and it can be wrong.
        It is told not to give you the answers.</div>
    </div>`;
  }

  function pagesHtml(itemId, pages) {
    if (!pages.length) return "";
    return `<div class="wc-pages">${pages.map((p) => `
      <figure class="wc-page">
        <img src="/api/work/${encodeURIComponent(itemId)}/photo/${encodeURIComponent(p.name)}"
             alt="a page of your work" loading="lazy">
        <button type="button" class="wc-del" data-page="${esc(p.name)}"
                title="remove this page" aria-label="remove this page">✕</button>
      </figure>`).join("")}</div>`;
  }

  function bodyHtml(itemId, pages, check) {
    const has = pages.length > 0;
    /* The buttons come FIRST, above the thumbnails. [MEASURED] 2026-09-10 at
       995x605: an assignment's pane leaves this box about 60px of visible
       height before it scrolls, and with the pages on top a single 104px
       thumbnail pushed every control out of sight — the affordance has to be
       the part that is always on screen. */
    return `
      <div class="wc-drop" id="work-drop">
        <div class="wc-actions">
          <button type="button" class="ghost" id="work-cam">📷 Take a photo</button>
          <button type="button" class="ghost" id="work-pick">Choose a file</button>
          <input type="file" id="work-file" accept="image/*" capture="environment"
                 multiple hidden>
          ${has ? `<button type="button" class="primary" id="work-check">Check my work</button>` : ""}
          ${has ? `<button type="button" class="ghost" id="work-clear">Remove all</button>` : ""}
        </div>
        <div class="kv wc-hint">${has
          ? "add another page, or drag one in — you can also paste a screenshot with ⌘V"
          : "photograph the paper, drag a file in, or paste a screenshot with ⌘V"}</div>
      </div>
      <div class="wc-cam" id="work-camera" hidden>
        <video id="work-video" playsinline muted></video>
        <div class="wc-actions">
          <button type="button" class="primary" id="work-snap">Take it</button>
          <button type="button" class="ghost" id="work-cam-close">Cancel</button>
        </div>
      </div>
      ${pagesHtml(itemId, pages)}
      <div class="wc-ask" id="work-ask" hidden></div>
      <div class="wc-note" id="work-note" hidden></div>
      ${checkHtml(check)}
      <div class="kv wc-privacy">The photo is kept on this Mac. Pressing
        <b>Check my work</b> sends it to Anthropic to be read — the same place
        chat goes — and nowhere else.</div>`;
  }

  async function refresh(itemId, knownCheck) {
    const host = $("#work-body");
    if (!host) return;
    let pages = [], check = knownCheck || null;
    try {
      const res = await fetch(`/api/work/${encodeURIComponent(itemId)}`);
      const out = await res.json();
      if (!out.error) { pages = out.pages || []; check = knownCheck || out.check || null; }
    } catch (err) { /* an empty box is the right answer when this fails */ }
    host.innerHTML = bodyHtml(itemId, pages, check);
    wire(itemId);
  }

  function wire(itemId) {
    const file = $("#work-file");
    const pick = $("#work-pick");
    if (pick && file) pick.onclick = () => file.click();
    if (file) file.onchange = () => { addFiles(itemId, file.files); file.value = ""; };

    const cam = $("#work-cam");
    if (cam) cam.onclick = () => openCamera(itemId);
    const snapBtn = $("#work-snap");
    if (snapBtn) snapBtn.onclick = () => snap(itemId);
    const camClose = $("#work-cam-close");
    if (camClose) camClose.onclick = closeCamera;

    const check = $("#work-check");
    if (check) check.onclick = () =>
      consentGiven() ? runCheck(itemId) : askConsent(itemId);

    /* Two taps, not a dialog: the second one is the confirmation, and the
       button says what it is about to do. Deleting his own photo is not
       dangerous, but it is not undoable either. */
    const clear = $("#work-clear");
    if (clear) clear.onclick = async () => {
      if (clear.dataset.armed !== "yes") {
        clear.dataset.armed = "yes";
        clear.textContent = "Really remove all?";
        clear.classList.add("danger-btn");
        return;
      }
      await fetch(`/api/work/${encodeURIComponent(itemId)}`, { method: "DELETE" });
      await refresh(itemId);
    };

    $("#work-body").querySelectorAll(".wc-del").forEach((button) => {
      button.onclick = async () => {
        await fetch(`/api/work/${encodeURIComponent(itemId)}/photo/`
          + encodeURIComponent(button.dataset.page), { method: "DELETE" });
        await refresh(itemId);
      };
    });

    const drop = $("#work-drop");
    if (drop) {
      ["dragenter", "dragover"].forEach((type) => drop.addEventListener(type, (event) => {
        event.preventDefault(); drop.classList.add("over");
      }));
      ["dragleave", "drop"].forEach((type) => drop.addEventListener(type, (event) => {
        event.preventDefault(); drop.classList.remove("over");
      }));
      drop.addEventListener("drop", (event) =>
        addFiles(itemId, event.dataTransfer && event.dataTransfer.files));
    }
  }

  /* Paste is wired once on the document, not per render, and only fires while
     the box for THIS assignment is on screen. */
  document.addEventListener("paste", (event) => {
    const host = $("#work-body");
    if (!host || !host.dataset.item || !host.offsetParent) return;
    const files = [...((event.clipboardData || {}).items || [])]
      .filter((entry) => entry.kind === "file" && entry.type.startsWith("image/"))
      .map((entry) => entry.getAsFile());
    if (!files.length) return;
    event.preventDefault();
    addFiles(host.dataset.item, files);
  });

  /* Called by renderDetail once the assignment's pane is built. */
  window.mountWorkCheck = function (itemId) {
    const host = $("#work-body");
    if (!host) return;
    closeCamera();
    host.dataset.item = itemId;
    host.innerHTML = `<div class="kv">loading…</div>`;
    refresh(itemId);
  };

  /* Leaving the assignment must switch the camera light off. */
  window.unmountWorkCheck = closeCamera;
})();
