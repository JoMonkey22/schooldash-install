"""The whole of §15's enforcement: the server binds loopback or does not start.

The page renders a logged-in Canvas session and config.json holds secret feed
URLs; a non-loopback bind would expose both to the network. There is no auth
module because there is nothing network-reachable to authenticate. If the student
ever authorizes a non-loopback mode, THIS is the single place that changes —
and it must then require a token compared in constant time on every request
including SSE.
"""

import ipaddress


class BindError(RuntimeError):
    pass


def assert_loopback(host: str) -> str:
    """Returns the host if it is a numeric loopback address; raises otherwise.
    'localhost' is refused too — it resolves to ::1 first on this machine and
    cost a measured ~2 seconds per request (spec §6.10)."""
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        raise BindError(
            f"refusing to bind {host!r}: the server is loopback-only (spec "
            "§5.7 — the page renders a logged-in Canvas session and the config "
            "holds secret feed URLs). Use the numeric 127.0.0.1; 'localhost' "
            "stalls ~2s per request on this machine (spec §6.10).")
    if not address.is_loopback:
        raise BindError(
            f"refusing to bind {host!r}: not a loopback address (spec §5.7). "
            "To reach the dashboard from another device, keep this bind and "
            "use Tailscale's `tailscale serve` — see README.md.")
    return host
