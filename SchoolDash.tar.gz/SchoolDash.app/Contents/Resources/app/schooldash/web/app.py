"""The Flask app factory and the serve entry points.

`run.py serve` runs in the foreground; `run.py serve --detach` spawns the
server, waits for the port to actually answer, and returns — the skill only
ever calls the detached form. Everything binds through bind_guard.
"""

import socket
import subprocess
import sys
import time

from flask import Flask

from schooldash import config, paths
from schooldash.logging_setup import get, setup
from schooldash.web.bind_guard import assert_loopback

log = get("web")


def create_app() -> Flask:
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config["JSON_SORT_KEYS"] = False
    # A request body bigger than this is refused before Flask buffers it.
    # `work.save` has its own 8 MB rule with a sentence for the person, and
    # that one is the message they see; this is the floor under it, so a
    # mistaken 500 MB POST cannot be read into memory first just to be told
    # no. Photos are shrunk to about 200 KB by the page before they are sent.
    app.config["MAX_CONTENT_LENGTH"] = 12 * 1024 * 1024
    from schooldash.web.routes_api import api
    from schooldash.web.routes_page import page
    app.register_blueprint(page)
    app.register_blueprint(api, url_prefix="/api")
    return app


def port_answering(host: str, port: int, timeout: float = 1.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def serve_foreground() -> int:
    setup(console=True)
    cfg = config.load()["server"]
    host = assert_loopback(cfg["host"])
    port = cfg["port"]
    app = create_app()
    log.info("serving at http://%s:%d/", host, port)
    print(f"SchoolDash at http://{host}:{port}/  (Ctrl+C stops it)")
    try:
        app.run(host=host, port=port, threaded=True, debug=False,
                use_reloader=False)
    except OSError as exc:
        # Errno 48/98. On macOS this is nearly always AirPlay Receiver, which
        # holds port 5000 out of the box and gives no hint that it is doing so.
        hint = ("System Settings > General > AirDrop & Handoff > turn off "
                "AirPlay Receiver, or change server.port in config.json"
                if sys.platform == "darwin"
                else "change server.port in config.json")
        log.error("could not bind %s:%d — %s", host, port, exc)
        print(f"could not start: {host}:{port} is already in use — {hint}")
        return 1
    return 0


def serve_detached(open_browser: bool = False) -> int:
    """Spawn, wait for the port to answer, return. Console-less output goes to
    the log — pythonw discards stdout/stderr entirely."""
    cfg = config.load()["server"]
    host = assert_loopback(cfg["host"])
    port = cfg["port"]
    if port_answering(host, port):
        print(f"already serving at http://{host}:{port}/")
        if open_browser:
            _open_browser(host, port)
        return 0

    creationflags = 0
    if sys.platform == "win32":
        creationflags = (subprocess.CREATE_NO_WINDOW
                         | subprocess.CREATE_NEW_PROCESS_GROUP)
    log_handle = open(paths.log_file(), "a", encoding="utf-8")
    subprocess.Popen(
        [sys.executable, str(paths.project_root() / "run.py"), "serve"],
        stdout=log_handle, stderr=log_handle, stdin=subprocess.DEVNULL,
        cwd=str(paths.project_root()), creationflags=creationflags,
        close_fds=True)
    deadline = time.time() + 30
    while time.time() < deadline:
        if port_answering(host, port):
            print(f"serving at http://{host}:{port}/")
            if open_browser:
                _open_browser(host, port)
            return 0
        time.sleep(0.4)
    print(f"the server did not answer on {host}:{port} within 30s — "
          f"check {paths.log_file()}")
    return 1


def _open_browser(host: str, port: int) -> None:
    # the one place a browser-open call exists, per platform (spec §3)
    import webbrowser
    webbrowser.open(f"http://{host}:{port}/")


def cli_serve(detach: bool = False, open_browser: bool = False) -> int:
    if detach:
        return serve_detached(open_browser=open_browser)
    return serve_foreground()
