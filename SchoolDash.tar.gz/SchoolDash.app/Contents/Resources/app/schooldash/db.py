"""SQLite persistence at data/state.db. Plain SQL, integer schema version.

Durable state only: tick-offs, run history, the adjudication cache, and chat
session ids. The full item list lives in cache/state.json (rebuilt every
refresh) — deleting either file is always safe.
"""

import json
import sqlite3
from datetime import datetime
from pathlib import Path

from schooldash import paths

SCHEMA_VERSION = 1

_SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS done (
    item_id TEXT PRIMARY KEY,
    done_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS runs (
    run_id TEXT PRIMARY KEY,
    started TEXT NOT NULL,
    finished TEXT,
    ok INTEGER NOT NULL DEFAULT 0,
    counts TEXT NOT NULL DEFAULT '{}',
    warnings TEXT NOT NULL DEFAULT '[]',
    diagnostics TEXT NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS adjudications (
    fingerprint TEXT NOT NULL,
    cell_hash TEXT NOT NULL,
    result TEXT NOT NULL,
    created TEXT NOT NULL,
    PRIMARY KEY (fingerprint, cell_hash)
);
CREATE TABLE IF NOT EXISTS ai_usage (
    month TEXT NOT NULL,
    kind TEXT NOT NULL,
    used INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (month, kind)
);
CREATE TABLE IF NOT EXISTS chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    asked_at TEXT NOT NULL,
    role TEXT NOT NULL,
    text TEXT NOT NULL,
    meta_json TEXT
);
CREATE INDEX IF NOT EXISTS chat_messages_time ON chat_messages (asked_at);
CREATE TABLE IF NOT EXISTS chat_sessions (
    session_key TEXT PRIMARY KEY,
    provider_session_id TEXT NOT NULL,
    updated TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS custom_tasks (
    item_id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    due_date TEXT,
    course TEXT,
    section TEXT,
    notes TEXT,
    created TEXT NOT NULL,
    archived INTEGER NOT NULL DEFAULT 0,
    category TEXT
);
CREATE TABLE IF NOT EXISTS doc_state (
    file_id TEXT PRIMARY KEY,
    content_hash TEXT NOT NULL,
    items_json TEXT NOT NULL,
    course_links_json TEXT NOT NULL DEFAULT '[]',
    fingerprint TEXT,
    updated TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS accelerations (
    item_id TEXT PRIMARY KEY,
    content_hash TEXT NOT NULL,
    result_json TEXT NOT NULL,
    provider TEXT,
    created TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS item_history (
    item_id TEXT PRIMARY KEY,
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL,
    item_json TEXT NOT NULL
);
"""


# Columns added after the first release. `CREATE TABLE IF NOT EXISTS` does
# nothing to a table that already exists, so a new column has to be added
# explicitly — and idempotently, because connect() runs on every request.
_ADDED_COLUMNS = [("custom_tasks", "category", "TEXT")]


def _add_missing_columns(conn: sqlite3.Connection) -> None:
    for table, column, kind in _ADDED_COLUMNS:
        existing = {row["name"] for row in
                    conn.execute(f"PRAGMA table_info({table})")}
        if column not in existing:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {kind}")
            conn.commit()


def connect(path: Path | None = None) -> sqlite3.Connection:
    conn = sqlite3.connect(path or paths.db_path())
    conn.row_factory = sqlite3.Row
    conn.executescript(_SCHEMA)
    _add_missing_columns(conn)
    row = conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
    if row is None:
        conn.execute("INSERT INTO meta (key, value) VALUES ('schema_version', ?)",
                     (str(SCHEMA_VERSION),))
        conn.commit()
    return conn


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


# ---- tick-off ---------------------------------------------------------------

def get_done_ids(conn: sqlite3.Connection) -> set[str]:
    return {row["item_id"] for row in conn.execute("SELECT item_id FROM done")}


def set_done(conn: sqlite3.Connection, item_id: str, done: bool) -> None:
    """Idempotent, so it doubles as Undo."""
    if done:
        conn.execute(
            "INSERT INTO done (item_id, done_at) VALUES (?, ?) "
            "ON CONFLICT(item_id) DO NOTHING", (item_id, _now()))
    else:
        conn.execute("DELETE FROM done WHERE item_id = ?", (item_id,))
    conn.commit()


# ---- runs -------------------------------------------------------------------

def record_run(conn: sqlite3.Connection, run) -> None:
    conn.execute(
        "INSERT INTO runs (run_id, started, finished, ok, counts, warnings, diagnostics) "
        "VALUES (?, ?, ?, ?, ?, ?, ?) "
        "ON CONFLICT(run_id) DO UPDATE SET finished=excluded.finished, ok=excluded.ok, "
        "counts=excluded.counts, warnings=excluded.warnings, diagnostics=excluded.diagnostics",
        (run.run_id, run.started, run.finished, int(run.ok),
         json.dumps(run.counts), json.dumps(run.warnings), json.dumps(run.diagnostics)))
    conn.commit()


def list_runs(conn: sqlite3.Connection, limit: int = 20) -> list[dict]:
    rows = conn.execute(
        "SELECT * FROM runs ORDER BY started DESC LIMIT ?", (limit,)).fetchall()
    out = []
    for row in rows:
        out.append({
            "run_id": row["run_id"],
            "started": row["started"],
            "finished": row["finished"],
            "ok": bool(row["ok"]),
            "counts": json.loads(row["counts"]),
            "warnings": json.loads(row["warnings"]),
            "diagnostics": json.loads(row["diagnostics"]),
        })
    return out


# ---- adjudication cache -----------------------------------------------------

def adjudication_get(conn: sqlite3.Connection, fingerprint: str, cell_hash: str) -> dict | None:
    row = conn.execute(
        "SELECT result FROM adjudications WHERE fingerprint=? AND cell_hash=?",
        (fingerprint, cell_hash)).fetchone()
    return json.loads(row["result"]) if row else None


def adjudication_put(conn: sqlite3.Connection, fingerprint: str, cell_hash: str,
                     result: dict) -> None:
    conn.execute(
        "INSERT INTO adjudications (fingerprint, cell_hash, result, created) "
        "VALUES (?, ?, ?, ?) ON CONFLICT(fingerprint, cell_hash) DO UPDATE SET "
        "result=excluded.result, created=excluded.created",
        (fingerprint, cell_hash, json.dumps(result), _now()))
    conn.commit()


# ---- custom tasks -------------------------------------------------------------

def add_custom_task(conn: sqlite3.Connection, item_id: str, title: str,
                    due_date: str | None, course: str | None,
                    section: str | None, notes: str | None,
                    category: str | None = None) -> None:
    conn.execute(
        "INSERT INTO custom_tasks (item_id, title, due_date, course, section, "
        "notes, created, category) VALUES (?, ?, ?, ?, ?, ?, ?, ?) "
        "ON CONFLICT(item_id) DO UPDATE SET title=excluded.title, "
        "due_date=excluded.due_date, course=excluded.course, "
        "section=excluded.section, notes=excluded.notes, "
        "category=excluded.category, archived=0",
        (item_id, title, due_date, course, section, notes, _now(), category))
    conn.commit()


def list_custom_tasks(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute(
        "SELECT * FROM custom_tasks WHERE archived=0 ORDER BY created").fetchall()
    return [dict(row) for row in rows]


def archive_custom_task(conn: sqlite3.Connection, item_id: str) -> bool:
    cur = conn.execute(
        "UPDATE custom_tasks SET archived=1 WHERE item_id=?", (item_id,))
    conn.commit()
    return cur.rowcount > 0


# ---- incremental doc cache -----------------------------------------------------

def doc_state_get(conn: sqlite3.Connection, file_id: str) -> dict | None:
    row = conn.execute("SELECT * FROM doc_state WHERE file_id=?",
                       (file_id,)).fetchone()
    return dict(row) if row else None


def doc_state_put(conn: sqlite3.Connection, file_id: str, content_hash: str,
                  items: list[dict], course_links: list[dict],
                  fingerprint: str) -> None:
    conn.execute(
        "INSERT INTO doc_state (file_id, content_hash, items_json, "
        "course_links_json, fingerprint, updated) VALUES (?, ?, ?, ?, ?, ?) "
        "ON CONFLICT(file_id) DO UPDATE SET content_hash=excluded.content_hash, "
        "items_json=excluded.items_json, "
        "course_links_json=excluded.course_links_json, "
        "fingerprint=excluded.fingerprint, updated=excluded.updated",
        (file_id, content_hash, json.dumps(items), json.dumps(course_links),
         fingerprint, _now()))
    conn.commit()


# ---- AI usage, per calendar month ---------------------------------------------
#
# Counted here rather than trusted to the plan, because an allowance nobody
# measures is a promise, not a limit. One row per (month, kind): the month is
# "YYYY-MM" in the student's own timezone, so an allowance resets when their
# month does and not at some UTC hour in the middle of a school night.


def ai_month(when=None) -> str:
    from schooldash import timezones

    now = when or datetime.now(timezones.zone())
    return f"{now.year:04d}-{now.month:02d}"


def ai_usage(conn: sqlite3.Connection, kind: str, month: str | None = None) -> int:
    row = conn.execute("SELECT used FROM ai_usage WHERE month=? AND kind=?",
                       (month or ai_month(), kind)).fetchone()
    return int(row[0]) if row else 0


def ai_usage_all(conn: sqlite3.Connection, month: str | None = None) -> dict:
    target = month or ai_month()
    return {row[0]: int(row[1]) for row in conn.execute(
        "SELECT kind, used FROM ai_usage WHERE month=?", (target,))}


def ai_usage_record(conn: sqlite3.Connection, kind: str,
                    month: str | None = None) -> int:
    """Count one model call. Returns the new total for that month."""
    target = month or ai_month()
    conn.execute(
        "INSERT INTO ai_usage (month, kind, used) VALUES (?, ?, 1) "
        "ON CONFLICT(month, kind) DO UPDATE SET used = used + 1",
        (target, kind))
    conn.commit()
    return ai_usage(conn, kind, target)


# ---- item history (memory of old stuff; the UI only looks at the new) ----------

def remember_items(conn: sqlite3.Connection, items: list[dict]) -> None:
    now = _now()
    conn.executemany(
        "INSERT INTO item_history (item_id, first_seen, last_seen, item_json) "
        "VALUES (?, ?, ?, ?) ON CONFLICT(item_id) DO UPDATE SET "
        "last_seen=excluded.last_seen, item_json=excluded.item_json",
        [(i["item_id"], now, now, json.dumps(i, default=str)) for i in items])
    conn.commit()


def content_key(entry: dict) -> str:
    """A key for "the same line in the same course", stable across rewording.

    An item_id is a hash of the item as extracted, so any improvement to the
    extractor mints a new id for the same line. [MEASURED] 2026-09-02: two
    undated Spanish lines first seen on 2026-08-26 came back with
    `first_seen` of today, purely because that afternoon's prose changes
    altered their titles — which silently restarted the clock the retirement
    rule reads. A fix that any future extractor change disarms is not a fix.

    The raw text the teacher wrote does not change when our reading of it
    does, so that is the key.
    """
    raw = (entry.get("detail") or entry.get("title") or "").strip().lower()
    return f"{entry.get('course_key') or ''}|{' '.join(raw.split())[:160]}"


def first_seen_by_content(conn: sqlite3.Connection) -> dict:
    """{content_key: earliest first_seen} over everything ever remembered.

    The whole table, because the point is to find an ancestor of an item whose
    id has changed. It is small — one row per item ever seen, 80 after a term
    — and read once per refresh.
    """
    out: dict = {}
    for item_id, first_seen, item_json in conn.execute(
            "SELECT item_id, first_seen, item_json FROM item_history"):
        try:
            entry = json.loads(item_json)
        except (TypeError, ValueError):
            continue
        key = content_key(entry)
        if key and (key not in out or first_seen < out[key]):
            out[key] = first_seen
    return out


def first_seen_map(conn: sqlite3.Connection, item_ids: list[str]) -> dict:
    """{item_id: first_seen ISO string} for the ids given.

    `item_history` has recorded this since the beginning and nothing read it.
    It is the only honest clock for "how long has this been on the board
    unanswered" — see pipeline.retire_stale_undated.
    """
    if not item_ids:
        return {}
    out: dict = {}
    for chunk in range(0, len(item_ids), 400):
        window = item_ids[chunk:chunk + 400]
        marks = ",".join("?" * len(window))
        for row in conn.execute(
                f"SELECT item_id, first_seen FROM item_history "
                f"WHERE item_id IN ({marks})", window):
            out[row[0]] = row[1]
    return out


# ---- accelerated assignments (study guides) -----------------------------------

def acceleration_get(conn: sqlite3.Connection, item_id: str) -> dict | None:
    row = conn.execute("SELECT * FROM accelerations WHERE item_id=?",
                       (item_id,)).fetchone()
    if not row:
        return None
    out = dict(row)
    out["result"] = json.loads(out.pop("result_json"))
    return out


def acceleration_ids(conn: sqlite3.Connection) -> set:
    """Which items have a study guide written. Ids only — the chat payload
    lists them cheaply and fetches the text only when asked about one."""
    return {row[0] for row in conn.execute("SELECT item_id FROM accelerations")}


def acceleration_put(conn: sqlite3.Connection, item_id: str, content_hash: str,
                     result: dict, provider: str) -> None:
    conn.execute(
        "INSERT INTO accelerations (item_id, content_hash, result_json, provider, created) "
        "VALUES (?, ?, ?, ?, ?) ON CONFLICT(item_id) DO UPDATE SET "
        "content_hash=excluded.content_hash, result_json=excluded.result_json, "
        "provider=excluded.provider, created=excluded.created",
        (item_id, content_hash, json.dumps(result, ensure_ascii=False), provider, _now()))
    conn.commit()


def acceleration_delete(conn: sqlite3.Connection, item_id: str) -> None:
    conn.execute("DELETE FROM accelerations WHERE item_id=?", (item_id,))
    conn.commit()


# ---- chat sessions ----------------------------------------------------------

# ---- chat history -------------------------------------------------------------
#
# The conversation used to live only in the page. Reloading the app, or opening
# it the next morning, showed an empty box — and the questions a student asks
# are a record of what confused them, which is worth keeping. Stored on their
# own Mac like everything else.
#
# Trimmed rather than unbounded: a year of chat is thousands of rows nobody
# reads, and the payload sent to the model never includes history anyway.
CHAT_HISTORY_KEEP = 200


def chat_message_add(conn: sqlite3.Connection, role: str, text: str,
                     meta: dict | None = None) -> None:
    conn.execute(
        "INSERT INTO chat_messages (asked_at, role, text, meta_json) "
        "VALUES (?, ?, ?, ?)",
        (_now(), role, text, json.dumps(meta or {}, default=str)))
    conn.execute(
        "DELETE FROM chat_messages WHERE id NOT IN "
        "(SELECT id FROM chat_messages ORDER BY id DESC LIMIT ?)",
        (CHAT_HISTORY_KEEP,))
    conn.commit()


def chat_history(conn: sqlite3.Connection, limit: int = 60) -> list[dict]:
    """Oldest first, so the page can replay it in order."""
    rows = conn.execute(
        "SELECT asked_at, role, text, meta_json FROM chat_messages "
        "ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    out = []
    for asked_at, role, text, meta_json in reversed(rows):
        try:
            meta = json.loads(meta_json or "{}")
        except ValueError:
            meta = {}
        out.append({"at": asked_at, "role": role, "text": text, "meta": meta})
    return out


def chat_history_clear(conn: sqlite3.Connection) -> int:
    count = conn.execute("SELECT count(*) FROM chat_messages").fetchone()[0]
    conn.execute("DELETE FROM chat_messages")
    conn.commit()
    return int(count)


def chat_session_get(conn: sqlite3.Connection, session_key: str) -> str | None:
    row = conn.execute(
        "SELECT provider_session_id FROM chat_sessions WHERE session_key=?",
        (session_key,)).fetchone()
    return row["provider_session_id"] if row else None


def chat_session_put(conn: sqlite3.Connection, session_key: str, provider_id: str) -> None:
    conn.execute(
        "INSERT INTO chat_sessions (session_key, provider_session_id, updated) "
        "VALUES (?, ?, ?) ON CONFLICT(session_key) DO UPDATE SET "
        "provider_session_id=excluded.provider_session_id, updated=excluded.updated",
        (session_key, provider_id, _now()))
    conn.commit()
