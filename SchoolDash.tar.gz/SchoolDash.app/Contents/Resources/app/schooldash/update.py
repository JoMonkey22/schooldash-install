"""Is there a newer SchoolDash, and can this one become it?

The app installs to `~/Applications/SchoolDash.app` and its Python environment
lives OUTSIDE the bundle, in the data home — which is what makes updating in
place possible at all: the bundle is just files, and swapping it does not
disturb the venv, the browser profile, the database or the config.

Three rules this module keeps:

* **It never updates on its own.** The check is a read; the swap happens only
  when someone presses the button. An app that replaces itself while a student
  is mid-refresh is a bug, not a feature.
* **It never destroys the working copy until the new one is proven.** The
  download is verified as a real archive holding a real bundle with a VERSION
  strictly newer than this one, unpacked to a temporary directory, and only
  then swapped. The old bundle is moved aside, not deleted, and is put back if
  anything fails.
* **It is honest about not knowing.** No network, a site that has never been
  deployed, a missing marker file: all of these mean "could not check", which
  is a different sentence from "you are up to date", and neither is a banner.

What it deliberately does NOT do: download and execute `install.sh`. That
script exists for the first install, where there is nothing to run the work.
Here there is — this process — so the update is done in Python where every
step can be checked, rather than by piping a shell script from the internet.
"""

import json
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
from pathlib import Path

import httpx

from schooldash import config, paths
from schooldash.logging_setup import get

log = get("update")

# Where the published build lives. His own installer site by default; the same
# environment variable install.sh honours, so a test can point both at a local
# copy without editing anyone's config.
DEFAULT_BASE = "https://jomonkey22.github.io/schooldash-install"
MARKER = "version.json"
ARCHIVE = "SchoolDash.tar.gz"

# A check is worth making a few times a day, not on every page load.
CHECK_EVERY_S = 6 * 3600
HTTP_TIMEOUT = 20.0
# The real archive is ~500 KB. The cap is generous enough to survive the app
# growing and small enough that a redirect to something enormous is refused
# rather than written to his disk.
MAX_ARCHIVE_BYTES = 80 * 1024 * 1024


def base_url() -> str:
    env = os.environ.get("SCHOOLDASH_INSTALL_BASE")
    if env:
        return env.rstrip("/")
    configured = (config.load().get("update") or {}).get("base") or ""
    return (configured or DEFAULT_BASE).rstrip("/")


def enabled() -> bool:
    """Update checks can be switched off entirely in config."""
    section = config.load().get("update") or {}
    return section.get("check", True) is not False


def current_version() -> str:
    try:
        return (paths.project_root() / "VERSION").read_text(encoding="utf-8").strip()
    except OSError:
        return "unknown"


def bundle_path() -> Path | None:
    """The `.app` this code is running from, or None in a dev checkout.

    project_root() inside the bundle is `SchoolDash.app/Contents/Resources/app`,
    so the bundle is three levels up. Returning None for a checkout is the
    point: `~/Projects/schooldash` must never be overwritten by an installer.
    """
    root = paths.project_root()
    for candidate in list(root.parents)[:3]:
        if candidate.suffix != ".app" or not candidate.is_dir():
            continue
        # It must be OUR bundle, laid out the way build_app.sh lays one out.
        # [PROVEN] tests/test_prosecution.py: a checkout that merely happens to
        # sit inside some other `.app` — `~/Some App.app/schooldash` — matched
        # on the suffix alone, and `install()` would then have moved that
        # application aside and unpacked SchoolDash over it.
        if candidate.name != "SchoolDash.app":
            continue
        if not (candidate / "Contents" / "Resources" / "app" / "VERSION").exists():
            continue
        return candidate
    return None


def parse_version(text: str) -> tuple:
    """'0.18.0.1' -> (0, 18, 0, 1). Anything unparseable sorts lowest, so a
    corrupt marker can never look like an upgrade."""
    parts = []
    for chunk in str(text or "").strip().split("."):
        digits = "".join(ch for ch in chunk if ch.isdigit())
        if not digits:
            return ()
        parts.append(int(digits))
    return tuple(parts)


def is_newer(remote: str, local: str) -> bool:
    left, right = parse_version(remote), parse_version(local)
    if not left or not right:
        return False
    return left > right


def _cache_path() -> Path:
    return paths.cache_dir() / "update.json"


def _read_cache() -> dict:
    try:
        return json.loads(_cache_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _write_cache(record: dict) -> None:
    try:
        _cache_path().write_text(json.dumps(record, indent=1), encoding="utf-8")
    except OSError as exc:  # noqa: BLE001 — a cache that cannot be written is not an error
        log.debug("could not write the update cache: %s", exc)


def _fetch_marker() -> dict:
    """The published `version.json`. Raises on anything that is not one."""
    url = f"{base_url()}/{MARKER}"
    response = httpx.get(url, timeout=HTTP_TIMEOUT,
                         follow_redirects=True,
                         headers={"Cache-Control": "no-cache"})
    response.raise_for_status()
    # Netlify answers a missing file with a 200 HTML page, so the status alone
    # proves nothing — the shape of the body is what proves it.
    data = response.json()
    if not isinstance(data, dict) or not data.get("version"):
        raise ValueError("the published version marker has no version in it")
    return data


def status(force: bool = False) -> dict:
    """What is known about updates, without ever raising.

    Cached: a page load reads the cache, and the network is touched only when
    the cache is older than CHECK_EVERY_S or `force` is set.
    """
    local = current_version()
    bundle = bundle_path()
    record = _read_cache()
    result = {
        "current": local,
        "latest": record.get("latest"),
        "available": False,
        "checked_at": record.get("checked_at"),
        "error": record.get("error"),
        "notes": record.get("notes") or "",
        "can_install": bundle is not None,
        # A dev checkout is not a thing to update, and saying why beats a
        # button that would overwrite the source tree.
        "why_not": "" if bundle is not None
                   else "this is a source checkout, not an installed app — "
                        "update it with git",
        "enabled": enabled(),
    }
    if not enabled():
        result["why_not"] = "update checks are switched off in config.json"
        return result

    fresh = False
    if record.get("checked_at"):
        try:
            fresh = (time.time() - float(record["checked_at"])) < CHECK_EVERY_S
        except (TypeError, ValueError):
            fresh = False
    if force or not fresh:
        try:
            marker = _fetch_marker()
            record = {"checked_at": time.time(),
                      "latest": str(marker.get("version")).strip(),
                      "notes": str(marker.get("notes") or "")[:400],
                      "error": None}
        except Exception as exc:  # noqa: BLE001 — never let a check break a page
            log.info("update check failed: %s", exc)
            record = {"checked_at": time.time(),
                      "latest": record.get("latest"),
                      "notes": record.get("notes") or "",
                      "error": f"{type(exc).__name__}"}
        _write_cache(record)
        result.update({"latest": record.get("latest"),
                       "checked_at": record.get("checked_at"),
                       "notes": record.get("notes") or "",
                       "error": record.get("error")})

    result["available"] = bool(result["latest"]
                               and is_newer(result["latest"], local))
    return result


def _download(url: str, target: Path, emit=None) -> None:
    say = emit or (lambda _line: None)
    say(f"downloading {url}")
    written = 0
    with httpx.stream("GET", url, timeout=HTTP_TIMEOUT,
                      follow_redirects=True) as response:
        response.raise_for_status()
        with target.open("wb") as handle:
            for chunk in response.iter_bytes():
                written += len(chunk)
                if written > MAX_ARCHIVE_BYTES:
                    raise ValueError("the download is far larger than a "
                                     "SchoolDash build — refusing it")
                handle.write(chunk)
    say(f"downloaded {written // 1024} KB")


def _unpack(archive: Path, into: Path, emit=None) -> Path:
    """Unpack and return the bundle inside, refusing anything else."""
    say = emit or (lambda _line: None)
    if not tarfile.is_tarfile(archive):
        raise ValueError("that download is not an archive — the site may have "
                         "answered with an error page")
    with tarfile.open(archive, "r:gz") as tar:
        names = tar.getnames()
        if not any(name.split("/")[0] == "SchoolDash.app" for name in names):
            raise ValueError("the archive does not contain SchoolDash.app")
        # filter="data" refuses absolute paths, "..", links out of the tree
        # and device files. Extracting an archive from the network without it
        # is how a downloader writes outside the directory it meant to.
        tar.extractall(into, filter="data")
    new_bundle = into / "SchoolDash.app"
    if not (new_bundle / "Contents" / "Resources" / "app" / "VERSION").exists():
        raise ValueError("the unpacked app has no VERSION file")
    say("unpacked")
    return new_bundle


def install(emit=None, force: bool = False) -> dict:
    """Download the published build and swap this bundle for it.

    Returns {"installed": version, "restart_required": True}. Raises with a
    sentence a student can read on any failure, having left the working copy
    exactly as it was.
    """
    say = emit or (lambda _line: None)
    bundle = bundle_path()
    if bundle is None:
        raise RuntimeError("this is a source checkout, not an installed app — "
                           "update it with git, not from here")
    local = current_version()
    work = Path(tempfile.mkdtemp(prefix="schooldash-update-"))
    aside = bundle.with_name(bundle.name + ".previous")
    try:
        archive = work / ARCHIVE
        _download(f"{base_url()}/{ARCHIVE}", archive, say)
        new_bundle = _unpack(archive, work / "unpacked", say)
        new_version = (new_bundle / "Contents" / "Resources" / "app"
                       / "VERSION").read_text(encoding="utf-8").strip()
        say(f"downloaded version {new_version}, this one is {local}")
        if not force and not is_newer(new_version, local):
            raise RuntimeError(
                f"the published build is {new_version}, which is not newer "
                f"than the {local} already installed — nothing to do")

        # From here the working copy is at risk, so every step is reversible.
        if aside.exists():
            shutil.rmtree(aside, ignore_errors=True)
        say("putting the new version in place")
        os.rename(bundle, aside)
        try:
            shutil.copytree(new_bundle, bundle, symlinks=True)
        except Exception:
            # Put it back exactly as it was. A student left with no app
            # because an update failed halfway is the worst outcome here.
            if bundle.exists():
                shutil.rmtree(bundle, ignore_errors=True)
            os.rename(aside, bundle)
            raise
        say(f"SchoolDash {new_version} is installed")
        # The old bundle stays as .previous until the next update, so there is
        # always one working copy to fall back to.
        return {"installed": new_version, "previous": local,
                "restart_required": True, "bundle": str(bundle)}
    finally:
        shutil.rmtree(work, ignore_errors=True)


def restart_server() -> dict:
    """Hand the port to a server running the NEW code.

    The window is a separate process pointed at 127.0.0.1, so it survives
    this: only the server is replaced, and the page reconnects on its own.
    A detached helper does the waiting, because the process that has to exit
    cannot also be the one that waits for its own port to come free.
    """
    bundle = bundle_path()
    root = (bundle / "Contents" / "Resources" / "app") if bundle else paths.project_root()
    cfg = config.load()["server"]
    host, port = cfg["host"], int(cfg["port"])
    helper = (
        "import socket, subprocess, sys, time, os\n"
        f"host, port = {host!r}, {port}\n"
        "def answering():\n"
        "    try:\n"
        "        with socket.create_connection((host, port), timeout=1):\n"
        "            return True\n"
        "    except OSError:\n"
        "        return False\n"
        "deadline = time.time() + 30\n"
        "while time.time() < deadline and answering():\n"
        "    time.sleep(0.5)\n"
        f"subprocess.Popen([{sys.executable!r}, {str(root / 'run.py')!r}, 'serve'],\n"
        f"                 cwd={str(root)!r}, stdout=subprocess.DEVNULL,\n"
        "                 stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,\n"
        "                 start_new_session=True)\n"
    )
    subprocess.Popen([sys.executable, "-c", helper],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     stdin=subprocess.DEVNULL, start_new_session=True,
                     env={**os.environ})
    log.info("restart helper spawned; this server will exit")
    return {"restarting": True, "port": port}


def exit_soon(seconds: float = 1.0) -> None:
    """Let the HTTP reply reach the page before the process goes away."""
    import threading

    def stop():
        time.sleep(seconds)
        log.info("exiting for an update restart")
        os._exit(0)

    threading.Thread(target=stop, daemon=True).start()
