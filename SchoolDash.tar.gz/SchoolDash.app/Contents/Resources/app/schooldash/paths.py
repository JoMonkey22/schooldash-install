"""All filesystem path resolution for SchoolDash.

No path literal lives anywhere else in the package. Everything resolves
relative to the project root (the directory holding run.py), which can be
overridden with the SCHOOLDASH_HOME environment variable — that is what lets
the skill drive the project from any working directory.
"""

import os
import sys
from pathlib import Path


def project_root() -> Path:
    env = os.environ.get("SCHOOLDASH_HOME")
    if env:
        return Path(env).resolve()
    return Path(__file__).resolve().parent.parent


def data_root() -> Path:
    """Where mutable state lives: config.json, data/, cache/, logs/,
    browser_profile/. Defaults to project_root() (a normal dev checkout,
    where source and state have always shared one directory).

    The packaged Mac app points this elsewhere with SCHOOLDASH_DATA_HOME:
    a bundle launched normally (not from a trusted terminal) can't write
    inside its own app bundle — files copied out of a downloaded, quarantined
    disk image carry a com.apple.provenance attribute that a plain rename()
    ([MEASURED] os.replace raised PermissionError/EPERM) refuses to cross for
    a process without elevated trust. A location the app creates itself at
    runtime never inherits that attribute, so this sidesteps it entirely."""
    env = os.environ.get("SCHOOLDASH_DATA_HOME")
    if env:
        return _ensure(Path(env).resolve())
    return project_root()


def _ensure(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def data_dir() -> Path:
    return _ensure(data_root() / "data")


def profiles_dir() -> Path:
    return _ensure(data_dir() / "profiles")


def courses_dir() -> Path:
    """Per-course records: detected materials, the student's notes and links.
    One JSON file per course, hand-editable like the profiles."""
    return _ensure(data_dir() / "courses")


def chrome_extension_dir() -> Path | None:
    """The unpacked Chrome extension shipped with the app, or None.

    **Shipped inside the bundle so nobody has to download or unzip it.**
    Loading an unpacked extension needs a FOLDER on disk, and asking a
    fifteen-year-old to fetch a zip, find it in Downloads, unzip it, and then
    not delete it is four chances to give up — and a deleted folder silently
    breaks the extension later, because Chrome remembers the path.

    Two homes because there are two installs (see CLAUDE.md): in the packaged
    app it sits beside the Python payload in `Contents/Resources`; in the dev
    checkout it is `packaging/chrome-extension`, the source of truth both are
    built from. Returns None rather than a missing path, so a caller can say
    "not in this build" instead of offering a folder that is not there.
    """
    here = project_root()
    for candidate in (here.parent / "chrome-extension",
                      here / "packaging" / "chrome-extension"):
        if (candidate / "manifest.json").is_file():
            return candidate
    return None


def work_dir() -> Path:
    """Photos of finished work, one folder per assignment, plus the last
    check's reply. Under `data/`, which is gitignored and is never part of the
    classmate payload or a published snapshot — a photo of his homework has
    his handwriting and often his name on it."""
    return _ensure(data_dir() / "work")


def profiles_history_dir() -> Path:
    return _ensure(profiles_dir() / ".history")


def cache_dir() -> Path:
    return _ensure(data_root() / "cache")


def docs_cache_dir() -> Path:
    return _ensure(cache_dir() / "docs")


def state_json_path() -> Path:
    return cache_dir() / "state.json"


def session_path() -> Path:
    """The signed-in account token. Lives under data/, which is gitignored and
    excluded from the installer payload — it is a credential."""
    return data_dir() / "session.json"


def credentials_path() -> Path:
    """The saved sign-in details (school Google account, Veracross). Under
    data/, which is gitignored and excluded from the installer payload. The
    file is written mode 0600 — see schooldash/credentials.py for what it
    holds and why it exists."""
    return data_dir() / "credentials.json"


def login_shots_dir() -> Path:
    """Screenshots the auto-login saves when it gets stuck, so the person
    helping can see the page that stopped it without being there."""
    return _ensure(logs_dir() / "login-shots")


def logs_dir() -> Path:
    return _ensure(data_root() / "logs")


def log_file() -> Path:
    return logs_dir() / "schooldash.log"


def grounding_log_path() -> Path:
    return logs_dir() / "grounding.jsonl"


def cli_prefix() -> str:
    """How to invoke run.py on THIS install, quoted ready for a shell.

    Every fix string used to read `python run.py …`, and macOS has no `python`
    on PATH at all — only `python3`, which on the build machine is a 3.14 from
    python.org that the project does not run on. [MEASURED] 2026-08-31: the
    dashboard told the student to run `python run.py login`, bash answered
    "command not found", and the advice was a dead end — twice, on two
    different Macs. The packaged app is worse again: its interpreter lives
    inside Application Support, nowhere near a shell's PATH.

    sys.executable is already the right interpreter in both installs, because
    whatever is printing the fix is being run by it.
    """
    exe = sys.executable or "python3"
    return f'"{exe}" "{project_root() / "run.py"}"'


def runnable(fix: str) -> str:
    """Turn a `python run.py …` fix into one that runs on this machine."""
    if not fix:
        return fix
    for prefix in ("python run.py", "python3 run.py"):
        if fix.startswith(prefix):
            return cli_prefix() + fix[len(prefix):]
    return fix


def config_path() -> Path:
    return data_root() / "config.json"


def config_example_path() -> Path:
    return project_root() / "config.example.json"


def db_path() -> Path:
    return data_dir() / "state.db"


def default_browser_profile_dir() -> Path:
    return data_root() / "browser_profile"


def legacy_tracker_dir() -> Path:
    """The predecessor assignment-tracker project, if it sits next to us.

    Used only for the one-time config / doc_done.json import; everything
    degrades gracefully when it is absent.
    """
    return project_root().parent / "assignment-tracker"


def legacy_dir() -> Path:
    """Byte-for-byte copies of the predecessor scripts inside this repo."""
    return project_root() / "legacy"


def skill_source_dir() -> Path:
    return project_root() / ".claude" / "skills" / "schooldash"


def skill_install_dir() -> Path:
    return Path.home() / ".claude" / "skills" / "schooldash"
