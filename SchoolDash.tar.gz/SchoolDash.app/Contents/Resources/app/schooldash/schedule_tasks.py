"""Windows Task Scheduler wiring for the automatic refresh+publish.

One schtasks entry per configured time (the union of school-day and off-day
slots); publish_task.pyw decides at runtime whether the current slot applies —
school days use 06:30/10:40/14:20/17:00, weekends and breaks 06:00/12:00, and
"school day" means the class feed actually has meetings today. Everything is
console-less and logs to logs/schooldash.log. Runs only while the PC is on;
missed slots are skipped, which is the behavior that was asked for.
"""

import subprocess
import sys
from pathlib import Path

from schooldash import config, paths

TASK_PREFIX = "SchoolDash Publish"


def _pythonw() -> str:
    candidate = Path(sys.executable).with_name("pythonw.exe")
    return str(candidate if candidate.exists() else sys.executable)


def _slots() -> list[str]:
    pub = config.load()["publish"]
    times = sorted(set((pub.get("schedule_school") or [])
                       + (pub.get("schedule_off") or [])))
    return times


def install() -> int:
    if sys.platform != "win32":
        print("scheduled publishing is wired for Windows Task Scheduler; on "
              "macOS use launchd or cron with: python3 run.py publish")
        return 1
    script = paths.project_root() / "publish_task.pyw"
    created = []
    for hhmm in _slots():
        name = f"{TASK_PREFIX} {hhmm.replace(':', '')}"
        command = ["schtasks", "/Create", "/F", "/TN", name,
                   "/SC", "DAILY", "/ST", hhmm,
                   "/TR", f'"{_pythonw()}" "{script}"']
        result = subprocess.run(command, capture_output=True, text=True)
        if result.returncode == 0:
            created.append((name, hhmm))
        else:
            print(f"  ! could not create {name}: "
                  f"{(result.stderr or result.stdout).strip()[:200]}")
    print(f"created {len(created)} scheduled task(s):")
    for name, hhmm in created:
        print(f"  {hhmm}  Task Scheduler -> \"{name}\" -> pythonw {script.name}")
    print("Each run decides for itself whether its slot applies today "
          "(school day vs weekend/break) and logs to logs/schooldash.log.")
    return 0 if created else 1


def remove() -> int:
    removed = 0
    for hhmm in _slots():
        name = f"{TASK_PREFIX} {hhmm.replace(':', '')}"
        result = subprocess.run(["schtasks", "/Delete", "/F", "/TN", name],
                                capture_output=True, text=True)
        if result.returncode == 0:
            removed += 1
    print(f"removed {removed} scheduled task(s)")
    return 0


def status() -> int:
    result = subprocess.run(["schtasks", "/Query", "/FO", "LIST"],
                            capture_output=True, text=True)
    lines = [l for l in (result.stdout or "").splitlines()
             if TASK_PREFIX in l or (TASK_PREFIX.split()[0] in l and "Next Run" in l)]
    ours = [l.split(":", 1)[1].strip() for l in (result.stdout or "").splitlines()
            if l.startswith("TaskName") and TASK_PREFIX in l]
    if not ours:
        print("no SchoolDash scheduled tasks — create them: python run.py schedule --install")
        return 1
    for name in ours:
        print(f"  {name}")
    return 0


def cli_schedule(install_flag=False, remove_flag=False) -> int:
    if install_flag:
        return install()
    if remove_flag:
        return remove()
    return status()
