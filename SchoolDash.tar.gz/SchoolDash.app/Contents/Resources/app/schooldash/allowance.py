"""Whether a model call is inside the month's allowance, and counting it.

Two rules, both of which exist so a limit is a limit rather than a promise:

**A call is counted after it happens, not before.** A refused request, a dead
network, a provider that raises — none of those got the student an answer, and
charging them for it would be the app taking something for nothing.

**Running out never takes away what needs no model.** Three in five chat
questions are answered from the board by `ai/lookup.py`, and those keep
working when the allowance is gone. So does the board, the schedule, grades,
links and ticking work off. What stops is the model — and the app says so,
with the date it comes back.

The month is the student's own calendar month in their own timezone
(`db.ai_month`), so an allowance resets when their month does.
"""

from __future__ import annotations

from schooldash import db, plans
from schooldash.logging_setup import get

log = get("allowance")


class Exhausted(RuntimeError):
    """The month's allowance for this kind of call is used up."""

    def __init__(self, kind: str, used: int, included: int, plan_name: str):
        super().__init__(f"{kind}: {used} of {included} used this month")
        self.kind = kind
        self.used = used
        self.included = included
        self.plan_name = plan_name

    @property
    def message(self) -> str:
        what = {"chat": "chat questions that need the assistant",
                "accelerate": "study guides",
                "profiles": "classes learned from a teacher's document"
                }.get(self.kind, self.kind)
        # On Free, "it resets on the 1st" is true but it is not the useful
        # half of the sentence. On a paid plan an upgrade nudge would be
        # nagging someone who is already paying.
        next_step = ("Basic is $4.99 a month for five times as much."
                     if self.plan_name.lower() == "free"
                     else "It resets on the 1st.")
        return (f"You have used all {self.included} {what} on "
                f"{self.plan_name} this month. {next_step} "
                "Everything else keeps working — the board, your schedule, "
                "grades, and the questions the app answers itself.")


# Only these providers cost the person who sold the plan anything. The others
# are free at the point of use:
#
#   claude_code  the student's own Claude access pays for the call
#   ollama       a model on their own machine
#   null         no model at all
#
# So an allowance is enforced only against a metered API key. This is not a
# loophole — it is the whole difference between "you are spending my money"
# and "you are spending yours", and capping the second would be inventing a
# limit for no one's benefit. [MEASURED] 2026-09-03: every install today runs
# claude_code, including his own, so nothing is capped yet.
METERED_PROVIDERS = frozenset({"anthropic_api"})


def metered(kind: str = "chat") -> bool:
    """Is the model call about to be billed to whoever sold the plan?"""
    try:
        from schooldash.ai import detect

        return detect.provider_for(kind).name in METERED_PROVIDERS
    except Exception:  # noqa: BLE001 — unknown means do not charge
        return False


def _plan_key() -> str:
    """The plan the entitlement says they are on. Basic when nothing says."""
    try:
        from schooldash import account

        # account.subscription(), not state() or status(): the plan lives on
        # the subscription, and status() only wraps it. Two wrong names in a
        # row here silently fell back to Basic for everyone — which is what a
        # broad `except` around an attribute lookup buys you.
        return (account.subscription() or {}).get("plan") or plans.DEFAULT_PLAN
    except Exception:  # noqa: BLE001 — a missing account is Basic, never a crash
        return plans.DEFAULT_PLAN


def status(kind: str | None = None) -> dict:
    """What is used and what is included, for Settings and the API."""
    key = _plan_key()
    conn = db.connect()
    try:
        used = db.ai_usage_all(conn)
    finally:
        conn.close()
    # `profiles` is here so Settings can show the repair budget, which is the
    # one allowance a student never presses a button for and would otherwise
    # only discover by its refusal.
    kinds = [kind] if kind else ["chat", "accelerate", "profiles"]
    out = {"plan": key, "plan_name": plans.plan(key)["name"],
           "month": db.ai_month(), "metered": metered(), "kinds": {}}
    for name in kinds:
        included = plans.allowance(key, name)
        spent = int(used.get(name, 0))
        out["kinds"][name] = {
            "used": spent, "included": included,
            "left": max(0, included - spent),
            "exhausted": included > 0 and spent >= included,
            # 0 means UNLIMITED here, as it does in `check` above — said
            # explicitly because the page cannot be expected to know that.
            # [PROSECUTION 2026-09-11, COUNT 2] Settings rendered Basic's
            # unlimited profile budget as "3 of 0 used this month · 0 left",
            # which reads as exhausted. `exhausted` was already correct; the
            # sentence built from `included` and `left` was not.
            "unlimited": included <= 0,
        }
    return out


def check(kind: str) -> None:
    """Raise Exhausted when this month's allowance for `kind` is gone.

    Returns without doing anything when the call is not metered — the
    student's own Claude access, a local model, or no model. An allowance of 0
    also means unlimited rather than blocked, so a future plan that forgets to
    set one cannot lock the app.
    """
    if not metered(kind):
        return
    key = _plan_key()
    included = plans.allowance(key, kind)
    if included <= 0:
        return
    conn = db.connect()
    try:
        used = db.ai_usage(conn, kind)
    finally:
        conn.close()
    if used >= included:
        raise Exhausted(kind, used, included, plans.plan(key)["name"])


def record(kind: str) -> int:
    """Count one call that actually happened. Never raises."""
    try:
        conn = db.connect()
        try:
            return db.ai_usage_record(conn, kind)
        finally:
            conn.close()
    except Exception as exc:  # noqa: BLE001 — metering must not break a reply
        log.warning("could not record %s usage: %s", kind, exc)
        return 0
