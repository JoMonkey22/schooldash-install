"""Photos of finished work, and where they live.

*"add a thing in asgnments where you can click on the assginment and take a
photo of your assignment or uplod the assghinment had the ai will check it"*

One folder per assignment under `data/work/<item_id>/`, holding the pages he
photographed and `check.json`, the last reply. Three things this module exists
to get right:

**An item id from a URL is not a path.** Every id in this app is hex from
`db.item_id`, so `_safe` requires exactly that and refuses everything else.
A folder is never built by joining a caller's string onto a directory without
that check — `../../` in a path segment is the oldest file-server bug there is.

**A file's extension is not what it is.** The bytes are sniffed for the magic
numbers of the formats a model can actually read, and the stored name comes
from that sniff, not from whatever the browser called the upload.

**The photos are private and stay that way.** `data/` is gitignored, is not in
the classmate installer's payload, and `snapshot.py` does not read this
folder. A photo of his homework carries his handwriting and usually his name.
"""

from __future__ import annotations

import json
import re
import time
from pathlib import Path

from schooldash import paths
from schooldash.logging_setup import get

log = get("work")

# `\Z`, not `$`. [MEASURED] 2026-09-10 by a test written to be paranoid:
# Python's `$` also matches immediately BEFORE a trailing newline, so
# `"a2c13710da7e1d13\n"` passed `ID` and would have been joined onto the work
# directory as a folder name. Nothing escapes the directory that way, but a
# validator that accepts what it is meant to reject is not a validator.
ID = re.compile(r"^[0-9a-f]{6,64}\Z")
NAME = re.compile(r"^[0-9]{8}-[0-9]{6}-[0-9a-f]{4}\.(jpg|png|webp)\Z")

# The formats Claude can read, by magic number. HEIC — what an iPhone shoots
# by default — is NOT here: the model cannot read it and neither can a canvas
# in Safari without a decode step, so the page converts to JPEG before upload
# and an unconverted HEIC is refused with a sentence saying so rather than
# stored as something that will fail later.
MAGIC = (
    (b"\xff\xd8\xff", "jpg", "image/jpeg"),
    (b"\x89PNG\r\n\x1a\n", "png", "image/png"),
    (b"RIFF", "webp", "image/webp"),        # checked further below
)
MAX_BYTES = 8 * 1024 * 1024
MAX_PAGES = 8

# What every page of one assignment may add up to, checked before a model ever
# sees them. [PROSECUTION 2026-09-11, COUNT 3] MAX_BYTES x MAX_PAGES is 64 MB,
# and `workcheck.check` loads every page and sends them in ONE vision call —
# ~85 MB once base64'd. The page shrinks a photo to about 200 KB so this is
# unreachable through the app; it is reachable by anything that can POST to the
# loopback, which is the case a limit is for.
MAX_CHECK_BYTES = 12 * 1024 * 1024


class WorkError(RuntimeError):
    """Something the person can fix, with the sentence to show them."""

    def __init__(self, message: str, fix: str = ""):
        super().__init__(message)
        self.message = message
        self.fix = fix


def _safe(item_id: str) -> str:
    if not isinstance(item_id, str) or not ID.match(item_id):
        raise WorkError("that is not an assignment id",
                        "open the assignment from the board and try again")
    return item_id


def folder(item_id: str, create: bool = False) -> Path:
    path = paths.work_dir() / _safe(item_id)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def sniff(data: bytes) -> tuple[str, str]:
    """(extension, media type) from the bytes themselves."""
    for magic, ext, media in MAGIC:
        if data.startswith(magic):
            if ext == "webp" and data[8:12] != b"WEBP":
                continue
            return ext, media
    if data[4:12] in (b"ftypheic", b"ftypheix", b"ftyphevc", b"ftypmif1"):
        raise WorkError(
            "that photo is in Apple's HEIC format, which the model cannot read",
            "the page normally converts it — try Choose file again, or open the "
            "photo in Preview and export it as JPEG")
    raise WorkError("that file is not a JPEG, PNG or WebP image",
                    "take a photo, or pick an image file")


def save(item_id: str, data: bytes) -> dict:
    """Store one page. Returns its row for the page's list."""
    if not data:
        raise WorkError("the upload was empty", "try taking the photo again")
    if len(data) > MAX_BYTES:
        raise WorkError(
            f"that image is {len(data) // (1024 * 1024)} MB and the limit is "
            f"{MAX_BYTES // (1024 * 1024)} MB",
            "the page shrinks photos before sending — if this came from "
            "somewhere else, export it smaller")
    ext, _media = sniff(data)
    home = folder(item_id, create=True)
    if len(pages(item_id)) >= MAX_PAGES:
        raise WorkError(f"there are already {MAX_PAGES} pages on this assignment",
                        "delete one first")
    stamp = time.strftime("%Y%m%d-%H%M%S")
    # A second page taken inside the same second must not overwrite the first.
    for n in range(0x1000):
        name = f"{stamp}-{n:04x}.{ext}"
        target = home / name
        if not target.exists():
            break
    else:                                                    # pragma: no cover
        raise WorkError("could not find a free name for that page", "")
    target.write_bytes(data)
    log.info("saved a page of work for %s (%d bytes)", item_id, len(data))
    return row(target)


def row(path: Path) -> dict:
    stat = path.stat()
    return {"name": path.name, "bytes": stat.st_size,
            "at": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(stat.st_mtime))}


def pages(item_id: str) -> list[dict]:
    home = folder(item_id)
    if not home.is_dir():
        return []
    return [row(p) for p in sorted(home.iterdir()) if NAME.match(p.name)]


def read(item_id: str, name: str) -> tuple[bytes, str]:
    """(bytes, media type). The name is matched against the pattern this
    module writes, so it can only ever name a file this module made."""
    if not NAME.match(name or ""):
        raise WorkError("no such page", "")
    path = folder(item_id) / name
    if not path.is_file():
        raise WorkError("no such page", "")
    data = path.read_bytes()
    return data, sniff(data)[1]


def delete(item_id: str, name: str) -> None:
    if not NAME.match(name or ""):
        raise WorkError("no such page", "")
    path = folder(item_id) / name
    if path.is_file():
        path.unlink()
        log.info("deleted a page of work for %s", item_id)


def clear(item_id: str) -> int:
    """Every page and the saved check. Used by the page's "remove all"."""
    home = folder(item_id)
    gone = 0
    if home.is_dir():
        for path in list(home.iterdir()):
            if NAME.match(path.name) or path.name == "check.json":
                path.unlink()
                gone += 1
    return gone


def check_path(item_id: str) -> Path:
    return folder(item_id) / "check.json"


def save_check(item_id: str, result: dict) -> None:
    folder(item_id, create=True)
    check_path(item_id).write_text(json.dumps(result, indent=2),
                                   encoding="utf-8")


def saved_check(item_id: str) -> dict | None:
    path = check_path(item_id)
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (ValueError, OSError):
        return None
