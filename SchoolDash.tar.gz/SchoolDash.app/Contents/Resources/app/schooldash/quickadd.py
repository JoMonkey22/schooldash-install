"""Turning a sentence into a task — no model needed.

Homework that never reaches Canvas or the teacher's doc is the homework a
teacher SAID: "read chapter 4 by Friday", "quiz on Tuesday", "bring the lab
notebook tomorrow". The chat used to hand those to the AI, which meant no AI,
no way to note them. This module reads the common shapes deterministically:

    "teacher said read ch 4 by friday"        -> title, due Friday
    "add bio quiz on the 12th"                -> title, course Biology, due the 12th
    "remember: spanish worksheet tomorrow"    -> title, course Spanish, due tomorrow
    "hw: problems 1-20 due next class"        -> title, due at the next meeting

Two rules from the rest of the app carry over. A date is never guessed: only a
phrase that actually names one produces a due date, and the note says how it
was read. And nothing is written here — the result is a PROPOSAL the person
confirms with a tap (chat.py's action path), exactly like the model's.
"""

import re
from datetime import date, timedelta

WEEKDAYS = {"monday": 0, "mon": 0, "tuesday": 1, "tue": 1, "tues": 1, "wednesday": 2,
            "wed": 2, "thursday": 3, "thu": 3, "thur": 3, "thurs": 3, "friday": 4,
            "fri": 4, "saturday": 5, "sat": 5, "sunday": 6, "sun": 6}
MONTHS = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6, "jul": 7,
          "aug": 8, "sep": 9, "sept": 9, "oct": 10, "nov": 11, "dec": 12}

# Something the person is telling us to remember, as opposed to asking.
LEAD_IN = re.compile(
    r"^\s*(?:(?:please\s+)?(?:add|remember|note|record|put down|write down|log)"
    r"(?:\s+(?:that|this|down))?\s*[:\-–]?\s*"
    r"|(?:my\s+)?(?:teacher|mr\.?|ms\.?|mrs\.?|dr\.?)\s*\w*\s*(?:said|says|told us|assigned|"
    r"gave us|wants|mentioned)\s*(?:that\s+)?(?:we\s+(?:have|need to|should)\s+)?[:\-–]?\s*"
    r"|(?:hw|homework|assignment|task|todo|to-do|reminder)\s*[:\-–]\s*"
    r"|(?:we|i)\s+(?:have|got|need to|should)\s+(?:a\s+|an\s+|to\s+)?"
    r"|new\s+(?:hw|homework|assignment)\s*[:\-–]?\s*)",
    re.I)

WHEN = re.compile(
    r"(?P<lead>\b(?:due|by|for|before|on|until|this|next|coming)\s+)?"
    r"(?P<when>"
    r"tomorrow|tonight|today|day after tomorrow|"
    r"(?:next|this)\s+(?:class|meeting|period|week|monday|tuesday|wednesday|thursday|friday|saturday|sunday)|"
    r"end of (?:the |this )?week|"
    r"in\s+(?:a|an|\d+)\s+(?:day|days|week|weeks)|"
    r"(?:mon|tue|tues|wed|thu|thur|thurs|fri|sat|sun)(?:day|sday|nesday|rsday|urday)?\b\.?|"
    r"\d{4}-\d{2}-\d{2}|"
    r"\d{1,2}/\d{1,2}(?:/\d{2,4})?|"
    r"(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s+\d{1,2}(?:st|nd|rd|th)?|"
    r"\d{1,2}(?:st|nd|rd|th)\s+(?:of\s+)?(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*|"
    r"the\s+\d{1,2}(?:st|nd|rd|th)"
    r")\b", re.I)

CATEGORY_WORDS = [
    ("test", re.compile(r"\b(test|exam|midterm|final)\b", re.I)),
    ("quiz", re.compile(r"\bquiz(?:zes)?\b", re.I)),
    ("project", re.compile(r"\bproject\b", re.I)),
    ("essay", re.compile(r"\b(essay|paper|composition)\b", re.I)),
    ("problem_set", re.compile(r"\b(problems?|problem set|worksheet|ws|exercises?|#\s?\d)\b", re.I)),
    ("reading", re.compile(r"\b(read|reading|chapter|ch\.?|pages?|pp\.?)\b", re.I)),
    ("discussion", re.compile(r"\b(discussion|post|reply)\b", re.I)),
]


def _school_year_date(month: int, day: int, today: date) -> date | None:
    """A month/day with no year lands in the school year that contains today:
    August–December in the year that started, January–July in the next."""
    for year in (today.year, today.year + 1, today.year - 1):
        try:
            candidate = date(year, month, day)
        except ValueError:
            continue
        # prefer the nearest date that is not far in the past
        if candidate >= today - timedelta(days=45):
            return candidate
    try:
        return date(today.year, month, day)
    except ValueError:
        return None


def parse_when(phrase: str, today: date, meetings=None, course: str | None = None
               ) -> tuple[str | None, str]:
    """(ISO date or None, note). `meetings` is a MeetingIndex for "next class"."""
    text = (phrase or "").strip().lower().rstrip(".")
    if not text:
        return None, "no date given"
    if text in ("today", "tonight"):
        return today.isoformat(), f"'{phrase}' = {today:%a %b %d}"
    if text == "tomorrow":
        when = today + timedelta(days=1)
        return when.isoformat(), f"'tomorrow' = {when:%a %b %d}"
    if text == "day after tomorrow":
        when = today + timedelta(days=2)
        return when.isoformat(), f"'{phrase}' = {when:%a %b %d}"
    if text in ("next class", "next meeting", "next period", "this class"):
        if meetings is not None and course:
            try:
                following = meetings.next_after(course, today)
            except Exception:  # noqa: BLE001
                following = None
            if following:
                return following.isoformat(), f"next {course} class = {following:%a %b %d}"
        return None, "'next class' — say which class so the date can be looked up"
    if text in ("end of week", "end of the week", "end of this week"):
        ahead = (4 - today.weekday()) % 7
        when = today + timedelta(days=ahead)
        return when.isoformat(), f"end of the week = {when:%a %b %d}"
    if text in ("next week", "this week"):
        return None, f"'{phrase}' is not a day — say which day"
    match = re.fullmatch(r"in\s+(a|an|\d+)\s+(day|days|week|weeks)", text)
    if match:
        count = 1 if match.group(1) in ("a", "an") else int(match.group(1))
        days = count * (7 if match.group(2).startswith("week") else 1)
        when = today + timedelta(days=days)
        return when.isoformat(), f"'{phrase}' = {when:%a %b %d}"
    match = re.fullmatch(r"(next|this)\s+([a-z]+)", text)
    if match and match.group(2) in WEEKDAYS:
        target = WEEKDAYS[match.group(2)]
        ahead = (target - today.weekday()) % 7 or 7
        when = today + timedelta(days=ahead)
        if match.group(1) == "next" and ahead < 7 and today.weekday() >= 4:
            pass  # "next Tuesday" said on a Friday means the coming one; keep
        return when.isoformat(), f"'{phrase}' = {when:%a %b %d}"
    word = re.sub(r"\.$", "", text)
    if word in WEEKDAYS:
        target = WEEKDAYS[word]
        ahead = (target - today.weekday()) % 7 or 7
        when = today + timedelta(days=ahead)
        return when.isoformat(), f"'{phrase}' = the coming {when:%A}, {when:%b %d}"
    match = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", text)
    if match:
        try:
            when = date(int(match.group(1)), int(match.group(2)), int(match.group(3)))
        except ValueError:
            return None, f"'{phrase}' is not a real date"
        return when.isoformat(), f"date given as {when:%a %b %d %Y}"
    match = re.fullmatch(r"(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?", text)
    if match:
        month, day = int(match.group(1)), int(match.group(2))
        if match.group(3):
            year = int(match.group(3))
            year += 2000 if year < 100 else 0
            try:
                when = date(year, month, day)
            except ValueError:
                return None, f"'{phrase}' is not a real date"
        else:
            when = _school_year_date(month, day, today)
            if when is None:
                return None, f"'{phrase}' is not a real date"
        return when.isoformat(), f"'{phrase}' = {when:%a %b %d %Y}"
    match = re.fullmatch(r"([a-z]+)\.?\s+(\d{1,2})(?:st|nd|rd|th)?", text)
    if match and match.group(1)[:3] in MONTHS and (
            match.group(1)[:4] in ("sept",) or match.group(1)[:3] in MONTHS):
        month = MONTHS.get(match.group(1)[:4], MONTHS.get(match.group(1)[:3]))
        when = _school_year_date(month, int(match.group(2)), today)
        if when is None:
            return None, f"'{phrase}' is not a real date"
        return when.isoformat(), f"'{phrase}' = {when:%a %b %d %Y}"
    match = re.fullmatch(r"(\d{1,2})(?:st|nd|rd|th)\s+(?:of\s+)?([a-z]+)", text)
    if match and match.group(2)[:3] in MONTHS:
        month = MONTHS.get(match.group(2)[:4], MONTHS.get(match.group(2)[:3]))
        when = _school_year_date(month, int(match.group(1)), today)
        if when is None:
            return None, f"'{phrase}' is not a real date"
        return when.isoformat(), f"'{phrase}' = {when:%a %b %d %Y}"
    match = re.fullmatch(r"the\s+(\d{1,2})(?:st|nd|rd|th)", text)
    if match:
        day = int(match.group(1))
        month, year = today.month, today.year
        if day < today.day:
            month = month % 12 + 1
            year += 1 if month == 1 else 0
        try:
            when = date(year, month, day)
        except ValueError:
            return None, f"'{phrase}' is not a real date"
        return when.isoformat(), f"'{phrase}' = the next {day}th, {when:%a %b %d}"
    return None, f"could not read '{phrase}' as a date"


def _short(name: str) -> str:
    return (name or "").split("-")[0].replace("Advanced Placement", "AP").strip()


COURSE_ALIASES = {
    "bio": "biology", "chem": "chemistry", "phys": "physics", "alg": "algebra",
    "geo": "geometry", "calc": "calculus", "eng": "english", "lit": "literature",
    "hist": "history", "gov": "government", "econ": "economics", "span": "spanish",
    "psych": "psychology", "comp sci": "computer science", "cs": "computer science",
    "apush": "united states history", "scrip": "scripture", "theo": "theology",
    "rel": "religion", "pe": "physical education", "s&c": "strength and conditioning",
}


def match_course(text: str, state: dict) -> tuple[str | None, str | None]:
    """(display name, course_key) of the one course the text names, or Nones.
    Two matches is ambiguous and gets no course rather than a coin-flip."""
    lowered = f" {(text or '').lower()} "
    for alias, full in COURSE_ALIASES.items():
        lowered = re.sub(rf"\b{re.escape(alias)}\b", full, lowered)
    words = set(re.findall(r"[a-z&]+", lowered))
    names: dict[str, str] = {}
    for profile in state.get("profiles") or []:
        display = profile.get("display_name") or profile.get("course_raw") or ""
        if profile.get("course_key") and display:
            names[profile["course_key"]] = display
    for item in state.get("items") or []:
        if item.get("course_key") and item.get("course") and item["course_key"] not in names:
            names[item["course_key"]] = _short(item["course"])
    hits = []
    for key, display in names.items():
        tokens = {w for w in re.findall(r"[a-z&]+", display.lower())
                  if len(w) > 2 and w not in ("honors", "advanced", "placement", "and", "the",
                                              "period", "training", "essentials")}
        if tokens and tokens & words:
            hits.append((len(tokens & words), key, display))
    if not hits:
        return None, None
    hits.sort(reverse=True)
    if len(hits) > 1 and hits[0][0] == hits[1][0]:
        return None, None
    return _short(hits[0][2]), hits[0][1]


def category_of(title: str) -> str | None:
    for name, pattern in CATEGORY_WORDS:
        if pattern.search(title or ""):
            return name
    return None


def parse(message: str, state: dict, today: date, meetings=None) -> dict | None:
    """A task proposal from a sentence, or None when the sentence is not one.

    Returns {"title", "due_date", "date_note", "course", "course_key",
    "category", "when_phrase"}. Only fires on a lead-in ("add…", "teacher
    said…", "hw:…") so ordinary questions are never mistaken for tasks.
    """
    text = (message or "").strip()
    lead = LEAD_IN.match(text)
    if not lead:
        return None
    body = text[lead.end():].strip().strip('"\'')
    if len(body) < 3 or body.endswith("?"):
        return None

    course, course_key = match_course(body, state)
    due_date, note, when_phrase = None, "no date given", None
    # take the LAST date phrase — "read ch 4 (assigned today) by friday"
    matches = list(WHEN.finditer(body))
    if matches:
        match = matches[-1]
        when_phrase = match.group("when")
        due_date, note = parse_when(when_phrase, today, meetings, course)
        if due_date or "could not read" not in note:
            body = (body[:match.start()] + body[match.end():]).strip()
    title = re.sub(r"\s+", " ", body).strip(" ,.;:-–")
    # drop the course's own name from the title when it was recognised —
    # "bio quiz" is a quiz filed under Biology, not a quiz called "bio quiz"
    if course:
        course_words = {w.lower() for w in re.findall(r"[A-Za-z&]+", course)
                        if len(w) > 2 and w.lower() not in ("honors", "advanced", "placement")}
        aliases = {alias for alias, full in COURSE_ALIASES.items()
                   if set(full.split()) & course_words}
        pattern = r"\b(?:for|in)?\s*(?:" + "|".join(
            re.escape(w) for w in sorted(course_words | aliases, key=len, reverse=True)) \
            + r")\b\s*[:\-–]?\s*"
        stripped = re.sub(pattern, " ", title, flags=re.I)
        stripped = re.sub(r"\s+", " ", stripped).strip(" ,.;:-–")
        title = stripped or title
    if not title:
        return None
    title = title[0].upper() + title[1:]
    return {"title": title[:110], "due_date": due_date, "date_note": note,
            "course": course, "course_key": course_key,
            "category": category_of(title), "when_phrase": when_phrase}
