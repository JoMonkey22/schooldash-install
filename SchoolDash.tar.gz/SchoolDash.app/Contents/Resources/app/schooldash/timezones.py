"""The only timezone code in the project.

Canvas emits UTC; an 11:59 pm Phoenix deadline arrives stamped 06:59Z the
next day. Every timestamp converts to the local zone before any date-level
decision. Arizona does not observe DST, but the zone is never hardcoded as
an offset — always ZoneInfo("America/Phoenix").
"""

from datetime import date, datetime
from zoneinfo import ZoneInfo

DEFAULT_ZONE_NAME = "America/Phoenix"

_cache: dict[str, ZoneInfo] = {}


def zone(name: str | None = None) -> ZoneInfo:
    name = name or _configured_zone_name()
    if name not in _cache:
        _cache[name] = ZoneInfo(name)
    return _cache[name]


def _configured_zone_name() -> str:
    try:
        from schooldash import config
        return config.load().get("school", {}).get("time_zone") or DEFAULT_ZONE_NAME
    except Exception:
        return DEFAULT_ZONE_NAME


def to_local(dt_or_str, tz: ZoneInfo | None = None) -> datetime:
    """Any datetime or ISO string -> tz-aware datetime in the local zone.

    A naive datetime is assumed to already be local (doc items are built
    locally); anything carrying an offset (including Z) is converted.
    """
    tz = tz or zone()
    value = dt_or_str
    if isinstance(value, str):
        value = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if not isinstance(value, datetime):
        raise TypeError(f"to_local() wants a datetime or ISO string, got {type(value)!r}")
    if value.tzinfo is None:
        return value.replace(tzinfo=tz)
    return value.astimezone(tz)


def local_date(dt_or_str, tz: ZoneInfo | None = None) -> date:
    """The calendar day something actually falls on, locally.

    Never call .date() on a UTC datetime — that is the bug this exists to
    prevent: 2026-08-14T06:59:00Z is August 13 in Phoenix.
    """
    return to_local(dt_or_str, tz).date()
