"""OllamaProvider — the fully-local, fully-offline option.

The same JSON Schema handed to Claude Code goes into Ollama's `format` field —
that symmetry is why profiling/schema.py is the single source of truth. Per
Ollama's own guidance the schema is ALSO pasted into the prompt text, and
temperature is 0. (Ollama Cloud does not support structured outputs; this is
the local server only.) Accuracy is measured by tests/online/, never assumed.
"""

import json

import httpx

from schooldash import config
from schooldash.ai.base import ProviderError
from schooldash.logging_setup import get

log = get("ai.ollama")


class OllamaProvider:
    name = "ollama"

    def __init__(self):
        cfg = config.load()["ai"]
        self.host = cfg["ollama_host"].rstrip("/")
        self.model = cfg["ollama_model"]   # a config value, never a constant

    def available(self) -> tuple[bool, str]:
        try:
            response = httpx.get(f"{self.host}/api/tags", timeout=3)
            response.raise_for_status()
        except httpx.HTTPError:
            return False, f"no Ollama server answering at {self.host}"
        models = [m.get("name", "") for m in response.json().get("models", [])]
        if not any(m.startswith(self.model) for m in models):
            return False, (f"Ollama is running but model {self.model!r} is not "
                           f"pulled (have: {', '.join(models) or 'none'})")
        return True, f"Ollama {self.model} at {self.host}"

    def _chat(self, messages: list[dict], schema: dict | None,
              timeout: int) -> str:
        payload = {"model": self.model, "messages": messages, "stream": False,
                   "options": {"temperature": 0}}
        if schema:
            payload["format"] = schema
        try:
            response = httpx.post(f"{self.host}/api/chat", json=payload,
                                  timeout=timeout)
            response.raise_for_status()
        except httpx.HTTPError as exc:
            raise ProviderError(f"Ollama request failed: {exc}") from exc
        return (response.json().get("message") or {}).get("content") or ""

    def complete_vision(self, *, system: str, user: str,
                        images=(), max_tokens: int = 1500,
                        timeout: int = 180) -> str:
        """Refused here, in one sentence, rather than downstream where it
        would read as a network fault. See base.Provider.complete_vision."""
        raise ProviderError(
            "the local model set in Settings cannot look at pictures")

    def complete(self, *, system: str, user: str, max_tokens: int = 1024,
                 timeout: int = 120) -> str:
        messages = ([{"role": "system", "content": system}] if system else []) \
            + [{"role": "user", "content": user}]
        return self._chat(messages, None, timeout)

    def complete_structured(self, *, system: str, user: str, schema: dict,
                            timeout: int = 240) -> dict:
        prompted = (f"{user}\n\nAnswer ONLY with JSON matching this schema:\n"
                    f"{json.dumps(schema)}")
        messages = ([{"role": "system", "content": system}] if system else []) \
            + [{"role": "user", "content": prompted}]
        text = self._chat(messages, schema, timeout)
        try:
            data = json.loads(text)
        except ValueError as exc:
            raise ProviderError(f"Ollama emitted non-JSON: {text[:200]!r}") from exc
        if not isinstance(data, dict):
            raise ProviderError("Ollama emitted JSON that is not an object")
        return data

    def stream(self, *, system: str, user: str, session_id: str | None = None):
        payload = {"model": self.model, "stream": True,
                   "options": {"temperature": 0},
                   "messages": ([{"role": "system", "content": system}]
                                if system else [])
                   + [{"role": "user", "content": user}]}
        full = []
        try:
            with httpx.stream("POST", f"{self.host}/api/chat", json=payload,
                              timeout=180) as response:
                for line in response.iter_lines():
                    if not line:
                        continue
                    try:
                        event = json.loads(line)
                    except ValueError:
                        continue
                    chunk = (event.get("message") or {}).get("content") or ""
                    if chunk:
                        full.append(chunk)
                        yield {"type": "text", "text": chunk}
        except httpx.HTTPError as exc:
            raise ProviderError(f"Ollama stream failed: {exc}") from exc
        yield {"type": "result", "text": "".join(full), "session_id": None}
