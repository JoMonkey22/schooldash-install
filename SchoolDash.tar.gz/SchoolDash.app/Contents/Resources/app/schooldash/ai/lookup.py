"""Answers computed from the data, with no model involved.

Why this exists. Chat needed Claude Code installed on the student's own Mac.
Everything else in SchoolDash works without it, so a classmate who paid arrived
at one dead box — and for a paid product a dead box reads as "this is broken",
whatever the rest of the page does.

The realisation that fixes it: the questions people actually ask are lookups,
not reasoning. "What's due tomorrow", "what's overdue", "what room is physics
in", "how many things are due Friday" — every one of those is a query over
`state`. [MEASURED] 2026-08-31, the model scored 7/10 on exactly this set and
its failures were *omissions*: asked what was due today it named five fewer
items than existed. A lookup cannot omit, cannot invent, and costs nothing.

So this is not a fallback that apologises for the missing model. For the
questions it recognises it is the better answer, and it runs first.

What it deliberately does NOT do: anything needing judgement. "Summarise my
week", "what should I not forget", "explain what my teacher meant" — those get
`None`, and the caller either asks a model or says plainly that this one needs
one. Guessing at an open question is how a lookup starts inventing.

Every item is cited by id, so grounding verifies these answers like any other.
"""

import re
from datetime import date, timedelta

from schooldash import timezones

WEEKDAYS = {"monday": 0, "tuesday": 1, "wednesday": 2, "thursday": 3,
            "friday": 4, "saturday": 5, "sunday": 6}

# Asking for work to be done, an opinion, or an explanation. Any of these and
# this module declines, whatever else the sentence contains.
# The exceptions: phrasings that contain a judgement word but are answered
# exactly by the app's own ranking. "What should I do first" is the question the
# focus card already answers deterministically, so declining it would be absurd.
ALWAYS_LOOKUP = re.compile(
    r"what should i (do|start|work on|tackle|study|revise)\b"
    r"|what do i (do|start) first\b"
    r"|which .*(should i|do i) do first\b"
    r"|should i (study|revise)\b")

NEEDS_JUDGEMENT = re.compile(
    r"\b(write|draft|rewrite|edit|explain|summari[sz]e|summary|help me|"
    r"should i|should we|why|how do i|teach me|check my|proofread|"
    r"improve|rephrase|translate|solve|answer this|do my|opinion|advice|"
    r"recommend|plan my|prioriti[sz]e)\b")


def _today(state: dict) -> date:
    stated = state.get("today")
    if stated:
        try:
            return date.fromisoformat(stated)
        except ValueError:
            pass
    from datetime import datetime
    return datetime.now(timezones.zone()).date()


def _open_items(state: dict) -> list[dict]:
    return [i for i in state.get("items") or [] if not i.get("done")]


def _short(name: str) -> str:
    return (name or "").split("-")[0].replace("Advanced Placement", "AP").strip()


def _due_label(item: dict) -> str:
    iso = item.get("due_date")
    if not iso:
        return "no date yet"
    try:
        when = date.fromisoformat(iso)
    except ValueError:
        return iso
    return when.strftime("%a %d %b")


def _line(item: dict) -> str:
    """One item, cited. The id is what lets grounding check this answer."""
    bits = [_short(item.get("course") or "")]
    if item.get("est_label"):
        bits.append(str(item["est_label"]))
    return (f"• {item.get('title', '(untitled)')} [{item.get('item_id', '')}]"
            f" — {_due_label(item)}" + (f", {', '.join(b for b in bits if b)}"
                                        if any(bits) else ""))


def _listing(items: list[dict], limit: int = 12) -> str:
    """Items, newest deadline first, with an honest note if trimmed.

    Nothing is hidden silently: if the list is cut, it says by how much, because
    "here are 12" reading as "there are 12" is the failure this whole app is
    built to avoid.
    """
    ordered = sorted(items, key=lambda i: (i.get("due_date") or "9999-99-99",
                                           -(i.get("score") or 0)))
    shown = ordered[:limit]
    text = "\n".join(_line(i) for i in shown)
    if len(ordered) > len(shown):
        text += f"\n…and {len(ordered) - len(shown)} more."
    return text


def _count(n: int, thing: str = "thing") -> str:
    """"3 classs" is the kind of detail that makes a paid app feel unfinished."""
    irregular = {"quiz": "quizzes", "class": "classes"}
    if n == 1:
        return f"1 {thing}"
    if thing in irregular:
        return f"{n} {irregular[thing]}"
    if thing.endswith(("s", "x", "z", "ch", "sh")):
        return f"{n} {thing}es"
    return f"{n} {thing}s"


# ---------------------------------------------------------------------------
# the handlers


def _by_date(state: dict, wanted: set[str], label: str) -> str:
    items = [i for i in _open_items(state) if i.get("due_date") in wanted]
    if not items:
        return f"Nothing is due {label}."
    return f"{_count(len(items))} due {label}:\n{_listing(items)}"


def _overdue(state: dict) -> str:
    today = _today(state).isoformat()
    items = [i for i in _open_items(state)
             if i.get("due_date") and i["due_date"] < today]
    if not items:
        return "Nothing is overdue — you are caught up."
    return (f"{_count(len(items))} overdue, oldest first:\n{_listing(items)}")


def _stale_caveat(state: dict) -> str:
    """Appended to every answer built from the timetable when the timetable was
    kept from an earlier refresh (COUNT 26).

    One function rather than a sentence written into each answer: the previous
    prosecution's worst finding was one fact worded four ways on four surfaces,
    three of them fixed. A room read yesterday is right nearly always, and
    "nearly always" is precisely what this app may not state as certain — he
    would walk to that room on the strength of it.
    """
    stale = state.get("schedule_stale") or {}
    if not stale:
        return ""
    return (f"\n\n(This is the timetable from {_read_day(stale.get('as_of'))} — "
            "I could not read the class feed on the last refresh, so check it "
            "if something looks off.)")


def _schedule_today(state: dict) -> str:
    meetings = state.get("meetings_today") or []
    if not meetings:
        if state.get("schedule_stale"):
            return ("I could not read the class-schedule feed on the last "
                    "refresh, so I do not know today's classes. Press Refresh "
                    "on the page to try again.")
        return "No classes on the schedule for today."
    lines = []
    for meeting in meetings:
        start = (meeting.get("start") or "")[11:16]
        end = (meeting.get("end") or "")[11:16]
        room = meeting.get("room") or ""
        lines.append(f"• {start}–{end}  {_short(meeting.get('course_raw') or '')}"
                     + (f"  in {room}" if room else ""))
    return (f"{_count(len(meetings), 'class')} today:\n" + "\n".join(lines)
            + _stale_caveat(state))


def _room_for(state: dict, question: str) -> str | None:
    """Only answers when exactly one course in the schedule matches the words
    asked about. Two matches is ambiguous and gets no answer rather than a
    coin-flip."""
    words = {w for w in re.findall(r"[a-z]+", question.lower()) if len(w) > 2}
    hits = []
    for meeting in state.get("meetings_today") or []:
        name = meeting.get("course_raw") or ""
        tokens = {w for w in re.findall(r"[a-z]+", name.lower()) if len(w) > 2}
        if tokens & words:
            hits.append(meeting)
    if len(hits) != 1:
        return None
    meeting = hits[0]
    room = meeting.get("room")
    start = (meeting.get("start") or "")[11:16]
    if not room:
        return (f"{_short(meeting.get('course_raw') or '')} is at {start} today, "
                "but the feed does not give a room for it."
                + _stale_caveat(state))
    return (f"{_short(meeting.get('course_raw') or '')} is in {room} today, "
            f"at {start}." + _stale_caveat(state))


def _next_class(state: dict) -> str:
    now = (state.get("now") or "")[11:16]
    upcoming = [m for m in state.get("meetings_today") or []
                if (m.get("start") or "")[11:16] > now]
    if not upcoming:
        return "No more classes today."
    nxt = upcoming[0]
    room = nxt.get("room")
    return (f"Next is {_short(nxt.get('course_raw') or '')} at "
            f"{(nxt.get('start') or '')[11:16]}"
            + (f" in {room}." if room else ".")
            + _stale_caveat(state))


# How many days before a quiz or test someone should already be revising. A
# quiz is not work you hand in, it is work you must have done beforehand, and
# nothing in the app said so.
STUDY_LEAD = {"test": 3, "quiz": 2, "project": 3, "essay": 2}


def _study_hint(item: dict, today: date) -> str | None:
    """A hint attached to a real item — never a new one. Inventing a "study for
    X" task would be inventing an assignment, which this app must not do."""
    lead = STUDY_LEAD.get(item.get("category"))
    if not lead or item.get("done") or not item.get("due_date"):
        return None
    try:
        days = (date.fromisoformat(item["due_date"]) - today).days
    except ValueError:
        return None
    if days < 0 or days > lead:
        return None
    what = item.get("category")
    if days == 0:
        return f"{what} is TODAY"
    if days == 1:
        return f"{what} tomorrow — study tonight"
    return f"{what} in {days} days — start studying"


def _study_lines(state: dict) -> list[str]:
    today = _today(state)
    out = []
    for item in _open_items(state):
        hint = _study_hint(item, today)
        if hint:
            out.append(f"• {item.get('title', '')} [{item.get('item_id', '')}]"
                       f" — {_short(item.get('course') or '')}: {hint}")
    return out


def _study(state: dict) -> str:
    lines = _study_lines(state)
    if not lines:
        return ("Nothing to revise for in the next few days — no quizzes, tests "
                "or projects that close.")
    return ("Worth studying for now:\n" + "\n".join(lines)
            + "\n\n(These are not things you hand in — they are things to have "
              "done before the day.)")


def _tests_ahead(state: dict) -> str:
    today = _today(state).isoformat()
    items = [i for i in _open_items(state)
             if i.get("category") in ("test", "quiz", "project", "essay")
             and (not i.get("due_date") or i["due_date"] >= today)]
    if not items:
        return "No tests, quizzes or projects on the list right now."
    return f"{_count(len(items))} coming up:\n{_listing(items)}"


def _first_tonight(state: dict) -> str:
    """The app's own ranking, not a second opinion invented here."""
    items = _open_items(state)
    if not items:
        return "Nothing open — you are done."
    best = max(items, key=lambda i: i.get("score") or 0)
    rest = len(items) - 1
    text = f"Start with this:\n{_line(best)}"
    if best.get("date_note"):
        text += f"\n({best['date_note']})"
    # A looming quiz outranks a to-do list, so say it here rather than making
    # someone ask a second question to find out.
    studying = _study_lines(state)
    if studying:
        text += "\n\nAnd study for:\n" + "\n".join(studying)
    if rest:
        text += f"\nThen there are {_count(rest, 'other thing')} open."
    return text


def _undated(state: dict) -> str:
    items = [i for i in _open_items(state) if not i.get("due_date")]
    if not items:
        return "Everything open has a date on it."
    return (f"{_count(len(items))} with no date — worth checking with the "
            f"teacher:\n{_listing(items)}")


def _by_class(state: dict) -> str:
    """How much open work each class has, most first.

    [MEASURED] run.py eval-chat --live, 2026-09-02: asked "which class has the
    most work right now?" the model grouped the items by course and the dates
    drifted off their ids — three grounding failures in one answer. It is a
    counting question over data already on this Mac, and a lookup cannot omit
    or invent.
    """
    open_items = _open_items(state)
    if not open_items:
        return "Nothing open in any class — you are clear."
    by_course: dict = {}
    for item in open_items:
        key = _short(item.get("course") or "unknown")
        by_course.setdefault(key, []).append(item)
    ordered = sorted(by_course.items(),
                     key=lambda pair: (-len(pair[1]),
                                       min(i.get("due_date") or "9999-99-99"
                                           for i in pair[1])))
    today = _today(state).isoformat()
    lines = []
    for course, items in ordered:
        dated = [i.get("due_date") for i in items if i.get("due_date")]
        # "next" has to mean next. A date already gone is not next, and calling
        # it that is how a board starts reading as noise.
        ahead = sorted(d for d in dated if d >= today)
        soonest = ahead[0] if ahead else (min(dated) if dated else None)
        nearest = next((i for i in items if i.get("due_date") == soonest), items[0])
        if not soonest:
            when = ", none dated"
        elif ahead:
            when = f", next {_due_label(nearest)}"
        else:
            when = f", earliest was {_due_label(nearest)}"
        lines.append(f"• {course}: {_count(len(items), 'thing')}{when} — "
                     f"{nearest.get('title', '')[:60]} "
                     f"[{nearest.get('item_id', '')}]")
    leader, most = ordered[0]
    headline = (f"{leader} has the most right now ({_count(len(most))})."
                if len(ordered) > 1 and len(most) > len(ordered[1][1])
                else "It is close between them.")
    return f"{headline}\n" + "\n".join(lines)


def _grades(state: dict) -> str:
    """The grades, and honestly how old they are.

    [MEASURED] 2026-09-02 (COUNT 23): when the portal could not be read, the
    Grades panel labelled the numbers "from Tue, Sep 1" while this answer still
    opened "From Veracross" — the same fact, two surfaces, one of them stating
    as current what it could not know. A grade is the last thing this app may
    be loose about.
    """
    grades = [g for g in state.get("grades") or [] if g.get("graded")]
    stale = state.get("grades_stale") or {}
    if not grades:
        # A read that failed is not the same as a term with no marks in it.
        tried = any(str(w).startswith("grades:")
                    for w in (state.get("warnings") or []))
        if tried or stale:
            return ("I could not read your grades on the last refresh — the "
                    "Veracross portal did not load. Press Refresh on the page "
                    "to try again.")
        return ("No grades have been read yet. They come from Veracross — open "
                "the Grades box on the page.")
    lines = [f"• {_short(g.get('display_name') or '')}: {g.get('letter')}"
             + (f" ({g['percent']:.2f}%)" if g.get("percent") is not None else "")
             for g in grades]
    if stale:
        when = _read_day(stale.get("as_of"))
        return (f"These are from {when} — I could not read the Veracross "
                "portal on the last refresh, so they may have changed since:\n"
                + "\n".join(lines))
    return ("From Veracross (click any of them on the page to open it there):\n"
            + "\n".join(lines))


def _read_day(stamp: str | None) -> str:
    """"Tue 01 Sep" out of a state timestamp, or a phrase that admits it does
    not know. Never a bare ISO string in a sentence a student reads."""
    if not stamp:
        return "an earlier refresh"
    try:
        return date.fromisoformat(str(stamp)[:10]).strftime("%a %d %b")
    except ValueError:
        return "an earlier refresh"


# ---------------------------------------------------------------------------
# routing


def _weekday_dates(state: dict, weekday: int) -> set[str]:
    """Both readings of "Friday" when today IS Friday, because both are
    reasonable and picking one silently would be wrong half the time."""
    base = _today(state)
    ahead = (weekday - base.weekday()) % 7
    days = {base + timedelta(days=ahead or 7)}
    if ahead == 0:
        days.add(base)
    return {d.isoformat() for d in days}


def answer(question: str, state: dict) -> str | None:
    """A cited answer, or None when this needs judgement rather than a lookup."""
    q = (question or "").lower().strip()
    if not q:
        return None

    # Judgement first, before any keyword match. Without this, "write my essay
    # intro" matched the word "essay" and answered with a list of upcoming
    # tests — a confident non-answer, which is worse than no answer and exactly
    # what this module's docstring promises not to do. A request to *do*
    # something is never a lookup, however many nouns it shares with one.
    if NEEDS_JUDGEMENT.search(q) and not ALWAYS_LOOKUP.search(q):
        return None

    today = _today(state)

    # order matters: "due tomorrow" must not be caught by the "due today" test
    if re.search(r"\b(overdue|late|behind|missing)\b", q):
        return _overdue(state)
    if re.search(r"\bgrade|gpa|how am i doing\b", q):
        return _grades(state)
    if re.search(r"\bwhat room|which room|where is\b", q):
        return _room_for(state, q)
    if re.search(r"\bnext class|next period\b", q):
        return _next_class(state)
    if re.search(r"\b(classes|schedule|periods)\b.*\btoday\b|\btoday\b.*\bschedule\b", q):
        return _schedule_today(state)
    if re.search(r"\bstudy|studying|revise|revising|cram\b", q):
        return _study(state)
    if re.search(r"\btest|quiz|exam|project|essay\b", q):
        return _tests_ahead(state)
    if re.search(r"\bundated|no date|without a date\b", q):
        return _undated(state)
    # Counting per class, before the generic "test|quiz" and date branches:
    # "which class has the most work" mentions no date and is not about one
    # class, so nothing below would answer it.
    if re.search(r"\b(which|what) class\b.*\b(most|least)\b"
                 r"|\bmost (work|homework|assignments)\b"
                 r"|\bwork(load)?\b.*\b(per|by|in each|for each) class\b"
                 r"|\b(per|by|each) class\b.*\bwork\b"
                 r"|\bworkload\b", q):
        return _by_class(state)
    if re.search(r"\bfirst\b.*\b(tonight|now|today)\b|what should i (do|start)", q):
        return _first_tonight(state)

    if re.search(r"\btomorrow\b", q):
        return _by_date(state, {(today + timedelta(days=1)).isoformat()}, "tomorrow")
    if re.search(r"\bdue (today|now)\b|\btoday\b", q):
        return _by_date(state, {today.isoformat()}, "today")
    for name, weekday in WEEKDAYS.items():
        if name in q:
            return _by_date(state, _weekday_dates(state, weekday),
                            name.capitalize())
    match = re.search(r"next (\d+) days?", q)
    if match:
        span = min(int(match.group(1)), 30)
        wanted = {(today + timedelta(days=n)).isoformat() for n in range(span + 1)}
        return _by_date(state, wanted, f"in the next {span} days")
    if re.search(r"\bthis week\b", q):
        wanted = {(today + timedelta(days=n)).isoformat()
                  for n in range(7 - today.weekday())}
        return _by_date(state, wanted, "this week")

    return None


CAN_ANSWER = [
    "what's due today",
    "what's due tomorrow",
    "what's overdue",
    "what's due Friday",
    "what's due in the next 3 days",
    "what should I do first",
    "what classes do I have today",
    "what room is biology in",
    "when's my next class",
    "any tests coming up",
    "what's undated",
    "what are my grades",
    "what should I study for",
    "which class has the most work",
]
