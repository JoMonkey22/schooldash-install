"""The Provider protocol every AI backend implements (spec §12.1)."""

from typing import Iterator, Protocol


class ProviderError(RuntimeError):
    pass


class Provider(Protocol):
    name: str

    def available(self) -> tuple[bool, str]:
        """(usable right now?, human-readable reason)."""
        ...

    def complete(self, *, system: str, user: str, max_tokens: int = 1024,
                 timeout: int = 120) -> str:
        ...

    def complete_structured(self, *, system: str, user: str, schema: dict,
                            timeout: int = 180) -> dict:
        ...

    def complete_vision(self, *, system: str, user: str,
                        images: list[tuple[str, bytes]],
                        max_tokens: int = 1500, timeout: int = 180) -> str:
        """Answer about pictures. `images` is [(media_type, raw bytes)].

        A separate method rather than an argument on `complete` because two of
        the four providers cannot do it at all and must say so in a sentence,
        not fail somewhere downstream looking like a network problem.
        """
        ...

    def stream(self, *, system: str, user: str,
               session_id: str | None = None) -> Iterator[dict]:
        """Yields {"type": "text", "text": ...} chunks, then one
        {"type": "result", "text": full, "session_id": ...}."""
        ...
