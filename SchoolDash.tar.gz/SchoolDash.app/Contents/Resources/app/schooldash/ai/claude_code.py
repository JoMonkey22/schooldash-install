"""ClaudeCodeProvider — the free default, on the user's own Claude subscription.

Verified facts this is built against (spec §12.2):
- --json-schema requires --output-format json; the validated object arrives in
  the envelope's structured_output. The `format` keyword is accepted but NOT
  enforced — dates are validated by our own code, never by the schema.
- A -p invocation starts in Manual permission mode and can block forever
  waiting for an approval; ALWAYS pass --permission-mode dontAsk. With
  --disallowedTools "*" there is nothing to approve anyway — belt and braces,
  and it is also the recursion guard (a headless call has no tools).
- Do NOT use --bare: it never reads OAuth credentials and would require
  ANTHROPIC_API_KEY, which violates the free constraint. If a key ever
  appears, --bare becomes the fast path behind a config flag.
- Exit 0 on success — but a failure inside the run is printed as the result on
  stdout, so both the exit code and the payload are checked.
- The command is NEVER built as a shell string: list + shell=False. Prompts
  carry document content and user text.
- On Windows the npm `claude` shim is a .cmd; modern Python refuses .cmd argv
  containing quotes (CVE-2024-24576), so the underlying native claude.exe is
  resolved and called directly.
"""

import base64
import json
import os
import shutil
import subprocess
from pathlib import Path

from schooldash import config
from schooldash.ai import jsonshape
from schooldash.ai.base import ProviderError
from schooldash.logging_setup import get

log = get("ai.claude")


def _resolve_executable() -> str | None:
    found = shutil.which("claude")
    if not found:
        return None
    path = Path(found)
    if path.suffix.lower() in (".cmd", ".bat"):
        native = (path.parent / "node_modules" / "@anthropic-ai" / "claude-code"
                  / "bin" / "claude.exe")
        if native.exists():
            return str(native)
        # the shim itself cannot safely receive quoted JSON argv on Windows
        log.warning("claude resolves to a .cmd shim and no native exe was "
                    "found beside it; structured calls may fail")
    return str(path)


class ClaudeCodeProvider:
    name = "claude_code"

    def __init__(self):
        self.executable = _resolve_executable()
        self.model = config.load()["ai"]["claude_model"]  # an alias, never a pinned ID

    def available(self) -> tuple[bool, str]:
        if not self.executable:
            return False, "the `claude` CLI is not on PATH"
        return True, f"claude CLI at {self.executable}"

    def _base_args(self, allow_structured: bool = False) -> list[str]:
        args = [self.executable, "-p",
                "--permission-mode", "dontAsk",
                "--model", self.model]
        if allow_structured:
            # structured output arrives via an internal StructuredOutput tool,
            # which a blanket "*" disallow would block — allow exactly it;
            # everything else is still auto-denied under dontAsk
            # An enumerated denial, which is the weaker discipline — and it is
            # on the path that carries teacher-document text, so it is the one
            # that matters. It stays enumerated because the alternatives were
            # measured and are worse:
            #   --disallowedTools "*"  kills structured output outright
            #                          (structured_output comes back null, with
            #                          is_error False, so it fails silently)
            #   --allowedTools alone   is an auto-approve list, not an
            #                          exclusive allowlist
            #   asking for JSON in the prompt instead: 2 of 3 replies used the
            #                          wrong key, so the schema is load-bearing
            # What removes the trust placed in this list is not the list: it is
            # that the reply is now validated against the schema on the way back
            # (see below), and that untrusted document text is fenced before it
            # ever reaches a model call (profiling/builder.fence).
            # MCP tools and Skill are named explicitly because they are the two
            # families that grow without this file changing.
            args += ["--allowedTools", "StructuredOutput",
                     "--disallowedTools",
                     "Bash,Read,Write,Edit,MultiEdit,Glob,Grep,LS,"
                     "WebFetch,WebSearch,Agent,Task,NotebookEdit,NotebookRead,"
                     "Skill,SlashCommand,KillShell,BashOutput,TodoWrite,"
                     "mcp__*,Artifact,Workflow"]
        else:
            args += ["--disallowedTools", "*"]
        return args

    def _run(self, args: list[str], prompt: str, timeout: int) -> str:
        if not self.executable:
            raise ProviderError("claude CLI is not installed")
        if os.environ.get("CLAUDECODE"):
            log.info("nested inside a Claude Code session (CLAUDECODE=1) — "
                     "the headless call has no tools, which is the guard")
        env = dict(os.environ)
        try:
            result = subprocess.run(
                args, input=prompt, capture_output=True, text=True,
                encoding="utf-8", timeout=timeout, shell=False, env=env)
        except subprocess.TimeoutExpired as exc:
            raise ProviderError(f"claude timed out after {timeout}s") from exc
        except OSError as exc:
            raise ProviderError(f"could not run claude: {exc}") from exc
        if result.returncode != 0:
            snippet = (result.stdout or result.stderr or "")[:400]
            raise ProviderError(f"claude exited {result.returncode}: {snippet}")
        return result.stdout

    def complete(self, *, system: str, user: str, max_tokens: int = 1024,
                 timeout: int = 120) -> str:
        args = self._base_args() + ["--output-format", "json"]
        if system:
            args += ["--system-prompt", system]
        stdout = self._run(args, user, timeout)
        envelope = _parse_envelope(stdout)
        return envelope.get("result") or ""

    def complete_vision(self, *, system: str, user: str,
                        images: list[tuple[str, bytes]],
                        max_tokens: int = 1500, timeout: int = 180) -> str:
        """A question about pictures, headless, with no tools.

        [MEASURED] 2026-09-10 against claude 2.1.246, on a sheet of five
        algebra answers with one wrong: it named the wrong one and no others.

        Facts this is built against, all three found by running it:

        - Images cannot go in a text prompt. They ride in as content blocks,
          which needs `--input-format stream-json`.
        - `--input-format stream-json` REQUIRES `--output-format stream-json`,
          which in turn REQUIRES `--verbose`. So the reply arrives as NDJSON
          and the answer is the last line's `result`.
        - **Therefore vision and `--json-schema` are mutually exclusive**:
          the schema flag requires `--output-format json`. That is why the
          checker asks for a line format in the prompt and parses it, instead
          of asking for structured output like everything else here does.

        It runs under `--disallowedTools "*"` like the rest: the image is sent
        in the message, so the model never needs Read, and the no-tools
        recursion guard stays exactly as strict as it is everywhere else.
        """
        if not images:
            raise ProviderError("no pictures were given to look at")
        content: list[dict] = [
            {"type": "image",
             "source": {"type": "base64", "media_type": media,
                        "data": base64.b64encode(raw).decode("ascii")}}
            for media, raw in images]
        content.append({"type": "text", "text": user})
        message = {"type": "user",
                   "message": {"role": "user", "content": content}}
        args = [self.executable, "-p",
                "--permission-mode", "dontAsk",
                "--model", self.model,
                "--disallowedTools", "*",
                "--input-format", "stream-json",
                "--output-format", "stream-json",
                "--verbose"]
        if system:
            args += ["--system-prompt", system]
        stdout = self._run(args, json.dumps(message) + "\n", timeout)
        answer = ""
        for line in stdout.splitlines():
            line = line.strip()
            if not line.startswith("{"):
                continue
            try:
                event = json.loads(line)
            except ValueError:
                continue
            if event.get("type") == "result":
                if event.get("is_error"):
                    raise ProviderError(
                        "claude could not read the picture: "
                        f"{str(event.get('result'))[:200]}")
                answer = event.get("result") or ""
        if not answer.strip():
            raise ProviderError("claude returned nothing for the picture "
                                f"(stdout was {len(stdout)} bytes)")
        return answer

    def complete_with_session(self, *, system: str, user: str,
                              session_id: str | None = None,
                              timeout: int = 120) -> tuple[str, str | None]:
        """(answer, session_id) — session_id feeds --resume next turn; that is
        the whole multi-turn implementation."""
        args = self._base_args() + ["--output-format", "json"]
        if system:
            args += ["--system-prompt", system]
        if session_id:
            args += ["--resume", session_id]
        stdout = self._run(args, user, timeout)
        envelope = _parse_envelope(stdout)
        return envelope.get("result") or "", envelope.get("session_id")

    def complete_structured(self, *, system: str, user: str, schema: dict,
                            timeout: int = 240) -> dict:
        structured, _session = self.complete_structured_with_session(
            system=system, user=user, schema=schema, timeout=timeout)
        return structured

    def complete_structured_with_session(self, *, system: str, user: str,
                                         schema: dict, timeout: int = 240,
                                         session_id: str | None = None
                                         ) -> tuple[dict, str | None]:
        args = self._base_args(allow_structured=True) + [
            "--output-format", "json",
            "--json-schema", json.dumps(schema),
        ]
        if system:
            args += ["--system-prompt", system]
        if session_id:
            args += ["--resume", session_id]
        stdout = self._run(args, user, timeout)
        envelope = _parse_envelope(stdout)
        structured = envelope.get("structured_output")
        if not isinstance(structured, dict):
            raise ProviderError(
                "claude returned no structured_output "
                f"(is_error={envelope.get('is_error')}, "
                f"result={str(envelope.get('result'))[:200]!r})")
        # Sending a schema is not the same as being sent one back. The caller
        # dispatches on these fields, so a shape mismatch has to fail here
        # rather than downstream where it looks like a different bug.
        problems = jsonshape.errors(structured, schema)
        if problems:
            raise ProviderError("structured reply did not match the schema: "
                                + "; ".join(problems[:4]))
        cost = envelope.get("total_cost_usd")
        log.info("structured call ok (model=%s, cost=%s)", self.model, cost)
        return structured, envelope.get("session_id")

    def stream(self, *, system: str, user: str, session_id: str | None = None):
        """--output-format stream-json: filter text_delta stream events,
        finish with the result message."""
        args = self._base_args() + [
            "--output-format", "stream-json", "--verbose",
            "--include-partial-messages",
        ]
        if system:
            args += ["--system-prompt", system]
        if session_id:
            args += ["--resume", session_id]
        process = subprocess.Popen(
            args, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, text=True, encoding="utf-8", shell=False)
        try:
            process.stdin.write(user)
            process.stdin.close()
            final = {}
            for line in process.stdout:
                line = line.strip()
                if not line:
                    continue
                try:
                    event = json.loads(line)
                except ValueError:
                    continue
                if event.get("type") == "stream_event":
                    delta = (event.get("event") or {}).get("delta") or {}
                    if delta.get("type") == "text_delta" and delta.get("text"):
                        yield {"type": "text", "text": delta["text"]}
                elif event.get("type") == "result":
                    final = event
            yield {"type": "result",
                   "text": final.get("result") or "",
                   "session_id": final.get("session_id")}
        finally:
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()


def _parse_envelope(stdout: str) -> dict:
    """stdout can carry more than one JSON document (observed live); the
    envelope is whichever dict carries structured_output or result."""
    candidates: list[dict] = []
    try:
        whole = json.loads(stdout)
        if isinstance(whole, dict):
            candidates.append(whole)
    except ValueError:
        decoder = json.JSONDecoder()
        index = 0
        text = stdout.strip()
        while index < len(text):
            try:
                obj, offset = decoder.raw_decode(text, index)
            except ValueError:
                index += 1
                continue
            if isinstance(obj, dict):
                candidates.append(obj)
            index = offset
            while index < len(text) and text[index] in " \r\n\t":
                index += 1
    if not candidates:
        raise ProviderError(f"claude emitted non-JSON: {stdout[:200]!r}")
    envelope = next((c for c in candidates if "structured_output" in c), None) \
        or next((c for c in candidates if "result" in c), candidates[-1])
    if envelope.get("is_error"):
        raise ProviderError(f"claude reported an error: "
                            f"{str(envelope.get('result'))[:300]}")
    return envelope
