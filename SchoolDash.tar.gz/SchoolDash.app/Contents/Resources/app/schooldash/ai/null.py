"""NullProvider — everything deterministic still runs; the model-dependent
parts degrade honestly instead of failing mysteriously."""

from schooldash.ai.base import ProviderError

# Two audiences, so two messages. MESSAGE is what a student sees on the page;
# SETUP_HINT is the developer detail, kept but moved out of their way. The old
# single message told a terminal-averse teenager to "run a local Ollama server,
# then set ai.provider in config.json".
MESSAGE = ("Chat is switched off on this Mac, and that is a normal way to run "
           "SchoolDash — your assignments, schedule and grades all work "
           "without it. Only the chat box needs an AI.")

SETUP_HINT = ("To turn chat on, install Claude Code (claude.com/claude-code) "
              "or run a local Ollama server, then set ai.provider in "
              "config.json.")


class NullProvider:
    name = "null"

    def available(self) -> tuple[bool, str]:
        return True, "null provider (no AI configured)"

    def complete_vision(self, *, system: str, user: str,
                        images=(), max_tokens: int = 1500,
                        timeout: int = 180) -> str:
        """Refused here, in one sentence, rather than downstream where it
        would read as a network fault. See base.Provider.complete_vision."""
        raise ProviderError(
            "no AI is set up on this Mac, so nothing can look at the photo")

    def complete(self, **kwargs) -> str:
        raise ProviderError(MESSAGE)

    def complete_structured(self, **kwargs) -> dict:
        raise ProviderError(MESSAGE)

    def stream(self, **kwargs):
        raise ProviderError(MESSAGE)
