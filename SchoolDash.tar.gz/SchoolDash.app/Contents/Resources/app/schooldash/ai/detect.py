"""Provider detection: config override -> claude on PATH -> Ollama answering
-> ANTHROPIC_API_KEY -> NullProvider. Different tasks can use different
providers (profiling_provider / chat_provider)."""

import os

from schooldash import config
from schooldash.logging_setup import get

log = get("ai.detect")

_cache: dict[str, object] = {}


def _make(name: str):
    if name == "claude_code":
        from schooldash.ai.claude_code import ClaudeCodeProvider
        return ClaudeCodeProvider()
    if name == "ollama":
        from schooldash.ai.ollama import OllamaProvider
        return OllamaProvider()
    if name == "anthropic_api":
        from schooldash.ai.anthropic_api import AnthropicApiProvider
        return AnthropicApiProvider()
    from schooldash.ai.null import NullProvider
    return NullProvider()


# Which providers were skipped to reach the one in use, per task. A demotion
# used to be announced with log.info to a file nobody opens: if the `claude` CLI
# dropped off PATH, chat quietly moved to a 3B local model and the answer still
# carried the same badge. The UI reads this so the change is visible where the
# answers are.
_demotions: dict[str, list[str]] = {}


def _auto(task: str = "chat"):
    skipped: list[str] = []
    for name in ("claude_code", "ollama", "anthropic_api"):
        provider = _make(name)
        ok, reason = provider.available()
        if ok:
            _demotions[task] = skipped
            return provider
        skipped.append(f"{name} ({reason})")
        log.info("provider %s unavailable: %s", name, reason)
    _demotions[task] = skipped
    return _make("null")


def provider_for(task: str = "chat"):
    """task: 'chat' | 'profiling' | 'adjudication' (adjudication follows
    profiling)."""
    cfg = config.load()["ai"]
    key = {"profiling": "profiling_provider",
           "adjudication": "profiling_provider"}.get(task, "chat_provider")
    choice = cfg.get(key) or cfg.get("provider") or "auto"
    if choice == "auto":
        choice = cfg.get("provider") if cfg.get("provider") not in (None, "auto") \
            else None
    cache_key = f"{task}:{choice or 'auto'}"
    if cache_key not in _cache:
        provider = _make(choice) if choice and choice != "auto" else _auto(task)
        ok, reason = provider.available()
        if not ok:
            log.warning("configured provider %s unavailable (%s); falling back",
                        choice, reason)
            _demotions.setdefault(task, []).insert(
                0, f"{choice} ({reason})")
            provider = _auto(task)
        _cache[cache_key] = provider
    return _cache[cache_key]


def describe() -> tuple[str, str]:
    provider = provider_for("chat")
    ok, reason = provider.available()
    return provider.name, reason


def status(task: str = "chat") -> dict:
    """What the UI needs to say honestly which model is answering.

    `configured` is what config.json asked for, `active` is what is actually
    running, and `skipped` is what stood in between. A demotion is a real change
    in answer quality, so it belongs on screen next to the answers.
    """
    cfg = config.load()["ai"]
    key = {"profiling": "profiling_provider",
           "adjudication": "profiling_provider"}.get(task, "chat_provider")
    configured = cfg.get(key) or cfg.get("provider") or "auto"
    provider = provider_for(task)
    skipped = list(_demotions.get(task) or [])
    detail = ""
    if provider.name == "ollama":
        detail = cfg.get("ollama_model") or ""
    elif provider.name == "claude_code":
        detail = cfg.get("claude_model") or ""
    return {"configured": configured, "active": provider.name,
            "model": detail, "skipped": skipped,
            "degraded": bool(skipped) or provider.name == "null"}


def reset_cache() -> None:
    """Providers are cached process-wide, so a config fix needed a restart that
    nobody knew to perform. Called by the refresh endpoint."""
    _cache.clear()
    _demotions.clear()
