"""Grounding verification (spec §13.2). Every failure is logged to
logs/grounding.jsonl.

**What this can and cannot certify.** It checks specific, checkable claims
against `state`: cited item ids, dates beside a citation, room numbers, a time
stated beside a course name, and any grade. It cannot read the answer for
meaning, so an answer that omits half of tomorrow's homework passes — being
incomplete is not a checkable claim.

That gap used to be hidden. `grounded` was `not violations`, so an answer with
no citations and nothing checkable scored a clean pass and the UI stamped it
"✓ checked against your data" — the cheapest way to earn the badge was to
assert everything and cite nothing. The verdict now separates the three real
outcomes, and the caller must not collapse them:

    confidence == "verified"    something was checked and held up
    confidence == "unverified"  nothing in the answer could be checked
    confidence == "failed"      a claim contradicts the data

`verified` counts the claims that actually passed, so the UI can say how many
rather than implying it checked everything."""

import hashlib
import json
import re
from datetime import date, datetime

from schooldash import paths, timezones
from schooldash.logging_setup import get

log = get("grounding")

CITATION = re.compile(r"\[([0-9a-f]{16})\]")
SHORT_CITATION = re.compile(r"\[([0-9a-f]{4,15})\]")
MONTH_DAY = re.compile(
    r"\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?\s+(\d{1,2})\b")
ISO_DATE = re.compile(r"\b(\d{4})-(\d{2})-(\d{2})\b")
QUOTED = re.compile(r"[\"“]([^\"”]{6,90})[\"”]")

# "Room 214", "in room P216" — an explicit location claim. Only the explicit
# form is trusted as a room claim: a bare code like P216 also turns up inside
# assignment titles, and flagging those would train the reader to ignore the
# badge, which is worse than not checking.
ROOM_CLAIM = re.compile(r"\b(?:room|rm\.?)\s+([A-Za-z]{0,2}\.?\s?\d{1,4}[A-Za-z]?)\b",
                        re.I)
ROOM_CODE = re.compile(r"\b([A-Z]{1,2}\.?\d{2,4})\b")
CLOCK = re.compile(r"\b(\d{1,2}):(\d{2})\s*(a\.?m\.?|p\.?m\.?)?", re.I)

# Grades are the one thing the payload declares unavailable, so any grade-shaped
# claim is unsourced unless it matches a grade actually in state.
PERCENT = re.compile(r"\b(\d{1,3}(?:\.\d+)?)\s*%")
# The cue words are case-insensitive; the letter itself must NOT be. With re.I
# applied to the whole pattern, `[A-F]` also matched the article "a", so
# "your grade in chemistry is a C" captured "a", found a real grade A in the
# data, and was stamped verified while the invented C sailed through. The
# scoped (?-i:...) keeps the cue loose and the grade strict.
LETTER_GRADE = re.compile(
    r"(?:grade|grades|score|scoring|average|sitting at|you have|you\'re at)"
    r"[^.!?\n]{0,40}?\b(?-i:([A-F][+-]?))\b", re.I)
GPA = re.compile(r"\bg\.?p\.?a\.?\b", re.I)

MONTH_NUM = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
             "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12}


def _tokens(text: str) -> set[str]:
    return {w for w in re.findall(r"[a-z0-9]+", (text or "").lower()) if len(w) > 2}


def _sentences(text: str) -> list[str]:
    return re.split(r"(?<=[.!?\n])\s+", text or "")


def _dates_in(sentence: str, year_hint: int) -> list[date]:
    found = []
    for match in ISO_DATE.finditer(sentence):
        try:
            found.append(date(int(match.group(1)), int(match.group(2)),
                              int(match.group(3))))
        except ValueError:
            pass
    for match in MONTH_DAY.finditer(sentence):
        month = MONTH_NUM[match.group(1).lower()[:3]]
        year = year_hint if month >= 7 else year_hint + 1
        try:
            found.append(date(year, month, int(match.group(2))))
        except ValueError:
            pass
    return found


def _norm_room(text: str) -> str:
    """P216, p 216 and P.216 are one room; compare on that basis."""
    return re.sub(r"[^a-z0-9]", "", (text or "").lower())


def _all_meetings(state: dict) -> list[dict]:
    """Every meeting the answer could legitimately be talking about.

    meetings_today plus the whole schedule window, because "what room is
    physics in on Thursday" is as checkable as today's.
    """
    seen: list[dict] = []
    for meeting in state.get("meetings_today") or []:
        seen.append(meeting)
    for day in (state.get("schedule") or {}).values():
        for meeting in day or []:
            seen.append(meeting)
    return seen


def _known_rooms(state: dict) -> set[str]:
    rooms = set()
    for meeting in _all_meetings(state):
        room = meeting.get("room")
        if room:
            rooms.add(_norm_room(room))
    for profile in state.get("profiles") or []:
        room = ((profile.get("meeting") or {}).get("typical_room"))
        if room:
            rooms.add(_norm_room(room))
    return rooms


def _course_times(state: dict) -> dict[frozenset, set[str]]:
    """course-name tokens -> the HH:MM times that course actually meets."""
    times: dict[frozenset, set[str]] = {}
    for meeting in _all_meetings(state):
        name = meeting.get("course_raw") or ""
        key = frozenset(_tokens(name))
        if not key:
            continue
        slot = times.setdefault(key, set())
        for field in ("start", "end"):
            stamp = (meeting.get(field) or "")[11:16]
            if stamp:
                slot.add(stamp)
    return times


def _clock_candidates(hour: int, minute: int, suffix: str | None) -> set[str]:
    """A school day is 8am-3pm, so "1:15" means 13:15 — but accept both rather
    than guess wrongly and invent a violation."""
    out = set()
    if suffix:
        lowered = suffix.replace(".", "").lower()
        adjusted = hour % 12 + (12 if lowered.startswith("p") else 0)
        out.add(f"{adjusted:02d}:{minute:02d}")
    else:
        out.add(f"{hour:02d}:{minute:02d}")
        if hour < 8:
            out.add(f"{hour + 12:02d}:{minute:02d}")
    return out


def _known_grades(state: dict) -> tuple[set[str], set[str]]:
    """(letters, percents) actually read from the portal."""
    letters, percents = set(), set()
    for grade in state.get("grades") or []:
        if not grade.get("graded"):
            continue
        if grade.get("letter"):
            letters.add(str(grade["letter"]).strip().upper())
        if grade.get("percent") is not None:
            percents.add(f"{float(grade['percent']):.2f}")
    return letters, percents


def _quotable_percents(state: dict) -> set[str]:
    """Percentages that appear in the student's own assignments.

    [MEASURED] 2026-09-02: once the English doc was being read, three eval
    questions failed on "the figure 50% is not a grade in your data" — because
    the assignment says so itself: "SARA: By September 18, 50% of Reading Level
    1 … must be completed = 25 points". An answer quoting that correctly was
    stamped with a warning.

    A badge that fires on correct answers is worse than no badge; this file
    already says exactly that about bare room codes. A percentage the data
    contains is being quoted, not invented — and a percentage found nowhere
    still fails, which is the case the rule exists for.
    """
    found = set()
    for item in state.get("items") or []:
        for field in ("title", "detail", "raw_cell"):
            for pct in PERCENT.findall(item.get(field) or ""):
                try:
                    found.add(f"{float(pct):.2f}")
                except ValueError:
                    continue
    return found


def check(answer: str, state: dict, question: str = "",
          retried: bool = False, strict: bool = False) -> dict:
    """{"grounded", "hard_fail", "violations", "cited", "verified", "checked",
    "unverifiable", "confidence"}.

    `strict=True` restores the soft near-miss band from before it was widened
    in 769552c, so run.py eval-chat can print the tuned and untuned numbers
    side by side instead of only the flattering one.
    """
    items = {i["item_id"]: i for i in state.get("items", [])}
    violations: list[str] = []
    checked: list[str] = []
    hard = False

    cited = CITATION.findall(answer or "")
    for cite in cited:
        if cite not in items:
            violations.append(f"cited id [{cite}] does not exist in the data")
            hard = True
        else:
            checked.append(f"item {items[cite].get('title', cite)!r} exists")
    for short in SHORT_CITATION.findall(answer or ""):
        if len(short) != 16:
            violations.append(f"citation [{short}] is truncated — citations "
                              "must be the full 16-character id")

    # a date attached to a cited item must match that item's due_date
    year_hint = None
    for item in items.values():
        if item.get("due_date"):
            year = int(item["due_date"][:4])
            month = int(item["due_date"][5:7])
            year_hint = year if month >= 7 else year - 1
            break
    year_hint = year_hint or datetime.now(timezones.zone()).year
    for sentence in _sentences(answer or ""):
        cites_here = [c for c in CITATION.findall(sentence) if c in items]
        if not cites_here:
            continue
        stated = _dates_in(sentence, year_hint)
        if not stated:
            continue
        due_dates = {items[c].get("due_date") for c in cites_here}
        for when in stated:
            if when.isoformat() in due_dates:
                checked.append(f"the date {when.isoformat()} matches its cited item")
                continue
            if True:
                violations.append(
                    f"the date {when.isoformat()} appears beside "
                    f"{['[' + c + ']' for c in cites_here]} but does not match "
                    f"the cited due date(s) {sorted(d or 'undated' for d in due_dates)}")
                hard = True

    # soft: a quoted assignment-title-like phrase that NEARLY matches a real
    # title (a near-miss suggests a mangled or invented assignment name).
    # Tuned against the first live eval: two false positives came from benign
    # short fragments, so a phrase must carry ≥3 meaningful tokens and overlap
    # a real title substantially-but-not-fully before it flags.
    real_titles = [_tokens(i.get("title")) for i in items.values()]
    floor, ceiling, min_words = (0.3, 1.0, 1) if strict else (0.5, 0.9, 3)
    for phrase in QUOTED.findall(answer or ""):
        words = _tokens(phrase)
        if len(words) < min_words:
            continue
        best = max((len(words & t) / len(words) for t in real_titles if t),
                   default=0)
        if floor <= best < ceiling:
            violations.append(f"the quoted phrase {phrase!r} nearly matches an "
                              "assignment title but not exactly — worth checking")

    # ---- rooms -----------------------------------------------------------
    # The payload hands the model today's rooms (chat.build_payload) and then
    # nothing looked at them again, so "Physics is in Room 214" was stamped
    # exactly like a true answer. Only the explicit "room X" form is treated as
    # a claim; a bare code also appears inside assignment titles.
    rooms = _known_rooms(state)
    if rooms:
        for stated_room in ROOM_CLAIM.findall(answer or ""):
            if _norm_room(stated_room) in rooms:
                checked.append(f"room {stated_room.strip()} is a real room")
            else:
                violations.append(
                    f"room {stated_room.strip()!r} is not any room in your "
                    "schedule")
                hard = True
        # a bare code is only judged inside a sentence that says "room"
        for sentence in _sentences(answer or ""):
            if not re.search(r"\broom\b", sentence, re.I):
                continue
            for code in ROOM_CODE.findall(sentence):
                if _norm_room(code) in rooms:
                    checked.append(f"room {code} is a real room")
                elif not ROOM_CLAIM.search(sentence):
                    violations.append(
                        f"room {code!r} is not any room in your schedule")
                    hard = True

    # ---- a time stated beside a course name -------------------------------
    course_times = _course_times(state)
    if course_times:
        for sentence in _sentences(answer or ""):
            words = _tokens(sentence)
            matches = [(key, slots) for key, slots in course_times.items()
                       if len(key & words) >= min(2, len(key))]
            if len(matches) != 1:
                continue          # ambiguous or no course named — not a claim
            key, slots = matches[0]
            for hour, minute, suffix in CLOCK.findall(sentence):
                try:
                    candidates = _clock_candidates(int(hour), int(minute), suffix)
                except ValueError:
                    continue
                if candidates & slots:
                    checked.append(f"{hour}:{minute} matches when that class meets")
                else:
                    violations.append(
                        f"the time {hour}:{minute} does not match when that "
                        f"class meets ({', '.join(sorted(slots)) or 'no times'})")
                    hard = True

    # ---- grades ----------------------------------------------------------
    # The payload explicitly declares grades unavailable and tells the model not
    # to invent one, and nothing enforced it. A grade is the single claim a
    # student is least able to sanity-check, so an unmatched one is a hard fail.
    letters, percents = _known_grades(state)
    quotable = _quotable_percents(state)
    if GPA.search(answer or ""):
        violations.append("a GPA is quoted, and this app never computes one — "
                          "it does not have the school's scale or credit weights")
        hard = True
    for pct in PERCENT.findall(answer or ""):
        try:
            normalised = f"{float(pct):.2f}"
        except ValueError:
            continue
        if normalised in percents:
            checked.append(f"{pct}% matches a grade actually read for you")
        elif normalised in quotable:
            checked.append(f"{pct}% is quoted from one of your assignments")
        else:
            violations.append(f"the figure {pct}% is not a grade in your data")
            hard = True
    for letter in LETTER_GRADE.findall(answer or ""):
        if letter.upper() in letters:
            checked.append(f"grade {letter} matches one actually read for you")
        else:
            violations.append(f"the grade {letter!r} is not in your data")
            hard = True

    # ---- the verdict, split three ways -----------------------------------
    verified = len(checked)
    if violations:
        confidence = "failed"
    elif verified:
        confidence = "verified"
    else:
        confidence = "unverified"
    grounded = not violations
    if not grounded:
        _log_failure(question, answer, violations, state, retried)
    return {"grounded": grounded, "hard_fail": hard,
            "violations": violations, "cited": cited,
            "verified": verified, "checked": checked,
            "unverifiable": confidence == "unverified",
            "confidence": confidence}


def _log_failure(question, answer, violations, state, retried):
    payload_hash = hashlib.sha1(
        json.dumps([i["item_id"] for i in state.get("items", [])])
        .encode()).hexdigest()[:12]
    entry = {"at": datetime.now(timezones.zone()).isoformat(timespec="seconds"),
             "payload_hash": payload_hash, "question": question,
             "answer": answer, "violations": violations, "retried": retried}
    try:
        with paths.grounding_log_path().open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except OSError:
        log.warning("could not write grounding log")


EVAL_QUESTIONS = [
    "what do I have due tomorrow?",
    "what's due today?",
    "what should I work on first tonight?",
    "what's my APCR?",
    "do I have any AP Classroom work due this week?",
    "what's overdue right now?",
    "what does chemistry want before the next class?",
    "when is the next chemistry quiz?",
    "what's the biggest thing due this week?",
    "how many things are due Friday?",
    "what do I have for English?",
    "is anything due Monday?",
    "what's my grade in physics?",
    "did I already turn in the Klara assessment?",
    "what classes do I have today?",
    "what room is physics in today?",
    "list everything due in the next 3 days",
    "what's the lowest-effort thing I can knock out right now?",
    "do I have any tests coming up?",
    "any quizzes this week?",
    "what did the English teacher assign on Day 4?",
    "is there homework in Science and Religion?",
    "what is due next Tuesday?",
    "which class has the most work right now?",
    "what links do I need for tonight's homework?",
    "summarize my week",
    "what's undated that I should double-check?",
    "did anything change since yesterday?",
    "when is the progress check due?",
    "what should I not forget to bring tomorrow?",
]


# ---------------------------------------------------------------------------
# Expected answers.
#
# The eval used to report a single number — "grounding pass rate" — and a pass
# only ever meant "the checker did not object". An answer that omitted half of
# tomorrow's homework scored identically to a complete one, and commit 769552c
# reported 30/30 after the checker itself had been edited to stop flagging the
# two questions that failed. Both problems are the same problem: the thing under
# test was also the thing doing the testing.
#
# So the highest-traffic questions now carry expectations, derived from `state`
# rather than written down, so they cannot rot when the fixture changes:
#
#   must_cite      every item id a correct answer has to mention (recall)
#   may_cite       ids it is allowed to mention; anything else is a precision
#                  failure — citing next week's essay when asked about today is
#                  wrong even though every id is real
#   must_include   substrings a correct answer contains (rooms, counts)
#   must_not_match a pattern a correct answer never contains — used for the
#                  grade question, where the only correct behaviour is to
#                  decline
def _open_items(state):
    return [i for i in state.get("items", []) if not i.get("done")]


def _day(state, offset=0):
    from datetime import timedelta
    base = date.fromisoformat(state["today"])
    return (base + timedelta(days=offset)).isoformat()


def _due_on(state, iso):
    return {i["item_id"] for i in _open_items(state) if i.get("due_date") == iso}


def _weekday_dates(state, weekday):
    """Both readings of "Friday", because on a Friday both are reasonable.

    The first run of this eval marked "how many things are due Friday?" wrong
    because the fixture's today IS a Friday: the expectation demanded the
    following Friday while the answer, sensibly, meant today. An expectation
    that punishes the reasonable reading measures the expectation, not the
    answer.
    """
    from datetime import timedelta
    base = date.fromisoformat(state["today"])
    ahead = (weekday - base.weekday()) % 7
    days = [base + timedelta(days=ahead or 7)]
    if ahead == 0:
        days.append(base)
    return [d.isoformat() for d in days]


def _expect_ids(ids: set, big: int = 8) -> dict:
    """Turn a set of ids into a realistic expectation.

    Demanding all 40 overdue items be cited would fail every sensible answer —
    a good one summarises and offers the worst few. So a large set asks for the
    count and a handful of real ids; a small set asks for all of them. Precision
    applies either way: citing something that is not in the set is wrong even
    when the id is real.
    """
    if len(ids) > big:
        # No count_of here. "do I have any tests coming up?" is a yes-and-list
        # question, not a counting one, and requiring the literal "33" measured
        # phrasing rather than correctness. Only the question that actually asks
        # "how many" carries a count expectation.
        return {"may_cite": ids, "min_cited": 3}
    return {"must_cite": ids, "may_cite": ids}


def _both_baselines(state, offset=0):
    """The same day counted from the state's `today` and from the real one.

    The frozen fixture is weeks old, and the payload now tells the model both
    the day the data describes and how stale it is — so for a date-relative
    question two answers are defensible. Recall is still judged against the
    state's own day; only the precision set is widened, so a real omission still
    fails while a defensible reading does not.
    """
    from datetime import timedelta
    days = []
    for base in (state.get("today"), datetime.now(timezones.zone()).date().isoformat()):
        if not base:
            continue
        try:
            days.append((date.fromisoformat(base) + timedelta(days=offset)).isoformat())
        except ValueError:
            continue
    return days


def _expect_relative(state, offset):
    isos = _both_baselines(state, offset)
    primary = _due_on(state, isos[0]) if isos else set()
    allowed = set().union(*[_due_on(state, iso) for iso in isos]) if isos else set()
    expectation = _expect_ids(primary)
    expectation["may_cite"] = allowed
    return expectation


def _expect_due_today(state):
    return _expect_relative(state, 0)


def _expect_due_tomorrow(state):
    return _expect_relative(state, 1)


def _expect_overdue(state):
    days = _both_baselines(state, 0)
    ids = {i["item_id"] for i in _open_items(state)
           if i.get("due_date") and i["due_date"] < days[0]}
    allowed = {i["item_id"] for i in _open_items(state)
               if i.get("due_date") and i["due_date"] < max(days)}
    expectation = _expect_ids(ids)
    expectation["may_cite"] = allowed
    return expectation


def _expect_next_three_days(state):
    span = {d for n in (0, 1, 2, 3) for d in _both_baselines(state, n)}
    primary = {_day(state, n) for n in (0, 1, 2, 3)}
    ids = {i["item_id"] for i in _open_items(state)
           if i.get("due_date") in primary}
    allowed = {i["item_id"] for i in _open_items(state)
               if i.get("due_date") in span}
    expectation = _expect_ids(ids)
    expectation["may_cite"] = allowed
    return expectation


def _expect_due_friday(state):
    options = [_due_on(state, iso) for iso in _weekday_dates(state, 4)]
    # the reading that has anything to report is the one being asked about
    ids = max(options, key=len)
    allowed = set().union(*options) if options else set()
    return {"must_cite": ids, "may_cite": allowed,
            "count_of": ids}


def _expect_due_monday(state):
    options = [_due_on(state, iso) for iso in _weekday_dates(state, 0)]
    ids = max(options, key=len)
    expectation = _expect_ids(ids)
    expectation["may_cite"] = set().union(*options) if options else set()
    return expectation


def _expect_tests_coming(state):
    today = _day(state, 0)
    ids = {i["item_id"] for i in _open_items(state)
           if i.get("category") in ("test", "quiz")
           and (not i.get("due_date") or i["due_date"] >= today)}
    return _expect_ids(ids)


def _expect_classes_today(state):
    names = [(m.get("course_raw") or "").split("-")[0].strip()
             for m in state.get("meetings_today") or []]
    return {"must_include": [n for n in names if n][:4]}


def _expect_room_today(state):
    for meeting in state.get("meetings_today") or []:
        if "physics" in (meeting.get("course_raw") or "").lower():
            room = meeting.get("room")
            return {"must_include": [room]} if room else {}
    return {}


def _expect_no_grade(state):
    # The one question whose only correct answer is a refusal: grades are
    # deliberately absent from the payload, so any figure is invented.
    return {"must_not_match": r"\b\d{1,3}(?:\.\d+)?\s*%|\bG\.?P\.?A\.?\b"}


EXPECTATIONS = {
    "what's due today?": _expect_due_today,
    "what do I have due tomorrow?": _expect_due_tomorrow,
    "what's overdue right now?": _expect_overdue,
    "list everything due in the next 3 days": _expect_next_three_days,
    "how many things are due Friday?": _expect_due_friday,
    "is anything due Monday?": _expect_due_monday,
    "do I have any tests coming up?": _expect_tests_coming,
    "what classes do I have today?": _expect_classes_today,
    "what room is physics in today?": _expect_room_today,
    "what's my grade in physics?": _expect_no_grade,
}


def score_answer(answer: str, expectation: dict) -> list[str]:
    """How this answer fails its expectation. Empty list means correct."""
    misses: list[str] = []
    text = (answer or "")
    lowered = text.lower()
    cited = set(CITATION.findall(text))

    missing = set(expectation.get("must_cite") or ()) - cited
    if missing:
        misses.append(f"did not mention {len(missing)} item(s) it should have")
    floor = expectation.get("min_cited")
    if floor and len(cited & set(expectation.get("may_cite") or ())) < floor:
        misses.append(f"cited fewer than {floor} of the relevant items")

    # Precision, but tolerant of context. A good answer to "what's due
    # tomorrow?" on a quiet day may well add "…but these two are overdue", and
    # the first run of this eval called that wrong. What is still wrong is
    # answering a different question, so this fails only when most of what was
    # cited is off-target.
    allowed = expectation.get("may_cite")
    if allowed is not None and cited:
        extra = cited - set(allowed)
        if len(extra) > max(1, len(cited) // 2):
            misses.append(f"{len(extra)} of {len(cited)} cited items do not "
                          "belong in the answer")

    # A count can be written "3", "three", or satisfied by naming the items.
    # Demanding the literal digit measured phrasing, not correctness.
    counted = expectation.get("count_of")
    if counted is not None:
        n = len(counted)
        words = {0: "no", 1: "one", 2: "two", 3: "three", 4: "four", 5: "five",
                 6: "six", 7: "seven", 8: "eight", 9: "nine", 10: "ten"}
        said_number = (re.search(rf"\b{n}\b", text)
                       or (n in words and re.search(rf"\b{words[n]}\b", lowered))
                       or (n == 0 and re.search(r"\bnothing|\bnone\b", lowered)))
        listed_them = bool(counted) and counted <= cited
        if not said_number and not listed_them:
            misses.append(f"never gave the number ({n})")
    for needle in expectation.get("must_include") or ():
        if needle and str(needle).lower() not in lowered:
            misses.append(f"never said {needle!r}")
    forbidden = expectation.get("must_not_match")
    if forbidden and re.search(forbidden, text, re.I):
        misses.append("stated a grade, which it has no data for")
    return misses


def cli_eval_chat(live: bool = False) -> int:
    """Replays the fixed question set and reports three numbers, not one.

    Reporting only the grounding pass rate is how "30/30" came to mean "the
    checker did not object, after the checker was edited". So:

      correctness  did the answer contain what a right answer contains
                   (EXPECTATIONS, derived from the state itself)
      grounding    tuned  — the soft near-miss band as it ships
      grounding    untuned — the band as it was before 769552c widened it

    The two grounding numbers cost nothing extra: the same answer is re-checked.
    A gap between them is the size of the tuning, printed rather than hidden.
    """
    import sys
    from schooldash import pipeline
    from schooldash.ai import chat as chat_mod

    fixture = (paths.project_root() / "tests" / "fixtures" / "eval"
               / "state.json")
    if live or not fixture.exists():
        state = pipeline.load_state()
        source = "live cache"
    else:
        state = json.loads(fixture.read_text(encoding="utf-8"))
        source = "frozen fixture"
    if not state:
        print("no state to evaluate against — run: python run.py refresh")
        return 1
    if source == "frozen fixture":
        print("NOTE: a frozen fixture cannot notice today's data breaking. "
              "Run with --live to evaluate against the real cache.")

    passed = untuned_passed = 0
    scored = correct = 0
    failures, wrong = [], []
    for n, question in enumerate(EVAL_QUESTIONS, 1):
        try:
            result = chat_mod.answer(question, state)
        except Exception as exc:  # noqa: BLE001
            failures.append((question, [f"provider error: {exc}"]))
            print(f"  {n:2}/{len(EVAL_QUESTIONS)} ERROR {question!r}: {exc}",
                  file=sys.stderr)
            continue
        answer_text = result.get("answer") or ""

        if result["grounded"]:
            passed += 1
        else:
            failures.append((question, result["violations"]))
        strict = check(answer_text, state, question=question, strict=True)
        if strict["grounded"]:
            untuned_passed += 1

        expectation = EXPECTATIONS.get(question)
        mark = "ok   "
        if expectation is not None:
            scored += 1
            misses = score_answer(answer_text, expectation(state))
            if misses:
                wrong.append((question, misses))
                mark = "WRONG"
            else:
                correct += 1
        elif not result["grounded"]:
            mark = "FAIL "
        print(f"  {n:2}/{len(EVAL_QUESTIONS)} {mark} {question}"
              + (f" — {result['violations']}" if result["violations"] else ""))

    total = len(EVAL_QUESTIONS)
    print(f"\nagainst the {source}")
    if scored:
        print(f"  correctness        {correct}/{scored} "
              f"({correct / scored * 100:.0f}%) of the questions that have an "
              "expected answer")
    print(f"  grounding, tuned   {passed}/{total} "
          f"({passed / total * 100:.0f}%)")
    print(f"  grounding, untuned {untuned_passed}/{total} "
          f"({untuned_passed / total * 100:.0f}%)  "
          "— the soft band before it was widened in 769552c")
    print("  (grounding only certifies checkable claims; correctness is the "
          "number that says an answer was right)")
    for question, misses in wrong:
        print(f"  WRONG:  {question!r}: {'; '.join(misses)}")
    for question, violations in failures:
        print(f"  FAILED: {question!r}: {violations}")
    # A wrong answer fails the run. Grounding alone never could.
    return 0 if (not wrong and passed == total) else 1
