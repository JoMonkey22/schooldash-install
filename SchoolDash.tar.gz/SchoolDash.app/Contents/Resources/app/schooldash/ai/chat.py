"""Chat: a compact grounded payload, a system prompt that forbids invention,
and grounding verification on every answer (spec §13)."""

import re
from datetime import datetime

from schooldash import timezones
from schooldash.ai import detect, grounding, lookup
from schooldash.logging_setup import get

log = get("chat")

SYSTEM = (
    "You are the assistant inside SchoolDash, a schedule and homework "
    "dashboard for a high-school student. Be brief, concrete, and "
    "encouraging. Use only the data below. Never invent an assignment, "
    "class, link, date, or grade. When you refer to a specific assignment, "
    "cite its full id in square brackets like [a3f1c9d2e4b58607]. If "
    "something is not in the data, say so plainly.")


# How much of a study guide travels with a question about it.
#
# A guide is ~2,240 tokens of writing (measured: the two in his database are
# 9,233 and 8,696 characters), and a normal chat payload is ~1,050. Sending a
# whole guide every time would triple the cost of every question, so it is
# sent only for a question about THAT item, and capped. The structured parts —
# the summary, the terms, the practice questions — go first and whole, because
# they are what a student asks about; the long prose is what gets trimmed.
GUIDE_PROSE_CHARS = 5000


def _guide_for(item_id: str) -> dict | None:
    """The cached study guide for one item, if Accelerate has written one."""
    if not item_id:
        return None
    try:
        from schooldash import db

        conn = db.connect()
        try:
            row = db.acceleration_get(conn, item_id)
        finally:
            conn.close()
        return (row or {}).get("result") or None
    except Exception as exc:  # noqa: BLE001 — never break a chat over this
        log.info("could not read the guide for %s: %s", item_id, exc)
        return None


def _guide_lines(guide: dict) -> list[str]:
    """A study guide, laid out so the model can answer questions from it.

    [MEASURED] 2026-09-03: the chat had never been told a guide existed. He
    could accelerate an assignment, read the guide, ask "what does covalent
    mean here" in the same window, and the assistant had no idea any of it had
    happened — it was answering from the board alone.
    """
    out = ["=== THE STUDY GUIDE ALREADY WRITTEN FOR THIS ITEM ==="]
    out.append("Answer from this when the question is about the material. It "
               "was written by you earlier from the real reading, so quoting "
               "it is quoting the student's own guide, not inventing.")
    for field, label in (("headline", "headline"), ("kind", "kind"),
                         ("time_estimate_minutes", "estimated minutes")):
        if guide.get(field) is not None:
            out.append(f"{label}: {guide.get(field)}")
    if guide.get("tldr"):
        out.append(f"summary: {guide['tldr']}")
    for term in guide.get("key_terms") or []:
        if isinstance(term, dict):
            out.append(f"term: {term.get('term')} — {term.get('meaning')}")
    for n, task in enumerate(guide.get("practice") or [], 1):
        if isinstance(task, dict):
            out.append(f"practice {n}: {task.get('prompt')}")
            if task.get("hint"):
                out.append(f"  hint: {task.get('hint')}")
            if task.get("answer"):
                out.append(f"  answer: {task.get('answer')}")
    for visual in guide.get("visuals") or []:
        if isinstance(visual, dict):
            out.append(f"visual: {visual.get('caption') or visual.get('alt') or ''}")
    prose = (guide.get("guide_markdown") or "").strip()
    if prose:
        clipped = prose[:GUIDE_PROSE_CHARS]
        out.append("guide:")
        out.append(clipped)
        if len(prose) > GUIDE_PROSE_CHARS:
            out.append(f"[the guide continues for {len(prose) - GUIDE_PROSE_CHARS} "
                       "more characters — say so rather than guessing at the rest]")
    return out


def build_payload(state: dict, item_id: str | None = None) -> str:
    """Full 16-character ids — grounding resolves citations against them."""
    now = datetime.now(timezones.zone())
    lines = []
    block = state.get("block_label") or ""
    # The day comes from the state, not the clock. These disagree whenever the
    # data is not from today — which is most of the time, since the app refreshes
    # at 07:00 and gets asked questions in the evening, and a failed refresh now
    # deliberately keeps yesterday's board. The payload used to assert the real
    # date beside August's items and an "Aug 17-28 block" label, so every
    # "tomorrow" was computed against a baseline the items did not share.
    stated_today = state.get("today")
    try:
        day = (datetime.fromisoformat(stated_today) if stated_today
               else now).strftime("%A %d %B %Y")
    except ValueError:
        day = now.strftime("%A %d %B %Y")
    lines.append(f"=== TODAY: {day}"
                 + (f" ({block})" if block else "") + " ===")
    # And say how old the data is, so the answer can be honest about it rather
    # than presenting a stale board as this minute's truth.
    gathered = state.get("generated_at") or ""
    if gathered:
        lines.append(f"(this data was gathered {gathered[:16].replace('T', ' ')}"
                     + (f"; it is now {now:%Y-%m-%d %H:%M}, so it may be out of "
                        "date — say so if it matters"
                        if gathered[:10] != (stated_today or gathered[:10])
                        or gathered[:10] != now.strftime("%Y-%m-%d") else "")
                     + ")")

    lines.append("=== SCHEDULE TODAY ===")
    todays = state.get("meetings_today") or []
    # A timetable kept from an earlier refresh (pipeline._carry_schedule) is
    # right nearly always, and the model has no way to tell. Unlabelled, it
    # will state a room as today's fact — the deterministic answers were fixed
    # for this in COUNT 26 and the model half would have kept doing it.
    sched_stale = state.get("schedule_stale") or {}
    if sched_stale:
        lines.append(f"(NOT read this refresh — kept from "
                     f"{str(sched_stale.get('as_of') or 'an earlier run')[:10]}, "
                     "because the class feed could not be read. Say so when you "
                     "use any time or room below.)")
    if todays:
        for n, m in enumerate(todays, 1):
            start = (m.get("start") or "")[11:16]
            end = (m.get("end") or "")[11:16]
            room = m.get("room") or ""
            lines.append(f"[{n}] {start}-{end}  {m.get('course_raw', '')}  {room}")
    elif sched_stale:
        lines.append("(the class feed could not be read, so today's classes "
                     "are unknown — do not say he has none)")
    else:
        lines.append("(no classes today per the feed)")

    lines.append("=== OPEN ITEMS (item_id | course | due | title | source | "
                 "confidence) ===")
    open_items = [i for i in state.get("items", []) if not i.get("done")]
    for item in open_items:
        lines.append(f"{item['item_id']} | {item.get('course', '')[:34]} | "
                     f"{item.get('due_date') or 'undated'} | "
                     f"{item.get('title', '')[:90]} | {item.get('source')} | "
                     f"{item.get('confidence')}")
    if not open_items:
        lines.append("(nothing open)")

    done_items = [i for i in state.get("items", []) if i.get("done")][:12]
    lines.append("=== DONE RECENTLY ===")
    for item in done_items:
        lines.append(f"{item['item_id']} | {item.get('course', '')[:30]} | "
                     f"{item.get('title', '')[:80]}")
    if not done_items:
        lines.append("(none)")

    lines.append("=== CLASS NOTATION ===")
    wrote = False
    for profile in state.get("profiles", []):
        for term, meaning in (profile.get("notation") or {}).items():
            lines.append(f"{term} = {meaning} "
                         f"({profile.get('display_name', '')})")
            wrote = True
    if not wrote:
        lines.append("(no special notation recorded)")

    if item_id:
        focus = next((i for i in state.get("items", [])
                      if i["item_id"] == item_id), None)
        if focus:
            lines.append("=== THE ITEM BEING ASKED ABOUT ===")
            for field in ("item_id", "course", "title", "detail", "due",
                          "date_note", "extractor", "confidence", "raw_cell"):
                lines.append(f"{field}: {focus.get(field)}")
            for link in focus.get("links", []):
                lines.append(f"link [{link.get('kind')}]: {link.get('url')}")
            guide = _guide_for(item_id)
            if guide:
                lines.extend(_guide_lines(guide))

    # Which items already have a guide, so "what did the study guide say about
    # the brief?" can be answered without the student first clicking the item.
    # One line each — the full text only travels for a focused question.
    try:
        from schooldash import db

        conn = db.connect()
        try:
            written = db.acceleration_ids(conn)
        finally:
            conn.close()
    except Exception:  # noqa: BLE001 — never break a chat over this
        written = set()
    if written:
        titled = [i for i in state.get("items", [])
                  if i.get("item_id") in written]
        if titled:
            lines.append("=== ITEMS THAT ALREADY HAVE A STUDY GUIDE ===")
            lines.append("Say the guide exists and offer to open it. Its text "
                         "is only sent when the question is about that item, "
                         "so do not quote a guide you cannot see here.")
            for entry in titled:
                lines.append(f"{entry['item_id']} | {entry.get('course', '')[:26]} "
                             f"| {(entry.get('title') or '')[:70]}")

    lines.append("=== NOT IN THIS PAYLOAD ===")
    # This used to read "Grades. Canvas does not supply them here." — which
    # stopped being true once grades were read from the Veracross portal and
    # rendered in the Grades panel. The instruction is unchanged, the reason is
    # now the real one: they are deliberately not sent to the model, so the
    # model has nothing to base a grade on and any number it produces is
    # invented. The grounding check now hard-fails an unmatched grade rather
    # than trusting this sentence to hold.
    lines.append("Grades. The dashboard reads them, but they are not included "
                 "here, so you have no grade data. Never state, estimate or "
                 "guess a grade or a GPA; say the Grades panel on the page has "
                 "them.")
    return "\n".join(lines)


DATE_HINT = re.compile(
    r"\b\d{1,2}\s*/\s*\d{1,2}"                       # 8/24
    r"|\b\d{4}-\d{2}-\d{2}\b"                          # 2026-08-24
    r"|\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s*\d{1,2}"
    r"|\b\d{1,2}(?:st|nd|rd|th)\b"                      # the 24th
    r"|\b(?:today|tomorrow|tonight|monday|tuesday|wednesday|thursday|friday"
    r"|saturday|sunday|next\s+week|this\s+week|weekend)\b",
    re.I)


def _mentions_a_date(message: str) -> bool:
    """Did the student actually say a date? Hard constraint: a date is never
    invented, and the only evidence that one was stated is that it appears in
    what they typed."""
    return bool(DATE_HINT.search(message or ""))


def _verdict_fields(verdict: dict) -> dict:
    """The parts of a grounding verdict the UI is allowed to see.

    `confidence`/`verified`/`checked` travel alongside `grounded` rather than
    replacing it, because the API is consumed by the published snapshot too and
    an older page must keep working. The UI prefers `confidence`; a caller that
    only reads `grounded` gets the old, coarser answer.
    """
    return {"cited": verdict["cited"], "grounded": verdict["grounded"],
            "violations": verdict["violations"],
            "confidence": verdict.get("confidence"),
            "verified": verdict.get("verified", 0),
            "checked": verdict.get("checked", [])}


def _ask(provider, user: str, session_id: str | None):
    if hasattr(provider, "complete_with_session"):
        return provider.complete_with_session(system=SYSTEM, user=user,
                                              session_id=session_id)
    return provider.complete(system=SYSTEM, user=user), None


def _looked_up(message: str, state: dict, provider_name: str) -> dict | None:
    """A computed answer, when the question is a lookup rather than a judgement.

    Runs BEFORE the model, for two reasons. It makes chat work at all on a Mac
    without Claude Code — which was one dead box in an otherwise working app,
    and for a paid product a dead box reads as "this is broken". And on exactly
    this set of questions it is the better answer: [MEASURED] 2026-08-31 the
    model scored 7/10 here and its failures were omissions, naming five fewer
    items than were due. A lookup cannot omit and cannot invent.

    Open questions still go to the model; see lookup.answer's docstring.
    """
    text = lookup.answer(message, state)
    if text is None:
        return None
    verdict = grounding.check(text, state, question=message)
    return {"answer": text, "session_id": None, "provider": f"{provider_name}+lookup",
            "mode": "lookup", **_verdict_fields(verdict)}


def _quick_added(message: str, state: dict, provider_name: str) -> dict | None:
    """A task proposal read straight from the sentence, no model involved.

    Runs BEFORE the model for the same reason the lookup does: on the shapes it
    recognises ("teacher said…", "add…", "hw:…") it is faster, it cannot invent
    a date it was not given, and it works on a Mac with no AI at all — which is
    how "orally communicated" homework gets recorded without one. Anything it
    does not recognise still goes to the model.
    """
    from schooldash import quickadd
    # The REAL today, not the state's. The board's date is whenever the data
    # was gathered, and "by Friday" said on a Tuesday evening over Friday's
    # stale board must still mean this coming Friday.
    today = _real_today()
    index = None
    try:
        from schooldash.feeds import classfeed
        meetings = []
        for day in (state.get("schedule") or {}).values():
            for m in day or []:
                meetings.append(m)
        if meetings:
            index = _ScheduleIndex(meetings)
    except Exception:  # noqa: BLE001 — "next class" simply stays unresolved
        index = None
    proposal = quickadd.parse(message, state, today, index)
    if not proposal:
        return None
    when = (f"due {proposal['due_date']}" if proposal["due_date"]
            else "with no date (you did not say one)")
    text = (f"Got it — add \"{proposal['title']}\""
            + (f" for {proposal['course']}" if proposal["course"] else "")
            + f", {when}?"
            + (f"\n({proposal['date_note']})" if proposal["due_date"] else ""))
    verdict = grounding.check(text, state, question=message)
    proposed = {"title": proposal["title"], "due_date": proposal["due_date"],
                "course": proposal["course"], "section": None,
                "category": proposal["category"],
                "notes": (f"heard as: {message.strip()[:200]}"
                          + (f" · {proposal['date_note']}" if proposal["due_date"] else ""))}
    return {"answer": text, "session_id": None, "provider": f"{provider_name}+quickadd",
            "mode": "quickadd", "action": {"intent": "add_task", "proposed": proposed},
            **_verdict_fields(verdict)}


def _real_today():
    return datetime.now(timezones.zone()).date()


class _ScheduleIndex:
    """Just enough of MeetingIndex for quickadd's "next class": built from the
    schedule already in state, so no feed fetch happens inside a chat turn."""

    def __init__(self, meetings: list[dict]):
        self.meetings = meetings

    def next_after(self, course: str, day):
        from datetime import date as date_cls
        wanted = {w for w in re.findall(r"[a-z]+", (course or "").lower()) if len(w) > 2}
        best = None
        for meeting in self.meetings:
            name = (meeting.get("course_raw") or "").lower()
            if not wanted & set(re.findall(r"[a-z]+", name)):
                continue
            try:
                when = date_cls.fromisoformat((meeting.get("date") or "")[:10])
            except ValueError:
                continue
            if when > day and (best is None or when < best):
                best = when
        return best


def _no_model_reply(message: str, state: dict) -> dict:
    """What to say when there is no model and the question needed one.

    Names what it CAN answer rather than only what it cannot: "chat needs an AI
    provider" tells a student nothing they can act on.
    """
    examples = "\n".join(f"• {q}" for q in lookup.CAN_ANSWER[:6])
    text = ("I can answer questions about your own homework and schedule without "
            "any AI set up — things like:\n" + examples
            + "\n\nThat one needs an AI, which is not installed on this Mac. "
              "Everything else on the page works without it.")
    verdict = grounding.check(text, state, question=message)
    return {"answer": text, "session_id": None, "provider": "lookup",
            "mode": "lookup", **_verdict_fields(verdict)}


def answer(message: str, state: dict, session_id: str | None = None,
           item_id: str | None = None) -> dict:
    """Non-streaming: grounding gates display, so a hard fail is retried once
    with the specific violation named; a second failure ships WITH the
    warning — nothing hidden, including the assistant's mistakes."""
    provider = detect.provider_for("chat")
    # An item-specific question is about that item's detail and links, which the
    # lookup does not carry — send those to the model.
    if not item_id:
        quick = _quick_added(message, state, provider.name)
        if quick is not None:
            return quick
        computed = _looked_up(message, state, provider.name)
        if computed is not None:
            return computed
    if provider.name == "null":
        return _no_model_reply(message, state)
    # The allowance is checked only once the lookup above has declined, so a
    # question the app can answer itself never costs anyone anything — three
    # in five never reach this line (plans.py).
    from schooldash import allowance as allowance_mod

    try:
        allowance_mod.check("chat")
    except allowance_mod.Exhausted as spent:
        return {"answer": spent.message, "provider": provider.name,
                "mode": "allowance", "grounded": True, "cited": [],
                "violations": [], "confidence": "n/a",
                "allowance": allowance_mod.status("chat")}
    payload = build_payload(state, item_id)
    user = f"{payload}\n\n=== QUESTION ===\n{message}"
    text, new_session = _ask(provider, user, session_id)
    # Counted here: after an answer exists. A provider that raised got the
    # student nothing, and charging for nothing is the app taking something.
    allowance_mod.record("chat")
    verdict = grounding.check(text, state, question=message)
    if not verdict["grounded"] and verdict["hard_fail"]:
        retry_user = (f"{user}\n\nYour previous answer failed a grounding "
                      f"check: {'; '.join(verdict['violations'])}. Answer "
                      "again using only items from the data, citing their ids.")
        text, new_session = _ask(provider, retry_user, new_session or session_id)
        verdict = grounding.check(text, state, question=message, retried=True)
    return {"answer": text, "session_id": new_session or session_id,
            "provider": provider.name, "mode": "complete",
            **_verdict_fields(verdict)}


ACTION_SCHEMA = {
    "type": "object",
    "properties": {
        "intent": {"type": "string", "enum": ["question", "add_task", "mark_done"]},
        "answer": {"type": "string",
                   "description": "the reply shown to the student; cite item "
                                  "ids in [brackets] when referring to items"},
        "task": {
            "type": ["object", "null"],
            "properties": {
                "title": {"type": "string"},
                "due_date": {"type": ["string", "null"],
                             "description": "YYYY-MM-DD, or null if not stated"},
                "course": {"type": ["string", "null"]},
                "section": {"type": ["string", "null"],
                            "enum": ["school", "clubs", "upcoming", None]},
                "notes": {"type": ["string", "null"]},
                "category": {"type": ["string", "null"],
                             "enum": ["assignment", "quiz", "test", "project", "essay",
                                      "reading", "problem_set", "discussion", None]},
            },
            "required": ["title"],
        },
        "done_item_id": {"type": ["string", "null"],
                         "description": "the FULL 16-char id of the item being "
                                        "marked done; must exist in the data"},
    },
    "required": ["intent", "answer"],
    "additionalProperties": False,
}

ACTION_SYSTEM = SYSTEM + (
    " You can also perform TWO actions when the student asks: intent "
    "'add_task' when they tell you about new work or an event to remember "
    "(e.g. 'Robotics workshop schedule 8/24' — title 'Robotics workshop "
    "schedule', due_date 2026-08-24, section 'clubs' for club things), and "
    "intent 'mark_done' when they say they finished something that exists in "
    "the data (done_item_id must be its full id). Never invent a due date the "
    "student did not state — leave it null. For plain questions use intent "
    "'question'.")


def answer_action(message: str, state: dict, session_id: str | None = None,
                  item_id: str | None = None) -> dict:
    """One structured turn: an answer plus an optional verified action.
    Actions are validated before they touch anything — a mark_done id that is
    not in the data is refused, and an added task echoes back exactly what was
    stored."""
    from schooldash import db as db_mod
    from schooldash import tasks as tasks_mod

    provider = detect.provider_for("chat")
    if not item_id:
        quick = _quick_added(message, state, provider.name)
        if quick is not None:
            return quick
        computed = _looked_up(message, state, provider.name)
        if computed is not None:
            computed["action"] = {"intent": "question"}
            return computed
    if provider.name == "null":
        reply = _no_model_reply(message, state)
        reply["action"] = {"intent": "question"}
        return reply
    payload = build_payload(state, item_id)
    user = f"{payload}\n\n=== MESSAGE ===\n{message}"
    if hasattr(provider, "complete_structured_with_session"):
        result, new_session = provider.complete_structured_with_session(
            system=ACTION_SYSTEM, user=user, schema=ACTION_SCHEMA,
            session_id=session_id, timeout=180)
    else:
        result = provider.complete_structured(system=ACTION_SYSTEM, user=user,
                                              schema=ACTION_SCHEMA, timeout=180)
        new_session = None

    intent = result.get("intent") or "question"
    text = result.get("answer") or ""
    action: dict = {"intent": intent}

    if intent == "add_task" and isinstance(result.get("task"), dict):
        # PROPOSED, not written. This used to write to the database
        # unconditionally and run the grounding check afterwards, on the
        # strength of a sentence in the prompt asking the model not to invent
        # dates. One misread intent — "should I add the robotics thing?" —
        # silently created homework no teacher assigned, with no confirmation
        # and no way to notice. mark_done validated its id all along; this is
        # the same standard applied to the other action.
        spec = result["task"]
        title = (spec.get("title") or "").strip()
        due = tasks_mod.normalize_due(spec.get("due_date"))
        proposed = {"title": title, "due_date": due,
                    "course": spec.get("course"),
                    "section": spec.get("section") if spec.get("section") in
                    (None, "school", "clubs", "upcoming") else None,
                    "notes": spec.get("notes"),
                    "category": spec.get("category")}
        if not title:
            action.update({"refused": "no title, so there was nothing to add"})
            text += "\n\n(I could not tell what to add, so I have not added anything.)"
        else:
            # A date the student never said is an invented date, prompt
            # instruction or not. If nothing date-shaped appears in what they
            # wrote, the proposal goes forward undated and says so.
            if due and not _mentions_a_date(message):
                proposed["due_date"] = None
                action["date_dropped"] = due
            action.update({"proposed": proposed})
    elif intent == "mark_done":
        target = result.get("done_item_id")
        known = {i["item_id"] for i in state.get("items", [])}
        if target in known:
            conn = db_mod.connect()
            db_mod.set_done(conn, target, True)
            conn.close()
            action.update({"marked_done": target})
            text += "\n\n✓ Marked done."
        else:
            action.update({"refused": "the id did not match anything in your data"})
            text += ("\n\n(I could not verify which item you meant, so nothing "
                     "was marked done — tap its Done button instead.)")

    verdict = grounding.check(text, state, question=message)
    return {"answer": text, "session_id": new_session or session_id,
            "provider": provider.name, "mode": "action", "action": action,
            **_verdict_fields(verdict)}


def answer_streaming(message: str, state: dict, session_id: str | None = None,
                     item_id: str | None = None):
    """Streaming: tokens already sent cannot be recalled, so grounding arrives
    as a terminal event and the UI stamps the finished bubble."""
    provider = detect.provider_for("chat")
    payload = build_payload(state, item_id)
    user = f"{payload}\n\n=== QUESTION ===\n{message}"
    final_text = ""
    final_session = session_id
    for event in provider.stream(system=SYSTEM, user=user, session_id=session_id):
        if event["type"] == "text":
            yield {"type": "text", "text": event["text"]}
        elif event["type"] == "result":
            final_text = event.get("text") or final_text
            final_session = event.get("session_id") or final_session
    verdict = grounding.check(final_text, state, question=message)
    yield {"type": "grounding", "session_id": final_session,
           "provider": provider.name, "mode": "stream",
           **_verdict_fields(verdict)}
