"""AnthropicApiProvider — used only if ANTHROPIC_API_KEY is ever present.
Kept minimal and dependency-free (httpx straight to the Messages API)."""

import base64
import json
import os

import httpx

from schooldash import config
from schooldash.ai import jsonshape
from schooldash.ai.base import ProviderError

API = "https://api.anthropic.com/v1/messages"
VERSION = "2023-06-01"


class AnthropicApiProvider:
    name = "anthropic_api"

    def __init__(self):
        self.key = os.environ.get("ANTHROPIC_API_KEY", "")
        alias = config.load()["ai"]["claude_model"]
        self.model = {"sonnet": "claude-sonnet-5", "opus": "claude-opus-5",
                      "haiku": "claude-haiku-4-5"}.get(alias, alias)

    def available(self) -> tuple[bool, str]:
        if not self.key:
            return False, "ANTHROPIC_API_KEY is not set"
        return True, "Anthropic API key present"

    def _call(self, system, messages, max_tokens, timeout):
        try:
            response = httpx.post(API, timeout=timeout, headers={
                "x-api-key": self.key, "anthropic-version": VERSION,
                "content-type": "application/json"},
                json={"model": self.model, "max_tokens": max_tokens,
                      "system": system or "", "messages": messages})
            response.raise_for_status()
        except httpx.HTTPError as exc:
            raise ProviderError(f"Anthropic API failed: {exc}") from exc
        blocks = response.json().get("content", [])
        return "".join(b.get("text", "") for b in blocks if b.get("type") == "text")

    def complete(self, *, system: str, user: str, max_tokens: int = 1024,
                 timeout: int = 120) -> str:
        return self._call(system, [{"role": "user", "content": user}],
                          max_tokens, timeout)

    def complete_vision(self, *, system: str, user: str,
                        images: list[tuple[str, bytes]],
                        max_tokens: int = 1500, timeout: int = 180) -> str:
        """The Messages API takes image blocks directly, so this one is the
        plain case — unlike the CLI, which needs a streaming input format."""
        if not images:
            raise ProviderError("no pictures were given to look at")
        content: list[dict] = [
            {"type": "image",
             "source": {"type": "base64", "media_type": media,
                        "data": base64.b64encode(raw).decode("ascii")}}
            for media, raw in images]
        content.append({"type": "text", "text": user})
        return self._call(system, [{"role": "user", "content": content}],
                          max_tokens, timeout)

    def complete_structured(self, *, system: str, user: str, schema: dict,
                            timeout: int = 240) -> dict:
        prompt = (f"{user}\n\nAnswer ONLY with a JSON object matching this "
                  f"schema, no prose:\n{json.dumps(schema)}")
        text = self._call(system, [{"role": "user", "content": prompt}],
                          4096, timeout).strip()
        if text.startswith("```"):
            text = text.strip("`")
            text = text[text.find("{"):text.rfind("}") + 1]
        try:
            parsed = json.loads(text)
        except ValueError as exc:
            raise ProviderError(f"API emitted non-JSON: {text[:200]!r}") from exc
        # The schema was pasted into the prompt and then never checked. Profiling
        # got away with it because profiling/schema.validate runs downstream; the
        # chat action path had no net at all.
        problems = jsonshape.errors(parsed, schema)
        if problems:
            raise ProviderError("API reply did not match the schema: "
                                + "; ".join(problems[:4]))
        return parsed

    def stream(self, *, system: str, user: str, session_id: str | None = None,
               max_tokens: int = 1024, timeout: int = 120):
        """Really streams, via the Messages API's SSE response.

        It used to satisfy the streaming interface by blocking for the whole
        answer and yielding it as one chunk. That is not a stream: the caller's
        whole reason for streaming — text on screen while the model is still
        talking — was silently unavailable, and only for this provider.

        A stream that dies mid-answer still has to produce a `result`, because
        the caller stamps grounding on whatever arrived; the partial text is
        returned with the error appended rather than thrown away.
        """
        collected: list[str] = []
        try:
            with httpx.stream("POST", API, timeout=timeout, headers={
                    "x-api-key": self.key, "anthropic-version": VERSION,
                    "content-type": "application/json"},
                    json={"model": self.model, "max_tokens": max_tokens,
                          "system": system or "", "stream": True,
                          "messages": [{"role": "user", "content": user}]}) as response:
                response.raise_for_status()
                for line in response.iter_lines():
                    if not line or not line.startswith("data:"):
                        continue
                    body = line[5:].strip()
                    if not body or body == "[DONE]":
                        continue
                    try:
                        event = json.loads(body)
                    except ValueError:
                        continue
                    if event.get("type") != "content_block_delta":
                        continue
                    piece = (event.get("delta") or {}).get("text") or ""
                    if piece:
                        collected.append(piece)
                        yield {"type": "text", "text": piece}
        except httpx.HTTPError as exc:
            note = f"\n\n(the answer was cut off: {exc})"
            collected.append(note)
            yield {"type": "text", "text": note}
        yield {"type": "result", "text": "".join(collected), "session_id": None}
