"""A small JSON-shape checker for model output.

Why this exists: a schema was being *sent* to the model and then never checked
on the way back. `AnthropicApiProvider.complete_structured` pasted the schema
into the prompt, called `json.loads`, and returned whatever parsed. Profiling
survived that because `profiling/schema.validate` runs downstream — the chat
action path had no such net, so a reply with `type` where `intent` belonged
reached the action dispatcher intact. [MEASURED] 2026-08-31: asking for JSON in
the prompt alone, 2 of 3 replies used the wrong key.

Only the subset of JSON Schema this project actually writes is implemented —
type, properties, required, enum, additionalProperties. Anything unrecognised
is ignored rather than guessed at, so this can only reject shapes it genuinely
understands.
"""

_TYPES = {
    "object": dict, "array": list, "string": str,
    "number": (int, float), "integer": int, "boolean": bool,
}


def _type_ok(value, spec) -> bool:
    names = spec if isinstance(spec, list) else [spec]
    for name in names:
        if name == "null":
            if value is None:
                return True
            continue
        expected = _TYPES.get(name)
        if expected is None:
            return True                      # unknown type name: do not judge
        if name == "number" and isinstance(value, bool):
            continue                         # bools are ints in Python, not numbers
        if name == "integer" and isinstance(value, bool):
            continue
        if isinstance(value, expected):
            return True
    return False


def errors(value, schema: dict, path: str = "") -> list[str]:
    """Every way `value` fails `schema`. Empty list means it fits."""
    out: list[str] = []
    if not isinstance(schema, dict):
        return out
    where = path or "the reply"

    if "type" in schema and not _type_ok(value, schema["type"]):
        out.append(f"{where} should be {schema['type']}, got "
                   f"{type(value).__name__}")
        return out                            # a wrong type makes the rest moot

    if "enum" in schema and value not in schema["enum"]:
        out.append(f"{where} should be one of {schema['enum']}, got {value!r}")

    if isinstance(value, dict):
        properties = schema.get("properties") or {}
        for name in schema.get("required") or []:
            if name not in value:
                out.append(f"{where} is missing required field {name!r}")
        if schema.get("additionalProperties") is False:
            for name in value:
                if name not in properties:
                    out.append(f"{where} has unexpected field {name!r}")
        for name, sub in properties.items():
            if name in value and value[name] is not None:
                out.extend(errors(value[name], sub, f"{where}.{name}"))
            elif name in value:
                out.extend(errors(value[name], sub, f"{where}.{name}"))

    if isinstance(value, list) and isinstance(schema.get("items"), dict):
        for n, entry in enumerate(value):
            out.extend(errors(entry, schema["items"], f"{where}[{n}]"))
    return out
