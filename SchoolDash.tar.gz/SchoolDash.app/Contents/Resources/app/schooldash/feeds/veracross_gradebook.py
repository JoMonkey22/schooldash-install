"""The per-assignment gradebook, read from Veracross — marks AND weights.

*"i want the grades and assignment grades to only be pulled from veracross not
canvas because how the classes are weighted is only in veracross"*

He is right, and it is measurable. [MEASURED] 2026-09-09, his account:

    Canvas    every course reported `group_weight` 0 and
              `apply_assignment_group_weights` false, and the whole gradebook
              held **0 per-assignment scores** across all ten courses
    Veracross Honors Biology — Classwork 50%, Quiz 30%, Lab 20% — with all
              eighteen marks, and 79.95x0.50 + 75.00x0.30 + 98.33x0.20
              = **82.14**, the exact percentage on the report card

**Why this was believed impossible, and what was actually wrong.** The
standing note said the Veracross gradebook "is not readable": the portal's
`/classes/<id>/grade_detail` returns ~33k of shell with zero tables, and no
XHR carrying the data ever fires. Both halves of that are true. The mistake
was the conclusion. The page is not fed by XHR at all — it nests an iframe,
and the grade detail is a *whole separate document* on a different host:

    portals.veracross.com/.../classes/<id>/grade_detail      the shell
      -> portals-embed.veracross.com/.../grade_detail        the frame
        -> documents.veracross.com/<school>/grade_detail/<id> the grades

That last document is server-rendered HTML with two real tables, and it can be
fetched straight from the signed-in session with no browser rendering at all.
Looking for the wrong mechanism cost this feature six days.

**No parameters.** The bare URL returns the CURRENT grading period. The portal
links carry `?grading_period=52&key=_`, and 52 is Semester 1 *this year* —
`grading_period=53` returns "Mid Semester 2" at 0.00% with four rows. Pinning
that number would have kept showing a finished semester after the roll-over,
so nothing is pinned and the document is asked what period it is.

**The two ways a class is weighted**, both verified against the reported grade:

    "Weighting by Assignment Type and Points"  weighted average of the
        category averages: sum(weight_i x average_i). Algebra:
        0.3125x100.00 + 0.6875x91.74 = 94.32 exactly.
    "Weighting by Assignment Points"           straight points:
        sum(earned) / sum(possible). English: 360/390 = 92.31 exactly.

**The weights are already renormalised, and that is a trap.** Honors Algebra
reports Homework 31.25% and Test 68.75% — a 5:11 ratio no teacher types. They
are the teacher's raw weights rescaled over only the categories that have work
so far (25:55 of an 80 that is missing a 20% category). So these are the
*effective* weights right now, correct for every mark that exists, and they
will shift on their own when an empty category gets its first assignment.
`renormalised` says so, and `weights_are_effective_now` is the flag the grade
page uses to keep the what-if calculator honest: a hypothetical mark in a
category that already has work is exact, and one in a category that does not
appear here cannot be modelled at all, because the raw weights are not on the
page in any form.
"""

import html as html_mod
import re
from decimal import Decimal, ROUND_HALF_UP

from schooldash import config
from schooldash.logging_setup import get
from schooldash.models import course_key_from_raw

log = get("vc-gradebook")

DOC_HOST = "https://documents.veracross.com"

# `<td class='points_earned number'>80.75</td>` — the class is the contract
# here, not the column order. Veracross drops the Weighting column entirely on
# a points-weighted class, so counting cells would read the wrong number.
CELL = re.compile(r"(?is)<t[dh][^>]*class=['\"]([^'\"]*)['\"][^>]*>(.*?)</t[dh]>")
ROW = re.compile(r"(?is)<tr([^>]*)>(.*?)</tr>")
TABLE = re.compile(r"(?is)<table[^>]*>.*?</table>")
GROUP_HEADER = re.compile(r"(?is)group_header")
SUBTOTAL = re.compile(r"(?is)subtotal")

METHOD = re.compile(
    r"(?is)assignment_grading_method['\"]?\s*>\s*Weighting by\s*(.*?)\s*</p>")
PERCENT = re.compile(r"(?is)ptd_grade['\"]\s*>\s*([\d.]+)")
LETTER = re.compile(r"(?is)letter_grade['\"]\s*>\s*([A-F][+-]?)")
PERIOD = re.compile(r"(?is)<h1>\s*(?:Grade Detail\s*-\s*)?(.*?)\s*</h1>")
# `<p><strong>Honors Biology</strong> - Mr. Roe</p>`. `[^<]` and not `.*?`:
# with DOTALL a lazy group still jumps the `</p>` and matched from the
# STUDENT's paragraph through to the class's, giving a name of "Alex Rivera -
# Grade 9 Honors Chemistry" and no teacher at all. The class line has no tags
# inside it, so say that.
COURSE_LINE = re.compile(r"(?is)<p>\s*<strong>\s*([^<]*?)\s*</strong>\s*-\s*([^<]*?)\s*</p>")
# "8 / 10", "8.5 / 10", and the ones that are not numbers at all.
SCORE_PAIR = re.compile(r"^\s*([\d.]+)\s*/\s*([\d.]+)\s*$")
ASSIGNMENT_COUNT = re.compile(r"\((\d+)\s+assignment")


def _text(markup: str) -> str:
    """Cell text with the tags gone. `<br />` inside a heading has to become a
    space, not nothing, or "Points<br/>Earned" reads as "PointsEarned"."""
    out = re.sub(r"(?is)<(script|style)[^>]*>.*?</\1>", " ", markup or "")
    out = re.sub(r"(?i)<br\s*/?>", " ", out)
    out = re.sub(r"(?s)<[^>]+>", " ", out)
    return re.sub(r"\s+", " ", html_mod.unescape(out)).strip()


def _number(value: str):
    match = re.search(r"-?\d+(?:\.\d+)?", (value or "").replace(",", ""))
    return float(match.group(0)) if match else None


def _cells(row_markup: str) -> dict:
    """Cells keyed by their class name, e.g. {"points_earned": "80.75"}."""
    found = {}
    for classes, inner in CELL.findall(row_markup):
        text = _text(inner)
        for name in classes.split():
            if name in ("number", "text", "alt"):
                continue
            found.setdefault(name, text)
    return found


def school_slug(portal: str = "") -> str:
    """`brophyprep` out of the configured portal URL."""
    portal = portal or (config.load()["veracross"]["portal"] or "")
    match = re.search(r"veracross\.com/([^/?#]+)", portal)
    return match.group(1) if match else ""


def doc_url(class_id, school: str = "") -> str:
    """No query string on purpose — see the module docstring."""
    return f"{DOC_HOST}/{school or school_slug()}/grade_detail/{class_id}"


def class_id_from(detail_url: str) -> str:
    match = re.search(r"/classes/(\d+)", detail_url or "")
    return match.group(1) if match else ""


def fetch(context, class_id, school: str = "") -> str:
    """The grade-detail document, or "" when the class has none.

    A class with no gradebook (his advisory, his sports team) answers 404, and
    that is a fact about the class rather than a failure — three of his ten do.
    """
    url = doc_url(class_id, school)
    try:
        response = context.request.get(url, timeout=30_000)
    except Exception as exc:  # noqa: BLE001 — one class, not the refresh
        log.info("grade detail for class %s could not be fetched: %s", class_id, exc)
        return ""
    if response.status == 404:
        return ""
    if not response.ok:
        log.info("grade detail for class %s returned %s", class_id, response.status)
        return ""
    try:
        return response.text()
    except Exception:  # noqa: BLE001
        return ""


def _kind_key(name: str) -> str:
    """A stable key for a category name. Used to line marks up with weights,
    so it must not collide: "Class Participation" and "Classwork" both start
    "class"."""
    return re.sub(r"[^a-z0-9]+", "-", (name or "").strip().lower()).strip("-") or "other"


def parse(markup: str, course_key: str = "", display_name: str = "") -> dict:
    """One class's gradebook: how it is weighted, and every mark in it."""
    if not markup or "assignment_grading_method" not in markup:
        return {}

    method_text = _text(METHOD.search(markup).group(1)) if METHOD.search(markup) else ""
    # "Assignment Type and Points" vs "Assignment Points". The distinction is
    # the presence of *Type*, not the wording around it.
    by_type = "type" in method_text.lower()

    percent = _number(PERCENT.search(markup).group(1)) if PERCENT.search(markup) else None
    letter_match = LETTER.search(markup)
    period = _text(PERIOD.search(markup).group(1)) if PERIOD.search(markup) else ""

    teacher = ""
    for name, who in COURSE_LINE.findall(markup):
        name, who = _text(name), _text(who)
        if name and who and "Grade " not in name:
            display_name = display_name or name
            teacher = who
            break

    tables = TABLE.findall(markup)
    groups, scores = [], []

    # ---- table 0: the category summary, which is where the weights live
    if tables:
        for attrs, body in ROW.findall(tables[0]):
            cells = _cells(body)
            name = cells.get("description", "")
            if not name or "Assignment Type" in name:
                continue
            weight = _number(cells.get("weight", "")) if "weight" in cells else None
            count = ASSIGNMENT_COUNT.search(name)
            groups.append({
                "id": _kind_key(name.split("(")[0]),
                "name": name.split("(")[0].strip(),
                "weight": weight,
                "earned": _number(cells.get("points_earned", "")),
                "possible": _number(cells.get("points_possible", "")),
                "average": _number(cells.get("average", "")),
                "count": int(count.group(1)) if count else None,
            })

    # ---- table 1: every mark, under a `group_header` row naming its category
    if len(tables) > 1:
        category = ""
        for attrs, body in ROW.findall(tables[1]):
            if GROUP_HEADER.search(attrs):
                category = _text(body)
                continue
            if SUBTOTAL.search(attrs):
                continue                      # Veracross's own per-category total
            cells = _cells(body)
            title = cells.get("assignment", "")
            if not title or "Assignment" == title:
                continue
            score_text = cells.get("score", "")
            pair = SCORE_PAIR.match(score_text)
            earned = _number(cells.get("points_earned", ""))
            possible = _number(cells.get("points_possible", ""))
            # Trust the points columns over the Score cell: a "Complete" mark
            # has no numerator to parse but still carries real points, and it
            # is Veracross's own points that add up to the reported grade.
            score = earned if earned is not None else (
                _number(pair.group(1)) if pair else None)
            if possible is None and pair:
                possible = _number(pair.group(2))
            graded = bool(pair) or (score is not None and score > 0)
            scores.append({
                "title": title,
                "category": _kind_key(category),
                "category_name": category,
                "group_id": _kind_key(category),
                "score": score,
                "possible": possible,
                "percent": _number(cells.get("grade", "")),
                "due": cells.get("due_date", ""),
                "score_text": score_text,
                "graded": graded,
                "omit": False,
                # A mark whose Score says something but earns nothing, out of
                # points that still count. [MEASURED] Biology's "Notes Ch 2.3"
                # reads "Complete" and scores 0.00 of 10, which on its own
                # costs the class ~5 points. Worth pointing at, never worth
                # quietly dropping or quietly averaging.
                "check": bool(score_text and not pair and not (score or 0)
                              and (possible or 0) > 0),
            })

    weight_sum = sum(g["weight"] or 0 for g in groups)
    return {
        "course_key": course_key or course_key_from_raw(display_name),
        "display_name": display_name,
        "teacher": teacher,
        "source": "veracross",
        "period": period,
        "method": "type" if by_type else "points",
        "method_label": ("Weighting by " + method_text) if method_text else "",
        # `weighted` and `groups` keep the shape the grade page already reads,
        # so there is still exactly ONE grade formula in the front end.
        "weighted": bool(by_type and any(g["weight"] for g in groups)),
        "percent": percent,
        "letter": _text(letter_match.group(1)) if letter_match else None,
        "groups": groups,
        "scores": scores,
        # Veracross rescales the weights over the categories that have work,
        # so they sum to 100 with a category missing. See the docstring.
        "renormalised": bool(by_type and 99.0 <= weight_sum <= 101.0
                             and any(g["count"] for g in groups)),
        "weights_are_effective_now": bool(by_type),
    }


def _round2(value: float) -> float:
    """Half-UP, the way a gradebook rounds.

    [MEASURED] 2026-09-09: Scripture is 72.5/80 = 90.625, and Veracross shows
    **90.63**. Python's round() is half-to-EVEN and gives 90.62, so the
    recomputed total disagreed with the number printed beside it by a cent —
    which on a grade page reads as a bug in the app, not a rounding
    convention, and would make the what-if calculator look untrustworthy on
    exactly the marks where it matters.
    """
    return float(Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def total_percent(record: dict) -> float | None:
    """Recompute the class percentage from the marks, Veracross's own way.

    This exists so the what-if calculator uses the SAME arithmetic that
    produced the number already on screen. Both branches were checked against
    the reported grade on four classes each; if this ever disagrees with
    `record["percent"]` the page says so rather than picking a winner.
    """
    groups = record.get("groups") or []
    if record.get("method") == "type":
        total = 0.0
        weight_used = 0.0
        for group in groups:
            weight, possible = group.get("weight"), group.get("possible")
            if not weight or not possible:
                continue
            earned = group.get("earned") or 0
            total += (weight / 100.0) * (earned / possible * 100.0)
            weight_used += weight
        if not weight_used:
            return None
        # Guard against a class whose listed weights do not reach 100 — the
        # renormalisation is Veracross's, and this must not invent a different
        # one silently.
        return _round2(total * (100.0 / weight_used)) if weight_used else None
    earned = sum(g.get("earned") or 0 for g in groups)
    possible = sum(g.get("possible") or 0 for g in groups)
    return _round2(earned / possible * 100.0) if possible else None
