"""The two thin, no-session feeds: Veracross assignments (behind a config
flag, lowest precedence) and the Canvas personal iCal (the fallback when the
browser session is dead, so a refresh still produces something)."""

import re
from datetime import datetime

import httpx

from schooldash import config, models, timezones
from schooldash.feeds import ical
from schooldash.logging_setup import get

log = get("veracross")


def _fetch(url: str) -> str:
    response = httpx.get(url, timeout=30, follow_redirects=True,
                         headers={"User-Agent": "schooldash/0.1"})
    response.raise_for_status()
    return response.text


def _course_from_summary(summary: str) -> tuple[str, str]:
    """Canvas iCal summaries end with '[Course Name]'."""
    match = re.search(r"\[([^\]]+)\]\s*$", summary or "")
    if match:
        return summary[: match.start()].strip(), match.group(1).strip()
    return summary or "", ""


def _event_to_item(event: dict, *, source: str, date_note: str,
                   confidence: str, kind: str) -> models.Item | None:
    title, course = _course_from_summary(event.get("summary", ""))
    if not title:
        return None
    stamp = event.get("dtstart")
    due = due_date = None
    all_day = bool(event.get("all_day"))
    if isinstance(stamp, datetime):
        local = timezones.to_local(stamp)
        due, due_date = local.isoformat(), local.date().isoformat()
    elif stamp is not None:  # a plain date (all-day)
        due_date = stamp.isoformat()
    url = event.get("url") or ""
    if not url:
        match = re.search(r"https?://\S+", event.get("description", "") or "")
        url = match.group(0) if match else ""
    item = models.Item(
        source=source,
        course_key=models.course_key_from_raw(course),
        course=course or "(no course)",
        title=title[:110],
        detail=event.get("description", "") or title,
        raw_cell=event.get("summary", ""),
        kind=kind,
        due=due,
        due_date=due_date,
        all_day=all_day,
        date_note=date_note,
        confidence=confidence,
        extractor="canvas_stated",
        url=url or None,
        links=[models.Link(url=url, text=title,
                           kind="canvas" if "instructure" in url else "other")]
        if url else [],
    )
    return item.finalize()


def assignments_items() -> list[models.Item]:
    """The thin Veracross assignments feed (~11 items). Config-gated."""
    cfg = config.load()
    if not cfg["sources"]["veracross_assignments"]:
        return []
    url = cfg["veracross"]["assignments_ics"]
    if not url:
        return []
    try:
        events = ical.parse(_fetch(url))
    except (httpx.HTTPError, OSError) as exc:
        log.warning("veracross assignments feed failed: %s", type(exc).__name__)
        return []
    items = []
    for event in events:
        item = _event_to_item(
            event, source="veracross",
            date_note="Veracross assignment date", confidence="high",
            kind="veracross assignment")
        if item:
            items.append(item)
    return items


def canvas_ics_items() -> list[models.Item]:
    """The Canvas personal calendar feed — the session-down fallback (§4.5)."""
    cfg = config.load()
    url = cfg["canvas_ics"]
    if not url or not cfg["sources"]["canvas_ics_fallback"]:
        return []
    try:
        events = ical.parse(_fetch(url))
    except (httpx.HTTPError, OSError) as exc:
        log.warning("canvas ics fallback failed: %s", type(exc).__name__)
        return []
    items = []
    for event in events:
        item = _event_to_item(
            event, source="canvas_ics",
            date_note="from the Canvas calendar feed; the browser session was "
                      "unavailable, so points and submitted-status are missing",
            confidence="medium",
            kind="assignment")
        if item:
            items.append(item)
    return items
