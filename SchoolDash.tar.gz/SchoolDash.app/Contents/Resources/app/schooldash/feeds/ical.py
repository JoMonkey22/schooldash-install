"""A tolerant ~150-line iCalendar parser.

Deliberately not a general library: it handles exactly the gotchas these feeds
exhibit — folded continuation lines (unfold BEFORE splitting on ':'), escaped
text, VALUE=DATE all-day stamps, UTC 'Z' stamps, and TZID parameters — and
nothing else. More predictable and more testable than a dependency here.
"""

import re
from datetime import date, datetime
from zoneinfo import ZoneInfo

from schooldash import timezones


class FeedError(RuntimeError):
    """.fix is the one-line remedy, and it depends on the cause.

    A missing feed URL and a dropped wifi connection are both FeedError, and
    both used to be reported with "setup --import-legacy" — which is useless
    advice for a network blip and sends someone re-importing a config that was
    never the problem.
    """

    def __init__(self, message, fix=""):
        super().__init__(message)
        self.fix = fix


def unfold(text: str) -> str:
    """A line beginning with space/tab continues the previous line. FIRST."""
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    return re.sub(r"\n[ \t]", "", text)


def unescape(value: str) -> str:
    out = []
    i = 0
    while i < len(value):
        ch = value[i]
        if ch == "\\" and i + 1 < len(value):
            nxt = value[i + 1]
            out.append({"n": "\n", "N": "\n", ",": ",", ";": ";", "\\": "\\"}.get(nxt, nxt))
            i += 2
        else:
            out.append(ch)
            i += 1
    return "".join(out)


def _parse_stamp(value: str, params: dict, tz) -> tuple[object, bool]:
    """Returns (date-or-aware-datetime, all_day)."""
    value = value.strip()
    if params.get("VALUE") == "DATE" or re.fullmatch(r"\d{8}", value):
        return date(int(value[:4]), int(value[4:6]), int(value[6:8])), True
    match = re.fullmatch(r"(\d{8})T(\d{6})(Z?)", value)
    if not match:
        raise ValueError(f"unrecognized iCal stamp: {value!r}")
    stamp = datetime.strptime(match.group(1) + match.group(2), "%Y%m%d%H%M%S")
    if match.group(3) == "Z":
        stamp = stamp.replace(tzinfo=ZoneInfo("UTC"))
    elif params.get("TZID"):
        try:
            stamp = stamp.replace(tzinfo=ZoneInfo(params["TZID"]))
        except KeyError:
            stamp = stamp.replace(tzinfo=tz)
    else:
        stamp = stamp.replace(tzinfo=tz)
    return stamp.astimezone(tz), False


TEXT_PROPS = {"SUMMARY", "LOCATION", "DESCRIPTION", "UID", "URL"}


def parse(text: str, tz=None) -> list[dict]:
    """iCalendar text -> [{summary, dtstart, dtend, all_day, location, ...}].

    dtstart/dtend are tz-aware local datetimes, or plain dates for all-day
    events (all_day True). Unparseable stamps skip the property, never crash.
    """
    tz = tz or timezones.zone()
    events: list[dict] = []
    current: dict | None = None

    for line in unfold(text).split("\n"):
        if not line.strip() or ":" not in line:
            continue
        head, _, value = line.partition(":")
        parts = head.split(";")
        name = parts[0].upper().strip()
        params = {}
        for raw in parts[1:]:
            key, _, val = raw.partition("=")
            if key:
                params[key.upper().strip()] = val.strip().strip('"')

        if name == "BEGIN" and value.strip().upper() == "VEVENT":
            current = {"all_day": False}
        elif name == "END" and value.strip().upper() == "VEVENT":
            if current is not None:
                events.append(current)
            current = None
        elif current is not None:
            if name in ("DTSTART", "DTEND"):
                try:
                    stamp, all_day = _parse_stamp(value, params, tz)
                except ValueError:
                    continue
                current[name.lower()] = stamp
                if all_day:
                    current["all_day"] = True
            elif name in TEXT_PROPS:
                current[name.lower()] = unescape(value).strip()
    return events
