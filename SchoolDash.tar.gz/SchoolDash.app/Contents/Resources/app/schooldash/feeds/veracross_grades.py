"""Course grades, read from the Veracross student portal.

The project spent its whole life saying grades were impossible. That was true
of *Canvas* — the school disables the endpoint that would supply them — and it
was never checked against Veracross, which puts a letter and a percentage next
to every course on the portal home page. [MEASURED] 2026-08-26: ten courses
carried a `.course-grade` element, seven of them with a real grade.

Two rules this module exists to keep:

**A grade is never invented.** A course with no graded work yet shows 0.0% in
the portal, which is indistinguishable from a real zero if you only read the
number. Anything the portal shows without a letter is reported as
`graded=False` and rendered as "no graded work yet", never as 0%. Telling a
student they have a zero when they do not is the single worst thing this
feature could do.

**Grades never leave the machine.** The published snapshot is deliberately
built without them — see publish.py. They are read from the student's own
signed-in session and written only to local state.
"""

import re
from dataclasses import dataclass, asdict
from datetime import datetime

from bs4 import BeautifulSoup

from schooldash import browser, config, timezones
from schooldash.logging_setup import get
from schooldash.models import course_key_from_raw

log = get("grades")

# "A 96.44%", "B+ 87.57%", "0.0%", "A-", "" — letter optional, percent optional.
GRADE_TEXT = re.compile(
    r"^\s*(?:(?P<letter>[A-F][+-]?)\s*)?(?:(?P<percent>\d+(?:\.\d+)?)\s*%)?\s*$")


@dataclass
class Grade:
    course_key: str
    display_name: str
    letter: str | None
    percent: float | None
    graded: bool
    detail_url: str | None
    fetched_at: str

    def as_dict(self) -> dict:
        return asdict(self)


def _absolute(href: str | None) -> str | None:
    """Portal links are usually relative; a relative href is useless to the
    dashboard, which is served from 127.0.0.1."""
    if not href:
        return None
    href = href.strip()
    if href.startswith(("http://", "https://")):
        return href
    if href.startswith("//"):
        return "https:" + href
    base = (config.load()["veracross"]["portal"] or "").rstrip("/")
    if not base:
        return None
    # A root-relative href joins the ORIGIN, not the portal path. Appending it
    # to the whole base produced .../brophyprep/student/student/course/123.
    if href.startswith("/"):
        from urllib.parse import urlsplit
        parts = urlsplit(base)
        return f"{parts.scheme}://{parts.netloc}{href}"
    return base + "/" + href


def _course_name_for(node) -> str | None:
    """The course a `.course-grade` belongs to.

    The grade element holds only the grade, so the name comes from the card
    around it. Walking up beats a fixed selector: the portal nests each course
    in a generic grid whose class names carry no meaning, and the depth of the
    grade inside it is not the same for every course.
    """
    current = node
    for _ in range(8):
        current = current.parent
        if current is None:
            return None
        for candidate in current.select(
                "h1, h2, h3, h4, .course-name, [class*=title], [class*=name]"):
            text = " ".join(candidate.get_text(" ", strip=True).split())
            # Skip the grade itself, which also lives under a *name*-ish class.
            if len(text) > 2 and not GRADE_TEXT.match(text):
                return text
    return None


def parse_grades(html: str, now: str | None = None) -> list[Grade]:
    """Every course grade on the portal home page.

    Pure, so the parser is tested against a saved page rather than against the
    school's live server — the portal is behind a login no test can hold.
    """
    stamp = now or datetime.now(timezones.zone()).isoformat(timespec="seconds")
    soup = BeautifulSoup(html or "", "lxml")
    grades: list[Grade] = []

    for node in soup.select(".course-grade"):
        raw = " ".join(node.get_text(" ", strip=True).split())
        match = GRADE_TEXT.match(raw)
        if match is None:
            log.debug("unrecognised grade text: %r", raw)
            continue

        name = _course_name_for(node)
        if not name:
            continue

        letter = match.group("letter")
        percent = float(match.group("percent")) if match.group("percent") else None

        # A course with nothing graded yet reports 0.0% and no letter. That is
        # not a zero, and showing it as one would be a lie the student would
        # believe. The letter is what separates "scored zero" from "not scored".
        graded = bool(letter)

        # The link can sit on the grade itself or on the card around it, and
        # it is often relative. [MEASURED] 2026-09-01: on this school's portal
        # there is no per-course anchor at all, so this is frequently None and
        # the dashboard falls back to the portal front page — which still lands
        # the student where the real grade lives.
        anchor = node.find("a", href=True)
        if anchor is None:
            hunt = node
            for _ in range(4):
                hunt = getattr(hunt, "parent", None)
                if hunt is None or not hasattr(hunt, "find"):
                    break
                anchor = hunt.find("a", href=True)
                if anchor is not None:
                    break
        grades.append(Grade(
            course_key=course_key_from_raw(name),
            display_name=name,
            letter=letter,
            percent=percent if graded else None,
            graded=graded,
            detail_url=_absolute(anchor["href"]) if anchor else None,
            fetched_at=stamp,
        ))

    log.info("parsed %d course grade(s), %d with a grade so far",
             len(grades), sum(1 for g in grades if g.graded))
    return grades


def fetch_grades(context) -> list[Grade]:
    """Read the portal home page through the signed-in browser session."""
    portal = config.load()["veracross"]["portal"].rstrip("/")
    page = context.new_page()
    try:
        page.goto(portal, wait_until="domcontentloaded", timeout=60_000)
        # An expired portal session redirects to accounts.veracross.com rather
        # than erroring, and that page has no .course-grade nodes — so it used
        # to parse to zero grades and return silently, indistinguishable from a
        # student with nothing graded yet. The dashboard then said "no grades
        # read yet — press Refresh", which is a lie: no number of refreshes can
        # fix a signed-out session. Checked before parsing, and raised, because
        # the pipeline already knows how to report a dead session with a fix.
        landed = page.url or ""
        if "accounts.veracross" in landed or "/login" in landed:
            raise browser.SessionError(
                "the Veracross portal session is expired or missing",
                fix="python run.py login --veracross")
        # The course cards render client-side; without settling, the page is a
        # shell and every course looks ungraded.
        try:
            page.wait_for_selector(".course-grade", timeout=20_000)
        except Exception:  # noqa: BLE001 — a portal with no grades is valid
            log.info("no .course-grade elements appeared on the portal")
        return parse_grades(page.content())
    finally:
        page.close()


def summarise(grades: list[Grade]) -> dict:
    """What the dashboard shows above the per-course list.

    No GPA. Converting these percentages into one number needs the school's
    scale and each course's credit weight, and neither is on the portal —
    a GPA computed without them would look authoritative and be wrong.
    """
    scored = [g for g in grades if g.graded and g.percent is not None]
    return {
        "courses": len(grades),
        "graded": len(scored),
        "ungraded": len(grades) - len(scored),
        "lowest": min((g.percent for g in scored), default=None),
        "highest": max((g.percent for g in scored), default=None),
    }
