"""Canvas via the browser session: planner items, course cards, homepages.

The planner is precise but incomplete — it carries points, submitted-status,
type, and canonical links, and about a quarter of the real workload. On an
expired session it fails loudly and specifically, and the caller lets the doc
half of the run complete regardless.
"""

import json
import re
from datetime import date, timedelta
from urllib.parse import urljoin

from schooldash import config, models, timezones
from schooldash.browser import SessionError, strip_while1
from schooldash.logging_setup import get

log = get("canvas")

NEXT_LINK = re.compile(r'<([^>]+)>;\s*rel="next"')


class CanvasRefused(RuntimeError):
    """Canvas said no to this request, with a session that is working.

    Kept apart from SessionError on purpose. A SessionError means "sign in
    again" and, inside a refresh, drops the Canvas half to the calendar-feed
    fallback with no points and no submitted status. That is the right answer
    to an expired session and the wrong answer to one endpoint the student
    simply cannot read.
    """


def _session_alive(context, timeout: int = 20_000) -> bool:
    """The cheapest question Canvas answers for a signed-in student."""
    host = config.load()["canvas"]["host"].rstrip("/")
    try:
        probe = context.request.get(f"{host}/api/v1/users/self", timeout=timeout)
    except Exception:  # noqa: BLE001 — no answer is not evidence of a session
        return False
    return bool(getattr(probe, "ok", False))


def _get_json(context, url: str, timeout: int = 45_000):
    """One session GET -> (parsed json, next_url or None).

    Raises SessionError when the session is the problem, so the caller can
    render the exact fix, and CanvasRefused when it is not.

    [MEASURED] 2026-09-02: Canvas caps `context_codes` at ten, so asking about
    fourteen courses at once returned 403 — and this reported "Canvas rejected
    the saved session (expired or logged out)" with the fix "python run.py
    login", while `/users/self` and the planner both answered normally in the
    same second. Signing in again could not have helped, and inside a refresh
    that misreading costs the whole Canvas half.
    """
    response = context.request.get(url, timeout=timeout)
    if response.status == 401:
        # 401 needs no second opinion, and a refresh should not pay for one.
        raise SessionError(
            "Canvas rejected the saved session (expired or logged out)",
            fix="python run.py login")
    if response.status == 403:
        if _session_alive(context):
            raise CanvasRefused(
                f"Canvas refused this request (403) with a working session: {url}")
        raise SessionError(
            "Canvas rejected the saved session (expired or logged out)",
            fix="python run.py login")
    if not response.ok:
        raise SessionError(f"Canvas returned HTTP {response.status} for {url}")
    text = strip_while1(response.text())
    try:
        data = json.loads(text)
    except ValueError as exc:
        if "login" in (response.url or ""):
            raise SessionError(
                "Canvas redirected to a login page — the session is expired",
                fix="python run.py login") from exc
        raise SessionError(f"Canvas sent non-JSON for {url}") from exc
    link_header = response.headers.get("link", "")
    match = NEXT_LINK.search(link_header)
    return data, (match.group(1) if match else None)


def planner_items_raw(context, start: date, end: date) -> list[dict]:
    """Every page of /api/v1/planner/items for the window."""
    host = config.load()["canvas"]["host"].rstrip("/")
    url = (f"{host}/api/v1/planner/items?start_date={start.isoformat()}"
           f"&end_date={end.isoformat()}&per_page=100")
    items: list[dict] = []
    pages = 0
    while url and pages < 20:
        data, url = _get_json(context, url)
        if isinstance(data, list):
            items.extend(data)
        pages += 1
    log.info("planner: %d items over %d page(s)", len(items), pages)
    return items


SKIP_PLANNER_KINDS = {"announcement", "calendar_event"}


# Software requirements a teacher appends to a title. [MEASURED] 2026-09-02:
# six of his Canvas items end in some spelling of "- Requires Respondus
# LockDown Browser", 37 characters of it, in a title with about 40 usable
# characters on his window — it pushed the actual name of the quiz out of
# view and made three different quizzes look like one item.
#
# A fact about the software, not about the work. The full title stays in
# `detail`, so he can still see that the quiz needs LockDown Browser.
# Kept here rather than imported from scoring, which imports nothing from the
# feeds: the two lists are asserted equal by a test so they cannot drift.
PROCTORED_MARKERS = ("lockdown browser", "respondus")


def scoring_produced() -> set:
    from schooldash import scoring

    return scoring.PRODUCED


RE_TITLE_BOILERPLATE = re.compile(
    r"\s*[-–—:(]*\s*requires?\s+(?:respondus\s+)?lock\s*down\s+browser"
    r"(?:\s*\+\s*monitor)?\s*\)?\s*$", re.I)


def clean_title(title: str) -> str:
    """The work's name, without the software it happens to need."""
    text = (title or "").strip()
    stripped = RE_TITLE_BOILERPLATE.sub("", text).strip(" -–—:")
    # A title that is ONLY the requirement keeps it: stripping would leave
    # nothing, and an item with no name is worse than an ugly one.
    return stripped or text


# Which submission states mean "he has handed this in". `pending_review` is a
# quiz waiting on a human to mark it — done, from his point of view, and the
# distinction matters because an item shown as outstanding when it is finished
# is the fastest way to make a board untrustworthy.
DONE_STATES = {"submitted", "graded", "pending_review"}


def assignments_raw(context, course_id: str) -> list[dict]:
    """Every page of /api/v1/courses/<id>/assignments, with submissions.

    The authoritative list, and the reason this exists next to the planner.
    [MEASURED] 2026-09-02, against his nine real courses: Canvas held 41
    published assignments; the planner returned 24 items for a 14-day window,
    and 14 of the dated assignments missing from the board were absent from
    the planner response altogether. The planner is a calendar — it carries
    the student's own dated view and nothing else — so an assignment with no
    due date cannot appear in it at all, however overdue the work is.
    """
    host = config.load()["canvas"]["host"].rstrip("/")
    url = (f"{host}/api/v1/courses/{course_id}/assignments"
           "?per_page=100&include[]=submission&include[]=all_dates")
    out: list[dict] = []
    pages = 0
    while url and pages < 12:
        data, url = _get_json(context, url)
        if isinstance(data, list):
            out.extend(data)
        pages += 1
    log.info("assignments: course %s -> %d over %d page(s)",
             course_id, len(out), pages)
    return out


def items_from_assignments(raw: list[dict], course: str, today: date,
                           days_back: int = 8,
                           days_forward: int = 14) -> list[models.Item]:
    """Map the assignments endpoint to Items.

    What is shown, and why:

    * **Work he still owes is shown however far ahead it is**, dated or not.
      That is the whole point: "Side Hustle Proposal", 100 points, due in 23
      days and unsubmitted, was invisible because the fetch window was 14.
      Behind, everything obeys the same `days_back` floor: work missed three
      weeks ago cannot be handed in, and a permanent block of red at the top
      of the board is its own kind of lie.
    * **Work he has finished is shown only inside the window** — recent
      enough to be context, not a term of history. This is also what keeps
      the end-of-term running logs ("Warm Up Board", due 2026-12-18, already
      graded) off a September board without a special case for them.
    * **Undated and finished is not shown at all.** Five of his six undated
      assignments are graded; an undated finished thing is not a task, and an
      undated item lingers until it is retired.
    * **Unpublished is never shown.** A draft is not work yet.
    """
    host = config.load()["canvas"]["host"].rstrip("/")
    floor = (today - timedelta(days=days_back)).isoformat()
    ceiling = (today + timedelta(days=days_forward)).isoformat()
    out: list[models.Item] = []
    for entry in raw or []:
        if not entry.get("published", True):
            continue
        raw_title = (entry.get("name") or "").strip()
        if not raw_title:
            continue
        # Read the facts out of the raw title BEFORE cleaning it: the
        # LockDown Browser phrase is the strongest evidence a title carries
        # (scoring.PROCTORED), and stripping it as boilerplate would throw
        # away what it proved.
        proctored = any(m in raw_title.lower() for m in PROCTORED_MARKERS)
        title = clean_title(raw_title)

        submission = entry.get("submission") or {}
        state = (submission.get("workflow_state") or "").lower()
        # No submission block means Canvas did not tell us, and guessing
        # "done" hides real work. Only one of the two errors is safe.
        submitted = state in DONE_STATES

        stamp = entry.get("due_at")
        due = due_date = None
        all_day = False
        if stamp:
            local = timezones.to_local(stamp)
            due = local.isoformat()
            due_date = local.date().isoformat()
            all_day = local.hour == 0 and local.minute == 0
            # No horizon ahead — unfinished work is unfinished, and hiding a
            # 100-point project because it is 23 days out was the defect that
            # started this. Behind, the same floor as everything else: an
            # assignment from three weeks ago that was never handed in cannot
            # be handed in now, and `_within_reach` names what showing it
            # produces — "a permanent block of false overdue at the top of the
            # board".
            if due_date < floor:
                continue
            if submitted and due_date > ceiling:
                continue
        elif submitted:
            continue

        quiz = bool(entry.get("quiz_id") or entry.get("is_quiz_assignment")
                    or proctored)
        # What Canvas says he has to hand in, which decides whether a title
        # containing "video" or "watch" is something to consume or to produce.
        produced = {t for t in (entry.get("submission_types") or [])
                    if t in scoring_produced()}
        url = entry.get("html_url") or ""
        if url:
            url = urljoin(host + "/", url)
        note = ("Canvas due date" if due_date else
                "Canvas lists this with no due date, and it is not handed in yet")
        item = models.Item(
            source="canvas",
            course_key=models.course_key_from_raw(course),
            course=course,
            title=title[:110],
            detail=raw_title,
            raw_cell=json.dumps({"assignment_id": entry.get("id"),
                                 "due_at": entry.get("due_at"),
                                 "workflow_state": state or None,
                                 "quiz_id": entry.get("quiz_id")}),
            kind="quiz" if quiz else "assignment",
            due=due,
            due_date=due_date,
            all_day=all_day,
            date_note=note,
            confidence="high",
            extractor="canvas_stated",
            points=entry.get("points_possible"),
            submitted=submitted,
            url=url or None,
            flags=["must_submit"] if produced else [],
            links=[models.Link(url=url, text=title, kind="canvas")] if url else [],
        )
        out.append(item.finalize())
    return out


def items_from_planner(raw: list[dict]) -> list[models.Item]:
    """Map planner JSON to Items. Dates convert to Phoenix FIRST (spec §4.6)."""
    host = config.load()["canvas"]["host"].rstrip("/")
    out: list[models.Item] = []
    for entry in raw:
        plannable = entry.get("plannable") or {}
        kind = (entry.get("plannable_type") or "").replace("_", " ")
        if kind.replace(" ", "_") in SKIP_PLANNER_KINDS:
            continue
        raw_title = plannable.get("title") or plannable.get("name") or ""
        if not raw_title:
            continue
        title = clean_title(raw_title)
        course = entry.get("context_name") or ""
        stamp = plannable.get("due_at") or entry.get("plannable_date")
        due = due_date = None
        all_day = False
        if stamp:
            local = timezones.to_local(stamp)
            due = local.isoformat()
            due_date = local.date().isoformat()
            all_day = local.hour == 0 and local.minute == 0
        submissions = entry.get("submissions")
        submitted = None
        if isinstance(submissions, dict):
            submitted = bool(submissions.get("submitted"))
        url = entry.get("html_url") or plannable.get("html_url") or ""
        if url:
            url = urljoin(host + "/", url)
        item = models.Item(
            source="canvas",
            course_key=models.course_key_from_raw(course),
            course=course,
            title=title[:110],
            detail=raw_title,
            raw_cell=json.dumps({k: entry.get(k) for k in
                                 ("plannable_type", "plannable_date", "context_name")}),
            kind=kind or "assignment",
            due=due,
            due_date=due_date,
            all_day=all_day,
            date_note="Canvas due date",
            confidence="high",
            extractor="canvas_stated",
            points=plannable.get("points_possible"),
            submitted=submitted,
            url=url or None,
            links=[models.Link(url=url, text=title, kind="canvas")] if url else [],
        )
        out.append(item.finalize())
    return out


def scores_from_assignments(raw: list[dict], course: str) -> list[dict]:
    """Every assignment Canvas has actually put a score on, with its kind.

    *"add a summery of what type of assighnments i am bad at and what I am
    good at"*. This is the honest basis for that, and it is real: [MEASURED]
    2026-09-03, twelve of fifteen Honors Biology assignments carry a score,
    and four of six in Spanish 1 — where the two quizzes are 60% and 70%
    while the test is 89%. That is a pattern from marks, not a guess from a
    single course percentage.

    What it is NOT: the Veracross gradebook. These are the Canvas-graded
    pieces only, and Canvas does not say how much each category counts
    towards the report-card grade. So a summary built from this may say "your
    quizzes come out lower than your tests" — a fact about the scores — and
    must not say "quizzes are dragging your grade down", which needs weights
    nobody here can read.
    """
    from schooldash import scoring

    out: list[dict] = []
    for entry in raw or []:
        submission = entry.get("submission") or {}
        score = submission.get("score")
        possible = entry.get("points_possible")
        if score is None or not possible:
            continue
        title = (entry.get("name") or "").strip()
        if not title:
            continue
        kind = "quiz" if (entry.get("quiz_id")
                          or entry.get("is_quiz_assignment")) else "assignment"
        out.append({
            "course_key": models.course_key_from_raw(course),
            "title": clean_title(title)[:90],
            "category": scoring.categorize(title, kind=kind),
            "score": float(score),
            "possible": float(possible),
            "percent": round(float(score) / float(possible) * 100, 1),
            "graded_at": submission.get("graded_at"),
            "url": entry.get("html_url") or None,
            # Which assignment group Canvas files this under, so the grade
            # page can weight it the way Canvas does (see gradebook_from).
            # `omit` marks work Canvas itself leaves out of the final grade —
            # a running log, a practice set — which must not be given a share.
            "assignment_id": entry.get("id"),
            "group_id": entry.get("assignment_group_id"),
            "omit": bool(entry.get("omit_from_final_grade")),
            "due_at": entry.get("due_at"),
        })
    return out


def assignment_groups_raw(context, course_id: str) -> list[dict]:
    """Every assignment group in the course, with its weight.

    /api/v1/courses/<id>/assignment_groups returns `group_weight` per group,
    and the course itself says whether those weights are applied
    (`apply_assignment_group_weights`). Together they are the only readable
    statement of how much a kind of work counts — the Veracross gradebook
    renders inside its own SPA and comes back as an empty shell ([MEASURED]
    2026-09-03). One request per course, no pagination in practice.
    """
    host = config.load()["canvas"]["host"].rstrip("/")
    url = f"{host}/api/v1/courses/{course_id}/assignment_groups?per_page=100"
    out: list[dict] = []
    pages = 0
    while url and pages < 5:
        data, url = _get_json(context, url)
        if isinstance(data, list):
            out.extend(data)
        pages += 1
    return out


def course_grade_raw(context, course_id: str) -> dict:
    """The course record with the student's own enrollment and Canvas's
    computed current score — the number the weights below add up to."""
    host = config.load()["canvas"]["host"].rstrip("/")
    data, _ = _get_json(
        context, f"{host}/api/v1/courses/{course_id}?include[]=total_scores")
    return data if isinstance(data, dict) else {}


def gradebook_from(course: str, groups_raw: list[dict], course_raw: dict) -> dict:
    """What Canvas says about how this class's grade is put together.

    *"have something to show the % of your grade each assignment is bc some
    are weighted"*. This is the honest basis for that. It is NOT a claim about
    the report-card grade: Veracross is the gradebook of record and may hold
    marks Canvas never sees. So the record carries Canvas's own computed score
    beside the weights — when it matches the Veracross percentage the weights
    explain the grade; when it does not, the page says so rather than
    pretending. `weighted` false means Canvas adds points straight up, and a
    share is then simply points over total points.
    """
    weighted = bool(course_raw.get("apply_assignment_group_weights"))
    enrollments = [e for e in (course_raw.get("enrollments") or [])
                   if isinstance(e, dict)]
    mine = next((e for e in enrollments
                 if (e.get("type") or "").lower().startswith("student")),
                enrollments[0] if enrollments else {})
    current = mine.get("computed_current_score")
    groups = []
    for group in groups_raw or []:
        if not isinstance(group, dict) or group.get("id") is None:
            continue
        try:
            weight = float(group.get("group_weight") or 0)
        except (TypeError, ValueError):
            weight = 0.0
        groups.append({"id": group.get("id"),
                       "name": (group.get("name") or "").strip()[:60],
                       "weight": weight,
                       "position": group.get("position")})
    groups.sort(key=lambda g: (g["position"] is None, g["position"] or 0))
    return {
        "course_key": models.course_key_from_raw(course),
        "weighted": weighted,
        "canvas_percent": (float(current) if isinstance(current, (int, float))
                           else None),
        "groups": groups,
    }


def dashboard_courses(context) -> list[models.Course]:
    """The course cards: id, name, homepage URL."""
    host = config.load()["canvas"]["host"].rstrip("/")
    data, _ = _get_json(context, f"{host}/api/v1/dashboard/dashboard_cards")
    courses: list[models.Course] = []
    for card in data if isinstance(data, list) else []:
        name = card.get("originalName") or card.get("shortName") or ""
        cid = str(card.get("id") or "")
        if not cid:
            continue
        courses.append(models.Course(
            course_key=models.course_key_from_raw(name),
            course_raw=name,
            display_name=card.get("shortName") or name,
            canvas_course_id=cid,
            canvas_url=f"{host}/courses/{cid}",
        ))
    return courses


def homepage_html(context, course_id: str) -> str:
    """The course homepage HTML: the front page body, else the syllabus body,
    else the rendered page (a last resort that needs a page object)."""
    host = config.load()["canvas"]["host"].rstrip("/")
    try:
        data, _ = _get_json(context, f"{host}/api/v1/courses/{course_id}/front_page")
        body = data.get("body") if isinstance(data, dict) else None
        if body:
            return body
    except SessionError as exc:
        if "401" in str(exc) or "403" in str(exc) or "expired" in str(exc):
            raise
    try:
        data, _ = _get_json(
            context, f"{host}/api/v1/courses/{course_id}?include[]=syllabus_body")
        body = data.get("syllabus_body") if isinstance(data, dict) else None
        if body:
            return body
    except SessionError:
        pass
    # Last resort: render the page and return its HTML (catches iframes the
    # API bodies would carry anyway, plus themes that hide the front page).
    page = context.new_page()
    try:
        page.goto(f"{host}/courses/{course_id}", wait_until="domcontentloaded",
                  timeout=60_000)
        try:
            page.wait_for_load_state("networkidle", timeout=12_000)
        except Exception:  # noqa: BLE001
            pass
        return page.content()
    finally:
        page.close()
