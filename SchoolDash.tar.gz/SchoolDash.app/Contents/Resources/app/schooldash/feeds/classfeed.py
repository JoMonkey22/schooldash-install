"""The Veracross class-schedule feed -> Meeting[] with blocks and day_of_block.

This is the single most valuable source in the project: it resolves Brophy's
rotating block schedule into real dated, timed periods with room numbers.
Nothing here computes the A/B rotation — a cancelled day is simply absent from
the feed, and Day N is the Nth meeting of that course inside its block.
"""

import re
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta

import httpx

from schooldash import config, models, timezones
from schooldash.feeds import ical
from schooldash.logging_setup import get

log = get("classfeed")


def fetch_text(url: str | None = None, timeout: float = 30.0) -> str:
    cfg = config.load()
    url = url or cfg["veracross"]["class_ics"]
    if not url:
        raise ical.FeedError(
            "no class feed configured",
            fix="python run.py login --veracross")
    try:
        response = httpx.get(url, timeout=timeout, follow_redirects=True,
                             headers={"User-Agent": "schooldash/0.1"})
        response.raise_for_status()
    except httpx.HTTPError as exc:
        # Never echo the URL: the token in it is the credential.
        #
        # The cause decides the advice. A dropped connection is not a broken
        # config, and telling someone to re-import their config because their
        # wifi hiccuped sends them to fix something that was never wrong.
        # [MEASURED] 2026-08-28: a transient ConnectError was reported with
        # "run setup --import-legacy"; the feed fetched 709 meetings minutes
        # later, untouched.
        offline = isinstance(exc, (httpx.ConnectError, httpx.ConnectTimeout,
                                   httpx.ReadTimeout, httpx.WriteTimeout,
                                   httpx.PoolTimeout))
        if offline:
            raise ical.FeedError(
                "could not reach the class feed — this Mac looks offline "
                f"({type(exc).__name__})",
                fix="") from exc
        raise ical.FeedError(
            f"the class feed refused the request ({type(exc).__name__})",
            fix="python run.py login --veracross") from exc
    return response.text


def infer_blocks(dates: set[date]) -> list[tuple[date, date]]:
    """Two-week blocks inferred from the calendar, never hardcoded.

    School weeks (Mondays with at least one meeting that week) are paired in
    chronological order; a strictly-consecutive pair forms one block, a lone
    week (a gap follows or the term ends) forms a one-week block. The
    5-meetings-per-course invariant check reports any mis-phasing.
    """
    weeks = sorted({d - timedelta(days=d.weekday()) for d in dates})
    blocks: list[tuple[date, date]] = []
    i = 0
    while i < len(weeks):
        start = weeks[i]
        if i + 1 < len(weeks) and (weeks[i + 1] - start).days == 7:
            end = weeks[i + 1] + timedelta(days=4)
            i += 2
        else:
            end = start + timedelta(days=4)
            i += 1
        blocks.append((start, end))
    return blocks


def load_meetings(text: str | None = None) -> tuple[list[models.Meeting], list[str]]:
    """Parse the feed into Meetings. Warns, never crashes (spec §10.1)."""
    warnings: list[str] = []
    if text is None:
        text = fetch_text()
    events = [e for e in ical.parse(text)
              if isinstance(e.get("dtstart"), datetime) and e.get("summary")]
    if not events:
        return [], ["the class feed parsed to zero timed events"]

    all_dates = {e["dtstart"].date() for e in events}
    blocks = infer_blocks(all_dates)

    def block_for(day: date):
        for span in blocks:
            if span[0] <= day <= span[1]:
                return span
        return None

    grouped: dict[tuple, list[dict]] = defaultdict(list)
    for event in sorted(events, key=lambda e: e["dtstart"]):
        key = models.course_key_from_raw(event["summary"])
        grouped[(key, block_for(event["dtstart"].date()))].append(event)

    meetings: list[models.Meeting] = []
    for (key, span), members in grouped.items():
        for nth, event in enumerate(sorted(members, key=lambda e: e["dtstart"]), 1):
            meetings.append(models.Meeting(
                course_key=key,
                course_raw=event["summary"],
                start=event["dtstart"],
                end=event.get("dtend"),
                date=event["dtstart"].date(),
                room=event.get("location") or None,
                period=None,
                block_id=f"{span[0].isoformat()}/{span[1].isoformat()}" if span else "",
                day_of_block=nth,
            ))
    meetings.sort(key=lambda m: (m.date, m.start))

    # Invariant: an academic course meets 5 times per full block. A checksum,
    # not a law — partial blocks legitimately have fewer. Trust the feed.
    counts_by_course: dict[str, list[int]] = defaultdict(list)
    for (key, span), members in grouped.items():
        counts_by_course[key].append(len(members))
    for key, counts in sorted(counts_by_course.items()):
        if 5 in counts:
            off = [c for c in counts if c != 5]
            if off:
                warnings.append(
                    f"{key}: {len(off)} block(s) with ≠5 meetings ({sorted(off)}) — "
                    "normal for a partial block; the feed is trusted")

    # Overlap check: two meetings of different courses at the same instant.
    seen: dict[tuple, str] = {}
    for m in meetings:
        slot = (m.date, m.start.timetz() if m.start else None)
        if slot in seen and seen[slot] != m.course_key and slot[1] is not None:
            warnings.append(f"overlapping periods on {m.date}: {seen[slot]} and {m.course_key}")
        seen[slot] = m.course_key

    for span in blocks:
        school_days = len({d for d in all_dates if span[0] <= d <= span[1]})
        if (span[1] - span[0]).days >= 11 and school_days < 8:
            warnings.append(
                f"block {span[0]}–{span[1]} has only {school_days} school days")

    return meetings, warnings


class MeetingIndex:
    """Query interface over Meeting[] used by date resolution and the header.

    Course lookup is by course_key with the predecessor's fuzzy fallback
    (prefix, then ≥2-word overlap), because doc extraction addresses courses
    by their Canvas display names.
    """

    def __init__(self, meetings: list[models.Meeting]):
        self.meetings = meetings
        self.by_course: dict[str, dict[date, models.Meeting]] = defaultdict(dict)
        for m in meetings:
            self.by_course[m.course_key][m.date] = m
        self.available = bool(self.by_course)

    def _key(self, course: str) -> str | None:
        want = models.course_key_from_raw(course)
        if want in self.by_course:
            return want
        for key in self.by_course:
            if key.startswith(want) or want.startswith(key):
                return key
        words = set(want.split("-"))
        best, score = None, 0
        for key in self.by_course:
            hits = len(words & set(key.split("-")))
            if hits > score:
                best, score = key, hits
        return best if score >= 2 else None

    def dates(self, course: str) -> list[date]:
        key = self._key(course)
        return sorted(self.by_course.get(key, {})) if key else []

    def meeting_on(self, course: str, day: date) -> models.Meeting | None:
        key = self._key(course)
        return self.by_course.get(key, {}).get(day) if key else None

    def time_on(self, course: str, day: date) -> datetime | None:
        meeting = self.meeting_on(course, day)
        return meeting.start if meeting else None

    def in_range(self, course: str, start: date, end: date) -> list[date]:
        return [d for d in self.dates(course) if start <= d <= end]

    def next_after(self, course: str, day: date) -> date | None:
        for d in self.dates(course):
            if d > day:
                return d
        return None

    def on_date(self, day: date) -> list[models.Meeting]:
        return sorted((m for m in self.meetings if m.date == day),
                      key=lambda m: m.start)

    def school_year_start(self) -> int | None:
        """The calendar year the school year starts in (August-anchored)."""
        every = [m.date for m in self.meetings]
        if not every:
            return None
        first = min(every)
        return first.year if first.month >= 7 else first.year - 1

    def block_label(self, day: date) -> str:
        """'school day 4 of 10 in the Aug 17–Aug 28 block', or '' off-calendar."""
        todays = [m for m in self.meetings if m.date == day]
        if not todays:
            return ""
        block_id = todays[0].block_id
        span_dates = sorted({m.date for m in self.meetings if m.block_id == block_id})
        try:
            nth = span_dates.index(day) + 1
        except ValueError:
            return ""
        start_s, end_s = block_id.split("/")
        start = date.fromisoformat(start_s)
        end = date.fromisoformat(end_s)
        return (f"school day {nth} of {len(span_dates)} in the "
                f"{start:%b %d}–{end:%b %d} block")


def cli_meetings(week: bool = False, verbose: bool = False) -> int:
    tz = timezones.zone()
    today = datetime.now(tz).date()
    try:
        meetings, warnings = load_meetings()
    except ical.FeedError as exc:
        print(f"error: {exc}")
        return 1

    index = MeetingIndex(meetings)
    days = [today + timedelta(days=n) for n in range(7)] if week else [today]
    label = index.block_label(today)
    print(f"{today:%A %B %d, %Y}" + (f" — {label}" if label else ""))
    shown = 0
    for day in days:
        todays = index.on_date(day)
        if not todays:
            continue
        if week:
            print(f"\n{day:%a %b %d}")
        for m in todays:
            end = f"–{m.end:%H:%M}" if m.end else ""
            room = f"  {m.room}" if m.room else ""
            print(f"  {m.start:%H:%M}{end}  {m.course_raw:<44}{room}  (day {m.day_of_block} of block)")
            shown += 1
    if not shown:
        print("  no classes" + (" this week" if week else " today") + " per the feed")

    print(f"\n{len(meetings)} meetings, {len({m.course_key for m in meetings})} courses, "
          f"{len({m.block_id for m in meetings})} blocks in the feed")
    if warnings:
        print(f"{len(warnings)} warning(s):" if verbose else
              f"{len(warnings)} warning(s) — rerun with --verbose to list them")
        if verbose:
            for w in warnings:
                print(f"  ! {w}")
    return 0
