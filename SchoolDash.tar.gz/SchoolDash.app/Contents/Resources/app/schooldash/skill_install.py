"""Install the /schooldash skill to ~/.claude/skills/schooldash/.

Prints exactly which files were written to which paths — a tool reading
~/.claude/... when you assumed the project-local file is a known confusion
(spec §6.14). The .project-path pointer file is what lets the installed copy
find this project from any working directory.
"""

import shutil

from schooldash import paths


def install() -> int:
    source = paths.skill_source_dir()
    target = paths.skill_install_dir()
    if not (source / "SKILL.md").exists():
        print(f"skill source missing at {source} — nothing installed")
        return 1
    target.mkdir(parents=True, exist_ok=True)
    written = []
    for name in ("SKILL.md", "status.py"):
        shutil.copyfile(source / name, target / name)
        written.append(target / name)
    pointer = target / ".project-path"
    pointer.write_text(str(paths.project_root()), encoding="utf-8")
    written.append(pointer)
    print("skill installed — files written:")
    for path in written:
        print(f"  {path}")
    print(f"  (source, versioned in the repo: {source})")
    print("`/schooldash` now works from any directory in a Claude Code session.")
    return 0
