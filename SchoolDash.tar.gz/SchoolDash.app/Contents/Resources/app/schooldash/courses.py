"""Per-class setup: what each course IS, beyond its homework.

A class has a textbook, a syllabus, a homepage doc, a Canvas page, a teacher,
a room — and until now the app knew only the parts it needed to pull
assignments. This module keeps one record per course (data/courses/<key>.json)
holding the materials SchoolDash detected, the ones the student added, their
notes, and whether they have looked it over.

Detection reads everything the student's own Canvas session can see for the
course — the front page, the syllabus page, the wiki pages, module items, the
external-tool tabs, recent announcements and assignment descriptions — plus the
resource links mined from the teacher's schedule doc, and classifies every link
by where it points and what it is called. [MEASURED] 2026-09-01 at this school:
students cannot list course files (HTTP 403), most courses have no modules, and
the front page is a 200-character iframe embed — the useful links live in the
doc's own resource table ("Syllabus | Textbook Notes Template | Textbook Login
Link | Office Hours"), the pages, and the assignment descriptions.

Two rules:
  - a person's edits win. Re-detection adds new links, refreshes titles, and
    never resurrects a link they hid or un-confirms one they confirmed;
  - nothing is invented. A "textbook mention" with no link is stored as text
    for the finder to search, clearly marked as a mention, never as a link.
"""

import hashlib
import json
import re
from datetime import datetime
from urllib.parse import urlparse

from bs4 import BeautifulSoup

from schooldash import config, paths, timezones
from schooldash.docs import links as links_mod
from schooldash.logging_setup import get
from schooldash.models import course_key_from_raw

log = get("courses")

KINDS = ("textbook", "syllabus", "schedule_doc", "canvas", "resource", "video",
         "tool", "website", "textbook_mention", "other")

# The kinds of marked work a syllabus weights. Same vocabulary as
# scoring.categorize produces for a Canvas score, so a weight typed in here
# lands on the right column of the grade page.
WEIGHT_KINDS = ("test", "quiz", "project", "essay", "problem_set", "reading",
                "discussion", "other")

KIND_LABELS = {
    "textbook": "Textbook", "syllabus": "Syllabus", "schedule_doc": "Homework doc",
    "canvas": "Canvas", "resource": "Resource", "video": "Video", "tool": "Tool",
    "website": "Website", "textbook_mention": "Textbook (no link yet)", "other": "Link",
}

# Publisher and e-text platforms. A link to any of these is a textbook link
# whatever it is called — "Login Link" is how the biology teacher labels theirs.
TEXTBOOK_HOSTS = (
    "pearson", "mheducation", "mcgraw", "connected.mcgraw", "cengage", "hmhco",
    "my.hrw", "openstax", "savvas", "vhlcentral", "vistahigherlearning", "bfwpub",
    "macmillanlearning", "macmillanhighered", "webassign", "kognity", "zybooks",
    "edmentum", "ck12", "activelylearn", "bedfordstmartins", "wiley", "wwnorton",
    "norton", "perusall", "redshelf", "vitalsource", "bookshelf", "sadlier",
    "prenticehall", "glencoe", "holtmcdougal", "bigideasmath", "bigideaslearning",
    "carnegielearning", "ixl", "deltamath", "mathxl", "mylab", "mastering",
    "launchpadworks", "achieve.macmillan", "studysync", "amplify", "newsela",
    "commonlit", "membean", "vocabulary.com", "noredink", "ebooks", "ebook",
)
TEXTBOOK_WORDS = re.compile(
    r"\b(text\s?book|e-?text|e-?book|ebook|isbn|online book|digital book|"
    r"student edition|course book|reader|anthology|workbook)\b", re.I)
NOT_TEXTBOOK = re.compile(r"template|notes template|worksheet", re.I)
SYLLABUS_WORDS = re.compile(
    r"\b(syllabus|course (expectations|policies|policy|outline|guide|overview|"
    r"description)|class (expectations|policies|rules)|grading policy|"
    r"course information|course info)\b", re.I)
TOOL_HOSTS = ("quizlet", "kahoot", "desmos", "edpuzzle", "albert.io", "khanacademy",
              "turnitin", "respondus", "lockdown", "flip.com", "padlet", "nearpod",
              "peardeck", "gimkit", "blooket", "socrative", "formative", "classkick",
              "goformative", "geogebra", "wolframalpha", "phet", "labster", "gizmos",
              "explorelearning", "myap.collegeboard", "apclassroom", "duolingo",
              "conjuguemos", "quia", "senorwooly", "edia", "brainpop", "readworks")
VIDEO_HOSTS = ("youtube.com", "youtu.be", "vimeo.com", "loom.com", "screencast")
IGNORE_HOSTS = ("instructure.com/login", "accounts.google.com", "mailto:",
                "brophyprep.org/calendar", "zoom.us/j/")

# School-wide Canvas integrations that appear as a tab in EVERY course and say
# nothing about the class. [MEASURED] 2026-09-01: nine identical "tools" on
# Algebra, Guitar and Scripture alike — Google Drive, Class Notebook, Office
# 365, Nearpod, Canva, Lucid, Google Meet, Gemini, LockDown Browser.
GENERIC_TOOL_LABELS = re.compile(
    r"^(google (drive|meet|gemini|docs|chat|calendar)|class notebook|notebook|office ?365|"
    r"microsoft (teams|onedrive)|onedrive|canva( for education)?|lucid.*|zoom|"
    r"nearpod|install lockdown browser|lockdown browser|respondus.*|"
    r"turnitin|studio|new analytics|attendance|roll call|chat|collaborations|"
    r"badges|portfolium|redirect tool|commons|syllabus)$", re.I)

ISBN = re.compile(r"\b(?:ISBN(?:-1[03])?:?\s*)?(97[89][-\s]?\d{1,5}[-\s]?\d{1,7}[-\s]?\d{1,7}[-\s]?\d|\d{9}[\dXx])\b")
TEXTBOOK_LINE = re.compile(
    r"(?im)^\W{0,3}(?:required\s+)?(?:text(?:book)?s?|e-?book|reading|book)\s*[:\-–]\s*(.{6,160})$")


def _now() -> str:
    return datetime.now(timezones.zone()).isoformat(timespec="seconds")


def canonical_url(url: str) -> str:
    """The URL without the parts that vary per link to the same thing: Google
    Docs' `?usp=sharing` / `?embedded=true` and `/edit` vs `/view` suffixes.
    Two links to one doc are one material."""
    url = (url or "").strip()
    try:
        parts = urlparse(url)
    except ValueError:
        return url
    if parts.netloc.endswith(("docs.google.com", "drive.google.com")):
        path = re.sub(r"/(edit|view|preview|pub|copy|htmlview)$", "", parts.path.rstrip("/"))
        return f"{parts.scheme}://{parts.netloc}{path}"
    return url.rstrip("/")


def _material_id(url: str, title: str = "") -> str:
    key = canonical_url(url).lower() or f"mention|{title.lower().strip()}"
    return hashlib.sha1(key.encode("utf-8")).hexdigest()[:12]


# --------------------------------------------------------------------------
# storage


def _path(course_key: str):
    safe = re.sub(r"[^a-z0-9_-]", "", course_key.lower()) or "course"
    return paths.courses_dir() / f"{safe}.json"


def load(course_key: str) -> dict | None:
    target = _path(course_key)
    if not target.exists():
        return None
    try:
        record = json.loads(target.read_text(encoding="utf-8"))
    except ValueError:
        log.warning("%s is not valid JSON — ignoring it", target.name)
        return None
    if isinstance(record, dict):
        _migrate(record)
    return record


def load_all() -> dict[str, dict]:
    out: dict[str, dict] = {}
    for path in sorted(paths.courses_dir().glob("*.json")):
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except ValueError:
            continue
        if isinstance(raw, dict) and raw.get("course_key"):
            _migrate(raw)
            out[raw["course_key"]] = raw
    return out


def save(record: dict) -> dict:
    record.setdefault("materials", [])
    record.setdefault("notes", "")
    record["updated_at"] = _now()
    target = _path(record["course_key"])
    tmp = target.with_suffix(".tmp")
    tmp.write_text(json.dumps(record, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(target)
    return record


def blank(course_key: str, display_name: str = "", course_raw: str = "") -> dict:
    return {"course_key": course_key, "display_name": display_name or course_key,
            "course_raw": course_raw or display_name or course_key, "teacher": None,
            "teachers": [], "term": None, "canvas_course_id": None, "canvas_url": None,
            "room": None, "materials": [], "notes": "", "announcements": [],
            "detected_at": None, "reviewed_at": None, "sources_scanned": []}


# --------------------------------------------------------------------------
# classification


def classify(url: str, text: str = "", context: str = "", ) -> str:
    """One of KINDS for a link, from its host, path and label.

    Order matters and is deliberate: what the HOST is beats what the words
    around the link say. `context` is surrounding text (a table cell, a
    heading) that can name a thing the anchor text does not — "Textbook |
    Login Link" — but a YouTube link in a sentence that mentions the eText is
    still a video, so context is consulted last and only for generic hosts.
    """
    text = text or ""
    context = context or ""
    host = ""
    path = ""
    try:
        parts = urlparse(url or "")
        host = (parts.netloc or "").lower()
        path = (parts.path or "").lower()
    except ValueError:
        pass
    if any(h in host for h in VIDEO_HOSTS):
        return "video"
    if any(h in host or h in path for h in TOOL_HOSTS) or "/external_tools/" in path:
        return "tool"
    if any(h in host for h in TEXTBOOK_HOSTS) and not NOT_TEXTBOOK.search(text):
        return "textbook"
    if SYLLABUS_WORDS.search(text):
        return "syllabus"
    if TEXTBOOK_WORDS.search(text) and not NOT_TEXTBOOK.search(text):
        return "textbook"
    if "instructure.com" in host:
        return "canvas"
    base_kind = links_mod.classify(url or "")
    generic = base_kind in ("other", "pdf") or base_kind.startswith("google_")
    if generic and SYLLABUS_WORDS.search(context):
        return "syllabus"
    if generic and base_kind == "other" and TEXTBOOK_WORDS.search(context) \
            and not NOT_TEXTBOOK.search(text + " " + context):
        return "textbook"
    if base_kind.startswith("google_") or base_kind == "pdf":
        return "resource"
    if base_kind in ("quizlet", "kahoot", "desmos", "edpuzzle", "albert", "khan", "turnitin"):
        return "tool"
    if base_kind == "youtube":
        return "video"
    return "website" if host else "other"


def _ignored(url: str) -> bool:
    low = (url or "").lower()
    return (not low.startswith(("http://", "https://"))
            or any(fragment in low for fragment in IGNORE_HOSTS))


def _links_from_html(html: str, base: str, source: str, context: str = "") -> list[dict]:
    if not html:
        return []
    soup = BeautifulSoup(html, "lxml")
    out = []
    for anchor in soup.find_all("a", href=True):
        url = links_mod.strip_tracking(links_mod.unwrap_google(anchor["href"].strip()))
        if url.startswith("/") and base:
            url = base.rstrip("/") + url
        if _ignored(url):
            continue
        text = " ".join(anchor.get_text(" ", strip=True).split())
        # a heading or table header above the link often names it
        nearby = ""
        cell = anchor.find_parent(["td", "th", "li", "p"])
        if cell is not None:
            nearby = " ".join(cell.get_text(" ", strip=True).split())[:120]
        if not text or text.startswith(("http://", "https://", "www.")):
            # a pasted URL as its own label: name it after where it sits
            # ("Graphing Exercise — doc") rather than showing 90 characters of
            # address, which is what the Classes page did on first sight
            where = source.split(":", 1)[-1].strip() if ":" in source else source
            kind_word = {"google_doc": "doc", "google_slides": "slides",
                         "google_sheet": "sheet", "google_form": "form",
                         "pdf": "PDF"}.get(links_mod.classify(url), "link")
            text = f"{where} — {kind_word}"[:120]
        out.append({"url": url, "title": text, "source": source,
                    "context": (context + " " + nearby).strip()[:160]})
    # iframes: an embedded doc is a link too
    for frame in soup.find_all("iframe", src=True):
        url = links_mod.strip_tracking(links_mod.unwrap_google(frame["src"].strip()))
        if _ignored(url):
            continue
        out.append({"url": url, "title": frame.get("title") or "embedded document",
                    "source": source, "context": context, "kind_hint": "embedded"})
    return out


def textbook_mentions(text: str) -> list[dict]:
    """Textbook titles and ISBNs written as text (no link)."""
    found: list[dict] = []
    seen: set[str] = set()
    for match in TEXTBOOK_LINE.finditer(text or ""):
        title = match.group(1).strip().rstrip(".;,")
        if len(title) < 6 or title.lower() in seen or re.match(r"https?://", title):
            continue
        seen.add(title.lower())
        found.append({"title": title[:160], "isbn": None})
    for match in ISBN.finditer(text or ""):
        digits = re.sub(r"[-\s]", "", match.group(1))
        if digits in seen:
            continue
        seen.add(digits)
        found.append({"title": f"ISBN {digits}", "isbn": digits})
    return found


# --------------------------------------------------------------------------
# merging detected links into a record


def _migrate(record: dict) -> None:
    """Bring a record written by an earlier version up to date, in place.

    Two things changed on 2026-09-01 after the first live scan: material ids
    became query-string-insensitive (so an embedded `…/pub?embedded=true` and
    the profile's `…/pub` are one row), and school-wide Canvas tool tabs are no
    longer recorded. Records from before carry the old ids and those tabs;
    without this they would sit beside the new rows forever.
    """
    merged: dict[str, dict] = {}
    for material in record.get("materials") or []:
        if (material.get("kind") == "tool" and not material.get("confirmed")
                and "course tabs" in (material.get("sources") or [])
                and GENERIC_TOOL_LABELS.match((material.get("title") or "").strip())):
            continue
        new_id = _material_id(material.get("url") or "", material.get("title") or "")
        material["id"] = new_id
        if new_id in merged:
            keep = merged[new_id]
            keep["confirmed"] = keep.get("confirmed") or material.get("confirmed", False)
            keep["hidden"] = keep.get("hidden") or material.get("hidden", False)
            if not keep.get("notes") and material.get("notes"):
                keep["notes"] = material["notes"]
            for source in material.get("sources") or []:
                if source not in keep.setdefault("sources", []):
                    keep["sources"].append(source)
            if (keep.get("title") in (None, "", "embedded document")
                    or keep["title"].startswith("http")) and material.get("title"):
                keep["title"] = material["title"]
            if keep.get("kind") in ("resource", "website", "other") and material.get("kind") \
                    not in ("resource", "website", "other", None):
                keep["kind"] = material["kind"]
            continue
        merged[new_id] = material
    record["materials"] = list(merged.values())


def _merge_materials(record: dict, detected: list[dict]) -> tuple[int, int]:
    """Add/refresh detected materials. Returns (added, refreshed). Hidden and
    confirmed flags on existing entries are untouched."""
    existing = {m["id"]: m for m in record.get("materials", [])}
    added = refreshed = 0
    for item in detected:
        mid = item["id"]
        if mid in existing:
            current = existing[mid]
            # a better (longer, non-URL) title is worth taking; a person's own
            # title (edited=True) is not overwritten
            if (not current.get("edited") and item.get("title")
                    and len(item["title"]) > len(current.get("title") or "")
                    and not item["title"].startswith("http")):
                current["title"] = item["title"]
                refreshed += 1
            current["last_seen"] = item.get("detected_at")
            if item.get("source") and item["source"] not in (current.get("sources") or []):
                current.setdefault("sources", []).append(item["source"])
            continue
        entry = dict(item)
        entry["sources"] = [item.get("source") or "detected"]
        entry.pop("source", None)
        entry["confirmed"] = False
        entry["hidden"] = False
        entry["notes"] = ""
        existing[mid] = entry
        record.setdefault("materials", []).append(entry)
        added += 1
    return added, refreshed


def _dedupe_detected(raw_links: list[dict]) -> list[dict]:
    by_id: dict[str, dict] = {}
    stamp = _now()
    for link in raw_links:
        mid = _material_id(link.get("url", ""), link.get("title", ""))
        kind = link.get("kind") or classify(link.get("url", ""), link.get("title", ""),
                                             link.get("context", ""))
        entry = by_id.get(mid)
        if entry is None:
            by_id[mid] = {"id": mid, "kind": kind, "title": (link.get("title") or "")[:160],
                          "url": link.get("url") or None, "source": link.get("source"),
                          "detected_at": stamp, "isbn": link.get("isbn")}
        else:
            title = link.get("title") or ""
            if ((len(title) > len(entry["title"]) or entry["title"] == "embedded document")
                    and title and not title.startswith("http") and title != "embedded document"):
                entry["title"] = title[:160]
            # a more specific kind wins over "website"/"other"
            if entry["kind"] in ("website", "other", "resource") and kind not in (
                    "website", "other", "resource"):
                entry["kind"] = kind
    return list(by_id.values())


# --------------------------------------------------------------------------
# detection


def _get_json(context, url: str):
    """Best-effort session GET -> parsed JSON or None (a 403 on files is
    normal for a student, not a failure)."""
    from schooldash.browser import strip_while1
    try:
        response = context.request.get(url, timeout=45_000)
    except Exception as exc:  # noqa: BLE001
        log.debug("GET %s failed: %s", url, exc)
        return None
    if not response.ok:
        return None
    try:
        return json.loads(strip_while1(response.text()))
    except ValueError:
        return None


def canvas_courses(context) -> list[dict]:
    """Every course the student can see — including the ones the dashboard
    cards hide. [MEASURED] the card list showed 9 of 14 courses."""
    host = config.load()["canvas"]["host"].rstrip("/")
    data = _get_json(context, f"{host}/api/v1/courses?state[]=available&state[]=unpublished"
                              "&state[]=completed&per_page=50&include[]=term&include[]=teachers")
    out = []
    for course in data if isinstance(data, list) else []:
        name = course.get("name") or ""
        cid = str(course.get("id") or "")
        if not name or not cid:
            continue
        out.append({"course_key": course_key_from_raw(name), "course_raw": name,
                    "display_name": name.split("-")[0].strip() or name,
                    "canvas_course_id": cid, "canvas_url": f"{host}/courses/{cid}",
                    "term": (course.get("term") or {}).get("name"),
                    "teachers": [t.get("display_name") for t in course.get("teachers") or []
                                 if t.get("display_name")]})
    return out


def detect_course(context, course: dict, doc_links: list[dict] | None = None,
                  doc_text: str = "") -> dict:
    """Scan one course and merge what was found into its record."""
    host = config.load()["canvas"]["host"].rstrip("/")
    cid = course.get("canvas_course_id")
    key = course["course_key"]
    record = load(key) or blank(key, course.get("display_name"), course.get("course_raw"))
    _migrate(record)
    for field in ("display_name", "course_raw", "canvas_course_id", "canvas_url", "term"):
        if course.get(field):
            record[field] = course[field]
    if course.get("teachers"):
        record["teachers"] = course["teachers"]
        record["teacher"] = record.get("teacher") or course["teachers"][0]

    raw_links: list[dict] = []
    scanned: list[str] = []
    text_blobs: list[str] = []
    if cid:
        base = f"{host}/courses/{cid}"
        raw_links.append({"url": base, "title": "Canvas course page", "kind": "canvas",
                          "source": "canvas"})
        front = _get_json(context, f"{host}/api/v1/courses/{cid}/front_page")
        if isinstance(front, dict) and front.get("body"):
            raw_links += _links_from_html(front["body"], host, "front page")
            text_blobs.append(BeautifulSoup(front["body"], "lxml").get_text(" ", strip=True))
            scanned.append("front page")
        info = _get_json(context, f"{host}/api/v1/courses/{cid}?include[]=syllabus_body")
        if isinstance(info, dict) and info.get("syllabus_body"):
            raw_links += _links_from_html(info["syllabus_body"], host, "syllabus page",
                                          context="syllabus")
            text_blobs.append(BeautifulSoup(info["syllabus_body"], "lxml").get_text(" ", strip=True))
            scanned.append("syllabus page")
            if len(info["syllabus_body"]) > 400:
                raw_links.append({"url": f"{base}/assignments/syllabus",
                                  "title": "Syllabus page in Canvas", "kind": "syllabus",
                                  "source": "canvas"})
        pages = _get_json(context, f"{host}/api/v1/courses/{cid}/pages?per_page=30")
        for page in (pages if isinstance(pages, list) else [])[:12]:
            slug = page.get("url")
            if not slug:
                continue
            body = _get_json(context, f"{host}/api/v1/courses/{cid}/pages/{slug}")
            if isinstance(body, dict) and body.get("body"):
                raw_links += _links_from_html(body["body"], host, f"page: {page.get('title')}",
                                              context=page.get("title") or "")
                text_blobs.append(BeautifulSoup(body["body"], "lxml").get_text(" ", strip=True))
            raw_links.append({"url": f"{base}/pages/{slug}", "title": page.get("title") or slug,
                              "kind": "canvas", "source": "pages"})
        if pages:
            scanned.append("pages")
        modules = _get_json(context, f"{host}/api/v1/courses/{cid}/modules?include[]=items&per_page=50")
        for module in modules if isinstance(modules, list) else []:
            for item in module.get("items") or []:
                url = item.get("external_url") or item.get("html_url")
                if url and not _ignored(url):
                    raw_links.append({"url": url, "title": item.get("title") or "",
                                      "source": f"module: {module.get('name')}",
                                      "context": module.get("name") or ""})
        if modules:
            scanned.append("modules")
        tabs = _get_json(context, f"{host}/api/v1/courses/{cid}/tabs")
        for tab in tabs if isinstance(tabs, list) else []:
            if tab.get("type") == "external" and tab.get("html_url"):
                if GENERIC_TOOL_LABELS.match((tab.get("label") or "").strip()):
                    continue
                url = tab["html_url"]
                if url.startswith("/"):
                    url = host + url
                label = tab.get("label") or "tool"
                squashed = label.lower().replace(" ", "")
                # A publisher's own tab ("Pearson Realize", "McGraw Hill") IS
                # the textbook, whatever Canvas calls the integration.
                is_book = bool(TEXTBOOK_WORDS.search(label)) or any(
                    name in squashed for name in ("pearson", "mcgraw", "cengage", "savvas",
                                                  "hmh", "openstax", "vhl", "bigideas",
                                                  "zybooks", "kognity", "webassign",
                                                  "macmillan", "norton", "wiley"))
                raw_links.append({"url": url, "title": label,
                                  "kind": "textbook" if is_book else "tool",
                                  "source": "course tabs"})
        if tabs:
            scanned.append("tabs")
        announcements = _get_json(
            context, f"{host}/api/v1/announcements?context_codes[]=course_{cid}&per_page=10")
        recent = []
        for ann in announcements if isinstance(announcements, list) else []:
            body_html = ann.get("message") or ""
            text = " ".join(BeautifulSoup(body_html, "lxml").get_text(" ", strip=True).split())
            recent.append({"title": ann.get("title") or "", "posted_at": ann.get("posted_at"),
                           "url": ann.get("html_url"), "text": text[:400]})
            raw_links += _links_from_html(body_html, host, f"announcement: {ann.get('title')}")
            text_blobs.append(text)
        if announcements is not None:
            record["announcements"] = recent
            scanned.append("announcements")
        assignments = _get_json(
            context, f"{host}/api/v1/courses/{cid}/assignments?per_page=40&order_by=due_at")
        for assignment in assignments if isinstance(assignments, list) else []:
            description = assignment.get("description") or ""
            if description:
                raw_links += _links_from_html(description, host,
                                              f"assignment: {assignment.get('name')}")
                text_blobs.append(BeautifulSoup(description, "lxml").get_text(" ", strip=True))
        if assignments:
            scanned.append("assignments")

    for link in doc_links or []:
        raw_links.append({"url": link.get("url"), "title": link.get("text") or "",
                          "source": "homework doc", "context": "resource table"})
    if doc_text:
        text_blobs.append(doc_text)
        scanned.append("homework doc")

    # the homepage doc itself
    doc_url = course.get("homepage_doc_url")
    if doc_url:
        raw_links.append({"url": doc_url, "title": "Teacher's schedule doc",
                          "kind": "schedule_doc", "source": "homepage"})

    detected = _dedupe_detected(raw_links)
    stamp = _now()
    for mention in textbook_mentions("\n".join(text_blobs)):
        detected.append({"id": _material_id("", mention["title"]), "kind": "textbook_mention",
                         "title": mention["title"], "url": None, "source": "text",
                         "detected_at": stamp, "isbn": mention.get("isbn")})
    added, refreshed = _merge_materials(record, detected)
    record["detected_at"] = stamp
    record["sources_scanned"] = scanned
    save(record)
    log.info("%s: %d material(s) detected (%d new, %d refreshed) from %s",
             key, len(detected), added, refreshed, ", ".join(scanned) or "nothing")
    return record


def detect_all(context, only: str | None = None, emit=None) -> dict[str, dict]:
    """Scan every visible course. `emit(message)` reports progress."""
    from schooldash import pipeline
    from schooldash.profiling import store

    def say(message):
        log.info(message)
        if emit:
            emit(message)

    state = pipeline.load_state() or {}
    per_course = (state.get("diagnostics") or {}).get("per_course") or {}
    profiles, _ = store.load_all()
    courses = canvas_courses(context)
    say(f"{len(courses)} course(s) visible in Canvas")
    results: dict[str, dict] = {}
    seen_keys = set()
    for course in courses:
        key = course["course_key"]
        if only and only not in key:
            continue
        seen_keys.add(key)
        profile = profiles.get(key)
        if profile is not None:
            course["homepage_doc_url"] = profile.get("doc", "url", default=None)
        doc_links = (per_course.get(key) or {}).get("course_links") or []
        doc_text = _doc_text(profile) if profile is not None else ""
        say(f"scanning {course['display_name']}…")
        try:
            results[key] = detect_course(context, course, doc_links, doc_text)
        except Exception as exc:  # noqa: BLE001 — one course, not the run
            log.warning("detection failed for %s: %s", key, exc)
            say(f"{course['display_name']}: could not scan ({type(exc).__name__})")
    # courses known only from the schedule feed / profiles still get a record
    for key, profile in profiles.items():
        if key in seen_keys or (only and only not in key):
            continue
        record = load(key) or blank(key, profile.get("display_name"), profile.get("course_raw"))
        _migrate(record)
        record["canvas_course_id"] = record.get("canvas_course_id") or profile.get("canvas_course_id")
        record["canvas_url"] = record.get("canvas_url") or profile.get("canvas_url")
        record["teacher"] = record.get("teacher") or profile.get("teacher")
        record["room"] = record.get("room") or profile.get("meeting", "typical_room", default=None)
        doc_links = (per_course.get(key) or {}).get("course_links") or []
        detected = _dedupe_detected([
            {"url": l.get("url"), "title": l.get("text") or "", "source": "homework doc"}
            for l in doc_links if l.get("url")])
        doc_url = profile.get("doc", "url", default=None)
        if doc_url:
            detected.append({"id": _material_id(doc_url), "kind": "schedule_doc",
                             "title": "Teacher's schedule doc", "url": doc_url,
                             "source": "homepage", "detected_at": _now(), "isbn": None})
        _merge_materials(record, detected)
        record["detected_at"] = _now()
        save(record)
        results[key] = record
    return results


def _doc_text(profile) -> str:
    """The latest cached copy of the course doc, as text, for mentions."""
    from schooldash.docs import fetch as fetch_mod
    file_id = profile.get("doc", "file_id", default=None)
    if not file_id:
        return ""
    html = fetch_mod.latest_cached(file_id)
    if not html:
        return ""
    return BeautifulSoup(html, "lxml").get_text("\n", strip=True)[:60_000]


# --------------------------------------------------------------------------
# edits from the dashboard


def update(course_key: str, patch: dict) -> dict:
    record = load(course_key) or blank(course_key)
    for field in ("notes", "teacher", "room", "display_name"):
        if field in patch:
            record[field] = (patch[field] or "").strip() if patch[field] is not None else None
    if patch.get("reviewed"):
        record["reviewed_at"] = _now()
    # Category weights typed in from the syllabus — the student's own statement
    # of how much each kind of work counts, used by the grade page when Canvas
    # does not apply group weights. Percentages 0-100 per kind; null clears.
    if "weights" in patch:
        weights = patch["weights"]
        if weights is None:
            record.pop("weights", None)
        elif isinstance(weights, dict):
            clean = {}
            for kind, value in weights.items():
                if kind not in WEIGHT_KINDS:
                    continue
                try:
                    number = float(value)
                except (TypeError, ValueError):
                    continue
                if 0 <= number <= 100:
                    clean[kind] = number
            record["weights"] = clean
    for edit in patch.get("materials") or []:
        target = next((m for m in record.get("materials", []) if m["id"] == edit.get("id")), None)
        if target is None:
            continue
        for field in ("confirmed", "hidden"):
            if field in edit:
                target[field] = bool(edit[field])
        if "kind" in edit and edit["kind"] in KINDS:
            target["kind"] = edit["kind"]
            target["edited"] = True
        if "title" in edit and (edit["title"] or "").strip():
            target["title"] = edit["title"].strip()[:160]
            target["edited"] = True
        if "notes" in edit:
            target["notes"] = (edit["notes"] or "")[:1000]
        if "url" in edit and (edit["url"] or "").startswith(("http://", "https://")):
            target["url"] = edit["url"].strip()
            target["edited"] = True
    return save(record)


def add_material(course_key: str, title: str, url: str | None, kind: str = "other",
                 notes: str = "", isbn: str | None = None, source: str = "you") -> dict:
    record = load(course_key) or blank(course_key)
    url = (url or "").strip() or None
    if url and not url.startswith(("http://", "https://")):
        url = "https://" + url
    # "other" from the form means "work it out" — a hand-added quizlet link
    # should still be filed as a tool.
    kind = kind if kind in KINDS and kind != "other" else classify(url or "", title)
    mid = _material_id(url or "", title)
    existing = next((m for m in record["materials"] if m["id"] == mid), None)
    if existing:
        existing.update({"hidden": False, "confirmed": True, "title": title[:160] or existing["title"],
                         "kind": kind, "notes": notes[:1000] if notes else existing.get("notes", "")})
        if isbn:
            existing["isbn"] = isbn
    else:
        record["materials"].append({"id": mid, "kind": kind, "title": title[:160],
                                    "url": url, "sources": [source], "detected_at": _now(),
                                    "confirmed": True, "hidden": False, "edited": True,
                                    "notes": notes[:1000], "isbn": isbn})
    return save(record)


def remove_material(course_key: str, material_id: str) -> dict | None:
    record = load(course_key)
    if not record:
        return None
    before = len(record["materials"])
    # detected links are hidden (so re-detection does not bring them back);
    # hand-added ones are deleted outright
    kept = []
    for material in record["materials"]:
        if material["id"] != material_id:
            kept.append(material)
        elif "you" not in (material.get("sources") or []):
            material["hidden"] = True
            kept.append(material)
    record["materials"] = kept
    if len(kept) == before and not any(m["id"] == material_id for m in kept):
        return None
    return save(record)


# --------------------------------------------------------------------------
# which term a class belongs to
#
# *"in classes only have the current semesters grade"* — the Classes list held
# sixteen courses, and four of them are not this semester. [MEASURED]
# 2026-09-07 the terms Canvas reports:
#
#     Health*-Cannia-Summer Session 2_26/27          2026/2027 Summer Session 2
#     World History Seminar*-Hamel-Summer Session 1  2026/2027 Summer Session 1
#     Makerspace Essentials-Lewkowitz-S2_26/27       2026/2027 Semester 2
#     Strength and Conditioning-Vanden Bosch-S2      2026/2027 Semester 2
#
# Two are last summer's and finished; two are next semester's and have not
# started. Canvas still lists all of them, which is also why the refresh
# collects a 403 on the two that have not begun.
#
# The current session is not guessed from the month — a school calendar does
# not follow the calendar year, and a wrong guess would hide a real class. It
# is READ from the courses that actually have meetings in the class feed this
# week: whatever session they all share is the session it is now.

TERM_SESSION = re.compile(
    r"(?P<year>\d{4}\s*/\s*\d{4})?\s*"
    r"(?P<session>Semester|Summer Session|Quarter|Trimester|Term)\s*(?P<n>\d+)",
    re.I)


def term_sessions(term: str | None) -> set[str]:
    """The sessions a term label covers.

    "2026/2027 Semester 1"             -> {"2026/2027 semester 1"}
    "2026/2027 Semester 1 - Semester 2" -> both, because a year-long course
                                           runs through each of them
    "Default Term" / None / ""          -> empty: nothing is claimed, and a
                                           course we cannot place is never
                                           hidden on the strength of a guess.
    """
    text = (term or "").strip()
    if not text:
        return set()
    year = ""
    out = set()
    for match in TERM_SESSION.finditer(text):
        year = (match.group("year") or year or "").replace(" ", "")
        session = f"{match.group('session')} {match.group('n')}".lower()
        out.add(f"{year} {session}".strip())
    return out


def current_sessions(records: dict, live_keys) -> set[str]:
    """The session(s) the classes that really meet right now belong to.

    Read, not assumed. The intersection is deliberate: a year-long class
    covers two sessions and a single-semester class covers one, so what they
    all share is the one that is running. An empty answer (no feed, no terms)
    means "unknown", and everything then counts as current.
    """
    sets = [term_sessions((records.get(key) or {}).get("term"))
            for key in live_keys]
    sets = [item for item in sets if item]
    if not sets:
        return set()
    shared = set.intersection(*sets)
    return shared


def is_current(record: dict, sessions: set[str]) -> bool:
    """Is this class running in the given session(s)?

    Unknown terms count as current. Hiding a class because its term could not
    be parsed would be the app deciding something it does not know — and the
    cost of being wrong is a class of real homework disappearing.
    """
    if not sessions:
        return True
    mine = term_sessions(record.get("term"))
    if not mine:
        return True
    return bool(mine & sessions)


def summary(record: dict) -> dict:
    """The compact shape the board needs beside an item."""
    visible = [m for m in record.get("materials", []) if not m.get("hidden")]
    by_kind: dict[str, list] = {}
    for material in visible:
        by_kind.setdefault(material["kind"], []).append(material)
    return {"course_key": record["course_key"], "display_name": record.get("display_name"),
            "teacher": record.get("teacher"), "room": record.get("room"),
            "canvas_url": record.get("canvas_url"), "notes": record.get("notes") or "",
            "reviewed_at": record.get("reviewed_at"), "detected_at": record.get("detected_at"),
            "weights": record.get("weights") or None,
            "counts": {kind: len(items) for kind, items in by_kind.items()},
            "textbooks": [m for m in visible if m["kind"] == "textbook"],
            "syllabus": [m for m in visible if m["kind"] == "syllabus"],
            "announcements": (record.get("announcements") or [])[:3]}
