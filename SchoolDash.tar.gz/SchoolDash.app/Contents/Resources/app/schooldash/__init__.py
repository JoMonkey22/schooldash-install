"""SchoolDash — a local-first homework and schedule dashboard."""

from pathlib import Path


def _read_version() -> str:
    """The VERSION file is the one source of truth (CHANGELOG.md explains the
    numbering). This used to be a hardcoded "0.1.0" that nobody bumped, so
    /api/health and the diagnostics reported a version eleven releases old."""
    try:
        return (Path(__file__).resolve().parent.parent / "VERSION").read_text(
            encoding="utf-8").strip() or "0.0.0.0"
    except OSError:
        return "0.0.0.0"


__version__ = _read_version()
