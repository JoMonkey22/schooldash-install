"""Data shapes. The dashboard, grounding check, and golden tests bind to these.

Field names follow the spec exactly — do not improvise. Items from docs and
Canvas share one shape so scoring and the dashboard treat both identically.
"""

import hashlib
import re
from dataclasses import dataclass, field, asdict
from datetime import date, datetime

# The closed extractor vocabulary. Golden files bind to it; add a value only by
# adding it here and to the golden files in the same commit.
EXTRACTORS = {
    "canvas_stated",
    "day_n_exact",
    "day_n_end_aligned",
    "weekday_snapped",
    "absolute",
    "absolute_snapped_forward",
    "month_heading",
    "model_adjudicated",
    "unresolved",
    "manual",           # tasks the student adds themselves (chat or API)
}

LINK_KINDS = {
    "ap_classroom", "canvas", "google_doc", "google_slides", "google_sheet",
    "google_form", "google_drive_file", "youtube", "pdf", "quizlet", "kahoot",
    "desmos", "edpuzzle", "albert", "khan", "turnitin", "other",
}

CATEGORIES = {"test", "project", "essay", "quiz", "reading", "practice", "admin", "neutral",
              # legacy scorer categories kept for parity with legacy/priority.py
              "writing", "problem_set", "discussion", "other"}


def norm_course(name: str) -> str:
    """The predecessor's course normalizer, kept byte-compatible because
    legacy_doc_id depends on it: text before the first '-', lowercased,
    non-alphanumerics stripped."""
    name = (name or "").split("-")[0]
    return re.sub(r"[^a-z0-9 ]", "", name.lower()).strip()


def course_key_from_raw(raw: str) -> str:
    """'AP Chemistry-Mazzolini-YR_26/27' -> 'ap-chemistry'."""
    return norm_course(raw).replace(" ", "-") or "unknown-course"


def make_item_id(source: str, course_key: str, title: str, due_date: str | None) -> str:
    key = f"{source}|{course_key}|{title}|{due_date or ''}"
    return hashlib.sha1(key.encode("utf-8")).hexdigest()[:16]


def make_legacy_doc_id(course_display: str, title: str, due_date: str | None) -> str:
    """The predecessor's doc_id recipe, verified against legacy/course_docs.py:
    sha1(norm_course(display)|normalized lowercase title|due DATE iso or '')[:16].
    Used ONLY to import an existing doc_done.json once."""
    key = "|".join([
        norm_course(course_display),
        re.sub(r"\s+", " ", (title or "").lower()).strip(),
        due_date or "",
    ])
    return hashlib.sha1(key.encode("utf-8")).hexdigest()[:16]


@dataclass
class Link:
    url: str
    text: str = ""
    kind: str = "other"

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Meeting:
    """One real, dated class period from the class feed (spec §8.1)."""
    course_key: str
    course_raw: str
    start: datetime           # tz-aware, local zone
    end: datetime | None
    date: date
    room: str | None = None
    period: int | None = None
    block_id: str = ""
    day_of_block: int = 0     # 1..N, the Nth meeting of THIS course in THIS block

    def to_dict(self) -> dict:
        return {
            "course_key": self.course_key,
            "course_raw": self.course_raw,
            "start": self.start.isoformat() if self.start else None,
            "end": self.end.isoformat() if self.end else None,
            "date": self.date.isoformat(),
            "room": self.room,
            "period": self.period,
            "block_id": self.block_id,
            "day_of_block": self.day_of_block,
        }


@dataclass
class Item:
    """One thing the student has to do (spec §8.2). Docs and Canvas share this shape."""
    source: str               # canvas | doc | veracross | canvas_ics
    course_key: str
    course: str               # display name
    title: str                # trimmed to ~110 chars at a word boundary
    detail: str = ""
    raw_cell: str = ""
    kind: str = ""            # "homepage doc" for docs; plannable_type for Canvas
    category: str = "neutral"
    due: str | None = None    # tz-aware ISO in the local zone, or None
    due_date: str | None = None
    all_day: bool = False
    date_note: str = ""       # REQUIRED non-empty before an item may ship
    confidence: str = "high"  # high | medium | low
    extractor: str = "unresolved"
    points: float | None = None
    submitted: bool | None = None
    done: bool = False
    url: str | None = None
    links: list = field(default_factory=list)      # list[Link] or dicts
    merged_from: list = field(default_factory=list)
    score: float = 0.0
    flags: list = field(default_factory=list)
    item_id: str = ""
    legacy_doc_id: str = ""

    def finalize(self) -> "Item":
        """Stamp ids and enforce invariants. Every item passes through here."""
        if not self.date_note:
            raise ValueError(
                f"item {self.title!r} has no date_note — an item may never ship "
                "without one (spec §5.9)")
        if self.extractor not in EXTRACTORS:
            raise ValueError(f"unknown extractor {self.extractor!r} on {self.title!r}")
        self.item_id = make_item_id(self.source, self.course_key, self.title, self.due_date)
        if self.source == "doc":
            self.legacy_doc_id = make_legacy_doc_id(self.course, self.title, self.due_date)
        return self

    def to_dict(self) -> dict:
        out = asdict(self)
        out["links"] = [l.to_dict() if isinstance(l, Link) else l for l in self.links]
        return out


@dataclass
class Course:
    course_key: str
    course_raw: str
    display_name: str = ""
    canvas_course_id: str = ""
    canvas_url: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Profile:
    """A thin wrapper over the profile JSON. profiling/schema.py is the single
    source of truth for the shape; this just carries it around."""
    course_key: str
    raw: dict = field(default_factory=dict)

    def get(self, *path, default=None):
        node = self.raw
        for part in path:
            if not isinstance(node, dict) or part not in node:
                return default
            node = node[part]
        return node

    def to_dict(self) -> dict:
        return self.raw


@dataclass
class Run:
    run_id: str
    started: str
    finished: str | None = None
    ok: bool = False
    counts: dict = field(default_factory=dict)
    warnings: list = field(default_factory=list)
    diagnostics: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)
