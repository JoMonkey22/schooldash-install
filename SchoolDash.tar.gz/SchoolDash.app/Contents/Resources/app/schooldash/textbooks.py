"""Finding and bookmarking the textbook for a class.

Given a title, an author, or an ISBN — from a syllabus line, a teacher's doc,
or the student typing it — look it up and hand back something worth
bookmarking: the book's proper title and cover, a stable catalogue link, and
any copy that can be read right now without paying again:

  - OpenStax and other openly licensed books (free by design);
  - the Internet Archive's lending library (borrowable);
  - Google Books, for the preview and the canonical record;
  - Open Library, for the ISBN-keyed record and editions.

The publisher platform the school actually pays for (Pearson, McGraw Hill,
Savvas…) shows up as a "textbook" material from courses.py when a teacher
links it; this module is for the case where the class names a book and links
nothing. It only searches public catalogues.
"""

import re
from urllib.parse import quote_plus

import httpx

from schooldash.logging_setup import get

log = get("textbooks")

GOOGLE_BOOKS = "https://www.googleapis.com/books/v1/volumes"
OPEN_LIBRARY = "https://openlibrary.org/search.json"
ARCHIVE = "https://archive.org/advancedsearch.php"
OPENSTAX = "https://openstax.org/apps/cms/api/v2/pages/"

TIMEOUT = 12.0
HEADERS = {"User-Agent": "schooldash/0.12 (student homework dashboard)"}


def _isbn_of(text: str) -> str | None:
    match = re.search(r"\b(97[89][-\s]?\d{1,5}[-\s]?\d{1,7}[-\s]?\d{1,7}[-\s]?\d|\d{9}[\dXx])\b",
                      text or "")
    return re.sub(r"[-\s]", "", match.group(1)) if match else None


def _get(url: str, params: dict | None = None):
    """The catalogue's answer, or None when it did not give one.

    None means "no answer" and an empty payload means "nothing there" — the
    caller must keep those apart. [PROVEN] tests/test_prosecution.py: Google
    Books answers HTTP 429 to unauthenticated requests from this machine, and
    swallowing that made a dead catalogue look exactly like a book that does
    not exist.
    """
    try:
        response = httpx.get(url, params=params, timeout=TIMEOUT, headers=HEADERS,
                             follow_redirects=True)
        response.raise_for_status()
        return response.json()
    except httpx.HTTPStatusError as exc:
        log.info("%s lookup refused: HTTP %s", url.split("/")[2],
                 exc.response.status_code)
        return None
    except (httpx.HTTPError, ValueError) as exc:
        log.info("%s lookup failed: %s", url.split("/")[2], type(exc).__name__)
        return None


# --------------------------------------------------------------------------
# parsers — pure, so they are testable against saved responses


def parse_google_books(data: dict | None) -> list[dict]:
    out = []
    for item in (data or {}).get("items") or []:
        info = item.get("volumeInfo") or {}
        isbn13 = next((i.get("identifier") for i in info.get("industryIdentifiers") or []
                       if i.get("type") == "ISBN_13"), None)
        access = item.get("accessInfo") or {}
        out.append({
            "title": info.get("title") or "",
            "subtitle": info.get("subtitle") or "",
            "authors": info.get("authors") or [],
            "publisher": info.get("publisher") or "",
            "year": (info.get("publishedDate") or "")[:4],
            "isbn13": isbn13,
            "cover": ((info.get("imageLinks") or {}).get("thumbnail") or "").replace("http://", "https://"),
            "catalog_url": info.get("infoLink") or info.get("canonicalVolumeLink") or "",
            "preview_url": info.get("previewLink") if access.get("viewability") not in (None, "NO_PAGES") else "",
            "free_url": ((access.get("pdf") or {}).get("downloadLink")
                         or (access.get("epub") or {}).get("downloadLink") or "")
            if access.get("accessViewStatus") == "FULL_PUBLIC_DOMAIN" else "",
            "source": "google_books",
        })
    return out


def parse_open_library(data: dict | None) -> list[dict]:
    out = []
    for doc in (data or {}).get("docs") or []:
        isbns = [i for i in doc.get("isbn") or [] if len(i) == 13]
        key = doc.get("key") or ""
        cover_id = doc.get("cover_i")
        out.append({
            "title": doc.get("title") or "",
            "subtitle": doc.get("subtitle") or "",
            "authors": doc.get("author_name") or [],
            "publisher": (doc.get("publisher") or [""])[0],
            "year": str(doc.get("first_publish_year") or ""),
            "isbn13": isbns[0] if isbns else None,
            "cover": f"https://covers.openlibrary.org/b/id/{cover_id}-M.jpg" if cover_id else "",
            "catalog_url": f"https://openlibrary.org{key}" if key else "",
            "preview_url": "",
            "free_url": (f"https://archive.org/details/{doc['ia'][0]}"
                         if doc.get("ia") and doc.get("ebook_access") in ("borrowable", "public")
                         else ""),
            "borrowable": doc.get("ebook_access") in ("borrowable", "public"),
            "source": "open_library",
        })
    return out


def parse_openstax(data: dict | None, query: str) -> list[dict]:
    """OpenStax books whose title shares a word with the query."""
    words = {w for w in re.findall(r"[a-z]+", (query or "").lower()) if len(w) > 3}
    out = []
    for item in (data or {}).get("items") or []:
        title = item.get("title") or ""
        if not words & {w for w in re.findall(r"[a-z]+", title.lower())}:
            continue
        slug = (item.get("meta") or {}).get("slug") or item.get("slug") or ""
        out.append({
            "title": title, "subtitle": "", "authors": ["OpenStax"],
            "publisher": "OpenStax (free, openly licensed)", "year": "",
            "isbn13": None,
            "cover": item.get("cover_url") or (item.get("book_cover") or ""),
            "catalog_url": f"https://openstax.org/details/books/{slug}" if slug else "https://openstax.org/subjects",
            "preview_url": "",
            "free_url": f"https://openstax.org/details/books/{slug}" if slug else "",
            "source": "openstax",
        })
    return out


def parse_archive(data: dict | None) -> list[dict]:
    out = []
    for doc in ((data or {}).get("response") or {}).get("docs") or []:
        ident = doc.get("identifier")
        if not ident:
            continue
        out.append({
            "title": doc.get("title") or ident, "subtitle": "",
            "authors": [doc["creator"]] if isinstance(doc.get("creator"), str)
            else list(doc.get("creator") or []),
            "publisher": doc.get("publisher") or "", "year": str(doc.get("year") or ""),
            "isbn13": None, "cover": f"https://archive.org/services/img/{ident}",
            "catalog_url": f"https://archive.org/details/{ident}",
            "preview_url": "", "free_url": f"https://archive.org/details/{ident}",
            "borrowable": True, "source": "internet_archive",
        })
    return out


# --------------------------------------------------------------------------


# How the four catalogues are described when one of them does not answer.
CATALOGUE_NAMES = {"google_books": "Google Books", "open_library": "Open Library",
                   "openstax": "OpenStax", "internet_archive": "the Internet Archive"}
# OpenStax books are free alternatives, not the book being searched for. Two is
# an offer; [PROVEN] four of them pushed the actual textbook off the list.
MAX_FREE_ALTERNATIVES = 2


def search(query: str, limit: int = 6) -> dict:
    """Look a book up everywhere.

    Returns {query, isbn, results, free, sources, unavailable, search_links}.
    `sources` records what each catalogue did, so the page can say "Google
    Books did not answer" instead of implying the book does not exist.
    """
    query = (query or "").strip()
    if not query:
        return {"query": query, "results": [], "free": [], "sources": {},
                "unavailable": [], "search_links": _search_links("")}
    isbn = _isbn_of(query)
    sources: dict[str, str] = {}

    def ask(name, url, params):
        payload = _get(url, params)
        sources[name] = "ok" if payload is not None else "no answer"
        return payload

    google = parse_google_books(ask(
        "google_books", GOOGLE_BOOKS,
        {"q": f"isbn:{isbn}" if isbn else query, "maxResults": limit,
         "printType": "books"}))
    ol_params = {"isbn": isbn} if isbn else {"q": query}
    ol_params.update({"limit": limit,
                      "fields": "key,title,subtitle,author_name,publisher,"
                                "first_publish_year,isbn,cover_i,ia,ebook_access"})
    openlib = parse_open_library(ask("open_library", OPEN_LIBRARY, ol_params))

    # An ISBN names one edition, and OpenStax has no ISBNs to match it against;
    # asking would only ever return unrelated free books.
    openstax = []
    if not isbn:
        openstax = parse_openstax(ask("openstax", OPENSTAX,
                                      {"type": "books.Book", "limit": 60,
                                       "fields": "title,slug,cover_url"}), query)
    archive = []
    if not isbn:
        archive = parse_archive(ask(
            "internet_archive", ARCHIVE,
            {"q": f"title:({query}) AND mediatype:texts",
             "fl[]": ["identifier", "title", "creator", "year", "publisher"],
             "rows": limit, "output": "json"}))

    # The book someone asked for comes first: the catalogues that index real
    # editions, then the free alternatives, then borrowable scans.
    results = _dedupe(google + openlib
                      + openstax[:MAX_FREE_ALTERNATIVES] + archive)[: limit * 2]
    unavailable = [CATALOGUE_NAMES.get(name, name)
                   for name, state in sources.items() if state != "ok"]
    return {"query": query, "isbn": isbn, "results": results,
            "free": [r for r in results if r.get("free_url")],
            "sources": sources, "unavailable": unavailable,
            "search_links": _search_links(query)}


def _search_links(query: str) -> dict:
    """Where to look by hand. Always offered: a catalogue that refused us will
    happily answer a browser."""
    encoded = quote_plus(query or "")
    return {
        "google_books": f"https://www.google.com/search?tbm=bks&q={encoded}",
        "open_library": f"https://openlibrary.org/search?q={encoded}",
        "internet_archive": (f"https://archive.org/search?query={encoded}"
                             "&and[]=mediatype%3A%22texts%22"),
        "openstax": "https://openstax.org/subjects",
    }


def _dedupe(results: list[dict]) -> list[dict]:
    seen: set[str] = set()
    out = []
    for result in results:
        key = result.get("isbn13") or re.sub(r"[^a-z0-9]", "", (result.get("title") or "").lower())[:40]
        if not key or key in seen:
            continue
        seen.add(key)
        out.append(result)
    return out
