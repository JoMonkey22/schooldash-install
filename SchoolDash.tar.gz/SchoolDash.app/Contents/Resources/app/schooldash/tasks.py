"""Custom tasks — things the student adds themselves, in chat ("Robotics workshop
schedule 8/24") or via the API. They live in the database, flow through the
same Item shape as everything else, and are honest about their origin:
extractor "manual", date_note says who added it and when.
"""

import hashlib
import re
from datetime import date, datetime

from schooldash import db, scoring, timezones
from schooldash.models import Item, course_key_from_raw

# Where a hand-added task belongs. "school" is homework like any other row;
# the rest are the things a student carries that no teacher posts — and that
# he asked to see in their own place: *"makeup / personal goals / project
# stuff / sport practices"*. The section rides in `flags` as "section:<name>"
# so the board can group it without a new field on Item.
SECTIONS = {"school", "clubs", "upcoming", "goals", "practice", "makeup",
            "personal"}


def _task_id(title: str, created: str) -> str:
    return hashlib.sha1(f"custom|{title}|{created}".encode("utf-8")).hexdigest()[:16]


RE_SLASH = re.compile(r"^\s*(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?\s*$")


def normalize_due(text: str | None, year_hint: int | None = None) -> str | None:
    """'8/24' or '2026-08-24' -> ISO date; anything else -> None (the task is
    still added, undated — never guessed)."""
    if not text:
        return None
    text = text.strip()
    try:
        return date.fromisoformat(text).isoformat()
    except ValueError:
        pass
    match = RE_SLASH.match(text)
    if match:
        month, day = int(match.group(1)), int(match.group(2))
        year = match.group(3)
        if year:
            year = int(year) + (2000 if int(year) < 100 else 0)
        else:
            hint = year_hint or datetime.now(timezones.zone()).year
            year = hint if month >= 7 else (hint + 1 if hint and month < 7 else hint)
        try:
            return date(year, month, day).isoformat()
        except ValueError:
            return None
    return None


# What a person can say a piece of work IS. "assignment" is the neutral default;
# the rest exist so a quiz can be told apart from homework, which is the whole
# point of asking.
CATEGORIES = ("assignment", "quiz", "test", "project", "essay", "reading",
              "problem_set", "discussion")


def add(conn, title: str, due_date: str | None = None, course: str | None = None,
        section: str | None = None, notes: str | None = None,
        category: str | None = None) -> dict:
    title = (title or "").strip()
    if not title:
        raise ValueError("a task needs a title")
    created = datetime.now(timezones.zone()).isoformat(timespec="seconds")
    item_id = _task_id(title, created)
    section = section if section in SECTIONS else None
    category = category if category in CATEGORIES else None
    db.add_custom_task(conn, item_id, title, due_date, course, section, notes,
                       category)
    return to_item(dict(item_id=item_id, title=title, due_date=due_date,
                        course=course, section=section, notes=notes,
                        created=created, category=category)).to_dict()


def to_item(row: dict) -> Item:
    created_label = (row.get("created") or "")[:10]
    course = row.get("course") or "Personal"
    item = Item(
        source="custom",
        course_key=course_key_from_raw(course),
        course=course,
        title=row["title"][:110],
        detail=row.get("notes") or row["title"],
        raw_cell=row["title"],
        kind="custom task",
        # What the person said it is, or what the title says it is. Everything
        # added by hand used to be "neutral", so a quiz someone typed in was
        # indistinguishable from a reading — and then it could not be studied
        # for, scored as a quiz, or shown with a quiz tag.
        category=(row.get("category")
                  or scoring.categorize(row.get("title") or "")),
        due=(f"{row['due_date']}T23:59:00" if row.get("due_date") else None),
        due_date=row.get("due_date"),
        all_day=True,
        date_note=f"added by you on {created_label}"
                  + ("" if row.get("due_date") else " (no date given)"),
        confidence="high",
        extractor="manual",
        url=None,
        links=[],
        flags=(["clubs"] if row.get("section") == "clubs" else [])
              + ([f"section:{row['section']}"]
                 if row.get("section") in SECTIONS - {"school", "upcoming"}
                 else []),
    )
    item.finalize()
    # a stable id independent of title edits is already stored — keep it
    item.item_id = row["item_id"]
    return item


def all_items(conn) -> list[Item]:
    return [to_item(row) for row in db.list_custom_tasks(conn)]
