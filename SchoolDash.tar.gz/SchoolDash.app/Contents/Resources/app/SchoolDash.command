#!/bin/bash
# SchoolDash — macOS double-click launcher.
# Starts the server detached (or reuses a running one) and opens the browser.
# Failures land in logs/schooldash.log.
cd "$(dirname "$0")" || exit 1
if [ -x ".venv/bin/python" ]; then
    PY=".venv/bin/python"
else
    PY=python3
    command -v python3 >/dev/null 2>&1 || PY=python
fi
"$PY" run.py serve --detach --open-browser
