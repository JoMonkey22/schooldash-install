#!/usr/bin/env python3
"""SchoolDash — the single CLI entry point for every operation.

Daily use never needs this file directly: double-click start.pyw (Windows) or
SchoolDash.command (macOS). Works under `python` and `python3` alike.
"""

import argparse
import sys

# Every entry point emits UTF-8, whatever the console code page says.
# The predecessor's CLI crashed on Windows' cp1252 console over an emoji.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8")
    except Exception:
        pass


def _not_implemented(name):
    def handler(args):
        print(f"{name}: not implemented yet")
        return 1
    return handler


def cmd_health(args):
    from schooldash import health
    return health.run(verbose=getattr(args, "verbose", False))


def cmd_meetings(args):
    from schooldash.feeds import classfeed
    return classfeed.cli_meetings(week=args.week, verbose=args.verbose)


def cmd_login(args):
    from schooldash import browser
    return browser.cli_login(canvas_feed=args.canvas_feed, veracross=args.veracross,
                             check=args.check, reset=args.reset,
                             auto=args.auto, all_sites=args.all, as_json=args.json)


def cmd_refresh(args):
    from schooldash import pipeline
    return pipeline.cli_refresh(
        docs_only=args.docs_only, profiles_dir=args.profiles_dir,
        course=args.course, verbose=args.verbose,
        include_private_docs=not args.skip_private_docs)


def cmd_setup(args):
    if args.missing:
        from schooldash.profiling import builder
        return builder.cli_learn_missing()
    if args.import_legacy:
        from schooldash import legacy_import
        code = legacy_import.cli_import()
        if code or not args.profile_all:
            return code
    from schooldash.profiling import builder
    return builder.cli_setup(profile_all=args.profile_all)


def cmd_discover(args):
    from schooldash.docs import discover
    return discover.cli_discover()


def cmd_serve(args):
    from schooldash.web import app
    return app.cli_serve(detach=args.detach, open_browser=args.open_browser)


def cmd_app(args):
    from schooldash import window
    return window.cli_app(path=args.path)


def cmd_notify(args):
    if args.schedule or args.unschedule:
        from schooldash import schedule_mac
        return schedule_mac.install() if args.schedule else schedule_mac.remove()
    from schooldash import notify
    return notify.cli_notify(refresh=args.refresh, dry_run=args.dry_run)


def cmd_profiles(args):
    from schooldash.profiling import store
    return store.cli_profiles()


def cmd_profile(args):
    from schooldash.profiling import builder
    return builder.cli_profile(course=args.course, relearn=args.relearn)


def cmd_explain(args):
    from schooldash import pipeline
    return pipeline.cli_explain(args.item_id)


def cmd_grant(args):
    """Record a payment that arrived out of band (Venmo, cash, anything).

    The money never touches this program. This only writes down that it came,
    so the account server starts letting that email in.
    """
    from schooldash import account
    return account.cli_grant(args.email, args.months, getattr(args, "plan", None))


def cmd_keepalive(args):
    from schooldash import keepalive
    return keepalive.cli_keepalive()


def cmd_grades(args):
    """Just the grades. A full refresh spends its time on teacher docs, and
    "my grades are not showing" needs none of that work redone."""
    import json

    from schooldash import pipeline

    result = pipeline.refresh_grades(
        pipeline.RefreshOptions(persist=not getattr(args, "dry_run", False)))
    if getattr(args, "json", False):
        print(json.dumps(result, indent=2, default=str))
        return 0 if result.get("ok") else 1
    if not result.get("ok"):
        print(f"Could not read your grades: {result['error']}")
        if result.get("kept"):
            print(f"  the {result['kept']} grade(s) already on the board are "
                  "kept and labelled with their date")
        if result.get("fix"):
            print(f"  try: {result['fix']}")
        return 1
    print(f"{result['courses']} course(s), {result['graded']} with a grade")
    for g in result.get("grades") or []:
        mark = (f"{g['letter']:<3} {g['percent']:.2f}%"
                if g.get("graded") and g.get("percent") is not None
                else "no graded work yet")
        print(f"  {g.get('display_name', g.get('course_key', '?')):<38} {mark}")
    return 0


def cmd_eval_chat(args):
    from schooldash.ai import grounding
    return grounding.cli_eval_chat(live=getattr(args, "live", False))


def build_parser():
    parser = argparse.ArgumentParser(prog="run.py", description=__doc__)
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("health", help="environment, config, and pipeline status")
    p.add_argument("--verbose", action="store_true")
    p.set_defaults(func=cmd_health)

    p = sub.add_parser("login", help="manual login into the dedicated browser profile")
    p.add_argument("--canvas-feed", action="store_true",
                   help="capture the Canvas personal calendar-feed URL into config")
    p.add_argument("--veracross", action="store_true",
                   help="one-time Veracross login; capture its feed URLs")
    p.add_argument("--check", action="store_true", help="report session state only")
    p.add_argument("--reset", action="store_true", help="wipe the browser profile")
    p.add_argument("--auto", action="store_true",
                   help="sign in with the saved details (Settings → Accounts); "
                        "opens a window only if a step needs a person")
    p.add_argument("--all", action="store_true",
                   help="with --auto: Canvas and Veracross both")
    p.add_argument("--json", action="store_true",
                   help="with --auto: end with a JSON line the dashboard reads")
    p.set_defaults(func=cmd_login)

    p = sub.add_parser("setup", help="first-run setup: courses, docs, profiles")
    p.add_argument("--profile-all", action="store_true")
    p.add_argument("--missing", action="store_true",
                   help="learn only the courses that have no profile yet "
                        "(what the app's Setup screen runs)")
    p.add_argument("--import-legacy", action="store_true",
                   help="import feed URLs + doc list from ../assignment-tracker")
    p.set_defaults(func=cmd_setup)

    p = sub.add_parser("discover", help="re-scan homepages: did a teacher swap/add/remove a doc?")
    p.set_defaults(func=cmd_discover)

    p = sub.add_parser("refresh", help="run the full pipeline once")
    p.add_argument("--docs-only", action="store_true")
    p.add_argument("--profiles-dir", help="use hand-authored profiles from this directory")
    p.add_argument("--course", help="only this course_key")
    # Private docs are read by default now (COUNT 29): skipping them dropped
    # two courses' homework from every refresh the app ran. The old flag stays
    # accepted so anything scripted against it keeps working; the useful one
    # is now the opposite, for a fast dev run that skips the browser.
    p.add_argument("--include-private-docs", action="store_true",
                   help=argparse.SUPPRESS)
    p.add_argument("--skip-private-docs", action="store_true",
                   help="do not open a browser for class-only docs (faster, "
                        "but two of his courses lose their homework)")
    p.add_argument("--verbose", action="store_true")
    p.set_defaults(func=cmd_refresh)

    p = sub.add_parser("serve", help="serve the dashboard at http://127.0.0.1:5055/")
    p.add_argument("--detach", action="store_true",
                   help="spawn, wait for the port to answer, return")
    p.add_argument("--open-browser", action="store_true")
    p.set_defaults(func=cmd_serve)

    p = sub.add_parser("app", help="open SchoolDash in its own window (starts the "
                                   "server first if it is not running)")
    p.add_argument("--path", default="/", help="which page to open, e.g. /setup")
    p.set_defaults(func=cmd_app)

    p = sub.add_parser("publish", help="build the anywhere-view page; push to Netlify if configured")
    p.add_argument("--local-only", action="store_true")
    p.set_defaults(func=lambda a: __import__(
        "schooldash.publish", fromlist=["cli_publish"]).cli_publish(
        local_only=a.local_only))

    p = sub.add_parser("schedule", help="the automatic refresh+publish schedule")
    p.add_argument("--install", action="store_true")
    p.add_argument("--remove", action="store_true")
    p.set_defaults(func=lambda a: __import__(
        "schooldash.schedule_tasks", fromlist=["cli_schedule"]).cli_schedule(
        install_flag=a.install, remove_flag=a.remove))

    p = sub.add_parser("notify", help="post a macOS banner for what is due, "
                                      "or manage the schedule that does it")
    p.add_argument("--refresh", action="store_true",
                   help="pull fresh data first (what the scheduled run does)")
    p.add_argument("--dry-run", action="store_true",
                   help="print the banner instead of posting it")
    p.add_argument("--schedule", action="store_true",
                   help="install the launchd agent (macOS)")
    p.add_argument("--unschedule", action="store_true")
    p.set_defaults(func=cmd_notify)

    p = sub.add_parser("meetings", help="the class schedule from the feed")
    p.add_argument("--week", action="store_true", help="this week instead of today")
    p.add_argument("--verbose", action="store_true")
    p.set_defaults(func=cmd_meetings)

    p = sub.add_parser("profiles", help="list class profiles")
    p.set_defaults(func=cmd_profiles)

    p = sub.add_parser("profile", help="inspect or relearn one course profile")
    p.add_argument("--course", required=True)
    p.add_argument("--relearn", action="store_true")
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("explain", help="one item: raw_cell, which rule fired, and why")
    p.add_argument("item_id")
    p.set_defaults(func=cmd_explain)

    p = sub.add_parser("grant",
                       help="after someone pays you, switch their subscription on")
    p.add_argument("email", help="the email they signed up with")
    p.add_argument("--months", type=int, default=1,
                   help="months to add (default 1; 0 revokes)")
    p.add_argument("--plan", default="basic",
                   choices=["basic", "plus"],
                   help="what they paid for: basic $4.99, or plus $10.00 with "
                        "ten times the chat and guides (default basic)")
    p.set_defaults(func=cmd_grant)

    p = sub.add_parser("keepalive",
                       help="touch the Veracross portal so its 30-minute "
                            "session does not lapse")
    p.set_defaults(func=cmd_keepalive)

    p = sub.add_parser("grades",
                       help="read just the course grades and update the board "
                            "(much faster than a full refresh)")
    p.add_argument("--json", action="store_true")
    p.add_argument("--dry-run", action="store_true",
                   help="read them and print, without writing to the board")
    p.set_defaults(func=cmd_grades)

    p = sub.add_parser("eval-chat",
                       help="replay the question set; report correctness plus "
                            "tuned and untuned grounding")
    p.add_argument("--live", action="store_true",
                   help="evaluate against the real cache instead of the frozen "
                        "fixture (a fixture cannot notice today's data breaking)")
    p.set_defaults(func=cmd_eval_chat)

    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "command", None):
        parser.print_help()
        return 0
    try:
        return args.func(args) or 0
    except ModuleNotFoundError as exc:
        # A phase that has not been built yet imports a module that is absent.
        print(f"{args.command}: not implemented yet ({exc.name} is missing)")
        return 1


if __name__ == "__main__":
    sys.exit(main())
