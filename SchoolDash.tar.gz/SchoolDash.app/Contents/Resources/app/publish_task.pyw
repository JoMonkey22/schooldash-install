"""SchoolDash scheduled refresh+publish (Task Scheduler runs this, console-less).

Slot logic: school days publish at the school-day times, weekends/breaks at the
off-day times; a run whose slot does not apply today exits quietly. "School
day" = the class feed has meetings today (a break day is simply absent from
the feed, so breaks handle themselves). Everything logs to logs/schooldash.log
— the only place a silent failure can surface.
"""

import sys
import traceback
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

SLOT_TOLERANCE_MIN = 25


def main():
    from schooldash import config, pipeline, timezones
    from schooldash.logging_setup import get, setup

    setup(console=False)
    log = get("publish_task")
    now = datetime.now(timezones.zone())

    state = pipeline.load_state() or {}
    todays = (state.get("schedule") or {}).get(now.date().isoformat())
    if todays is None:
        todays = state.get("meetings_today") if state.get("today") == now.date().isoformat() else None
    school_day = bool(todays) if todays is not None else now.weekday() < 5

    pub = config.load()["publish"]
    slots = pub["schedule_school"] if school_day else pub["schedule_off"]
    minutes_now = now.hour * 60 + now.minute

    def near(hhmm):
        hours, minutes = hhmm.split(":")
        return abs(minutes_now - (int(hours) * 60 + int(minutes))) <= SLOT_TOLERANCE_MIN

    if not any(near(slot) for slot in slots):
        log.info("publish_task: %s is not a %s slot (%s) — skipping",
                 now.strftime("%H:%M"),
                 "school-day" if school_day else "off-day", ", ".join(slots))
        return

    log.info("publish_task: %s slot on a %s — refreshing",
             now.strftime("%H:%M"), "school day" if school_day else "day off")
    pipeline.refresh(pipeline.RefreshOptions())

    from schooldash import publish
    code = publish.cli_publish()
    log.info("publish_task: publish exited %s", code)


if __name__ == "__main__":
    try:
        main()
    except Exception:  # noqa: BLE001 — console-less: the log is the only witness
        try:
            from schooldash.logging_setup import get, setup
            setup(console=False)
            get("publish_task").error("publish_task crashed:\n%s",
                                      traceback.format_exc())
        except Exception:
            (HERE / "logs").mkdir(exist_ok=True)
            with (HERE / "logs" / "schooldash.log").open("a", encoding="utf-8") as f:
                f.write(traceback.format_exc())
