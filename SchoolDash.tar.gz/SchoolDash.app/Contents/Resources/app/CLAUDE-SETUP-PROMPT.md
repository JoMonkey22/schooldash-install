# The prompt to hand Claude

Open **Claude Code** — in the desktop app, or by running `claude` in Terminal —
and paste everything in the box below. Claude will do the install and stop when
it reaches the one part only you can do: typing your own school password.

If you do not have Claude Code, follow [`SETUP-FROM-GIT.md`](SETUP-FROM-GIT.md)
by hand instead. It installs the same thing.

---

```
Set up SchoolDash on this Mac from its GitHub repo. Do everything you can
yourself; stop only for what is genuinely mine to do.

1. Confirm this is macOS 12 or later, then run `git --version`. If that pops
   up the Xcode Command Line Tools dialog, tell me to click Install and wait
   for it — it needs no password.

2. Clone the repo, if it is not already there:
      git clone https://github.com/ElMagoCT/schooldash.git ~/schooldash
   If git asks for a username or password, STOP and tell me: my GitHub access
   is not set up, and I will fix that myself. Never type a credential for me.

3. Run the installer once, and show me what it prints:
      cd ~/schooldash && ./packaging/setup-from-git.sh
   It builds the app from the clone, installs it to ~/Applications, pins it to
   the Dock and opens it. No administrator password is needed. Do not re-run
   it to see whether it works the second time.

4. First launch downloads its own Python and Chromium — about 150 MB, a few
   minutes. Watch it rather than guessing:
      tail -f "$HOME/Library/Application Support/SchoolDash/logs/schooldash.log"
   Tell me when the window is open. If it fails, read that log and tell me in
   plain words what it actually said.

5. STOP THERE and hand it back to me. The window opens on a Setup screen whose
   first step asks for my school Google email and password. That step is mine:
   do not type, read back, or store my password, and do not offer to. Tell me
   to work through step 1 (Save and continue), step 2 (Open the sign-in
   windows), step 3 (Detect materials and learn my classes) and step 4 (Pull
   my homework now), and to tell you when the board shows my homework.

6. Then verify it properly, with the app's own python:
      PY="$HOME/Library/Application Support/SchoolDash/venv/bin/python"
      cd ~/Applications/SchoolDash.app/Contents/Resources/app
      "$PY" run.py health
   Tell me plainly: is Canvas connected, was the class-schedule feed found,
   when was the last pull, and which of my courses came out `learned` rather
   than `heuristic`.

7. For any `heuristic` course, explain that nobody has taught SchoolDash how
   that teacher writes their homework doc, so prose-shaped homework in it gets
   missed silently. Then ask me — do not assume — about either of these:
      "$PY" run.py setup --profile-all     # learns them; uses my Claude sub
      "$PY" run.py notify --schedule       # homework reminders, 7am and 5pm

I am not a developer: explain in plain steps, and tell me what you actually
observed rather than what should have happened. Never enter a password of
mine. Nothing in this setup needs an administrator password — if something
asks for one, stop and tell me instead of working around it.
```

---

## What Claude cannot do for you

**Your school Google password.** Step 1 of the app's own Setup screen is the
one manual part, by design: Claude should not type your password, and the
sign-in may ask for a phone tap or a verification code that only you can
answer. Everything either side of it is automated.

**Anything asking for an administrator password.** Nothing in this setup needs
one. If something asks, that is a signal something has gone wrong — say so
rather than entering it.
