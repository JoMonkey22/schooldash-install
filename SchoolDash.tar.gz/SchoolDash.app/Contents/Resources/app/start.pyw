"""SchoolDash — Windows double-click launcher.

.pyw => pythonw => NO console window, so stdout/stderr do not exist and every
failure must land in logs/schooldash.log — the only place it can surface.

Behavior (ported from the working predecessor): start the server in-process,
wait for the port to answer, open the default browser. If the port already
answers, open the browser only — never a second server.
"""

import sys
import threading
import time
import traceback
import webbrowser
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))


def main():
    from schooldash import config
    from schooldash.logging_setup import get, setup
    from schooldash.web.app import create_app, port_answering
    from schooldash.web.bind_guard import assert_loopback

    setup(console=False)
    log = get("launcher")
    cfg = config.load()["server"]
    host = assert_loopback(cfg["host"])
    port = cfg["port"]
    url = f"http://{host}:{port}/"

    if port_answering(host, port):
        log.info("launcher: server already answering; opening the browser only")
        webbrowser.open(url)
        return

    def open_when_ready():
        deadline = time.time() + 30
        while time.time() < deadline:
            if port_answering(host, port):
                webbrowser.open(url)
                log.info("launcher: server up, browser opened at %s", url)
                return
            time.sleep(0.4)
        log.error("launcher: the server never answered on %s:%s", host, port)

    threading.Thread(target=open_when_ready, daemon=True).start()
    log.info("launcher: starting the server at %s", url)
    app = create_app()
    app.run(host=host, port=port, threaded=True, debug=False, use_reloader=False)


if __name__ == "__main__":
    try:
        main()
    except Exception:  # noqa: BLE001 — console-less: the log is the only witness
        try:
            from schooldash.logging_setup import get, setup
            setup(console=False)
            get("launcher").error("launcher crashed:\n%s", traceback.format_exc())
        except Exception:
            (HERE / "logs").mkdir(exist_ok=True)
            (HERE / "logs" / "schooldash.log").open("a", encoding="utf-8").write(
                traceback.format_exc())
