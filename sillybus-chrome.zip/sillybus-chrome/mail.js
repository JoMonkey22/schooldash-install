/* School mail, read and FILTERED inside Chrome before any of it leaves.
 *
 * [ASKED] 2026-09-22: mail is read the Chrome-extension way, with the session
 * the student is already signed into, and only **school senders plus anything
 * school-shaped** may be read at all. [MEASURED] 2026-09-23: the Mac app's own
 * browser answers 401 on this feed — its profile is not signed into Google —
 * while the Chrome he is sitting in front of is signed in all day.
 *
 * ## Why this is not an ordinary bridge capture
 *
 * Everything else the courier fetches is posted to the app verbatim. Mail
 * cannot be, because the Mail page's promise is that mail which is not school
 * mail **never reaches the app at all** — not on disk, not in memory, not for
 * a moment. A generic capture writes what it fetched to a file, so the whole
 * unfiltered inbox would land in one. So the filter runs here, and the post
 * carries only what passed. `filterMail` is the privacy guarantee and the
 * `if (!ok) continue` inside it is the line that keeps it.
 *
 * ## The filter is not defined here
 *
 * It arrives with the job, from `bridge.mail_job()`. There is already one copy
 * of the rule in Python and one in the other extension, and a whole test file
 * exists to stop those two drifting; a third copy would be a third thing to
 * drift. The patterns are plain alternations that mean the same to Python's
 * `re` and to JavaScript's `RegExp`.
 *
 * ## Parsing without a DOM
 *
 * **A Manifest V3 service worker has no `DOMParser`.** So this scans the feed
 * rather than parsing XML in general — which is only safe because Gmail's
 * Atom feed has had one fixed, documented shape since 2004: a `fullcount`,
 * then `entry` elements with `title`, `summary`, `author/name`,
 * `author/email`, `issued`, `link` and `id`. It is not an XML parser and must
 * never be pointed at anything else.
 *
 * It never writes to Gmail. Nothing here is anything but a GET.
 */

/* A sign-in page is perfectly good XML, and an empty inbox and a lapsed
   session look identical once the entries are counted — zero. So the ROOT is
   what decides, which is the same trap `feeds/gmail.py` names. */
export function looksLikeFeed(xml) {
  return /<feed[\s>]/i.test(String(xml || "").slice(0, 2000));
}

const ENTITIES = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", "#39": "'" };

function decode(text) {
  return String(text == null ? "" : text)
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, (whole, name) => {
      const key = name.toLowerCase();
      if (ENTITIES[key]) return ENTITIES[key];
      if (key[0] === "#") {
        const code = key[1] === "x" ? parseInt(key.slice(2), 16) : parseInt(key.slice(1), 10);
        return Number.isFinite(code) ? String.fromCodePoint(code) : whole;
      }
      return whole;
    })
    .trim();
}

/* One element's text. Namespace-agnostic by local name, because Gmail serves
   Atom 0.3 (`http://purl.org/atom/ns#`) and not the 1.0 namespace most
   parsers assume. */
function tagText(block, tag) {
  const found = new RegExp(`<(?:\\w+:)?${tag}\\b[^>]*>([\\s\\S]*?)</(?:\\w+:)?${tag}>`, "i")
    .exec(block || "");
  return found ? decode(found[1]) : "";
}

/* Either quote style. [MEASURED] 2026-09-23: a double-quote-only pattern
   returned an empty `link` for `href='...'`, which is the address the Mail
   page's "open in Gmail" button is built from — so every row would have
   opened nothing, silently, on a feed that happened to use single quotes. */
function attr(block, tag, name) {
  const found = new RegExp(`<(?:\\w+:)?${tag}\\b([^>]*)>`, "i").exec(block || "");
  if (!found) return "";
  const got = new RegExp(`${name}\\s*=\\s*("([^"]*)"|'([^']*)')`, "i").exec(found[1]);
  if (!got) return "";
  return decode(got[2] !== undefined ? got[2] : got[3]);
}

export function parseMailFeed(xml) {
  if (!looksLikeFeed(xml)) {
    return { error: "that answered, but not with a mail feed",
             messages: [], unread_total: 0 };
  }
  const text = String(xml);
  const total = parseInt(tagText(text, "fullcount"), 10);
  const messages = [];
  const entries = text.match(/<(?:\w+:)?entry\b[\s\S]*?<\/(?:\w+:)?entry>/gi) || [];
  for (const entry of entries) {
    const author = (/<(?:\w+:)?author\b[\s\S]*?<\/(?:\w+:)?author>/i.exec(entry) || [""])[0];
    messages.push({
      id: tagText(entry, "id"),
      subject: tagText(entry, "title"),
      snippet: tagText(entry, "summary"),
      from_name: tagText(author, "name"),
      from_email: tagText(author, "email"),
      issued: tagText(entry, "issued") || tagText(entry, "modified"),
      link: attr(entry, "link", "href"),
    });
  }
  return { error: null, messages,
           unread_total: Number.isFinite(total) ? total : messages.length };
}

function domainOf(address) {
  const at = String(address || "").trim().toLowerCase().lastIndexOf("@");
  return at < 0 ? "" : String(address).trim().toLowerCase().slice(at + 1);
}

/* (allowed, the reason to show). The reason is not decoration: a student
   should be able to see why each message was let through, or they stop
   trusting the filter and stop using the page. Same rule as `date_note`. */
export function mailWanted(message, rules) {
  const spec = rules || {};
  const address = domainOf(message.from_email);
  for (const raw of spec.domains || []) {
    const domain = String(raw || "").trim().replace(/^@/, "").toLowerCase();
    if (domain && (address === domain || address.endsWith("." + domain))) {
      return [true, `from ${domain}`];
    }
  }
  const text = `${message.subject || ""} ${message.snippet || ""}`;
  for (const word of (spec.courses || []).slice().sort()) {
    // A class name is strong evidence on its own — nobody outside school
    // writes "AP Calculus BC" to a teenager.
    if (word && word.length >= 6 && text.toLowerCase().includes(String(word).toLowerCase())) {
      return [true, `mentions ${word}`];
    }
  }
  let work = null;
  let dated = false;
  try {
    work = new RegExp(spec.work_words, "i").exec(text);
    dated = new RegExp(spec.date_words, "i").test(text);
  } catch (err) {
    // A pattern the app sent that this engine will not compile. Letting
    // everything through would be the wrong way to fail — the whole point of
    // this file is that it is the gate.
    return [false, ""];
  }
  if (work && dated) return [true, `says “${work[0].toLowerCase()}” and names a day`];
  return [false, ""];
}

export function filterMail(parsed, rules) {
  const out = { read_at: new Date().toISOString(),
                unread_total: parsed.unread_total || 0,
                messages: [], error: null };
  for (const message of parsed.messages || []) {
    const [ok, why] = mailWanted(message, rules);
    if (!ok) continue;               /* never posted, never stored, never seen */
    out.messages.push(Object.assign({}, message, { let_through: why }));
  }
  return out;
}

/* The whole job: fetch with this browser's own Google cookies, parse, filter,
   and answer with what may leave. Throws with a sentence a student can read;
   the caller turns that into the line on the popup. */
export async function readMail(job) {
  const rules = (job && job.filter) || {};
  let response;
  try {
    response = await fetch(job.url, { credentials: "include", redirect: "follow" });
  } catch (err) {
    throw new Error("your mail could not be read just now");
  }
  if (response.status === 401 || response.status === 403) {
    throw new Error("Gmail wants you to sign in again in this browser");
  }
  if (!response.ok) throw new Error(`Gmail answered HTTP ${response.status}`);
  const parsed = parseMailFeed(await response.text());
  if (parsed.error) {
    throw new Error("Gmail answered with a sign-in page rather than your mail");
  }
  return filterMail(parsed, rules);
}
