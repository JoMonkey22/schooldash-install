/* Silly Bus AI Bridge — the fetching half.
 *
 * Everything Silly Bus AI reads from Canvas and Veracross, it normally reads by
 * driving its own headless browser and signing in as the student. That is the
 * most fragile part of the whole program: Google SSO is broken in branded
 * Chrome on a cloud-managed school Mac; a Veracross session lives about
 * thirty minutes and needs a scheduled job to keep it warm; Canvas hands out
 * session-only cookies that REPLACE the persistent ones; and the Veracross
 * login sits behind a reCAPTCHA that no automation may satisfy on its own.
 *
 * The browser the student is sitting in front of has none of those problems.
 * It is already signed in to both.
 *
 * **This file is a courier and nothing else.** It asks the app which pages it
 * wants, fetches those URLs with the cookies already in this profile, and
 * posts the bodies back. It parses nothing — Silly Bus AI parses a bridged page
 * with exactly the code it uses for its own fetches, because two parsers for
 * one document is how they come to disagree. And it knows nothing about any
 * school: the URLs come from the app, whose config already holds them, so a
 * classmate elsewhere needs no change here.
 *
 * Nothing is sent anywhere except 127.0.0.1. No server, no analytics, no
 * account. A password is never seen, asked for or stored — the entire point
 * is to use a session that already exists.
 *
 * The app names the URLs, so the app could in principle name a bad one. Every
 * URL is checked against this file's own host allowlist before it is fetched,
 * because "the app tells the browser what to fetch" is otherwise a
 * redirection primitive pointed at a browser holding live school sessions.
 *
 * Service workers are ephemeral, so nothing is kept in a variable between
 * events: every listener re-reads chrome.storage, and the sweep is a
 * chrome.alarms alarm rather than setInterval.
 */

import { readMail } from "./mail.js";

const APP = "http://127.0.0.1:5055";
const ALARM = "sillybus-sweep";

/* Must agree with bridge.ALLOWED_HOSTS in the app. Checked on both sides on
 * purpose: the app is the party that could be wrong. */
const ALLOWED = [".instructure.com", "portals.veracross.com",
                 "portals-embed.veracross.com", "documents.veracross.com",
                 "docs.google.com", "drive.google.com", "mail.google.com"];

function hostAllowed(url) {
  let parsed;
  try { parsed = new URL(url); } catch (err) { return false; }
  if (parsed.protocol !== "https:") return false;
  const host = parsed.hostname.toLowerCase();
  return ALLOWED.some((ok) => host === ok || host.endsWith(ok));
}

async function token() {
  const { token } = await chrome.storage.local.get("token");
  return token || "";
}

/* ---------------- talking to the app ---------------- */

async function ask(pairing) {
  const response = await fetch(`${APP}/api/bridge/status`, {
    headers: { "X-SillyBus-Token": pairing } });
  if (response.status === 403) {
    throw new Error("that pairing code is not this Mac's — copy it again "
      + "from Silly Bus AI Settings");
  }
  if (!response.ok) throw new Error(`the app answered ${response.status}`);
  return await response.json();
}

async function send(kind, key, page, url, pairing) {
  const response = await fetch(`${APP}/api/bridge/capture`, {
    method: "POST",
    headers: { "Content-Type": "application/json",
               "X-SillyBus-Token": pairing },
    /* `headers` carries the two the app keeps (bridge.KEPT_HEADERS), and
       `link` is not a nicety: Canvas paginates through it and nothing else
       says how many pages there are, so a capture without it serves page one
       and silently loses the rest. */
    body: JSON.stringify({ kind, key, body: page.body, url,
                           headers: page.headers }),
  });
  let payload = {};
  try { payload = await response.json(); } catch (err) { /* not JSON */ }
  if (!response.ok || payload.error) {
    throw new Error((payload.error && payload.error.message)
      || `the app answered ${response.status}`);
  }
  return payload.saved;
}

/* ---------------- reading the school's pages ---------------- */

/* `credentials: "include"` is the whole reason this extension exists: the
 * cookies already in this profile. Without it the fetch is anonymous and
 * Veracross answers with a sign-in screen — which would then be posted back
 * and parsed as a gradebook holding no marks. So a reply that is plainly a
 * login page is refused here rather than handed on. */
async function grab(url) {
  const response = await fetch(url, {
    credentials: "include",
    redirect: "follow",
    headers: { "Accept": "text/html,application/json;q=0.9,*/*;q=0.8" },
  });
  if (!response.ok) throw new Error(`answered ${response.status}`);
  const text = await response.text();
  const head = text.slice(0, 4000);
  if (/id="?username|Sign in with Google|<title>[^<]*(Log ?in|Sign ?in)/i.test(head)) {
    throw new Error("came back as a sign-in screen — open it in a tab, "
      + "sign in, then try again");
  }
  if (!text.trim()) throw new Error("came back empty");
  return { body: text, headers: {
    link: response.headers.get("link") || "",
    "content-type": response.headers.get("content-type") || "",
  } };
}

/* How long the overlay's copy of the board is good for; see `board()`. */
const BOARD_MS = 5 * 60 * 1000;

/* ---------------- the one job everything calls ---------------- */

async function runCapture() {
  const pairing = await token();
  if (!pairing) {
    return { ok: false, sent: 0,
             problems: ["not paired yet — paste the code from Silly Bus AI Settings"] };
  }
  let status;
  try {
    status = await ask(pairing);
  } catch (err) {
    const why = /pairing code/.test(err.message) ? err.message
      : "Silly Bus AI is not running on this Mac. Open it and try again.";
    return { ok: false, sent: 0, problems: [why] };
  }

  /* ---- keep ourselves current --------------------------------------------
   *
   * The app ships this extension inside its own bundle, so when the app
   * updates, the files on disk change under a Chrome still running the old
   * ones — and an unpacked extension does not notice until somebody presses
   * Reload. [MEASURED] 2026-09-23: that is how a student ends up at
   * chrome://extensions fixing something they did nothing to break.
   *
   * `chrome.runtime.reload()` on an unpacked extension re-reads it from disk,
   * exactly as the Reload button does. Nothing is downloaded and nothing is
   * executed that was not already on this Mac — the files are the ones the
   * app installed. The version is only ever compared for INEQUALITY, so an
   * app rolled back to an older build brings the extension back with it.
   */
  const mine = chrome.runtime.getManifest().version;
  if (status.extension_version && status.extension_version !== mine) {
    await chrome.storage.local.set({
      lastProblems: [`updating to ${status.extension_version} — reading again in a moment`],
      lastRun: Date.now(), lastSent: 0,
    });
    chrome.runtime.reload();
    return { ok: false, sent: 0, reloading: true,
             problems: [`updating to ${status.extension_version}`] };
  }

  const problems = [];
  let sent = 0;
  const list = Array.isArray(status.wanted) ? status.wanted : [];
  if (!list.length) {
    problems.push(status.wanted_error
      || "nothing to fetch — everything the app wanted is already fresh");
  }
  for (const item of list) {
    const label = item.name || item.key || item.kind;
    if (!hostAllowed(item.url)) {
      problems.push(`${label}: refused — ${item.url} is not a school address`);
      continue;
    }
    try {
      /* Mail is the one job that is not posted verbatim. The Mail page's
         promise is that mail which is not school mail never reaches the app
         at all, and a generic capture writes what it fetched to a file — so
         the filter runs HERE, in Chrome, and only what passed is sent. See
         mail.js. */
      const page = item.kind === "gmail"
        ? { body: JSON.stringify(await readMail(item)), headers: {} }
        : await grab(item.url);
      await send(item.kind, item.key, page, item.url, pairing);
      sent += 1;
    } catch (err) {
      problems.push(`${label}: ${err.message}`);
    }
  }
  // New pages reached the app, so what it would say has changed.
  await chrome.storage.local.remove(["boardAt", "boardData"]);
  const at = Date.now();
  await chrome.storage.local.set({ lastRun: at, lastSent: sent,
                                   lastProblems: problems.slice(0, 6) });
  await chrome.action.setBadgeText({ text: sent ? String(sent) : "" });
  await chrome.action.setBadgeBackgroundColor({
    color: sent ? "#2563EB" : "#B03024" });
  return { ok: sent > 0, sent, problems, at };
}

/* ---------------- the board, for the overlay on Canvas ----------------
 *
 * [ASKED] 2026-09-23: *"in the chrome extetion I want it to be like better
 * campus where it changes and adds the assignments and grade and other info
 * for the class"*.
 *
 * **The content script is never given the pairing token.** It runs inside
 * canvas.instructure.com, which is a page written by somebody else; anything
 * handed to it is handed to that page. So the fetch happens here, in the
 * worker, and only the answer crosses over.
 *
 * Held for a few minutes because Canvas is a lot of page views and the board
 * changes once a refresh, not once a click. Short enough that a refresh he
 * just ran shows up on the next page he opens.
 */
async function board() {
  /* **In storage, not in a variable.** [MEASURED] by an existing test
     (test_the_worker_keeps_no_state_in_a_variable): a Manifest V3 service
     worker is terminated after about thirty seconds idle, so a module-level
     `let` is empty again by the next message. A cache like that is not a
     cache — it would have meant one fetch to the Mac app per Canvas page
     view, which is the thing it was written to avoid. */
  const held = await chrome.storage.local.get(["boardAt", "boardData"]);
  if (held.boardData && Date.now() - (held.boardAt || 0) < BOARD_MS) {
    return { ok: true, board: held.boardData, cached: true };
  }
  const pairing = await token();
  if (!pairing) return { ok: false, why: "not paired yet" };
  let response;
  try {
    response = await fetch(`${APP}/api/bridge/board`, {
      headers: { "X-SillyBus-Token": pairing },
    });
  } catch (err) {
    return { ok: false, why: "Silly Bus AI is not running on this Mac" };
  }
  if (!response.ok) return { ok: false, why: `the app answered ${response.status}` };
  let payload;
  try { payload = await response.json(); } catch (err) {
    return { ok: false, why: "the app sent something that was not a board" };
  }
  if (payload && payload.error) {
    return { ok: false, why: (payload.error.message || "the app refused") };
  }
  await chrome.storage.local.set({ boardAt: Date.now(), boardData: payload });
  return { ok: true, board: payload, cached: false };
}

/* ---------------- wiring ---------------- */

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      if (message && message.type === "capture") {
        sendResponse(await runCapture());
        return;
      }
      if (message && message.type === "board") {
        sendResponse(await board());
        return;
      }
      if (message && message.type === "status") {
        const pairing = await token();
        const saved = await chrome.storage.local.get(
          ["lastRun", "lastSent", "lastProblems", "auto"]);
        let app = { running: false, paired: false, held: 0, wanted: 0 };
        if (pairing) {
          try {
            const status = await ask(pairing);
            app = { running: true, paired: true,
                    held: Object.values(status.held || {})
                      .reduce((total, rows) => total + rows.length, 0),
                    wanted: (status.wanted || []).length,
                    freshMinutes: status.fresh_minutes,
                    /* What the app says this extension ought to be. The popup
                       is the one page re-read from disk every time it opens,
                       so it is the one place that can always act on this even
                       while THIS worker is running older code. */
                    extensionVersion: status.extension_version || "" };
          } catch (err) {
            app = { running: !/not running/.test(err.message), paired: false,
                    why: err.message, held: 0, wanted: 0 };
          }
        }
        sendResponse({ paired: !!pairing, app, ...saved });
        return;
      }
      sendResponse({ ok: false });
    } catch (err) {
      sendResponse({ ok: false, sent: 0,
                     problems: [String((err && err.message) || err)] });
    }
  })();
  return true;                 // the channel stays open for the async reply
});

chrome.runtime.onInstalled.addListener(async () => {
  // Hourly, not every few minutes: a gradebook changes when a teacher marks
  // something, and the app treats a capture as fresh for four hours anyway.
  await chrome.alarms.create(ALARM, { periodInMinutes: 60, delayInMinutes: 2 });
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== ALARM) return;
  const saved = await chrome.storage.local.get(["auto", "token"]);
  if (saved.auto === false || !saved.token) return;
  try {
    await runCapture();
  } catch (err) {
    // A failed sweep is not worth a notification. The popup says why, and the
    // app carries on signing in for itself exactly as it did before.
    console.warn("[sillybus] hourly capture failed:", err);
  }
});
