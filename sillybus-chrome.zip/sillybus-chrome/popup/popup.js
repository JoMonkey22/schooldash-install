/* The popup: one sentence about what is happening, and one button.
 *
 * It holds no logic of its own — every decision is the service worker's, and
 * this asks it. That way the hourly sweep and the button do the same thing by
 * construction rather than by two implementations agreeing.
 */

const $ = (sel) => document.querySelector(sel);

function say(text, tone) {
  const lead = $("#lead");
  lead.textContent = text;
  lead.className = "lead" + (tone ? ` ${tone}` : "");
}

function showProblems(lines) {
  const box = $("#problems");
  const list = (lines || []).filter(Boolean);
  box.hidden = !list.length;
  box.innerHTML = "";
  for (const line of list) {
    const item = document.createElement("li");
    item.textContent = line;                 // textContent, never innerHTML:
    box.appendChild(item);                   // these strings quote a server
  }
}

function ago(stamp) {
  if (!stamp) return "";
  const minutes = Math.round((Date.now() - stamp) / 60000);
  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.round(minutes / 60);
  return hours === 1 ? "an hour ago" : `${hours} hours ago`;
}

async function refresh() {
  const status = await chrome.runtime.sendMessage({ type: "status" });
  const app = status.app || {};
  $("#pair").hidden = !!status.paired;
  $("#ready").hidden = !status.paired;
  $("#unpair").hidden = !status.paired;
  $("#auto").checked = status.auto !== false;

  if (!status.paired) {
    say("Not paired yet. Silly Bus AI needs to know this browser is yours.");
    showProblems([]);
    return;
  }
  if (!app.running) {
    say("Silly Bus AI is not running on this Mac. Open it, then press the "
      + "button.", "bad");
  } else if (!app.paired) {
    say(app.why || "That pairing code is not this Mac's.", "bad");
  } else if (app.wanted) {
    say(`${app.wanted} page${app.wanted === 1 ? "" : "s"} to hand over.`);
  } else {
    say("Everything Silly Bus AI wanted is already fresh.", "good");
  }
  const bits = [];
  if (status.lastRun) {
    bits.push(`last sent ${status.lastSent || 0} page(s) ${ago(status.lastRun)}`);
  }
  if (app.paired) bits.push(`${app.held || 0} held by the app`);
  $("#foot").textContent = bits.join(" · ");
  showProblems(status.lastProblems);
}

$("#save").addEventListener("click", async () => {
  const code = $("#code").value.trim();
  if (!code) { say("Paste the code from Silly Bus AI Settings first.", "bad"); return; }
  await chrome.storage.local.set({ token: code });
  $("#code").value = "";
  say("Pairing…");
  await /* ---- the extension updating itself, from the one page read off disk -------
 *
 * [MEASURED] 2026-09-23. The app ships this extension inside its own bundle,
 * so an app update rewrites these files under a Chrome that is still running
 * the old ones. The service worker keeps running the code it was started
 * with, and an unpacked extension does not notice until somebody presses
 * Reload on chrome://extensions — a page whose buttons live in a shadow DOM,
 * which no automation and few students find quickly.
 *
 * **This file is different: a popup is loaded from disk every single time it
 * is opened.** So the newest code always runs here, even while the worker is
 * two versions behind — which makes clicking the toolbar icon the one action
 * that can always bring the rest up to date.
 *
 * Compared for INEQUALITY, so an app rolled back brings the extension back
 * with it. Nothing is downloaded: `chrome.runtime.reload()` re-reads the
 * folder the app already installed.
 */
async function updateIfTheAppHasMovedOn() {
  let status;
  try {
    status = await chrome.runtime.sendMessage({ type: "status" });
  } catch (err) { return false; }
  const want = status && status.extensionVersion;
  if (!want || want === chrome.runtime.getManifest().version) return false;
  say(`Updating to ${want}…`, "warn");
  chrome.runtime.reload();
  return true;
}

(async () => {
  if (await updateIfTheAppHasMovedOn()) return;
  refresh();
})();
});

$("#run").addEventListener("click", async () => {
  const button = $("#run");
  button.disabled = true;
  const was = button.textContent;
  button.textContent = "sending…";
  say("Reading your pages…");
  try {
    const out = await chrome.runtime.sendMessage({ type: "capture" });
    if (out && out.sent) {
      say(`Sent ${out.sent} page${out.sent === 1 ? "" : "s"} to Silly Bus AI.`, "good");
    } else {
      say("Nothing was sent.", "bad");
    }
    showProblems(out && out.problems);
  } finally {
    button.disabled = false;
    button.textContent = was;
    const status = await chrome.runtime.sendMessage({ type: "status" });
    $("#foot").textContent = status.lastRun
      ? `last sent ${status.lastSent || 0} page(s) ${ago(status.lastRun)}` : "";
  }
});

$("#auto").addEventListener("change", async (event) => {
  await chrome.storage.local.set({ auto: event.target.checked });
});

$("#unpair").addEventListener("click", async () => {
  await chrome.storage.local.remove(["token", "lastRun", "lastSent", "lastProblems"]);
  await chrome.action.setBadgeText({ text: "" });
  await /* ---- the extension updating itself, from the one page read off disk -------
 *
 * [MEASURED] 2026-09-23. The app ships this extension inside its own bundle,
 * so an app update rewrites these files under a Chrome that is still running
 * the old ones. The service worker keeps running the code it was started
 * with, and an unpacked extension does not notice until somebody presses
 * Reload on chrome://extensions — a page whose buttons live in a shadow DOM,
 * which no automation and few students find quickly.
 *
 * **This file is different: a popup is loaded from disk every single time it
 * is opened.** So the newest code always runs here, even while the worker is
 * two versions behind — which makes clicking the toolbar icon the one action
 * that can always bring the rest up to date.
 *
 * Compared for INEQUALITY, so an app rolled back brings the extension back
 * with it. Nothing is downloaded: `chrome.runtime.reload()` re-reads the
 * folder the app already installed.
 */
async function updateIfTheAppHasMovedOn() {
  let status;
  try {
    status = await chrome.runtime.sendMessage({ type: "status" });
  } catch (err) { return false; }
  const want = status && status.extensionVersion;
  if (!want || want === chrome.runtime.getManifest().version) return false;
  say(`Updating to ${want}…`, "warn");
  chrome.runtime.reload();
  return true;
}

(async () => {
  if (await updateIfTheAppHasMovedOn()) return;
  refresh();
})();
});

/* ---- the extension updating itself, from the one page read off disk -------
 *
 * [MEASURED] 2026-09-23. The app ships this extension inside its own bundle,
 * so an app update rewrites these files under a Chrome that is still running
 * the old ones. The service worker keeps running the code it was started
 * with, and an unpacked extension does not notice until somebody presses
 * Reload on chrome://extensions — a page whose buttons live in a shadow DOM,
 * which no automation and few students find quickly.
 *
 * **This file is different: a popup is loaded from disk every single time it
 * is opened.** So the newest code always runs here, even while the worker is
 * two versions behind — which makes clicking the toolbar icon the one action
 * that can always bring the rest up to date.
 *
 * Compared for INEQUALITY, so an app rolled back brings the extension back
 * with it. Nothing is downloaded: `chrome.runtime.reload()` re-reads the
 * folder the app already installed.
 */
async function updateIfTheAppHasMovedOn() {
  let status;
  try {
    status = await chrome.runtime.sendMessage({ type: "status" });
  } catch (err) { return false; }
  const want = status && status.extensionVersion;
  if (!want || want === chrome.runtime.getManifest().version) return false;
  say(`Updating to ${want}…`, "warn");
  chrome.runtime.reload();
  return true;
}

(async () => {
  if (await updateIfTheAppHasMovedOn()) return;
  refresh();
})();
