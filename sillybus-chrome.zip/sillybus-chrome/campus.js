/* SillyBus on Canvas's own pages.
 *
 * [ASKED] 2026-09-23: *"in the chrome extetion I want it to be like better
 * campus where it changes and adds the assignments and grade and other info
 * for the class"*.
 *
 * Canvas's pages are missing three things this program already knows, and
 * until now it only ever said them somewhere else:
 *
 *   1. A due date Canvas has wrong. `duedates.py` reads the deadline out of
 *      the assignment's own description; the place that correction matters is
 *      the page where the wrong date is printed. [ASKED] the corrected date
 *      REPLACES it, with Canvas's own on hover.
 *   2. Work Canvas never had — homework a teacher typed into their own
 *      document, which is most of some classes and invisible here by
 *      definition.
 *   3. The grade, on the dashboard cards. Canvas makes you click into each
 *      course for a number it already has.
 *
 * ## Three rules this file keeps
 *
 * **Everything it adds is marked as SillyBus's** ([ASKED]: "obviously
 * SillyBus"). Every node carries the `sb-` prefix and the accent colour. On a
 * page where one program is quietly correcting another, being able to tell
 * whose answer you are reading is not decoration.
 *
 * **It never removes anything Canvas wrote.** A replaced due date keeps the
 * original in a `title` and in a data attribute; nothing is deleted, so a
 * wrong correction costs a confusing line and never a missed deadline.
 *
 * **It is idempotent and it survives Canvas's own re-rendering.** Canvas
 * redraws lists after its own fetches, so decorating once on load decorates a
 * page that is about to be thrown away. Everything is keyed by a marker
 * attribute and re-applied from a MutationObserver.
 *
 * The board arrives from the service worker, which holds it for a few minutes
 * — a content script has no pairing token and must never be given one, and
 * one fetch per Canvas page view would be a fetch per click.
 */

(() => {
  "use strict";
  if (window.__sillybusCampus) return;      // one instance per page, ever
  window.__sillybusCampus = true;

  const MARK = "data-sb";                   // "this node has been handled"
  const RE_COURSE = /\/courses\/(\d+)/;
  const RE_ASSIGNMENT = /\/courses\/\d+\/assignments\/(\d+)/;
  const DAY = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const MONTH = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                 "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

  let BOARD = null;

  /* Where a row came from, when it did not come from Canvas — which is the
     whole reason a panel is worth having on a Canvas page. Short on the chip,
     in full on hover. */
  const SOURCE_SHORT = { doc: "doc", custom: "yours", ap_classroom: "AP",
                         albert: "Albert", veracross: "VC", gmail: "mail" };
  const SOURCE_WORDS = {
    doc: "from your teacher's own document — Canvas does not have this one",
    custom: "you added this yourself",
    ap_classroom: "from AP Classroom", albert: "from Albert.io",
    veracross: "from Veracross", gmail: "from an email you ticked",
  };

  /* ---------------- small helpers ---------------- */

  /* Everything that reaches the page goes through here. The board comes from
     the app over loopback, but "it came from us" is not a reason to trust a
     string with a teacher's assignment title in it into innerHTML. */
  const esc = (s) => String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

  function niceDate(iso) {
    if (!iso) return "";
    const d = new Date(iso + "T12:00:00");
    if (Number.isNaN(d.getTime())) return iso;
    return `${DAY[d.getDay()]} ${MONTH[d.getMonth()]} ${d.getDate()}`;
  }

  function relDays(iso, today) {
    if (!iso || !today) return "";
    const a = new Date(iso + "T12:00:00"), b = new Date(today + "T12:00:00");
    const n = Math.round((a - b) / 86400000);
    if (n === 0) return "today";
    if (n === 1) return "tomorrow";
    if (n < 0) return `${-n} day${n === -1 ? "" : "s"} ago`;
    return `in ${n} days`;
  }

  const courseIdOf = (href) => (RE_COURSE.exec(href || "") || [])[1] || "";
  const assignmentIdOf = (href) => (RE_ASSIGNMENT.exec(href || "") || [])[1] || "";

  /* The Canvas course id of the page we are on, from the address bar. */
  function thisCourseId() { return courseIdOf(location.pathname); }

  function el(tag, cls, html) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (html != null) node.innerHTML = html;
    return node;
  }

  /* ---------------- 1. a due date Canvas has wrong ---------------- */

  /* Only ever for an item whose date CAME from the description — the one case
     where SillyBus is confident enough to put its own answer on Canvas's page
     (see campus.stated_date). A mere disagreement gets a mark, not a rewrite:
     the app keeps Canvas's date in that case and so does this. */
  function fixDate(node, item) {
    if (!item || !item.due_date) return;
    if (!(item.flags || []).includes("date_from_description")) return;
    if (node.getAttribute(MARK) === "date") return;
    node.setAttribute(MARK, "date");
    node.setAttribute("data-sb-canvas-said", node.textContent.trim().slice(0, 80));
    const why = item.date_note || "SillyBus read this date from the description";
    node.textContent = "";
    node.appendChild(el("span", "sb-date",
      `${esc(niceDate(item.due_date))}<i class="sb-mark" aria-hidden="true">SB</i>`));
    /* Canvas's own words stay reachable. Nothing is deleted anywhere in this
       file, so a wrong correction costs a confusing line and never a missed
       deadline. */
    node.title = `SillyBus: ${why}`;
  }

  /* ---------------- 2. marks on an assignment row ---------------- */

  function marksFor(item) {
    const out = [];
    const flags = item.flags || [];
    if (flags.includes("date_from_description"))
      out.push(["moved", "↳", item.date_note || "the date came from the description"]);
    else if (flags.includes("date_conflict"))
      out.push(["clash", "≠", item.date_note || "Canvas and the description disagree"]);
    if (flags.includes("looks_repeated"))
      out.push(["twice", "2×", "this looks like the same work listed twice"]);
    if (item.repeat && item.repeat.says)
      out.push(["again", "↻", item.repeat.says]);
    if (item.submitted) out.push(["in", "✓", "handed in"]);
    return out;
  }

  function decorateRow(row, item) {
    if (!item || row.getAttribute(MARK) === "row") return;
    const marks = marksFor(item);
    if (!marks.length) return;
    row.setAttribute(MARK, "row");
    const strip = el("span", "sb-marks", marks.map(([cls, glyph, hover]) =>
      `<i class="sb-m sb-${esc(cls)}" title="${esc(hover)}">${glyph}</i>`).join(""));
    const title = row.querySelector("a[href*='/assignments/']") || row;
    (title.parentNode || row).insertBefore(strip, title.nextSibling);
  }

  /* ---------------- 3. the panel on a course page ---------------- */

  function panelHtml(open, grade) {
    const rows = open.slice(0, 12).map((i) => {
      const marks = marksFor(i).map(([cls, glyph, hover]) =>
        `<i class="sb-m sb-${esc(cls)}" title="${esc(hover)}">${glyph}</i>`).join("");
      const when = i.due_date
        ? `${esc(niceDate(i.due_date))} <em>${esc(relDays(i.due_date, BOARD.today))}</em>`
        : (i.repeat && i.repeat.expected
            ? `<em title="${esc(i.repeat.expected_note || "")}">usually ${esc(
                DAY[new Date(i.repeat.expected + "T12:00:00").getDay()])}</em>`
            : "<em>no date</em>");
      const link = i.url ? `href="${esc(i.url)}"` : "";
      /* Where it came from, when it did not come from Canvas — that is the
         whole reason a panel is worth having on a Canvas page. */
      /* One word. [MEASURED] 2026-09-23 in a 294px Canvas sidebar: the chip
         reading "teacher's doc" took enough width to cut the title to "True
         Di…" and clip the date to "in 2 day". The full wording is on hover,
         where a chip's meaning belongs. */
      const from = i.source && i.source !== "canvas"
        ? `<span class="sb-from" title="${esc(SOURCE_WORDS[i.source]
            || "Canvas does not have this one")}">${esc(
            SOURCE_SHORT[i.source] || i.source.replace(/_/g, " "))}</span>`
        : "";
      return `<li><a ${link} class="sb-row" title="${esc(i.date_note || "")}">
        <span class="sb-t">${esc(i.title)}</span>${marks}${from}
        <span class="sb-w">${when}</span></a></li>`;
    }).join("");
    const more = open.length > 12
      ? `<li class="sb-more">and ${open.length - 12} more in SillyBus</li>` : "";
    const head = grade && grade.percent != null
      ? `<span class="sb-grade">${esc(grade.letter || "")} ${esc(
          Number(grade.percent).toFixed(1))}%</span>` : "";
    return `<div class="sb-head"><b>SillyBus</b>${head}</div>
      ${open.length ? `<ul class="sb-list">${rows}${more}</ul>`
        : `<p class="sb-empty">Nothing open in this class.</p>`}
      ${grade && grade.percent != null ? whatIfHtml(grade) : ""}
      <p class="sb-foot">from SillyBus AI on this Mac${
        BOARD.generated_at ? ` · read ${esc(BOARD.generated_at.slice(0, 16).replace("T", " "))}` : ""}</p>`;
  }

  /* [ASKED] "what-if on a single class". Deliberately one class and no GPA:
     a GPA needs the school's scale and whether Honors and AP are weighted,
     and a confident wrong number is worse than no number. This is arithmetic
     on marks already on screen, and it says so. */
  function whatIfHtml(grade) {
    return `<details class="sb-whatif"><summary>What if…</summary>
      <div class="sb-wi">
        <label>score <input type="number" class="sb-wi-score" min="0" max="100" value="85">%</label>
        <label>worth <input type="number" class="sb-wi-worth" min="0" max="100" value="10">% of the grade</label>
        <p class="sb-wi-out" data-now="${esc(grade.percent)}"></p>
      </div></details>`;
  }

  function wireWhatIf(host, grade) {
    const box = host.querySelector(".sb-wi");
    if (!box) return;
    const score = box.querySelector(".sb-wi-score");
    const worth = box.querySelector(".sb-wi-worth");
    const out = box.querySelector(".sb-wi-out");
    /* `Number("")` is 0, not NaN. [MEASURED] 2026-09-23: an empty "worth"
       box therefore read as 0% and the line said "91.4% → about 91.4%" —
       a confident answer to a question nobody had finished asking. An empty
       box is missing, not zero. */
    const num = (node) => (String(node.value).trim() === "" ? NaN : Number(node.value));
    const draw = () => {
      const now = Number(grade.percent);
      const s = num(score), w = num(worth) / 100;
      if (!Number.isFinite(now) || !Number.isFinite(s) || !Number.isFinite(w) || w < 0 || w > 1) {
        out.textContent = "put a number in both boxes"; return;
      }
      /* The honest form: the new mark takes `w` of the grade and what you
         have now keeps the rest. It is an estimate and the sentence says so
         — the real weighting is Canvas's assignment groups, which SillyBus
         reads but which a teacher can change after the fact. */
      const after = now * (1 - w) + s * w;
      out.textContent = `${now.toFixed(1)}% → about ${after.toFixed(1)}% `
        + `(an estimate: it assumes this is worth ${(w * 100).toFixed(0)}% of the whole grade)`;
    };
    score.addEventListener("input", draw);
    worth.addEventListener("input", draw);
    draw();
  }

  function addPanel() {
    const cid = thisCourseId();
    if (!cid || !BOARD) return;
    if (document.getElementById("sb-panel")) return;
    const right = document.getElementById("right-side")
      || document.querySelector("#right-side-wrapper")
      || document.querySelector("#content");
    if (!right) return;
    const key = (BOARD.course_keys || {})[cid] || "";
    /* Work with a Canvas link, plus work in the same class that has none —
       the teacher's-document homework, which is the whole point. */
    const byCourse = (BOARD.open_by_course || {})[cid] || [];
    const byKey = key ? ((BOARD.open_by_key || {})[key] || []) : [];
    const seen = new Set(byCourse.map((i) => i.item_id));
    const open = byCourse.concat(byKey.filter((i) => !seen.has(i.item_id)));
    const grade = (BOARD.grades || []).find(
      (g) => g.canvas_course_id === cid || (key && g.course_key === key));
    const panel = el("div", "sb-panel", panelHtml(open, grade));
    panel.id = "sb-panel";
    right.insertBefore(panel, right.firstChild);
    if (grade) wireWhatIf(panel, grade);
  }

  /* ---------------- 4. grades on the dashboard cards ---------------- */

  function addCardGrades() {
    if (!BOARD) return;
    for (const card of document.querySelectorAll(".ic-DashboardCard")) {
      if (card.getAttribute(MARK) === "card") continue;
      const link = card.querySelector("a[href*='/courses/']");
      const cid = courseIdOf(link && link.getAttribute("href"));
      if (!cid) continue;
      const grade = (BOARD.grades || []).find((g) => g.canvas_course_id === cid);
      if (!grade || grade.percent == null) continue;
      card.setAttribute(MARK, "card");
      const open = ((BOARD.open_by_course || {})[cid] || []).length;
      card.appendChild(el("div", "sb-card",
        `<span class="sb-grade">${esc(grade.letter || "")} ${esc(
          Number(grade.percent).toFixed(1))}%</span>`
        + (open ? `<span class="sb-open">${open} open</span>` : "")));
    }
  }

  /* ---------------- putting it on whatever page this is ---------------- */

  function itemByAssignment(id) {
    if (!id || !BOARD) return null;
    return (BOARD.items || []).find((i) => i.canvas_assignment_id === id) || null;
  }

  function decorateAssignmentRows() {
    for (const link of document.querySelectorAll("a[href*='/assignments/']")) {
      /* Not our own panel. [MEASURED] 2026-09-23: the panel's rows are links
         to assignments too, so this decorated them, and each one grew a
         second copy of its marks on a line of its own — then another on the
         next mutation, because the panel's `<li>` is not the node MARK was
         written to. An overlay that reacts to itself compounds. */
      if (link.closest("#sb-panel")) continue;
      const id = assignmentIdOf(link.getAttribute("href"));
      const item = itemByAssignment(id);
      if (!item) continue;
      const row = link.closest(".assignment, li, tr") || link.parentElement;
      if (row) decorateRow(row, item);
      /* Canvas prints the due date in its own node beside the link. */
      const dates = (row || document).querySelectorAll(
        ".assignment-date-due .screenreader-only ~ *, .ig-details__item, .due_date_display");
      for (const node of dates) {
        if (/due/i.test(node.textContent || "") || node.classList.contains("due_date_display")) {
          fixDate(node, item);
        }
      }
    }
  }

  function decorateAssignmentPage() {
    const id = assignmentIdOf(location.pathname);
    const item = itemByAssignment(id);
    if (!item) return;
    for (const node of document.querySelectorAll(
        ".student-assignment-overview td, .due_date_display, .assignment__due-at")) {
      if (node.getAttribute(MARK)) continue;
      if (/\d/.test(node.textContent || "")) { fixDate(node, item); break; }
    }
  }

  function paint() {
    if (!BOARD) return;
    try { addCardGrades(); } catch (e) { /* one page, not the extension */ }
    try { addPanel(); } catch (e) { /* ignore */ }
    try { decorateAssignmentRows(); } catch (e) { /* ignore */ }
    try { decorateAssignmentPage(); } catch (e) { /* ignore */ }
  }

  /* Canvas redraws its lists after its own fetches, so painting once on load
     decorates a page that is about to be thrown away. Re-applied on change,
     debounced, and idempotent through the MARK attribute. */
  let pending = null;
  function schedule() {
    if (pending) return;
    pending = setTimeout(() => { pending = null; paint(); }, 250);
  }

  chrome.runtime.sendMessage({ type: "board" }, (reply) => {
    if (chrome.runtime.lastError || !reply || !reply.ok) return;
    BOARD = reply.board;
    paint();
    new MutationObserver(schedule).observe(document.documentElement,
      { childList: true, subtree: true });
  });
})();
