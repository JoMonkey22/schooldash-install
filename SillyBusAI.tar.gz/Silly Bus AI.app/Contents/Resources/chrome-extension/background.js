import {syncMacAutomatically} from "./mac-auto.js";
import "./mac-pages.js";
// SillyBus AI service worker.
//
// The whole app — the Python that reads Canvas and the teachers' documents,
// the SQLite database, the dashboard — runs in the extension's own page
// (index.html → bridge.js → worker.js). This worker only opens that page.
// Everything stays in this Chrome profile on this computer; there is no
// SillyBus AI server.

import * as focus from "./focus-worker.js";
import { linkMacCalendar, refreshMacCalendars, linkMacSchool } from "./mac-calendars.js";

const DASHBOARD = chrome.runtime.getURL("index.html");
// The public website. [ASKED] 2026-10-07: the extension should open
// sillybusai.com "always … all of them" — right after install, from the
// pop-down's main button, and from a link in the pop-down's footer.
const WEBSITE = "https://sillybusai.com/";

// The toolbar button opens the dashboard in THIS window, reusing a tab that
// is already showing it there.
//
// [ASKED] 2026-09-20: "it also only lets you open one tab, please change
// that. all the tabs should be in perfect sink but can be in different
// windows." It used to jump to the one dashboard tab wherever it was, and a
// second tab closed itself, because two Pythons on one data store erase each
// other's work. That is now handled where it belongs: bridge.js elects one
// tab to run Python and the rest are views onto it, so any number of tabs in
// any number of windows is fine and they all show the same thing. Per window
// rather than per profile, because the point of a second window is to have
// it on the other screen.
async function openDashboard(excludeTabId, windowId) {
  const here = windowId === undefined ? chrome.windows.WINDOW_ID_CURRENT : windowId;
  let mine = [];
  try {
    mine = (await chrome.tabs.query({ url: DASHBOARD, windowId: here }))
      .filter((t) => t.id !== excludeTabId);
  } catch (e) { /* no current window (a click from a popup): fall through */ }
  if (mine.length) {
    await chrome.tabs.update(mine[0].id, { active: true });
    await chrome.windows.update(mine[0].windowId, { focused: true });
    return;
  }
  await chrome.tabs.create({ url: DASHBOARD, windowId: windowId });
}

chrome.action.onClicked.addListener((tab) => openDashboard(undefined, tab && tab.windowId));

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "open-dashboard") {
    // `closeMe` was how a duplicate tab got rid of itself. Nothing asks for
    // it any more; it is honoured only if something does.
    const mine = sender.tab ? sender.tab.id : undefined;
    openDashboard(mine, sender.tab ? sender.tab.windowId : undefined).then(async () => {
      if (message.closeMe && mine !== undefined) { try { await chrome.tabs.remove(mine); } catch (e) { /* already gone */ } }
      sendResponse({ ok: true });
    });
    return true;
  }
  // The dashboard asks not to be discarded: Chrome's Memory Saver unloads
  // background tabs, and for this tab an unload is the whole app booting
  // again. Only the dashboard's own tab is ever marked.
  // Compared without the #view — a dashboard reloaded at index.html#calendar
  // was never protected (prosecution round 3).
  if (message?.type === "keep-this-tab" && sender.tab && String(sender.tab.url || "").split("#")[0] === DASHBOARD) {
    chrome.tabs.update(sender.tab.id, { autoDiscardable: false }).then(() => sendResponse({ ok: true }), () => sendResponse({ ok: false }));
    return true;
  }
  return false;
});

// "Always running", as far as an extension can: when Chrome starts, open the
// dashboard pinned and in the background, so it has booted by the time he
// looks. Off unless Settings -> Connections switched it on.
chrome.runtime.onStartup.addListener(async () => {
  const { autostart } = await chrome.storage.local.get("autostart");
  if (!autostart) return;
  const open = await chrome.tabs.query({ url: DASHBOARD });
  if (!open.length) await chrome.tabs.create({ url: DASHBOARD, pinned: true, active: false });
});

chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  // A fresh install opens the website INSTEAD of the dashboard ([ASKED]
  // 2026-10-07). The dashboard is one click away in the pop-down, and the
  // pinned tab on startup above is untouched.
  if (reason === "install") { chrome.tabs.create({ url: WEBSITE }); return; }
  // Development only: with dev-mode.json present (never shipped), a reload
  // reopens the dashboard so the dev channel in dev.js comes back on its own.
  if (reason === "update") {
    try {
      const probe = await fetch(chrome.runtime.getURL("dev-mode.json"), { cache: "no-store" });
      if (probe.ok) await openDashboard();   // reuse the one in this window
    } catch (e) { /* no dev mode */ }
  }
});


// ---- Focus ----------------------------------------------------------------
// Self-discipline, as three modes (sillybus/focus.py). The gate and the
// reminder are drawn by focus.js on the site itself; every decision is made
// in focus-worker.js, which is the only place that can see the PIN hash and
// this session's bypasses. Two things happen here: the messages are routed,
// and the content script is registered for exactly the granted origins.
//
// Its own listener rather than another branch of the one above, so a change
// to Focus can never break opening the dashboard.
const MINE = chrome.runtime.getURL("");
const ours = (sender) => !!(sender && sender.id === chrome.runtime.id
  && typeof sender.url === "string" && sender.url.startsWith(MINE));

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (!["mac-calendar-link", "mac-school-link"].includes(message?.type)) return false;
  const page = String(sender.url || "").split(/[?#]/)[0];
  if (!ours(sender) || ![chrome.runtime.getURL("popup.html"), chrome.runtime.getURL("index.html")].includes(page)) {
    respond({ok: false, message: "Link calendars from the SillyBus toolbar."});
    return false;
  }
  syncMacAutomatically().then(() => message.type === "mac-school-link" ? linkMacSchool(message) : linkMacCalendar(message)).then(respond);
  return true;
});
chrome.alarms.create("mac-calendars", {periodInMinutes: 5});
chrome.alarms.onAlarm.addListener(alarm => {
  // Automatic pairing and calendar discovery are handled by mac-auto.js.
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const kind = message && message.type;
  if (!kind || !kind.startsWith("focus-")) return false;

  // The host is taken from the SENDER, not from the message, whenever there
  // is one: a page that could name its own host could name a host that is not
  // on the list and talk its way out of the gate.
  let host = (message && message.host) || "";
  if (sender && sender.tab && sender.url && !ours(sender)) {
    try { host = new URL(sender.url).hostname; } catch (e) { /* keep what was sent */ }
  }

  const run = {
    "focus-check": () => focus.decide({ host, reason: message.reason }),
    "focus-unlock": () => focus.unlock({ host, pin: message.pin }),
    "focus-reminded": () => focus.reminded({ host }),
    // The two below are only ever sent by our own pages. A content script on
    // youtube.com has no business setting or clearing the PIN, and the test
    // is the sender's ORIGIN rather than its URL: the dashboard carries its
    // view in the hash, so an equality check against index.html would refuse
    // the real caller.
    "focus-set-pin": () => (ours(sender) ? focus.setPin(message.pin, message.current)
      : Promise.resolve({ ok: false, message: "not allowed from a web page" })),
    "focus-clear-pin": () => (ours(sender) ? focus.clearPin(message.current)
      : Promise.resolve({ ok: false, message: "not allowed from a web page" })),
    "focus-verify-pin": () => (ours(sender) ? focus.verifyPin(message.pin)
      : Promise.resolve({ ok: false, message: "not allowed from a web page" })),
    "focus-status": () => focus.status(),
    "focus-sync": () => focus.syncScripts(),
  }[kind];
  if (!run) return false;

  run().then(sendResponse, (err) => sendResponse({ error: String(err && err.message ? err.message : err) }));
  return true;   // answering asynchronously
});

// The registration has to follow four different things, because any of them
// can make the live set wrong: the mode and the site list (written by the
// dashboard through bridge.js), and the permissions themselves, which the
// student can revoke from chrome://extensions at any time without telling us.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && "focus" in changes) focus.syncScripts();
});
try {
  chrome.permissions.onAdded.addListener(() => focus.syncScripts());
  chrome.permissions.onRemoved.addListener(() => focus.syncScripts());
} catch (e) { /* older Chrome: the storage change still re-syncs */ }
chrome.runtime.onStartup.addListener(() => focus.syncScripts());
chrome.runtime.onInstalled.addListener(() => focus.syncScripts());

// ---- AP Classroom and Albert.io, read when HE opens them -----------------
// [ASKED] 2026-10-07: "stop opening https://account.collegeboard.org/login…
// and https://www.albert.io/my-data have the option to link them with the
// new method". The dashboard used to open these sites in background tabs on
// every refresh, which landed on their sign-in pages whenever he was signed
// out. Now nothing opens them. Once a site is LINKED (the toolbar pop-down's
// Link button on that site, or Link on the Apps page), each time he opens it
// himself this reads it as the page loads — at most every ten minutes — and
// leaves the answer in storage for the dashboard to hand to Python.
const SCHOOL_SITES = [
  { key: "googleclassroom", host: "classroom.google.com", file: "google-classroom.js",
    reader: "__sillybusReadGoogleClassroom", label: "Google Classroom" },
  { key: "apclassroom", host: "apclassroom.collegeboard.org", file: "apclassroom.js",
    reader: "__sillybusReadApClassroom", label: "AP Classroom" },
  { key: "albert", host: "www.albert.io", file: "albert.js",
    reader: "__sillybusReadAlbert", label: "Albert.io" },
];
const VISIT_EVERY_MS = 10 * 60 * 1000;
const LINK_WINDOW_MS = 15 * 60 * 1000;
// One read per site at a time; a page load that lands DURING a read is
// remembered and read after it (round 6: College Board hops out to its
// sign-in host and back, and the load that mattered was the one dropped).
const visiting = new Map();
// Linked, or read successfully before linking existed — the same rule as
// bridge.js, so an older setup is read on its visits too (round 6).
const isLinked = (held, key) => (held.siteLinks || {})[key] === true
  || ((held.siteLinks || {})[key] === undefined && (held.siteState || {})[key] === "ok");

async function stillOn(tabId, spec) {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab || !tab.url) return false;
  try { return new URL(tab.url).hostname === spec.host && tab.status === "complete"; } catch (e) { return false; }
}

async function readOnVisit(tabId, spec, linking) {
  if (visiting.has(spec.key)) { visiting.get(spec.key).again = { tabId, linking }; return; }
  const job = { again: null };
  visiting.set(spec.key, job);
  try {
    // Settled on the site for two looks in a row, a second apart: a sign-in
    // hop leaves and comes back, and a script sent mid-hop is lost.
    let steady = 0;
    for (let i = 0; i < 20 && steady < 2; i++) {
      await new Promise((r) => setTimeout(r, 1000));
      steady = (await stillOn(tabId, spec)) ? steady + 1 : 0;
    }
    if (steady < 2) return;
    await chrome.scripting.executeScript({ target: { tabId }, files: [spec.file] });
    const results = await Promise.race([
      chrome.scripting.executeScript({ target: { tabId }, args: [spec.reader],
        func: (name) => (globalThis[name] ? globalThis[name]() : null) }),
      new Promise((r) => setTimeout(() => r(null), 30000)),
    ]);
    const payload = ((results || []).find((x) => x && x.result) || {}).result;
    if (!payload) return;
    const signedOut = String(payload.error || "").startsWith("not signed in");
    const held = await chrome.storage.local.get(["siteLinks", "siteRead", "siteState", "siteErrors", "pendingSiteLink"]);
    // Unlinked while this read was running: drop it (round 7 — the read
    // re-linked a site he had just unlinked).
    if (!linking && !isLinked(held, spec.key)) return;
    const siteState = { ...(held.siteState || {}), [spec.key]: signedOut ? "signed-out" : (payload.error ? "error" : "ok") };
    // A sign-in wait or a passing error is not a finished link and not a
    // read: the state is noted, and the next load tries again (round 6).
    if (signedOut || payload.error) {
      await chrome.storage.local.set({siteState, siteErrors: {...(held.siteErrors || {}), [spec.key]: String(payload.error)}});
      return;
    }
    const update = {
      siteState,
      siteErrors: {...(held.siteErrors || {}), [spec.key]: ""},
      siteLinks: { ...(held.siteLinks || {}), [spec.key]: true },
      siteRead: { ...(held.siteRead || {}), [spec.key]: { payload, at: Date.now(), linking: !!linking } },
    };
    await chrome.storage.local.set(update);
    job.read = true;
    await syncMacAutomatically();
    if (linking) await chrome.storage.local.remove("pendingSiteLink");
  } catch (e) {
    console.log(`[sillybus] ${spec.label} was not read on this visit: ${e && e.message ? e.message : e}`);
  } finally {
    visiting.delete(spec.key);
    if (job.again && !job.read) readOnVisit(job.again.tabId, spec, job.again.linking);
  }
}

chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (!tab || !tab.url || (info.status !== "complete" && !(info.url && tab.url.startsWith("https://classroom.google.com/")))) return;
  let host = "";
  try { host = new URL(tab.url).hostname; } catch (e) { return; }
  const spec = SCHOOL_SITES.find((s) => s.host === host);
  if (!spec) return;
  const held = await chrome.storage.local.get(["siteLinks", "siteState", "siteRead", "pendingSiteLink"]);
  const pending = held.pendingSiteLink;
  const linking = !!(pending && pending.key === spec.key && Date.now() - (pending.at || 0) < LINK_WINDOW_MS);
  if (!linking && !isLinked(held, spec.key)) return;
  const last = ((held.siteRead || {})[spec.key] || {}).at || 0;
  if (!linking && spec.key !== "googleclassroom" && Date.now() - last < VISIT_EVERY_MS) return;
  readOnVisit(tabId, spec, linking);
});
