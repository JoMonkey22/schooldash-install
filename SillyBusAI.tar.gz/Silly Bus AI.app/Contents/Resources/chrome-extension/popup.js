// The toolbar pop-down: get the Mac app, open SillyBus, or link the page you
// are on.
//
// [ASKED] 2026-10-07: open sillybusai.com "always … all of them". The main
// button is "Get the Mac app" (the website's download page); "Open SillyBus
// in Chrome" is the smaller button under it and does what "Open SillyBus"
// did; the footer links to the website.
//
// [ASKED] 2026-10-06: "a way to link to teamsnap that is better right now it
// is hard to do make it so you open the page you want to link to silly bus
// and you click the silliy bus Icon in the chrome pop down". Linking used to
// mean finding TeamSnap's Subscribe/Export page, copying a webcal:// address
// and pasting it into Settings. Now: be on any TeamSnap page, click the icon,
// press "Link this page", press "Connect it".
//
// It ASKS first what it is meant to find — [ASKED] 2026-10-06: "make it ask
// what type of info it is supost to find". Three answers, each one something
// the app already knows how to keep: a calendar (games, practices → a saved
// connection), homework for a class (a teacher's Google Doc or Canvas page →
// that class's homework source, read on every refresh), or a link for a
// class (a textbook, a study site → one of that class's materials). The
// likely answer is ticked for him (TeamSnap → calendar, a Google Doc →
// homework); he can change it.
//
// Three permissions make that work, and none of them is new to the user:
//   activeTab  — this tab only, only because he clicked the icon. No warning
//                at install, nothing granted for any other tab.
//   scripting  — already held (Focus); runs findCalendars() in that one tab.
//   the feed's own site, e.g. ical-cdn.teamsnap.com — ASKED for when he
//                presses Connect, from the optional list the manifest already
//                carries for Focus, because the feed has no CORS headers and
//                the extension's Python has to be allowed to read it.
// The address itself is a password in disguise (anyone holding it reads his
// schedule), so it goes from this pop-down into chrome.storage.local and
// straight to the dashboard, which saves it exactly as a pasted one is saved.
// It is never shown here, put in a URL, or logged.

const $ = (id) => document.getElementById(id);
let FOUND = { feeds: [], name: "", page: "" };

const SITE = "https://sillybusai.com/";
const DOWNLOAD_PAGE = "https://sillybusai.com/download.html";

// A new tab beside this one, then the pop-down closes.
function openWebsite(url) {
  chrome.tabs.create({ url }, () => { void chrome.runtime.lastError; window.close(); });
}

$("get-mac").addEventListener("click", () => openWebsite(DOWNLOAD_PAGE));

$("site").addEventListener("click", (e) => { e.preventDefault(); openWebsite(SITE); });

$("open").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "open-dashboard" }, () => { void chrome.runtime.lastError; window.close(); });
});

function say(text, bad) {
  const el = $("say");
  el.hidden = !text;
  el.textContent = text || "";
  el.classList.toggle("bad", !!bad);
}

async function currentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

// Runs IN the page (chrome.scripting serialises it), so it must not use
// anything from this file. Reads, never clicks or changes anything.
async function findCalendars() {
  const feeds = [];
  const seen = new Set();
  const add = (raw, label) => {
    let url = String(raw || "").trim();
    if (!url) return;
    url = url.replace(/^webcal:\/\//i, "https://");
    if (/^http:\/\/ical-cdn\.teamsnap\.com\//i.test(url)) url = url.replace(/^http:/i, "https:");
    if (!/^https:\/\//i.test(url)) return;
    const key = url;
    if (seen.has(key)) return;
    seen.add(key);
    feeds.push({ url, label });
  };
  const looksLikeFeed = (u) => /^webcal:/i.test(u) || /\.ics(\?|#|$)/i.test(u) || /\/ical\//i.test(u);
  const teamsnapLabel = (u) => (/\/filter\/games\//i.test(u) ? "Games only"
    : /\/filter\/attending\//i.test(u) ? "Only what you're going to" : "All games and events");
  const scan = (root, teamsnap) => {
    for (const a of root.querySelectorAll("a[href]")) {
      const h = a.getAttribute("href") || "";
      if (looksLikeFeed(h)) add(h, teamsnap ? teamsnapLabel(h) : (a.textContent || "").trim().slice(0, 60) || "Calendar");
    }
    for (const el of root.querySelectorAll("input[value], textarea, [data-clipboard-text]")) {
      const v = el.getAttribute("data-clipboard-text") || el.value || el.getAttribute("value") || "";
      if (!looksLikeFeed(v)) continue;
      // Google Calendar's settings page: the SECRET address (…/private-…/)
      // is his calendar; the public one only works if he shared it publicly.
      const label = teamsnap ? teamsnapLabel(v)
        : /\/private-[0-9a-f]+\//i.test(v) ? "Your Google Calendar (private link)"
        : /calendar\.google\.com\/calendar\/ical\/.*\/public\//i.test(v) ? "Public link — works only if the calendar is public"
        : "Calendar";
      add(v, label);
    }
    // A Google Calendar embedded in a page: its public feed, from the embed.
    for (const f of root.querySelectorAll("iframe[src*='calendar.google.com/calendar/embed']")) {
      try {
        const src = new URL(f.getAttribute("src"), location.href);
        for (const id of src.searchParams.getAll("src")) {
          add(`https://calendar.google.com/calendar/ical/${encodeURIComponent(id)}/public/basic.ics`, "Google Calendar");
        }
      } catch (e) { /* not a URL */ }
    }
  };
  const teamsnap = /(^|\.)teamsnap\.com$/i.test(location.hostname);
  scan(document, teamsnap);
  // TeamSnap keeps the links on its own export page, reachable from any of
  // its pages with the session this tab already has. [MEASURED] 2026-10-06:
  // go.teamsnap.com/team/export_schedule holds three webcal://ical-cdn…
  // links — all, /filter/attending/, /filter/games/.
  let signedOut = false;
  // Also when the page itself showed only a filtered link (Games only):
  // the export page is where "All games and events" is.
  if (teamsnap && !feeds.some((f) => f.label === "All games and events")) {
    try {
      const res = await fetch("/team/export_schedule", { credentials: "include" });
      if (/\/login\b|sign_?in/i.test(res.url)) signedOut = true;
      else if (res.ok) scan(new DOMParser().parseFromString(await res.text(), "text/html"), true);
    } catch (e) { /* the page's network is the page's business */ }
  }
  // On Google Calendar itself: the calendar's own Export, read with the
  // Google sign-in this Chrome already has — no secret address to dig out
  // of a settings page, so it works for everyone ([ASKED] 2026-10-06).
  if (/(^|\.)calendar\.google\.com$/i.test(location.hostname)
      && !feeds.some((f) => /private link/.test(f.label))) {
    // The account this tab is showing (/calendar/u/1/… is the second Google
    // account in Chrome), not always the first. Round 7, 2026-10-07.
    const account = Number((/\/calendar\/u\/(\d+)\//.exec(location.pathname) || [])[1] || 0);
    feeds.unshift({ url: account ? `https://calendar.google.com/calendar/u/${account}/exporticalzip`
                                 : "https://calendar.google.com/calendar/exporticalzip",
                    label: account ? `Your Google Calendar (account ${account + 1})` : "Your Google Calendar" });
  }
  const best = (f) => (f.label === "All games and events" || /private link|Your Google Calendar/.test(f.label) ? -1 : 0);
  feeds.sort((a, b) => best(a) - best(b));
  return {
    feeds, signedOut, teamsnap,
    google: /(^|\.)calendar\.google\.com$/i.test(location.hostname),
    title: (document.title || location.hostname).replace(/^TeamSnap\s*::\s*/i, "").slice(0, 60),
  };
}

let TAB = null;
let CLASSES = [];

function googleSettingsUrl(url) {
  const account = /\/calendar\/u\/(\d+)\//.exec(url || "")?.[1] || "0";
  return `https://calendar.google.com/calendar/u/${account}/r/settings`;
}

$("google-calendar").addEventListener("click", async () => {
  TAB = await currentTab();
  if (!/^https:\/\/calendar\.google\.com\//.test(TAB?.url || "")) {
    openWebsite("https://calendar.google.com/calendar/u/0/r/month");
    return;
  }
  await findCalendarHere();
});

// AP Classroom and Albert.io are linked, not scraped from a background tab.
// [ASKED] 2026-10-07: "stop opening … have the option to link them with the
// new method". On one of those sites the button says so, and pressing it
// marks the site linked and reloads the page, so background.js reads it as
// it loads — from then on, every time he opens it.
const SCHOOL_SITES = [
  { key: "googleclassroom", host: "classroom.google.com", label: "Google Classroom" },
  { key: "apclassroom", host: "apclassroom.collegeboard.org", label: "AP Classroom" },
  { key: "albert", host: "www.albert.io", label: "Albert.io" },
];
const siteFor = (url) => {
  let host = "";
  try { host = new URL(url).hostname; } catch (e) { return null; }
  if (host.endsWith(".instructure.com") && !host.endsWith(".login.instructure.com")) return {key: "canvas", label: "Canvas", native: true};
  if (host === "portals.veracross.com") return {key: "veracross", label: "Veracross", native: true};
  return SCHOOL_SITES.find((s) => s.host === host) || null;
};
async function linkSchoolSite(tab, site) {
  if (site.native) {
    const result = await chrome.runtime.sendMessage({type: "mac-school-link", url: tab.url});
    say(result?.message || "Could not connect to the Mac app.", !result?.ok);
    return;
  }
  const held = await chrome.storage.local.get("siteLinks");
  await chrome.storage.local.set({
    siteLinks: { ...(held.siteLinks || {}), [site.key]: true },
    pendingSiteLink: { key: site.key, at: Date.now() },
  });
  await chrome.tabs.reload(tab.id);
  say(`Linking ${site.label} — it is read as the page loads, and every time you open it after this. `
      + "If it asks you to sign in, sign in and it links itself.");
}

function guessKind(url) {
  if (/(^|\.)teamsnap\.com\//i.test(url) || /calendar\.google\.com\//i.test(url)) return "calendar";
  if (/docs\.google\.com\/document\//i.test(url) || /\.instructure\.com\/courses\/\d+/i.test(url)) return "homework";
  return "";
}
function chosenKind() {
  const on = document.querySelector('input[name="kind"]:checked');
  return on ? on.value : "";
}
function showClassRow() {
  const kind = chosenKind();
  $("class-row").hidden = !(kind === "homework" || kind === "link" || kind === "todo");
  $("details").hidden = !(kind === "event" || kind === "todo");
  $("time-row").hidden = kind !== "event";
  $("go").textContent = { calendar: "Find the calendar", homework: "Use it for homework",
    link: "Save the link", event: "Put it on my calendar", todo: "Add the to-do" }[kind] || "Next";
  $("go").disabled = !kind;
  // A to-do's class is optional ("no class" first); a homework source or a
  // class link needs one.
  const opts = CLASSES.map((c) => new Option(c.name, c.key));
  if (kind === "todo") opts.unshift(new Option("no class (personal)", ""));
  else if (!CLASSES.length) opts.push(new Option("open SillyBus once so it knows your classes", ""));
  $("class").replaceChildren(...opts);
}

$("start").addEventListener("click", async () => {
  say("");
  $("found").hidden = true;
  $("chrome-calendar").hidden = true;
  TAB = await currentTab();
  if (!TAB || !/^https?:/i.test(TAB.url || "")) {
    say("Open the page you want to link first — TeamSnap, a teacher's doc, a class page.", true);
    return;
  }
  const site = siteFor(TAB.url);
  if (site) { await linkSchoolSite(TAB, site); return; }
  // His classes, left here by the dashboard each time it loads (bridge.js).
  try { CLASSES = (await chrome.storage.local.get("sbClasses")).sbClasses || []; } catch (e) { CLASSES = []; }
  const guess = guessKind(TAB.url);
  for (const r of document.querySelectorAll('input[name="kind"]')) {
    r.checked = r.value === guess;
    r.onchange = showClassRow;
  }
  $("what").value = (TAB.title || "").replace(/\s*[|\-–—:]+\s*[^|\-–—:]*$/, "").slice(0, 140) || (TAB.title || "");
  $("day").value = "";
  $("time").value = "";
  showClassRow();
  $("ask").hidden = false;
  $("start").hidden = true;
});

$("go").addEventListener("click", async () => {
  const kind = chosenKind();
  if (kind === "calendar") return findCalendarHere();
  if (kind === "event" || kind === "todo") {
    const what = $("what").value.trim();
    const day = $("day").value;
    if (!what) { say("Say what it is first.", true); return; }
    if (kind === "event" && !day) { say("Pick the day it happens.", true); return; }
    const course = kind === "todo" ? $("class").value : "";
    await chrome.storage.local.set({ pendingLink: { kind, url: TAB.url, title: what, day,
      time: kind === "event" ? ($("time").value || "") : "", course,
      className: (CLASSES.find((c) => c.key === course) || {}).name || "", at: Date.now() } });
    chrome.runtime.sendMessage({ type: "open-dashboard" }, () => { void chrome.runtime.lastError; window.close(); });
    return;
  }
  const course = $("class").value;
  if (!course) { say("Open SillyBus once first, so it knows your classes — then try again.", true); return; }
  const url = TAB.url;
  /* Only a homework page: guessKind() says "calendar" for TeamSnap, which is
     truthy — a TeamSnap address was saved as a class's Canvas page
     (prosecution 2026-10-06). */
  if (kind === "homework" && guessKind(url) !== "homework") {
    say("SillyBus can read homework from a teacher's Google Doc or a Canvas class page. "
      + "For any other page, choose \u201cSave it as a link\u201d.", true);
    return;
  }
  const className = (CLASSES.find((c) => c.key === course) || {}).name || "that class";
  await chrome.storage.local.set({ pendingLink: { kind, url, course, className,
    title: (TAB.title || "").slice(0, 120), at: Date.now() } });
  chrome.runtime.sendMessage({ type: "open-dashboard" }, () => { void chrome.runtime.lastError; window.close(); });
});

async function findCalendarHere() {
  const button = $("go");
  button.disabled = true;
  $("found").hidden = true;
  $("chrome-calendar").hidden = true;
  say("Looking for a calendar on this page…");
  try {
    const tab = TAB || await currentTab();
    let result;
    try {
      [{ result }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: findCalendars });
    } catch (e) {
      say("Chrome does not let extensions read this page. Open the schedule in a normal tab and try again.", true);
      return;
    }
    if (!result || !result.feeds.length) {
      if (result && result.signedOut) say("Sign in to TeamSnap in this tab first, then press Link this page again.", true);
      else if (result && result.teamsnap) say("TeamSnap did not show a schedule link. Open My Full Schedule and try again.", true);
      else if (result && result.google) {
        // [MEASURED] 2026-10-06 on his school account: the calendar's own
        // settings page holds the address; the secret one appears only after
        // the eye next to it is clicked, and a school can switch it off.
        say("In Google Calendar: Settings → your calendar → Integrate calendar → click the eye next to "
          + "\u201cSecret address in iCal format\u201d, then press Link this page again.", true);
        $("gcal-settings").hidden = false;
      }
      else say("No calendar on this page. Open the page with the schedule (TeamSnap, Google Calendar, a team site) and try again.", true);
      return;
    }
    const host = new URL(tab.url).hostname;
    FOUND = { feeds: result.feeds, page: tab.url,
              name: result.teamsnap ? "TeamSnap" : (result.google ? "Google Calendar" : result.title || host) };
    $("gcal-settings").hidden = !result.google;
    $("google-help").hidden = !result.google;
    const pick = $("pick");
    pick.replaceChildren(...result.feeds.map((f, i) => new Option(f.label, String(i))));
    $("pick-row").hidden = result.feeds.length < 2;
    $("found-text").textContent = result.teamsnap
      ? "Found your TeamSnap schedule. Your games and practices will show on the SillyBus calendar."
      : result.google
      ? "Connect the Google account open in this tab. SillyBus reads its events using your Chrome sign-in. No AI account or API key is needed."
      : `Found a calendar on ${host}. Its events will show on the SillyBus calendar.`;
    /* Reuse permission for a single non-Google feed. Google and multiple
       choices wait for Connect so the student can confirm the account/feed. */
    try {
      const first = result.feeds[0];
      const origin = `${new URL(first.url).origin}/*`;
      if (!result.google && result.feeds.length === 1 && await chrome.permissions.contains({ origins: [origin] })) {
        if (await saveCalendarLink(first)) return;
      }
    } catch (e) { /* show the normal confirmation step */ }
    $("ask").hidden = true;
    $("found").hidden = false;
    say("");
  } finally {
    button.disabled = false;
  }
}

async function saveCalendarLink(feed) {
  let macLinked = false;
  // A fresh Chrome-only install has no Mac token. Its own dashboard already
  // reads Google exports; do not require a separate app before opening it.
  const {macCalendarToken} = await chrome.storage.local.get("macCalendarToken");
  if (macCalendarToken) {
    try {
      const result = await chrome.runtime.sendMessage({ type: "mac-calendar-link",
        url: feed.url, name: FOUND.name });
      macLinked = !!(result && result.ok);
      if (!macLinked) {
        say(result?.message || "The Mac app could not sync this calendar. Try Connect again.", true);
        $("chrome-calendar").hidden = false;
        $("gcal-settings").hidden = !/^https:\/\/calendar\.google\.com\//.test(FOUND.page || "");
        return false;
      }
    } catch (e) {
      say("The Mac app could not sync this calendar. Open it, then try Connect again.", true);
      $("chrome-calendar").hidden = false;
      return false;
    }
  }
  return queueCalendarLink(feed, macLinked);
}

async function queueCalendarLink(feed, macLinked = false) {
  await chrome.storage.local.set({ pendingLink: { kind: "calendar",
    url: feed.url, name: FOUND.name, label: feed.label, macLinked, at: Date.now() } });
  chrome.runtime.sendMessage({ type: "open-dashboard" }, () => { void chrome.runtime.lastError; window.close(); });
  return true;
}

$("chrome-calendar").addEventListener("click", async () => {
  const feed = FOUND.feeds[Number($("pick").value || 0)] || FOUND.feeds[0];
  if (feed) await queueCalendarLink(feed);
});

$("connect").addEventListener("click", async () => {
  const feed = FOUND.feeds[Number($("pick").value || 0)] || FOUND.feeds[0];
  if (!feed) return;
  // First, while the click still counts: Chrome only asks for a permission
  // during a user gesture, and an await before this would spend it.
  let allowed = false;
  try {
    allowed = await chrome.permissions.request({ origins: [`${new URL(feed.url).origin}/*`] });
  } catch (e) { allowed = false; }
  if (!allowed) {
    say("SillyBus needs Chrome's OK to read that calendar. Press Connect it again and choose Allow.", true);
    return;
  }
  await saveCalendarLink(feed);
});

// Say what the button will do on THIS page before it is pressed.
currentTab().then((tab) => {
  let host = "";
  try { host = new URL(tab.url).hostname; } catch (e) { /* chrome:// */ }
  if (!host) $("start").title = "Open TeamSnap, a teacher's doc or a class page first.";
  const site = siteFor(tab.url);
  if (site) $("start").textContent = `🔗 Link ${site.label}`;
  if (host === "calendar.google.com") {
    $("google-calendar").textContent = "Connect this Google Calendar account";
    $("gcal-settings").hidden = false;
    $("google-help").hidden = false;
  }
}).catch(() => {});

$("gcal-settings").addEventListener("click", async () => {
  const tab = TAB || await currentTab();
  if (tab) await chrome.tabs.update(tab.id, { url: googleSettingsUrl(tab.url) });
  window.close();
});

(async () => {
  const {macCalendarToken} = await chrome.storage.local.get("macCalendarToken");
  $("extension-status").textContent = `SillyBus extension ${chrome.runtime.getManifest().version} · ${macCalendarToken ? "Chrome + Mac app" : "Ready in Chrome"}`;
  const tab = await currentTab();
  const site = siteFor(tab?.url);
  const {siteErrors = {}} = await chrome.storage.local.get("siteErrors");
  if (site && siteErrors[site.key]) say(siteErrors[site.key], true);
})().catch(() => {});

$("send-mac-pages").addEventListener("click", async () => {
  const button = $("send-mac-pages"); button.disabled = true;
  say("Sending your school pages to the Mac app…");
  try {
    const out = await chrome.runtime.sendMessage({type: "mac-pages-send"});
    say(out?.sent ? `Sent ${out.sent} school pages to the Mac app.`
      : out?.problems?.join("; ") || out?.message || "No school pages sent. Connect this extension to the Mac app first.", !out?.sent);
  } catch (e) { say("Open the Mac app and connect this extension, then try again.", true); }
  finally { button.disabled = false; }
});
