// The extension's own settings: the two values the Python side cannot find
// out for itself. Both are secrets. Both live in chrome.storage.local on this
// computer only, are shown redacted, and are handed to the Python worker by
// bridge.js (pushSettings) — never logged, never sent anywhere but where they
// are for (the feed to Veracross, the key to api.anthropic.com).

const $ = (sel) => document.querySelector(sel);

function redactFeedUrl(url) {
  try {
    const u = new URL(url);
    return `${u.host}/…${u.pathname.slice(-6)}`;
  } catch (e) { return "(not a valid URL)"; }
}

function redactKey(key) {
  const k = String(key || "");
  if (k.length < 12) return "•••• (saved)";
  return `${k.slice(0, 7)}…${k.slice(-4)}`;
}

async function showKey() {
  const { anthropicApiKey = "" } = await chrome.storage.local.get("anthropicApiKey");
  const el = $("#key-saved");
  el.textContent = anthropicApiKey
    ? `Saved: ${redactKey(anthropicApiKey)} — SillyBus AI's AI is on.`
    : "No key saved — SillyBus AI's AI is off. The board, schedule and grades work without it.";
  el.className = anthropicApiKey ? "muted saved" : "muted";
  $("#key-clear").hidden = !anthropicApiKey;
}

async function showFeed() {
  const { classFeedUrl = "" } = await chrome.storage.local.get("classFeedUrl");
  const el = $("#feed-saved");
  el.textContent = classFeedUrl ? `Saved: ${redactFeedUrl(classFeedUrl)}` : "No feed saved.";
  el.className = classFeedUrl ? "muted saved" : "muted";
  $("#feed-clear").hidden = !classFeedUrl;
}

$("#key-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const key = $("#key").value.trim();
  const el = $("#key-saved");
  if (!key) return;
  if (!/^sk-ant-/.test(key)) {
    el.textContent = "That does not look like an Anthropic API key (they start with sk-ant-). Not saved.";
    el.className = "muted problem";
    return;
  }
  await chrome.storage.local.set({ anthropicApiKey: key });
  $("#key").value = "";
  await showKey();
});
$("#key-clear").addEventListener("click", async () => {
  await chrome.storage.local.remove("anthropicApiKey");
  $("#key-test-result").textContent = "";
  await showKey();
});

// Test key: one GET to the Models endpoint with the saved key — the same
// headers the Python side sends (sillybus/ai/anthropic_api.py headers()),
// including anthropic-dangerous-direct-browser-access, which the API requires
// of any request carrying a browser Origin. Nothing is generated and nothing
// is billed; the answer is either the number of models the key can see or the
// API's own error message, verbatim. The key itself is never shown.
$("#key-test").addEventListener("click", async () => {
  const el = $("#key-test-result");
  const { anthropicApiKey = "" } = await chrome.storage.local.get("anthropicApiKey");
  if (!anthropicApiKey) { el.textContent = "Save a key first."; el.className = "muted problem"; return; }
  el.className = "muted"; el.textContent = "Asking api.anthropic.com…";
  try {
    const res = await fetch("https://api.anthropic.com/v1/models?limit=100", {
      headers: { "x-api-key": anthropicApiKey, "anthropic-version": "2023-06-01",
                 "anthropic-dangerous-direct-browser-access": "true" },
    });
    let body = null;
    try { body = await res.json(); } catch (e) { body = null; }
    if (res.ok) {
      const ids = (body && body.data ? body.data : []).map((m) => m.id);
      const haiku = ids.find((id) => id.startsWith("claude-haiku")) || "";
      el.textContent = `Key works: ${ids.length} model(s) visible` + (haiku ? `, including ${haiku} (the default for chat)` : "") + ".";
      el.className = "muted saved";
    } else {
      const err = body && body.error ? `${body.error.type}: ${body.error.message}` : `HTTP ${res.status}`;
      el.textContent = `Key refused — HTTP ${res.status}. ${err}`;
      el.className = "muted problem";
    }
  } catch (err) {
    el.textContent = `Could not reach api.anthropic.com: ${err && err.message ? err.message : err}`;
    el.className = "muted problem";
  }
});

$("#feed-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const url = $("#feed-url").value.trim();
  const el = $("#feed-saved");
  if (!url) return;
  if (!/^https:\/\/[^/]*veracross\.com\//.test(url)) {
    el.textContent = "That is not a Veracross link. Not saved.";
    el.className = "muted problem";
    return;
  }
  await chrome.storage.local.set({ classFeedUrl: url });
  $("#feed-url").value = "";
  await showFeed();
});
$("#feed-clear").addEventListener("click", async () => {
  await chrome.storage.local.remove("classFeedUrl");
  await showFeed();
});

$("#open-dashboard").addEventListener("click", () => chrome.runtime.sendMessage({ type: "open-dashboard" }));

// Move in from the Mac app: hand the chosen zip to a worker of our own, which
// boots the same Python the dashboard runs, unpacks the zip into /data and
// flushes it to IndexedDB. Runs here rather than in the dashboard so the
// dashboard's own worker is not writing the same mount at the same time.
$("#move-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const el = $("#move-status");
  const file = $("#move-file").files[0];
  if (!file) { el.textContent = "Choose the zip first."; el.className = "muted problem"; return; }
  if (!/\.zip$/i.test(file.name)) { el.textContent = "That is not a zip file."; el.className = "muted problem"; return; }
  el.className = "muted";
  el.textContent = "Starting Python…";
  $("#move-form button").disabled = true;
  const zip = await file.arrayBuffer();
  const worker = new Worker(new URL("worker.js", location.href), { type: "module" });
  const finish = () => { worker.terminate(); $("#move-form button").disabled = false; };
  worker.onmessage = ({ data: msg }) => {
    if (msg.type === "status") {
      el.textContent = msg.message;
    } else if (msg.type === "empty") {
      worker.postMessage({ type: "restore", zip: null });   // the chosen zip is what is wanted, not the backup
    } else if (msg.type === "ready") {
      worker.postMessage({ type: "import", zip }, [zip]);
    } else if (msg.type === "imported") {
      finish();
      if (msg.error) { el.textContent = `Not moved in: ${msg.error}`; el.className = "muted problem"; return; }
      const left = msg.skipped && msg.skipped.length ? ` Left out: ${msg.skipped.join(", ")}.` : "";
      el.textContent = `Moved in ${msg.written} file(s): ${msg.profiles} class profile(s), ` +
        `${msg.items} saved item(s) on the board.${left} Open SillyBus AI to see it.`;
      el.className = "muted saved";
    } else if (msg.type === "fatal") {
      finish();
      el.textContent = msg.code === "busy"
        ? "The dashboard tab is still open — close it first, then Move in. (Two copies writing the same store is how files go missing.)"
        : `Python could not start: ${msg.message}`;
      el.className = "muted problem";
    }
  };
});

// ---- the automatic backup -------------------------------------------
async function showBackup() {
  const el = $("#backup-status");
  const { backup, backup_prev } = await chrome.storage.local.get(["backup", "backup_prev"]);
  if (!backup || !backup.data) {
    el.textContent = "No automatic backup yet — one is made about twenty seconds after the dashboard opens.";
    $("#backup-download").disabled = true; $("#backup-restore").disabled = true;
    return;
  }
  const info = backup.info || {};
  el.textContent = `Last backup ${new Date(backup.at).toLocaleString()}: ${info.items ?? "?"} items on the board, ` +
    `${info.profiles ?? "?"} class profile(s), ${Math.round(backup.size / 1024)} KB` +
    (backup_prev ? `; the one before is from ${new Date(backup_prev.at).toLocaleString()}.` : ".");
}
const unb64 = (s) => { const bin = atob(s); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u.buffer; };
$("#backup-download").addEventListener("click", async () => {
  const { backup } = await chrome.storage.local.get("backup");
  if (!backup || !backup.data) return;
  const blob = new Blob([unb64(backup.data)], { type: "application/zip" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `SillyBusAI-backup-${new Date(backup.at).toISOString().slice(0, 16).replace(/[:T]/g, "-")}.zip`;
  document.body.appendChild(a); a.click(); a.remove();
  $("#backup-note").textContent = "Saved to your Downloads folder. It is the same kind of zip the Move in box accepts.";
});
// Restoring runs the same worker the move-in does, with the stored zip.
// Close the dashboard tab first, for the same reason.
$("#backup-restore").addEventListener("click", async () => {
  const el = $("#backup-note");
  const { backup } = await chrome.storage.local.get("backup");
  if (!backup || !backup.data) return;
  if (!confirm("Put the last backup back over what the app has now? Close the dashboard tab first.")) return;
  el.textContent = "Starting Python…";
  const zip = unb64(backup.data);
  const worker = new Worker(new URL("worker.js", location.href), { type: "module" });
  worker.onmessage = ({ data: msg }) => {
    if (msg.type === "status") el.textContent = msg.message;
    else if (msg.type === "empty") worker.postMessage({ type: "restore", zip: null });
    else if (msg.type === "ready") worker.postMessage({ type: "import", zip }, [zip]);
    else if (msg.type === "imported") {
      worker.terminate();
      el.textContent = msg.error ? `Not restored: ${msg.error}`
        : `Restored ${msg.written} file(s): ${msg.profiles} class profile(s), ${msg.items} item(s). Open SillyBus AI to see it.`;
    } else if (msg.type === "fatal") {
      worker.terminate();
      el.textContent = msg.code === "busy"
        ? "The dashboard tab is still open — close it first, then restore."
        : `Python could not start: ${msg.message}`;
    }
  };
});

showKey();
showFeed();
showBackup();
