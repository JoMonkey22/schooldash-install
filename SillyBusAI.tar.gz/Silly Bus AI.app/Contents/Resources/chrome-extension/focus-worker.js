// Focus, the deciding half. Runs in the service worker.
//
// Everything that must not live on the page lives here: the PIN hash, the
// session's bypasses, and the decision itself. `focus.js` on youtube.com only
// draws what this file tells it to, which means YouTube's own scripts have
// nothing to read and nothing to fake — a `focus-check` reply is the only
// thing that puts a gate up, and it comes from the extension.
//
// It also owns registration. Focus is off by default, and off has to mean
// ABSENT: no host permission held, no content script registered, nothing
// injected. So the site list is turned into `chrome.scripting` registrations
// here, re-synced whenever the list, the mode or the granted permissions
// change, and torn down the moment the mode goes back to off.
//
// Where the pieces live:
//   storage.local.focus      the snapshot Python writes (bridge.js mirrors
//                            /api/focus after boot and after every refresh):
//                            mode, site list, settings, and what is due
//   storage.local.focusPin   {salt, hash, iters} — never the PIN itself
//   storage.session.focusOpen   site label -> when its bypass expires
//   storage.session.focusSaid   site label -> when it last reminded

const SCRIPT_ID = "sillybus-focus";
const DEFAULT_BYPASS = 15;
const HOUR = 60 * 60 * 1000;

// PBKDF2-SHA256. An honest note, because the number invites more confidence
// than it earns: a four-digit PIN is ten thousand guesses and no iteration
// count makes that strong. The hash is here so the PIN is not sitting in
// plain text in a storage inspector — the security of Focus is that getting
// past it takes a deliberate act, not that the act is hard.
const ITERATIONS = 150000;

const enc = new TextEncoder();
const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");

async function derive(pin, saltHex, iters) {
  const salt = new Uint8Array(saltHex.match(/../g).map((h) => parseInt(h, 16)));
  const key = await crypto.subtle.importKey("raw", enc.encode(pin), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt, iterations: iters, hash: "SHA-256" }, key, 256);
  return hex(bits);
}

// Changing or removing a PIN that is set takes the current one, and so does
// anything that weakens Block (prosecution #7, 2026-10-07): without it, the
// way past the gate was to open Settings and set a new PIN — no effort at all.
async function needsCurrent(current) {
  if (!(await hasPin())) return null;
  if (await checkPin(current)) return null;
  return { ok: false, needsPin: true, message: "Type your current PIN first." };
}

export async function verifyPin(pin) {
  if (!(await hasPin())) return { ok: true };
  return (await checkPin(pin)) ? { ok: true }
    : { ok: false, needsPin: true, message: "That is not the PIN." };
}

export async function setPin(pin, current) {
  if (!/^[0-9]{4,8}$/.test(String(pin || ""))) {
    return { ok: false, message: "A PIN is 4 to 8 digits." };
  }
  const refused = await needsCurrent(current);
  if (refused) return refused;
  const saltHex = hex(crypto.getRandomValues(new Uint8Array(16)));
  const hash = await derive(String(pin), saltHex, ITERATIONS);
  await chrome.storage.local.set({ focusPin: { salt: saltHex, hash, iters: ITERATIONS } });
  return { ok: true };
}

export async function clearPin(current) {
  const refused = await needsCurrent(current);
  if (refused) return refused;
  await chrome.storage.local.remove("focusPin");
  return { ok: true };
}

export async function hasPin() {
  const { focusPin } = await chrome.storage.local.get("focusPin");
  return !!(focusPin && focusPin.hash);
}

async function checkPin(pin) {
  const { focusPin } = await chrome.storage.local.get("focusPin");
  if (!focusPin || !focusPin.hash) return false;
  const hash = await derive(String(pin), focusPin.salt, focusPin.iters || ITERATIONS);
  // Constant time is beside the point against a local ten-thousand-guess
  // space, but comparing lengths first and never short-circuiting on the
  // first differing character costs nothing.
  if (hash.length !== focusPin.hash.length) return false;
  let same = 0;
  for (let i = 0; i < hash.length; i += 1) same |= hash.charCodeAt(i) ^ focusPin.hash.charCodeAt(i);
  return same === 0;
}

// ---- the site list -------------------------------------------------------
// Suffix matching, not endsWith: "notyoutube.com".endsWith("youtube.com") is
// true and is a different site. Mirrors focus._matches in Python.
function under(host, suffix) {
  host = String(host || "").toLowerCase().replace(/\.$/, "").replace(/^www\./, "");
  return host === suffix || host.endsWith("." + suffix);
}

function matchSite(host, sites) {
  for (const site of sites || []) {
    for (const suffix of site.hosts || []) {
      if (under(host, suffix)) return site;
    }
  }
  return null;
}

export function originsFor(focus) {
  const out = [];
  for (const site of (focus && focus.sites) || []) {
    for (const host of site.hosts || []) {
      const pattern = `*://*.${host}/*`;
      if (!out.includes(pattern)) out.push(pattern);
    }
  }
  return out;
}

// ---- registration --------------------------------------------------------
// Only patterns Chrome has actually granted may be registered; registering an
// ungranted one throws and would take the whole list down with it, so each is
// checked on its own. A pattern the student put on the list but never granted
// is simply not registered — Settings shows it as waiting for permission
// rather than pretending it is live.
// One at a time. [MEASURED] 2026-10-07 (prosecution round 3, 5 of 5 runs):
// turning Focus on wrote storage (one sync from onChanged) AND sent
// focus-sync (a second) — both saw nothing registered, both registered, the
// second hit "Duplicate script ID" and its catch UNREGISTERED the first. Focus
// showed as on and gated nothing.
let syncing = Promise.resolve();
let verifyTimer = null;
export function syncScripts(verifying = false) {
  const next = syncing.then(syncScriptsNow, syncScriptsNow);
  syncing = next.catch(() => {});
  // …and look again shortly after. Chrome's getRegisteredContentScripts can
  // still report a script that an unregister is about to remove (Focus off
  // then straight on), so the "already registered" answer can be stale. One
  // quiet second pass repairs that; it never schedules a third.
  if (!verifying) {
    clearTimeout(verifyTimer);
    verifyTimer = setTimeout(() => { syncScripts(true); }, 1500);
  }
  return next;
}

async function syncScriptsNow() {
  let focus = {};
  try { ({ focus = {} } = await chrome.storage.local.get("focus")); } catch (e) { /* first run */ }
  const wanted = (focus.mode && focus.mode !== "off") ? originsFor(focus) : [];

  const granted = [];
  for (const pattern of wanted) {
    try {
      if (await chrome.permissions.contains({ origins: [pattern] })) granted.push(pattern);
    } catch (e) { /* a malformed pattern is not worth the whole list */ }
  }

  let live = [];
  try { live = await chrome.scripting.getRegisteredContentScripts({ ids: [SCRIPT_ID] }); } catch (e) { live = []; }

  if (!granted.length) {
    if (live.length) {
      try { await chrome.scripting.unregisterContentScripts({ ids: [SCRIPT_ID] }); } catch (e) { /* already gone */ }
    }
    return { registered: [] };
  }

  const same = live.length === 1
    && live[0].matches.length === granted.length
    && granted.every((p) => live[0].matches.includes(p));
  if (same) return { registered: granted };

  const spec = {
    id: SCRIPT_ID,
    js: ["focus.js"],
    matches: granted,
    // document_start, because a gate that arrives after the video has started
    // is a gate that lost. focus.js waits for <body> before it draws.
    runAt: "document_start",
    allFrames: false,
    persistAcrossSessions: true,
  };
  let lastErr = null;
  // Chrome commits a register/unregister asynchronously: right after an
  // unregister (Focus off, then straight back on) a register can still say
  // "Duplicate script ID", and an update can say "not found". So: ask again
  // what is live, a little later, and do the call that fits — a few times —
  // rather than tearing everything down (round 3: 2 of 5 runs still ended
  // with nothing registered).
  for (let attempt = 0; attempt < 4; attempt++) {
    try {
      if (live.length) await chrome.scripting.updateContentScripts([spec]);
      else await chrome.scripting.registerContentScripts([spec]);
      return { registered: granted };
    } catch (err) {
      lastErr = err;
      if (!/duplicate|not found|nonexistent|does not exist/i.test(String(err && err.message))) break;
      await new Promise((r) => setTimeout(r, 120 * (attempt + 1)));
      try { live = await chrome.scripting.getRegisteredContentScripts({ ids: [SCRIPT_ID] }); } catch (e) { live = []; }
    }
  }
  {
    const err = lastErr;
    // Chrome refuses the whole call if any pattern is bad. Fall back to
    // registering nothing rather than leaving a stale list registered.
    try { await chrome.scripting.unregisterContentScripts({ ids: [SCRIPT_ID] }); } catch (e) { /* none */ }
    return { registered: [], error: String(err && err.message ? err.message : err) };
  }
}

// ---- the decision --------------------------------------------------------
async function session(key) {
  try {
    const got = await chrome.storage.session.get(key);
    return got[key] || {};
  } catch (e) { return {}; }
}

async function remindAllowed(label, focus, reason) {
  const every = focus.remind_every || "visit";
  // A timer tick is neither a visit nor a navigation; it exists so an
  // expiring bypass closes the gate, and it must never raise a card.
  if (reason === "timer") return false;
  if (every === "visit") return reason === "load";
  if (every === "always") return true;
  const said = await session("focusSaid");
  return !(said[label] && Date.now() - said[label] < HOUR);
}

export async function decide({ host, reason }) {
  let focus = {};
  try { ({ focus = {} } = await chrome.storage.local.get("focus")); } catch (e) { return { action: "none" }; }
  const mode = focus.mode || "off";
  if (mode === "off") return { action: "none" };

  const site = matchSite(host, focus.sites);
  if (!site) return { action: "none" };
  const due = { ...(focus.due || { known: false, clear: false, headline: "", lead: "" }) };
  // "Clear?" is worked out NOW, from the dates, when the snapshot carries
  // them: overdue (not a past test), today or tomorrow counts as work due.
  if (due.known && Array.isArray(focus.open_dates)) {
    const d = new Date();
    const iso = (x) => `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, "0")}-${String(x.getDate()).padStart(2, "0")}`;
    const today = iso(d);
    const tomorrow = iso(new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1));
    const pressing = focus.open_dates.filter((o) => o.d <= tomorrow && !(o.a && o.d < today));
    const clearNow = pressing.length === 0;
    if (clearNow !== due.clear || focus.as_of !== today) {
      due.clear = clearNow;
      if (focus.as_of !== today) {
        due.headline = clearNow ? "" : `${pressing.length} due by tomorrow`;
        due.lead = "";
      }
    }
  }

  if (mode === "remind") {
    if (!(await remindAllowed(site.label, focus, reason))) return { action: "none" };
    return { action: "remind", site: site.label, due };
  }

  // block. An unknown board counts as work outstanding: the alternative is
  // Focus quietly letting everything through on a fresh install.
  if ((focus.when_clear || "allow") === "allow" && due.known && due.clear) {
    return { action: "none" };
  }
  const open = await session("focusOpen");
  if ((open[site.label] || 0) > Date.now()) return { action: "none" };

  return {
    action: "block",
    site: site.label,
    due,
    pinSet: await hasPin(),
    bypassMinutes: focus.bypass_minutes || DEFAULT_BYPASS,
  };
}

export async function unlock({ host, pin }) {
  let focus = {};
  try { ({ focus = {} } = await chrome.storage.local.get("focus")); } catch (e) { /* none */ }
  const site = matchSite(host, focus.sites);
  if (!site) return { ok: true };            // not on the list: nothing to open
  if (!(await checkPin(pin))) {
    // No lockout counter, deliberately. This is the student's own PIN on the
    // student's own browser; a lockout would only ever punish the person who
    // set it, and the way past Focus was never guessing the PIN anyway.
    return { ok: false, message: "That is not the PIN." };
  }
  const minutes = focus.bypass_minutes || DEFAULT_BYPASS;
  const open = await session("focusOpen");
  open[site.label] = Date.now() + minutes * 60 * 1000;
  try { await chrome.storage.session.set({ focusOpen: open }); } catch (e) { /* nothing to do */ }
  return { ok: true, minutes };
}

export async function reminded({ host }) {
  let focus = {};
  try { ({ focus = {} } = await chrome.storage.local.get("focus")); } catch (e) { return { ok: true }; }
  const site = matchSite(host, focus.sites);
  if (!site) return { ok: true };
  const said = await session("focusSaid");
  said[site.label] = Date.now();
  try { await chrome.storage.session.set({ focusSaid: said }); } catch (e) { /* nothing to do */ }
  return { ok: true };
}

// What Settings shows: which of the student's sites are live, and which are
// still waiting for Chrome's permission prompt.
export async function status() {
  let focus = {};
  try { ({ focus = {} } = await chrome.storage.local.get("focus")); } catch (e) { /* none */ }
  const wanted = originsFor(focus);
  const missing = [];
  for (const pattern of wanted) {
    try {
      if (!(await chrome.permissions.contains({ origins: [pattern] }))) missing.push(pattern);
    } catch (e) { missing.push(pattern); }
  }
  let live = [];
  try { live = await chrome.scripting.getRegisteredContentScripts({ ids: [SCRIPT_ID] }); } catch (e) { live = []; }
  return {
    mode: focus.mode || "off",
    pinSet: await hasPin(),
    wanted,
    missing,
    registered: live.length ? live[0].matches : [],
  };
}
