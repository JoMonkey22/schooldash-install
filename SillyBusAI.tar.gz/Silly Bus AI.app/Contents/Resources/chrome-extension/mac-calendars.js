// The regular toolbar's calendar handoff to an explicitly paired local app.
const APP = "http://127.0.0.1:5055";
const googleExport = url => /^https:\/\/calendar\.google\.com\/calendar\/(?:u\/\d\/)?exporticalzip\/?$/.test(url);

export async function linkMacCalendar(link, remember = true) {
  try {
    const {macCalendarToken} = await chrome.storage.local.get("macCalendarToken");
    if (!macCalendarToken) return {ok: false, message: "Connect this extension to the Mac app first."};
    const payload = {url: link.url, name: link.name || "Calendar", refresh_only: !remember};
    if (googleExport(link.url)) {
      const response = await fetch(link.url, {credentials: "include", signal: AbortSignal.timeout(20000)});
      if (!response.ok) throw new Error();
      const bytes = new Uint8Array(await response.arrayBuffer());
      if (bytes.length > 3 * 1024 * 1024 || bytes[0] !== 80 || bytes[1] !== 75) throw new Error();
      let binary = "";
      for (let i = 0; i < bytes.length; i += 8192) binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
      payload.export = btoa(binary);
    }
    const response = await fetch(`${APP}/api/bridge/calendar`, {method: "POST", signal: AbortSignal.timeout(30000),
      headers: {"Content-Type": "application/json", "X-SillyBus-Token": macCalendarToken},
      body: JSON.stringify(payload)});
    const out = await response.json();
    if (response.status === 410) {
      // Removed in the Mac app: stop sending it every five minutes.
      const {macGoogleCalendars = []} = await chrome.storage.local.get("macGoogleCalendars");
      await chrome.storage.local.set({macGoogleCalendars: macGoogleCalendars.filter(c => c.url !== link.url)});
    }
    if (!response.ok) return {ok: false, message: out.error?.message || "Could not connect this calendar to the Mac app."};
    if (remember && googleExport(link.url)) {
      const {macGoogleCalendars = []} = await chrome.storage.local.get("macGoogleCalendars");
      const rest = macGoogleCalendars.filter(c => c.url !== link.url);
      await chrome.storage.local.set({macGoogleCalendars: [...rest, {url: link.url, name: payload.name}].slice(-5)});
    }
    return {ok: true, events: out.events_on_board ?? null,
      calendarEvents: out.calendar_events ?? null, message: out.sync_message || "Calendar saved."};
  } catch (e) {
    return {ok: false, message: "Open the Mac app and sign in to this Google Calendar in Chrome, then link again."};
  }
}

export async function refreshMacCalendars() {
  const {macCalendarToken, macGoogleCalendars = []} = await chrome.storage.local.get(["macCalendarToken", "macGoogleCalendars"]);
  if (!macCalendarToken) return;
  // Only calendars deliberately linked here; never a URL supplied by a web page.
  for (const calendar of macGoogleCalendars) {
    if (googleExport(calendar.url)) await linkMacCalendar(calendar, false);
  }
}

export async function linkMacSchool(link) {
  try {
    const {macCalendarToken} = await chrome.storage.local.get("macCalendarToken");
    if (!macCalendarToken) return {ok: false, message: "Connect this extension to the Mac app first."};
    const response = await fetch(`${APP}/api/bridge/school`, {method: "POST", signal: AbortSignal.timeout(30000),
      headers: {"Content-Type": "application/json", "X-SillyBus-Token": macCalendarToken},
      body: JSON.stringify({url: link.url})});
    const out = await response.json();
    return response.ok ? out : {ok: false, message: out.error?.message || "Could not connect this school."};
  } catch (e) { return {ok: false, message: "Open the Mac app and try Connect again."}; }
}

export async function sendMacAssignments(source, payload) {
  const {macCalendarToken} = await chrome.storage.local.get('macCalendarToken');
  if (!macCalendarToken) return {ok: false};
  const response = await fetch(`${APP}/api/bridge/assignments`, {
    method: 'POST', headers: {'Content-Type': 'application/json', 'X-SillyBus-Token': macCalendarToken},
    body: JSON.stringify({source, payload}), signal: AbortSignal.timeout(30000)});
  return response.json();
}
