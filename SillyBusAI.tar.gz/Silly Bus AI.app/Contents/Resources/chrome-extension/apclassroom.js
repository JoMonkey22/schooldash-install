// SillyBus AI — content script for https://apclassroom.collegeboard.org/*
//
// AP Classroom authorises its API with a token the page keeps in its own
// localStorage, not a cookie, so nothing outside this page can read the
// student's assignments. This script runs ON the page, asks AP Classroom's
// own API the same question the page asks, and answers the extension with
// the assignments only: subject, title, due date, status, link. The token is
// read here, used here, and never sent anywhere but AP Classroom's API — not
// to the extension, not to Python, not into any file.
//
// It does nothing until asked (background.js sends {type: "assignments"}
// during a refresh), and it never signs anyone in: no token means the honest
// answer "not signed in", and the dashboard shows a button to open this site.

(() => {
  // Injected by the manifest on page load and again by bridge.js before each
  // read. Every injection redefines the reader (so a newer file replaces an
  // older one already in the tab); only the message listener is registered
  // once. [MEASURED] 2026-09-14: a guard that skipped the whole file kept an
  // old reader alive in a long-open tab through three rebuilds.
  const firstTime = !window.__sillybusApClassroom;
  window.__sillybusApClassroom = true;

  const API = "https://apc-api-production.collegeboard.org/fym/";
  const SITE = "https://apclassroom.collegeboard.org";

  function token() {
    try {
      const t = window.localStorage.getItem("account_access_token") || "";
      const expires = Number.parseInt(window.localStorage.getItem("expires") || "0", 10);
      if (!t.startsWith("ey")) return null;
      if (expires && Date.now() > expires) return null; // the page refreshes it on its own when it is open
      return t;
    } catch (e) { return null; }
  }

  // Every call is bounded: the dashboard waits for this whole read before its
  // refresh, so one slow answer must not hold the board hostage.
  async function api(path, params, ms = 12000) {
    const url = new URL(API + path);
    for (const [k, v] of Object.entries(params || {})) if (v !== undefined && v !== null && v !== "") url.searchParams.set(k, String(v));
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), ms);
    let res;
    try {
      res = await fetch(url, { headers: { Authorization: `Bearer ${token()}`, Accept: "application/json" }, credentials: "omit", signal: ctl.signal });
    } catch (err) {
      throw new Error(err && err.name === "AbortError" ? `no answer in ${ms / 1000}s for ${path}` : `network: ${err && err.message ? err.message : err}`);
    } finally { clearTimeout(timer); }
    if (res.status === 401 || res.status === 403) throw new Error("not signed in");
    if (!res.ok) throw new Error(`AP Classroom answered ${res.status} for ${path}`);
    return res.json();
  }

  // --- reading the answers ----------------------------------------------------
  // AP Classroom's JSON is not documented, and the field names below are the
  // ones its bundles use (title/name, due_date/dueDate/due_at, status,
  // assignment_id/id). Every accessor tries the spellings in turn and gives up
  // to null rather than guessing, and the raw key names travel back in
  // `diagnostics` so a change on their side is seen, not silently missed.
  const pick = (o, ...keys) => { for (const k of keys) if (o && o[k] !== undefined && o[k] !== null && o[k] !== "") return o[k]; return null; };
  const str = (v) => (v === null || v === undefined ? "" : String(v));

  // The student's subjects, as the page itself learns them: the `me` query.
  // Its `id` is the number in the page's own URLs (/26/assignments) and the
  // one the assessments endpoint is keyed on; `initId` is a second id kept as
  // a fallback. (The REST /assessments/api/subjects/ list answers with other
  // ids that the endpoint 404s on — [MEASURED] 2026-09-14, all 12 subjects.)
  const ME_QUERY = "query me { me { initId isStudent } studentSubjects { id name subjectProgram initId } }";
  // The student dashboard's own query, verbatim from the site's bundles.
  const OVERVIEW_QUERY = "query assignmentsOverviewStudent($subjectId: Int!, $assessmentIds: [Int]!) { assignmentsOverviewStudent { assignments(subjectId: $subjectId, assessmentIds: $assessmentIds) { id name assessmentId startsAt dueAt headline link status scoringCompletedAt showResults submittedAt learnositySubmittedAt assignmentCreatedAt score maxScore sessionStatus allowLateSubmission } } }";

  async function graphql(operationName, query, variables, ms = 12000) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), ms);
    let res;
    try {
      res = await fetch(API + "graphql", {
        method: "POST", credentials: "omit", signal: ctl.signal,
        headers: { Authorization: `Bearer ${token()}`, Accept: "application/json", "Content-Type": "application/json" },
        body: JSON.stringify({ operationName, query, variables: variables || {} }),
      });
    } catch (err) {
      throw new Error(err && err.name === "AbortError" ? `no answer in ${ms / 1000}s for graphql ${operationName}` : `network: ${err && err.message ? err.message : err}`);
    } finally { clearTimeout(timer); }
    if (res.status === 401 || res.status === 403) throw new Error("not signed in");
    if (!res.ok) throw new Error(`AP Classroom answered ${res.status} for graphql ${operationName}`);
    return res.json();
  }

  async function studentSubjects(diagnostics) {
    const body = await graphql("me", ME_QUERY, {});
    if (body && body.errors && body.errors.length) diagnostics.me_errors = body.errors.map((e) => str(e.message)).slice(0, 3);
    const list = (body && body.data && Array.isArray(body.data.studentSubjects)) ? body.data.studentSubjects : [];
    diagnostics.me_keys = list[0] ? Object.keys(list[0]) : [];
    return list.map((s) => ({
      id: str(pick(s, "id")),
      initId: str(pick(s, "initId")),
      name: str(pick(s, "name")),
      program: str(pick(s, "subjectProgram")),
    })).filter((s) => s.id && s.name);
  }

  function* walkAssignments(data) {
    // …/chameleon/assessments/<subjectId>/ answers {resources: [...]} (or
    // assessments), each resource carrying its assignments: the page reads
    // `resources || []` and each assignment's id, starts_at and due_at.
    // The student list is flat: {assignments: [...]} ([MEASURED] 2026-09-14,
    // with has_secure_assignments and readiness_check_url beside it).
    if (data && !Array.isArray(data) && Array.isArray(data.assignments)) {
      for (const a of data.assignments) yield { resource: a.resource || a.assessment || null, assignment: a };
      return;
    }
    const resources = Array.isArray(data) ? data
      : Array.isArray(data?.resources) ? data.resources
      : Array.isArray(data?.assessments) ? data.assessments
      : Array.isArray(data?.results) ? data.results : [];
    for (const r of resources) {
      const inner = Array.isArray(r?.assignments) ? r.assignments : (r?.assignment ? [r.assignment] : []);
      if (inner.length) for (const a of inner) yield { resource: r, assignment: a };
      else if (pick(r, "due_at", "due_date", "dueDate", "dueAt")) yield { resource: r, assignment: r };
    }
  }

  function toRecord(subject, { resource, assignment }, overview) {
    const a = assignment || {}, r = resource || {}, o = overview || {};
    const id = str(pick(a, "id", "assignment_id", "assignmentId") || pick(o, "id"));
    const title = str(pick(o, "name", "headline") || pick(a, "title", "name") || pick(r, "title", "name") || pick(r?.assessment, "title", "name"));
    const due = pick(o, "dueAt") || pick(a, "due_at", "due_date", "dueDate", "dueAt", "due", "end_date", "endDate");
    const status = str(pick(o, "status", "sessionStatus") || pick(a, "status", "assignment_status", "assignmentStatus", "state") || pick(r, "status")).toLowerCase();
    const kind = str(pick(r, "resource_type", "resourceType", "type", "assessment_type") || pick(a, "type", "assignment_type"));
    const assigned = pick(o, "startsAt") || pick(a, "starts_at", "assigned_date", "assignedDate", "start_date", "startDate", "created_at");
    const submitted = pick(o, "submittedAt", "learnositySubmittedAt") || pick(a, "submitted_at", "submittedAt");
    if (!title) return null;
    // Where the student stands: the list's progress counters and actions
    // ("continue" once started, "begin" before).
    const progress = a.progress || {};
    const actions = Array.isArray(a.actions) ? a.actions.map(str) : [];
    const state = submitted || progress.submitted || progress.complete ? "submitted"
      : (progress.started || actions.includes("continue")) ? "started"
      : status === "opened" || actions.includes("begin") ? "not started" : (status || "");
    // The routes the site's own Begin/Continue and View links use.
    const openUrl = id ? `${SITE}/${subject.id}/assessments/assignments/${id}` : `${SITE}/${subject.id}/assignments/dashboard`;
    const resultsUrl = id ? `${SITE}/${subject.id}/assessments/results/${id}` : openUrl;
    return {
      id,
      subject: subject.name,
      subject_id: subject.id,
      title,
      due: due ? str(due) : null,
      status,
      state,
      kind,
      timer: typeof a.timer === "number" ? a.timer : (typeof o.timer === "number" ? o.timer : null),
      assigned: assigned ? str(assigned) : null,
      submitted: submitted ? str(submitted) : null,
      score: o.score ?? a.score ?? null,
      max_score: o.maxScore ?? a.max_score ?? null,
      url: state === "submitted" ? resultsUrl : openUrl,
      results_url: resultsUrl,
    };
  }

  // How many questions, of which type, an open Progress Check has — counts
  // only, from the site's own getQuestionsTypesOnAssignment. The questions
  // themselves are College Board's assessment and are not read.
  const QUESTION_TYPES_QUERY = "query getQuestionsTypesOnAssignment($assignmentId: String) { assignment(assignmentId: $assignmentId) { id questions { ... on MultipleChoiceQuestion { id: itemId type: __typename } ... on FreeResponseQuestion { id: itemId type: __typename } } } }";
  const MAX_QUESTION_LOOKUPS = 12;

  async function countQuestions(records, diagnostics) {
    const open = records.filter((r) => r.kind === "ppc" && r.state !== "submitted" && r.id).slice(0, MAX_QUESTION_LOOKUPS);
    diagnostics.question_lookups = open.length;
    await Promise.all(open.map(async (r) => {
      try {
        const body = await graphql("getQuestionsTypesOnAssignment", QUESTION_TYPES_QUERY, { assignmentId: r.id }, 8000);
        const qs = body?.data?.assignment?.questions || [];
        r.questions = { mcq: qs.filter((q) => q.type === "MultipleChoiceQuestion").length,
                        frq: qs.filter((q) => q.type === "FreeResponseQuestion").length };
      } catch (err) {
        diagnostics.question_errors = (diagnostics.question_errors || 0) + 1;
      }
    }));
  }

  const shorten = (v) => (typeof v === "string" && v.length > 60 ? v.slice(0, 60) + "…" : v);
  const trim = (o, depth = 0) => (Array.isArray(o) ? o.slice(0, 2).map((x) => trim(x, depth + 1))
    : o && typeof o === "object" && depth < 4 ? Object.fromEntries(Object.entries(o).slice(0, 24).map(([k, v]) => [k, trim(v, depth + 1)]))
    : shorten(o));

  async function readAssignments() {
    if (!token()) return { error: "not signed in", assignments: [], subjects: [], diagnostics: { sign_in: signInState() } };
    const t0 = Date.now();
    const diagnostics = { assignment_keys: [], resource_keys: [], per_subject: {}, ms: {} };
    const subjects = await studentSubjects(diagnostics);
    diagnostics.subjects = subjects.length;
    diagnostics.subject_sample = trim(subjects.slice(0, 2));
    const assignments = [];
    // All subjects at once: one slow subject then costs its own 12 s, not
    // 12 s times the number of AP classes.
    await Promise.all(subjects.map(async (subject) => {
      const s0 = Date.now();
      let data;
      try {
        // The student's own list — the page's "All Assigned" view. (The
        // teacher list at …/chameleon/assessments/ answers 401 to a student
        // token; [MEASURED] 2026-09-14 on all six subjects.)
        data = await api(`assessments/api/chameleon/student_assignments/${subject.id}/`, { status: "all-assigned" });
      } catch (err) {
        diagnostics.per_subject[subject.name] = `error: ${err.message}`;
        diagnostics.ms[subject.name] = Date.now() - s0;
        return;
      }
      const pairs = [...walkAssignments(data)];
      if (!diagnostics.list_keys) diagnostics.list_keys = Array.isArray(data) ? ["<array>"] : Object.keys(data || {}).slice(0, 20);
      // Names, status and due dates come from the overview query, keyed by
      // the assessment ids the list carries; the list alone has ids and dates.
      const assessmentIds = [...new Set(pairs.map(({ resource, assignment }) => Number(pick(assignment, "assessment_id", "assessmentId") || pick(resource, "assessment_id", "assessmentId", "id") || pick(resource?.assessment, "id"))).filter((n) => Number.isFinite(n) && n > 0))];
      let overview = new Map();
      if (assessmentIds.length) {
        try {
          const body = await graphql("assignmentsOverviewStudent", OVERVIEW_QUERY, { subjectId: Number(subject.id), assessmentIds });
          for (const a of (body?.data?.assignmentsOverviewStudent?.assignments || [])) overview.set(str(a.id), a);
          if (body?.errors?.length) diagnostics.overview_errors = body.errors.map((e) => str(e.message)).slice(0, 3);
        } catch (err) { diagnostics.overview_errors = [err.message]; }
      }
      let n = 0;
      for (const pair of pairs) {
        if (!diagnostics.assignment_keys.length) diagnostics.assignment_keys = Object.keys(pair.assignment || {});
        if (!diagnostics.resource_keys.length) diagnostics.resource_keys = Object.keys(pair.resource || {});
        if (!diagnostics.resource_sample) diagnostics.resource_sample = trim(pair.resource);
        if (!diagnostics.assignment_sample) diagnostics.assignment_sample = trim(pair.assignment);
        const rec = toRecord(subject, pair, overview.get(str(pick(pair.assignment, "id", "assignment_id", "assignmentId"))));
        if (rec) { assignments.push(rec); n++; }
      }
      if (!diagnostics.overview_sample && overview.size) diagnostics.overview_sample = trim([...overview.values()][0]);
      diagnostics.per_subject[subject.name] = n || `0 (shape ${Array.isArray(data) ? `array[${data.length}]` : `{${Object.keys(data || {}).slice(0, 12).join(",")}}`})`;
      diagnostics.ms[subject.name] = Date.now() - s0;
    }));
    await countQuestions(assignments, diagnostics);
    diagnostics.ms.total = Date.now() - t0;
    return { assignments, subjects: subjects.map((s) => ({ id: s.id, name: s.name })), diagnostics };
  }

  function signInState() {
    try {
      const t = window.localStorage.getItem("account_access_token") || "";
      const exp = Number.parseInt(window.localStorage.getItem("expires") || "0", 10);
      return { token_present: t.startsWith("ey"), expires_in_min: exp ? Math.round((exp - Date.now()) / 60000) : null, where: location.pathname };
    } catch (e) { return { token_present: false, storage: "unavailable" }; }
  }

  const READER_VERSION = "2026-09-14f";
  async function answer() {
    try { return { ...(await readAssignments()), read_at: new Date().toISOString(), reader_version: READER_VERSION }; }
    catch (err) {
      // The message alone has been misleading; the first stack line says
      // which line of this file the failure is on.
      const where = String(err && err.stack || "").split("\n").slice(1, 3).join(" ").replace(/chrome-extension:\/\/[a-z]+\//g, "");
      return { error: `${err && err.message ? err.message : err}${where ? ` @ ${where.trim()}` : ""}`, assignments: [], read_at: new Date().toISOString(), reader_version: READER_VERSION };
    }
  }

  // Two ways to be asked. bridge.js prefers chrome.scripting.executeScript
  // with a function that calls this global — the answer is the function's
  // return value, no message port involved. [MEASURED] 2026-09-14: on his
  // Chrome, tabs.sendMessage to this tab answered "Receiving end does not
  // exist" ten times running, injection and a tab reload included, while the
  // script itself was fine — so the port is not relied on.
  globalThis.__sillybusReadApClassroom = answer;

  if (firstTime) try {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message?.type !== "assignments") return false;
      answer().then(sendResponse);
      return true; // answered asynchronously
    });
  } catch (e) { /* not a content-script context */ }
})();
