// Runs before app.js and views.js. Teaches the unchanged dashboard to live in
// an extension page instead of behind a server on 127.0.0.1:5055.
//
//   fetch("/api/…")        → a message to the Python worker
//   new EventSource(url)   → the same, replayed as server-sent events
//   history.pushState("/classes") → "#classes" (an extension page has one real
//                            path; the view name rides in the hash)
//   navigator.serviceWorker → a harmless stand-in (extensions have their own)
//
// Nothing in app.js / views.js is edited to make this work, except that the
// build step swaps `location.pathname` for `__sdPath()` — see build-payload.sh.

(function () {
  /* ---- one Python, any number of tabs ------------------------------------
   *
   * [ASKED] 2026-09-20: "it also only lets you open one tab, please change
   * that. all the tabs should be in perfect sink but can be in different
   * windows."
   *
   * Only one tab may RUN the app, and that is not a preference. The data home
   * is an IDBFS mount, and its write-back REMOVES from IndexedDB every entry
   * the local mount does not have — so two Pythons on one store erase each
   * other's work ([MEASURED] 2026-09-20: his class profiles went 2 → 7 → 0
   * between refreshes). The old answer was to refuse the second tab and close
   * it, which is why he could only ever have one.
   *
   * The new answer is one owner and any number of viewers. The first tab wins
   * the `sillybus-owner` lock and boots Python. Every other tab sends its
   * /api/ calls to that tab over a BroadcastChannel and gets the real answers
   * back — so a second window is the same app, not a second copy: one
   * database, one set of files, one refresh. The owner tells every tab
   * whenever anything was written, so a tick in one window lands in the
   * others at once. When the owner closes, its lock is released, the next tab
   * in the queue takes over and boots Python itself.
   *
   * A tab knows nothing about which windows the others are in; the channel is
   * per profile, so windows, split screens and a pinned tab all work the same.
   */
  const CHAN = new BroadcastChannel("sillybus-app");
  const CLIENT = Math.random().toString(36).slice(2, 10);
  let worker = null;            // the owner's Python; null in a viewer tab
  let role = "";                // "owner" | "follower"
  let ownerId = "";             // which owner generation a viewer is talking to
  let bootedVersion = null;
  let lastStatus = "Starting…";
  const pending = new Map();    // our own in-flight calls
  const relaying = new Map();   // as owner: calls being answered for a viewer
  let nextId = 1;
  let ready;
  const readyPromise = new Promise((resolve) => { ready = resolve; });
  const toWorker = (msg, transfer) => { if (worker) worker.postMessage(msg, transfer || []); };

  // ---- boot overlay -------------------------------------------------------
  const overlay = document.createElement("div");
  overlay.id = "sd-boot";
  overlay.setAttribute("role", "status");
  overlay.innerHTML = `
    <style>
      #sd-boot { position: fixed; inset: 0; z-index: 99999; display: grid; place-items: center;
        background: #F6F7FA; color: #1B2233; font: 16px/1.5 -apple-system, "Segoe UI", system-ui, sans-serif; }
      @media (prefers-color-scheme: dark) { #sd-boot { background: #0F131C; color: #E7EAF1; } }
      #sd-boot .card { display: grid; gap: 10px; justify-items: center; text-align: center; max-width: 34ch; padding: 24px; }
      #sd-boot .bar { width: 220px; height: 4px; border-radius: 2px; background: rgba(127,138,160,.25); overflow: hidden; }
      #sd-boot .bar i { display: block; height: 100%; width: 40%; background: #2F55C4; border-radius: 2px; animation: sd-slide 1.2s ease-in-out infinite; }
      @keyframes sd-slide { 0% { transform: translateX(-100%);} 100% { transform: translateX(350%);} }
      @media (prefers-reduced-motion: reduce) { #sd-boot .bar i { animation: none; width: 100%; } }
      #sd-boot .msg { color: #7C8699; font-size: .95rem; }
      #sd-boot .err { color: #B8362D; font-size: .95rem; white-space: pre-wrap; }
    </style>
    <div class="card"><strong>SillyBus AI</strong><div class="bar"><i></i></div><div class="msg">Starting…</div></div>`;
  const mount = () => document.documentElement.appendChild(overlay);
  if (document.documentElement) mount(); else document.addEventListener("DOMContentLoaded", mount);
  const setStatus = (text) => { const m = overlay.querySelector(".msg"); if (m) m.textContent = text; };
  const setFatal = (text) => {
    const card = overlay.querySelector(".card");
    card.innerHTML = `<strong>SillyBus AI could not start</strong><div class="err"></div>
      <div class="msg">Reload the tab to try again. If it keeps happening, this message is what to report.</div>`;
    card.querySelector(".err").textContent = text;
  };

  // Hooks for dev.js (development only; see that file). Harmless otherwise.
  const listeners = [];
  window.__sd = { sdFetch: (...a) => sdFetch(...a), onWorkerMessage: (fn) => listeners.push(fn),
                  get worker() { return worker; }, get role() { return role; } };

  // What the dashboard may ask of Chrome itself. Settings -> Connections shows
  // the "Always running" card only when this object exists, so the Mac app
  // (which has launchd for the same job) never shows a switch it cannot keep.
  window.sdChrome = {
    autostart: false,
    sessions: {},
    async setAutostart(on) {
      this.autostart = !!on;
      await chrome.storage.local.set({ autostart: !!on });
    },
  };
  chrome.storage.local.get("autostart").then((o) => { window.sdChrome.autostart = !!o.autostart; }).catch(() => {});
  // A discarded tab is a cold boot; Memory Saver is told to leave this one.
  try { chrome.runtime.sendMessage({ type: "keep-this-tab" }); } catch (e) { /* no service worker yet */ }

  // ---- the automatic backup ---------------------------------------------
  // [MEASURED] 2026-09-19 16:09: the IndexedDB store the whole data home lives
  // in came back empty while chrome.storage.local, a different store, kept
  // the Options page's settings from five days earlier. So the copy goes
  // there: a zip of config, state.db, profiles, courses and the last board
  // (boot.export_archive), base64 in chrome.storage.local under `backup`,
  // with the one before it under `backup_prev`. Made shortly after boot, five
  // minutes after any write, and every six hours; a backup with no work on
  // it never replaces one that had work. On an empty data home the worker
  // asks for it back before Python writes anything.
  const b64 = (buf) => { const u = new Uint8Array(buf); let s = ""; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); };
  const unb64 = (s) => { const bin = atob(s); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u.buffer; };
  let backupTimer = null;
  /* Backups are the owner's job: it is the only tab with the files. */
  /* The EARLIEST pending backup wins. [MEASURED] 2026-10-07 (prosecution
     round 3): the 20-second first backup was replaced by "5 minutes after the
     last write" as soon as refresh-on-open wrote anything, so it landed ~310 s
     after boot — and a session closed sooner never backed up at all. */
  let backupDue = 0;
  function scheduleBackup(ms) {
    const at = Date.now() + ms;
    if (backupTimer && backupDue && backupDue <= at) return;
    clearTimeout(backupTimer);
    backupDue = at;
    backupTimer = setTimeout(() => { backupTimer = null; backupDue = 0; askBackup(); }, ms);
  }
  const askBackup = () => (role === "owner" ? toWorker({ type: "backup" })
                                            : CHAN.postMessage({ t: "cmd", from: CLIENT, name: "backup" }));
  async function keepBackup(msg) {
    try {
      const { backup } = await chrome.storage.local.get("backup");
      const info = msg.info || {};
      const prev = (backup && backup.info) || {};
      const emptier = (!info.state_db && prev.state_db) || (info.items === 0 && (prev.items || 0) > 0) || (info.profiles === 0 && (prev.profiles || 0) > 0);
      if (emptier) { console.log("[sillybus] backup skipped: this one holds less than the last"); return; }
      const entry = { at: msg.at, size: msg.zip.byteLength, info, data: b64(msg.zip) };
      const write = { backup: entry };
      if (backup && backup.data) write.backup_prev = backup;
      await chrome.storage.local.set(write);
      window.sdChrome.backup = { at: entry.at, size: entry.size, info };
      window.dispatchEvent(new CustomEvent("sd-backup"));
    } catch (err) { console.log("[sillybus] backup not kept:", err && err.message ? err.message : err); }
  }
  async function answerRestore() {
    let zip = null;
    try {
      const { backup } = await chrome.storage.local.get("backup");
      if (backup && backup.data) { zip = unb64(backup.data); setStatus(`Your data store was empty — putting back the backup from ${new Date(backup.at).toLocaleString()}…`); }
    } catch (e) { /* nothing to restore */ }
    toWorker({ type: "restore", zip }, zip ? [zip] : []);
  }
  chrome.storage.local.get("backup").then(({ backup }) => { if (backup) window.sdChrome.backup = { at: backup.at, size: backup.size, info: backup.info }; }).catch(() => {});
  window.sdChrome.backupNow = () => new Promise((resolve) => {
    const done = () => { window.removeEventListener("sd-backup", done); resolve(window.sdChrome.backup); };
    window.addEventListener("sd-backup", done);
    askBackup();
    setTimeout(done, 8000);
  });
  window.sdChrome.downloadBackup = async () => {
    const { backup } = await chrome.storage.local.get("backup");
    if (!backup || !backup.data) return false;
    const blob = new Blob([unb64(backup.data)], { type: "application/zip" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `SillyBusAI-backup-${new Date(backup.at).toISOString().slice(0, 16).replace(/[:T]/g, "-")}.zip`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 10000);
    return true;
  };
  // One tab makes the backups, not all of them — including a tab PROMOTED to
  // owner later, which used to get neither the first backup nor the 6-hourly
  // one (it was a viewer when this ran).
  let backupsStarted = false;
  function startBackups() {
    if (backupsStarted || role !== "owner") return;
    backupsStarted = true;
    scheduleBackup(20 * 1000);
    setInterval(() => { if (role === "owner") toWorker({ type: "backup" }); }, 6 * 60 * 60 * 1000);
  }
  readyPromise.then(startBackups);

  const toResponse = (status, headers, body) => {
    // A 204/205/304 may carry no body at all — the Response constructor
    // throws on an empty Uint8Array for those, which would turn the
    // "nothing changed" answer into a failed poll.
    const bodiless = [204, 205, 304].includes(status);
    return new Response(bodiless ? null : body, { status, headers });
  };
  const fireProgress = (d) => window.dispatchEvent(new CustomEvent("sd-progress", { detail: {
    kind: d.kind, jobId: d.jobId, line: d.line, done: !!d.done, ok: d.ok } }));
  /* Something was written. Every tab reloads on this, which is what makes a
     tick in one window land in the others. */
  const fireChanged = (path) =>
    window.dispatchEvent(new CustomEvent("sd-changed", { detail: { path } }));

  function handleWorkerMessage(msg) {
    for (const fn of listeners) { try { fn(msg); } catch (e) { /* dev hook */ } }
    if (msg.type === "status") { lastStatus = msg.message; setStatus(msg.message); CHAN.postMessage({ t: "status", from: CLIENT, message: msg.message }); }
    else if (msg.type === "ready") {
      bootedVersion = msg.version;
      overlay.remove(); ready(); window.__sdVersion = msg.version;
      CHAN.postMessage({ t: "ready", from: CLIENT, version: msg.version });
    }
    else if (msg.type === "fatal") {
      // "busy" can no longer happen from a tab we elected, but a stale worker
      // of a tab that has just closed can still be holding the data lock for
      // a moment. Waiting is right; closing this tab is not.
      if (msg.code === "busy") { setStatus(msg.message); setTimeout(() => location.reload(), 1500); }
      else { setFatal(msg.message); CHAN.postMessage({ t: "fatal", from: CLIENT, message: msg.message }); }
    }
    else if (msg.type === "log") console.log("[sillybus]", msg.message);
    // A job talking while it works. Every tab shows it, so the ⚡ panel's
    // thinking is on screen in the window he is actually looking at.
    else if (msg.type === "progress") {
      fireProgress(msg);
      CHAN.postMessage({ t: "progress", from: CLIENT, kind: msg.kind, jobId: msg.jobId,
                         line: msg.line, done: !!msg.done, ok: msg.ok });
    }
    else if (msg.type === "empty") { answerRestore(); }
    else if (msg.type === "restored") { setStatus(`Put back ${msg.items} items and ${msg.profiles} class profiles from the last backup`); }
    else if (msg.type === "synced") { scheduleBackup(5 * 60 * 1000); }
    else if (msg.type === "backup") { keepBackup(msg); }
    else if (msg.type === "keepalive") {
      window.sdChrome.sessions[msg.name] = { url: msg.url, ok: !!msg.ok, status: msg.status, at: msg.at };
      window.dispatchEvent(new CustomEvent("sd-sessions"));
      CHAN.postMessage({ t: "sessions", from: CLIENT, sessions: window.sdChrome.sessions });
    }
    else if (msg.type === "response") {
      // Answering for a viewer tab: the bytes go back down the channel
      // exactly as they came out of Python.
      const relay = relaying.get(msg.id);
      if (relay) {
        relaying.delete(msg.id);
        CHAN.postMessage({ t: "res", from: CLIENT, to: relay.to, id: relay.id,
                           status: msg.status, headers: msg.headers, body: msg.body });
        if (relay.method !== "GET") { fireChanged(relay.path); announce(relay.path); }
        return;
      }
      const p = pending.get(msg.id);
      if (!p) return;
      pending.delete(msg.id);
      // Tell THIS tab too: the owner only told the others, so its own
      // Focus mirror, connector list and class list never refreshed after
      // its own writes — a task added here left the YouTube gate on the old
      // "nothing due", and a connector switched off still opened its site
      // (prosecution round 3, 2026-10-07).
      if (p.method !== "GET") { announce(p.path); fireChanged(p.path); }
      p.resolve(toResponse(msg.status, msg.headers, msg.body));
    }
  }
  const announce = (path) => CHAN.postMessage({ t: "changed", from: CLIENT, path });

  // ---- who runs Python, and who only watches ------------------------------

  function becomeOwner() {
    role = "owner";
    queueMicrotask(() => readyPromise.then(startBackups));
    // ?own=1 tells the worker it was elected: it may WAIT for the data lock
    // if a just-closed tab's worker is still letting go of it.
    worker = new Worker(new URL("worker.js?own=1", location.href), { type: "module" });
    worker.onmessage = (event) => handleWorkerMessage(event.data);
    worker.onerror = (e) => setFatal(e.message || "the Python worker failed to start");
    pushSettings();
    resendPending();
  }

  function becomeFollower() {
    role = "follower";
    setStatus("Connecting to the tab that is running SillyBus AI…");
    CHAN.postMessage({ t: "hello", from: CLIENT });
  }

  /* Taking over after the owner tab closed. The overlay comes back because
     this tab is genuinely unusable for the few seconds Python takes to
     start — pretending otherwise would just show stale numbers. */
  function promote() {
    if (role === "owner") return;
    if (!overlay.isConnected) document.documentElement.appendChild(overlay);
    setStatus("The tab that was running SillyBus AI closed — taking over…");
    becomeOwner();
  }

  /* Calls that were in flight when the owner went away, or when a new owner
     announced itself. A GET is simply asked again. Anything that writes is
     NOT retried: it may already have happened, and doing it twice is worse
     than saying so. */
  function resendPending() {
    if (!pending.size) return;
    const waiting = [...pending.values()];
    pending.clear();
    for (const p of waiting) {
      if (p.method !== "GET") {
        p.reject(new Error("the tab running SillyBus AI closed while that was in "
          + "flight — it may or may not have gone through; check before trying again"));
        continue;
      }
      send(p.method, p.path, p.body, p.headers).then(p.resolve, p.reject);
    }
  }

  CHAN.onmessage = (event) => {
    const m = event.data || {};
    if (!m.t || m.from === CLIENT) return;
    if (role === "owner") {
      if (m.t === "hello") {
        CHAN.postMessage(bootedVersion
          ? { t: "ready", from: CLIENT, version: bootedVersion }
          : { t: "status", from: CLIENT, message: lastStatus });
      } else if (m.t === "req") {
        const id = nextId++;
        relaying.set(id, { to: m.from, id: m.id, method: m.method, path: m.path });
        toWorker({ type: "request", id, method: m.method, path: m.path,
                   body: m.body ?? null, headers: m.headers || {} });
      } else if (m.t === "cmd" && m.name === "backup") {
        toWorker({ type: "backup" });
      } else if (m.t === "handoff") {
        toWorker({ type: m.key, payload: m.payload });
      }
      return;
    }
    // A viewer tab.
    if (m.t === "status") setStatus(m.message);
    else if (m.t === "ready") {
      // A DIFFERENT owner than the one we were talking to means the old one
      // went away mid-call; ask again rather than waiting on a dead tab.
      const changedOwner = ownerId && ownerId !== m.from;
      ownerId = m.from;
      bootedVersion = m.version;
      window.__sdVersion = m.version;
      overlay.remove();
      ready();
      if (changedOwner) resendPending();
    }
    else if (m.t === "fatal") setFatal(m.message);
    else if (m.t === "progress") fireProgress(m);
    else if (m.t === "changed") fireChanged(m.path);
    else if (m.t === "sessions") {
      window.sdChrome.sessions = m.sessions || {};
      window.dispatchEvent(new CustomEvent("sd-sessions"));
    }
    else if (m.t === "res" && m.to === CLIENT) {
      const p = pending.get(m.id);
      if (!p) return;
      pending.delete(m.id);
      p.resolve(toResponse(m.status, m.headers, m.body));
    }
  };

  /* The election. `ifAvailable` decides this tab's role now; the second,
     queued request is how a viewer becomes the owner later, the moment the
     owner tab's lock is released. Without the Web Locks API (never true in
     Chrome 116+, which the manifest requires) every tab runs its own Python,
     which is the behaviour this replaced. */
  if (navigator.locks && navigator.locks.request) {
    navigator.locks.request("sillybus-owner", { ifAvailable: true }, (lock) => {
      if (lock) { becomeOwner(); return new Promise(() => {}); }
      becomeFollower();
      navigator.locks.request("sillybus-owner", () => { promote(); return new Promise(() => {}); });
      return undefined;
    }).catch(() => { if (!role) becomeOwner(); });
  } else {
    becomeOwner();
  }

  // ---- fetch → whoever is running Python ----------------------------------
  function send(method, path, body, headers, transfer) {
    const id = nextId++;
    return new Promise((resolve, reject) => {
      pending.set(id, { resolve, reject, method, path, body, headers });
      if (role === "owner") {
        toWorker({ type: "request", id, method, path, body, headers }, transfer || []);
      } else {
        // BroadcastChannel copies rather than transfers, so the body is still
        // ours afterwards — which is what makes a resend possible at all.
        CHAN.postMessage({ t: "req", from: CLIENT, id, method, path, body, headers });
      }
    });
  }

  async function sdFetch(path, init = {}) {
    await readyPromise;
    let body = init.body ?? null;
    const transfer = [];
    if (body && typeof body !== "string") {
      if (body instanceof URLSearchParams) body = body.toString();
      else if (body instanceof FormData) body = new URLSearchParams(body).toString();
      /* [MEASURED] 2026-09-18 from his install: "custom backgrounds now doesn't
         do anything". The Appearance page POSTs the dropped File itself as the
         body; String(file) is the fourteen characters "[object File]", so the
         Python side saved a 14-byte "image", the <img> could not decode it,
         and the board quietly dropped the background. Bytes go as bytes. */
      else if (body instanceof Blob || body instanceof ArrayBuffer || ArrayBuffer.isView(body)) {
        const buf = body instanceof Blob ? await body.arrayBuffer()
          : body instanceof ArrayBuffer ? body : body.buffer.slice(body.byteOffset, body.byteOffset + body.byteLength);
        body = new Uint8Array(buf);
        transfer.push(body.buffer);
      }
      else body = String(body);
    }
    const headers = {};
    if (init.headers) {
      const h = init.headers instanceof Headers ? init.headers : new Headers(init.headers);
      h.forEach((v, k) => { headers[k] = v; });
    }
    return send((init.method || "GET").toUpperCase(), path, body, headers,
                role === "owner" ? transfer : undefined);
  }

  // The sign-in button. Python (_shims/extlogin.py) checks which sites this
  // Chrome is already signed in to and answers in the wizard's own format;
  // when a site needs the student, it names the URL and this opens it in a tab.
  async function signIn(url, init) {
    const res = await sdFetch(url, init);
    try {
      const out = await res.clone().json();
      for (const target of out.open_urls || []) {
        try { await chrome.tabs.create({ url: target, active: true }); } catch (e) { window.open(target, "_blank", "noopener"); }
      }
    } catch (e) { /* not JSON; hand it to the page as-is */ }
    return res;
  }

  // AP Classroom cannot be read from here: its token lives in that page's own
  // storage, so the content script on an AP Classroom tab (apclassroom.js)
  // answers for it. This page — not the service worker — finds or opens that
  // tab and asks it. [MEASURED] 2026-09-14: relayed through background.js,
  // the reply came back as "The message port closed before a response was
  // received": a service worker is put to sleep while a pull waits on a page
  // load, and its port goes with it. An extension page has the same
  // chrome.tabs access and stays alive as long as the dashboard is open.
  // Whatever happens, the refresh still runs: a failure is a banner on the
  // board (with a button to open the site), not a missing refresh.
  //
  // Generalised 2026-09-16 for Albert.io, which needs exactly the same dance
  // for a different reason (its API is cookie-authorised and allows only the
  // albert.io origin, so nothing outside an albert.io page can ask it). The
  // machinery below — find or open a tab, thaw a frozen one, wait for the
  // sign-in round trip, inject, bound everything — is unchanged in behaviour;
  // it is now written once and instantiated per site, so the next site that
  // has to be read on its own page is a SITES entry and a content script.
  const SITES = [
    {key: "googleclassroom", source: "google_classroom", label: "Google Classroom",
     site: "https://classroom.google.com/", inside: "https://classroom.google.com/",
     file: "google-classroom.js", reader: "__sillybusReadGoogleClassroom"},
    {
      key: "apclassroom",
      // The config switch that turns this site off. Read from /api/health
      // before every pull; see refreshWithSites.
      source: "ap_classroom",
      label: "AP Classroom",
      site: "https://apclassroom.collegeboard.org/",
      // The site's front door sends a student on to myap.collegeboard.org,
      // where this extension has no permission and no script; the subjects
      // page stays on apclassroom.collegeboard.org.
      inside: "https://apclassroom.collegeboard.org/subjects/preview",
      file: "apclassroom.js",
      reader: "__sillybusReadApClassroom",
    },
    {
      key: "albert",
      source: "albert",
      label: "Albert.io",
      site: "https://www.albert.io/",
      // Signed in, /dashboard is the assignments home; signed out it
      // redirects to the sign-in page on the same origin, so a content
      // script still runs and can answer "not signed in" honestly.
      inside: "https://www.albert.io/dashboard",
      file: "albert.js",
      reader: "__sillybusReadAlbert",
    },
  ];

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const stamp = () => new Date().toISOString();

  function waitForLoad(tabId, ms = 25000) {
    return new Promise((resolve) => {
      const timer = setTimeout(() => { chrome.tabs.onUpdated.removeListener(onUpdated); resolve(false); }, ms);
      function onUpdated(id, info) {
        if (id === tabId && info.status === "complete") {
          clearTimeout(timer); chrome.tabs.onUpdated.removeListener(onUpdated); resolve(true);
        }
      }
      chrome.tabs.onUpdated.addListener(onUpdated);
    });
  }

  // Anything asked of another tab is bounded. [MEASURED] 2026-09-14: a
  // background AP Classroom tab that had been open a while took a script
  // injection and never answered — Chrome freezes idle background tabs, and
  // a frozen tab runs nothing until it is looked at. So an open tab gets one
  // short chance; otherwise a fresh background tab is opened for the read
  // (same profile, so the same sign-in) and closed afterwards.
  const withTimeout = (promise, ms, what) => Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`${what} took more than ${ms / 1000}s`)), ms)),
  ]);

  function makeSiteReader(spec) {
    // Breadcrumbs for the console (and the dev channel): where a slow pull
    // spends its time is otherwise invisible.
    const say = (t0, text) => console.log(`[sillybus] ${spec.label} +${((Date.now() - t0) / 1000).toFixed(1)}s ${text}`);
    const empty = (error) => ({ error, assignments: [], read_at: stamp() });

    // Run the reader inside the tab and take its return value. The content
    // script defines the global; injecting the file first makes sure it is
    // there even in a tab that was open before the extension loaded.
    async function runReaderIn(tabId, t0 = Date.now(), budgetMs = 30000) {
      await withTimeout(chrome.scripting.executeScript({ target: { tabId }, files: [spec.file] }), 8000, "injecting the reader");
      say(t0, "reader file injected");
      const results = await withTimeout(chrome.scripting.executeScript({
        target: { tabId },
        args: [budgetMs, spec.reader, spec.label],
        // The reader bounds every call it makes, and this bounds the reader.
        func: (budget, readerName, label) => (globalThis[readerName]
          ? Promise.race([
              globalThis[readerName](),
              new Promise((resolve) => setTimeout(() => resolve({ error: `the reader did not finish within ${budget / 1000} seconds inside the ${label} tab`, assignments: [], read_at: new Date().toISOString() }), budget)),
            ])
          : { error: `the reader did not load in the ${label} tab`, assignments: [] }),
      }), budgetMs + 5000, "running the reader");
      say(t0, `reader returned ${results ? results.length : 0} result(s)`);
      const hit = (results || []).find((r) => r && r.result);
      return hit ? hit.result : null;
    }

    // A fresh load goes out through the site's sign-in host and comes back —
    // hosts this extension cannot see, so the tab's URL reads as empty while
    // it is away. Wait for it to be back inside; a tab that never comes back
    // is one that stopped at the sign-in form.
    async function waitInside(tabId, t0, ms = 20000) {
      const until = Date.now() + ms;
      let seen = "";
      let stable = 0;
      while (Date.now() < until) {
        const tab = await chrome.tabs.get(tabId).catch(() => null);
        if (!tab) return null;
        const where = tab.url && tab.url.startsWith(spec.site) ? "inside" : "away";
        if (where !== seen) { say(t0, `tab is ${where}${where === "inside" ? `: ${String(tab.url).slice(0, 70)} (${tab.status})` : ""}`); seen = where; stable = 0; }
        // Inside and finished loading for two polls running: the page hops out
        // to the sign-in host and back on its way in, and a script sent during
        // the hop is refused for the host it is briefly on.
        if (where === "inside" && tab.status === "complete" && ++stable >= 2) return tab;
        await sleep(1000);
      }
      return null;
    }

    async function readInTab(tabId, t0) {
      let lastError = "";
      for (let attempt = 0; attempt < 3; attempt++) {
        const tab = await waitInside(tabId, t0);
        if (!tab) return empty("not signed in");
        await sleep(800); // the page's own scripts settle the session
        try {
          return await runReaderIn(tabId, t0);
        } catch (err) {
          lastError = err && err.message ? err.message : String(err);
          // Refused for the host: the page hopped out again mid-way. Wait for
          // it to come back and try once more.
          if (!/Cannot access|host/i.test(lastError)) throw err;
          say(t0, `the page was away when asked (${lastError.slice(0, 60)}…); waiting for it to come back`);
        }
      }
      throw new Error(lastError || `the page kept leaving ${spec.label}`);
    }

    async function read() {
      const t0 = Date.now();
      const tried = [];
      const open = await chrome.tabs.query({ url: spec.site + "*" });
      say(t0, `${open.length} ${spec.label} tab(s) open${open[0] ? `: ${String(open[0].url || "").slice(0, 70)} (${open[0].status}${open[0].discarded ? ", discarded" : ""})` : ""}`);
      const announce = (out) => { say(t0, out.error ? `answer: error — ${out.error}` : `answer: ${(out.assignments || []).length} assignment(s)`); return out; };
      if (open[0]) {
        // The student's own tab, signed in. Frozen after a while in the
        // background, so a short first try, then a reload to thaw it (the
        // session survives a reload; a fresh tab would have to go through the
        // sign-in round trip).
        try {
          let out = await runReaderIn(open[0].id, t0, 20000);
          // A tab that has sat in the background can hold an expired session;
          // the page renews it only when it runs. Reload once and ask again
          // before calling that "not signed in".
          if (out && String(out.error || "").startsWith("not signed in")) {
            say(t0, "the open tab's session looks stale; reloading it and asking again");
            await chrome.tabs.reload(open[0].id);
            await waitForLoad(open[0].id, 20000);
            out = await readInTab(open[0].id, t0);
          }
          if (out) return announce(out);
          tried.push("open tab: no result");
        } catch (err) {
          tried.push(`open tab: ${err && err.message ? err.message : err}`);
          say(t0, `the open tab did not answer (${err && err.message ? err.message : err}); reloading it to thaw it`);
          try {
            await chrome.tabs.reload(open[0].id);
            await waitForLoad(open[0].id, 20000);
            const out = await readInTab(open[0].id, t0);
            if (out) return announce(out);
            tried.push("reloaded tab: no result");
          } catch (err2) {
            tried.push(`reloaded tab: ${err2 && err2.message ? err2.message : err2}`);
          }
        }
      } else {
        // No tab of his own is open: nothing is opened for him any more
        // ([ASKED] 2026-10-07, "stop opening" these sites). What background.js
        // read the last time he opened the site is handed over instead, once.
        try {
          const held = (await chrome.storage.local.get("siteRead")).siteRead || {};
          const visit = held[spec.key];
          if (visit && visit.payload && !visit.handed) {
            await chrome.storage.local.set({ siteRead: { ...held, [spec.key]: { ...visit, handed: Date.now() } } });
            say(t0, "no tab open — handing over what was read on his last visit");
            return announce(visit.payload);
          }
        } catch (e) { /* nothing held */ }
        say(t0, "no tab open — nothing new; it is read each time he opens the site");
        return null;
      }
      return empty(`the ${spec.label} page did not answer (${tried.join(" | ")})`);
    }

    // The whole read, bounded, and handed to Python as its own message kind.
    // One site failing is one banner; the refresh runs regardless.
    async function pull() {
      let payload;
      try {
        payload = await Promise.race([
          read(),
          sleep(120000).then(() => empty(`${spec.label} did not answer within 120 seconds`)),
        ]);
      } catch (err) {
        payload = empty(String((err && err.message) || err));
      }
      if (payload === null) return;   // nothing new: the last hand-off stands
      // Remembered for the automatic read on open: a site that answered "not
      // signed in" is not opened in a background tab again until a read
      // succeeds or the student presses Refresh (prosecution round 3, #4 — a
      // fresh install opened albert.io and AP Classroom on every open, for
      // students with no account there).
      try {
        const err = String(payload && payload.error || "");
        const state = err.startsWith("not signed in") ? "signed-out" : (err ? "" : "ok");
        if (state) {
          const { siteState = {} } = await chrome.storage.local.get("siteState");
          await chrome.storage.local.set({ siteState: { ...siteState, [spec.key]: state } });
        }
      } catch (e) { /* only a memory; the read itself is done */ }
      /* The reading was done by THIS tab (only a page can talk to a content
         script), but Python lives in the owner tab. */
      if (role === "owner") toWorker({ type: spec.key, payload });
      else CHAN.postMessage({ t: "handoff", from: CLIENT, key: spec.key, payload });
    }

    return { key: spec.key, source: spec.source, pull };
  }

  const READERS = SITES.map(makeSiteReader);

  // Which sites are switched on, from Python's own config. Asked once per
  // page and cached: reading a site costs a background tab and a sign-in
  // round trip on EVERY refresh, so a student with no Albert.io account
  // should not pay for one — and switching `sources.albert` off in config
  // ought to actually stop it, not merely make Python ignore the result.
  //
  // A failure here means ON. Losing a source because a status call hiccuped
  // is worse than one wasted tab, and the reader's own answer ("not signed
  // in", with a button) is honest either way.
  let sourcesPromise = null;
  /* Flipping a connector off has to stop its site being opened on the NEXT
     refresh, not the next reload. [ASKED] 2026-09-20. The answer is cached
     because it is asked before every pull; it is dropped whenever anything
     is written, which is exactly when a switch could have changed. */
  window.addEventListener("sd-changed", (ev) => {
    const path = (ev.detail || {}).path || "";
    if (path.startsWith("/api/sources") || path.startsWith("/api/prefs")) sourcesPromise = null;
  });
  function enabledSources() {
    if (!sourcesPromise) {
      sourcesPromise = sdFetch("/api/health")
        .then((res) => res.json())
        .then((body) => (body && body.sources) || {})
        .catch(() => ({}));
    }
    return sourcesPromise;
  }

  // Every enabled site is read before the refresh, and in parallel: they are
  // independent tabs and doing them in turn would add one sign-in round trip
  // per site to every pull. `allSettled`, because one site being signed out
  // must not stop the other from being read — or the refresh from running.
  async function refreshWithSites(url, init, automatic = false) {
    await readyPromise;
    try {
      const sources = await enabledSources();
      let skip = {}, links = {};
      try {
        const held = await chrome.storage.local.get(["siteState", "siteLinks"]);
        skip = held.siteState || {};
        links = held.siteLinks || {};
      } catch (e) { /* read none: a site is read only once it is linked */ }
      // Linked, or read successfully before linking existed (so a working
      // setup keeps working). [ASKED] 2026-10-07.
      const linked = (key) => links[key] === true || (links[key] === undefined && skip[key] === "ok");
      const wanted = READERS.filter((r) => sources[r.source] !== false && linked(r.key)
        && !(automatic && skip[r.key] === "signed-out"));
      // An unlinked site says so to Python, which then shows nothing for it —
      // not an old "signed out" banner with a button that opens its sign-in.
      for (const r of READERS) {
        if (sources[r.source] === false || linked(r.key)) continue;
        const payload = { error: "not linked", assignments: [], read_at: stamp() };
        if (role === "owner") toWorker({ type: r.key, payload });
        else CHAN.postMessage({ t: "handoff", from: CLIENT, key: r.key, payload });
      }
      await Promise.allSettled(wanted.map((r) => r.pull()));
    } catch (e) { /* the refresh runs regardless */ }
    return sdFetch(url, init);
  }

  const realFetch = window.fetch.bind(window);
  window.fetch = (input, init) => {
    const url = typeof input === "string" ? input : (input && input.url) || "";
    const method = ((init && init.method) || (input && input.method) || "GET").toUpperCase();
    if (url === "/api/login" && method === "POST") return signIn(url, init);
    if (url === "/api/refresh" && method === "POST") return refreshWithSites(url, init);
    if (url.startsWith("/api/")) return sdFetch(url, init || (input instanceof Request ? { method: input.method, headers: input.headers } : {}));
    return realFetch(input, init);
  };

  // Settings the extension keeps for itself (Options page → chrome.storage)
  // are handed to Python at boot and whenever they change: the class schedule
  // feed URL (which the Mac app captured from Veracross traffic and the
  // extension cannot) and the student's own Anthropic API key. Both go
  // straight to the worker; neither is logged or shown unredacted.
  const SETTING_KEYS = ["classFeedUrl", "anthropicApiKey"];
  function pushSettings() {
    try {
      chrome.storage.local.get(SETTING_KEYS, (items) => {
        const settings = {};
        for (const k of SETTING_KEYS) settings[k] = (items && items[k]) || "";
        toWorker({ type: "settings", settings });
      });
    } catch (e) { /* not an extension page (e.g. opened as a file): nothing to push */ }
  }
  pushSettings();
  try { chrome.storage.onChanged.addListener((changes, area) => { if (area === "local" && SETTING_KEYS.some((k) => k in changes)) pushSettings(); }); } catch (e) { /* same */ }

  // ---- Focus -------------------------------------------------------------
  // The gate runs on youtube.com, where there is no Python: the dashboard tab
  // is very often closed. So Python's whole answer — the mode, the site list
  // and what is actually due — is MIRRORED into chrome.storage.local, where
  // the service worker can read it in one go (focus-worker.js decides from
  // exactly this object). Written after boot and after anything that could
  // change it: a preference, a refresh, a tick.
  //
  // Only the owner tab writes it. Every tab could, and then four tabs would
  // write the same object four times on every tick.
  let focusTimer = null;
  async function mirrorFocus() {
    if (role !== "owner") return;
    try {
      const res = await sdFetch("/api/focus");
      if (!res.ok) return;
      const body = await res.json();
      if (!body || !body.focus) return;
      await chrome.storage.local.set({ focus: body.focus });
    } catch (e) { /* the board still works; Focus keeps its last answer */ }
  }
  const mirrorFocusSoon = (ms = 1200) => { clearTimeout(focusTimer); focusTimer = setTimeout(mirrorFocus, ms); };
  /* ---- reading everything when the dashboard opens -----------------------
   *
   * [ASKED] 2026-09-24: *"I want it to always work and always update and read
   * every thing every time I open the chrome extention"*.
   *
   * Until now a refresh happened only when someone pressed Refresh. Opening
   * the dashboard showed whatever was last written, however old — and for
   * mail that is worse than for anything else, because the Gmail hand-off
   * goes stale after six hours and then the page's only content is a sentence
   * explaining that it is stale. [MEASURED] 2026-09-24: twenty hours old, and
   * the advice it gave was for a different build.
   *
   * So opening the dashboard reads everything, through the same path the
   * button uses — `refreshWithSites`, so mail and every other connector are
   * read the same way rather than mail getting a special case.
   *
   * Two guards, and neither is a compromise on "every time":
   *
   *   * **Only the owner tab.** Four tabs open on four screens is four views
   *     of one Python; it must not be four refreshes.
   *   * **Not twice inside OPEN_GUARD_MS.** Closing and reopening a tab twice
   *     in ten seconds is one opening, and a refresh opens background tabs at
   *     other sites — doing that twice is visible and rude. Anything older
   *     than the guard reads again, which is what "every time" means in
   *     practice.
   */
  const OPEN_GUARD_MS = 90 * 1000;

  async function readEverythingOnOpen() {
    if (role !== "owner") return;
    try {
      const held = await chrome.storage.local.get(["lastOpenRefresh"]);
      if (Date.now() - (held.lastOpenRefresh || 0) < OPEN_GUARD_MS) return;
      await chrome.storage.local.set({ lastOpenRefresh: Date.now() });
    } catch (e) { /* no storage: read anyway, which is the safe direction */ }
    try {
      await refreshWithSites("/api/refresh", { method: "POST" }, true);
      window.dispatchEvent(new CustomEvent("sd-changed"));
    } catch (e) { /* the board still shows what it had */ }
  }

  /* ---- and keeping itself current -----------------------------------------
   *
   * An unpacked extension is read from disk when Chrome loads it and not
   * again, so rebuilding the folder changes nothing until somebody presses
   * Reload on `chrome://extensions` — a page whose controls sit in a shadow
   * DOM that no automation here can reach. [MEASURED] 2026-09-23/24: that one
   * button was the whole distance between a build and a working build, twice,
   * across two days.
   *
   * **This page is loaded from disk every time it is opened**, and `app.zip`
   * inside it carries the Python's own VERSION. When the two disagree, the
   * folder has been rebuilt under a Chrome still running the old copy, and
   * `chrome.runtime.reload()` re-reads it exactly as the button would.
   *
   * Nothing is downloaded. Compared for inequality, so a rebuild at an older
   * version brings the extension back with it.
   */
  async function updateIfTheFolderHasMovedOn() {
    let manifest;
    try { manifest = chrome.runtime.getManifest(); } catch (e) { return false; }
    let app = "";
    try {
      const res = await sdFetch("/api/health");
      if (res.ok) app = ((await res.json()) || {}).version || "";
    } catch (e) { return false; }
    if (!app || app === manifest.version) return false;
    // At most once per version pair. [MEASURED] 2026-10-07 (prosecution
    // round 3): a folder whose manifest and app.zip disagree stays that way
    // after a reload, so EVERY open reloaded and closed the tab — and once
    // Chrome throttled reload(), refresh-on-open and the Focus mirror were
    // skipped on every open, silently.
    const pair = `${manifest.version}->${app}`;
    try {
      const held = await chrome.storage.session.get("reloadedFor");
      if (held.reloadedFor === pair) {
        console.log(`[sillybus] folder is ${app}, this copy is ${manifest.version} — already reloaded once; carrying on`);
        return false;
      }
      await chrome.storage.session.set({ reloadedFor: pair });
    } catch (e) { return false; }
    console.log(`[sillybus] folder is ${app}, this copy is ${manifest.version} — reloading`);
    chrome.runtime.reload();
    return true;
  }

  readyPromise.then(async () => {
    if (await updateIfTheFolderHasMovedOn()) return;   /* about to be torn down */
    mirrorFocusSoon(400);
    readEverythingOnOpen();
  });
  window.addEventListener("sd-changed", () => mirrorFocusSoon());

  // What Settings -> Focus may ask of Chrome. The permission request has to
  // happen here rather than in the worker, because Chrome only grants one
  // from a user gesture in a page of ours — and the dashboard is that page.
  const toSW = (message) => new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage(message, (reply) => { void chrome.runtime.lastError; resolve(reply || {}); });
    } catch (e) { resolve({}); }
  });
  /* A number on the toolbar icon: how many heads-ups the board has that
     nobody has dismissed (app.js counts them; the page owns the dismissals).
     No permission is needed for a badge, and a badge is the quietest
     notification Chrome has — which is the right loudness for "one date
     moved". Cleared with an empty string, never left over. */
  window.sdChrome.badge = (count) => {
    try {
      chrome.action.setBadgeText({ text: count ? String(count) : "" });
      if (count) chrome.action.setBadgeBackgroundColor({ color: "#d2691e" });
    } catch (e) { /* no action API here */ }
  };
  window.sdChrome.focus = {
    status: () => toSW({ type: "focus-status" }),
    setPin: (pin, current) => toSW({ type: "focus-set-pin", pin, current }),
    clearPin: (current) => toSW({ type: "focus-clear-pin", current }),
    verifyPin: (pin) => toSW({ type: "focus-verify-pin", pin }),
    sync: () => toSW({ type: "focus-sync" }),
    mirror: mirrorFocus,
    // Asked for the student's OWN sites and nothing else. The manifest's
    // wildcard is only what may be ASKED for; what is granted is the list on
    // the Focus page, one origin per site.
    async request(origins) {
      if (!origins || !origins.length) return true;
      try { return await chrome.permissions.request({ origins }); } catch (e) { return false; }
    },
    async drop(origins) {
      if (!origins || !origins.length) return true;
      try { return await chrome.permissions.remove({ origins }); } catch (e) { return false; }
    },
  };

  // ---- AP Classroom and Albert.io: linked, never opened for him -----------
  // [ASKED] 2026-10-07. Link opens the site in a tab he can see (it is his
  // click) and marks it pending; background.js reads it as it loads — after
  // his sign-in, if he has to sign in — and from then on each time he opens
  // it. The dashboard hands each new read to Python, and the first one is
  // followed by a refresh so the work appears straight away.
  const SITE_HOME = { googleclassroom: "https://classroom.google.com/", apclassroom: "https://apclassroom.collegeboard.org/subjects/preview",
                      albert: "https://www.albert.io/dashboard" };
  // A site read successfully before linking existed is linked for good
  // (round 6: one later signed-out read made it "not linked", and the next
  // refresh replaced his AP Classroom work with nothing and no banner).
  (async () => {
    try {
      const held = await chrome.storage.local.get(["siteLinks", "siteState"]);
      const links = { ...(held.siteLinks || {}) };
      let changed = false;
      for (const key of Object.keys(SITE_HOME)) {
        if (links[key] === undefined && (held.siteState || {})[key] === "ok") { links[key] = true; changed = true; }
      }
      if (changed) await chrome.storage.local.set({ siteLinks: links });
    } catch (e) { /* not an extension page */ }
  })();
  window.sdChrome.sites = {
    async status() {
      try {
        const held = await chrome.storage.local.get(["siteLinks", "siteState", "siteRead", "pendingSiteLink"]);
        const out = {};
        for (const key of Object.keys(SITE_HOME)) {
          const state = (held.siteState || {})[key] || "";
          const links = held.siteLinks || {};
          out[key] = { linked: links[key] === true || (links[key] === undefined && state === "ok"),
                       state, readAt: ((held.siteRead || {})[key] || {}).at || 0,
                       pending: !!(held.pendingSiteLink && held.pendingSiteLink.key === key) };
        }
        return out;
      } catch (e) { return {}; }
    },
    // Called straight from the click: the tab opens inside the gesture.
    link(key) {
      if (!SITE_HOME[key]) return;
      chrome.storage.local.set({ pendingSiteLink: { key, at: Date.now() } });
      chrome.tabs.create({ url: SITE_HOME[key], active: true });
    },
    async unlink(key) {
      const held = await chrome.storage.local.get(["siteLinks", "siteRead"]);
      const siteRead = { ...(held.siteRead || {}) };
      delete siteRead[key];
      await chrome.storage.local.set({ siteLinks: { ...(held.siteLinks || {}), [key]: false }, siteRead });
    },
  };
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !changes.siteRead || role !== "owner") return;
      const now = changes.siteRead.newValue || {};
      const before = changes.siteRead.oldValue || {};
      for (const key of Object.keys(SITE_HOME)) {
        const visit = now[key];
        if (!visit || visit.handed || (before[key] && before[key].at === visit.at)) continue;
        const label = key === "googleclassroom" ? "Google Classroom" : key === "albert" ? "Albert.io" : "AP Classroom";
        // Re-read before writing: a snapshot from this event could erase a
        // read background.js stored in between (round 6).
        chrome.storage.local.get("siteRead").then(({ siteRead = {} }) => {
          const cur = siteRead[key];
          if (cur && cur.at === visit.at) chrome.storage.local.set({ siteRead: { ...siteRead, [key]: { ...cur, handed: Date.now() } } });
        }).catch(() => {});
        toWorker({ type: key, payload: visit.payload });
        if (visit.linking) {
          linkToast(`${label} is linked — reading it now.`, true);
          sdFetch("/api/refresh", { method: "POST" })
            .then(() => window.dispatchEvent(new CustomEvent("sd-changed")))
            .catch(() => {});
        }
        window.dispatchEvent(new CustomEvent("sd-sites"));
      }
    });
  } catch (e) { /* not an extension page */ }

  // ---- "Link this page", from the toolbar pop-down ------------------------
  // popup.js found a calendar on the page he was on and left it in
  // chrome.storage.local as `pendingLink`. Saved here through the SAME route
  // a pasted address takes (POST /api/connections: checked, fetched once,
  // refused if it is not a calendar), then its events are read straight onto
  // the board and the calendar opens. One tab takes it: the lock means two
  // open dashboards cannot both add it. A link older than ten minutes is
  // dropped rather than acted on — it was not this visit's click.
  // [ASKED] 2026-10-06, see popup.js.
  function linkToast(text, ok) {
    let box = document.getElementById("sd-link-toast");
    if (!box) {
      box = document.createElement("div");
      box.id = "sd-link-toast";
      box.setAttribute("role", "status");
      box.style.cssText = "position:fixed;z-index:9999;left:50%;bottom:96px;transform:translateX(-50%);"
        + "max-width:min(560px,90vw);padding:12px 18px;border-radius:12px;font:14px/1.45 -apple-system,system-ui,sans-serif;"
        + "box-shadow:0 10px 30px rgba(0,0,0,.25);color:#fff;";
      document.body.appendChild(box);
    }
    box.style.background = ok ? "#1E7A4F" : "#9B2C24";
    box.textContent = text;
    clearTimeout(linkToast.t);
    linkToast.t = setTimeout(() => box.remove(), 9000);
  }
  // Saves one calendar address and says how it went. Both ways in use it —
  // the pop-down's pendingLink below and the calendar page's Link TeamSnap
  // button (linkTeamSnap) — so a link is never saved two different ways.
  // Returns true when the calendar is linked (or already was).
  async function postLink(link) {
    const name = link.name || "";
    await readyPromise;
    linkToast(`Linking ${name || "your calendar"}…`, true);
    try {
      const res = await window.fetch("/api/connections", { method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: link.url, name }) });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) {
        const err = out.error || {};
        if (err.code === "already_connected") {
          linkToast(`${name || "That calendar"} is already linked — it is on your calendar.`, true);
        } else if (err.code === "signed_out") {
          // Kept, not thrown away: signed out, the link waits and finishes
          // the moment he signs in. [MEASURED] 2026-10-07 in his recording:
          // "Could not link it: sign in…", he signed in, and TeamSnap was
          // never linked because the link was already gone.
          // A list, not one slot: two Google accounts linked while signed
          // out are both kept (round 7). One entry per address.
          try {
            const { heldLinks = [] } = await chrome.storage.local.get("heldLinks");
            const rest = heldLinks.filter((h) => h.url !== link.url);
            await chrome.storage.local.set({ heldLinks: [...rest, { ...link, at: Date.now() }] });
          } catch (e) { /* only a convenience */ }
          linkToast(`Sign in to SillyBus above — ${name || "your calendar"} links itself as soon as you do.`, true);
          finishHeldLinkSoon();
          return false;
        } else {
          linkToast(`Could not link it: ${err.message || "that page did not give a calendar"}`
            + (err.fix ? ` — ${err.fix}` : ""), false);
          return false;
        }
      } else {
        const n = Number(out.events_on_board) || 0;
        linkToast(`Linked ${name || "your calendar"} — ${n} event${n === 1 ? "" : "s"} now on your calendar.`, true);
      }
      if (!link.macLinked) {
        const { macCalendarToken } = await chrome.storage.local.get("macCalendarToken");
        if (macCalendarToken) {
          try {
            const mac = await chrome.runtime.sendMessage({ type: "mac-calendar-link", url: link.url, name });
            if (!mac || !mac.ok) throw new Error(mac && mac.message || "Open the Mac app, then link again.");
            linkToast(`Linked ${name || "your calendar"} in Chrome and the Mac app.`, true);
          } catch (err) {
            linkToast(`Saved in Chrome. The Mac app could not update: ${err.message || "open it and link again"}`, false);
          }
        }
      }
      if (window.loadState) await window.loadState();
      if (window.showView) window.showView("calendar");
      return true;
    } catch (e) {
      linkToast(`Could not link it: ${e && e.message ? e.message : e}`, false);
      return false;
    }
  }
  // A link held while signed out: finished once a session exists (checked
  // every few seconds for up to half an hour), dropped after a day.
  // One check at a time (round 7: overlapping checks on a slow /api/session
  // posted the same link a dozen times), only in the owner tab, and the list
  // is taken inside the same lock the pop-down's links use.
  let heldTimer = null;
  let heldBusy = false;
  function finishHeldLinkSoon() {
    clearTimeout(heldTimer);
    let tries = 0;
    const tick = async () => {
      if (++tries > 600) return;
      if (heldBusy || role !== "owner") { heldTimer = setTimeout(tick, 3000); return; }
      heldBusy = true;
      try {
        let held = [];
        try { held = (await chrome.storage.local.get("heldLinks")).heldLinks || []; } catch (e) { held = []; }
        held = held.filter((h) => Date.now() - (h.at || 0) < 24 * 3600 * 1000);
        if (!held.length) { chrome.storage.local.remove("heldLinks"); return; }
        let session;
        try { session = await (await window.fetch("/api/session")).json(); } catch (e) { session = null; }
        if (!session || !session.signed_in) { heldTimer = setTimeout(tick, 3000); return; }
        const run = async () => {
          const now = ((await chrome.storage.local.get("heldLinks")).heldLinks || []);
          await chrome.storage.local.remove("heldLinks");
          for (const h of now) {
            if (await postLink({ url: h.url, name: h.name, macLinked: h.macLinked }) === false) {
              const { heldLinks = [] } = await chrome.storage.local.get("heldLinks");
              await chrome.storage.local.set({heldLinks: [...heldLinks.filter(x => x.url !== h.url), h]});
              heldTimer = setTimeout(tick, 3000);
            }
          }
        };
        if (navigator.locks && navigator.locks.request) await navigator.locks.request("sillybus-link", run);
        else await run();
      } finally {
        heldBusy = false;
      }
    };
    heldTimer = setTimeout(tick, 3000);
  }
  readyPromise.then(() => finishHeldLinkSoon());

  /* The pop-down's other two answers ([ASKED] 2026-10-06, "make it ask what
     type of info it is supost to find"). Each goes where the app already
     keeps that thing, through the route the Classes page uses:
       homework — a teacher's Google Doc becomes the class's homework doc and
                  a Canvas class page its Canvas address (PUT /api/courses,
                  `connectors`), read on every refresh from then on;
       link     — one of the class's materials (POST …/materials). */
  async function savePageFor(pending) {
    await readyPromise;
    const cls = pending.className || "that class";
    const key = encodeURIComponent(pending.course || "");
    try {
      let res;
      if (pending.kind === "event") {
        // One event from the page — his day and time, the page as where.
        res = await window.fetch("/api/events", { method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title: pending.title, date: pending.day, start: pending.time || null }) });
        const out = await res.json().catch(() => ({}));
        if (!res.ok) { linkToast(`Could not add it: ${(out.error || {}).message || "it was refused"}`, false); return; }
        linkToast(`\u201c${pending.title}\u201d is on your calendar.`, true);
        if (window.loadState) await window.loadState();
        if (window.showView) window.showView("calendar");
        return;
      }
      if (pending.kind === "todo") {
        // A to-do with the page as its link (tasks.py reads the address out
        // of the notes and makes it the row's link).
        res = await window.fetch("/api/tasks", { method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title: pending.title, due_date: pending.day || null,
            course: pending.className || null, notes: `from ${pending.url}` }) });
        const out = await res.json().catch(() => ({}));
        if (!res.ok) { linkToast(`Could not add it: ${(out.error || {}).message || "it was refused"}`, false); return; }
        linkToast(`Added \u201c${pending.title}\u201d to your list.`, true);
        if (window.loadState) await window.loadState();
        return;
      }
      if (pending.kind === "homework") {
        const doc = /docs\.google\.com\/document\//i.test(pending.url);
        res = await window.fetch(`/api/courses/${key}`, { method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ connectors: doc ? { doc_url: pending.url } : { canvas_url: pending.url } }) });
      } else {
        res = await window.fetch(`/api/courses/${key}/materials`, { method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title: pending.title || "", url: pending.url }) });
      }
      const out = await res.json().catch(() => ({}));
      if (!res.ok) {
        const err = out.error || {};
        linkToast(`Could not save it: ${err.message || "that page was refused"}${err.fix ? ` — ${err.fix}` : ""}`, false);
        return;
      }
      linkToast(pending.kind === "homework"
        ? `${cls} will read its homework from that page — press Refresh to pull it now.`
        : `Saved to ${cls}'s links.`, true);
      if (window.loadState) await window.loadState();
    } catch (e) {
      linkToast(`Could not save it: ${e && e.message ? e.message : e}`, false);
    }
  }

  /* His classes, for the pop-down's "Which class?" — it cannot ask Python
     itself. Names and keys only, refreshed whenever the board changes. */
  async function shareClassList() {
    try {
      await readyPromise;
      const out = await (await window.fetch("/api/courses")).json();
      const list = (out.courses || []).filter((c) => c.current !== false)
        .map((c) => ({ key: c.course_key, name: c.display_name || c.course_raw || c.course_key }))
        .filter((c) => c.key);
      await chrome.storage.local.set({ sbClasses: list });
    } catch (e) { /* the pop-down says to open SillyBus once */ }
  }
  shareClassList();
  window.addEventListener("sd-changed", () => { clearTimeout(shareClassList.t); shareClassList.t = setTimeout(shareClassList, 3000); });

  async function takePendingLink() {
    const run = async () => {
      let pending;
      try { pending = (await chrome.storage.local.get("pendingLink")).pendingLink; } catch (e) { return; }
      if (!pending) return;
      await chrome.storage.local.remove("pendingLink");
      if (!pending.url || Date.now() - (pending.at || 0) > 10 * 60 * 1000) return;
      if (pending.kind === "homework" || pending.kind === "link"
          || pending.kind === "event" || pending.kind === "todo") await savePageFor(pending);
      else if (await postLink({ url: pending.url, name: pending.name, macLinked: pending.macLinked }) === false) {
        const { heldLinks = [] } = await chrome.storage.local.get("heldLinks");
        await chrome.storage.local.set({heldLinks: [...heldLinks.filter(x => x.url !== pending.url), pending]});
        finishHeldLinkSoon();
      }
    };
    if (navigator.locks && navigator.locks.request) await navigator.locks.request("sillybus-link", run);
    else await run();
  }

  // ---- "Link TeamSnap", from the calendar page itself ----------------------
  // [ASKED] 2026-10-06: "make at least one for the ability to link in the app
  // right here" — the pop-down needs him to be ON a TeamSnap tab first; this
  // is one button on the SillyBus calendar, and nothing else to find.
  //
  // It can be one click only because this page is the extension: with
  // go.teamsnap.com granted, its fetch carries the TeamSnap session Chrome
  // already has and is not stopped by CORS. [MEASURED] 2026-10-06 on his
  // account: go.teamsnap.com/team/export_schedule answers 200 with three
  // webcal://ical-cdn.teamsnap.com/… links when signed in (the one without
  // /filter/ is "All games and events"), and sends a signed-out visitor to a
  // /login/ page. ical-cdn sends no CORS header, so the feed's host is asked
  // for at the same moment — Python reads the feed through this page.
  //
  // The permission request MUST be the first thing this does: Chrome only
  // shows the prompt during the click that asked for it, and any await in
  // front of it (even a storage read) spends the click and the prompt never
  // appears. app.js calls this straight from its click handler for the same
  // reason. The address is a password in disguise: it goes from TeamSnap's
  // page to POST /api/connections and nowhere else — never logged, shown,
  // or put in a URL.
  const TEAMSNAP_ORIGINS = ["https://go.teamsnap.com/*", "https://ical-cdn.teamsnap.com/*"];
  const TEAMSNAP_EXPORT = "https://go.teamsnap.com/team/export_schedule";
  function teamsnapFeedIn(html) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const found = [];
    const take = (raw) => {
      let u = String(raw || "").trim();
      if (!/ical-cdn\.teamsnap\.com\//i.test(u)) return;
      u = u.replace(/^webcal:\/\//i, "https://").replace(/^http:\/\//i, "https://");
      if (/^https:\/\//i.test(u) && !found.includes(u)) found.push(u);
    };
    for (const a of doc.querySelectorAll("a[href]")) take(a.getAttribute("href"));
    for (const el of doc.querySelectorAll("input[value], textarea, [data-clipboard-text]")) {
      take(el.getAttribute("data-clipboard-text") || el.getAttribute("value") || el.textContent);
    }
    // "All games and events" is the one without /filter/; the others
    // (/filter/attending/, /filter/games/) would hide practices from him.
    return found.find((u) => !/\/filter\//i.test(u)) || found[0] || "";
  }
  function teamsnapSignedOut(res) {
    return !!res && (res.type === "opaqueredirect" || res.status === 401 || res.status === 403
      || /\/login\b|sign_?in/i.test(res.url || ""));
  }
  // When the quiet read finds nothing — a cookie Chrome would not send from
  // here, a TeamSnap that renders the links itself — read the export page in
  // a tab instead, where he is signed in exactly as he is anywhere in Chrome.
  // He pressed Link, so a tab he can see is expected. [ASKED] 2026-10-07:
  // "make it work with the extention" (linking TeamSnap did not work).
  async function teamsnapFeedFromTab() {
    let tab = null;
    try {
      tab = await chrome.tabs.create({ url: TEAMSNAP_EXPORT, active: true });
      // Up to ten minutes: signing in takes as long as it takes (round 7 —
      // thirty seconds closed the tab under him). Signed in but landed on a
      // team page, he is sent back to the export page.
      let steered = 0;
      for (let i = 0; i < 800; i++) {
        await new Promise((r) => setTimeout(r, 750));
        const now = await chrome.tabs.get(tab.id).catch(() => null);
        if (!now) return { closed: true };
        const where = now.url || "";
        if (!where || /\/login\b|sign_?in|auth\./i.test(where)) continue;   // he is signing in
        if (now.status !== "complete") continue;
        if (!/go\.teamsnap\.com\/team\/export_schedule/.test(where)) {
          if (/go\.teamsnap\.com\//.test(where) && steered < 3) {
            steered += 1;
            await chrome.tabs.update(tab.id, { url: TEAMSNAP_EXPORT }).catch(() => {});
          }
          continue;
        }
        const [hit] = await chrome.scripting.executeScript({ target: { tabId: tab.id },
          func: () => [...document.querySelectorAll("a[href], input[value], textarea, [data-clipboard-text]")]
            .map((el) => el.getAttribute("href") || el.getAttribute("data-clipboard-text") || el.getAttribute("value") || el.textContent || "")
            .filter((v) => /ical-cdn\.teamsnap\.com\//i.test(v)) });
        const links = (hit && hit.result) || [];
        if (links.length) {
          const html = links.map((u) => `<a href="${u.replace(/"/g, "")}"></a>`).join("");
          const feed = teamsnapFeedIn(html);
          if (feed.length) { chrome.tabs.remove(tab.id).catch(() => {}); tab = null; }
          return { feed };
        }
      }
      return { feed: "" };
    } catch (e) {
      return { feed: "" };
    }
    // Not closed on failure: his TeamSnap tab stays where he can see it.
  }
  window.sdChrome.linkTeamSnap = async () => {
    let allowed = false;
    try { allowed = await chrome.permissions.request({ origins: TEAMSNAP_ORIGINS }); } catch (e) { allowed = false; }
    if (!allowed) {
      linkToast("SillyBus needs Chrome's OK to read your TeamSnap schedule. Press Link TeamSnap again and choose Allow.", false);
      return false;
    }
    linkToast("Looking for your TeamSnap schedule…", true);
    let res = null;
    try {
      res = await realFetch(TEAMSNAP_EXPORT, { credentials: "include" });
    } catch (e) {
      // A signed-out visit is redirected to a login page, possibly on a host
      // this was not granted — and that fails as a network error. Ask again
      // without following, to tell "signed out" from "offline".
      try { res = await realFetch(TEAMSNAP_EXPORT, { credentials: "include", redirect: "manual" }); }
      catch (e2) { res = null; }
      if (!res || !teamsnapSignedOut(res)) {
        linkToast("Could not reach TeamSnap. Check the internet connection, then press Link TeamSnap again.", false);
        return false;
      }
    }
    let feed = "";
    if (res && res.ok && !teamsnapSignedOut(res)) {
      try { feed = teamsnapFeedIn(await res.text()); } catch (e) { feed = ""; }
    }
    if (!feed) {
      linkToast("Opening TeamSnap — sign in there if it asks; SillyBus reads your schedule link and closes the tab.", true);
      const viaTab = await teamsnapFeedFromTab();
      if (viaTab.closed) {
        linkToast("The TeamSnap tab was closed before your schedule was found. Press Link TeamSnap again.", false);
        return false;
      }
      feed = viaTab.feed || "";
    }
    if (!feed) {
      linkToast("TeamSnap did not show a schedule link. Open TeamSnap → Schedule → Go to My Full Schedule → Subscribe/Export once, then press Link TeamSnap again.", false);
      return false;
    }
    return postLink({ url: feed, name: "TeamSnap" });
  };
  // ---- "Link Google Calendar", from the calendar page ---------------------
  // [ASKED] 2026-10-06: "by pass this for every one" (the eye-icon step on
  // Google Calendar's settings page). The calendar's own Export is read with
  // the Google sign-in Chrome already has, so the only step left is Chrome's
  // OK for calendar.google.com — asked FIRST, while the click still counts.
  // Saved through postLink like any calendar; Python's reader
  // (calendars._fetch_google_export) unzips it on every refresh.
  window.sdChrome.linkGoogleCalendar = async () => {
    let allowed = false;
    try { allowed = await chrome.permissions.request({ origins: ["https://calendar.google.com/*"] }); }
    catch (e) { allowed = false; }
    if (!allowed) {
      linkToast("SillyBus needs Chrome's OK to read your Google Calendar. Press Link Google Calendar again and choose Allow.", false);
      return false;
    }
    // Every Google account signed in to Chrome, not only the first ([ASKED]
    // 2026-10-07: "a way to a mutipul google calender accounts I have 2").
    // Chrome numbers them /u/0/, /u/1/…; an account that isn't signed in
    // answers 403 instead of a zip. The ones already linked are skipped, so
    // pressing the button again after adding an account in Chrome links it.
    const linked = new Set();
    try {
      const have = await (await window.fetch("/api/connections")).json();
      for (const c of (have.connections || [])) {
        const m = /calendar\.google\.com\/calendar\/(?:u\/(\d)\/)?exporticalzip/i.exec(c.url || c.display || "");
        if (m) linked.add(Number(m[1] || 0));
      }
    } catch (e) { /* link what answers; duplicates are refused by the server */ }
    const accounts = [];
    for (let n = 0; n < 5; n++) {
      try {
        const res = await realFetch(`https://calendar.google.com/calendar/u/${n}/exporticalzip`, { credentials: "include" });
        const head = new Uint8Array(await res.arrayBuffer()).slice(0, 2);
        // A school account can forbid export while a later personal account works.
        if (!(res.ok && head[0] === 0x50 && head[1] === 0x4b)) continue;   // "PK": a zip
        accounts.push(n);
      } catch (e) { continue; }
    }
    if (!accounts.length) {
      linkToast("Sign in to Google Calendar in Chrome (calendar.google.com), then press 🔗 Google again.", false);
      return false;
    }
    let paired = false;
    try { paired = !!(await chrome.storage.local.get("macCalendarToken")).macCalendarToken; }
    catch (e) { /* the unpaired extension still links its own calendars */ }
    // Pairing after a calendar was linked in Chrome must still send it to the Mac.
    const todo = paired ? accounts : accounts.filter((n) => !linked.has(n));
    if (!todo.length) {
      linkToast(`All ${accounts.length} Google account${accounts.length === 1 ? "" : "s"} in this Chrome ${accounts.length === 1 ? "is" : "are"} already linked. To add another, sign in to it in Chrome, then press 🔗 Google again.`, true);
      return true;
    }
    let ok = true;
    for (const n of todo) {
      const url = n === 0 ? "https://calendar.google.com/calendar/exporticalzip"
                          : `https://calendar.google.com/calendar/u/${n}/exporticalzip`;
      const name = accounts.length > 1 ? `Google Calendar (account ${n + 1})` : "Google Calendar";
      ok = (await postLink({ url, name })) && ok;
    }
    return ok;
  };
  takePendingLink();
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.pendingLink && changes.pendingLink.newValue) takePendingLink();
    });
  } catch (e) { /* no storage events here */ }

  // Settings → "Connect Chrome" is the Mac app's card for pairing with the
  // bridge extension. This IS Chrome; there is nothing to connect. views.js
  // skips the card when its element is missing, so it is removed rather than
  // hidden. The Options link takes its place, since that is where the two
  // settings the extension owns (feed URL, API key) actually live.
  document.addEventListener("DOMContentLoaded", () => {
    const card = document.getElementById("settings-chrome");
    if (!card) return;
    card.innerHTML = `<h3>Extension options</h3>
      <p class="muted">Your Anthropic API key and class schedule feed are kept by the
        extension itself, in this Chrome profile.</p>
      <div class="row-actions"><button type="button" class="ghost" id="sd-open-options">Open options</button></div>`;
    card.querySelector("#sd-open-options").onclick = () => {
      try { chrome.runtime.openOptionsPage(); } catch (e) { window.open("options.html", "_blank", "noopener"); }
    };
  });

  // ---- EventSource → worker -----------------------------------------------
  // Python answers the whole event stream at once (the run has finished by the
  // time the page asks), so the polyfill replays it message by message.
  class SDEventSource {
    constructor(url) {
      this.onmessage = null; this.onerror = null; this.readyState = 0; this._closed = false;
      sdFetch(url).then(async (res) => {
        if (this._closed) return;
        this.readyState = 1;
        const text = await res.text();
        for (const block of text.split("\n\n")) {
          if (this._closed) return;
          const line = block.split("\n").find((l) => l.startsWith("data:"));
          if (line && this.onmessage) this.onmessage({ data: line.slice(5).trim() });
        }
      }).catch(() => { if (this.onerror && !this._closed) this.onerror(new Event("error")); });
    }
    close() { this._closed = true; this.readyState = 2; }
    addEventListener(type, fn) { if (type === "message") this.onmessage = fn; if (type === "error") this.onerror = fn; }
  }
  window.EventSource = SDEventSource;

  // ---- one real path, views in the hash -----------------------------------
  window.__sdPath = () => "/" + location.hash.replace(/^#\/?/, "");
  const toHash = (url) => (typeof url === "string" && url.startsWith("/") && !url.includes(".") ? "#" + url.slice(1) : url);
  const push = history.pushState.bind(history), replace = history.replaceState.bind(history);
  history.pushState = (state, title, url) => push(state, title, toHash(url));
  history.replaceState = (state, title, url) => replace(state, title, toHash(url));

  // ---- no service worker in an extension page -----------------------------
  if (navigator.serviceWorker) {
    const fake = { update() {}, unregister() { return Promise.resolve(true); }, addEventListener() {} };
    try { Object.defineProperty(navigator, "serviceWorker", { value: { register: () => Promise.resolve(fake), ready: Promise.resolve(fake), addEventListener() {}, getRegistrations: () => Promise.resolve([]) } }); }
    catch (e) { /* not configurable in some contexts; the failed register is harmless */ }
  }

  // Flush Python's files to IndexedDB when the tab goes away.
  addEventListener("pagehide", () => toWorker({ type: "sync" }));
})();
