// A dismissible reminder after each 2 minutes in active listed tabs.
(() => {
  if (window.__sillybusFocus || window.top !== window) return;
  window.__sillybusFocus = true;
  let card = null;
  let busy = false;
  let last = performance.now();
  let wasActive = document.visibilityState === "visible" && document.hasFocus();
  const active = () => document.visibilityState === "visible" && document.hasFocus();
  // Reset at focus/visibility boundaries: time in another tab/app is excluded.
  const reset = () => { last = performance.now(); wasActive = active(); };
  document.addEventListener("visibilitychange", reset);
  window.addEventListener("focus", reset);
  window.addEventListener("blur", reset);
  const ask = message => new Promise(resolve => {
    try {
      chrome.runtime.sendMessage(message, reply => {
        void chrome.runtime.lastError;
        resolve(reply);
      });
    } catch (_) { resolve(null); }
  });
  const CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif; }
    .wrap { position: fixed; inset: 0; z-index: 2147483647; display: grid; place-items: center;
            background: rgba(8, 15, 20, .82); backdrop-filter: blur(14px) saturate(.8); }
    .sheet { width: min(30rem, calc(100vw - 2.5rem)); padding: 1.9rem 1.8rem 1.6rem;
             border-radius: 1.1rem; background: #0f1a1f; color: #eaf3f2;
             border: 1px solid rgba(255,255,255,.09);
             box-shadow: 0 1.6rem 4rem rgba(0,0,0,.55);
             animation: rise .34s cubic-bezier(.2,.9,.3,1) both; }
    @keyframes rise { from { opacity: 0; transform: translateY(1.1rem) scale(.985); } }
    @keyframes slide { from { opacity: 0; transform: translateY(1.4rem); } }
    @media (prefers-reduced-motion: reduce) { .sheet, .toast { animation: none; } }
    .mark { display: flex; align-items: center; gap: .55rem; font-size: .78rem;
            letter-spacing: .09em; text-transform: uppercase; color: #5eead4; font-weight: 650; }
    .mark i { width: .5rem; height: .5rem; border-radius: 50%; background: #5eead4;
              box-shadow: 0 0 0 .28rem rgba(94,234,212,.16); font-style: normal; }
    h1 { margin: .9rem 0 .35rem; font-size: 1.42rem; line-height: 1.2; font-weight: 640; }
    h2 { margin: 0 0 .2rem; font-size: 1.02rem; line-height: 1.3; font-weight: 620; }
    p { margin: .35rem 0 0; font-size: .92rem; line-height: 1.5; color: #a9c0bf; }
    p.work { color: #eaf3f2; }
    .row { display: flex; flex-wrap: wrap; gap: .55rem; margin-top: 1.3rem; }
    button { font: inherit; font-size: .9rem; font-weight: 570; padding: .6rem 1rem;
             border-radius: .6rem; border: 1px solid transparent; cursor: pointer;
             transition: transform .12s ease, background .16s ease, border-color .16s ease; }
    button:active { transform: translateY(1px); }
    button.go { background: #14b8a6; color: #04201c; }
    button.go:hover { background: #2dd4bf; }
    button.ghost { background: transparent; color: #cfe3e1; border-color: rgba(255,255,255,.18); }
    button.ghost:hover { border-color: rgba(255,255,255,.34); background: rgba(255,255,255,.05); }
    button.link { background: none; border: 0; color: #7dd3c8; padding: .3rem 0; text-decoration: underline;
                  text-underline-offset: .18em; font-size: .85rem; }
    form { display: flex; gap: .5rem; margin-top: 1.2rem; align-items: center; }
    input { font: inherit; font-size: 1.15rem; letter-spacing: .42em; text-align: center;
            width: 7.6rem; padding: .55rem .5rem; border-radius: .6rem; color: #eaf3f2;
            background: rgba(255,255,255,.06); border: 1px solid rgba(255,255,255,.18); }
    input:focus { outline: 2px solid #14b8a6; outline-offset: 1px; }
    .err { margin-top: .6rem; font-size: .86rem; color: #fca5a5; }
    .fine { margin-top: 1.1rem; font-size: .78rem; line-height: 1.45; color: #6f8a89; }
    /* the reminder */
    .toast { position: fixed; right: 1.1rem; bottom: 1.1rem; z-index: 2147483647;
             width: min(23rem, calc(100vw - 2.2rem)); padding: 1.05rem 1.1rem 1rem;
             border-radius: .95rem; background: #0f1a1f; color: #eaf3f2;
             border: 1px solid rgba(255,255,255,.1);
             box-shadow: 0 1rem 2.6rem rgba(0,0,0,.45);
             animation: slide .38s cubic-bezier(.2,.9,.3,1) both; }
    .toast .row { margin-top: .95rem; }
    .toast button { padding: .48rem .8rem; font-size: .86rem; }
  `;


  function showCard(info) {
    if (card?.isConnected) card.remove();
    const host = document.createElement("div");
    host.setAttribute("data-sillybus-focus", "card");
    const root = host.attachShadow({mode: "closed"});
    const style = document.createElement("style");
    style.textContent = CSS;
    const box = document.createElement("div");
    box.className = "toast";
    box.setAttribute("role", "status");
    const heading = document.createElement("h2");
    heading.textContent = info.due.headline;
    const text = document.createElement("p");
    text.textContent = info.due.lead;
    const row = document.createElement("div");
    row.className = "row";
    const dismiss = document.createElement("button");
    dismiss.className = "ghost";
    dismiss.textContent = "Keep going";
    dismiss.onclick = () => host.remove();
    const board = document.createElement("button");
    board.className = "go";
    board.textContent = "Open SillyBus";
    board.onclick = () => { host.remove(); ask({type: "open-dashboard"}); };
    row.append(board, dismiss);
    box.append(heading, text, row);
    root.append(style, box);
    (document.body || document.documentElement).append(host);
    card = host;
    setTimeout(() => host.remove(), 20000);
  }
  setInterval(async () => {
    const now = performance.now();
    const isActive = active();
    const usageMs = wasActive && isActive && now - last <= 5000 ? now - last : 0;
    last = now;
    wasActive = isActive;
    if (busy || !usageMs) return;
    busy = true;
    try {
      const info = await ask({type: "focus-check", usageMs});
      if (info?.action === "remind" && active()) showCard(info);
    } finally { busy = false; }
  }, 2500);
})();
