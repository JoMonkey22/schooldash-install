// Focus — the card and the gate, drawn on a distracting site.
//
// This file is registered DYNAMICALLY (background.js) and only for the hosts
// the student put on their own list and Chrome actually granted. With Focus
// off nothing here is registered, so the code never runs and no permission is
// held; see focus.py for what the three modes mean.
//
// It decides nothing. Every decision — which mode, whether the board is
// clear, whether this host is unlocked, whether a reminder already showed —
// is made by the service worker, which is the only place that can see the
// PIN hash and the session's unlocks. This file asks, then draws.
//
// Two things it has to survive:
//
//   The page's own CSS and scripts. The overlay lives in a closed shadow root
//   on a fixed host element with the top z-index, so YouTube's stylesheet
//   cannot restyle it and YouTube's scripts cannot read the PIN field out of
//   the DOM.
//
//   Single-page navigation. youtube.com never reloads: home → a video is a
//   history change. So the check is re-run on URL change and on a timer,
//   which is also what brings the gate back when a bypass runs out.

(() => {
  if (window.__sillybusFocus) return;   // one instance per frame
  window.__sillybusFocus = true;
  if (window.top !== window) return;    // an embedded player is not a visit

  const TICK = 2500;                    // how often the URL is looked at
  const CHECK_EVERY = 60000;            // how often a quiet page asks anyway
  let gate = null;                      // the shadow host while it is up
  let card = null;
  let pausing = null;

  const ask = (message) =>
    new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(message, (reply) => {
          void chrome.runtime.lastError;   // the worker restarting is not an error
          resolve(reply || null);
        });
      } catch (e) { resolve(null); }      // extension reloaded: leave the page alone
    });

  // ---- what it looks like --------------------------------------------------
  // One stylesheet for both the card and the gate. The accent is SillyBus's
  // teal; nothing here reads a preference, because a gate that waits on a
  // fetch is a gate that shows up after the video starts.
  const CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif; }
    .wrap { position: fixed; inset: 0; z-index: 2147483647; display: grid; place-items: center;
            background: rgba(8, 15, 20, .82); backdrop-filter: blur(14px) saturate(.8); }
    .sheet { width: min(30rem, calc(100vw - 2.5rem)); padding: 1.9rem 1.8rem 1.6rem;
             border-radius: 1.1rem; background: #0f1a1f; color: #eaf3f2;
             border: 1px solid rgba(255,255,255,.09);
             box-shadow: 0 1.6rem 4rem rgba(0,0,0,.55);
             animation: rise .34s cubic-bezier(.2,.9,.3,1) both; }
    @keyframes rise { from { opacity: 0; transform: translateY(1.1rem) scale(.985); } }
    @keyframes slide { from { opacity: 0; transform: translateY(1.4rem); } }
    @media (prefers-reduced-motion: reduce) { .sheet, .toast { animation: none; } }
    .mark { display: flex; align-items: center; gap: .55rem; font-size: .78rem;
            letter-spacing: .09em; text-transform: uppercase; color: #5eead4; font-weight: 650; }
    .mark i { width: .5rem; height: .5rem; border-radius: 50%; background: #5eead4;
              box-shadow: 0 0 0 .28rem rgba(94,234,212,.16); font-style: normal; }
    h1 { margin: .9rem 0 .35rem; font-size: 1.42rem; line-height: 1.2; font-weight: 640; }
    h2 { margin: 0 0 .2rem; font-size: 1.02rem; line-height: 1.3; font-weight: 620; }
    p { margin: .35rem 0 0; font-size: .92rem; line-height: 1.5; color: #a9c0bf; }
    p.work { color: #eaf3f2; }
    .row { display: flex; flex-wrap: wrap; gap: .55rem; margin-top: 1.3rem; }
    button { font: inherit; font-size: .9rem; font-weight: 570; padding: .6rem 1rem;
             border-radius: .6rem; border: 1px solid transparent; cursor: pointer;
             transition: transform .12s ease, background .16s ease, border-color .16s ease; }
    button:active { transform: translateY(1px); }
    button.go { background: #14b8a6; color: #04201c; }
    button.go:hover { background: #2dd4bf; }
    button.ghost { background: transparent; color: #cfe3e1; border-color: rgba(255,255,255,.18); }
    button.ghost:hover { border-color: rgba(255,255,255,.34); background: rgba(255,255,255,.05); }
    button.link { background: none; border: 0; color: #7dd3c8; padding: .3rem 0; text-decoration: underline;
                  text-underline-offset: .18em; font-size: .85rem; }
    form { display: flex; gap: .5rem; margin-top: 1.2rem; align-items: center; }
    input { font: inherit; font-size: 1.15rem; letter-spacing: .42em; text-align: center;
            width: 7.6rem; padding: .55rem .5rem; border-radius: .6rem; color: #eaf3f2;
            background: rgba(255,255,255,.06); border: 1px solid rgba(255,255,255,.18); }
    input:focus { outline: 2px solid #14b8a6; outline-offset: 1px; }
    .err { margin-top: .6rem; font-size: .86rem; color: #fca5a5; }
    .fine { margin-top: 1.1rem; font-size: .78rem; line-height: 1.45; color: #6f8a89; }
    /* the reminder */
    .toast { position: fixed; right: 1.1rem; bottom: 1.1rem; z-index: 2147483647;
             width: min(23rem, calc(100vw - 2.2rem)); padding: 1.05rem 1.1rem 1rem;
             border-radius: .95rem; background: #0f1a1f; color: #eaf3f2;
             border: 1px solid rgba(255,255,255,.1);
             box-shadow: 0 1rem 2.6rem rgba(0,0,0,.45);
             animation: slide .38s cubic-bezier(.2,.9,.3,1) both; }
    .toast .row { margin-top: .95rem; }
    .toast button { padding: .48rem .8rem; font-size: .86rem; }
  `;

  function mount(kind) {
    const host = document.createElement("div");
    host.setAttribute("data-sillybus-focus", kind);
    // The page can still delete our node; re-checking on a timer puts it back.
    const root = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = CSS;
    root.append(style);
    (document.body || document.documentElement).append(host);
    return { host, root };
  }

  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const openBoard = () => ask({ type: "open-dashboard" });

  // ---- the gate -----------------------------------------------------------
  // A video that keeps talking behind the gate defeats the gate, so anything
  // playing is paused, and kept paused: YouTube restarts playback on its own
  // when its player finishes setting up.
  function holdMedia(on) {
    if (pausing) { clearInterval(pausing); pausing = null; }
    if (!on) return;
    const pause = () => {
      for (const el of document.querySelectorAll("video, audio")) {
        try { if (!el.paused) el.pause(); } catch (e) { /* cross-origin player */ }
      }
    };
    pause();
    pausing = setInterval(pause, 700);
  }

  function showGate(info) {
    // A gate the page (or DevTools) removed is gone: draw a new one rather
    // than trusting a detached node for ever (prosecution round 3).
    if (gate && gate.isConnected) return;
    if (gate) removeGate();
    const { host, root } = mount("gate");
    gate = host;
    holdMedia(true);

    const due = info.due || {};
    const headline = due.known
      ? (due.headline || "Nothing is due right now")
      : "SillyBus has not read your work yet";
    const work = due.known && due.lead ? `<p class="work">${esc(due.lead)}</p>` : "";
    const wrap = document.createElement("div");
    wrap.className = "wrap";
    wrap.innerHTML = `
      <div class="sheet" role="dialog" aria-modal="true" aria-labelledby="sbf-h">
        <div class="mark"><i></i>SillyBus &middot; Focus</div>
        <h1 id="sbf-h">${esc(info.site || "This site")} is blocked while you have work.</h1>
        <h2>${esc(headline)}</h2>
        ${work}
        <div class="row">
          <button class="go" data-act="board">Open SillyBus</button>
          <button class="ghost" data-act="back">Go back</button>
        </div>
        <form data-role="pin" ${info.pinSet ? "" : "hidden"}>
          <input type="password" inputmode="numeric" autocomplete="off" maxlength="8"
                 pattern="[0-9]*" aria-label="bypass PIN" placeholder="PIN">
          <button class="ghost" type="submit">Let me through</button>
        </form>
        <div class="err" data-role="err" hidden></div>
        ${info.pinSet
          ? `<p class="fine">A correct PIN opens ${esc(info.site || "this site")} for
               ${esc(info.bypassMinutes)} minute${info.bypassMinutes === 1 ? "" : "s"}.
               This is friction, not a lock &mdash; you can always switch the extension
               off in chrome://extensions. That is the point: it has to be deliberate.</p>`
          : `<p class="fine">You have not set a bypass PIN. Set one in
               SillyBus &rarr; Settings &rarr; Focus if you want a way through.</p>`}
      </div>`;
    root.append(wrap);

    const err = wrap.querySelector('[data-role="err"]');
    const form = wrap.querySelector('[data-role="pin"]');
    const field = form.querySelector("input");

    wrap.querySelector('[data-act="board"]').onclick = () => openBoard();
    wrap.querySelector('[data-act="back"]').onclick = () => {
      // history.back() on the first page of a tab goes nowhere, so a tab
      // opened straight onto the site gets the board instead of a dead button.
      if (history.length > 1) history.back(); else openBoard();
    };
    const submitPin = async () => {
      const pin = field.value.trim();
      err.hidden = true;
      if (!/^[0-9]{4,8}$/.test(pin)) {
        err.textContent = "The PIN is 4 to 8 digits.";
        err.hidden = false;
        return;
      }
      const reply = await ask({ type: "focus-unlock", host: location.hostname, pin });
      if (reply && reply.ok) { removeGate(); return; }
      field.value = "";
      err.textContent = (reply && reply.message) || "That is not the PIN.";
      err.hidden = false;
      field.focus();
    };
    form.onsubmit = (event) => { event.preventDefault(); submitPin(); };
    // Enter is handled here as well as by the form, and the reason is the
    // SITE: YouTube binds single keys at the document level (k, j, l, /,
    // space) and there is no promise it leaves Enter alone. Stopping the
    // event at our own field means the page never sees the keystrokes typed
    // into the PIN box, whatever it has bound.
    field.onkeydown = (event) => {
      event.stopPropagation();
      if (event.key !== "Enter") return;
      event.preventDefault();
      submitPin();
    };
    if (info.pinSet) setTimeout(() => field.focus(), 60);
  }

  function removeGate() {
    holdMedia(false);
    if (gate) { gate.remove(); gate = null; }
  }

  // ---- the reminder -------------------------------------------------------
  function showCard(info) {
    if (card || gate) return;
    const due = info.due || {};
    if (!due.headline) return;    // nothing pressing: say nothing at all
    const { host, root } = mount("card");
    card = host;

    const box = document.createElement("div");
    box.className = "toast";
    box.setAttribute("role", "status");
    box.innerHTML = `
      <div class="mark"><i></i>SillyBus</div>
      <h2 style="margin-top:.7rem">${esc(due.headline)}</h2>
      ${due.lead ? `<p>${esc(due.lead)}</p>` : ""}
      <div class="row">
        <button class="go" data-act="board">Open it</button>
        <button class="ghost" data-act="close">Not now</button>
      </div>`;
    root.append(box);

    const close = () => { if (card) { card.remove(); card = null; } };
    box.querySelector('[data-act="board"]').onclick = () => { close(); openBoard(); };
    box.querySelector('[data-act="close"]').onclick = close;
    // Reminders that sit there forever become furniture. Twenty seconds is
    // long enough to read twice and short enough not to be in the way.
    setTimeout(close, 20000);
    ask({ type: "focus-reminded", host: location.hostname });
  }

  // ---- the loop -----------------------------------------------------------
  // `reason` is what the worker decides "once per visit" against: a page load
  // is a visit, a single-page navigation inside the site is not, and a timer
  // tick is neither -- it exists so a bypass running out closes the gate and
  // so a refresh landing in the dashboard tab is noticed. Without the reason
  // the worker would have to guess, and every guess here is either a reminder
  // that never comes back or one that comes back every fifteen seconds.
  let lastUrl = location.href;
  let busy = false;
  let ticks = 0;

  async function check(reason) {
    if (busy) return;
    busy = true;
    try {
      const info = await ask({ type: "focus-check", reason,
                               host: location.hostname, url: location.href });
      // No answer is not "let him in": an extension update or reload
      // invalidates this script's context and every reply comes back empty —
      // which unlocked every gated tab within ten seconds (round 3). A gate
      // that is up stays up until the worker actually says otherwise.
      if (!info || !info.action) { if (!gate) removeGate(); return; }
      if (info.action === "block") { showGate(info); return; }
      removeGate();
      if (info.action === "remind") showCard(info);
    } finally { busy = false; }
  }

  // document_start can be before <body>; the overlay needs somewhere to go.
  if (document.body) check("load");
  else document.addEventListener("DOMContentLoaded", () => check("load"), { once: true });

  setInterval(() => {
    if (location.href !== lastUrl) { lastUrl = location.href; ticks = 0; check("nav"); return; }
    ticks += TICK;
    // A gate is watched closely because it has an expiry; a quiet page is
    // asked about once a minute, so the worker is not woken for nothing.
    const due = gate ? 10000 : CHECK_EVERY;
    if (ticks >= due) { ticks = 0; check("timer"); }
  }, TICK);
  window.addEventListener("popstate", () => { lastUrl = location.href; check("nav"); });
  // A site restored from the back/forward cache never re-runs its scripts.
  window.addEventListener("pageshow", (e) => { if (e.persisted) check("load"); });
})();
