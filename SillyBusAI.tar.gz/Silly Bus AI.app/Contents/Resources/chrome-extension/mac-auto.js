// Pair through an authenticated app page: never expose token minting to websites.
import {refreshMacCalendars, sendMacAssignments} from './mac-calendars.js';
const APP = 'http://127.0.0.1:5055';
let running;
export function syncMacAutomatically() {
  if (running) return running;
  running = sync().catch(() => {}).finally(() => { running = null; });
  return running;
}
async function sync() {
  let {macCalendarToken} = await chrome.storage.local.get('macCalendarToken');
  if (macCalendarToken) {
    const status = await fetch(`${APP}/api/bridge/status`, {
      headers: {'X-SillyBus-Token': macCalendarToken}, signal: AbortSignal.timeout(3000)});
    if (status.status === 403) macCalendarToken = null;
    else if (!status.ok) return;
  }
  if (!macCalendarToken) {
    // Probe before creating a background tab, so an absent app opens nothing.
    await fetch(`${APP}/api/health`, {signal: AbortSignal.timeout(3000)});
    let [tab] = await chrome.tabs.query({url: `${APP}/*`});
    let created = false;
    try {
      if (!tab) { tab = await chrome.tabs.create({url: `${APP}/settings`, active: false}); created = true; }
      for (let i = 0; i < 30; i++) {
        const current = await chrome.tabs.get(tab.id);
        if (current.status === 'complete') break;
        await new Promise(resolve => setTimeout(resolve, 200));
      }
      const [answer] = await chrome.scripting.executeScript({target: {tabId: tab.id}, func: async () => {
        if (location.origin !== 'http://127.0.0.1:5055') return null;
        const response = await fetch('/api/bridge/pair', {method: 'POST'});
        return response.ok ? (await response.json()).token : null;
      }});
      if (!answer?.result) return; // App sign-in remains required.
      macCalendarToken = answer.result;
      await chrome.storage.local.set({macCalendarToken});
    } finally {
      if (created) await chrome.tabs.remove(tab.id).catch(() => {});
    }
  }

  const {siteRead = {}, siteLinks = {}} = await chrome.storage.local.get(['siteRead', 'siteLinks']);
  for (const source of ['apclassroom', 'albert', 'googleclassroom']) {
    const visit = siteRead[source];
    if (siteLinks[source] !== true || !visit?.payload || visit.macHanded === visit.at) continue;
    const result = await sendMacAssignments(source, visit.payload);
    if (result?.ok) {
      const latest = (await chrome.storage.local.get('siteRead')).siteRead || {};
      if (latest[source]?.at === visit.at) {
        await chrome.storage.local.set({siteRead: {...latest, [source]: {...latest[source], macHanded: visit.at}}});
      }
    }
  }
  await refreshMacCalendars();
}
chrome.runtime.onStartup.addListener(syncMacAutomatically);
chrome.runtime.onInstalled.addListener(syncMacAutomatically);
chrome.tabs.onUpdated.addListener((_id, info, tab) => {
  if (info.status === 'complete' && /^https:\/\/calendar\.google\.com\//.test(tab.url || '')) syncMacAutomatically();
});
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === 'mac-calendars') syncMacAutomatically();
});
