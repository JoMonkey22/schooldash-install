import {digest,slot} from './reminder-core.mjs';
const ALARM='sillybus-homework-reminders';
let reminderWrites=Promise.resolve();
const own=sender=>sender?.id===chrome.runtime.id&&sender.url?.startsWith(chrome.runtime.getURL(''));
let checking=null;
export function checkReminder(now=new Date()){if(checking)return checking;checking=runReminder(now).finally(()=>{checking=null;});return checking;}
async function runReminder(now){
 const {desktopReminders:p={},reminderSnapshot:s,reminderLast:l}=await chrome.storage.local.get(['desktopReminders','reminderSnapshot','reminderLast']);
 if(!p.enabled||!await chrome.permissions.contains({permissions:['notifications']}))return;
 const key=slot(now,s?.zone,p.times);if(!key||l?.slot===key)return;const out=digest(s,now);if(!out)return;
 if(l?.message===out.message&&now.getTime()-l.at<6*3600000)return;
 await chrome.notifications.create('sillybus-homework',{type:'basic',iconUrl:'icon128.png',title:out.title,message:out.message});
 await chrome.storage.local.set({reminderLast:{slot:key,message:out.message,at:now.getTime()}});
}
chrome.alarms.get(ALARM).then(alarm=>{if(!alarm)return chrome.alarms.create(ALARM,{periodInMinutes:5});}).catch(()=>{});
chrome.alarms.onAlarm.addListener(a=>{if(a.name===ALARM)checkReminder().catch(()=>{});});
chrome.runtime.onMessage.addListener((m,sender,respond)=>{if(!own(sender))return false;
 if(m?.type==='reminders-clear'){const clearedAt=Date.now();reminderWrites=reminderWrites.then(async()=>{await chrome.storage.local.set({reminderClearedAt:clearedAt});await chrome.storage.local.remove(['reminderSnapshot','reminderLast']);try{await chrome.notifications.clear('sillybus-homework');}catch{}respond({ok:true});});return true;}
 if(m?.type==='reminders-snapshot'){const s=m.snapshot;if(!s||!Array.isArray(s.items)||s.items.length>10000){respond({ok:false});return false;}const snapshot={enabled:s.enabled===true,zone:s.zone,captured_at:s.captured_at,items:s.items.map(i=>({day:typeof i.day==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(i.day)?i.day:null,due:typeof i.due==='string'&&/^\d{4}-\d{2}-\d{2}T[0-9:.+-]+Z?$/.test(i.due)?i.due:null,done:!!i.done,all_day:!!i.all_day,category:['test','quiz'].includes(i.category)?i.category:'other'}))};reminderWrites=reminderWrites.then(async()=>{const {reminderClearedAt=0}=await chrome.storage.local.get('reminderClearedAt');if(!Number.isFinite(m.issuedAt)||m.issuedAt<=reminderClearedAt)return respond({ok:false});await chrome.storage.local.set({reminderSnapshot:snapshot});respond({ok:true});});return true;}
 if(m?.type==='reminders-test'){chrome.permissions.contains({permissions:['notifications']}).then(async yes=>{if(!yes)return respond({ok:false,message:'Allow Chrome notifications first.'});await chrome.notifications.create('sillybus-reminder-test',{type:'basic',iconUrl:'icon128.png',title:'SillyBus reminders are ready',message:'Homework reminders can appear while Chrome is running. No Mac app is needed.'});respond({ok:true});}).catch(()=>respond({ok:false}));return true;}
});
chrome.notifications?.onClicked.addListener(id=>{if(!id.startsWith('sillybus-'))return;const url=chrome.runtime.getURL('index.html');chrome.tabs.query({url}).then(tabs=>tabs.length?chrome.tabs.update(tabs[0].id,{active:true}):chrome.tabs.create({url})).catch(()=>{});});
