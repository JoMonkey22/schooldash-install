
  /* Not deferred and not a module: this has to land before first paint or a
     pinned theme flashes the other one. It applies the saved appearance —
     theme, accent, font set, density, text size — from sillybus.prefs, and
     falls back to the pre-0.18 sillybus.theme key so an upgrade keeps the
     choice someone already made. app.js owns the same logic (applyPrefs) for
     changes made while the page is open; this copy exists only for the first
     paint. */
  (function () {
    try {
      var root = document.documentElement;
      var prefs = {};
      try { prefs = JSON.parse(localStorage.getItem("sillybus.prefs")) || {}; } catch (e) {}
      var theme = prefs.theme;
      if (!theme) {
        var old = localStorage.getItem("sillybus.theme");
        if (old === "dark" || old === "light") theme = old;
      }
      if (theme === "dark" || theme === "light" || theme === "offwhite") {
        root.setAttribute("data-theme", theme);
        var meta = document.querySelector('meta[name="color-scheme"]');
        if (meta) meta.content = theme === "dark" ? "dark" : "light";
      }
      if (prefs.font) root.setAttribute("data-font", prefs.font);
      if (prefs.density) root.setAttribute("data-density", prefs.density);
      if (prefs.textSize) root.style.setProperty("--text-size", prefs.textSize + "px");
      if (prefs.accent && /^#[0-9a-fA-F]{6}$/.test(prefs.accent)) {
        root.style.setProperty("--accent", prefs.accent);
      }
      if (prefs.leftWidth) root.style.setProperty("--left-w", prefs.leftWidth + "px");
      if (prefs.rightWidth) root.style.setProperty("--right-w", prefs.rightWidth + "px");
      if (prefs.hideLeft) root.classList.add("hide-left");
      if (prefs.hideRight) root.classList.add("hide-right");
      /* 0.20: the truth for every one of these lives in config.json under
         `ui`, read through GET /api/prefs — which is what makes a choice made
         in the Mac app show up in the Chrome extension. But a fetch cannot
         finish before the first frame, and a pinned theme that flashes the
         other one for 200ms is exactly the bug this script exists to stop. So
         the appearance keys are MIRRORED into localStorage every time they
         are applied, and this reads the mirror. Config wins the moment
         /api/prefs lands (applyUiPrefs in app.js); the mirror only has to be
         right often enough that the first paint is not a lie. */
      var ui = {};
      try { ui = JSON.parse(localStorage.getItem("sillybus.ui")) || {}; } catch (e) {}
      if (ui.theme === "dark" || ui.theme === "light" || ui.theme === "warm") {
        root.setAttribute("data-theme", ui.theme);
        var m2 = document.querySelector('meta[name="color-scheme"]');
        if (m2) m2.content = ui.theme === "dark" ? "dark" : "light";
      }
      if (ui.accent && /^#[0-9a-fA-F]{6}$/.test(ui.accent)) root.style.setProperty("--accent", ui.accent);
      root.setAttribute("data-look", ui.look === "board" ? "board" : "simple");
      if (ui.pattern) root.setAttribute("data-pattern", ui.pattern);
      if (ui.density) root.setAttribute("data-density", ui.density);
      if (ui.motion) root.setAttribute("data-motion", ui.motion);
      if (ui.date_notes) root.setAttribute("data-date-notes", ui.date_notes);
      if (ui.surface) root.setAttribute("data-surface", ui.surface);
      if (ui.ticks) root.setAttribute("data-ticks", ui.ticks);
      if (ui.transition) root.setAttribute("data-transition", ui.transition);
      if (ui.transition_strength) root.setAttribute("data-transition-strength", ui.transition_strength);
      if (ui.pattern_strength) root.setAttribute("data-pattern-strength", ui.pattern_strength);
      if (ui.pattern_color && /^#[0-9a-fA-F]{6}$/.test(ui.pattern_color)) root.style.setProperty("--pat", ui.pattern_color);
      if (ui.text_size) root.style.setProperty("--text-size", ui.text_size + "px");
      if (ui.font_body) root.style.setProperty("--font-body", '"' + ui.font_body + '", system-ui, sans-serif');
      if (ui.font_head) root.style.setProperty("--font-display", '"' + ui.font_head + '", Georgia, serif');
    } catch (e) { /* private mode — the system setting still applies */ }
  })();
