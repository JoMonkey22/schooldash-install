/* The panes beyond the board: first-run Setup, Classes, Settings, the grade
   page, the Accelerate guide — plus the chat extras (dictation, "teacher
   said") and the ⌘K jump palette.

   A second file on purpose. app.js is the board and is also inlined into the
   published read-only snapshot; none of this belongs there (a snapshot has no
   server to set up, no classes to edit, no model to call, and never carries
   grades). Everything here talks to the local API and reuses app.js's
   globals: STATE, $, esc, loadState, refresh, niceDate, shortCourse,
   showPane, savePrefs, getPrefs and the helpers on window.SD. */
"use strict";

(function () {
  if (typeof window.SNAPSHOT === "object" && window.SNAPSHOT !== null) return;

  /* Every name here is a path the page can stand on, so routes_page.py must
     answer each one (tests/test_web.py checks). "grades" is the old page's
     name, kept so a bookmark still lands somewhere sensible. */
  /* 0.20: "home" is the board's own front — the greeting and the priority
     cards. Adding a name here means adding a route in routes_page.py, which
     tests/test_web.py::test_every_view_the_app_can_navigate_to_has_a_route
     reads THIS list to check; the three move together, always. */
  const VIEWS = ["home", "work", "life", "calendar", "chat", "item", "grade", "grades", "accel", "quiz", "done", "add",
                 "classes", "settings", "setup", "classlist"];
  let CURRENT = "chat";
  let SETUP = null;            // /api/setup/status
  let SETUP_STEP = null;       // which wizard step is on screen
  let COURSES = {};            // course_key -> record
  let SUMMARIES = {};          // course_key -> summary
  let SELECTED_COURSE = null;
  let ACCEL_ITEM = null;
  let GRADE_KEY = null;
  const SD = window.SD || {};

  /* Where the extension and the app are downloaded from. One constant, so the
     page, the README and the install site cannot drift apart. */
  const SITE_URL = "https://jomonkey22.github.io/schooldash-install/";
  const EXT_URL = SITE_URL + "#chrome";

  /* ---------------- small helpers ---------------- */
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function api(path, options) {
    const res = await fetch(path, options);
    let body = {};
    try { body = await res.json(); } catch (e) { /* no body */ }
    if (!res.ok || body.error) {
      const err = new Error(errorMessage(body, res.status));
      err.status = res.status; err.body = body;
      throw err;
    }
    return body;
  }
  /* What went wrong, in words, whatever shape the failure arrived in.
     [MEASURED] 2026-09-20 — "it keeps giving me a HTTP 200 error". The old
     one-liner reached for body.error.message, and a body.error that is a
     plain STRING has no .message, so it fell through to the status code. On
     a route that answers 200 and reports its own failure in the body (the
     job poller did exactly that) the words printed were "HTTP 200": a
     complaint about a response that had in fact succeeded, in place of the
     real reason the study guide failed. Never print a 2xx as an error. */
  function errorMessage(body, status) {
    const e = (body || {}).error;
    if (typeof e === "string" && e.trim()) return e.trim();
    if (e && typeof e === "object") {
      if (e.message) return e.message;
      if (e.code) return String(e.code).replace(/_/g, " ");
    }
    if (body && typeof body.message === "string" && body.message.trim()) return body.message.trim();
    if (status >= 200 && status < 300) return "that did not work, and the app was not told why";
    return `the app could not reach that (HTTP ${status})`;
  }

  const post = (path, data) => api(path, { method: "POST",
    headers: { "Content-Type": "application/json" }, body: JSON.stringify(data || {}) });
  const put = (path, data) => api(path, { method: "PUT",
    headers: { "Content-Type": "application/json" }, body: JSON.stringify(data || {}) });
  const del = (path) => api(path, { method: "DELETE" });

  /* Poll a background job (routes_api._start_job) until it finishes, reporting
     each new progress line. Bounded on purpose: `for(;;)` left the page polling
     for the rest of the day behind a spinner if a job's thread ever hung. */
  const JOB_POLL_MS = 1500;
  const JOB_MAX_WAIT_MS = 30 * 60 * 1000;

  async function pollJob(started, onLine) {
    if (!started.started && !(started.already_running && started.job_id)) {
      throw new Error("could not start — something else may be running");
    }
    if (!started.started) {
      onLine && onLine("(one of these was already running — following it)");
    }
    let seen = 0;
    const deadline = Date.now() + JOB_MAX_WAIT_MS;
    while (Date.now() < deadline) {
      await sleep(JOB_POLL_MS);
      const job = await api(`/api/jobs/${started.job_id}`);
      for (; seen < job.lines.length; seen++) onLine && onLine(job.lines[seen]);
      if (job.done) {
        if (job.ok) return job.result;
        /* `failure`, not `error`: see get_job in routes_api.py. */
        throw new Error(job.failure || "the job failed, and said nothing about why");
      }
    }
    throw new Error("this took too long and was given up on — the work may "
      + "still finish in the background; press Refresh in a minute to see");
  }

  /* Start a sign-in (POST /api/login) and wait for it. A human step can take
     minutes, so this waits up to 40. */
  async function runLogin(kind, onNote) {
    const started = await post("/api/login", { kind, auto: true });
    if (!started.started) {
      onNote && onNote(started.message || "a sign-in is already running");
      return { ok: false, results: [], busy: true };
    }
    onNote && onNote("signing in… (a window only appears if a step needs you)");
    for (let n = 0; n < 800; n++) {
      await sleep(3000);
      const status = await api(`/api/login/${started.job_id}`);
      if (status.done) return status;
    }
    return { ok: false, results: [], output: "still waiting" };
  }

  function siteResultHtml(result) {
    const dot = result.ok ? "ok-dot" : (result.needs_human ? "warn-dot" : "bad-dot");
    const how = { already: "already signed in", auto: "signed in automatically",
                  human: "finished by you", failed: "did not finish",
                  skipped: "skipped" }[result.how] || result.how;
    return `<div class="site-result"><span class="sr-name ${dot}">${esc(
      result.site === "canvas" ? "Canvas" : "Veracross")}</span>
      <span><strong>${esc(how)}</strong> — ${esc(result.message)}${result.detail
        ? `<span class="muted"> (${esc(result.detail)})</span>` : ""}</span></div>`;
  }

  /* ---------------- views ----------------
     showView is the URL-aware wrapper around app.js's showPane: the pane
     changes, the address bar follows for the pages worth bookmarking, and a
     pane that needs data asks for it. */
  const PUSHABLE = new Set(["home", "work", "life", "calendar", "chat", "classes", "settings", "setup", "done",
                            "grades", "classlist"]);
  function showView(name, push) {
    if (!VIEWS.includes(name)) name = "home";
    /* a bookmark from 0.18, when the grades list was a page of its own */
    if (name === "grades" && !(window.simpleLook && window.simpleLook())) name = "home";
    if (name === "classlist" && !(window.simpleLook && window.simpleLook())) name = "home";
    if (["item", "grade", "accel", "quiz"].includes(name) && push !== false) {
      // contextual panes are opened by their own functions, never by path
      name = "chat";
    }
    CURRENT = name;
    /* A path is deliberate navigation, so in the simple layout it moves the
       PAGE rather than only the centre pane — otherwise /classes would render
       into a column that layout keeps hidden.

       `push === false` is the initial route and the back button, and "/" maps
       to "chat" there. [MEASURED] 2026-09-10: that made boot overwrite the
       saved page, so the app always opened on Chat no matter which page he
       had left it on. In this layout "/" means home, and home is the page he
       was last on. */
    window.showPane(name);
    if (push !== false && PUSHABLE.has(name)) {
      const path = name === "home" ? "/" : `/${name}`;
      if (__sdPath() !== path) history.pushState({ view: name }, "", path);
    }
  }
  window.showView = showView;
  window.onPaneShown = function (name) {
    CURRENT = name;
    $("#banners").hidden = name === "setup";
    if (name === "life" && window.renderLifePage) window.renderLifePage();
    if (name === "calendar" && window.renderCalendarPage) window.renderCalendarPage();
    if (name === "done" && window.renderDonePage) window.renderDonePage();
    if (name === "work" && window.renderWorkPage) window.renderWorkPage();
    if (name === "grades" && window.renderGradesPage) window.renderGradesPage();
    if (name === "classlist" && window.renderClassListPage) window.renderClassListPage();
    if (name === "classes") renderClasses();
    if (name === "settings") renderSettings();
    if (name === "setup") renderSetup();
    if (name === "home" || name === "chat" || name === "done") {
      if (PUSHABLE.has(name)) {
        const path = name === "home" ? "/" : `/${name}`;
        if (__sdPath() !== path && !__sdPath().startsWith("/setup")) {
          history.replaceState({ view: name }, "", path);
        }
      }
    }
  };

  /* Scoped to real controls. The runtime stamps data-* attributes on <html>
     itself, so a bare `[data-view]` in a delegated handler matches every
     click in the document — a bug that has silently disabled a whole board
     twice. */
  document.addEventListener("click", (ev) => {
    /* A ⚡ row in the Recent list reopens its guide. Checked before
       [data-view] so a row can carry both without the view winning. */
    const guide = ev.target.closest("button[data-open-accel]");
    if (guide) {
      ev.preventDefault();
      const id = guide.dataset.openAccel;
      const item = (STATE.items || []).find((i) => i.item_id === id);
      openAccelerate(id, item ? item.title : guide.textContent.trim().slice(0, 60));
      return;
    }
    const hit = ev.target.closest("button[data-view], a[data-view]");
    if (hit) { ev.preventDefault(); showView(hit.dataset.view); }
  });
  window.addEventListener("popstate", () => {
    showView(__sdPath().replace("/", "") || "home", false);
  });

  /* ---------------- setup status + banner ---------------- */
  const setupBanner = document.createElement("div");
  setupBanner.id = "setup-banner";
  const banners = $("#banners");
  banners.parentNode.insertBefore(setupBanner, banners);

  async function refreshSetup() {
    try { SETUP = await api("/api/setup/status"); } catch (e) { return SETUP; }
    renderSetupBanner();
    return SETUP;
  }

  /* Steps come from the server (sillybus/onboarding.py). Address them by
     key: positional indexing silently checked the wrong thing the moment a
     step was added or reordered. */
  function step(key) {
    return ((SETUP && SETUP.steps) || []).find((s) => s.key === key) || {};
  }

  /* The setup nudge is a MARK in the top bar now, drawn by app.js from this
     list; the banner it used to be is gone with the rest of them. */
  window.setupPending = () => (!SETUP || SETUP.complete || CURRENT === "setup") ? []
    : SETUP.steps.filter((s) => !s.done).map((s) => s.title.toLowerCase());
  function renderSetupBanner() {
    setupBanner.innerHTML = "";
    if (window.renderQuickLinks) window.renderQuickLinks();
    return;
    if (!SETUP || CURRENT === "setup") { setupBanner.innerHTML = ""; return; }
    if (SETUP.complete) { setupBanner.innerHTML = ""; return; }
    const pending = SETUP.steps.filter((s) => !s.done).map((s) => s.title.toLowerCase());
    setupBanner.innerHTML = `<div class="banner warn">SillyBus AI is not fully set up yet
      (${esc(pending.join(", "))}).
      <a class="banner-link" href="/setup" data-view="setup">Finish setting up →</a></div>`;
    setupBanner.querySelector("a").addEventListener("click", (ev) => {
      ev.preventDefault(); showView("setup");
    });
  }

  /* ---------------- the accounts form (Settings + Setup share it) ---------------- */
  function accountsForm(host, options) {
    options = options || {};
    const creds = (SETUP && SETUP.credentials) || {};
    const google = creds.google || {};
    const vx = creds.veracross || {};
    const school = (SETUP && SETUP.school) || {};
    /* (prosecution round 5, 2026-10-07) "same as Google" used to start ticked,
       so saving the form sent the Google password to whatever Veracross was
       configured — the shipped school's, for a classmate at another one. It
       starts ticked only once a portal is confirmed, and the Veracross part
       is not shown at all for a school without one. */
    const vxInUse = !!school.uses_veracross;
    const sameAsGoogle = vx.configured ? !!vx.use_google : (vxInUse && !!school.confirmed);
    host.innerHTML = `
      <form class="accounts-form">
        <label class="field">School Google email
          <input name="google_email" type="email" autocomplete="username"
                 value="${esc(google.username || "")}" placeholder="your school email" required>
        </label>
        <label class="field">Google password
          <input name="google_password" type="password" autocomplete="current-password"
                 placeholder="${google.has_password ? "(saved — leave blank to keep it)" : ""}">
        </label>
        <div class="vx-part" ${vxInUse ? "" : "hidden"}>
        <label class="check"><input type="checkbox" name="vx_same" ${sameAsGoogle ? "checked" : ""}>
          Veracross uses the same email and password</label>
        <div class="vx-own" ${sameAsGoogle ? "hidden" : ""}>
          <div class="field-row">
            <label class="field">Veracross username
              <input name="vx_username" type="text" autocomplete="off"
                     value="${esc(vx.use_google ? "" : (vx.username || ""))}">
            </label>
            <label class="field">Veracross password
              <input name="vx_password" type="password" autocomplete="off"
                     placeholder="${vx.has_password && !vx.use_google ? "(saved)" : ""}">
            </label>
          </div>
        </div>
        </div>
        <label class="check"><input type="checkbox" name="show"> show passwords while typing</label>
        <div class="row-actions">
          <button type="submit" class="primary">${esc(options.saveLabel || "Save")}</button>
          <button type="button" class="ghost af-test" ${google.configured ? "" : "disabled"}>Test the sign-in</button>
          ${google.configured ? `<button type="button" class="ghost af-forget">Forget these</button>` : ""}
          ${options.allowSkip ? `<button type="button" class="ghost af-skip">Skip for now</button>` : ""}
        </div>
        <p class="note af-note"></p>
        <div class="af-results"></div>
      </form>`;
    const form = host.querySelector("form");
    const note = form.querySelector(".af-note");
    const say = (text, cls) => { note.textContent = text; note.className = "note af-note " + (cls || ""); };
    form.querySelector('[name="vx_same"]').addEventListener("change", (ev) => {
      form.querySelector(".vx-own").hidden = ev.target.checked;
    });
    form.querySelector('[name="show"]').addEventListener("change", (ev) => {
      form.querySelectorAll('input[type="password"], input[data-pw]').forEach((i) => {
        i.type = ev.target.checked ? "text" : "password"; i.dataset.pw = "1";
      });
    });
    form.addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const same = form.querySelector('[name="vx_same"]').checked;
      const body = {
        google: { email: form.google_email.value.trim(), password: form.google_password.value },
      };
      if (vxInUse) {
        body.veracross = same ? { use_google: true }
          : { username: form.vx_username.value.trim(), password: form.vx_password.value,
              use_google: false };
      }
      if (!body.google.email) { say("the email is needed", "bad"); return; }
      if (!body.google.password && !google.has_password) { say("the password is needed", "bad"); return; }
      const btn = form.querySelector('button[type="submit"]');
      btn.disabled = true;
      try {
        await put("/api/credentials", body);
        say("saved on this Mac", "ok");
        form.google_password.value = "";
        await refreshSetup();
        options.onSaved && options.onSaved();
      } catch (err) {
        say("could not save: " + err.message, "bad");
      }
      btn.disabled = false;
    });
    const test = form.querySelector(".af-test");
    test.addEventListener("click", async () => {
      test.disabled = true;
      const results = form.querySelector(".af-results");
      results.innerHTML = "";
      say(vxInUse ? "signing in to Canvas and Veracross with the saved details…"
                  : "signing in to Canvas with the saved details…");
      try {
        const out = await runLogin("all", (t) => say(t));
        results.innerHTML = (out.results || []).map(siteResultHtml).join("")
          || `<div class="muted">${esc(out.output || "no result came back")}</div>`;
        say(out.ok ? (vxInUse ? "both signed in" : "signed in") : "not everything signed in — see below", out.ok ? "ok" : "bad");
        await refreshSetup();
        options.onTested && options.onTested(out);
      } catch (err) {
        say("could not run it: " + err.message, "bad");
      }
      test.disabled = false;
    });
    const forget = form.querySelector(".af-forget");
    if (forget) forget.addEventListener("click", async () => {
      await del("/api/credentials");
      await refreshSetup();
      accountsForm(host, options);
    });
    const skip = form.querySelector(".af-skip");
    if (skip) skip.addEventListener("click", async () => {
      await post("/api/setup/mark", { key: "skipped_accounts" });
      await refreshSetup();
      options.onSkipped && options.onSkipped();
    });
  }

  /* ---------------- SETUP wizard ---------------- */
  async function renderSetup() {
    if (!SETUP) await refreshSetup();
    if (!SETUP) { $("#setup-body").innerHTML = "<p>SillyBus AI is not answering.</p>"; return; }
    renderSetupBanner();
    if (!SETUP_STEP) {
      let sawGuide = false;
      try { sawGuide = localStorage.getItem("sillybus.extension-guide") === "1"; } catch (e) {}
      SETUP_STEP = !SETUP.complete && !sawGuide ? "extension_intro" : SETUP.next || "first_refresh";
    }
    const steps = [{ key: "extension_intro", title: "Start in Chrome", summary: "See how Connect works", done: false }, ...SETUP.steps];
    $("#setup-steps").innerHTML = steps.map((s, i) => `
      <button type="button" class="setup-step${s.done ? " done" : ""}${s.key === SETUP_STEP ? " active" : ""}"
              data-step="${esc(s.key)}">
        <span class="ss-n">${s.done ? "✓" : i + 1}</span><strong>${esc(s.title)}</strong>
        <span class="ss-sum">${esc(s.summary)}</span></button>`).join("")
      + `<button type="button" class="setup-step" data-step="board"><span class="ss-n">→</span>
         <strong>Open the board</strong><span class="ss-sum">${SETUP.complete ? "setup is complete" : "you can come back any time"}</span></button>`;
    $("#setup-steps").querySelectorAll(".setup-step").forEach((b) =>
      b.addEventListener("click", () => {
        if (b.dataset.step === "board") { showView("chat"); return; }
        SETUP_STEP = b.dataset.step; renderSetup();
      }));
    const body = $("#setup-body");
    const render = { extension_intro: stepExtensionIntro, school: stepSchool, accounts: stepAccounts, connect: stepConnect, classes: stepClasses,
                     first_refresh: stepFinish }[SETUP_STEP] || stepSchool;
    render(body);
  }

  function next(step) { SETUP_STEP = step; renderSetup(); }

  /* Step one: which school. (prosecution round 5, 2026-10-07) Setup never
     asked, so a classmate elsewhere was wired to the shipped school's Canvas,
     Veracross and time zone, and the saved Google password went to that
     school's Veracross. Nothing is pre-filled for an install that has not
     answered — a pre-filled box is an answer the student did not give — and
     the shipped school is one button away instead. */
  async function stepSchool(body) {
    let school = {};
    try { school = await api("/api/school"); } catch (e) { /* the form still works */ }
    const known = !!school.confirmed;
    const zone = (known && school.time_zone) || school.mac_time_zone
      || (Intl.DateTimeFormat().resolvedOptions().timeZone || "") || school.time_zone || "";
    const usesVx = known ? !!school.uses_veracross : false;
    body.innerHTML = `<h2>Your school</h2>
      <p class="lede">Which school's Canvas${usesVx ? " and Veracross" : ""} SillyBus AI should read, and which time
      zone your due dates are in.</p>
      <form class="accounts-form" id="school-form">
        <label class="field">School name
          <input name="name" maxlength="80" value="${esc(known ? school.name || "" : "")}" placeholder="your school's name">
        </label>
        <label class="field">Canvas address
          <input name="canvas_host" type="text" inputmode="url" autocomplete="off"
                 value="${esc(known ? school.canvas_host || "" : "")}" placeholder="https://yourschool.instructure.com">
        </label>
        <label class="check"><input type="checkbox" name="uses_veracross" ${usesVx ? "checked" : ""}>
          My school uses Veracross</label>
        <div class="vx-own" ${usesVx ? "" : "hidden"}>
          <label class="field">Veracross portal address
            <input name="veracross_portal" type="text" inputmode="url" autocomplete="off"
                   value="${esc(usesVx ? school.veracross_portal || "" : "")}"
                   placeholder="https://portals.veracross.com/yourschool/student">
          </label>
        </div>
        <label class="field">Time zone ${timeZoneSelect("tz", zone, 'name="time_zone"')}</label>
        <p class="muted">Copy each address from your browser's address bar after signing in — the app keeps only the
          part it needs.</p>
        <div class="row-actions">
          <button type="submit" class="primary">Save and continue</button>
          ${known ? "" : `<button type="button" class="ghost" id="school-shipped">I'm at Brophy Prep</button>`}
        </div>
        <p class="note af-note"></p>
      </form>`;
    const form = $("#school-form");
    const note = form.querySelector(".af-note");
    const say = (text, cls) => { note.textContent = text; note.className = "note af-note " + (cls || ""); };
    const vxBox = form.querySelector('[name="uses_veracross"]');
    vxBox.addEventListener("change", () => { form.querySelector(".vx-own").hidden = !vxBox.checked; });
    const shipped = $("#school-shipped");
    if (shipped) shipped.addEventListener("click", () => {
      form.elements["name"].value = "Brophy College Preparatory";
      form.canvas_host.value = school.default_canvas_host || "";
      vxBox.checked = true; form.querySelector(".vx-own").hidden = false;
      form.veracross_portal.value = school.default_veracross_portal || "";
      form.time_zone.value = "America/Phoenix";
    });
    form.addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const canvas = form.canvas_host.value.trim();
      if (!canvas) { say("the Canvas address is needed", "bad"); return; }
      if (vxBox.checked && !form.veracross_portal.value.trim()) {
        say("type the Veracross portal address, or untick \"My school uses Veracross\"", "bad"); return;
      }
      const btn = form.querySelector('button[type="submit"]');
      btn.disabled = true;
      try {
        await put("/api/school", {
          name: form.elements["name"].value.trim(), canvas_host: canvas,
          uses_veracross: vxBox.checked,
          veracross_portal: vxBox.checked ? form.veracross_portal.value.trim() : "",
          time_zone: form.time_zone.value, confirm: true });
        if (typeof loadSchool === "function") await loadSchool();
        await refreshSetup();
        next("accounts");
        return;
      } catch (err) {
        say("could not save: " + err.message, "bad");
      }
      btn.disabled = false;
    });
  }

  function extensionGuideHtml() {
    return `<div class="extension-demo" aria-label="Animated example: open Canvas, open the top-right SillyBus extension, then Connect">
      <div class="demo-toolbar"><span>Canvas · your signed-in Chrome</span><span class="demo-puzzle" aria-hidden="true">🧩</span></div>
      <div class="demo-scene demo-canvas"><b>Canvas</b><span>Your classes and assignments</span><small>1 · Open Canvas and sign in</small></div>
      <div class="demo-scene demo-popup"><b>SillyBus</b><span>Link this page</span><small>2 · Top right: 🧩 → SillyBus</small></div>
      <div class="demo-scene demo-connect"><b>Connect</b><span>Follow the popup's steps</span><small>3 · Connect, then check the result</small></div>
    </div>
    <button type="button" class="ghost demo-toggle" aria-pressed="false">Pause preview</button>
    <ol class="extension-guide-steps"><li>Open the service in <strong>Chrome</strong> and sign in.</li>
      <li>At the top right, click the <strong>puzzle icon</strong>, then <strong>SillyBus</strong>. Pin it to keep it handy.</li>
      <li>Choose <strong>Link this page</strong> or <strong>Connect</strong>, follow the steps, and wait for the result. Allow the requested site access if Chrome asks.</li></ol>`;
  }

  function wireExtensionPreview(body) {
    const button = body.querySelector(".demo-toggle");
    if (!button) return;
    const demo = body.querySelector(".extension-demo");
    const reduced = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const setPaused = (paused) => {
      demo.classList.toggle("paused", paused);
      button.setAttribute("aria-pressed", String(paused));
      button.textContent = paused ? "Play preview" : "Pause preview";
    };
    setPaused(!!reduced);
    button.onclick = () => setPaused(button.getAttribute("aria-pressed") !== "true");
  }

  function stepExtensionIntro(body) {
    body.innerHTML = `<h2>Start with SillyBus in Chrome</h2>
      <p class="lede">Connect from the school or calendar page you're already signed in to.</p>
      ${extensionGuideHtml()}
      <p class="fieldnote">The SillyBus AI extension reads Canvas, Veracross, AP Classroom and Albert.io. TeamSnap and Google Calendar use calendar connections. Google Classroom imports visible coursework from linked Classwork pages, without a grade reader; other platforms need a supported calendar feed or can be saved as links. Blackboard has no dedicated grade reader. Gmail is not a connection.</p>
      <div class="setup-actions"><a class="linkbtn" href="${esc(EXT_URL)}" target="_blank" rel="noopener">Get the Chrome extension</a>
      <button type="button" class="primary" id="extension-intro-next">Next: your school →</button></div>
      <p class="muted">After connecting in Chrome, use the Mac app for your homework, grades and schedule.</p>`;
    wireExtensionPreview(body);
    $("#extension-intro-next").onclick = () => {
      try { localStorage.setItem("sillybus.extension-guide", "1"); } catch (e) {}
      next("school");
    };
  }

  function stepAccounts(body) {
    body.innerHTML = `<h2>Use your Chrome sign-ins</h2>
      <p class="lede">Open Canvas and your school's grade portal in Chrome. Sign in on each site, then connect through the SillyBus popup.</p>
      ${extensionGuideHtml()}
      <p class="muted">You do not need to save school passwords here. Chrome keeps your existing sign-ins.</p>
      <div class="setup-actions"><button type="button" class="primary" id="accounts-next">Next: check connections →</button></div>`;
    wireExtensionPreview(body);
    $("#accounts-next").onclick = async () => {
      await post("/api/setup/mark", { key: "skipped_accounts" });
      await refreshSetup(); next("connect");
    };
  }

  function stepConnect(body) {
    const c = SETUP.canvas, v = SETUP.veracross, creds = SETUP.credentials || {};
    const vxInUse = v.in_use !== false;   // a Canvas-only school has no feed or portal grades to find
    body.innerHTML = `<h2>${vxInUse ? "Connect Canvas and Veracross" : "Connect Canvas"}</h2>
      <p class="lede">${vxInUse
        ? "Connect these pages with SillyBus in your signed-in Chrome, then check the data here."
        : "Connect Canvas with SillyBus in your signed-in Chrome, then check your classes here."}</p>
      <dl class="kv-list">
        <dt>Canvas</dt><dd class="${c.signed_in ? "ok-dot" : "bad-dot"}">${c.signed_in
          ? `signed in${c.name ? " as " + esc(c.name) : ""}` : "not connected yet"}</dd>
        ${vxInUse ? `<dt>Class schedule</dt><dd class="${v.class_feed ? "ok-dot" : "bad-dot"}">${v.class_feed
          ? `feed saved${v.meetings ? ` — ${v.meetings} class meetings` : ""}` : "feed not found yet"}</dd>
        <dt>Grades</dt><dd class="${v.grades ? "ok-dot" : "warn-dot"}">${v.grades
          ? `${v.grades} courses read` : "not read yet (happens on the first pull)"}</dd>` : ""}
      </dl>
      <div class="setup-actions">
        <button type="button" class="primary" id="connect-go">Check connected data</button>
        <button type="button" class="ghost" id="connect-chrome">Connect Chrome to the Mac app</button>
        <button type="button" class="ghost" id="connect-next">Next: your classes →</button>
      </div>
      <p class="note" id="connect-note">Link services in Chrome first. If the Mac app is empty, pair the extension with this app under Settings → Connect Chrome.</p>
      <div id="connect-results"></div>`;
    $("#connect-next").addEventListener("click", () => next("classes"));
    $("#connect-chrome").onclick = () => { showView("settings"); showSetPage("connections"); };
    $("#connect-go").addEventListener("click", async () => {
      const btn = $("#connect-go"); btn.disabled = true;
      const note = $("#connect-note");
      try {
        note.textContent = "Checking connected data…";
        await refresh(); await refreshSetup(); renderSetup();
      } catch (err) { note.textContent = "Could not check: " + err.message; }
      finally { btn.disabled = false; }
    });
  }

  function stepClasses(body) {
    body.innerHTML = `<h2>Your classes</h2>
      <p class="lede">For each class SillyBus AI finds the textbook, syllabus, the teacher's homework
      doc and the tools it uses, and learns how that teacher writes homework. Check each one,
      fix anything wrong, add what it missed.</p>
      <div class="setup-actions">
        <button type="button" class="primary" id="classes-learn">Detect materials and learn my classes</button>
        <button type="button" class="ghost" id="classes-next">Next: finish →</button>
      </div>
      <div id="setup-classes-progress" class="progress" hidden></div>
      <div id="setup-classes-grid" class="classes-grid" style="margin-top:14px"></div>
      <aside id="setup-class-detail" class="class-detail" hidden style="margin-top:14px"></aside>`;
    $("#classes-next").addEventListener("click", async () => {
      await post("/api/setup/mark", { key: "classes_seen" });
      await refreshSetup();
      next("first_refresh");
    });
    $("#classes-learn").addEventListener("click", () => learnClasses(
      $("#setup-classes-progress"), $("#classes-learn"),
      () => renderClassGrid($("#setup-classes-grid"), $("#setup-class-detail"))));
    loadCourses().then(() => renderClassGrid($("#setup-classes-grid"), $("#setup-class-detail")));
  }

  /* Detect materials for every class, then learn the profiles nobody has
     learned yet. Two jobs, run in sequence, one progress strip. */
  async function learnClasses(progress, button, onDone) {
    button.disabled = true;
    progress.hidden = false; progress.innerHTML = "";
    const line = (t) => { const d = document.createElement("div"); d.textContent = t;
      progress.appendChild(d); progress.scrollTop = progress.scrollHeight; };
    try {
      line("[materials] scanning your Canvas courses…");
      await pollJob(await post("/api/courses/detect", {}), (t) => line("[materials] " + t));
      await loadCourses();
      onDone && onDone();
      line("[learn] learning how each teacher posts homework…");
      await pollJob(await post("/api/setup/learn", {}), (t) => line("[learn] " + t));
      line("done");
      await refreshSetup();
      await loadState();
    } catch (err) {
      line("stopped: " + err.message);
    }
    button.disabled = false;
    setTimeout(() => { progress.hidden = true; }, 6000);
  }

  function stepFinish(body) {
    const first = step("first_refresh");
    const done = !!first.done;
    body.innerHTML = `<h2>${done ? "You're set" : "Almost there"}</h2>
      <p class="lede">${done
        ? `Your board has ${esc(first.summary || "your work on it")}. From here on SillyBus AI refreshes itself every half hour while your Mac is awake.`
        : "One first pull of your homework, schedule and grades, and the board is live."}</p>
      <div class="setup-actions">
        ${done ? "" : `<button type="button" class="primary" id="finish-pull">Pull my homework now</button>`}
        <button type="button" class="ghost" id="finish-reminders">Turn on reminders (7am &amp; 5pm)</button>
        <button type="button" class="primary" id="finish-open">${done ? "Open my board" : "Open the board anyway"}</button>
      </div>
      <p class="note" id="finish-note"></p>
      <p class="muted">You can change any of this later under <strong>Settings</strong> and <strong>Classes</strong>.</p>`;
    const note = $("#finish-note");
    const pull = $("#finish-pull");
    if (pull) pull.addEventListener("click", async () => {
      pull.disabled = true; note.textContent = "pulling…";
      await refresh(); await refreshSetup(); renderSetup();
    });
    $("#finish-reminders").addEventListener("click", async () => {
      const b = $("#finish-reminders"); b.disabled = true;
      try {
        const out = await post("/api/setup/reminders", {});
        note.textContent = out.message || "reminders scheduled";
      } catch (err) { note.textContent = "could not schedule: " + err.message; }
    });
    $("#finish-open").addEventListener("click", async () => {
      await post("/api/setup/mark", { key: "completed_at" });
      await refreshSetup();
      // the tour plays the first time the board opens after setup (app.js)
      setTimeout(() => { if (window.maybeStartTour) window.maybeStartTour(); }, 900);
      showView("chat");
    });
  }

  /* ---------------- CLASSES ---------------- */
  async function loadCourses() {
    try {
      const out = await api("/api/courses");
      COURSES = {}; for (const c of out.courses) COURSES[c.course_key] = c;
      SUMMARIES = out.summaries || {};
    } catch (e) { /* keep what we have */ }
    return COURSES;
  }

  function courseName(key) {
    const c = COURSES[key];
    if (c) return c.display_name || key;
    const g = (STATE && STATE.grades || []).find((x) => x.course_key === key);
    if (g) return g.display_name || key;
    const p = (STATE && STATE.profiles || []).find((x) => x.course_key === key);
    if (p) return p.display_name || p.course_raw || key;
    const i = (STATE && STATE.items || []).find((x) => x.course_key === key);
    return i ? i.course : key;
  }

  /* Every class we know about: records, plus profiles with no record yet. */
  function allCourseKeys() {
    const keys = new Set(Object.keys(COURSES));
    for (const p of (STATE && STATE.profiles) || []) keys.add(p.course_key);
    return [...keys].sort((a, b) => courseName(a).localeCompare(courseName(b)));
  }

  /* *"in classes only have the current semesters grade"*. The server flags
     each record with `current`, worked out from the session the classes that
     actually meet this week belong to. A class with no record yet (a profile
     the detector has not scanned) has nothing to judge, so it counts as
     current rather than being hidden. */
  const isCurrentKey = (key) => {
    const record = COURSES[key];
    return !record || record.current !== false;
  };
  const termOf = (key) => (COURSES[key] || {}).term || "another term";

  function visibleMaterials(record) {
    return (record.materials || []).filter((m) => !m.hidden);
  }

  function classCardHtml(key) {
    const record = COURSES[key];
    const profile = ((STATE && STATE.profiles) || []).find((p) => p.course_key === key) || {};
    const materials = record ? visibleMaterials(record) : [];
    const has = (kind) => materials.some((m) => m.kind === kind);
    const chips = [];
    chips.push(`<span class="cc-chip ${has("textbook") ? "have" : (has("textbook_mention") ? "" : "miss")}">${
      has("textbook") ? "textbook ✓" : has("textbook_mention") ? "textbook named" : "no textbook"}</span>`);
    chips.push(`<span class="cc-chip ${has("syllabus") ? "have" : ""}">${has("syllabus") ? "syllabus ✓" : "no syllabus"}</span>`);
    if (has("schedule_doc") || profile.homework_source === "doc" || profile.homework_source === "both")
      chips.push(`<span class="cc-chip have">homework doc</span>`);
    else if (profile.homework_source === "canvas") chips.push(`<span class="cc-chip">Canvas only</span>`);
    if (profile.learned_by) chips.push(`<span class="cc-chip">${
      profile.learned_by === "heuristic" ? "format not learned" : "format learned"}</span>`);
    if (materials.length) chips.push(`<span class="cc-chip">${materials.length} link${materials.length === 1 ? "" : "s"}</span>`);
    if (record && record.reviewed_at) chips.push(`<span class="cc-chip have">reviewed ✓</span>`);
    const teacher = (record && record.teacher) || profile.teacher || "";
    const room = (record && record.room) || (profile.meeting || {}).typical_room || "";
    return `<button type="button" class="class-card${SELECTED_COURSE === key ? " selected" : ""}" data-key="${esc(key)}"
        style="border-left: 3px solid ${esc(SD.classColor ? SD.classColor(key) : "transparent")}">
      <div class="cc-name">${esc(shortCourse(courseName(key)))}</div>
      <div class="cc-sub">${esc([teacher, room ? "room " + room : ""].filter(Boolean).join(" · ") || " ")}</div>
      <div class="cc-chips">${chips.join("")}</div></button>`;
  }

  function renderClassGrid(grid, detailHost) {
    const all = allCourseKeys();
    const keys = all.filter(isCurrentKey);
    const others = all.filter((k) => !isCurrentKey(k));
    /* Nothing is hidden silently (spec §5.2): the classes from another term
       are one click away and the line says which term each belongs to. */
    const byTerm = new Map();
    for (const key of others) {
      const term = termOf(key);
      if (!byTerm.has(term)) byTerm.set(term, []);
      byTerm.get(term).push(key);
    }
    grid.innerHTML = (keys.length ? keys.map(classCardHtml).join("")
      : `<div class="empty-note">no classes known yet — connect Canvas and Veracross first, then press Detect materials</div>`)
      + (others.length ? `<details class="other-terms"><summary>${others.length} class${
          others.length === 1 ? "" : "es"} from another term — ${[...byTerm.entries()]
            .map(([term, list]) => `${list.length} in ${esc(term)}`).join(", ")}</summary>
          <div class="classes-grid">${others.map(classCardHtml).join("")}</div></details>` : "");
    grid.querySelectorAll(".class-card").forEach((b) => b.addEventListener("click", () => {
      SELECTED_COURSE = b.dataset.key;
      grid.querySelectorAll(".class-card").forEach((x) => x.classList.toggle("selected", x === b));
      renderClassDetail(detailHost);
      detailHost.scrollIntoView({ block: "nearest" });
    }));
  }

  async function renderClasses() {
    await loadCourses();
    /* Counted from the list the GRID draws — records plus profiles with no
       record yet — not from COURSES alone. Two different lists meant the
       sentence could say "12 classes this semester" above thirteen cards. */
    const all = allCourseKeys();
    const live = all.filter(isCurrentKey).length;
    const past = all.length - live;
    $("#classes-sub").textContent = all.length
      ? `${live} class${live === 1 ? "" : "es"} this semester. Click one to review it.`
        + (past ? ` ${past} from another term ${past === 1 ? "is" : "are"} listed at the bottom.` : "")
      : "Nothing detected yet — press Detect materials (needs Canvas signed in).";
    renderClassGrid($("#classes-grid"), $("#class-detail"));
    if (SELECTED_COURSE) renderClassDetail($("#class-detail"));
    const btn = $("#classes-detect");
    btn.onclick = () => learnClasses($("#classes-progress"), btn,
      () => renderClassGrid($("#classes-grid"), $("#class-detail")));
  }

  const KIND_ORDER = ["textbook", "textbook_mention", "syllabus", "schedule_doc", "tool",
                      "resource", "video", "canvas", "website", "other"];
  const KIND_LABEL = { textbook: "Textbook", textbook_mention: "Textbook named, no link yet",
    syllabus: "Syllabus", schedule_doc: "Teacher's homework doc", tool: "Tools", resource: "Docs & files",
    video: "Videos", canvas: "Canvas pages", website: "Websites", other: "Other" };

  function materialRow(m) {
    const title = m.title || m.url || "(untitled)";
    const titleHtml = m.url
      ? `<a href="${esc(m.url)}" target="_blank" rel="noopener">${esc(title)}</a>` : esc(title);
    const meta = [(m.sources || []).join(", ")].filter(Boolean).join(" · ");
    return `<div class="mat${m.confirmed ? " confirmed" : ""}${m.kind === "textbook_mention" ? " mention" : ""}" data-id="${esc(m.id)}">
      <input type="checkbox" class="mat-ok" title="this is right" ${m.confirmed ? "checked" : ""}>
      <div><div class="mat-title">${titleHtml}</div>
        <div class="mat-meta">${esc(meta)}${m.notes ? ` · <em>${esc(m.notes)}</em>` : ""}</div></div>
      <div class="mat-actions">
        ${m.kind === "textbook_mention" ? `<button type="button" class="mat-find" title="look this book up">find</button>` : ""}
        <button type="button" class="mat-edit" title="rename or re-file">✎</button>
        <button type="button" class="mat-hide" title="not useful — hide it">×</button>
      </div></div>`;
  }

  /* Drawn into TWO hosts — #class-detail and the wizard's #setup-class-detail
     — with the same element ids, so every lookup is scoped to `host`. */
  /* ---- what this teacher does: the examples list and the two add forms ----
     [ASKED] 2026-09-28. A photo, a PDF or pasted text; for graded work, the
     grade and the teacher's comments too. The file goes up as raw bytes
     (the same route shape as Check my work), the metadata in the query. */
  function teachRowHtml(key, r) {
    const grade = r.kind === "graded" && r.percent != null
      ? ` · ${esc(String(r.grade))}${r.possible ? "/" + esc(String(r.possible)) : "%"} (${r.percent}%)` : "";
    return `<div class="teach-row" data-id="${esc(r.id)}">
      <span class="teach-kind">${r.kind === "quiz" ? "quiz" : "graded"}</span>
      <div class="teach-main"><b>${esc(r.title)}</b>${grade}
        <div class="kv">${esc((r.added_at || "").slice(0, 10))}${(r.files || []).length ? ` · ${r.files.length} file${r.files.length === 1 ? "" : "s"}` : ""}${
          r.needs_transcription ? " · photo not read yet" : r.chars ? ` · ${r.chars} chars of text` : ""}${
          r.comments ? ` · “${esc(r.comments.slice(0, 80))}”` : ""}</div>
        ${r.preview ? `<div class="teach-preview">${esc(r.preview)}</div>` : ""}</div>
      <button type="button" class="ghost teach-del" title="remove">×</button></div>`;
  }
  function teachFormHtml(kind) {
    const graded = kind === "graded";
    return `<form id="teach-form" class="teach-form">
      <input type="text" name="title" class="field" required maxlength="160"
             placeholder="${graded ? "e.g. Cell lab write-up" : "e.g. Unit 2 quiz, Sept 22"}">
      ${graded ? `<div class="teach-grade-row">
        <input type="text" name="grade" class="field" placeholder="score, e.g. 17" inputmode="decimal">
        <span>/</span><input type="text" name="possible" class="field" placeholder="out of, e.g. 20" inputmode="decimal">
        <input type="text" name="assignment" class="field" placeholder="which assignment (optional)"></div>
        <textarea name="comments" class="field" rows="2" placeholder="what the teacher wrote on it"></textarea>` : ""}
      <textarea name="text" class="field" rows="4" placeholder="${graded
        ? "paste your work, or add a photo of it below" : "paste the questions, or add a photo of the quiz below"}"></textarea>
      <div class="teach-files"><input type="file" name="files" accept="image/*,application/pdf" multiple>
        <span class="kv">photos or a PDF — a photo is read by the model the first time it is needed</span></div>
      <div class="add-actions"><button type="submit" class="primary">Save</button>
        <button type="button" class="ghost" id="teach-cancel">Cancel</button></div></form>`;
  }
  async function wireTeacherSection(host, key) {
    const list = host.querySelector("#cd-teacher-list");
    const note = host.querySelector("#cd-teach-note");
    const formHost = host.querySelector("#cd-teach-form");
    if (!list) return;
    const say = (t, cls) => { note.textContent = t; note.className = "note " + (cls || ""); };
    const reloadList = async () => {
      let data = { examples: [], summary: null };
      try { data = await api(`/api/teacher/${encodeURIComponent(key)}`); } catch (e) { /* empty */ }
      list.innerHTML = data.examples.length
        ? data.examples.map((r) => teachRowHtml(key, r)).join("")
        : `<div class="kv">nothing added yet</div>`;
      list.querySelectorAll(".teach-del").forEach((b) => b.onclick = async () => {
        const row = b.closest(".teach-row");
        await del(`/api/teacher/${encodeURIComponent(key)}/${encodeURIComponent(row.dataset.id)}`);
        reloadList();
      });
    };
    reloadList();
    const open = (kind) => {
      formHost.hidden = false;
      formHost.innerHTML = teachFormHtml(kind);
      const form = formHost.querySelector("#teach-form");
      formHost.querySelector("#teach-cancel").onclick = () => { formHost.hidden = true; formHost.innerHTML = ""; };
      form.onsubmit = async (ev) => {
        ev.preventDefault();
        const f = form.elements;
        const files = [...(f.files.files || [])];
        const text = (f.text.value || "").trim();
        if (!text && !files.length) { say("paste the text or add a photo", "bad"); return; }
        say("saving…");
        try {
          let example = null;
          const meta = { kind, title: f.title.value, grade: f.grade ? f.grade.value : "",
                         possible: f.possible ? f.possible.value : "", comments: f.comments ? f.comments.value : "",
                         assignment: f.assignment ? f.assignment.value : "" };
          if (text) example = (await post(`/api/teacher/${encodeURIComponent(key)}`, { ...meta, text })).example;
          for (const file of files) {
            const q = new URLSearchParams({ ...meta, example_id: example ? example.id : "" });
            const res = await fetch(`/api/teacher/${encodeURIComponent(key)}/file?${q}`, { method: "POST", body: file });
            const out = await res.json();
            if (!res.ok || out.error) throw new Error(errorMessage(out, res.status));
            example = out.example;
          }
          say("saved", "good");
          formHost.hidden = true; formHost.innerHTML = "";
          reloadList();
        } catch (err) { say(err.message, "bad"); }
      };
    };
    host.querySelector("#cd-teach-quiz").onclick = () => open("quiz");
    host.querySelector("#cd-teach-graded").onclick = () => open("graded");
    host.querySelector("#cd-quiz").onclick = () => openQuiz(key, null);
  }

  async function renderClassDetail(host) {
    const key = SELECTED_COURSE;
    if (!key) { host.hidden = true; return; }
    host.hidden = false;
    const at = (sel) => host.querySelector(sel);
    let record = COURSES[key];
    const profile = ((STATE && STATE.profiles) || []).find((p) => p.course_key === key) || {};
    if (!record) {
      record = { course_key: key, display_name: courseName(key), teacher: profile.teacher,
                 room: (profile.meeting || {}).typical_room, canvas_url: profile.canvas_url,
                 materials: [], notes: "", announcements: [] };
    }
    const groups = {};
    for (const m of visibleMaterials(record)) (groups[m.kind] = groups[m.kind] || []).push(m);
    const hidden = (record.materials || []).filter((m) => m.hidden);
    const sections = KIND_ORDER.filter((k) => groups[k]).map((k) =>
      `<div class="cd-section"><h4>${esc(KIND_LABEL[k] || k)}</h4>${groups[k].map(materialRow).join("")}</div>`).join("");
    host.innerHTML = `
      <div class="cd-head"><div><h3>${esc(record.display_name || courseName(key))}</h3>
        <div class="cd-sub">${esc([record.teacher, record.room ? "room " + record.room : "",
          record.term].filter(Boolean).join(" · "))}
          ${record.canvas_url ? ` · <a href="${esc(record.canvas_url)}" target="_blank" rel="noopener">Canvas</a>` : ""}
          · <a href="#" class="cd-grades">grades</a></div></div>
        <button type="button" class="fold-btn" id="cd-close" aria-label="close">×</button></div>
      ${sections || `<div class="empty-note">nothing detected for this class yet</div>`}
      <div class="cd-section"><h4>Find the textbook</h4>
        <form id="cd-find" class="cd-add-row"><input type="text" placeholder="title, author or ISBN" required>
          <button type="submit" class="ghost">Search</button></form>
        <div id="cd-find-results"></div></div>
      <div class="cd-section"><h4>Add a link</h4>
        <form id="cd-add">
          <input type="text" name="title" placeholder="what is it? e.g. Class Quizlet" maxlength="160" class="cd-input">
          <div class="cd-add-row" style="margin-top:6px"><input type="url" name="url" placeholder="https://…">
            <select name="kind"><option value="other">work it out</option><option value="textbook">textbook</option>
              <option value="syllabus">syllabus</option><option value="tool">tool</option><option value="resource">doc/file</option>
              <option value="video">video</option><option value="website">website</option></select></div>
          <div class="add-actions" style="margin-top:6px"><button type="submit" class="primary">Add</button></div></form></div>
      <div class="cd-section" id="cd-teacher"><h4>What this teacher does</h4>
        <div class="muted">Add the quizzes and tests this teacher has actually given, and homework
          they have graded, and SillyBus writes practice quizzes in their style and checks your work
          the way they mark it. Examples, on this Mac — nothing is sent anywhere until a quiz or a
          check uses them.</div>
        <div id="cd-teacher-list" class="teach-list"></div>
        <div class="row-actions">
          <button type="button" class="ghost" id="cd-teach-quiz">+ a quiz they gave</button>
          <button type="button" class="ghost" id="cd-teach-graded">+ graded homework</button>
          <button type="button" class="primary" id="cd-quiz">Practice quiz</button>
        </div>
        <div id="cd-teach-form" hidden></div>
        <p class="note" id="cd-teach-note"></p></div>
      <div class="cd-section"><h4>Your notes about this class</h4>
        <textarea id="cd-notes" class="field" placeholder="e.g. quizzes every Friday · he checks homework at the door · textbook login is my school email">${esc(record.notes || "")}</textarea>
        <p class="note" id="cd-notes-note"></p></div>
      ${(record.announcements || []).length ? `<div class="cd-section"><h4>Recent announcements</h4>${
        record.announcements.slice(0, 5).map((a) => `<div class="ann"><a href="${esc(a.url || "#")}" target="_blank" rel="noopener">${esc(a.title)}</a>
          <span class="ann-when">${esc((a.posted_at || "").slice(0, 10))}</span>
          <div class="ann-text">${esc((a.text || "").slice(0, 220))}</div></div>`).join("")}</div>` : ""}
      <div class="cd-section"><h4>How homework is read</h4>
        <div class="muted">${esc(profile.homework_source === "doc" || profile.homework_source === "both"
          ? "from the teacher's doc" + (profile.learned_by === "heuristic" ? " — format NOT learned yet (heuristics only)" : ` — learned by ${profile.learned_by || "?"}`)
          : profile.homework_source === "canvas" ? "from Canvas assignments" : profile.homework_source === "none"
          ? "no homework expected (" + (profile.verified_zero_reason || "not academic") + ")" : "unknown — learn the class first")}
          ${profile.confidence != null ? ` · confidence ${Math.round(profile.confidence * 100)}%` : ""}</div>
        <div class="row-actions">
          <button type="button" class="ghost" id="cd-relearn">Relearn the format</button>
          <button type="button" class="ghost" id="cd-rescan">Rescan materials</button>
          <button type="button" class="primary" id="cd-reviewed">${record.reviewed_at ? "Reviewed ✓ — mark again" : "Mark as reviewed"}</button>
        </div><p class="note" id="cd-note"></p></div>
      ${hidden.length ? `<details class="cd-section"><summary class="muted">${hidden.length} hidden link(s)</summary>${
        hidden.map((m) => `<div class="mat"><span></span><div class="mat-title">${esc(m.title || m.url)}</div>
          <div class="mat-actions"><button type="button" class="mat-unhide" data-id="${esc(m.id)}">restore</button></div></div>`).join("")}</details>` : ""}`;

    const note = at("#cd-note");
    const say = (t, cls) => { note.textContent = t; note.className = "note " + (cls || ""); };
    const reload = async () => { await loadCourses(); renderClassDetail(host);
      const grid = host.id === "class-detail" ? $("#classes-grid") : $("#setup-classes-grid");
      if (grid) renderClassGrid(grid, host); };
    at("#cd-close").addEventListener("click", () => { SELECTED_COURSE = null; host.hidden = true;
      document.querySelectorAll(".class-card").forEach((x) => x.classList.remove("selected")); });
    at(".cd-grades").addEventListener("click", (ev) => { ev.preventDefault(); openGradePane(key); });
    wireTeacherSection(host, key);

    host.querySelectorAll(".mat").forEach((row) => {
      const id = row.dataset.id;
      if (!id) return;
      const ok = row.querySelector(".mat-ok");
      if (ok) ok.addEventListener("change", async () => {
        await put(`/api/courses/${key}`, { materials: [{ id, confirmed: ok.checked }] }); reload(); });
      const hide = row.querySelector(".mat-hide");
      if (hide) hide.addEventListener("click", async () => {
        await del(`/api/courses/${key}/materials/${id}`); reload(); });
      const edit = row.querySelector(".mat-edit");
      if (edit) edit.addEventListener("click", async () => {
        const m = (record.materials || []).find((x) => x.id === id) || {};
        const title = prompt("Name for this link:", m.title || "");
        if (title === null) return;
        const kind = prompt("File it as (textbook, syllabus, tool, resource, video, website, other):", m.kind || "other");
        if (kind === null) return;
        await put(`/api/courses/${key}`, { materials: [{ id, title, kind: kind.trim() }] }); reload(); });
      const find = row.querySelector(".mat-find");
      if (find) find.addEventListener("click", () => {
        const m = (record.materials || []).find((x) => x.id === id) || {};
        const input = at("#cd-find input"); input.value = m.isbn || m.title || "";
        at("#cd-find").requestSubmit(); });
    });
    host.querySelectorAll(".mat-unhide").forEach((b) => b.addEventListener("click", async () => {
      await put(`/api/courses/${key}`, { materials: [{ id: b.dataset.id, hidden: false }] }); reload(); }));

    at("#cd-find").addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const q = at("#cd-find input").value.trim();
      const out = at("#cd-find-results");
      out.innerHTML = `<div class="muted">searching…</div>`;
      try {
        const res = await api(`/api/textbooks/search?q=${encodeURIComponent(q)}`);
        const links = `<a href="${esc(res.search_links.google_books)}" target="_blank" rel="noopener">Google Books</a>,
          <a href="${esc(res.search_links.open_library)}" target="_blank" rel="noopener">Open Library</a> or
          <a href="${esc(res.search_links.internet_archive)}" target="_blank" rel="noopener">the Internet Archive</a>`;
        const down = (res.unavailable || []).length
          ? `<div class="muted">${esc(res.unavailable.join(" and "))} did not answer just now,
             so this list may be short. Searching by hand still works: ${links}.</div>` : "";
        if (!res.results.length) {
          out.innerHTML = down || `<div class="muted">nothing matched${res.isbn
            ? ` ISBN ${esc(res.isbn)}` : ""} in any catalogue. Try on ${links}.</div>`;
          return;
        }
        out.innerHTML = down + res.results.slice(0, 8).map((r, i) => `<div class="tb-result">
          ${r.cover ? `<img src="${esc(r.cover)}" alt="">` : "<span></span>"}
          <div><strong>${esc(r.title)}</strong>${r.subtitle ? `: ${esc(r.subtitle)}` : ""}
            <div class="muted">${esc([r.authors.slice(0, 2).join(", "), r.publisher, r.year].filter(Boolean).join(" · "))}
              ${r.isbn13 ? ` · ISBN ${esc(r.isbn13)}` : ""}</div>
            ${r.free_url ? `<div class="tb-free">free/borrowable copy: <a href="${esc(r.free_url)}" target="_blank" rel="noopener">open</a></div>` : ""}
            ${r.preview_url ? `<a class="muted" href="${esc(r.preview_url)}" target="_blank" rel="noopener">preview</a>` : ""}</div>
          <button type="button" class="ghost tb-save" data-i="${i}">Bookmark</button></div>`).join("");
        out.querySelectorAll(".tb-save").forEach((b) => b.addEventListener("click", async () => {
          const r = res.results[Number(b.dataset.i)];
          b.disabled = true;
          await post(`/api/courses/${key}/materials`, {
            title: r.title + (r.authors.length ? ` — ${r.authors[0]}` : ""),
            url: r.free_url || r.catalog_url || r.preview_url, kind: "textbook", isbn: r.isbn13,
            notes: r.free_url ? "free/borrowable copy" : (r.source || "").replace("_", " ") });
          reload();
        }));
      } catch (err) { out.innerHTML = `<div class="muted">search failed: ${esc(err.message)}</div>`; }
    });

    at("#cd-add").addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const f = ev.target;
      if (!f.title.value.trim() && !f.url.value.trim()) return;
      await post(`/api/courses/${key}/materials`, { title: f.title.value.trim(), url: f.url.value.trim(), kind: f.kind.value });
      reload();
    });
    const notes = at("#cd-notes");
    notes.addEventListener("blur", async () => {
      if (notes.value === (record.notes || "")) return;
      await put(`/api/courses/${key}`, { notes: notes.value });
      at("#cd-notes-note").textContent = "saved"; at("#cd-notes-note").className = "note ok";
      await loadCourses();
    });
    at("#cd-reviewed").addEventListener("click", async () => {
      await put(`/api/courses/${key}`, { reviewed: true }); say("marked as reviewed", "ok"); reload(); await refreshSetup(); });
    at("#cd-rescan").addEventListener("click", async () => {
      const b = at("#cd-rescan"); b.disabled = true; say("rescanning…");
      try { await pollJob(await post("/api/courses/detect", { course_key: key }), (t) => say(t)); say("rescanned", "ok"); reload(); }
      catch (err) { say("could not rescan: " + err.message, "bad"); }
      b.disabled = false; });
    at("#cd-relearn").addEventListener("click", async () => {
      const b = at("#cd-relearn"); b.disabled = true; say("relearning how this teacher writes homework (one model call)…");
      try { const out = await post(`/api/profiles/${key}/relearn`, {}); say(out.ok ? "relearned — refresh to see the effect" : (out.report || "").slice(-200), out.ok ? "ok" : "bad"); await loadState(); }
      catch (err) { say("could not relearn: " + err.message, "bad"); }
      b.disabled = false; });
  }

  /* Chips for the item pane: the class's textbook and syllabus. */
  window.courseMaterialsHtml = function (courseKey) {
    const s = SUMMARIES[courseKey];
    if (!s) return "";
    const chips = [];
    for (const t of (s.textbooks || []).slice(0, 2))
      chips.push(`<a class="linkbtn" href="${esc(t.url)}" target="_blank" rel="noopener" title="${esc(t.title)}">📘 ${esc((t.title || "Textbook").slice(0, 28))}</a>`);
    for (const t of (s.syllabus || []).slice(0, 1))
      chips.push(`<a class="linkbtn" href="${esc(t.url)}" target="_blank" rel="noopener">📄 Syllabus</a>`);
    chips.push(`<a class="linkbtn" href="/classes" data-class="${esc(courseKey)}">🏫 Class setup</a>`);
    return `<div class="detail-materials">${chips.join("")}</div>`;
  };
  document.addEventListener("click", (ev) => {
    const a = ev.target.closest("a[data-class]");
    if (!a) return;
    ev.preventDefault();
    SELECTED_COURSE = a.dataset.class;
    showView("classes");
  });

  /* ---------------- the GRADE pane ----------------
     *"when you click on a class in the grade panel, it should open the grade
     details in the middle and in an easy to comprehend way show all your
     grades and have something to show the % of your grade each assignment is
     bc some are weighted. section them based on their category too."*

     Columns, one per kind of work, each mark with its score and its share of
     the grade. Where the share comes from is said out loud, because it is
     the only part that can be wrong:
       veracross — the gradebook of record: Veracross's own category weights,
                   which reproduce the report-card percentage exactly.
       canvas    — Canvas group weights. Kept for a school where Canvas is
                   the gradebook; not used here.
       syllabus  — weights the student typed in from the syllabus; by kind.
       points    — a mark's share is its points over all points marked so far.
     Since 0.18.6.0 the marks and the weights both come from Veracross —
     *"i want the grades and assignment grades to only be pulled from
     veracross not canvas because how the classes are weighted is only in
     veracross"* — so on this school's data these numbers ARE the
     report-card grade rather than a second opinion on it. [MEASURED]
     2026-09-09: Canvas held 0 scores and 0 weights across all ten courses.
     What it never does: claim a kind is "dragging the grade down". */
  function scoresFor(key) {
    return ((STATE && STATE.scores) || []).filter((s) => s.course_key === key);
  }
  /* `extra` is a hypothetical mark — the what-if calculator's whole
     mechanism. It goes through this function rather than a formula of its
     own, because a projection that disagreed with the columns above it would
     be worse than no projection at all. */
  function gradeShares(key, extra) {
    /* COPIES of the marks, not the objects in STATE. `_share` and `_earned`
       are written onto each mark below, and the what-if calculator runs this
       whole function again with a hypothetical mark in the pool — which
       recomputes every real mark's share against an inflated total. Writing
       that back into STATE means the next thing to read `_share` (the columns,
       on any later paint) shows a share that includes an assignment nobody
       has been set. Nothing outside this function may see those fields. */
    const scores = scoresFor(key).filter((s) => !s.omit).map((s) => ({ ...s }));
    if (extra) scores.push({ ...extra });
    const book = ((STATE && STATE.gradebook) || {})[key] || {};
    const manual = ((SUMMARIES[key] || {}).weights) || null;
    const groups = [];
    let mode = "points";
    /* Which marks count at all. An excused or not-yet-entered row comes from
       Veracross as score null, percent null, graded false — and it used to be
       counted here as 0 out of its points, which dropped a 90% class to 81%
       and then crashed the page on `null.toFixed`. Veracross leaves such a
       row out of its own total (its points-earned cell is blank), so it is
       left out here too. A "check" mark (reads "Complete", scores a real 0)
       stays in: Veracross counts it, and the page flags it.
       (prosecution round 4, 2026-10-07) */
    const counts = (m) => m.check || (m.score != null && Number.isFinite(Number(m.score)));
    const pool = (list) => list.filter(counts).reduce((t, m) => t + (Number(m.possible) || 0), 0);

    if (book.source === "veracross" && (book.groups || []).length) {
      /* Veracross gives the categories in BOTH weighting methods, so the
         columns come from the gradebook rather than from guessing a kind off
         each title. `method === "type"` carries real weights; "points" has
         none and falls through to the points arithmetic below, which is the
         same sum Veracross does. Keyed as strings: these ids are name slugs
         ("class-participation"), not Canvas's numbers. */
      mode = book.method === "type" ? "veracross" : "points";
      const byGroup = new Map((book.groups || []).map((g) => [String(g.id),
        { key: String(g.id), name: g.name || "group", weight: g.weight, marks: [] }]));
      const other = { key: "other", name: "other", weight: 0, marks: [] };
      for (const s of scores) {
        const g = byGroup.get(String(s.group_id));
        (g ? g.marks : other.marks).push(s);
      }
      for (const g of byGroup.values()) groups.push(g);
      if (other.marks.length) groups.push(other);
    } else if (book.weighted && (book.groups || []).length) {
      mode = "canvas";
      const byGroup = new Map((book.groups || []).map((g) => [g.id, { key: String(g.id), name: g.name || "group",
                                                                     weight: g.weight, marks: [] }]));
      const other = { key: "other", name: "other", weight: 0, marks: [] };
      for (const s of scores) {
        const g = byGroup.get(s.group_id);
        (g ? g.marks : other.marks).push(s);
      }
      for (const g of byGroup.values()) groups.push(g);
      if (other.marks.length) groups.push(other);
    } else {
      const byKind = new Map();
      for (const s of scores) {
        const kind = s.category || "other";
        if (!byKind.has(kind)) byKind.set(kind, { key: kind, name: SD.kindName ? SD.kindName(kind) : kind, weight: null, marks: [] });
        byKind.get(kind).marks.push(s);
      }
      const order = (SD.GRADE_KINDS || []);
      groups.push(...[...byKind.values()].sort((a, b) => order.indexOf(a.key) - order.indexOf(b.key)));
      if (manual && Object.keys(manual).length) {
        mode = "syllabus";
        for (const g of groups) g.weight = manual[g.key] != null ? Number(manual[g.key]) : 0;
        for (const kind of Object.keys(manual)) {
          if (!byKind.has(kind) && Number(manual[kind]) > 0) {
            groups.push({ key: kind, name: SD.kindName ? SD.kindName(kind) : kind, weight: Number(manual[kind]), marks: [] });
          }
        }
      }
    }
    /* Canvas's rule: groups with no marks yet do not count yet — the weights
       of the groups that do have marks are scaled to 100 between them. */
    /* `_earned` is the mark's points over the pool's points, NOT
       `_share * score / possible`. The two are the same for an ordinary mark,
       but extra credit is a mark out of 0: its points are added to what was
       earned and nothing is added to what was possible — that is how both
       Veracross and Canvas count it. The old formula gave any mark out of 0
       an `_earned` of 0, so a 9/10 plus 2 points of extra credit read 90%
       where the gradebook says 110%. Dividing by the pool, never by the
       mark's own `possible`, also keeps a hypothetical "out of 0" typed into
       the what-if box from turning the whole grade into NaN.
       (prosecution round 4, 2026-10-07) */
    const earnedOf = (m) => Number(m.score) || 0;
    if (mode === "points") {
      const total = pool(scores);
      for (const g of groups) {
        g.effective = total ? pool(g.marks) / total * 100 : 0;
        for (const m of g.marks) {
          const on = counts(m);
          m._share = on && total ? ((Number(m.possible) || 0) / total) * 100 : 0;
          m._earned = on && total ? (earnedOf(m) / total) * 100 : 0;
        }
      }
    } else {
      // A group whose only marks are excused has nothing marked yet, and
      // Canvas's rule below gives such a group no weight.
      const live = groups.filter((g) => g.marks.some(counts) && (g.weight || 0) > 0);
      const sum = live.reduce((t, g) => t + g.weight, 0);
      for (const g of groups) {
        g.effective = g.marks.some(counts) && sum ? g.weight / sum * 100 : 0;
        const p = pool(g.marks);
        for (const m of g.marks) {
          const on = counts(m);
          m._share = on && p ? ((Number(m.possible) || 0) / p) * g.effective : 0;
          m._earned = on && p ? (earnedOf(m) / p) * g.effective : 0;
        }
      }
    }
    const earned = groups.reduce((t, g) => t + g.marks.reduce((u, m) => u + m._earned, 0), 0);
    /* `source` is for the WORDS, `mode` is for the arithmetic. A Veracross
       points-weighted class computes exactly like a points class and must not
       be described like one ("no weights are known" is false — points ARE the
       weighting the teacher chose). */
    return { mode, groups, earned, book, manual, count: scores.filter(counts).length,
             source: book.source || (book.weighted ? "canvas" : "") };
  }

  /* ---------------- what if I get… ----------------
     *"a grade calculator for a hypothetical assignment where I enter the
     grade and the category. Then it would tell me what my grade in the class
     would be if I got a 9/10 or a 10/10"*.

     Two honesty rules, both load-bearing:

     * It projects the number CANVAS's marks come to, not the report-card
       grade. Those two already disagree in six of his seven graded classes
       (the pane says so above), and a calculator that implied it was moving
       the Veracross grade would be inventing a grade fact.
     * With nothing marked yet there is nothing to project from, and it says
       that instead of showing a number.
   */
  function projectedPercent(key, groupKey, score, possible) {
    const shares = gradeShares(key);
    const extra = { score, possible, omit: false, title: "what if" };
    if (shares.source === "veracross") {
      /* Grouped by `group_id` in BOTH Veracross modes, so the hypothetical
         mark has to carry one or it lands in "other" — where, in a
         points class, it would still be counted (right answer, wrong column)
         and in a weighted class would be given weight 0 and silently ignored,
         making every projection read "no change". */
      extra.group_id = String(groupKey);
      extra.category = groupKey;
    } else if (shares.mode === "canvas") {
      const asNumber = Number(groupKey);
      extra.group_id = Number.isNaN(asNumber) ? groupKey : asNumber;
      extra.category = "other";
    } else {
      extra.category = groupKey;
    }
    return gradeShares(key, extra).earned;
  }

  /* The scores worth showing for a mark out of `possible`. Whole marks when
     the assignment is small (his example is out of 10, and "9/10" is the
     question people actually ask); percentage steps when it is not. */
  function whatIfScores(possible) {
    if (!(possible > 0)) return [];
    if (possible <= 25 && Number.isInteger(possible)) {
      const out = [];
      for (let n = possible; n >= 0 && out.length < 5; n--) out.push(n);
      return out;
    }
    // Deduped: rounding to one decimal turns 0.5/0.45/0.4 into 0.5/0.5/0.4,
    // and two identical rows in a table of outcomes reads as a bug.
    const steps = [1, 0.9, 0.8, 0.7, 0.6]
      .map((f) => Math.round(possible * f * 10) / 10);
    return [...new Set(steps)];
  }

  function whatIfHtml(key, state) {
    const shares = gradeShares(key);
    if (!shares.count) {
      return `<div class="whatif"><h4 class="gd-h">What if I get…</h4>
        <p class="gd-none">Nothing is marked for this class yet, so there is no
        grade to work forward from.</p></div>`;
    }
    // Only groups that can actually move the number: in a weighted class a
    // group worth 0% cannot, and offering it would produce a row of zeros.
    const pickable = shares.groups.filter(
      (g) => shares.mode === "points" || (g.weight || 0) > 0 || g.marks.length);
    const canMove = (g) => shares.mode === "points" || (g.weight || 0) > 0;
    const chosen = state.group && pickable.some((g) => g.key === state.group)
      ? state.group
      : (pickable.find((g) => g.marks.length && canMove(g))
         || pickable.find(canMove) || pickable[0] || {}).key;
    const possible = Number(state.possible) > 0 ? Number(state.possible) : 10;
    const base = shares.earned;
    const rows = whatIfScores(possible).map((score) => {
      const after = projectedPercent(key, chosen, score, possible);
      const delta = after - base;
      return `<tr${state.score !== "" && Number(state.score) === score ? ' class="wi-picked"' : ""}>
        <td class="wi-mark">${esc(SD.trimNum(score))}/${esc(SD.trimNum(possible))}</td>
        <td class="wi-pct"><span class="pg-chip band-${SD.gradeBand(after)}">${after.toFixed(2)}%</span></td>
        <td class="wi-delta ${delta >= 0.005 ? "up" : delta <= -0.005 ? "down" : ""}">${
          Math.abs(delta) < 0.005 ? "no change"
            : (delta > 0 ? "+" : "\u2212") + Math.abs(delta).toFixed(2)}</td></tr>`;
    }).join("");
    const exact = state.score !== "" && Number(state.score) >= 0
      ? projectedPercent(key, chosen, Number(state.score), possible) : null;
    return `<div class="whatif">
      <h4 class="gd-h">What if I get… <span class="muted">a mark you have not been given yet</span></h4>
      <div class="wi-form">
        <label>Out of<input type="number" id="wi-possible" min="0.5" step="0.5" value="${esc(String(possible))}"></label>
        <label>Counts as<select id="wi-group" ${shares.mode === "points" ? "disabled" : ""}>${pickable.map((g) =>
          `<option value="${esc(g.key)}" ${g.key === chosen ? "selected" : ""}>${esc(g.name)}${
            shares.mode === "points" ? ""
              : g.weight ? ` — ${g.weight}%`
              : " — 0%, does not count"}</option>`).join("")}</select></label>
        <label>My score<input type="number" id="wi-score" min="0" step="0.5"
          placeholder="optional" value="${esc(String(state.score))}"></label>
      </div>
      ${rows ? `<table class="wi-table"><tbody>${rows}</tbody></table>`
             : `<p class="gd-none">Put in how many points the assignment is out of.</p>`}
      ${exact !== null ? `<p class="wi-exact">With <b>${esc(SD.trimNum(Number(state.score)))}/${esc(SD.trimNum(possible))}</b>
        this class comes to <b>${exact.toFixed(2)}%</b>.</p>` : ""}
      ${shares.mode !== "points" ? "" : shares.source === "veracross"
        ? `<p class="wi-why">Where it counts makes no difference in this class —
        your teacher weights it <b>by points</b>, so every point is worth the
        same wherever it sits and the answer is just points over points.</p>`
        : `<p class="wi-why">Where it counts makes no
        difference in this class — no weights are known, so every point is worth
        the same and the answer is just points over points. Type your syllabus
        weights in above and this will follow them.</p>`}
      <p class="wi-note">Worked out from the ${shares.count} mark${shares.count === 1 ? "" : "s"}
        in this class's gradebook, using the same weighting as the columns above
        (${esc(shares.source === "veracross"
                ? (shares.mode === "veracross"
                   ? "Veracross's own category weights"
                   : "points, which is how this class is weighted")
                : {canvas: "Canvas's own group weights",
                   syllabus: "the weights you typed in",
                   points: "points, since no weights are known"}[shares.mode])}).
        ${shares.source === "veracross"
          ? `These are Veracross's marks and Veracross's weights, so this is your
             <b>report-card</b> grade${shares.book && shares.book.renormalised
               ? ` — as long as the weights hold. Veracross scales them across the
                   kinds of work that have marks so far, so they shift on their own
                   when a category gets its first assignment`
               : ""}.`
          : `It is what <b>Canvas's</b> total would become — the report-card grade is
             Veracross's and can differ.`}</p>
    </div>`;
  }

  function weightsFormHtml(key) {
    const kinds = SD.GRADE_KINDS || [];
    const manual = ((SUMMARIES[key] || {}).weights) || {};
    const present = new Set(scoresFor(key).map((s) => s.category || "other"));
    const shown = kinds.filter((k) => present.has(k) || manual[k] != null);
    for (const k of ["test", "quiz", "problem_set", "project"]) if (!shown.includes(k)) shown.push(k);
    return `<form class="weights-form" id="weights-form">
      ${shown.map((k) => `<label>${esc(SD.kindName ? SD.kindName(k) : k)} %
        <input type="number" min="0" max="100" step="1" name="${esc(k)}" value="${esc(manual[k] != null ? manual[k] : "")}" placeholder="—"></label>`).join("")}
      <div class="wf-actions">
        <button type="submit" class="primary">Save weights</button>
        <button type="button" class="ghost" id="weights-clear">Clear</button>
        <button type="button" class="ghost" id="weights-cancel">Cancel</button>
        <span class="wf-sum" id="weights-sum"></span>
      </div></form>`;
  }

  /* What sits in a mark's percent cell. An excused or not-yet-entered row has
     no percent (Veracross sends null) and extra credit is out of 0, so it has
     none either; `null.toFixed` here used to throw and blank the WHOLE grade
     page, not just the one row. (prosecution round 4, 2026-10-07) */
  function markPctText(m) {
    if (typeof m.percent === "number" && Number.isFinite(m.percent)) return `${m.percent.toFixed(0)}%`;
    if (m.score == null) return m.score_text || "\u2014";
    if (!(Number(m.possible) > 0)) return "extra";
    return "\u2014";
  }
  function markScoreText(m) {
    return m.score == null ? "\u2014" : SD.trimNum(m.score);
  }

  /* A mark's due date as a sortable "YYYY-MM-DD", or "9999" when it has
     none (sorted last; the sort is stable, so undated rows keep Veracross's
     own order). Veracross prints "Sep 30" with no year, and sorting that TEXT
     put every April mark before August and "Oct 02" before "Sep 30". The
     year is the school year's: August to December belong to the year it
     started, January to July to the next. (prosecution round 4, 2026-10-07) */
  const MARK_MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
  function markDueKey(m, today) {
    if (m.due_at) {
      const iso = String(m.due_at).slice(0, 10);
      if (/^\d{4}-\d{2}-\d{2}$/.test(iso)) return iso;
    }
    const text = String(m.due || "").trim();
    if (/^\d{4}-\d{2}-\d{2}/.test(text)) return text.slice(0, 10);
    let month = -1, day = 0;
    const named = /^([A-Za-z]{3})[A-Za-z]*\.?\s+(\d{1,2})\b/.exec(text);
    const slashed = /^(\d{1,2})\/(\d{1,2})\b/.exec(text);
    if (named) { month = MARK_MONTHS.indexOf(named[1].toLowerCase()); day = Number(named[2]); }
    else if (slashed) { month = Number(slashed[1]) - 1; day = Number(slashed[2]); }
    if (month < 0 || month > 11 || !(day >= 1 && day <= 31)) return "9999";
    const now = String(today || "");
    const year = Number(now.slice(0, 4)) || new Date().getFullYear();
    const nowMonth = (Number(now.slice(5, 7)) || (new Date().getMonth() + 1)) - 1;
    const started = nowMonth >= 7 ? year : year - 1;          // the school year began in August
    const y = month >= 7 ? started : started + 1;
    return `${y}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
  }

  function markRow(m) {
    const band = SD.gradeBand ? SD.gradeBand(m.percent) : "none";
    const lost = m._share - m._earned;
    return `<div class="gb-mark">
      <span class="gb-title">${m.url ? `<a href="${esc(m.url)}" target="_blank" rel="noopener">${esc(m.title)}</a>` : esc(m.title)}</span>
      <span class="pg-chip gb-pctchip band-${band}">${esc(markPctText(m))}</span>
      <span class="gb-raw">${esc(markScoreText(m))}/${esc(SD.trimNum(m.possible))}${m.graded_at ? ` · ${esc(niceDate(m.graded_at.slice(0, 10)))}` : ""}</span>
      <span class="gb-share${lost >= 0.5 ? " lost" : ""}" title="how much of the class grade this one mark carries${lost >= 0.05 ? `, and how much of that was lost` : ""}">${m._share.toFixed(1)}% of grade${lost >= 0.05 ? ` · −${lost.toFixed(1)}` : ""}</span>
    </div>`;
  }

  function strengthsHtml(key) {
    // Only marks with a percent of their own: an excused row (percent null)
    // averaged as 0 called a kind of work weak that was never marked, and
    // extra credit is out of 0 so it has no percent to average.
    // (prosecution round 4, 2026-10-07)
    const scores = scoresFor(key).filter((m) => typeof m.percent === "number");
    if (!scores.length) {
      return `<p class="gd-none">No marked work for this class yet, so there is nothing to compare.</p>`;
    }
    const groups = new Map();
    for (const mark of scores) {
      const kind = mark.category || "other";
      if (!groups.has(kind)) groups.set(kind, []);
      groups.get(kind).push(mark);
    }
    const MIN = SD.STRENGTH_MIN_MARKS || 2;
    const rows = [...groups.entries()].map(([kind, marks]) => {
      const mean = marks.reduce((t, m) => t + m.percent, 0) / marks.length;
      return { kind, marks, mean, zeros: marks.filter(m => m.percent === 0).length };
    }).sort((a, b) => a.mean - b.mean);
    const ranked = rows.filter(r => r.marks.length >= MIN);
    const worst = ranked[0];
    const best = ranked[ranked.length - 1];
    const zeros = rows.reduce((t, r) => t + r.zeros, 0);
    const name = SD.kindName || ((k) => k);
    let summary = "";
    if (best && worst && best !== worst) {
      summary = `Your <strong>${esc(name(best.kind))}</strong> come out highest
        (${best.mean.toFixed(0)}% over ${best.marks.length}), and your
        <strong>${esc(name(worst.kind))}</strong> lowest
        (${worst.mean.toFixed(0)}% over ${worst.marks.length}).`;
    } else if (best) {
      summary = `Only <strong>${esc(name(best.kind))}</strong> have enough marks
        to compare — ${best.mean.toFixed(0)}% over ${best.marks.length}.`;
    } else {
      summary = `Not enough marked work yet to compare kinds — a single score is
        an anecdote, so nothing is called a strength or a weakness until there are ${MIN}.`;
    }
    return `<div class="gd-strengths">
      <p class="gd-summary">${summary}</p>
      ${zeros ? `<p class="gd-warn">${zeros} of these scored 0. A piece of work never handed in looks
        the same here as one marked badly — worth checking which it was before reading anything
        into the average.</p>` : ""}
    </div>`;
  }

  function openGradePane(courseKey) {
    if (!courseKey) return;
    GRADE_KEY = courseKey;
    if (window.selectClass) window.selectClass(courseKey);
    window.showPane("grade");
    renderGradePane(courseKey);
    if (!SUMMARIES[courseKey] && !Object.keys(SUMMARIES).length) {
      loadCourses().then(() => { if (GRADE_KEY === courseKey) renderGradePane(courseKey); });
    }
    if (window.renderClassPage) window.renderClassPage(courseKey);
  }
  window.openGradePane = openGradePane;

  /* What the calculator's boxes currently hold, per class. Kept outside the
     render so a keystroke does not reset the other two boxes — the pane
     re-renders on every refresh. */
  const WHATIF = {};
  function whatIfState(key) {
    if (!WHATIF[key]) WHATIF[key] = { possible: 10, group: "", score: "" };
    return WHATIF[key];
  }

  function renderGradePane(courseKey, editing) {
    const body = $("#grade-detail-body");
    const title = $("#grade-detail-title");
    const actions = $("#grade-detail-actions");
    if (!body || !title || courseKey !== GRADE_KEY) return;
    const grade = ((STATE && STATE.grades) || []).find((g) => g.course_key === courseKey);
    /* The CLASS's name, not the grades page's spelling of it: after coursejoin
       the grade for "AP Chem" is filed under AP Chemistry, and the pane should
       say what the tab and the strip say. The grade's own name is the fallback
       for a class that has a grade and no work. */
    const profileName = ((STATE.profiles || []).find((p) => p.course_key === courseKey) || {}).display_name;
    const name = shortCourse(profileName || (grade ? grade.display_name : courseName(courseKey)));
    // Local, not UTC: toISOString() is tomorrow after 5 pm in Phoenix.
    const today = (STATE && STATE.today) || (() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; })();
    const mine = ((STATE && STATE.items) || []).filter((i) => i.course_key === courseKey);
    const open = mine.filter((i) => !i.done).sort((a, b) => (a.due_date || "9999") < (b.due_date || "9999") ? -1 : 1);
    const overdue = open.filter((i) => i.due_date && i.due_date < today && !(SD.isPastAssessment && SD.isPastAssessment(i, today)));
    const shares = gradeShares(courseKey);
    const pct = grade && grade.graded && grade.percent != null ? grade.percent : null;
    title.textContent = name;
    actions.innerHTML = `${grade && grade.detail_url
      ? `<a class="linkbtn" href="${esc(grade.detail_url)}" target="_blank" rel="noopener" title="the real gradebook">Veracross ↗</a>` : ""}
      <button type="button" class="mini-btn" id="gd-ask" style="border-color:var(--line)">ask what to work on</button>`;

    const vc = shares.source === "veracross";
    const modeLine = vc
      ? (shares.mode === "veracross"
         ? `<b>Weighted the way your teacher weights this class</b> — ${shares.groups
              .filter((g) => (g.weight || 0) > 0)
              .map((g) => `${esc(g.name)} ${g.weight}%`).join(" · ")
            } — straight from Veracross, the gradebook your report card comes from.${
              shares.book.renormalised ? ` These are the weights <b>as they stand now</b>:
              Veracross spreads them across the kinds of work that have marks so far, so
              they move on their own when a new kind gets its first assignment.` : ""}`
         : `<b>Weighted by points</b> — this class has categories but no percentages,
            so every point counts the same wherever it sits and a mark's share is simply
            its points over all the points marked so far. That is Veracross's own rule
            for this class, not a guess.`)
      : {
      canvas: `<b>Weighted the way Canvas weights this class</b> — each column's weight comes from Canvas's own assignment groups, so a mark's share of the grade is exact for what Canvas holds.`,
      syllabus: `<b>Weighted by the percentages you typed in from the syllabus</b> — columns are kinds of work, and a mark's share is worked out from those.`,
      points: `<b>No weights are known for this class</b> — Canvas adds points straight up here, or has not said. A mark's share is its points over everything marked so far. If the syllabus weights kinds of work, type them in and the shares will follow it.`,
    }[shares.mode];
    /* Does our own arithmetic reproduce the grade Veracross prints? This
       replaced a Canvas-vs-Veracross comparison that no longer means
       anything now that both halves come from the same gradebook — but the
       check itself is worth more than the old one, because it is the page
       auditing ITSELF. If a mark failed to read, or a "Complete" row was
       mishandled, this is where it shows up, and it must never be silently
       reconciled by trusting one number over the other. */
    let agree = "";
    if (vc && pct != null && shares.count) {
      const gap = Math.abs(pct - shares.earned);
      agree = gap <= 0.05
        ? `<div class="gd-note ok">The ${shares.count} mark${shares.count === 1 ? "" : "s"}
             below add up to <b>${shares.earned.toFixed(2)}%</b> — the same as the grade
             Veracross shows, so this is the whole story of the grade so far.</div>`
        : `<div class="gd-note warn">Veracross shows <b>${pct.toFixed(2)}%</b> but the marks
             below add up to <b>${shares.earned.toFixed(2)}%</b>. Something is not being read
             correctly, so trust the ${pct.toFixed(2)}% and treat the shares below as
             approximate${shares.groups.some((g) => g.marks.some((m) => m.check))
               ? ` — a mark with no number in its Score column is the usual cause` : ""}.</div>`;
    }
    const flagged = shares.groups.flatMap((g) => g.marks.filter((m) => m.check));
    if (flagged.length) {
      /* [MEASURED] 2026-09-09: Honors Biology's "Notes Ch 2.3" says
         **Complete** and scores 0.00 out of 10. It is inside the 50%-weighted
         Classwork column, and on its own it costs that class about five
         percentage points. It is not our place to decide whether the teacher
         meant nothing by it — only to make sure he can see it. */
      agree += `<div class="gd-note warn">${flagged.length === 1 ? "One mark counts" :
        flagged.length + " marks count"} points against you without a score:
        ${flagged.slice(0, 3).map((m) => `<b>${esc(m.title)}</b> reads
        &ldquo;${esc(m.score_text)}&rdquo; and scores ${esc(SD.trimNum(m.score || 0))} of
        ${esc(SD.trimNum(m.possible))}`).join("; ")}. That may just be a mark your teacher
        has not entered yet — worth asking.</div>`;
    }
    /* *"make the grade page look like it does in canvas"*.
       Canvas's course Grades page is a TABLE — Name, Due, Score, Out of — with
       the assignment groups and the total in a box beside it. That is what
       this is now. The five columns of stacked cards it replaced were his own
       earlier request and they read worse: a mark's date, score and share were
       three lines in a narrow card, and you could not compare two rows without
       moving your eyes sideways across a scrolling strip.

       Two columns are kept that Canvas does not have, because they are the
       reason this page exists: **share of grade** (what this one mark is worth
       out of the whole class) and the category weight on each group header.
       Canvas cannot show either at this school — it has no weights and no
       scores here at all. */
    const cols = shares.groups.filter((g) => g.marks.length || (g.weight || 0) > 0);
    const dueOf = (m) => m.due || (m.due_at ? niceDate(String(m.due_at).slice(0, 10)) : "");
    const rowsFor = (g) => g.marks.slice()
      .sort((x, y) => markDueKey(x, today).localeCompare(markDueKey(y, today)))
      .map((m) => {
        const band = SD.gradeBand ? SD.gradeBand(m.percent) : "none";
        const lost = m._share - m._earned;
        return `<tr class="gt-row${m.check ? " gt-check" : ""}">
          <td class="gt-name">${m.url
            ? `<a href="${esc(m.url)}" target="_blank" rel="noopener">${esc(m.title)}</a>`
            : esc(m.title)}${m.check
            ? `<span class="gt-flag" title="this reads &ldquo;${esc(m.score_text || "")}&rdquo; and still counts ${esc(SD.trimNum(m.possible))} points against you \u2014 it may just not be entered yet">check</span>`
            : ""}</td>
          <td class="gt-due">${esc(dueOf(m))}</td>
          <td class="gt-score">${esc(markScoreText(m))}<span class="gt-of">/${esc(SD.trimNum(m.possible))}</span></td>
          <td class="gt-pct"><span class="pg-chip band-${band}">${esc(markPctText(m))}</span></td>
          <td class="gt-share${lost >= 0.5 ? " lost" : ""}"
              title="how much of the whole class grade this one mark carries${lost >= 0.05 ? ", and how much of that was lost" : ""}">${
            m._share.toFixed(1)}%${lost >= 0.05 ? ` <small>\u2212${lost.toFixed(1)}</small>` : ""}</td>
        </tr>`;
      }).join("");
    const colHtml = `<table class="gtable">
      <thead><tr>
        <th class="gt-name">Assignment</th>
        <th class="gt-due">Due</th>
        <th class="gt-score">Score</th>
        <th class="gt-pct">Grade</th>
        <th class="gt-share" title="what this mark is worth out of the whole class grade">Of class</th>
      </tr></thead>
      ${cols.map((g) => {
        /* The header's percent is the column's points over its points — the
           same two numbers printed beside it, and the same sum Veracross puts
           in its own "average" column. It used to be the plain mean of each
           mark's percent, which weighs a 5-point quiz like a 50-point test:
           18/20 + 9/10 + 0/10 printed "60%" next to "27/40", where Veracross
           says 67.5%. Excused rows are in neither sum (they do not count);
           extra credit adds to the points and not to the possible.
           (prosecution round 4, 2026-10-07) */
        const counted = g.marks.filter((m) => m.check || (m.score != null && Number.isFinite(Number(m.score))));
        const earned = counted.reduce((t, m) => t + (Number(m.score) || 0), 0);
        const possible = counted.reduce((t, m) => t + (Number(m.possible) || 0), 0);
        const mean = possible > 0 ? earned / possible * 100 : null;
        return `<tbody class="gt-group">
          <tr class="gt-head">
            <th class="gt-name" colspan="2">${esc(g.name)}
              <span class="gt-w">${shares.mode === "points"
                ? `${g.effective.toFixed(0)}% of the points so far`
                : `${(g.weight || 0).toFixed(0)}% of the grade${g.marks.length && Math.abs(g.effective - g.weight) > 0.5
                    ? ` (${g.effective.toFixed(0)}% for now)` : ""}`}</span></th>
            <th class="gt-score">${counted.length
              ? `${esc(SD.trimNum(earned))}<span class="gt-of">/${esc(SD.trimNum(possible))}</span>` : ""}</th>
            <th class="gt-pct">${mean != null
              ? `<span class="pg-chip band-${SD.gradeBand(mean)}">${mean.toFixed(0)}%</span>` : ""}</th>
            <th class="gt-share">${g.marks.length
              ? `${g.marks.reduce((t, m) => t + m._share, 0).toFixed(0)}%` : ""}</th>
          </tr>
          ${g.marks.length ? rowsFor(g)
            : `<tr class="gt-row gt-empty"><td colspan="5">nothing marked in here yet \u2014 it does not count yet</td></tr>`}
        </tbody>`;
      }).join("")}
    </table>`;

    body.innerHTML = `
      <div class="gd-top">
        <span class="gd-letter band-${SD.gradeBand(pct)}" style="background:none">${esc((grade && grade.letter) || "—")}</span>
        <span class="gd-pct">${pct != null ? esc(pct.toFixed(2)) + "%"
          : grade && grade.graded && grade.letter ? "no percentage" : "not graded yet"}</span>
        <span class="gd-sub">${shares.count ? `${shares.count} marked` : "nothing marked yet"}${open.length ? ` · ${open.length} open` : ""}${overdue.length ? ` · <span style="color:var(--danger)">${overdue.length} overdue</span>` : ""}</span>
      </div>
      ${grade && grade.graded === false ? `<div class="gd-note">Veracross has not graded this class yet, so there is no percentage.</div>` : ""}
      ${STATE && STATE.scores_stale ? `<div class="stale-note">marks from ${esc((STATE.scores_stale.as_of || "").slice(0, 10))} — ${esc(STATE.scores_stale.reason || "the gradebook could not be read")}</div>` : ""}
      ${agree}
      <div class="gd-weights"><span>${modeLine}</span>
        ${shares.mode === "canvas" || vc ? "" : `<button type="button" class="mini-btn" id="gd-weights-edit">${shares.manual && Object.keys(shares.manual).length ? "edit syllabus weights" : "set weights from the syllabus"}</button>`}</div>
      ${editing && shares.mode !== "canvas" && !vc ? weightsFormHtml(courseKey) : ""}
      ${cols.length ? `<div class="gb-cols">${colHtml}</div>` : `<p class="gd-none">No marked work for this class yet.</p>`}
      ${shares.count && shares.mode !== "points" ? `<p class="gd-sub" style="margin:2px 0 8px">The shares add up to <b>${shares.earned.toFixed(1)}%</b> earned of the ${shares.groups.filter(g => g.marks.length).reduce((t, g) => t + g.effective, 0).toFixed(0)}% counted so far.</p>` : ""}
      ${shares.count && shares.mode === "points" ? `<p class="gd-sub" style="margin:2px 0 8px">By points alone the marks come to <b>${shares.earned.toFixed(1)}%</b>.</p>` : ""}
      ${whatIfHtml(courseKey, whatIfState(courseKey))}
      <h4 class="gd-h">What you are good at, and what you are not</h4>
      ${strengthsHtml(courseKey)}
      ${open.length ? `<h4 class="gd-h">Open in this class <span class="muted">${open.length}</span></h4>
        <div class="gd-open-rows">${open.slice(0, 12).map((i) => SD.rowHtml(i, "sibling")).join("")}</div>` : ""}
    `;
    body.querySelectorAll(".row-open").forEach((b) => b.addEventListener("click", () => window.openDetail(b.dataset.id)));
    body.querySelectorAll(".row-accel").forEach((b) => b.addEventListener("click", (ev) => {
      ev.stopPropagation();
      const it = (STATE.items || []).find((i) => i.item_id === b.dataset.id);
      if (it) openAccelerate(it.item_id, it.title);
    }));
    body.querySelectorAll(".tick").forEach((t) => t.addEventListener("click", () => window.toggleDone(t.dataset.id, t.checked)));
    const ask = $("#gd-ask");
    if (ask) ask.addEventListener("click", () => {
      const input = $("#chat-input");
      const form = $("#chat-form");
      if (!input || !form) return;
      window.setChatContext({ label: name, sticky: true });
      input.value = `from the work on my board, what should I focus on to bring this grade up, and what is still outstanding?`;
      form.dispatchEvent(new Event("submit", { cancelable: true }));
    });
    const edit = $("#gd-weights-edit");
    if (edit) edit.addEventListener("click", () => renderGradePane(courseKey, !editing));
    /* The calculator redraws only its own block, so the pane does not jump
       and the box being typed in keeps focus. */
    const wi = whatIfState(courseKey);
    const rewire = (field, prop, cast) => {
      const el = $(field);
      if (!el) return;
      el.addEventListener("input", () => {
        wi[prop] = cast ? cast(el.value) : el.value;
        const host = body.querySelector(".whatif");
        if (!host) return;
        const at = document.activeElement && document.activeElement.id;
        const caret = el.selectionStart;
        host.outerHTML = whatIfHtml(courseKey, wi);
        rewireAll();
        const again = at && $("#" + at);
        if (again) {
          again.focus();
          try { again.setSelectionRange(caret, caret); } catch (e) { /* number inputs */ }
        }
      });
    };
    function rewireAll() {
      rewire("#wi-possible", "possible", (v) => v);
      rewire("#wi-score", "score", (v) => v);
      const g = $("#wi-group");
      if (g) g.addEventListener("change", () => {
        wi.group = g.value;
        const host = body.querySelector(".whatif");
        if (host) { host.outerHTML = whatIfHtml(courseKey, wi); rewireAll(); }
      });
    }
    rewireAll();
    const form = $("#weights-form");
    if (form) {
      const sum = $("#weights-sum");
      const total = () => {
        const t = [...form.querySelectorAll("input")].reduce((s, i) => s + (Number(i.value) || 0), 0);
        sum.textContent = t ? `adds up to ${t}%` : "";
        sum.classList.toggle("bad", t > 0 && Math.abs(t - 100) > 0.5);
      };
      form.addEventListener("input", total); total();
      form.addEventListener("submit", async (ev) => {
        ev.preventDefault();
        const weights = {};
        for (const i of form.querySelectorAll("input")) if (i.value !== "") weights[i.name] = Number(i.value);
        await put(`/api/courses/${courseKey}`, { weights });
        await loadCourses();
        renderGradePane(courseKey, false);
      });
      $("#weights-clear").addEventListener("click", async () => {
        await put(`/api/courses/${courseKey}`, { weights: null });
        await loadCourses();
        renderGradePane(courseKey, false);
      });
      $("#weights-cancel").addEventListener("click", () => renderGradePane(courseKey, false));
    }
    if (window.setChatContext && window.currentPane && window.currentPane() === "grade") {
      window.setChatContext({ label: name });
    }
  }
  window.renderGradePane = (key) => renderGradePane(key, false);

  /* ---------------- SETTINGS ---------------- */
  const THEMES = [
    ["system", "System", "linear-gradient(90deg,#fff 50%,#0D1220 50%)"],
    ["light", "Light", "#FFFFFF"],
    ["offwhite", "Off-white", "#F3EFE7"],
    ["dark", "Dark", "#0D1220"],
  ];
  const ACCENTS = ["#2563EB", "#4F46E5", "#7C3AED", "#DB2777", "#DC2626", "#EA580C",
                   "#D97706", "#16A34A", "#0D9488", "#0891B2", "#475569", "#111827"];
  const FONTS = [["modern", "Modern"], ["system", "System"], ["rounded", "Rounded"],
                 ["serif", "Serif"], ["mono", "Mono"]];

  function renderAppearance() {
    /* 0.20: Appearance is drawn by app.js from the ui block (renderAppearancePage).
       This body is the 0.18 one and runs only if the new host is missing. */
    if (window.renderAppearancePage) return;
    const host = $("#appearance-host");
    if (!host) return;
    const p = window.getPrefs();
    const custom = !ACCENTS.some((a) => a.toLowerCase() === (p.accent || "").toLowerCase());
    host.innerHTML = `
      <div class="pref"><div class="pref-label">Theme</div>
        <div class="pref-row">${THEMES.map(([k, label, swatch]) => `<button type="button" class="pref-opt theme-opt${p.theme === k ? " active" : ""}" data-theme-opt="${k}">
          <span class="theme-swatch" style="background:${swatch}"></span>${label}</button>`).join("")}</div></div>
      <div class="pref"><div class="pref-label">Accent colour</div>
        <div class="swatches">${ACCENTS.map((a) => `<button type="button" class="swatch${(p.accent || "").toLowerCase() === a.toLowerCase() ? " active" : ""}"
            style="background:${esc(a)}" data-accent="${esc(a)}" title="${esc(a)}" aria-label="accent ${esc(a)}"></button>`).join("")}
          <span class="accent-custom" title="any colour — the wheel opens the system picker">
            <input type="color" id="accent-picker" value="${esc(p.accent || "#2563EB")}" aria-label="pick any accent colour">
            <input type="text" id="accent-hex" value="${esc(p.accent || "#2563EB")}" maxlength="7" spellcheck="false" aria-label="accent as hex">
            ${custom ? `<span class="muted">custom</span>` : ""}</span></div></div>
      <div class="pref"><div class="pref-label">Font set</div>
        <div class="pref-row">${FONTS.map(([k, label]) => `<button type="button" class="pref-opt font-opt${p.font === k ? " active" : ""}" data-font="${k}">${label}</button>`).join("")}</div></div>
      <div class="pref"><div class="pref-label">Text size</div>
        <div class="pref-range"><input type="range" id="text-size" min="12" max="17" step="0.5" value="${esc(p.textSize)}"><output id="text-size-out">${esc(p.textSize)}px</output></div></div>
      <div class="pref"><div class="pref-label">Density</div>
        <div class="pref-row">${[["compact", "Compact"], ["normal", "Normal"], ["roomy", "Roomy"]].map(([k, label]) =>
          `<button type="button" class="pref-opt${p.density === k ? " active" : ""}" data-density="${k}">${label}</button>`).join("")}</div></div>
      <div class="pref"><div class="pref-label">Motion</div>
        <div class="pref-row">${[["on", "Animations on"], ["off", "Reduce motion"]].map(([k, label]) =>
          `<button type="button" class="pref-opt${p.motion === k ? " active" : ""}" data-motion="${k}">${label}</button>`).join("")}</div></div>
      <div class="pref"><button type="button" class="ghost" id="prefs-reset">Reset appearance and layout</button></div>`;
    host.querySelectorAll("[data-theme-opt]").forEach((b) => b.addEventListener("click", () => { window.savePrefs({ theme: b.dataset.themeOpt }); renderAppearance(); }));
    host.querySelectorAll("[data-accent]").forEach((b) => b.addEventListener("click", () => { window.savePrefs({ accent: b.dataset.accent }); renderAppearance(); }));
    const picker = $("#accent-picker"), hex = $("#accent-hex");
    picker.addEventListener("input", () => { hex.value = picker.value; window.savePrefs({ accent: picker.value }); });
    picker.addEventListener("change", () => renderAppearance());
    hex.addEventListener("change", () => {
      let v = hex.value.trim();
      if (/^[0-9a-fA-F]{6}$/.test(v)) v = "#" + v;
      if (/^#[0-9a-fA-F]{6}$/.test(v)) { window.savePrefs({ accent: v.toUpperCase() }); renderAppearance(); }
      else hex.value = window.getPrefs().accent;
    });
    host.querySelectorAll("[data-font]").forEach((b) => b.addEventListener("click", () => { window.savePrefs({ font: b.dataset.font }); renderAppearance(); }));
    host.querySelectorAll("[data-density]").forEach((b) => b.addEventListener("click", () => { window.savePrefs({ density: b.dataset.density }); renderAppearance(); }));
    host.querySelectorAll("[data-motion]").forEach((b) => b.addEventListener("click", () => { window.savePrefs({ motion: b.dataset.motion }); renderAppearance(); }));
    const size = $("#text-size"), out = $("#text-size-out");
    size.addEventListener("input", () => { out.textContent = `${size.value}px`; window.savePrefs({ textSize: Number(size.value) }); });
    $("#prefs-reset").addEventListener("click", () => {
      try { localStorage.removeItem("sillybus.prefs"); localStorage.removeItem("sillybus.panels"); localStorage.removeItem("sillybus.theme"); } catch (e) { /* ok */ }
      location.reload();
    });
  }
  window.renderAppearance = renderAppearance;

  /* ---------------- which layout ----------------
     The chooser on the first run is the same choice as this, so they must not
     be able to disagree: both write `layout` through savePrefs and both read
     it back from getPrefs. Switching here re-renders the whole board rather
     than reloading the page — the layout is CSS plus one attribute, so a
     reload would only lose the scroll position. */
  const LAYOUTS = [
    ["dash", "Dashboard", "Everything on one screen: grades and calendar on the left, "
      + "all your work on the right, chat in the middle. Nothing to click for, more to read."],
    ["simple", "Simple", "One page at a time, with tabs across the top \u2014 Today, Tests, "
      + "Personal, Grades, Calendar, Chat, Classes, Done, Settings. Easier to read, "
      + "one tap to move."],
  ];
  function renderLayoutPrefs() {
    if (!$("#layout-host")) return;   // 0.20: there is one layout; the card is gone
    const host = $("#layout-host");
    if (!host) return;
    const p = window.getPrefs();
    host.innerHTML = `
      <div class="pref"><div class="pref-label">How it looks</div>
        <div class="lp-options lp-inline">${LAYOUTS.map(([k, label, desc]) => `
          <button type="button" class="lp-opt${p.layout === k ? " active" : ""}" data-layout-opt="${k}">
            <span class="lp-mini ${k === "dash" ? "lp-mini-dash" : "lp-mini-simple"}" aria-hidden="true">${
              k === "dash"
                ? `<span class="lp-m-side"></span><span class="lp-m-mid"></span><span class="lp-m-side"></span>`
                : `<span class="lp-m-tabs"><i></i><i></i><i></i><i></i></span><span class="lp-m-page"></span>`
            }</span>
            <b>${esc(label)}</b><span class="lp-desc">${esc(desc)}</span></button>`).join("")}</div></div>
      <p class="muted">The two show the same data from the same place \u2014 they are two ways of
        arranging one app, not two apps. Anything you tick off, add or ask in one is
        already there in the other.</p>`;
    host.querySelectorAll("[data-layout-opt]").forEach((b) => b.addEventListener("click", () => {
      window.savePrefs({ layout: b.dataset.layoutOpt });
      renderLayoutPrefs();
      if (window.render) window.render();
    }));
  }
  window.renderLayoutPrefs = renderLayoutPrefs;

  function renderBoardPrefs() {
    const host = $("#board-prefs-host");
    if (!host) return;
    const p = window.getPrefs();
    const opts = (name, pairs, current) => `<div class="pref-row">${pairs.map(([k, label]) =>
      `<button type="button" class="pref-opt${current === k ? " active" : ""}" data-pref="${esc(name)}" data-value="${esc(String(k))}">${esc(label)}</button>`).join("")}</div>`;
    host.innerHTML = `
      <div class="pref"><div class="pref-label">Grades order</div>${opts("gradeSort", [["low", "Lowest first"], ["name", "A to Z"]], p.gradeSort)}</div>
      <div class="pref"><div class="pref-label">Assignments order</div>${opts("assignSort", [["smart", "Smart"], ["due", "By date"], ["class", "By class"], ["time", "Longest first"]], p.assignSort)}
        <p class="muted" style="margin:4px 0 0">Smart is the board's own ranking: how soon it is due, what kind of work it is, how many points, and a nudge for classes with a lower grade — longer work first when two tie.</p></div>
      <div class="pref"><div class="pref-label">Calendar opens as</div>${opts("calendar", [["day", "Day"], ["week", "Week"]], p.calendar)}</div>
      <div class="pref"><div class="pref-label">Week view</div>${opts("showWeekends", [[false, "Weekdays"], [true, "Include weekends"]], !!p.showWeekends)}</div>
      <div class="pref"><div class="pref-label">Keyboard</div>
        <p class="muted" style="margin:0"><b>⌘K</b> jump anywhere · <b>/</b> type in chat · <b>Esc</b> back to chat · <b>[</b> <b>]</b> hide a side · <b>r</b> refresh</p></div>`;
    host.querySelectorAll("[data-pref]").forEach((b) => b.addEventListener("click", () => {
      let v = b.dataset.value;
      if (v === "true") v = true; else if (v === "false") v = false;
      window.savePrefs({ [b.dataset.pref]: v });
      renderBoardPrefs();
      if (window.render) window.render();
    }));
  }

  /* ---------------- Settings → your calendars & other programs ----------------
     The addresses he pastes in (spec §4.7). One rule shapes this whole
     section: the URL is the credential, so it goes UP once and never comes
     back down — /api/connections answers with everything about a connection
     except its address. Nothing here ever renders a URL, because there is
     never one to render.

     Every row says what it is, when it last read, and what went wrong if
     something did — in a sentence with the fix in it, not a status code. */
  function connRowHtml(c) {
    const off = c.enabled === false;
    const when = c.last_read
      ? `last read ${esc(String(c.last_read).slice(0, 16).replace("T", " "))}`
      : "not read yet";
    let line = `${esc(c.label || "Calendar")} · ${esc(when)}`;
    if (c.events) line += ` · ${c.events} thing${c.events === 1 ? "" : "s"} on it`;
    let extra = "";
    if (c.error) {
      extra = `<span class="conn-meta bad">${esc(c.error)}${c.fix ? ` — ${esc(c.fix)}` : ""}</span>`;
    } else if (c.note) {
      extra = `<span class="conn-meta warn">${esc(c.note)}</span>`;
    }
    return `<div class="conn-row${off ? " is-off" : ""}" data-conn="${esc(c.id)}">
      <div>
        <span class="conn-name">${esc(c.name || c.label || "Calendar")}</span>
        <span class="conn-meta">${line}${off ? " · switched off" : ""}</span>
        ${extra}
      </div>
      <div class="conn-actions">
        <button type="button" class="mini-btn" data-conn-toggle="${esc(c.id)}"
          title="${esc(off ? "use this calendar again" : "stop reading it, but keep the address")}">${off ? "Turn on" : "Turn off"}</button>
        <button type="button" class="mini-btn" data-conn-remove="${esc(c.id)}"
          title="forget the address and everything read from it">Remove</button>
      </div>
    </div>`;
  }

  /* The board going OUT into someone else's calendar. A file rather than a
     live sync because Google can only be written to through its API (OAuth and
     a Cloud project, forbidden by SPEC §5.3) or by import — and import creates
     real events. Says how many rows it will hold BEFORE it is pressed: a
     download that turns out to be empty teaches you not to trust the button. */
  async function renderCalendarExport() {
    const pick = $("#export-what"), go = $("#export-download"), out = $("#export-note");
    if (!pick || !go) return;                /* the card is absent in some builds */
    async function say() {
      if (!out) return;
      try {
        const n = await api(`/api/calendar/export/summary?what=${encodeURIComponent(pick.value)}`);
        out.textContent = n.total
          ? `${n.total} thing${n.total === 1 ? "" : "s"} to import`
            + (pick.value === "all" ? ` — ${n.events} from your calendars, ${n.work} of homework` : "")
          : "nothing to export yet — press Refresh on the board first";
        go.disabled = !n.total;
      } catch (err) { out.textContent = `could not check what is in it (${err.message})`; }
    }
    pick.onchange = say;
    go.onclick = () => {
      /* An anchor, not fetch(): the browser's own download handles the
         Content-Disposition and the file lands where downloads land. */
      const a = document.createElement("a");
      a.href = `/api/calendar/export.ics?what=${encodeURIComponent(pick.value)}`;
      a.download = "";
      document.body.appendChild(a);
      a.click();
      a.remove();
      /* Revealed rather than always there: before a download it would send
         you to a page with nothing to pick, which is how a helpful button
         becomes a dead end. After one, it IS the next step. */
      const toGoogle = $("#export-open-google");
      if (toGoogle) toGoogle.hidden = false;
      if (out) out.textContent = "downloaded — now import it, using the steps below";
    };
    await say();
  }

  /* ---- how to actually connect each thing --------------------------------
     *"make it really easy to connect I still do not understand based on the
     instructions in the app"* (2026-09-21), then *"make teamsnap, google
     classroom, google calender, and all the other connector all have there
     own mini icon in settings where you click on it and get spacific
     instructions"*.

     One registry, one tile per program, and the tile carries which of the
     three honest shapes it is — the same three the Apps page above already
     names, because a student who is told "paste its address" for a site the
     app signs in to has been sent to the wrong box:

       calendar — you fetch an iCal address out of it and paste it in
       signin   — the app signs in AS you, with details in the sign-ins card
       chrome   — you are signed in already, and the extension reads the page
       export   — the other direction: this board going out to your calendar

     The steps live here rather than in the template so a guide's words and
     its Open button cannot drift apart, and so adding the next program is
     one entry rather than a new block of markup. */
  const CONNECT_GUIDES = [
    {
      id: "google", name: "Google Calendar", mark: "gcal", how: "calendar",
      blurb: "games, family things, anything already in your Google Calendar",
      open: "https://calendar.google.com/calendar/u/0/r/settings",
      openLabel: "Open Google Calendar settings",
      steps: [
        "Press the button above. It opens Google Calendar's settings in your browser.",
        "Down the left side, under <b>Settings for my calendars</b>, click the calendar "
          + "you want — the family one, or your own.",
        "Scroll that page right to the bottom, to the part headed <b>Integrate calendar</b>.",
        "Copy the long address in the box marked <b>Secret address in iCal format</b>. "
          + "It ends in <code>.ics</code>. The box above it says <i>Public address</i> — "
          + "that one usually does not work, so take the secret one.",
        "Paste it in the box below and press <b>Connect</b>.",
      ],
      also: {
        title: "Going the other way — putting this board INTO Google Calendar",
        steps: [
          "Use <b>Put this in your own calendar</b>, the card just below this one. "
            + "Download the file, then press <b>Open Google Calendar's import page</b> "
            + "and choose it.",
          "There is no live two-way sync, and that is not an oversight: Google only "
            + "lets a program write to your calendar through a Google Cloud project and "
            + "a sign-in permission screen, which this app deliberately does not have. "
            + "Importing again after a change <b>updates</b> what is there rather than "
            + "making a second copy, so re-importing is the sync.",
        ],
      },
    },
    {
      id: "classroom", name: "Google Classroom", mark: "classroom", how: "chrome",
      blurb: "visible coursework from the classes you link in Chrome",
      open: "https://classroom.google.com/", openLabel: "Open Google Classroom",
      steps: [
        "Open a class in Google Classroom, then open Classwork and expand the assignments you want to read.",
        "Click the SillyBus Chrome toolbar icon, then <b>Link this page</b>. Visible coursework is imported as assignments, with its original links and any readable stated dates.",
        "Open other classes or more coursework to read those too. This reads visible pages, so it does not claim to have found every assignment. It needs no ChatGPT account or Google API key.",
      ],
    },
    {
      id: "teamsnap", name: "TeamSnap", mark: "teamsnap", how: "calendar",
      blurb: "games and practices, every team on one address",
      open: "https://go.teamsnap.com",
      openLabel: "Open TeamSnap",
      steps: [
        "Press the button above and sign in to TeamSnap on this computer.",
        "Click <b>Schedule</b>, then <b>Go to My Full Schedule</b> at the top. "
          + "That one page covers every team, so you only have to do this once.",
        "Click <b>Subscribe/Export</b> and choose <b>All games and events</b>.",
        "Copy the link it gives you. It starts with <code>webcal://</code> — that is "
          + "the right one, paste it exactly as it is.",
        "Paste it in the box below and press <b>Connect</b>.",
      ],
      also: {
        title: "On the phone app instead",
        steps: [
          "<b>All Schedules</b> → the calendar icon → <b>Sync other calendar</b>. "
            + "TeamSnap emails you the links; open that mail on this computer and copy "
            + "the one for all events.",
        ],
      },
    },
    {
      id: "canvas", name: "Canvas", mark: "canvas", how: "signin",
      blurb: "assignments, announcements, and what teachers put on the class page",
      open: "",
      openLabel: "",
      steps: [
        "Nothing to paste. Canvas is one of the two the app signs in to <i>as you</i>, "
          + "so it can keep reading after a session runs out.",
        "Put your school Google details in <b>Your school sign-ins</b>, the card at the "
          + "bottom of this page. They stay on this Mac.",
        "Then press <b>Refresh data</b> at the top of this page.",
      ],
      also: {
        title: "If you would rather not save a sign-in",
        steps: [
          "Canvas also publishes a plain calendar feed: open Canvas → <b>Calendar</b> → "
            + "<b>Calendar Feed</b>, bottom right, and copy that address into the box "
            + "below.",
          "It carries due dates only — no announcements, no class pages, no grades. "
            + "It is the thin version, and worth knowing it is thin.",
        ],
      },
    },
    {
      id: "veracross", name: "Veracross", mark: "veracross", how: "signin",
      blurb: "the class schedule and grades — what the whole board stands on",
      open: "",
      openLabel: "",
      steps: [
        "Nothing to paste. Like Canvas, the app signs in as you.",
        "Put your Veracross details in <b>Your school sign-ins</b> at the bottom of this "
          + "page, and set your school's portal address in <b>Your school</b> above.",
        "Then press <b>Refresh data</b>.",
      ],
    },
    {
      id: "apclassroom", name: "AP Classroom", mark: "ap", how: "chrome",
      blurb: "assignments set on College Board, read in your own Chrome",
      open: "https://apclassroom.collegeboard.org/",
      openLabel: "Open AP Classroom",
      steps: [
        "Nothing to paste, and no password saved anywhere. You stay signed in to "
          + "College Board in your own Chrome, and the SillyBus extension reads the "
          + "assignment list off the page you are already looking at.",
        "Install the extension first — <b>Connect Chrome</b>, the card above this one, "
          + "has the steps and the pairing code.",
        "Then press the button above and open your assignments. The extension hands "
          + "them over as you look at them; only the assignment name and date are read.",
      ],
    },
    {
      id: "albert", name: "Albert.io", mark: "albert", how: "chrome",
      blurb: "assignments set on Albert, read in your own Chrome",
      open: "https://www.albert.io/",
      openLabel: "Open Albert.io",
      steps: [
        "Same as AP Classroom: no password here, the extension reads the page you are "
          + "signed in to yourself.",
        "Install the extension from <b>Connect Chrome</b> above if you have not already.",
        "Press the button above, sign in, and open your assignments.",
      ],
    },
    {
      id: "schoology", name: "Schoology", mark: "school", how: "calendar",
      blurb: "if your school runs Schoology instead of Canvas",
      open: "", openLabel: "",
      steps: [
        "Sign in to your school's Schoology in your browser.",
        "Click your name, top right → <b>Account Settings</b>.",
        "Find <b>Share Your Schoology Calendar</b> and copy the iCal address it shows.",
        "One catch: the address only appears once the calendar has at least one thing "
          + "on it. An empty calendar shows nothing, and that is not a fault.",
        "Paste it in the box below and press <b>Connect</b>.",
      ],
    },
    {
      id: "powerschool", name: "PowerSchool", mark: "school", how: "calendar",
      blurb: "if your school runs PowerSchool",
      open: "", openLabel: "",
      steps: [
        "Sign in to your school's PowerSchool student portal.",
        "Open <b>Class Assignments</b> and look for <b>Subscribe</b>.",
        "Copy the iCal address it gives you, then paste it in the box below.",
      ],
    },
    {
      id: "blackbaud", name: "Blackbaud", mark: "school", how: "calendar",
      blurb: "also sold as myschoolapp",
      open: "", openLabel: "",
      steps: [
        "Sign in to your school's Blackbaud or myschoolapp portal.",
        "Open the calendar and look for the <b>RSS</b> or <b>iCal</b> button on it.",
        "Copy the address it gives you, then paste it in the box below.",
      ],
    },
    {
      id: "own", name: "Your own calendar", mark: "apple", how: "export",
      blurb: "the other direction — this board, on your phone",
      open: "", openLabel: "",
      steps: [
        "This one goes outwards, so it is the card below: <b>Put this in your own "
          + "calendar</b>.",
        "Choose what to include, press <b>Download</b>, then open the file.",
        "On a Mac, double-clicking it adds it straight to Apple Calendar, and if your "
          + "Google account is already in Apple Calendar you can pick that calendar — "
          + "which puts it in Google too, with no importing.",
        "On an iPhone, open the downloaded file from Files or Mail.",
        "Put it on its own calendar, one you could call SillyBus, so you can hide the "
          + "whole thing at once without touching anything else.",
      ],
    },
    {
      id: "other", name: "Something else", mark: "link", how: "calendar",
      blurb: "a club, a job, another school's system",
      open: "", openLabel: "",
      steps: [
        "Open the calendar page of whatever it is.",
        "Look for a link called <b>Subscribe</b>, <b>iCal</b>, <b>ICS</b>, <b>Export</b> "
          + "or <b>Calendar feed</b>.",
        "Right-click that link and choose <b>Copy Link Address</b>. You want the address "
          + "itself, not a downloaded file.",
        "Paste it in the box below and press <b>Connect</b>. If it is a calendar, it "
          + "will work — the app does not need to have heard of the program.",
      ],
    },
  ];

  // All primary service connections start on the signed-in Chrome page.
  // Keep calendar-only platforms honest: connecting a feed does not read grades.
  for (const guide of CONNECT_GUIDES) {
    if (["canvas", "veracross", "apclassroom", "albert", "google", "teamsnap"].includes(guide.id)) {
      guide.how = "chrome";
      guide.steps = [
        `Open <b>${guide.name}</b> in Chrome and sign in.`,
        "At the top right, click the <b>puzzle icon</b> → <b>SillyBus</b>.",
        "Press <b>Link this page</b> or <b>Connect</b>. Follow the popup's instructions and approve requested site access.",
        "Wait for its result. The extension connects to the running Mac app automatically and sends supported data across.",
      ];
      if (guide.id === "google") guide.openLabel = "Open Google Calendar";
      if (guide.id === "canvas" || guide.id === "veracross") guide.also = undefined;
    } else if (["schoology", "powerschool", "blackbaud", "other"].includes(guide.id)) {
      guide.how = "chrome";
      guide.steps = ["Open its calendar subscription or export page in Chrome while signed in.",
        "Click the top-right <b>puzzle icon</b> → <b>SillyBus</b> → <b>Link this page</b> → <b>Games, practices &amp; events</b>.",
        "Connect a discovered iCal feed. If none is found, this page cannot be synced through the popup; you can save it as a link instead. A calendar feed supplies dates, not grades."];
    }
  }

  /* What each shape means, said once. The tag on an open guide, so "paste its
     address" is never shown for a site the app signs in to instead. */
  const CONNECT_SHAPES = {
    calendar: ["paste its address", "you copy an iCal address out of it, once"],
    signin: ["the app signs in as you", "your details are saved on this Mac, in the card below"],
    chrome: ["read in your Chrome", "you sign in on the site yourself; the extension reads the page"],
    export: ["the other direction", "this board going out into your own calendar"],
  };


  /* What you just pasted appears to be. A guess, on purpose, and it never
     stops you pressing Connect: the server fetches the address before saving
     it, so it is the one that knows. What this catches is the wrong-thing
     paste — the browser link instead of the feed — which otherwise costs you
     a round trip to a "that answered, but not with a calendar" error.

     Pure string work, and deliberately no network: the address is a
     credential, so it must not travel in a query string or reach a log. */
  function readAddress(raw) {
    const text = String(raw == null ? "" : raw).trim();
    if (!text) return { ok: true, kind: "", say: "" };

    const framed = /<iframe[^>]*\bsrc=["']([^"']+)["']/i.exec(text);
    if (framed) {
      return { ok: false, kind: "embed",
        say: "that is the code for putting a calendar on a web page, not an address",
        fix: "go back to Integrate calendar and copy Secret address in iCal format instead" };
    }
    if (!/^(https?|webcal):\/\//i.test(text)) {
      return { ok: false, kind: "notaddress",
        say: "that is not an address yet",
        fix: "copy the whole link, including the https:// or webcal:// at the front" };
    }

    const lower = text.toLowerCase();
    const ics = /\.ics(\?|#|$)/.test(lower);

    if (/calendar\.google\.com/.test(lower) && !ics) {
      /* Google's embed/view link. The calendar's own id is sitting in src=,
         so the feed address can be offered instead of merely described —
         it only works on a calendar shared publicly, which the offer says. */
      const src = /[?&]src=([^&#]+)/.exec(text);
      return { ok: false, kind: "googlepage",
        say: "that is the link for looking at the calendar in a browser, not the one this app reads",
        fix: "in Google Calendar, scroll to Integrate calendar and copy Secret address in iCal format — it ends in .ics",
        instead: src ? "https://calendar.google.com/calendar/ical/" + src[1] + "/public/basic.ics" : "" };
    }
    if (/teamsnap\.com/.test(lower) && !ics && !lower.startsWith("webcal")) {
      return { ok: false, kind: "teamsnappage",
        say: "that is a TeamSnap page, not its schedule link",
        fix: "on My Full Schedule press Subscribe/Export and copy the link it gives you" };
    }

    if (/calendar\.google\.com/.test(lower)) {
      return /\/public\//.test(lower)
        ? { ok: true, kind: "google-public",
            say: "a Google Calendar feed — the public one, which only works if that calendar is shared publicly" }
        : { ok: true, kind: "google", say: "a Google Calendar feed" };
    }
    if (/teamsnap\.com/.test(lower)) return { ok: true, kind: "teamsnap", say: "a TeamSnap schedule" };
    if (ics || lower.startsWith("webcal://")) {
      return { ok: true, kind: "calendar", say: "a calendar feed" };
    }
    /* Plenty of real feeds have no .ics on the end. Say so honestly rather
       than inventing a complaint about an address that may be perfectly good. */
    return { ok: true, kind: "unknown",
      say: "this might be a calendar — press Connect and you will be told for certain" };
  }

  /* Draws the grid of tiles and whichever guide is open under it.

     A grid of marks rather than a row of words because twelve programs in a
     pill strip is a wall of text you scan rather than a set of things you
     recognise — and the mark for each is the one already in the top bar and
     the Apps list above, so the same thing looks the same in all three
     places. markHtml() comes from app.js, which is where LOGOS lives. */
  let CONN_GUIDE = "google";     /* the one most people have */
  function renderConnectHelp() {
    const pick = $("#conn-pick"), steps = $("#conn-steps");
    if (!pick || !steps) return;               /* the card is absent in some builds */
    const mark = window.markHtml || (() => "");
    pick.innerHTML = CONNECT_GUIDES.map((g) => `<button type="button"
      class="conn-tile${g.id === CONN_GUIDE ? " on" : ""}" data-guide="${esc(g.id)}"
      aria-pressed="${g.id === CONN_GUIDE ? "true" : "false"}"
      title="${esc(g.blurb)}">${mark(g.mark)}<span>${esc(g.name)}</span></button>`).join("");

    const guide = CONNECT_GUIDES.find((g) => g.id === CONN_GUIDE) || CONNECT_GUIDES[0];
    const [shape, shapeNote] = CONNECT_SHAPES[guide.how] || CONNECT_SHAPES.calendar;
    const opener = guide.open
      ? `<p class="conn-open"><a class="linkbtn" href="${esc(guide.open)}" target="_blank"
           rel="noopener">${esc(guide.openLabel)} →</a></p>` : "";
    const also = guide.also
      ? `<div class="conn-also"><b>${esc(guide.also.title)}</b>
           <ol>${guide.also.steps.map((line) => `<li>${line}</li>`).join("")}</ol></div>` : "";
    steps.innerHTML = `
      <div class="conn-guide-head">
        <b>${esc(guide.name)}</b>
        <span class="tag" title="${esc(shapeNote)}">${esc(shape)}</span>
        <span class="conn-guide-blurb">${esc(guide.blurb)}</span>
      </div>
      ${opener}
      <ol class="conn-stepped">${guide.steps.map((line) => `<li>${line}</li>`).join("")}</ol>
      ${also}`;
    pick.querySelectorAll("[data-guide]").forEach((b) => b.onclick = () => {
      CONN_GUIDE = b.dataset.guide;
      renderConnectHelp();
      /* The paste box is only the next step for the ones you paste into.
         Saying "the box below" on the AP Classroom tile would be a lie, and
         the shape tag above is what keeps that straight. */
    });
  }

  /* Opens one program's steps from elsewhere — the calendar's Link TeamSnap
     note in the Mac app sends him here on the TeamSnap tile, scrolled to it,
     rather than on Google's. [ASKED] 2026-10-06, see calLinkTeamSnap. */
  window.showConnectGuide = (id) => {
    if (!CONNECT_GUIDES.some((g) => g.id === id)) return;
    CONN_GUIDE = id;
    renderConnectHelp();
    const card = $("#settings-connect-guide");
    if (card) setTimeout(() => card.scrollIntoView({ block: "start", behavior: "smooth" }), 60);
  };

  function showAddressVerdict() {
    const box = $("#conn-url"), out = $("#conn-verdict");
    if (!box || !out) return;
    const seen = readAddress(box.value);
    if (!box.value.trim()) { out.hidden = true; out.textContent = ""; return; }
    out.hidden = false;
    out.classList.toggle("bad", !seen.ok);
    /* Two lines, not one: what it is, then what to do about it. Run together
       on one line at .68rem the fix was the tail of a sentence nobody
       finished reading, which is how the old help failed in the first place. */
    out.innerHTML = seen.ok
      ? `<span class="conn-verdict-say">${esc("Looks like " + seen.say + ".")}</span>`
      : `<span class="conn-verdict-say">${esc("That is not it — " + seen.say + ".")}</span>`
        + (seen.fix ? `<span class="conn-verdict-fix">${esc(seen.fix)}.</span>` : "")
        + (seen.instead
          ? `<button type="button" class="mini-btn" id="conn-instead">Try this address instead</button>` : "");
    const swap = $("#conn-instead");
    if (swap) swap.onclick = () => { box.value = seen.instead; showAddressVerdict(); };
  }

  async function renderConnections() {
    const host = $("#connections-list");
    if (!host) return;                       /* the card is absent in some builds */
    let data = { connections: [] };
    try { data = await api("/api/connections"); }
    catch (err) {
      host.innerHTML = `<p class="muted">could not read your connections (${esc(err.message)})</p>`;
      return;
    }
    /* How far ahead these are read. Its own setting and not the homework
       window: homework you can do tonight is a fortnight's worth, but a
       season is months, and reading events through the homework window was
       why "when is the Gonzaga game" answered nothing in September. */
    const ahead = Number(data.days_forward) || 150;
    const [amin, amax] = data.days_forward_range || [14, 400];
    const aheadHtml = `
      <div class="conn-window">
        <label class="field">How far ahead to read them
          <select id="conn-ahead">
            ${[[30, "a month"], [90, "three months"], [150, "five months — a whole season"],
               [210, "seven months"], [300, "the school year"], [400, "a year and a bit"]]
              .filter(([d]) => d >= amin && d <= amax)
              .map(([d, label]) => `<option value="${esc(d)}"${d === ahead ? " selected" : ""}>${esc(label)}</option>`)
              .join("")}
          </select></label>
        <p class="fieldnote">Games and practices months away show up on the board and
          the calendar. Your homework list is unaffected — that stays at two weeks.</p>
      </div>`;
    host.innerHTML = aheadHtml + (data.connections.length
      ? data.connections.map(connRowHtml).join("")
      : `<p class="muted">nothing connected yet. Paste a calendar address below and
         your games, practices and appointments join the board.</p>`);
    const aheadPick = host.querySelector("#conn-ahead");
    if (aheadPick) aheadPick.onchange = async () => {
      aheadPick.disabled = true;
      try {
        await put("/api/connections/window", { days_forward: Number(aheadPick.value) });
        note("saved — the next refresh reads that far ahead");
      } catch (err) { note(`could not save that: ${err.message}`); }
      aheadPick.disabled = false;
    };
    host.querySelectorAll("[data-conn-remove]").forEach((b) => b.onclick = async () => {
      const row = b.closest(".conn-row");
      const name = row ? row.querySelector(".conn-name").textContent.trim() : "this calendar";
      /* Asked, because it cannot be undone: the address is gone and he has to
         go back to Google or TeamSnap to copy it again. */
      if (!window.confirm(`Remove ${name}? The saved address is deleted, along with `
          + "everything read from it. You would have to copy it again to add it back.")) return;
      b.disabled = true;
      try { await del(`/api/connections/${encodeURIComponent(b.dataset.connRemove)}`); }
      catch (err) { note(`could not remove it: ${err.message}`); }
      await renderConnections();
      if (window.refresh) { /* the board still shows its events until the next pull */ }
    });
    host.querySelectorAll("[data-conn-toggle]").forEach((b) => b.onclick = async () => {
      const id = b.dataset.connToggle;
      const off = b.textContent.trim() === "Turn on";
      b.disabled = true;
      try { await put(`/api/connections/${encodeURIComponent(id)}`, { enabled: off }); }
      catch (err) { note(`could not change it: ${err.message}`); }
      await renderConnections();
    });

    function note(text, ok) {
      const el = $("#conn-note");
      if (!el) return;
      el.hidden = !text;
      el.textContent = text || "";
      el.classList.toggle("ok-dot", !!ok);
    }
    renderConnectHelp();
    const form = $("#conn-add");
    if (form && !form.dataset.wired) {
      form.dataset.wired = "1";
      /* Both events: `input` catches typing, and Safari fires `paste` before
         the value lands, so the read is deferred a tick. */
      const box = $("#conn-url");
      if (box) {
        box.addEventListener("input", showAddressVerdict);
        box.addEventListener("paste", () => setTimeout(showAddressVerdict, 0));
      }
      form.addEventListener("submit", async (ev) => {
        ev.preventDefault();
        const url = ($("#conn-url").value || "").trim();
        const name = ($("#conn-name").value || "").trim();
        if (!url) return note("paste the calendar address first");
        const button = form.querySelector("button[type=submit]");
        button.disabled = true;
        note("reading it…");
        try {
          /* The server fetches it once before saving, so this answer is
             whether it actually works — not whether it looked plausible. */
          const out = await post("/api/connections", { url, name });
          $("#conn-url").value = ""; $("#conn-name").value = "";
          showAddressVerdict();
          note(`connected ${out.connection.name} — press Refresh to see what is on it`, true);
        } catch (err) {
          const fix = ((err.body || {}).error || {}).fix;
          note(err.message + (fix ? ` — ${fix}` : ""));
        }
        button.disabled = false;
        await renderConnections();
      });
    }
  }

  /* The hand-in switch. Its own renderer because it is the only control in
     Settings that turns on a WRITE to a school system, and it says what it is
     doing rather than just flipping. */
  async function renderSubmitSwitch() {
    const box = $("#submit-switch"), note = $("#submit-note");
    if (!box) return;                        /* the card is absent in some builds */
    let status = null;
    try { status = await api("/api/submit/status"); }
    catch (err) { if (note) note.textContent = `could not check (${err.message})`; return; }
    box.checked = !!status.enabled;
    if (note) {
      const done = (status.history || []).filter((h) => h.ok).length;
      note.textContent = status.enabled
        ? (done ? `on — ${done} handed in from here so far` : "on — nothing handed in yet")
        : "off — no assignment can be handed in from SillyBus AI while this is off";
    }
    box.onchange = async () => {
      box.disabled = true;
      try {
        await put("/api/submit/switch", { enabled: box.checked });
        await renderSubmitSwitch();
      } catch (err) {
        box.checked = !box.checked;
        if (note) note.textContent = `could not save that: ${err.message}`;
      }
      box.disabled = false;
    };
  }

  async function renderSettings() {
    /* 0.20: six pages. The per-class records (materials, notes, textbooks)
       are fetched once here so the Classes and Textbooks pages have them; the
       page that is open is drawn by showSetPage, which also draws Appearance
       from the ui block. The 0.18 renderAppearance() is retired below — it
       wrote localStorage and stamped <html> itself, and would have fought
       applyUiPrefs() over the same attributes. */
    if (window.loadCourseRecords) await window.loadCourseRecords();
    if (window.showSetPage) window.showSetPage(window.SET_PAGE_NOW ? window.SET_PAGE_NOW() : "classes");
    renderBoardPrefs();
    /* The format multi-select. It lives in app.js beside SECTIONS, which is
       the list it is a picker for — a second copy of that list here is how a
       picker and a board end up offering different formats. */
    if (window.renderMainPage) window.renderMainPage();
    /* Its own try: a failure reading the connections must not blank the rest
       of Settings, which is the same fault-isolation lesson as render(). */
    renderConnections().catch(() => {});
    renderSubmitSwitch().catch(() => {});
    renderCalendarExport().catch(() => {});
    await refreshSetup();
    accountsForm($("#accounts-form-host"), { saveLabel: "Save" });
    const s = SETUP || {};
    const c = s.canvas || {}, v = s.veracross || {};
    $("#connections-body").innerHTML = `
      <dt>Canvas</dt><dd class="${c.signed_in ? "ok-dot" : "bad-dot"}">${c.signed_in ? `signed in${c.name ? " as " + esc(c.name) : ""}` : "not signed in"}
        ${c.checked_at ? `<span class="muted"> (checked ${esc(c.checked_at.slice(0, 16).replace("T", " "))})</span>` : ""}</dd>
      <dt>Veracross</dt><dd class="${v.signed_in ? "ok-dot" : "warn-dot"}">${v.signed_in ? "signed in" : "not signed in or not checked yet"}</dd>
      <dt>Class schedule</dt><dd class="${v.class_feed ? "ok-dot" : "bad-dot"}">${v.class_feed ? `${v.meetings} class meetings on file` : "no feed saved"}</dd>
      <dt>Grades</dt><dd>${v.grades ? `${v.grades} courses` : "none read yet"}</dd>
      <dt>Classes</dt><dd>${(s.profiles || {}).count || 0} profiles${(s.profiles || {}).heuristic ? ` (${s.profiles.heuristic} unlearned)` : ""} · ${(s.courses || {}).reviewed || 0}/${(s.courses || {}).count || 0} reviewed</dd>`;
    const note = $("#settings-connect-note");
    $("#settings-connect").onclick = () => {
      SETUP_STEP = "extension_intro";
      showView("setup");
    };
    $("#settings-refresh").onclick = async () => { await refresh(); renderSettings(); };
    $("#settings-reminders").onclick = async () => {
      const b = $("#settings-reminders"); b.disabled = true;
      try { const out = await post("/api/setup/reminders", {}); note.textContent = out.message || "reminders scheduled (7am & 5pm, refresh every 30 min)"; }
      catch (err) { note.textContent = "could not schedule: " + err.message; }
      b.disabled = false;
    };
    let health = {};
    try { health = await api("/api/health"); } catch (e) { /* fine */ }
    const ps = (STATE && STATE.provider_status) || {};
    const upd = window.updateStatus && window.updateStatus();
    const updLine = !upd ? "not checked yet"
      : upd.available ? `<b>${esc(upd.latest)} is available</b>${upd.notes ? ` — ${esc(upd.notes)}` : ""}`
      : upd.error ? `could not check just now (${esc(upd.error)})`
      : upd.latest ? `up to date (latest published is ${esc(upd.latest)})`
      : "no published version to compare with yet";
    $("#app-body").innerHTML = `
      <dt>Version</dt><dd>${esc(health.version || "?")}
        <div class="muted" id="update-line">${updLine}</div>
        <div class="row-actions">
          <button type="button" class="ghost" id="update-check">Check for updates</button>
          ${upd && upd.available && upd.can_install
            ? `<button type="button" class="primary" id="update-now">Update to ${esc(upd.latest)}</button>` : ""}
        </div>
        <p class="note" id="update-settings-note"></p></dd>
      <dt>AI</dt><dd>${esc(health.provider === "hosted" ? "SillyBus AI included" : health.provider || "none")}${ps.model ? ` (${esc(ps.model)})` : ""}${ps.degraded ? ` <span class="warn-dot">fallback</span>` : ""}
        <div class="muted">Chat, learning a teacher's doc and Accelerate use it. Add your Anthropic API key under Extension options to turn it on; everything else works without.</div></dd>
      <dt>Data lives in</dt><dd><code>${esc(s.data_home || "")}</code></dd>
      <dt>Last pull</dt><dd>${esc(health.last_run || "never")}${health.stale_hours != null ? ` (${health.stale_hours} h ago)` : ""}</dd>
      <dt>Refreshes</dt><dd>when you open Silly Bus AI and when you press Refresh; your Chrome sign-in is used as it is</dd>`;
    try {
      const acct = await api("/api/session");
      const sub = acct.subscription || {};
      const allow = (STATE && STATE.allowance) || {};
      const kinds = allow.kinds || {};
      const line = (label, k) => {
        const row = kinds[k];
        if (!row || !allow.metered) return "";
        /* An unlimited allowance is `included: 0`, which read as
           "3 of 0 used this month · 0 left" — i.e. exhausted, on the plan
           where it is limitless. */
        if (row.unlimited) {
          return `<dt>${esc(label)}</dt><dd>${row.used} this month · not limited on this plan</dd>`;
        }
        return `<dt>${esc(label)}</dt><dd>${row.used} of ${row.included} used this month`
             + (row.exhausted ? ` · <span class="warn-dot">used up until the 1st</span>` : ` · ${row.left} left`)
             + `</dd>`;
      };
      const usage = allow.metered
        ? `${line("Chat", "chat")}${line("Study guides", "accelerate")}${line("Classes learned", "profiles")}`
        : `<dt>Usage</dt><dd>not limited — the model runs on your own Claude access, so nothing is counted</dd>`;
      /* What Free actually is, said where someone on it will look. Without
         this a lapsed account sees "Plan: Free" and no idea what that buys —
         and the half of the app that has no allowance at all is the half
         worth knowing about. */
      const free = (sub.plan === "free" && allow.metered)
        ? `<dt>On Free</dt><dd>${(kinds.chat || {}).included || 0} chat questions that need the
             assistant, ${(kinds.accelerate || {}).included || 0} study guides a month, and
             every class learned from its teacher's document. Resets on the 1st.
             <br>The board, its dates, your schedule, grades, links and ticking work off
             have no limit and never will — they need no AI.</dd>` : "";
      /* With SillyBus AI included, the Plan card above is the plan — the
         older Basic/Plus rows here would name a second price. */
      const hosted = health.provider === "hosted";
      $("#account-body").innerHTML = acct.configured
        ? `<dt>Status</dt><dd>${acct.signed_in ? `signed in as ${esc(acct.email)}${hosted ? "" : ` · ${esc(sub.state || "")}${sub.days_left != null ? ` (${sub.days_left} days left)` : ""}`}` : "not signed in"}</dd>
           ${hosted ? "" : `<dt>Plan</dt><dd>${esc(sub.plan_name || "Basic")}${sub.price && sub.plan !== "free" ? ` · $${esc(sub.price.amount)} a month` : ""}</dd>
           ${free}
           ${usage}`}
           <dt>Required</dt><dd>${acct.required ? "yes — the board asks for it" : "no — optional on this install"}</dd>
           ${acct.signed_in ? `<dt>Got a code?</dt><dd><input type="text" id="acct-code" placeholder="free-access code" autocomplete="off" style="max-width:12em">
             <button type="button" class="ghost" id="acct-code-use">Use code</button>
             <button type="button" class="ghost" id="acct-check">Check my plan</button>
             <span class="note" id="acct-note"></span></dd>
           <dt></dt><dd><button type="button" class="ghost" id="acct-out">Sign out</button></dd>` : ""}`
        : `<dt>Status</dt><dd>no account server configured — this is a solo install; nothing leaves this Mac</dd>`;
      /* Sign out closes the board at once — it used to stay on screen until
         the next minute's poll (prosecution round 3). */
      const out = $("#acct-out");
      if (out) out.onclick = async () => { await del("/api/session"); location.reload(); };
      /* The code box and "check my plan" lived only on the paywall, which a
         signed-in student never sees any more (a lapsed account keeps the
         board), so there was no way to use a free code at all (round 3). */
      const note = $("#acct-note");
      const say = (text) => { if (note) note.textContent = ` ${text}`; };
      const use = $("#acct-code-use");
      if (use) use.onclick = async () => {
        const code = ($("#acct-code").value || "").trim();
        if (!code) { $("#acct-code").focus(); return; }
        use.disabled = true;
        try {
          const res = await fetch("/api/session/redeem", { method: "POST",
            headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code }) });
          const got = await res.json();
          if (got.error) say(got.error.message || "that code did not work");
          else { say(got.message || "code accepted"); setTimeout(() => location.reload(), 1200); }
        } catch (e) { say("could not reach the account server"); }
        use.disabled = false;
      };
      const chk = $("#acct-check");
      if (chk) chk.onclick = async () => {
        chk.disabled = true;
        try {
          const res = await fetch("/api/session/refresh", { method: "POST" });
          const got = await res.json();
          const st = (got.subscription || {}).state;
          say(got.error ? (got.error.message || "could not check") : st ? `your plan: ${st}` : "checked");
          if (!got.error) renderSettings();
        } catch (e) { say("could not reach the account server"); }
        chk.disabled = false;
      };
      const check = $("#update-check");
      if (check) check.onclick = async () => {
        check.disabled = true;
        $("#update-line").textContent = "checking…";
        /* Pressing the button yourself is the one thing that undoes a
           "Later": you asked, so you get the answer even for a version you
           waved off earlier. */
        await window.checkUpdate(true, { ignoreDismissed: true });
        renderSettings();
        if (window.render) window.render();
      };
      const now = $("#update-now");
      if (now) now.onclick = () => window.runUpdateFromSettings(now, $("#update-settings-note"));
    } catch (e) { $("#account-body").innerHTML = `<dt>Status</dt><dd>unknown</dd>`; }
    try { await renderChrome(); } catch (e) { /* its own card, its own failure */ }
    try { await renderPlan(); } catch (e) { $("#plan-body").innerHTML = `<dt>Plan</dt><dd>could not check right now</dd>`; }
  }

  /* ---- SillyBus AI included: the plan ---------------------------------
     [ASKED] 2026-10-01: a free month, then $5 a month for the AI features
     (or $7 with Better Gmail), paid here — Stripe's own form, shown inside
     this card from SillyBus's checkout page, so nobody leaves SillyBus and
     the card never touches this computer. The owner's server answers every
     question; this only draws it. */
  const CHECKOUT_PAGE = "https://jomonkey22.github.io/better-gmail-site/checkout.html";
  const perMonth = (p) => String(p || "").replace(" a month", "/mo");
  const day = (ms) => new Date(ms).toLocaleDateString(undefined, { month: "long", day: "numeric" });
  async function renderPlan(recheck) {
    const box = $("#plan-body");
    if (!box) return;
    const p = await api("/api/plan" + (recheck ? "?recheck=1" : ""));
    if (!p.ok) { box.innerHTML = `<dt>Plan</dt><dd>${esc(p.error || "could not check right now")}</dd>`; return; }
    /* [ASKED] 2026-10-06: every account gets 10¢ of AI a month on the owner's
       key, and learning classes has its own pot on top. The card used to
       hide the amount whenever the state was "free" — which is everyone
       today — and still said the AI stops when the free month ends
       (prosecution 2026-10-06). */
    const u = p.usage || {};
    const cents = (n) => { n = Number(n || 0); return n > 0 && n < 0.01 ? "under 1¢" : n < 1 ? `${Math.round(n * 100)}¢` : `$${n.toFixed(2)}`; };
    const used = !u.unlimited && u.limit
      ? `<dt>AI this month</dt><dd>${cents(u.spent)} of ${cents(u.limit)} used · it comes back on the 1st</dd>` : "";
    const learning = u.learning && u.learning.limit
      ? `<dt>Learning classes</dt><dd>free, from its own ${cents(u.learning.limit)} a month (${cents(u.learning.spent)} used) — it never takes from the AI above</dd>` : "";
    const more = p.subscribe ? ` Subscribe for ${esc(p.price)} for more.` : "";
    const says = {
      free: p.promoUntil && !u.paying
        ? `SillyBus AI is free for everyone until ${new Date(p.promoUntil).toLocaleDateString(undefined, { month: "long", day: "numeric", timeZone: "UTC" })}: ${cents(u.limit)} of AI a month.`
        : u.paying ? "You're subscribed. Thank you!" : `Every month includes ${cents(u.limit)} of AI, free.${more}`,
      trial: `Free month: ${p.daysLeft} day${p.daysLeft === 1 ? "" : "s"} left, with ${cents(u.limit)} of AI a month.${more}`,
      paid: "You're subscribed. Thank you!",
      expired: `Your free month is over. You still get ${cents(u.limit)} of AI a month, free.${more}`,
    }[p.state] || "";
    const offers = (p.subscribe && (p.state === "trial" || p.state === "expired"))
      ? (p.plans || []).map((x) => `<button type="button" class="${x.id === "bundle" ? "ghost" : "primary"}" data-plan="${esc(x.id)}">${esc(x.id === "bundle" ? "Both apps: " + x.name : "Subscribe")} · ${esc(perMonth(x.price))}</button>`).join(" ")
      : "";
    box.innerHTML = `<dt>Status</dt><dd id="plan-says">${says}</dd>${used}${learning}
      <dt>Board</dt><dd>free, always — the homework board, dates, schedule and grades need no AI</dd>
      ${offers ? `<dt></dt><dd>${offers}</dd>` : ""}
      <dt></dt><dd><button type="button" class="ghost" id="plan-cancel" hidden>Cancel subscription</button><span class="note" id="plan-note"></span></dd>`;
    box.querySelectorAll("[data-plan]").forEach((b) => { b.onclick = () => openPlanCheckout(b.dataset.plan); });
    if (p.state === "paid") drawPlanSubscription(await api("/api/plan/subscription"));
  }
  function drawPlanSubscription(s) {
    const btn = $("#plan-cancel");
    if (!btn || !s || !s.ok || !s.subscribed) return;
    btn.hidden = false;
    const what = s.bundle ? "Better Gmail + SillyBus AI" : "SillyBus AI";
    $("#plan-says").textContent = s.cancelling
      ? `Your ${what} subscription ends on ${day(s.endsAt)}. It keeps working until then.`
      : `You're subscribed to ${what}. It renews on ${day(s.endsAt)}.`;
    btn.textContent = s.cancelling ? "Keep my subscription" : "Cancel subscription";
    btn.onclick = async () => {
      if (!s.cancelling && !confirm(`Cancel your ${what} subscription? ${s.bundle ? "This stops Better Gmail's AI too. " : ""}It stays on until ${day(s.endsAt)}, then stops. You won't be charged again.`)) return;
      btn.disabled = true;
      const out = await post("/api/plan/cancel", { resume: s.cancelling });
      btn.disabled = false;
      $("#plan-note").textContent = out.ok ? (s.cancelling ? " It will keep going." : " Cancelled — you won't be charged again.") : ` ${out.error || "That did not work."}`;
      if (out.ok) drawPlanSubscription(out);
    };
  }
  async function openPlanCheckout(plan) {
    const note = $("#plan-note");
    note.textContent = " Opening the payment form…";
    const s = await post("/api/plan/checkout", { plan });
    if (!s.ok) { note.textContent = ` ${s.error || "Could not open the payment form."}`; return; }
    note.textContent = "";
    const page = new URL(CHECKOUT_PAGE);
    const frame = $("#plan-frame");
    $("#plan-checkout").hidden = false;
    const onMessage = async (e) => {
      if (e.source !== frame.contentWindow || e.origin !== page.origin) return;
      const m = e.data || {};
      if (m.type === "bgx-ready") frame.contentWindow.postMessage({ type: "bgx-checkout", clientSecret: s.clientSecret, publishableKey: s.publishableKey }, page.origin);
      if (m.type === "bgx-height" && m.height > 200) frame.style.height = `${Math.min(m.height + 8, 1400)}px`;
      if (m.type === "bgx-paid") {
        note.textContent = " Payment received. Checking with Stripe…";
        for (let i = 0; i < 6; i++) {
          await new Promise((r) => setTimeout(r, i ? 4000 : 1500));
          const p = await api("/api/plan?recheck=1");
          if (p && p.state === "paid") break;
        }
        window.removeEventListener("message", onMessage);
        $("#plan-checkout").hidden = true;
        await renderPlan();
      }
    };
    window.addEventListener("message", onMessage);
    frame.src = page.href;
    frame.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  /* ---------------- CONNECT CHROME ----------------
     Three numbered steps, each with a button that does the fiddly half.

     The extension ships INSIDE the app (paths.chrome_extension_dir), so there
     is nothing to download, nothing to unzip, and nothing in Downloads to
     delete by accident — which would silently break the extension later,
     because Chrome remembers the folder it was loaded from. Step 2 opens
     Finder on that folder; step 1 copies the chrome:// URL, which cannot be
     opened by a link from a web page at all.

     The pairing code is not fetched until it is asked for: minting it is a
     decision, and a secret sitting in a page nobody asked for is a secret
     that ends up in a screenshot. */
  async function renderChrome() {
    const host = $("#chrome-body");
    if (!host) return;
    const bridge = (STATE && STATE.bridge) || {};
    const ext = bridge.extension || {};
    const held = Object.values(bridge.held || {})
      .reduce((total, rows) => total + rows.length, 0);

    host.innerHTML = `
      <p class="muted cx-lead">Start in the Chrome you already use: open your school or calendar page, click the top-right SillyBus extension and Connect. Pair it below to bring supported school pages into this Mac app.</p>

      <ol class="cx-steps">
        <li><b>Open Chrome's extensions page.</b> Paste this into Chrome's
          address bar — a link cannot open it.
          <div class="cx-row"><code id="cx-url">chrome://extensions</code>
            <button type="button" class="ghost" id="cx-copy-url">Copy</button></div>
          Turn on <b>Developer mode</b> (top right).</li>

        <li><b>Click “Load unpacked” and pick this folder.</b>
          ${ext.present ? `<div class="cx-row">
              <button type="button" class="primary" id="cx-reveal">Show me the folder</button>
              <span class="muted">it is already on this Mac — nothing to download</span>
            </div>
            <code class="cx-path" id="cx-path">${esc(ext.folder)}</code>
            <button type="button" class="ghost" id="cx-copy-path">Copy the path</button>`
          : `<div class="cx-row">
              <a class="linkbtn" href="${esc(EXT_URL)}" target="_blank" rel="noopener">Download it</a>
              <span class="muted">this build does not carry it — unzip it and pick that folder</span>
            </div>`}</li>

        <li><b>It connects automatically.</b> Keep the Mac app running and approve Chrome's local app access if asked. If sign-in is required, open this app's Settings page in Chrome and sign in.
          <div class="cx-row"><a class="linkbtn" href="http://127.0.0.1:5055/settings" target="_blank" rel="noopener">Open app Settings in Chrome</a>
          ${bridge.paired ? `<button type="button" class="ghost" id="cx-unpair">Unpair</button>` : ""}</div>
          One extension handles everything; there is no code to copy.</li>
      </ol>

      <p class="muted cx-note">${
        held ? `Working. ${held} page${held === 1 ? "" : "s"} handed over; each
                counts as current for ${esc(String(bridge.fresh_minutes || 240))}
                minutes, and after that SillyBus AI fetches it itself as before.`
        : bridge.paired
        ? `Mac connection is ready. Nothing has been handed over yet — connect the extension through its popup, then press <b>Send my school pages to the Mac app</b>. Until then SillyBus AI
           keeps signing in for itself, exactly as before.`
        : "Not set up yet. Nothing changes until you do this — the app keeps "
          + "signing in for itself."
      }</p>`;

    const copyTo = (button, text, done) => {
      if (!button) return;
      button.onclick = async () => {
        try {
          await navigator.clipboard.writeText(text);
          button.textContent = done;
        } catch (e) {
          /* Clipboard access gets refused often enough to need a real answer
             — an insecure origin, a stale gesture, a locked-down profile. */
          button.textContent = "select it and press ⌘C";
        }
      };
    };
    copyTo($("#cx-copy-url"), "chrome://extensions", "Copied");
    copyTo($("#cx-copy-path"), ext.folder || "", "Copied");

    const reveal = $("#cx-reveal");
    if (reveal) reveal.onclick = async () => {
      reveal.disabled = true;
      try {
        await post("/api/bridge/reveal", {});
        reveal.textContent = "Finder is showing it";
      } catch (err) {
        reveal.textContent = "copy the path instead";
      } finally { reveal.disabled = false; }
    };

    const unpair = $("#cx-unpair");
    if (unpair) unpair.onclick = async () => {
      if (unpair.dataset.armed !== "yes") {
        unpair.dataset.armed = "yes";
        unpair.textContent = "Really unpair?";
        return;
      }
      await del("/api/bridge/pair");
      await loadState();
      renderChrome();
    };
  }

  /* ---------------- ACCELERATE ---------------- */
  function md(text) {
    /* A small Markdown renderer. Escapes everything first, so model output can
       never inject markup; then headings, lists, tables, fences, quotes,
       bold/italic/code and http links. */
    const lines = String(text || "").replace(/\r/g, "").split("\n");
    let html = "", i = 0;
    const inline = (s) => esc(s)
      .replace(/`([^`]+)`/g, "<code>$1</code>")
      .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
      .replace(/(^|[\s(])\*([^*\n]+)\*/g, "$1<em>$2</em>")
      .replace(/(^|[\s(])_([^_\n]+)_/g, "$1<em>$2</em>")
      .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
    while (i < lines.length) {
      const line = lines[i];
      if (/^\s*```/.test(line)) {
        const buf = []; i++;
        while (i < lines.length && !/^\s*```/.test(lines[i])) buf.push(lines[i++]);
        i++; html += `<pre><code>${esc(buf.join("\n"))}</code></pre>`; continue;
      }
      const h = line.match(/^\s*(#{1,4})\s+(.*)$/);
      if (h) { const lvl = Math.min(h[1].length + 1, 4); html += `<h${lvl}>${inline(h[2])}</h${lvl}>`; i++; continue; }
      if (/^\s*\|.*\|\s*$/.test(line) && i + 1 < lines.length && /^\s*\|[\s:|-]+\|\s*$/.test(lines[i + 1])) {
        const cells = (l) => l.trim().replace(/^\||\|$/g, "").split("|").map((c) => c.trim());
        const head = cells(line); i += 2;
        let rows = "";
        while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) rows += `<tr>${cells(lines[i++]).map((c) => `<td>${inline(c)}</td>`).join("")}</tr>`;
        html += `<table><thead><tr>${head.map((c) => `<th>${inline(c)}</th>`).join("")}</tr></thead><tbody>${rows}</tbody></table>`; continue;
      }
      if (/^\s*[-*+]\s+/.test(line)) {
        let items = "";
        while (i < lines.length && /^\s*[-*+]\s+/.test(lines[i])) items += `<li>${inline(lines[i++].replace(/^\s*[-*+]\s+/, ""))}</li>`;
        html += `<ul>${items}</ul>`; continue;
      }
      if (/^\s*\d+[.)]\s+/.test(line)) {
        let items = "";
        while (i < lines.length && /^\s*\d+[.)]\s+/.test(lines[i])) items += `<li>${inline(lines[i++].replace(/^\s*\d+[.)]\s+/, ""))}</li>`;
        html += `<ol>${items}</ol>`; continue;
      }
      if (/^\s*>\s?/.test(line)) {
        let buf = [];
        while (i < lines.length && /^\s*>\s?/.test(lines[i])) buf.push(lines[i++].replace(/^\s*>\s?/, ""));
        html += `<blockquote>${inline(buf.join(" "))}</blockquote>`; continue;
      }
      if (!line.trim()) { i++; continue; }
      let buf = [];
      while (i < lines.length && lines[i].trim() && !/^\s*(#{1,4}\s|[-*+]\s|\d+[.)]\s|>|\||```)/.test(lines[i])) buf.push(lines[i++]);
      if (buf.length) html += `<p>${inline(buf.join(" "))}</p>`; else i++;
    }
    return html;
  }
  window.renderMarkdown = md;

  // Mermaid ships inside the app (static/vendor/, 11.17.2 from npm). Never a
  // CDN: the Chrome Web Store refuses remotely hosted code in an MV3 extension,
  // and the extension's CSP (script-src 'self') would block it anyway.
  let mermaidLoading = null;
  function loadMermaid() {
    if (window.mermaid) return Promise.resolve(window.mermaid);
    if (mermaidLoading) return mermaidLoading;
    mermaidLoading = new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = "/static/vendor/mermaid.min.js";
      s.onload = () => resolve(window.mermaid);
      s.onerror = () => { mermaidLoading = null; reject(new Error("mermaid did not load")); };
      document.head.appendChild(s);
    });
    return mermaidLoading;
  }

  async function drawVisuals(container) {
    const nodes = [...container.querySelectorAll(".mermaid[data-src]")];
    if (!nodes.length) return;
    try {
      const mermaid = await loadMermaid();
      const dark = document.documentElement.getAttribute("data-theme") === "dark"
        || (!document.documentElement.getAttribute("data-theme")
            && window.matchMedia("(prefers-color-scheme: dark)").matches);
      mermaid.initialize({ startOnLoad: false, theme: dark ? "dark" : "neutral", securityLevel: "strict" });
      for (const node of nodes) {
        node.textContent = node.dataset.src;
        node.removeAttribute("data-processed");
      }
      await mermaid.run({ nodes });
    } catch (err) {
      for (const node of nodes) {
        const pre = document.createElement("pre");
        pre.textContent = node.dataset.src;
        node.replaceWith(pre);
      }
    }
  }

  function accelHtml(saved) {
    const r = saved.result || {};
    const kindLabel = { reading: "reading", problem_set: "problem set", writing: "writing",
      test_prep: "test prep", project: "project", lab: "lab", discussion: "discussion", other: "assignment" }[r.kind] || r.kind;
    const visuals = (r.visuals || []).map((v, i) => {
      if (v.kind === "mermaid") return `<div class="visual"><div class="vis-title">${esc(v.title)}</div>
        <div class="mermaid" id="vis-${i}" data-src="${esc(v.code)}"></div></div>`;
      if (v.kind === "table") return `<div class="visual"><div class="vis-title">${esc(v.title)}</div><div class="md">${md(v.code)}</div></div>`;
      return `<div class="visual"><div class="vis-title">${esc(v.title)}</div><pre>${esc(v.code)}</pre></div>`;
    }).join("");
    const practice = (r.practice || []).map((p) => `<div class="practice"><div class="pr-prompt">${esc(p.prompt)}</div>
      ${Array.isArray(p.choices) && p.choices.length ? `<ol class="pr-choices">${p.choices.map((c) => `<li>${esc(c)}</li>`).join("")}</ol>` : ""}
      ${p.hint ? `<details><summary>hint</summary><div>${esc(p.hint)}</div></details>` : ""}
      ${p.answer ? `<details><summary>answer / worked pattern</summary><div class="md">${md(p.answer)}</div></details>` : ""}</div>`).join("");
    const terms = (r.key_terms || []).map((t) => `<div class="term"><b>${esc(t.term)}</b><span>${esc(t.meaning)}</span></div>`).join("");
    const tabs = [
      ["guide", "Guide", `<div class="md">${md(r.guide_markdown)}</div>${visuals}`],
      ["practice", r.kind === "problem_set" ? "How to do the problems" : "Check yourself", practice || `<div class="muted">nothing here</div>`],
      ["terms", "Key terms", terms || `<div class="muted">none</div>`],
      ["watch", "Watch out", (r.watch_out || []).length ? `<ul>${r.watch_out.map((w) => `<li>${esc(w)}</li>`).join("")}</ul>` : `<div class="muted">none</div>`],
    ];
    const minutes = Number(r.time_estimate_minutes) > 0
      ? ` · about ${esc(String(r.time_estimate_minutes))} min` : "";
    return `<div class="accel-kicker">${esc(kindLabel)}${minutes}</div>
      <div class="accel-headline">${esc(r.headline || "")}</div>
      <ul class="accel-tldr">${(r.tldr || []).map((t) => `<li>${esc(t)}</li>`).join("")}</ul>
      ${(r.not_available || []).length ? `<div class="accel-warn">Could not read: ${esc(r.not_available.join("; "))}. The parts that depend on it are general, not from the material.</div>` : ""}
      <div class="accel-tabs">${tabs.map(([k, label], i) => `<button type="button" data-tab="${k}" class="${i === 0 ? "active" : ""}">${esc(label)}</button>`).join("")}</div>
      ${tabs.map(([k, , body], i) => `<div class="accel-tab" data-tab="${k}" ${i === 0 ? "" : "hidden"}>${body}</div>`).join("")}
      <div class="accel-foot">Read: ${esc((r.sources_used || []).join("; ") || "nothing linked — from the title and class only")}.
        Written ${esc((r.generated_at || saved.created || "").slice(0, 16).replace("T", " "))} by ${esc(saved.provider || "the AI")}.
        Checks the material, not your teacher — when they disagree, the teacher wins.</div>`;
  }

  async function openAccelerate(itemId, title) {
    ACCEL_ITEM = itemId;
    const body = $("#accel-body");
    window.showPane("accel");
    $("#accel-title").textContent = "⚡ " + (title || "Accelerated").slice(0, 60);
    body.innerHTML = `<div class="accel-status">looking for a saved guide…</div>`;
    const item = (STATE.items || []).find((i) => i.item_id === itemId);
    if (item && window.setChatContext) window.setChatContext({ itemId, label: item.title.slice(0, 50) });
    let saved = null;
    try { saved = await api(`/api/accelerate/${itemId}`); } catch (e) { saved = null; }
    if (ACCEL_ITEM !== itemId) return;
    if (saved) { body.innerHTML = accelHtml(saved); wireAccel(body); return; }
    await generateAccel(itemId, false);
  }
  window.openAccelerate = openAccelerate;

  /* The thinking, on screen, while it is happening.

     [ASKED] 2026-09-20: "i want it to show thinking while an accelerate is
     being made". What was here before was one fixed sentence and a <div> that
     collected the job's progress lines as raw text — no shape, nothing moving,
     and in the Chrome extension not even that, because the extension has no
     threads: the POST does not answer until the guide is finished, so every
     line landed at once after the wait was over. The lines now also arrive
     live through the sd-progress event the extension pushes out mid-work
     (sillybus/web/progress.py), and they are drawn as a list that grows, with
     an elapsed clock so a long one plainly reads as working rather than
     stuck. */
  function thinkingShell(title) {
    return `<div class="accel-think">
      <div class="think-head"><span class="bolt spin">⚡</span>
        <b>Writing your guide</b><em class="think-clock">0:00</em></div>
      <div class="think-sub">${esc(title || "reading the assignment")} — usually 30–90 seconds</div>
      <ol class="think-lines"></ol></div>`;
  }

  async function generateAccel(itemId, force) {
    const body = $("#accel-body");
    const item = (STATE.items || []).find((i) => i.item_id === itemId);
    const title = item ? item.title : "";
    body.innerHTML = thinkingShell(title);
    const list = body.querySelector(".think-lines");
    const clock = body.querySelector(".think-clock");
    const began = Date.now();
    const tick = setInterval(() => {
      if (!clock.isConnected) { clearInterval(tick); return; }
      const secs = Math.round((Date.now() - began) / 1000);
      clock.textContent = `${Math.floor(secs / 60)}:${String(secs % 60).padStart(2, "0")}`;
    }, 1000);

    let last = "";
    const say = (text) => {
      const line = String(text || "").trim();
      if (!line || line === last) return;     // the extension can echo a line
      last = line;
      if (list && list.isConnected) {
        const prev = list.querySelector("li.now");
        if (prev) prev.classList.remove("now");
        const li = document.createElement("li");
        li.className = "now";
        li.textContent = line;
        list.appendChild(li);
        li.scrollIntoView({ block: "nearest" });
      }
      if (window.accelLiveLine) window.accelLiveLine(line);
    };

    if (window.accelLiveStart) window.accelLiveStart(itemId, title);
    /* Lines the extension pushes out of its worker while it is blocked. */
    const onProgress = (ev) => {
      const d = ev.detail || {};
      if (d.kind === `accelerate:${itemId}` && !d.done) say(d.line);
    };
    window.addEventListener("sd-progress", onProgress);
    const stop = () => {
      clearInterval(tick);
      window.removeEventListener("sd-progress", onProgress);
    };

    try {
      const saved = await pollJob(await post(`/api/accelerate/${itemId}`, { force }), say);
      stop();
      if (window.accelLiveEnd) window.accelLiveEnd("");
      if (ACCEL_ITEM !== itemId) return;
      body.innerHTML = accelHtml(saved);
      wireAccel(body);
    } catch (err) {
      stop();
      if (window.accelLiveEnd) window.accelLiveEnd(err.message);
      if (ACCEL_ITEM !== itemId) return;
      body.innerHTML = `<div class="accel-warn">${esc(err.message)}</div>
        <button type="button" class="ghost" id="accel-retry">Try again</button>`;
      $("#accel-retry").onclick = () => generateAccel(itemId, true);
    }
  }

  function wireAccel(body) {
    body.querySelectorAll(".accel-tabs button").forEach((b) => b.addEventListener("click", () => {
      body.querySelectorAll(".accel-tabs button").forEach((x) => x.classList.toggle("active", x === b));
      body.querySelectorAll(".accel-tab").forEach((t) => { t.hidden = t.dataset.tab !== b.dataset.tab; });
      drawVisuals(body);
    }));
    drawVisuals(body);
  }
  $("#accel-close").addEventListener("click", () => {
    const back = ACCEL_ITEM;
    ACCEL_ITEM = null;
    if (back && (STATE.items || []).some((i) => i.item_id === back)) window.openDetail(back);
    else window.showPane("home");
  });
  $("#accel-regenerate").addEventListener("click", () => { if (ACCEL_ITEM) generateAccel(ACCEL_ITEM, true); });

  /* ---------------- practice quizzes ----------------
     [ASKED] 2026-09-28: *"make silly bus be able to create quizes for the
     usser and a way to uplod the quiz the teacher actually gave ... so it
     makes quizes that would be closer to the questions on the test"*.

     The pane has three states: the list of quizzes for a class (with the
     button that makes another), the thinking shell while one is written,
     and the quiz itself — one question at a time is not used, deliberately:
     a real quiz is a page you can look over, so this is too. Multiple-choice
     and true/false are marked here; a short answer is shown beside the
     model answer for the student to judge, because a regex marking prose
     would be wrong often enough to be worse than nothing. */
  let QUIZ_COURSE = null;
  let QUIZ_ITEM = null;
  let QUIZ = null;            // the open quiz
  let QUIZ_RESULT = null;     // the last marked attempt

  function quizListHtml(rows, summary) {
    const teach = summary ? `<div class="quiz-teach">
      <b>This teacher's past quizzes:</b> ${summary.quizzes || 0} on file${summary.unread_photos
        ? ` (${summary.unread_photos} photo${summary.unread_photos === 1 ? "" : "s"} not read yet — read the first time a quiz is made)` : ""}.
      <a href="#" class="quiz-teach-link">Add one</a> — every quiz you add makes the practice ones closer to the real thing.</div>` : "";
    return `${teach}
      <div class="quiz-make">
        <input type="text" id="quiz-topic" class="field" placeholder="${esc(QUIZ_ITEM ? "about this assignment (or type a topic)" : "topic, e.g. chapter 3 cells")}">
        <select id="quiz-count" class="field"><option value="5">5 questions</option><option value="8" selected>8 questions</option><option value="12">12 questions</option><option value="20">20 questions</option></select>
        <button type="button" class="primary" id="quiz-make">Make a practice quiz</button>
      </div>
      ${rows.length ? `<div class="quiz-list">${rows.map((q) => `
        <button type="button" class="quizrow" data-quiz="${esc(q.id)}">
          <span class="qr-title">${esc(q.title)}</span>
          <span class="qr-meta">${esc((q.created || "").slice(0, 10))} · ${q.questions} questions${
            q.examples_used ? ` · in this teacher's style (${q.examples_used})` : " · general"}${
            q.attempts ? ` · best ${q.best_percent == null ? "self-marked" : q.best_percent + "%"} in ${q.attempts} go${q.attempts === 1 ? "" : "es"}` : ""}</span>
        </button>`).join("")}</div>` : `<div class="muted">No practice quizzes for this class yet.</div>`}`;
  }

  function quizHtml(quiz, result) {
    const r = quiz.result || {};
    const marks = {};
    for (const row of (result && result.rows) || []) marks[row.n] = row;
    const qs = (r.questions || []).map((q, n) => {
      const m = marks[n];
      const verdict = m ? m.verdict : "";
      let input = "";
      if (q.kind === "mc" || q.kind === "tf") {
        input = `<div class="qz-choices">${(q.choices || []).map((c, i) => {
          const letter = q.kind === "tf" ? c : String.fromCharCode(65 + i);
          const checked = m && m.given && m.given.replace(/^\(/, "").toLowerCase().startsWith(letter.toLowerCase()) ? "checked" : "";
          return `<label class="qz-choice"><input type="radio" name="q${n}" value="${esc(letter)}" ${checked} ${m ? "disabled" : ""}> <span>${esc(c)}</span></label>`;
        }).join("")}</div>`;
      } else {
        input = `<textarea class="field qz-short" name="q${n}" rows="2" placeholder="your answer" ${m ? "disabled" : ""}>${esc(m ? m.given : "")}</textarea>`;
      }
      const after = m ? `<div class="qz-after qz-${esc(verdict)}">
          ${verdict === "right" ? "✓ right" : verdict === "wrong" ? `✗ the answer is <b>${esc(m.answer)}</b>` : `model answer: <b>${esc(m.answer)}</b> — you decide`}
          ${m.why ? `<div class="kv">${esc(m.why)}</div>` : ""}</div>` : "";
      return `<div class="qz-q${m ? " marked" : ""}">
        <div class="qz-prompt"><span class="qz-n">${n + 1}.</span> ${esc(q.prompt)}${q.like && q.like !== "general" ? ` <span class="kv" title="the example quiz this question's style follows">like ${esc(q.like)}</span>` : ""}</div>
        ${input}${after}</div>`;
    }).join("");
    const score = result ? `<div class="qz-score"><b>${result.marked ? `${result.right} of ${result.marked} right${result.percent != null ? ` · ${result.percent}%` : ""}` : "marked"}</b>${
      result.self_marked ? ` · ${result.self_marked} short answer${result.self_marked === 1 ? "" : "s"} for you to judge` : ""}</div>` : "";
    return `<div class="quiz">
      <div class="accel-kicker">${esc(r.course || "")}${r.item_title ? ` · ${esc(r.item_title)}` : ""}</div>
      <div class="accel-headline">${esc(r.title || "Practice quiz")}</div>
      ${r.style_notes ? `<div class="qz-style">${esc(r.style_notes)}</div>` : ""}
      ${score}
      <form id="quiz-form">${qs}
        <div class="qz-acts">
          ${result ? `<button type="button" class="primary" id="quiz-again">Try it again</button>` : `<button type="submit" class="primary">Mark it</button>`}
          <button type="button" class="ghost" id="quiz-back">All quizzes</button>
        </div></form>
      <div class="accel-foot">Based on: ${esc((r.based_on || []).join("; ") || "general knowledge of the topic")}.
        ${r.examples_used ? `Written in this teacher's style from ${r.examples_used} of their past quizzes.` : "No past quizzes from this teacher were on file — add one under the class to get closer to the real thing."}
        Practice only: nothing here touches a grade.</div>
    </div>`;
  }

  async function openQuiz(courseKey, itemId, quizId) {
    QUIZ_COURSE = courseKey; QUIZ_ITEM = itemId || null; QUIZ = null; QUIZ_RESULT = null;
    window.showPane("quiz");
    $("#quiz-title").textContent = "📝 " + (courseName(courseKey) || "Practice quiz").slice(0, 50);
    if (quizId) { await showQuiz(quizId); return; }
    await renderQuizList();
  }
  window.openQuiz = openQuiz;

  async function renderQuizList() {
    const body = $("#quiz-body");
    body.innerHTML = `<div class="accel-status">looking for quizzes…</div>`;
    let rows = [], summary = null;
    try { rows = (await api(`/api/quizzes?course_key=${encodeURIComponent(QUIZ_COURSE)}`)).quizzes || []; } catch (e) { rows = []; }
    try { summary = (await api(`/api/teacher/${encodeURIComponent(QUIZ_COURSE)}`)).summary; } catch (e) { summary = null; }
    body.innerHTML = quizListHtml(rows, summary);
    $("#quiz-make").onclick = () => makeQuiz();
    body.querySelectorAll(".quizrow").forEach((b) => b.onclick = () => showQuiz(b.dataset.quiz));
    const teach = body.querySelector(".quiz-teach-link");
    if (teach) teach.onclick = (ev) => { ev.preventDefault(); SELECTED_COURSE = QUIZ_COURSE; showView("classes"); };
  }

  async function makeQuiz() {
    const body = $("#quiz-body");
    const topic = ($("#quiz-topic") || {}).value || "";
    const count = Number(($("#quiz-count") || {}).value || 8);
    body.innerHTML = thinkingShell(topic || "this teacher's style").replace("Writing your guide", "Writing your quiz");
    const list = body.querySelector(".think-lines");
    const say = (text) => {
      const line = String(text || "").trim();
      if (!line || !list) return;
      const li = document.createElement("li"); li.textContent = line; list.appendChild(li);
    };
    const onProgress = (ev) => { const d = ev.detail || {}; if (String(d.kind || "").startsWith(`quiz:${QUIZ_COURSE}:`) && !d.done) say(d.line); };
    window.addEventListener("sd-progress", onProgress);
    try {
      const quiz = await pollJob(await post("/api/quiz", { course_key: QUIZ_COURSE, item_id: QUIZ_ITEM, topic, count }), say);
      window.removeEventListener("sd-progress", onProgress);
      QUIZ = quiz; QUIZ_RESULT = null;
      body.innerHTML = quizHtml(quiz, null);
      wireQuiz();
    } catch (err) {
      window.removeEventListener("sd-progress", onProgress);
      body.innerHTML = `<div class="accel-warn">${esc(err.message)}</div>
        <button type="button" class="ghost" id="quiz-retry">Back</button>`;
      $("#quiz-retry").onclick = () => renderQuizList();
    }
  }

  async function showQuiz(quizId) {
    const body = $("#quiz-body");
    body.innerHTML = `<div class="accel-status">opening…</div>`;
    try { QUIZ = await api(`/api/quiz/${encodeURIComponent(quizId)}`); }
    catch (err) { body.innerHTML = `<div class="accel-warn">${esc(err.message)}</div>`; return; }
    QUIZ_RESULT = null;
    body.innerHTML = quizHtml(QUIZ, null);
    wireQuiz();
  }

  function wireQuiz() {
    const body = $("#quiz-body");
    const form = $("#quiz-form");
    if (form) form.onsubmit = async (ev) => {
      ev.preventDefault();
      const answers = {};
      (QUIZ.result.questions || []).forEach((q, n) => {
        if (q.kind === "short") answers[String(n)] = (form.querySelector(`[name=q${n}]`) || {}).value || "";
        else { const on = form.querySelector(`[name=q${n}]:checked`); answers[String(n)] = on ? on.value : ""; }
      });
      try {
        QUIZ_RESULT = await post(`/api/quiz/${encodeURIComponent(QUIZ.id)}/attempt`, { answers });
        body.innerHTML = quizHtml(QUIZ, QUIZ_RESULT);
        wireQuiz();
        body.scrollTop = 0;
      } catch (err) { alert(err.message); }
    };
    const again = $("#quiz-again");
    if (again) again.onclick = () => { QUIZ_RESULT = null; body.innerHTML = quizHtml(QUIZ, null); wireQuiz(); };
    const back = $("#quiz-back");
    if (back) back.onclick = () => renderQuizList();
  }
  $("#quiz-close").addEventListener("click", () => {
    const item = QUIZ_ITEM;
    QUIZ = null;
    if (item && (STATE.items || []).some((i) => i.item_id === item)) window.openDetail(item);
    else if (QUIZ_COURSE) { SELECTED_COURSE = QUIZ_COURSE; showView("classes"); }
    else window.showPane("home");
  });

  /* ---------------- chat extras ---------------- */
  const input = $("#chat-input");
  document.querySelectorAll(".chat-chips .chip-btn[data-fill]").forEach((b) =>
    b.addEventListener("click", () => { input.value = b.dataset.fill; input.focus(); }));
  const teacher = $("#chat-teacher");
  if (teacher) teacher.addEventListener("click", () => {
    input.value = "Teacher said: ";
    input.placeholder = "e.g. Teacher said: read chapter 4 by Friday";
    input.focus();
  });
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const mic = $("#chat-mic");
  if (mic && Recognition) {
    mic.hidden = false;
    let rec = null;
    mic.addEventListener("click", () => {
      if (rec) { rec.stop(); return; }
      rec = new Recognition();
      rec.lang = "en-US"; rec.interimResults = true; rec.continuous = false;
      const base = input.value ? input.value.replace(/\s*$/, " ") : "";
      mic.classList.add("listening"); mic.textContent = "■";
      rec.onresult = (ev) => {
        let text = "";
        for (const res of ev.results) text += res[0].transcript;
        input.value = base + text;
      };
      // In the Mac app (its user agent ends "SillyBusMac/<version>") a
      // refusal is macOS's: say where to switch it back on. "service-not-
      // allowed" means speech recognition is unavailable on this Mac at all,
      // so the button goes rather than failing on every press.
      rec.onerror = (ev) => {
        const err = (ev && ev.error) || "";
        const mac = navigator.userAgent.includes("SillyBusMac");
        if (err === "service-not-allowed") mic.hidden = true;
        input.placeholder = err === "not-allowed" && mac
          ? "allow Silly Bus AI the microphone in System Settings → Privacy & Security, or type instead"
          : "the microphone did not work — type instead";
      };
      rec.onend = () => { mic.classList.remove("listening"); mic.textContent = "🎙"; rec = null; input.focus(); };
      rec.start();
    });
  }

  /* ---------------- the jump palette (⌘K) ----------------
     Type a few letters, land on an assignment, a class or a page. Every
     entry is something already on the screen; the palette only saves the
     hunt. */
  const palette = $("#palette");
  const pInput = $("#palette-input");
  const pList = $("#palette-list");
  let pIndex = 0;
  function paletteEntries(q) {
    q = q.trim().toLowerCase();
    const entries = [];
    const pages = [["chat", "Chat", "page"], ["classes", "Classes", "page"], ["done", "Done", "page"],
                   ["settings", "Settings", "page"], ["add", "Add something", "page"]];
    for (const [key, label] of pages) entries.push({ kind: "page", label, sub: "", key, icon: "▸" });
    entries.push({ kind: "action", label: "Refresh", sub: "pull Canvas, docs and grades now", icon: "⟳", run: () => refresh() });
    entries.push({ kind: "action", label: "Toggle night mode", sub: "", icon: "◐", run: () => $("#theme-toggle").click() });
    for (const g of (STATE && STATE.grades) || []) {
      entries.push({ kind: "class", label: shortCourse(g.display_name), icon: "◔",
        // A letter-only grade ("A", "P") is a grade: say the letter, not
        // "not graded yet". (prosecution round 4, 2026-10-07)
        sub: g.graded && g.percent != null ? `${g.letter || ""} ${g.percent.toFixed(1)}%`
          : g.graded && g.letter ? g.letter : "not graded yet",
        run: () => openGradePane(g.course_key) });
    }
    for (const i of (STATE && STATE.items) || []) {
      if (i.done) continue;
      entries.push({ kind: "item", label: i.title, icon: "•",
        sub: `${shortCourse(i.course)} · ${i.due_date ? SD.relDays(i.due_date, STATE.today) : "no date"}`,
        run: () => window.openDetail(i.item_id) });
    }
    if (!q) return entries.slice(0, 14);
    const score = (e) => {
      const t = (e.label + " " + e.sub).toLowerCase();
      if (t.startsWith(q)) return 3;
      if (t.includes(q)) return 2;
      return q.split(/\s+/).every((w) => t.includes(w)) ? 1 : 0;
    };
    return entries.map((e) => [score(e), e]).filter(([s]) => s > 0).sort((a, b) => b[0] - a[0]).map(([, e]) => e).slice(0, 14);
  }
  function renderPalette() {
    const entries = paletteEntries(pInput.value);
    pIndex = Math.max(0, Math.min(pIndex, entries.length - 1));
    pList.innerHTML = entries.length ? entries.map((e, i) => `<button type="button" class="palette-row${i === pIndex ? " active" : ""}" data-i="${i}">
      <span>${esc(e.icon)}</span><span>${esc(e.label)}${e.sub ? ` <small>${esc(e.sub)}</small>` : ""}</span><span class="pr-kind">${esc(e.kind)}</span></button>`).join("")
      : `<div class="empty-note">nothing matches</div>`;
    pList.querySelectorAll(".palette-row").forEach((b) => b.addEventListener("click", () => pick(entries[Number(b.dataset.i)])));
    pList._entries = entries;
  }
  function pick(entry) {
    closePalette();
    if (!entry) return;
    if (entry.run) entry.run();
    else if (entry.kind === "page") showView(entry.key);
  }
  function openPalette() {
    if (!palette) return;
    palette.hidden = false; pInput.value = ""; pIndex = 0; renderPalette(); pInput.focus();
  }
  function closePalette() { if (palette) palette.hidden = true; }
  if (palette) {
    $("#palette-open").addEventListener("click", openPalette);
    palette.addEventListener("click", (ev) => { if (ev.target === palette) closePalette(); });
    pInput.addEventListener("input", () => { pIndex = 0; renderPalette(); });
    pInput.addEventListener("keydown", (ev) => {
      const entries = pList._entries || [];
      if (ev.key === "ArrowDown") { ev.preventDefault(); pIndex = Math.min(pIndex + 1, entries.length - 1); renderPalette(); }
      else if (ev.key === "ArrowUp") { ev.preventDefault(); pIndex = Math.max(pIndex - 1, 0); renderPalette(); }
      else if (ev.key === "Enter") { ev.preventDefault(); pick(entries[pIndex]); }
      else if (ev.key === "Escape") { ev.preventDefault(); closePalette(); }
    });
    document.addEventListener("keydown", (ev) => {
      if ((ev.metaKey || ev.ctrlKey) && ev.key.toLowerCase() === "k") { ev.preventDefault(); palette.hidden ? openPalette() : closePalette(); }
    });
  }

  /* ---------------- boot ---------------- */
  const initial = __sdPath().replace("/", "") || "home";
  refreshSetup().then(() => {
    if (initial === "home" && SETUP && !SETUP.complete
        && !step("accounts").done && !step("connect").done) {
      // a brand-new install: open the wizard straight away
      showView("setup", false); history.replaceState({ view: "setup" }, "", "/setup");
    }
  });
  showView(VIEWS.includes(initial) ? initial : "home", false);
  loadCourses();
  setInterval(() => { if (!document.hidden && CURRENT === "chat") refreshSetup(); }, 120000);
})();
