// School-page courier integrated into the single SillyBus AI extension.
const APP = "http://127.0.0.1:5055";
const ALARM = "sillybus-sweep";

/* Must agree with bridge.ALLOWED_HOSTS in the app. Checked on both sides on
 * purpose: the app is the party that could be wrong. */
const ALLOWED = [".instructure.com", "portals.veracross.com",
                 "portals-embed.veracross.com", "documents.veracross.com",
                 "docs.google.com", "drive.google.com"];

function hostAllowed(url) {
  let parsed;
  try { parsed = new URL(url); } catch (err) { return false; }
  if (parsed.protocol !== "https:") return false;
  const host = parsed.hostname.toLowerCase();
  return ALLOWED.some((ok) => host === ok || host.endsWith(ok));
}

async function token() {
  const saved = await chrome.storage.local.get(["macCalendarToken", "token"]);
  return saved.macCalendarToken || saved.token || "";
}

/* ---------------- talking to the app ---------------- */

async function ask(pairing) {
  const response = await fetch(`${APP}/api/bridge/status`, {
    headers: { "X-SillyBus-Token": pairing } });
  if (response.status === 403) {
    throw new Error("that pairing code is not this Mac's — copy it again "
      + "from Silly Bus AI Settings");
  }
  if (!response.ok) throw new Error(`the app answered ${response.status}`);
  return await response.json();
}

async function send(kind, key, page, url, pairing) {
  const response = await fetch(`${APP}/api/bridge/capture`, {
    method: "POST",
    headers: { "Content-Type": "application/json",
               "X-SillyBus-Token": pairing },
    /* `headers` carries the two the app keeps (bridge.KEPT_HEADERS), and
       `link` is not a nicety: Canvas paginates through it and nothing else
       says how many pages there are, so a capture without it serves page one
       and silently loses the rest. */
    body: JSON.stringify({ kind, key, body: page.body, url,
                           headers: page.headers }),
  });
  let payload = {};
  try { payload = await response.json(); } catch (err) { /* not JSON */ }
  if (!response.ok || payload.error) {
    throw new Error((payload.error && payload.error.message)
      || `the app answered ${response.status}`);
  }
  return payload.saved;
}

/* ---------------- reading the school's pages ---------------- */

/* `credentials: "include"` is the whole reason this extension exists: the
 * cookies already in this profile. Without it the fetch is anonymous and
 * Veracross answers with a sign-in screen — which would then be posted back
 * and parsed as a gradebook holding no marks. So a reply that is plainly a
 * login page is refused here rather than handed on. */
async function grab(url) {
  const response = await fetch(url, {
    credentials: "include",
    redirect: "follow",
    headers: { "Accept": "text/html,application/json;q=0.9,*/*;q=0.8" },
  });
  if (!response.ok) throw new Error(`answered ${response.status}`);
  const text = await response.text();
  const head = text.slice(0, 4000);
  if (/id="?username|Sign in with Google|<title>[^<]*(Log ?in|Sign ?in)/i.test(head)) {
    throw new Error("came back as a sign-in screen — open it in a tab, "
      + "sign in, then try again");
  }
  if (!text.trim()) throw new Error("came back empty");
  return { body: text, headers: {
    link: response.headers.get("link") || "",
    "content-type": response.headers.get("content-type") || "",
  } };
}

/* How long the overlay's copy of the board is good for; see `board()`. */
const BOARD_MS = 5 * 60 * 1000;

/* ---------------- the one job everything calls ---------------- */

async function runCapture() {
  const pairing = await token();
  if (!pairing) {
    return { ok: false, sent: 0,
             problems: ["not paired yet — paste the code from Silly Bus AI Settings"] };
  }
  let status;
  try {
    status = await ask(pairing);
  } catch (err) {
    const why = /pairing code/.test(err.message) ? err.message
      : "Silly Bus AI is not running on this Mac. Open it and try again.";
    return { ok: false, sent: 0, problems: [why] };
  }

  // The store extension and Mac app may update independently. A mismatch is
  // not evidence that this folder changed; reloading here could loop forever.
  const problems = [];
  let sent = 0;
  const list = Array.isArray(status.wanted) ? status.wanted : [];
  if (!list.length) {
    problems.push(status.wanted_error
      || "nothing to fetch — everything the app wanted is already fresh");
  }
  for (const item of list) {
    const label = item.name || item.key || item.kind;
    if (!hostAllowed(item.url)) {
      problems.push(`${label}: refused — ${item.url} is not a school address`);
      continue;
    }
    try {
      const page = await grab(item.url);
      await send(item.kind, item.key, page, item.url, pairing);
      sent += 1;
    } catch (err) {
      problems.push(`${label}: ${err.message}`);
    }
  }
  // New pages reached the app, so what it would say has changed.
  await chrome.storage.local.remove(["boardAt", "boardData"]);
  const at = Date.now();
  await chrome.storage.local.set({ lastRun: at, lastSent: sent,
                                   lastProblems: problems.slice(0, 6) });
  await chrome.action.setBadgeText({ text: sent ? String(sent) : "" });
  await chrome.action.setBadgeBackgroundColor({
    color: sent ? "#2563EB" : "#B03024" });
  return { ok: sent > 0, sent, problems, at };
}

/* ---------------- the board, for the overlay on Canvas ----------------
 *
 * [ASKED] 2026-09-23: *"in the chrome extetion I want it to be like better
 * campus where it changes and adds the assignments and grade and other info
 * for the class"*.
 *
 * **The content script is never given the pairing token.** It runs inside
 * canvas.instructure.com, which is a page written by somebody else; anything
 * handed to it is handed to that page. So the fetch happens here, in the
 * worker, and only the answer crosses over.
 *
 * Held for a few minutes because Canvas is a lot of page views and the board
 * changes once a refresh, not once a click. Short enough that a refresh he
 * just ran shows up on the next page he opens.
 */
async function board() {
  /* **In storage, not in a variable.** [MEASURED] by an existing test
     (test_the_worker_keeps_no_state_in_a_variable): a Manifest V3 service
     worker is terminated after about thirty seconds idle, so a module-level
     `let` is empty again by the next message. A cache like that is not a
     cache — it would have meant one fetch to the Mac app per Canvas page
     view, which is the thing it was written to avoid. */
  const held = await chrome.storage.local.get(["boardAt", "boardData"]);
  if (held.boardData && Date.now() - (held.boardAt || 0) < BOARD_MS) {
    return { ok: true, board: held.boardData, cached: true };
  }
  const pairing = await token();
  if (!pairing) return { ok: false, why: "not paired yet" };
  let response;
  try {
    response = await fetch(`${APP}/api/bridge/board`, {
      headers: { "X-SillyBus-Token": pairing },
    });
  } catch (err) {
    return { ok: false, why: "Silly Bus AI is not running on this Mac" };
  }
  if (!response.ok) return { ok: false, why: `the app answered ${response.status}` };
  let payload;
  try { payload = await response.json(); } catch (err) {
    return { ok: false, why: "the app sent something that was not a board" };
  }
  if (payload && payload.error) {
    return { ok: false, why: (payload.error.message || "the app refused") };
  }
  await chrome.storage.local.set({ boardAt: Date.now(), boardData: payload });
  return { ok: true, board: payload, cached: false };
}


// One extension serves both the Chrome planner and the paired Mac app.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!["mac-pages-send", "mac-pages-status", "board"].includes(message?.type)) return false;
  if (sender.id !== chrome.runtime.id) return false;
  if (message.type !== "board" && sender.url !== chrome.runtime.getURL("popup.html")) return false;
  (async () => {
    try {
      if (message.type === "mac-pages-send") return await runCapture();
      if (message.type === "board") return await board();
      const pairing = await token();
      if (!pairing) return {ok: false, paired: false};
      const status = await ask(pairing);
      return {ok: true, paired: true, wanted: (status.wanted || []).length};
    } catch (err) { return {ok: false, message: err.message}; }
  })().then(sendResponse);
  return true;
});
chrome.runtime.onInstalled.addListener(async () => {
  const saved = await chrome.storage.local.get(["macCalendarToken", "token"]);
  if (!saved.macCalendarToken && saved.token) await chrome.storage.local.set({macCalendarToken: saved.token});
  await chrome.alarms.create(ALARM, {periodInMinutes: 60, delayInMinutes: 2});
});
chrome.alarms.onAlarm.addListener(async alarm => {
  if (alarm.name !== ALARM) return;
  const saved = await chrome.storage.local.get(["auto", "macCalendarToken", "token"]);
  if (saved.auto === false || !(saved.macCalendarToken || saved.token)) return;
  try { await runCapture(); } catch (err) { /* The next explicit Send retries. */ }
});
