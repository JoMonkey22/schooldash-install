// Pure notification planning. No titles, links, grades or credentials are cached.
export function localParts(now,zone){const p=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(now).map(x=>[x.type,x.value]));return {day:`${p.year}-${p.month}-${p.day}`,hour:Number(p.hour),minute:Number(p.minute)};}
export function digest(snapshot,now=new Date()){
 if(!snapshot?.enabled||!Array.isArray(snapshot.items))return null;
 let today;try{today=localParts(now,snapshot.zone).day;}catch{return null;}
 const tomorrow=new Date(today+'T12:00:00Z');tomorrow.setUTCDate(tomorrow.getUTCDate()+1);const next=tomorrow.toISOString().slice(0,10);
 const groups={overdue:0,today:0,tomorrow:0,undated:0};
 for(const i of snapshot.items){if(i.done)continue;let day=i.day;if(!/^\d{4}-\d{2}-\d{2}$/.test(day||'')){groups.undated++;continue;}const passed=!i.all_day&&typeof i.due==='string'&&i.due.includes('T')&&Number.isFinite(Date.parse(i.due))&&Date.parse(i.due)<now.getTime();if(day<today||(day===today&&passed)){if(!['test','quiz'].includes(i.category))groups.overdue++;}else if(day===today)groups.today++;else if(day===next)groups.tomorrow++;}
 const main=[['overdue','overdue'],['today','due today'],['tomorrow','due tomorrow']].filter(([k])=>groups[k]).map(([k,label])=>`${groups[k]} ${label}`).join(' · ');if(!main)return null;
 const age=now.getTime()-Date.parse(snapshot.captured_at);if(!Number.isFinite(age)||age<0||age>48*3600000)return null;
 return {title:'SillyBus homework reminder',message:main+(groups.undated?` · ${groups.undated} dates unconfirmed`:'')+'\nBased on your saved board'+(age>3*3600000?' (needs a refresh).':'.'),groups};
}
export function slot(now,zone,times=['07:00','17:00']){let p;try{p=localParts(now,zone);}catch{return null;}if(p.hour<6||p.hour>=22)return null;const n=p.hour*60+p.minute;const chosen=times.filter(t=>/^\d{2}:\d{2}$/.test(t)).filter(t=>{const [h,m]=t.split(':').map(Number);return h>=6&&h<22&&m<60&&n>=h*60+m&&n<h*60+m+15}).sort().at(-1);return chosen?`${p.day}/${chosen}`:null;}
