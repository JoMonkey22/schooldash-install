// SillyBus AI — content script for https://www.albert.io/*
//
// The twin of apclassroom.js, and for the same reason: Albert.io's data is on
// a different origin (api.albert.io) which [MEASURED] 2026-09-16 answers 401
// unauthenticated, is authorised by a SESSION COOKIE rather than a bearer
// token, and whose CORS reply names `https://www.albert.io` as the only
// allowed origin with credentials on. So a fetch from the extension's own
// origin is refused the origin AND has no cookie; a fetch from Python has
// neither. Only code running on an albert.io page can ask — which is this.
//
// **What it reads, and what it will never read.** Assignment METADATA only:
// what is assigned, when it is due, whether it is finished, how many
// questions are left, and a link that opens it. It does NOT read questions,
// answer choices, explanations or passages, and it must not be changed to.
// Albert.io is a graded question bank; pulling its questions into this app —
// and from there into a model — is doing the check rather than studying for
// it. The same line AP Classroom is held to. See sillybus/feeds/albert.py.
//
// The cookie is never read by this script (fetch sends it, the script never
// sees it), never leaves the site, and never reaches Python.
//
// It does nothing until asked, and it never signs anyone in: a 401 is the
// honest answer "not signed in", and the dashboard shows a button to open
// the site.

(() => {
  // Every injection redefines the reader, so a newer file replaces an older
  // one already living in a long-open tab. The lesson is apclassroom.js's:
  // an early-return guard kept a stale reader alive across three rebuilds.
  const firstTime = !window.__sillybusAlbert;
  window.__sillybusAlbert = true;

  const API = "https://api.albert.io/";
  const SITE = "https://www.albert.io";
  const READER_VERSION = "2026-09-16a";

  // Albert's JSON:API resource for a student's assignments, read out of the
  // site's own bundle. Kept in a list because the version suffix is theirs to
  // change and a 404 on the first spelling should try the next rather than
  // report "no assignments".
  const ENDPOINTS = ["assignments_v3", "assignments_v2", "assignments"];

  async function api(path, ms = 12000) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), ms);
    let res;
    try {
      // credentials:"include" is the whole trick: this runs on www.albert.io,
      // so the request carries the student's own session to an origin that
      // allows exactly this one.
      res = await fetch(API + path, {
        headers: { Accept: "application/vnd.api+json, application/json" },
        credentials: "include",
        signal: ctl.signal,
      });
    } catch (err) {
      throw new Error(err && err.name === "AbortError"
        ? `no answer in ${ms / 1000}s for ${path}`
        : `network: ${err && err.message ? err.message : err}`);
    } finally { clearTimeout(timer); }
    if (res.status === 401 || res.status === 403) {
      const e = new Error("not signed in"); e.status = res.status; throw e;
    }
    if (!res.ok) { const e = new Error(`Albert.io answered ${res.status} for ${path}`); e.status = res.status; throw e; }
    return { body: await res.json(), status: res.status };
  }

  // --- reading the answer -----------------------------------------------------
  //
  // This shape is NOT documented and was not verifiable without an account:
  // the endpoint's existence, its auth and its origin rules were measured, its
  // field names were not. So every accessor tries the spellings JSON:API and
  // Albert's bundle make likely, gives up to null rather than guessing, and
  // sends the raw key names back in `diagnostics`. The first real run in
  // The student's own Chrome is what settles them — and if none match, the
  // board says
  // "read Albert.io but did not recognise what it sent" with the key names
  // attached, which is a bug report, not a silent zero.
  const pick = (o, ...keys) => {
    for (const k of keys) {
      if (o && o[k] !== undefined && o[k] !== null && o[k] !== "") return o[k];
    }
    return null;
  };
  const str = (v) => (v === null || v === undefined ? "" : String(v));
  const num = (v) => {
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  };
  const trim = (o) => {
    // A sample of the SHAPE, for diagnostics: keys and the types behind them,
    // never the values — a question's text is a value.
    if (!o || typeof o !== "object") return null;
    const out = {};
    for (const k of Object.keys(o).slice(0, 30)) {
      const v = o[k];
      out[k] = Array.isArray(v) ? `array[${v.length}]`
        : v && typeof v === "object" ? `{${Object.keys(v).slice(0, 8).join(",")}}`
        : typeof v;
    }
    return out;
  };

  // JSON:API puts the real fields under `attributes` and the id beside it; a
  // plainer API puts them at the top level. Flattening one level covers both
  // without caring which it is.
  function flatten(row) {
    if (!row || typeof row !== "object") return null;
    const attrs = row.attributes && typeof row.attributes === "object" ? row.attributes : {};
    return { ...attrs, ...row, ...(row.id !== undefined ? { id: row.id } : {}) };
  }

  // The list itself can arrive as `data`, `assignments`, `results`, or as a
  // bare array. Anything else is reported, not guessed at.
  function rows(body) {
    if (Array.isArray(body)) return body;
    for (const key of ["data", "assignments", "results", "items"]) {
      if (Array.isArray(body && body[key])) return body[key];
    }
    return null;
  }

  function toRecord(row) {
    const r = flatten(row);
    if (!r) return null;
    const title = str(pick(r, "name", "title", "assignment_name", "assignmentName", "label")).trim();
    if (!title) return null;
    const id = str(pick(r, "id", "assignment_id", "assignmentId", "guid"));
    const subject = str(pick(r, "subject", "subject_name", "course", "course_name",
                             "classroom_name", "classroomName", "class_name", "section_name")).trim();
    const due = pick(r, "due_at", "dueAt", "due_date", "dueDate", "ends_at", "endsAt", "due");
    const assigned = pick(r, "assigned_at", "assignedAt", "starts_at", "startsAt",
                          "created_at", "createdAt", "published_at");
    const status = str(pick(r, "status", "state", "student_status", "studentStatus"));
    const submitted = pick(r, "submitted_at", "submittedAt", "completed_at", "completedAt",
                           "finished_at", "turned_in_at");
    // COUNTS ONLY. How much work is left — never what the work asks. See the
    // header: this is the boundary, not a detail.
    const total = num(pick(r, "question_count", "questionCount", "total_questions",
                           "totalQuestions", "questions_count", "num_questions"));
    const done = num(pick(r, "questions_completed", "questionsCompleted",
                          "completed_count", "completedCount", "answered_count",
                          "num_answered"));
    const link = str(pick(r, "url", "link", "student_url", "web_url"))
      || (id ? `${SITE}/assignment/${id}` : "");
    return {
      id,
      subject,
      title,
      due: due ? str(due) : null,
      assigned: assigned ? str(assigned) : null,
      status: status.toLowerCase(),
      submitted: submitted ? str(submitted) : null,
      questions: total,
      completed: done,
      url: link,
    };
  }

  async function readAssignments() {
    const t0 = Date.now();
    const diagnostics = { endpoint: null, http_status: null, shape: null,
                          assignment_keys: null, tried: [], ms: {} };
    let body = null;
    let lastError = null;
    for (const path of ENDPOINTS) {
      try {
        const out = await api(path);
        body = out.body;
        diagnostics.endpoint = path;
        diagnostics.http_status = out.status;
        break;
      } catch (err) {
        diagnostics.tried.push(`${path}: ${err && err.message ? err.message : err}`);
        // "not signed in" is an answer about the student, not about the path:
        // trying the other spellings would give the same 401 three times.
        if (err && err.message === "not signed in") throw err;
        lastError = err;
      }
    }
    if (body === null) throw (lastError || new Error("Albert.io did not answer"));

    const list = rows(body);
    if (list === null) {
      diagnostics.shape = Array.isArray(body) ? `array[${body.length}]`
        : `{${Object.keys(body || {}).slice(0, 12).join(",")}}`;
      throw new Error("Albert.io answered, but not with a list of assignments "
        + `(it sent ${diagnostics.shape})`);
    }
    diagnostics.shape = `list[${list.length}]`;
    if (list.length) diagnostics.assignment_keys = trim(flatten(list[0]));

    const assignments = [];
    for (const row of list) {
      const rec = toRecord(row);
      if (rec) assignments.push(rec);
    }
    diagnostics.ms.total = Date.now() - t0;
    diagnostics.recognised = assignments.length;
    return { assignments, diagnostics };
  }

  function signInState() {
    // Cookie-authorised, so there is nothing to look at: what can be said is
    // where the page is, which is enough to tell "signed out and redirected"
    // from "signed in and the shape changed".
    return { auth: "cookie", where: location.pathname };
  }

  async function answer() {
    try {
      const out = await readAssignments();
      out.diagnostics.sign_in = signInState();
      return { ...out, read_at: new Date().toISOString(), reader_version: READER_VERSION };
    } catch (err) {
      const where = String((err && err.stack) || "").split("\n").slice(1, 3)
        .join(" ").replace(/chrome-extension:\/\/[a-z]+\//g, "");
      const message = err && err.message ? err.message : String(err);
      return {
        error: message === "not signed in"
          ? "not signed in to Albert.io in this Chrome"
          : `${message}${where ? ` @ ${where.trim()}` : ""}`,
        assignments: [],
        diagnostics: { sign_in: signInState() },
        read_at: new Date().toISOString(),
        reader_version: READER_VERSION,
      };
    }
  }

  globalThis.__sillybusReadAlbert = answer;

  if (firstTime) try {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message?.type !== "albert_assignments") return false;
      answer().then(sendResponse);
      return true;
    });
  } catch (e) { /* not a content-script context */ }
})();
