// Optional background operation uses Chrome alone, never the Mac companion.
const ALARM='sillybus-chrome-background-refresh';
export async function refreshInChrome(){
 const {autostart}=await chrome.storage.local.get('autostart');if(autostart!==true)return;
 const url=chrome.runtime.getURL('index.html');const tabs=await chrome.tabs.query({url});
 if(!tabs.length){await chrome.tabs.create({url,pinned:true,active:false});return;}
 await chrome.runtime.sendMessage({type:'sillybus-background-refresh'}).catch(()=>{});
}
chrome.alarms.get(ALARM).then(a=>{if(!a)return chrome.alarms.create(ALARM,{periodInMinutes:30});}).catch(()=>{});
chrome.alarms.onAlarm.addListener(a=>{if(a.name===ALARM)refreshInChrome().catch(()=>{});});
