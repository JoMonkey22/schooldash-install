// Read visible Classroom coursework after Link this page. No Google API key,
// private application state, session token, or assessment question is collected.
(() => {
  window.__sillybusReadGoogleClassroom = async () => {
    const read_at = new Date().toISOString();
    if (location.hostname !== 'classroom.google.com') return {read_at, error: 'not on Google Classroom'};
    const page = document.body.innerText || '';
    if (/Welcome to Google Classroom|Continue with Google Classroom/.test(page)) {
      return {read_at, error: 'Finish Google Classroom setup in this tab, then link again.'};
    }
    if (/Add a class to get started/.test(page)) {
      return {read_at, error: 'This Google account has no Classroom classes. Use the Google account enrolled in your classes, or join your class, then open Classwork and link again.'};
    }
    const clean = value => String(value || '').replace(/\s+/g, ' ').trim();
    const visible = node => node.getClientRects().length > 0;
    const subject = clean(document.querySelector('h1')?.innerText || document.title.replace(/ - (?:Classroom|Google Classroom).*$/, ''));
    const assignments = new Map();
    for (const anchor of document.querySelectorAll('a[href]')) {
      if (!visible(anchor)) continue;
      let url;
      try { url = new URL(anchor.href, location.href); } catch (_) { continue; }
      // Coursework detail links, not course navigation, announcements or materials.
      const ids = /^\/c\/([^/]+)\/a\/([^/]+)(?:\/|$)/.exec(url.pathname);
      if (url.origin !== 'https://classroom.google.com' || !ids) continue;
      const row = anchor.closest('[data-stream-item-id], [role="listitem"], article, li') || anchor;
      const heading = row.querySelector('h2, h3, [role="heading"]');
      const title = clean(heading?.innerText || anchor.innerText || anchor.getAttribute('aria-label'));
      if (!title || /^(View (?:assignment|instructions)|Open assignment)$/i.test(title)) continue;
      const text = row.innerText || '';
      const dueText = text.split('\n').map(clean).find(line => /^(?:Due\b|No due date\b)/i.test(line)) || '';
      const time = [...row.querySelectorAll('time[datetime]')].find(node => /due/i.test(node.getAttribute('aria-label') || node.parentElement?.innerText || ''));
      const raw = time?.getAttribute('datetime') || '';
      // An ISO date is stated. A localized/relative label remains readable text;
      // never turn a post timestamp or an assumed year into a deadline.
      const due = /^\d{4}-\d{2}-\d{2}(?:T.*)?$/.test(raw) ? raw : null;
      const status = text.split('\n').map(clean).find(line => /^(Assigned|Missing|Turned in|Returned|Graded|Done)$/i.test(line)) || '';
      const key = `${ids[1]}/${ids[2]}`;
      url.search = ''; url.hash = '';
      assignments.set(key, {id: key, subject, title: title.slice(0, 300), due,
        due_text: dueText.slice(0, 200), status, url: url.href});
    }
    if (!assignments.size) return {read_at, error: 'No readable coursework on this page. Open Classwork, expand an assignment if needed, then Link this page. Only visible coursework is imported.'};
    return {read_at, assignments: [...assignments.values()], partial: true,
      message: 'Read visible coursework. Open other classes or more assignments to import them too.'};
  };
})();
