# SillyBus Lock on iPhone: the plan

He asked for the lock on "both" his Mac and his phone. The Mac version is
built (README.md). The iPhone version is **not built yet**, and this note
explains why and what it will take.

## Why it is not built yet

On an iPhone, one app can block another app only through Apple's **Screen
Time API**: FamilyControls, ManagedSettings and DeviceActivity. That requires
three things this project does not have yet:

1. **A paid Apple Developer Program membership** ($99/year). The account here
   is the free tier, which cannot use the Family Controls capability at all.
2. **Apple's approval for the Family Controls entitlement.** You request it
   from Apple with a form that explains the app, and it is reviewed by a person.
   Development builds can use it before approval, but TestFlight and the App
   Store cannot.
3. **An adult on the account.** The developer account must belong to someone
   18 or over, so a parent would enroll and own it.

## How it would work once those exist

- **Picking apps.** The phone app shows Apple's own picker
  (`FamilyActivityPicker`), with "Games" and "Social" ticked by default. Apple
  hides app identities from the developer, so the choice stays on the phone.
- **Blocking.** `ManagedSettingsStore.shield.applicationCategories` covers the
  chosen apps with a shield screen, a customizable "Locked until today's work
  is done" page.
- **Telling the phone about the homework.** The phone cannot reach
  `127.0.0.1` on the Mac. SillyBus would send the same yes/no that
  `sillybus/lock.py` produces, as yes/no plus a count and no titles, through the
  existing relay (the Cloudflare Worker that already carries the hosted AI).
  The phone app would read it every few minutes. It would also read it from a
  background refresh or a silent push.
- **The 30-minute rule.** It works the same as on the Mac. The phone sees the
  "finished" count rise, lifts the shield, and schedules a `DeviceActivity`
  interval that puts the shield back 30 minutes later.

## What to do when the account exists

1. Enroll in the Apple Developer Program, with the parent as the account holder.
2. Request the Family Controls (Distribution) entitlement.
3. Then build `lock/ios/`: a SwiftUI app plus a DeviceActivityMonitor
   extension and a ShieldConfiguration extension.
