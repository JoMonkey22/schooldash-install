#!/bin/bash
# Build SillyBus Lock.app with swiftc (Xcode not needed), run its self-test,
# and — with `install` — put it in ~/Applications, start it, and start it at
# every login.
#
#   lock/build.sh              → lock/dist/SillyBus Lock.app
#   lock/build.sh install      → also ~/Applications/SillyBus Lock.app, running
#
# Ad-hoc signed: it is built on this Mac, so Gatekeeper never sees a download
# (no quarantine) and there is nothing to notarize.
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
VERSION="$(cat "$ROOT/VERSION")"
OUT="$HERE/dist"
APP="$OUT/SillyBus Lock.app"
LABEL="com.sillybus.lock"

rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"

echo "==> compiling"
swiftc -O -swift-version 5 -target "$(uname -m)-apple-macos14.0" \
  -o "$APP/Contents/MacOS/SillyBusLock" "$HERE/SillyBusLock.swift"

cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>SillyBus Lock</string>
  <key>CFBundleDisplayName</key><string>SillyBus Lock</string>
  <key>CFBundleIdentifier</key><string>$LABEL</string>
  <key>CFBundleVersion</key><string>$VERSION</string>
  <key>CFBundleShortVersionString</key><string>$VERSION</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleExecutable</key><string>SillyBusLock</string>
  <key>CFBundleIconFile</key><string>sillybus</string>
  <key>LSUIElement</key><true/>
  <key>LSMinimumSystemVersion</key><string>14.0</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>NSAppleEventsUsageDescription</key><string>SillyBus Lock checks whether the tab in front is YouTube or another blocked site, and closes it when you press OK.</string>
  <key>NSAppTransportSecurity</key><dict><key>NSAllowsLocalNetworking</key><true/></dict>
  <key>NSHumanReadableCopyright</key><string>Runs entirely on this Mac.</string>
</dict></plist>
PLIST

SRC_ICON="$ROOT/sillybus/web/static/brand/icon-1024.png"
if [ -f "$SRC_ICON" ]; then
  ICONSET="$(mktemp -d)/sillybus.iconset"
  mkdir -p "$ICONSET"
  for size in 16 32 128 256 512; do
    sips -z $size $size "$SRC_ICON" --out "$ICONSET/icon_${size}x${size}.png" >/dev/null 2>&1
    sips -z $((size*2)) $((size*2)) "$SRC_ICON" --out "$ICONSET/icon_${size}x${size}@2x.png" >/dev/null 2>&1
  done
  iconutil -c icns "$ICONSET" -o "$APP/Contents/Resources/sillybus.icns" >/dev/null 2>&1 || true
fi

codesign --force --sign - "$APP" >/dev/null 2>&1

echo "==> self-test"
"$APP/Contents/MacOS/SillyBusLock" --self-test | sed 's/^/    /'

# The download for anyone who has not got the Command Line Tools.
rm -f "$OUT"/SillyBus-Lock-*.zip
ditto -c -k --keepParent "$APP" "$OUT/SillyBus-Lock-$VERSION.zip"

echo "==> built $APP"

[ "${1:-}" = "install" ] || exit 0

DEST="$HOME/Applications/SillyBus Lock.app"
AGENT="$HOME/Library/LaunchAgents/$LABEL.plist"
echo "==> installing to $DEST"
launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || true
pkill -x SillyBusLock 2>/dev/null || true
sleep 1
mkdir -p "$HOME/Applications" "$HOME/Library/LaunchAgents"
rm -rf "$DEST"
cp -R "$APP" "$DEST"

# The same plist the app's own "Start when I log in" switch writes.
cat > "$AGENT" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key><array><string>$DEST/Contents/MacOS/SillyBusLock</string></array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><dict><key>SuccessfulExit</key><false/></dict>
  <key>ProcessType</key><string>Interactive</string>
</dict></plist>
PLIST
launchctl bootstrap "gui/$(id -u)" "$AGENT"
sleep 2
if curl -s --max-time 3 http://127.0.0.1:5066/status >/dev/null; then
  echo "==> running: $(curl -s http://127.0.0.1:5066/status)"
else
  echo "!! installed but not answering on 127.0.0.1:5066" >&2
  exit 1
fi
