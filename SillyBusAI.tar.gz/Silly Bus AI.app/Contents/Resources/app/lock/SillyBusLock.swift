// SillyBus Lock — hides games and social apps on this Mac until today's
// schoolwork is done.
//
// [ASKED] 2026-10-06: "I want an app that is link to the chrome extention and
// the exteyion sends the info to the app and the data on the app restrics
// stuff". Blocks "all social media and games" by default (he picks the rest),
// and unlocks when "Today's work is done" — or, his second rule, "do one
// assignemt the 30 mins then lock until Today's work is done".
//
// This app knows nothing about homework. SillyBus decides what "done" means
// (sillybus/lock.py) and tells it, two ways:
//   * pushed — whichever SillyBus page is open (the Chrome extension, or the
//     Mac app's window) POSTs its status to 127.0.0.1:5066 every minute;
//   * pulled — every minute this app asks the Mac app's server
//     (127.0.0.1:5055/api/lock), so it works with every window closed.
// When two sources disagree, the one whose answer CHANGED most recently wins:
// that is where he last ticked something off.
//
// Built by lock/build.sh with swiftc (no Xcode). `--self-test` runs the
// decision and the request guards without a window.

import AppKit
import Network
import SwiftUI

// MARK: - Constants

enum K {
    static let port: UInt16 = 5066
    static let pullURL = URL(string: "http://127.0.0.1:5055/api/lock")!
    static let breakSeconds: TimeInterval = 30 * 60
    static let agentLabel = "com.sillybus.lock"
    static let maxBody = 256 * 1024
    static let maxSeenKeys = 5000
    /// "Get More Time" ([ASKED] 2026-10-07, "have it do what thebrainrotapp.com
    /// does … it tries to convince you to do your work"): a local five-second
    /// confirmation on the Mac app's /talk page, then a few minutes — at
    /// most this many, this many times a school day.
    static let extraMaxMinutes = 10
    static let extraPerDay = 3
    static let talkURL = "http://127.0.0.1:5055/talk"
    static let macAppOrigin = "http://127.0.0.1:5055"
}

// MARK: - What SillyBus sends (sillybus/lock.py)

struct OpenItem: Codable, Hashable {
    var title: String
    var course: String?
    var due: String?
}

/// Downtime ([ASKED] 2026-10-07: "in settings add a thing where you set a
/// down time or tell the chat to do it") — Screen Time's Downtime: set hours
/// when games and social media stay shut even on a finished day. SillyBus
/// works out `active`/`until` (sillybus/downtime.py) and sends the schedule
/// too, so the lock can keep Downtime by itself while it cannot hear SillyBus.
struct DowntimeInfo: Codable, Equatable {
    var on: Bool?
    var active: Bool?
    var until: String?        // "HH:MM", the end of the window it is in
    var label: String?
    var start: String?        // "HH:MM", in `tz`
    var end: String?
    var days: [String]?       // "mon"…"sun"; a window past midnight belongs to the day it starts
    var tz: String?
    var set_at: Double?       // when it was last changed, wherever: the newest change wins
}

struct LockStatus: Codable {
    var known: Bool
    var done: Bool
    var for_date: String
    var open_count: Int?
    var open: [OpenItem]?
    var overdue_count: Int?
    var done_keys: [String]?
    var signed_out: Bool?     // the Mac app's sign-in has expired: no titles
    var tz: String?           // the time zone SillyBus counts days in (config school.time_zone)
    var key_version: Int?     // how done_keys are made; a change re-baselines the source
    var downtime: DowntimeInfo?   // Downtime's schedule, and whether it is on now

    var fingerprint: String {
        let titles = (open ?? []).map(\.title).joined(separator: "\u{1}")
        let keys = (done_keys ?? []).sorted().joined(separator: ",")
        return "\(known)|\(done)|\(for_date)|\(open_count ?? -1)|\(overdue_count ?? 0)|\(titles)|\(keys)"
    }
}

struct Heard {
    var status: LockStatus
    var receivedAt: Date
    var changedAt: Date
}

enum Mode: String, CaseIterable {
    case allDone          // locked until today's work is done
    case perAssignment    // each finished assignment = 30 minutes, then locked again

    var label: String {
        switch self {
        case .allDone: return "When all of today's work is done"
        case .perAssignment: return "30 minutes for each assignment I finish"
        }
    }
}

struct Decision: Equatable {
    var locked: Bool
    var headline: String
    var detail: String
    var open: [OpenItem]
    var openCount: Int
    var overdueCount: Int
    var breakLeft: TimeInterval?
    var heardAt: Date?
    /// Set while it is Downtime: the "HH:MM" it ends. The card and the Time
    /// Limit page then say Downtime, because "you've reached your limit" on a
    /// finished day would be a lie about why.
    var downtimeUntil: String? = nil
}

/// "Today" in the zone SillyBus counts days in. [MEASURED] 2026-10-06 (the
/// prosecution pass): this Mac is on Pacific time and SillyBus on Phoenix, so
/// every winter night from 23:00 to midnight each status was dated "tomorrow"
/// by the Mac's clock, thrown away, and the lock shut on a finished day.
func todayString(_ now: Date = Date(), zone: String? = nil) -> String {
    let f = DateFormatter()
    f.calendar = Calendar(identifier: .gregorian)
    f.locale = Locale(identifier: "en_US_POSIX")
    f.timeZone = zone.flatMap { TimeZone(identifier: $0) } ?? TimeZone.current
    f.dateFormat = "yyyy-MM-dd"
    return f.string(from: now)
}

func plural(_ n: Int, _ one: String, _ many: String) -> String { n == 1 ? "1 \(one)" : "\(n) \(many)" }

// MARK: - Downtime

/// Calendar's weekday 1…7 is Sunday…Saturday.
let WEEKDAYS = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"]

func minutesOf(_ hhmm: String?) -> Int? {
    guard let parts = hhmm?.split(separator: ":"), parts.count == 2,
          let h = Int(parts[0]), let m = Int(parts[1]), (0...23).contains(h), (0...59).contains(m) else { return nil }
    return h * 60 + m
}

/// "07:00" → "7:00 AM", the same words sillybus/downtime.py `clock()` uses.
func clockWords(_ hhmm: String) -> String {
    guard let m = minutesOf(hhmm) else { return hhmm }
    let h = m / 60
    return "\(h % 12 == 0 ? 12 : h % 12):\(String(format: "%02d", m % 60)) \(h < 12 ? "AM" : "PM")"
}

/// The "HH:MM" Downtime ends, if `now` is inside a window — else nil.
///
/// Worked out HERE from the schedule rather than taken from the `active` flag
/// SillyBus sent: that flag is up to a minute old (the pull is once a
/// minute), and the schedule is exact at 10:00:00 PM. The rules are
/// sillybus/downtime.py's, and tests/test_downtime.py runs both on the same
/// cases. The flag is used only for a schedule this cannot read, and only
/// while it is fresh.
func downtimeEnd(_ d: DowntimeInfo?, now: Date, heardAt: Date? = nil) -> String? {
    guard let d, d.on == true else { return nil }
    guard let start = minutesOf(d.start), let end = minutesOf(d.end), start != end else {
        if d.active == true, let at = heardAt, now.timeIntervalSince(at) < 120 { return d.until ?? d.end }
        return nil
    }
    var cal = Calendar(identifier: .gregorian)
    cal.timeZone = d.tz.flatMap { TimeZone(identifier: $0) } ?? TimeZone.current
    let c = cal.dateComponents([.hour, .minute, .weekday], from: now)
    guard let hour = c.hour, let minute = c.minute, let wd = c.weekday else { return nil }
    let mins = hour * 60 + minute
    let days = Set(d.days ?? WEEKDAYS)
    let today = WEEKDAYS[wd - 1]
    let yesterday = WEEKDAYS[(wd + 5) % 7]
    let inside = start < end
        ? days.contains(today) && mins >= start && mins < end
        // Crosses midnight: the evening belongs to today, the small hours to
        // the day before — the day the window started.
        : (mins >= start && days.contains(today)) || (mins < end && days.contains(yesterday))
    return inside ? d.end : nil
}

/// The whole rule, in one pure function (the self-test runs it).
/// How long a status from yesterday still counts just after midnight, until
/// the next pull lands — without it, midnight quit the game in front even
/// in the middle of a break (prosecution 2026-10-06).
let MIDNIGHT_GRACE: TimeInterval = 5 * 60

func decide(heard: [String: Heard], now: Date, mode: Mode, grantUntil: Date?,
            downtime: DowntimeInfo? = nil, downtimeHeardAt: Date? = nil) -> Decision {
    let today = { (s: LockStatus) in todayString(now, zone: s.tz) }
    var fresh = heard.values.filter { $0.status.for_date == today($0.status) }
    if fresh.isEmpty {
        fresh = heard.values.filter {
            $0.status.for_date == todayString(now.addingTimeInterval(-86400), zone: $0.status.tz)
                && now.timeIntervalSince($0.receivedAt) < MIDNIGHT_GRACE
        }
    }
    let pick = fresh.max { a, b in
        a.changedAt != b.changedAt ? a.changedAt < b.changedAt : a.receivedAt < b.receivedAt
    }
    // Downtime first: shut even when the work is done, and a 30-minute break
    // does not open it either. The coach's "Get More Time" minutes still do
    // — LockModel.refresh applies those on top of this, as the escape hatch.
    if let until = downtimeEnd(downtime, now: now, heardAt: downtimeHeardAt) {
        let s = pick?.status
        let known = s?.known == true
        let open = known ? (s?.open ?? []) : []
        return Decision(locked: true, headline: "Downtime until \(clockWords(until))",
                        detail: "SillyBus Lock keeps games and social media closed during Downtime.",
                        open: open, openCount: known && s?.done == false ? (s?.open_count ?? open.count) : 0,
                        overdueCount: s?.overdue_count ?? 0, breakLeft: nil, heardAt: pick?.receivedAt,
                        downtimeUntil: until)
    }
    guard let pick else {
        if mode == .perAssignment, let until = grantUntil, until > now {
            let left = until.timeIntervalSince(now)
            return Decision(locked: false, headline: "Break: \(Int((left / 60).rounded(.up))) min left",
                            detail: "Then it locks again until the next assignment is done.",
                            open: [], openCount: 0, overdueCount: 0, breakLeft: left, heardAt: nil)
        }
        return Decision(locked: true, headline: "Waiting for SillyBus",
                        detail: "Open SillyBus so the lock can see today's work.",
                        open: [], openCount: 0, overdueCount: 0, breakLeft: nil, heardAt: nil)
    }
    let s = pick.status
    let open = s.open ?? []
    let count = s.open_count ?? open.count
    let overdue = s.overdue_count ?? 0
    if !s.known {
        return Decision(locked: true, headline: "Waiting for SillyBus",
                        detail: "SillyBus hasn't loaded your work yet. Open it and press Refresh.",
                        open: [], openCount: 0, overdueCount: overdue, breakLeft: nil, heardAt: pick.receivedAt)
    }
    if s.done {
        return Decision(locked: false, headline: "Today's work is done",
                        detail: "Games and social apps are open. Nice work.",
                        open: [], openCount: 0, overdueCount: overdue, breakLeft: nil, heardAt: pick.receivedAt)
    }
    if mode == .perAssignment, let until = grantUntil, until > now {
        let left = until.timeIntervalSince(now)
        return Decision(locked: false, headline: "Break: \(Int((left / 60).rounded(.up))) min left",
                        detail: "Then it locks again until the next assignment is done.",
                        open: open, openCount: count, overdueCount: overdue, breakLeft: left, heardAt: pick.receivedAt)
    }
    let how = mode == .perAssignment
        ? "Finish one and tick it Done in SillyBus for 30 minutes."
        : "Tick them Done in SillyBus and everything unlocks."
    return Decision(locked: true, headline: "\(plural(count, "thing", "things")) due today or tomorrow",
                    detail: how, open: open, openCount: count, overdueCount: overdue,
                    breakLeft: nil, heardAt: pick.receivedAt)
}

// MARK: - Who may tell the lock anything

/// A browser always sends Origin on a cross-site POST, so a web page cannot
/// pose as SillyBus: only Chrome extensions and the Mac app's own page
/// (http://127.0.0.1:5055) are listened to. Not any loopback port: a dev copy
/// on :5079 counted as SillyBus, and a tick made while testing gave a real
/// 30-minute break (prosecution 2026-10-06).
func originAllowed(_ origin: String?) -> Bool {
    guard let origin, !origin.isEmpty else { return false }
    if origin.hasPrefix("chrome-extension://") {
        let id = origin.dropFirst("chrome-extension://".count)
        return id.count == 32 && id.allSatisfy { ("a"..."p").contains($0) }
    }
    return origin == "http://127.0.0.1:5055" || origin == "http://localhost:5055"
}

/// DNS rebinding: a site that points its own name at 127.0.0.1 still sends
/// its own name as Host.
func hostAllowed(_ host: String?) -> Bool {
    guard let host else { return false }
    return host == "127.0.0.1:\(K.port)" || host == "localhost:\(K.port)"
}

func sourceName(_ origin: String) -> String {
    if origin.hasPrefix("chrome-extension://") { return "extension:" + origin.dropFirst("chrome-extension://".count) }
    return "mac-app"
}

// MARK: - Which apps are games or social media

struct AppInfo: Identifiable, Hashable {
    var id: String          // bundle identifier
    var name: String
    var path: String
    var defaultBlocked: Bool
    var why: String
}

enum Catalog {
    /// Apps whose Info.plist does not say what they are, or says it wrongly.
    static let known: [String: String] = [
        "com.valvesoftware.steam": "game store", "com.epicgames.EpicGamesLauncher": "game store",
        "net.battle.app": "game store", "com.blizzard.worldofwarcraft": "game",
        "com.roblox.RobloxPlayer": "game", "com.roblox.RobloxStudio": "game",
        "com.mojang.minecraftlauncher": "game", "com.mojang.minecraft": "game",
        "com.hnc.Discord": "social", "com.tinyspeck.slackmacgap": "",
        "net.whatsapp.WhatsApp": "social", "desktop.WhatsApp": "social",
        "ru.keepcoder.Telegram": "social", "org.telegram.desktop": "social",
        "com.facebook.archon": "social", "com.facebook.Facebook": "social",
        "com.burbn.instagram": "social", "com.zhiliaoapp.musically": "social",
        "com.toyopagroup.picaboo": "social", "com.atebits.Tweetie2": "social",
        "com.reddit.Reddit": "social", "tv.twitch.TwitchApp": "video",
        "com.google.ios.youtube": "video", "com.netflix.Netflix": "video",
        "com.apple.Chess": "game",
    ]

    static func plist(_ url: URL) -> [String: Any]? {
        for rel in ["Contents/Info.plist", "WrappedBundle/Info.plist", "Info.plist"] {
            if let d = NSDictionary(contentsOf: url.appendingPathComponent(rel)) as? [String: Any] { return d }
        }
        return nil
    }

    /// iPhone/iPad apps installed on a Mac carry the App Store genre instead.
    static func iosGenre(_ url: URL) -> Int? {
        let meta = url.appendingPathComponent("Wrapper/iTunesMetadata.plist")
        guard let d = NSDictionary(contentsOf: meta) as? [String: Any] else { return nil }
        return (d["genreId"] as? Int) ?? (d["genreId"] as? NSNumber)?.intValue
    }

    static func classify(id: String?, url: URL?, name: String?, exe: URL? = nil) -> (Bool, String) {
        let id = id ?? ""
        if id.hasPrefix("com.sillybus") { return (false, "") }
        if let why = known[id] { return (!why.isEmpty, why) }
        if let path = url?.path, path.contains("/steamapps/common/") { return (true, "Steam game") }
        // [MEASURED] 2026-10-06: Minecraft itself runs as a bare "java" with no
        // bundle id — only its runtime's folder says what it is.
        if let path = exe?.path ?? url?.path, path.contains("/Application Support/minecraft/") {
            return (true, "game")
        }
        if let n = name, n.hasPrefix("Minecraft") { return (true, "game") }
        if id.hasPrefix("com.apple.") { return (false, "") }
        if let url {
            if let cat = plist(url)?["LSApplicationCategoryType"] as? String {
                if cat.contains("games") { return (true, "game") }
                if cat.contains("social-networking") { return (true, "social") }
            }
            switch iosGenre(url) {
            case 6014: return (true, "game")
            case 6005: return (true, "social")
            default: break
            }
        }
        return (false, "")
    }

    static func scan() -> [AppInfo] {
        let fm = FileManager.default
        let home = fm.homeDirectoryForCurrentUser.path
        let roots = ["/Applications", "\(home)/Applications", "/System/Applications",
                     "\(home)/Library/Application Support/Steam/steamapps/common"]
        var found: [String: AppInfo] = [:]
        func visit(_ dir: String, depth: Int) {
            guard depth <= 2, let names = try? fm.contentsOfDirectory(atPath: dir) else { return }
            for n in names {
                let p = (dir as NSString).appendingPathComponent(n)
                if n.hasSuffix(".app") {
                    let url = URL(fileURLWithPath: p)
                    let info = plist(url)
                    guard let id = info?["CFBundleIdentifier"] as? String else { continue }
                    let name = (info?["CFBundleDisplayName"] as? String) ?? (info?["CFBundleName"] as? String)
                        ?? (n as NSString).deletingPathExtension
                    let (blocked, why) = classify(id: id, url: url, name: name)
                    if found[id] == nil { found[id] = AppInfo(id: id, name: name, path: p, defaultBlocked: blocked, why: why) }
                } else {
                    var isDir: ObjCBool = false
                    if fm.fileExists(atPath: p, isDirectory: &isDir), isDir.boolValue, !n.hasPrefix(".") {
                        visit(p, depth: depth + 1)
                    }
                }
            }
        }
        for r in roots { visit(r, depth: 0) }
        for app in NSWorkspace.shared.runningApplications where app.activationPolicy == .regular {
            guard let id = app.bundleIdentifier, found[id] == nil, let url = app.bundleURL else { continue }
            let (blocked, why) = classify(id: id, url: url, name: app.localizedName)
            found[id] = AppInfo(id: id, name: app.localizedName ?? id, path: url.path, defaultBlocked: blocked, why: why)
        }
        return found.values.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }
}

// MARK: - The model

enum Env {
    static let selfTest = CommandLine.arguments.contains("--self-test") || CommandLine.arguments.contains("--render-cards")
    /// For testing on a Mac where someone is playing: says what it would hide.
    static let watchOnly = CommandLine.arguments.contains("--watch-only")
}

@MainActor
final class LockModel: ObservableObject {
    static let shared = LockModel()
    // A self-test run gets its own settings, so it can never touch the real ones.
    let defaults = Env.selfTest ? UserDefaults(suiteName: "com.sillybus.lock.selftest")!
        : Env.watchOnly ? UserDefaults(suiteName: "com.sillybus.lock.watch")! : UserDefaults.standard

    @Published var heard: [String: Heard] = [:]
    @Published var decision = decide(heard: [:], now: Date(), mode: .allDone, grantUntil: nil)
    @Published var mode: Mode { didSet { defaults.set(mode.rawValue, forKey: "mode"); refresh() } }
    @Published var alwaysBlock: Set<String> { didSet { defaults.set(Array(alwaysBlock), forKey: "alwaysBlock") } }
    @Published var neverBlock: Set<String> { didSet { defaults.set(Array(neverBlock), forKey: "neverBlock") } }
    /// Websites he switched OFF — every site starts blocked, so a site added in
    /// a later version is blocked for everyone without a migration.
    @Published var sitesOff: Set<String> { didSet { defaults.set(Array(sitesOff), forKey: "sitesOff") } }
    var grantUntil: Date? { didSet { defaults.set(grantUntil, forKey: "grantUntil") } }
    /// Minutes talked out of the coach on the /talk page, in either mode.
    var extraUntil: Date? { didSet { defaults.set(extraUntil, forKey: "extraUntil") } }
    var extraDay: String { didSet { defaults.set(extraDay, forKey: "extraDay") } }
    var extraCount: Int { didSet { defaults.set(extraCount, forKey: "extraCount") } }
    var seenKeys: Set<String>
    var knownSources: Set<String>
    var keyVersions: [String: Int]
    /// The Downtime schedule last heard, kept across restarts so a lock that
    /// starts up at night with SillyBus closed still keeps Downtime.
    var downtime: DowntimeInfo? {
        didSet { defaults.set(downtime.flatMap { try? JSONEncoder().encode($0) }, forKey: "downtime") }
    }
    var downtimeHeardAt: Date?
    var onChange: ((Decision, Decision) -> Void)?
    var onBreakEarned: (() -> Void)?

    private init() {
        mode = Mode(rawValue: defaults.string(forKey: "mode") ?? "") ?? .allDone
        alwaysBlock = Set(defaults.stringArray(forKey: "alwaysBlock") ?? [])
        neverBlock = Set(defaults.stringArray(forKey: "neverBlock") ?? [])
        sitesOff = Set(defaults.stringArray(forKey: "sitesOff") ?? [])
        grantUntil = defaults.object(forKey: "grantUntil") as? Date
        extraUntil = defaults.object(forKey: "extraUntil") as? Date
        extraDay = defaults.string(forKey: "extraDay") ?? ""
        extraCount = defaults.integer(forKey: "extraCount")
        seenKeys = Set(defaults.stringArray(forKey: "seenKeys") ?? [])
        knownSources = Set(defaults.stringArray(forKey: "knownSources") ?? [])
        keyVersions = (defaults.dictionary(forKey: "keyVersions") as? [String: Int]) ?? [:]
        downtime = defaults.data(forKey: "downtime").flatMap { try? JSONDecoder().decode(DowntimeInfo.self, from: $0) }
    }

    /// The Mac app and the Chrome extension each keep their own settings and
    /// both talk to the lock, so the schedule CHANGED most recently wins —
    /// not whichever spoke last, which would flip it every minute.
    func takeDowntime(_ d: DowntimeInfo?, at now: Date) {
        guard let d else { return }
        if let have = downtime, (d.set_at ?? 0) < (have.set_at ?? 0) { return }
        if d != downtime { downtime = d }
        downtimeHeardAt = now
    }

    func downtimeNow(_ now: Date = Date()) -> String? {
        downtimeEnd(downtime, now: now, heardAt: downtimeHeardAt)
    }

    func receive(_ status: LockStatus, from source: String, at now: Date = Date()) {
        let prev = heard[source]
        let changed = prev == nil || prev!.status.fingerprint != status.fingerprint
        heard[source] = Heard(status: status, receivedAt: now, changedAt: changed ? now : prev!.changedAt)
        takeDowntime(status.downtime, at: now)

        // The 30-minute rule: something newly ticked Done. The first message
        // from a source is its baseline — otherwise the first run would hand out
        // a break for every assignment finished last week.
        let keys = Set(status.done_keys ?? [])
        // A "not loaded yet" message is no baseline: when the board then
        // arrived, a week of finished work counted as new and granted a
        // break (prosecution 2026-10-06).
        guard status.known else { refresh(now); return }
        // New key format from this source: its keys are all "new" but none
        // was just finished — start its baseline again (round 2, 2026-10-07).
        let version = status.key_version ?? 1
        if keyVersions[source] != version {
            keyVersions[source] = version
            defaults.set(keyVersions, forKey: "keyVersions")
            knownSources.remove(source)
        }
        if knownSources.contains(source) {
            let newlyDone = keys.subtracting(seenKeys)
            // Not during Downtime: a break cannot open it, and a "30 minutes
            // unlocked" card over a shut lock would be a lie.
            if !newlyDone.isEmpty, mode == .perAssignment, status.known, !status.done,
               status.for_date == todayString(now, zone: status.tz), downtimeNow(now) == nil {
                grantUntil = now.addingTimeInterval(K.breakSeconds)
                onBreakEarned?()
            }
        } else {
            knownSources.insert(source)
            defaults.set(Array(knownSources), forKey: "knownSources")
        }
        if !keys.isSubset(of: seenKeys) {
            seenKeys.formUnion(keys)
            if seenKeys.count > K.maxSeenKeys { seenKeys = keys }
            defaults.set(Array(seenKeys), forKey: "seenKeys")
        }
        refresh(now)
    }

    /// The coach's few minutes. Refused past extraPerDay grants a school day.
    func grantExtra(minutes: Int, now: Date = Date()) -> (ok: Bool, until: Date?, leftToday: Int) {
        // The school's day, from the source heard most recently — not
        // whichever the dictionary lists first (round 6).
        let newest = heard.values.max { $0.receivedAt < $1.receivedAt }
        let day = newest.map { todayString(now, zone: $0.status.tz) } ?? todayString(now)
        if extraDay != day { extraDay = day; extraCount = 0 }
        guard extraCount < K.extraPerDay else { return (false, nil, 0) }
        let mins = max(1, min(minutes, K.extraMaxMinutes))
        extraUntil = now.addingTimeInterval(TimeInterval(mins * 60))
        extraCount += 1
        refresh(now)
        return (true, extraUntil, K.extraPerDay - extraCount)
    }

    func refresh(_ now: Date = Date()) {
        var next = decide(heard: heard, now: now, mode: mode, grantUntil: grantUntil,
                          downtime: downtime, downtimeHeardAt: downtimeHeardAt)
        // "Get More Time" opens it even during Downtime — the escape hatch,
        // capped at extraPerDay a day ([ASKED] 2026-10-07).
        if next.locked, let until = extraUntil, until > now {
            let left = until.timeIntervalSince(now)
            next = Decision(locked: false, headline: "Extra time: \(Int((left / 60).rounded(.up))) min left",
                            detail: "You talked your way into a few minutes. Then it locks again.",
                            open: next.open, openCount: next.openCount, overdueCount: next.overdueCount,
                            breakLeft: left, heardAt: next.heardAt)
        }
        let old = decision
        if next != old { decision = next }
        onChange?(old, next)
    }

    func isBlocked(id: String, defaultBlocked: Bool) -> Bool {
        if neverBlock.contains(id) { return false }
        if alwaysBlock.contains(id) { return true }
        return defaultBlocked
    }

    func isSiteBlocked(_ id: String) -> Bool { !sitesOff.contains(id) }

    func setBlocked(_ app: AppInfo, _ on: Bool) {
        alwaysBlock.remove(app.id); neverBlock.remove(app.id)
        if on != app.defaultBlocked { if on { alwaysBlock.insert(app.id) } else { neverBlock.insert(app.id) } }
    }

    func blocks(_ app: NSRunningApplication) -> Bool {
        guard app.activationPolicy == .regular, app.processIdentifier != getpid() else { return false }
        let (def, _) = Catalog.classify(id: app.bundleIdentifier, url: app.bundleURL, name: app.localizedName,
                                        exe: app.executableURL)
        // Minecraft's game follows the switch for its launcher (it has no id of its own).
        let id = app.bundleIdentifier
            ?? (Self.displayName(app) == "Minecraft" ? "com.mojang.minecraftlauncher" : "name:" + (app.localizedName ?? "?"))
        return isBlocked(id: id, defaultBlocked: def)
    }

    /// Minecraft's game window belongs to a process called "java".
    static func displayName(_ app: NSRunningApplication) -> String {
        if let p = app.executableURL?.path, p.contains("/Application Support/minecraft/") { return "Minecraft" }
        return app.localizedName ?? "That app"
    }

    /// The icon Screen Time would show: Minecraft's game has none of its own.
    static func displayIcon(_ app: NSRunningApplication) -> NSImage? {
        if displayName(app) == "Minecraft", app.bundleIdentifier == nil {
            let ws = NSWorkspace.shared
            if let url = ws.urlForApplication(withBundleIdentifier: "com.mojang.minecraftlauncher") {
                return ws.icon(forFile: url.path)
            }
        }
        return app.icon
    }

    var lastHeard: Date? { heard.values.map(\.receivedAt).max() }
}

// MARK: - Listening on 127.0.0.1:5066

struct HTTPRequest {
    var method: String
    var path: String
    var headers: [String: String]
    var query: [String: String] = [:]
    var body: Data

    /// nil until the whole request has arrived.
    static func parse(_ buf: Data) -> HTTPRequest? {
        guard let end = buf.range(of: Data("\r\n\r\n".utf8)) else { return nil }
        guard let head = String(data: buf[buf.startIndex..<end.lowerBound], encoding: .utf8) else { return nil }
        var lines = head.components(separatedBy: "\r\n")
        let first = lines.removeFirst().split(separator: " ")
        guard first.count >= 2 else { return nil }
        var headers: [String: String] = [:]
        for line in lines {
            guard let colon = line.firstIndex(of: ":") else { continue }
            headers[line[..<colon].trimmingCharacters(in: .whitespaces).lowercased()] =
                line[line.index(after: colon)...].trimmingCharacters(in: .whitespaces)
        }
        // A negative or unreadable length used to reach body.prefix(-1) and
        // crash the lock — before any Origin check (prosecution 2026-10-06).
        guard let length = Int(headers["content-length"] ?? "0"), length >= 0 else {
            return HTTPRequest(method: "BAD", path: "/", headers: headers, body: Data())
        }
        let body = buf[end.upperBound...]
        guard body.count >= length else { return nil }
        let target = String(first[1])
        let path = target.split(separator: "?").first.map(String.init) ?? "/"
        var query: [String: String] = [:]
        if let q = target.split(separator: "?", maxSplits: 1).dropFirst().first {
            for pair in q.split(separator: "&") {
                let kv = pair.split(separator: "=", maxSplits: 1).map { String($0).removingPercentEncoding ?? String($0) }
                if kv.count == 2 { query[kv[0]] = kv[1] }
            }
        }
        return HTTPRequest(method: String(first[0]), path: path, headers: headers, query: query,
                           body: Data(body.prefix(length)))
    }
}

struct HTTPResponse {
    var status: Int
    var headers: [String: String] = [:]
    var body = Data()

    var data: Data {
        let reason = [200: "OK", 204: "No Content", 400: "Bad Request", 403: "Forbidden",
                      404: "Not Found", 413: "Too Large"][status] ?? "Error"
        var head = "HTTP/1.1 \(status) \(reason)\r\n"
        var h = headers
        h["Content-Length"] = String(body.count)
        h["Connection"] = "close"
        h["Cache-Control"] = "no-store"
        for (k, v) in h.sorted(by: { $0.key < $1.key }) { head += "\(k): \(v)\r\n" }
        return Data((head + "\r\n").utf8) + body
    }
}

@MainActor
func decisionJSON(_ d: Decision, mode: Mode) -> Data {
    var o: [String: Any] = ["app": "SillyBus Lock", "locked": d.locked, "headline": d.headline,
                            "mode": mode.rawValue]
    if let left = d.breakLeft { o["break_seconds_left"] = Int(left) }
    if let until = d.downtimeUntil { o["downtime_until"] = until }
    o["chrome_access"] = Chrome.allowedForUI.map { $0 ? "allowed" : "not allowed" } ?? "not asked yet"
    // Who has spoken, and when — names and ages only, for "is it connected?".
    o["heard_from"] = LockModel.shared.heard.map { name, h in
        ["source": name, "seconds_ago": Int(Date().timeIntervalSince(h.receivedAt)), "for_date": h.status.for_date]
    }
    return (try? JSONSerialization.data(withJSONObject: o)) ?? Data("{}".utf8)
}

func esc(_ s: String) -> String {
    s.replacingOccurrences(of: "&", with: "&amp;").replacingOccurrences(of: "<", with: "&lt;")
        .replacingOccurrences(of: ">", with: "&gt;").replacingOccurrences(of: "\"", with: "&quot;")
}

/// The Time Limit page a blocked site's tab is turned into — Screen Time's
/// look, as a web page, so Chrome itself stays usable.
@MainActor
func limitPage(site: Site?, decision d: Decision) -> String {
    let name = site.map { $0.id == "games" ? "game websites" : $0.label } ?? "this website"
    var items = ""
    for i in d.open.prefix(5) {
        let sub = [i.course ?? "", dueWord(i.due)].filter { !$0.isEmpty }.joined(separator: " · ")
        items += "<li><b>\(esc(i.title))</b><small>\(esc(sub))</small></li>"
    }
    if !d.open.isEmpty && d.openCount > min(5, d.open.count) {
        items += "<li class=more>+ \(d.openCount - min(5, d.open.count)) more</li>"
    }
    // Downtime is its own reason, and says so ([ASKED] 2026-10-07).
    let title = d.downtimeUntil == nil ? "Time Limit" : "Downtime"
    let why = d.downtimeUntil.map { "It's Downtime, so \(name) is closed until \(clockWords($0))." }
        ?? "You've reached your limit on \(name)."
    let list = items.isEmpty
        ? (d.openCount > 0 ? "<p class=sub>\(plural(d.openCount, "thing", "things")) due today or tomorrow — open SillyBus to see the list.</p>" : "")
        : "<ul>\(items)</ul>"
    return """
    <!doctype html><html lang=en><head><meta charset=utf-8>
    <meta name=viewport content="width=device-width,initial-scale=1">
    <title>\(esc(title))</title>
    <style>
    :root{--bg:#f2f2f7;--card:#fff;--ink:#1c1c1e;--sub:#6e6e73;--accent:#0a84ff;--hour:#5856d6}
    @media (prefers-color-scheme:dark){:root{--bg:#1c1c1e;--card:#2c2c2e;--ink:#f5f5f7;--sub:#a1a1a6}}
    *{box-sizing:border-box}html,body{height:100%;margin:0}
    body{background:var(--bg);color:var(--ink);font:15px/1.4 -apple-system,system-ui,sans-serif;
      display:flex;align-items:center;justify-content:center;padding:24px}
    main{max-width:440px;width:100%;text-align:center}
    .glass{width:84px;height:84px;border-radius:50%;background:var(--hour);display:grid;place-items:center;margin:0 auto 18px}
    h1{font-size:32px;margin:0 0 6px}p{margin:0 0 10px}.sub{color:var(--sub)}
    ul{list-style:none;margin:18px 0;padding:12px 14px;background:var(--card);border-radius:14px;text-align:left}
    li{padding:6px 0}li b{display:block;font-weight:500}li small{color:var(--sub);font-size:12px}
    li.more{color:var(--sub);font-size:12px}
    button{font:inherit;cursor:pointer;border:0}
    #ok{display:block;width:240px;margin:22px auto 6px;padding:10px;border-radius:999px;background:var(--accent);color:#fff;font-weight:600;font-size:16px}
    #more{background:none;color:var(--accent);font-weight:600;margin-top:12px}
    .tiny{color:var(--sub);font-size:12px}
    </style></head><body><main>
    <div class=glass><svg width=40 height=40 viewBox="0 0 24 24" fill=none stroke=#fff stroke-width=2 stroke-linecap=round stroke-linejoin=round>
    <path d="M6 2h12M6 22h12M7 2c0 5 10 5 10 10S7 17 7 22M17 2c0 5-10 5-10 10s10 5 10 10"/></svg></div>
    <h1>\(esc(title))</h1>
    <p class=sub>\(esc(why))</p>
    <p>\(esc(d.detail))</p>
    \(list)
    <button id=ok autofocus>OK</button>
    <div class=tiny>OK closes this tab. The rest of Chrome is yours.</div>
    <button id=more data-site="\(esc(name))">Get More Time</button>
    <div class=tiny>A short hold gives you a few more minutes, without a chat.</div>
    </main><script>
    const send = (p) => fetch(p, {method: "POST"}).catch(() => {});
    document.getElementById("ok").onclick = () => send("/limit/close");
    document.getElementById("more").onclick = (e) => send("/limit/more?site=" + encodeURIComponent(e.currentTarget.dataset.site || ""));
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") send("/limit/close"); });
    // Unlocked while this page is open: back to where he was.
    setInterval(async () => {
      try { const s = await (await fetch("/status")).json(); if (!s.locked) history.back(); } catch (e) {}
    }, 5000);
    </script></body></html>
    """
}

/// Everything the server does, without the network — the self-test drives it.
@MainActor
func handle(_ req: HTTPRequest, model: LockModel) -> HTTPResponse {
    if req.method == "BAD" { return HTTPResponse(status: 400) }
    let origin = req.headers["origin"]
    guard hostAllowed(req.headers["host"]) else { return HTTPResponse(status: 403) }
    var cors: [String: String] = ["Vary": "Origin"]
    if let origin, originAllowed(origin) {
        cors["Access-Control-Allow-Origin"] = origin
        cors["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        cors["Access-Control-Allow-Headers"] = "Content-Type"
        cors["Access-Control-Allow-Private-Network"] = "true"
    }
    if req.path == "/limit" && req.method == "GET" {
        let id = req.query["site"] ?? ""
        let site = Sites.all.first { $0.id == id }
        return HTTPResponse(status: 200, headers: ["Content-Type": "text/html; charset=utf-8"],
                            body: Data(limitPage(site: site, decision: model.decision).utf8))
    }
    if req.path == "/more-time" {
        // Only the Mac app's /talk page grants minutes, after the coach.
        var talkCors: [String: String] = ["Vary": "Origin"]
        guard origin == K.macAppOrigin else { return HTTPResponse(status: 403, headers: talkCors) }
        talkCors["Access-Control-Allow-Origin"] = origin
        talkCors["Access-Control-Allow-Methods"] = "POST, OPTIONS"
        talkCors["Access-Control-Allow-Headers"] = "Content-Type"
        talkCors["Access-Control-Allow-Private-Network"] = "true"
        if req.method == "OPTIONS" { return HTTPResponse(status: 204, headers: talkCors) }
        guard req.method == "POST" else { return HTTPResponse(status: 405, headers: talkCors) }
        let asked = (try? JSONSerialization.jsonObject(with: req.body) as? [String: Any])?["minutes"] as? Int ?? 5
        let got = model.grantExtra(minutes: asked)
        talkCors["Content-Type"] = "application/json"
        var out: [String: Any] = ["granted": got.ok, "left_today": got.leftToday]
        if let until = got.until { out["until"] = until.timeIntervalSince1970 }
        return HTTPResponse(status: got.ok ? 200 : 429, headers: talkCors,
                            body: (try? JSONSerialization.data(withJSONObject: out)) ?? Data())
    }
    if (req.path == "/limit/close" || req.path == "/limit/more") && req.method == "POST" {
        // Only the Time Limit page itself (served from here) may press its buttons.
        guard origin == "http://127.0.0.1:\(K.port)" else { return HTTPResponse(status: 403) }
        if req.path == "/limit/more" {
            let raw = req.query["site"] ?? ""
            openTalk(app: raw.replacingOccurrences(of: "+", with: " ").removingPercentEncoding ?? raw)
        }
        // After the reply, so the page is not closed mid-request.
        Chrome.closeLimitTabs()
        return HTTPResponse(status: 204)
    }
    guard req.path == "/status" else { return HTTPResponse(status: 404, headers: cors) }
    switch req.method {
    case "OPTIONS":
        return HTTPResponse(status: originAllowed(origin) ? 204 : 403, headers: cors)
    case "GET":
        if origin != nil && !originAllowed(origin) { return HTTPResponse(status: 403) }
        cors["Content-Type"] = "application/json"
        return HTTPResponse(status: 200, headers: cors, body: decisionJSON(model.decision, mode: model.mode))
    case "POST":
        guard let origin, originAllowed(origin) else { return HTTPResponse(status: 403) }
        guard req.body.count <= K.maxBody,
              let status = try? JSONDecoder().decode(LockStatus.self, from: req.body) else {
            return HTTPResponse(status: 400, headers: cors)
        }
        model.receive(status, from: sourceName(origin))
        cors["Content-Type"] = "application/json"
        return HTTPResponse(status: 200, headers: cors, body: decisionJSON(model.decision, mode: model.mode))
    default:
        return HTTPResponse(status: 404, headers: cors)
    }
}

final class LockServer: @unchecked Sendable {
    private var listener: NWListener?

    func start() throws {
        let params = NWParameters.tcp
        params.allowLocalEndpointReuse = true
        params.requiredLocalEndpoint = .hostPort(host: "127.0.0.1", port: NWEndpoint.Port(rawValue: K.port)!)
        let l = try NWListener(using: params)
        l.newConnectionHandler = { [weak self] conn in
            conn.start(queue: .main)
            // A connection that never finishes its request is dropped after
            // ten seconds rather than held for ever (prosecution 2026-10-06).
            DispatchQueue.main.asyncAfter(deadline: .now() + 10) { conn.cancel() }
            self?.read(conn, Data())
        }
        l.stateUpdateHandler = { state in
            if case .failed(let err) = state {
                NSLog("SillyBus Lock: cannot listen on \(K.port): \(err)")
            }
        }
        l.start(queue: .main)
        listener = l
    }

    private func read(_ conn: NWConnection, _ buf: Data) {
        conn.receive(minimumIncompleteLength: 1, maximumLength: 65536) { [weak self] data, _, complete, error in
            var buf = buf
            if let data { buf.append(data) }
            if buf.count > K.maxBody + 16 * 1024 {
                self?.reply(conn, HTTPResponse(status: 413)); return
            }
            if let req = HTTPRequest.parse(buf) {
                MainActor.assumeIsolated {
                    self?.reply(conn, handle(req, model: LockModel.shared))
                }
            } else if complete || error != nil {
                conn.cancel()
            } else {
                self?.read(conn, buf)
            }
        }
    }

    private func reply(_ conn: NWConnection, _ res: HTTPResponse) {
        conn.send(content: res.data, completion: .contentProcessed { _ in conn.cancel() })
    }
}

// MARK: - Asking the Mac app

@MainActor
func pullFromMacApp() {
    var req = URLRequest(url: K.pullURL, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 8)
    req.setValue("application/json", forHTTPHeaderField: "Accept")
    URLSession.shared.dataTask(with: req) { data, resp, _ in
        guard let data, (resp as? HTTPURLResponse)?.statusCode == 200,
              let status = try? JSONDecoder().decode(LockStatus.self, from: data) else { return }
        DispatchQueue.main.async {
            MainActor.assumeIsolated { LockModel.shared.receive(status, from: "mac-app") }
        }
    }.resume()
}

// MARK: - Opening SillyBus

/// "Get More Time": a local hold confirmation on the Mac app.
/// Without the Mac app running, SillyBus itself.
@MainActor
func openTalk(app: String) {
    var req = URLRequest(url: URL(string: "http://127.0.0.1:5055/api/health")!,
                         cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 2)
    req.httpMethod = "GET"
    URLSession.shared.dataTask(with: req) { _, resp, _ in
        let up = (resp as? HTTPURLResponse)?.statusCode == 200
        DispatchQueue.main.async {
            MainActor.assumeIsolated {
                var c = URLComponents(string: K.talkURL)!
                c.queryItems = [URLQueryItem(name: "app", value: String(app.prefix(60)))]
                if up, let url = c.url { NSWorkspace.shared.open(url) } else { openSillyBus() }
            }
        }
    }.resume()
}

@MainActor
func openSillyBus() {
    let fm = FileManager.default
    let home = fm.homeDirectoryForCurrentUser.path
    let heard = LockModel.shared.heard
    let ext = heard.filter { $0.key.hasPrefix("extension:") }.max { $0.value.receivedAt < $1.value.receivedAt }?.key
    // The Mac app, unless its sign-in has expired and Chrome's copy has spoken
    // — then the board he can actually read is in Chrome.
    let macSignedOut = heard["mac-app"]?.status.signed_out == true
    if !(macSignedOut && ext != nil) {
        for p in ["\(home)/Applications/Silly Bus AI.app", "/Applications/Silly Bus AI.app"] where fm.fileExists(atPath: p) {
            NSWorkspace.shared.openApplication(at: URL(fileURLWithPath: p), configuration: .init())
            return
        }
    }
    if let ext {
        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/usr/bin/open")
        p.arguments = ["-a", "Google Chrome", "chrome-extension://\(ext.dropFirst("extension:".count))/index.html"]
        try? p.run()
        return
    }
    NSWorkspace.shared.open(URL(string: "http://127.0.0.1:5055/")!)
}

// MARK: - The card that appears over a blocked app

final class CardPanel: NSPanel {
    override var canBecomeKey: Bool { true }
}

/// [MEASURED] 2026-10-06 in his screen recording: OK took two clicks — the
/// first only made the panel key. A click on a card is always meant.
final class FirstClickHostingView<V: View>: NSHostingView<V> {
    override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }
}

enum CardKind: Equatable {
    case breakEarned           // ticked one Done in 30-minute mode
    case welcome               // the first launch
}

struct LockCard: View {
    @ObservedObject var model = LockModel.shared
    var kind: CardKind
    var close: () -> Void

    var title: String {
        switch kind {
        case .breakEarned: return "30 minutes unlocked"
        case .welcome: return "SillyBus Lock is on"
        }
    }

    var icon: (String, Color) {
        switch kind {
        case .breakEarned: return ("party.popper.fill", .orange)
        case .welcome: return ("hourglass", Color(red: 0.35, green: 0.34, blue: 0.84))
        }
    }

    var body: some View {
        let d = model.decision
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 10) {
                Image(systemName: icon.0)
                    .font(.system(size: 26, weight: .semibold))
                    .foregroundStyle(icon.1)
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.title3.bold())
                    Text(d.headline).font(.callout).foregroundStyle(.secondary)
                }
            }
            if kind == .welcome {
                Text("While schoolwork is due today or tomorrow, games and social media apps get a Time Limit, "
                     + "like Screen Time. Tick your work Done in SillyBus and they open up.")
                    .font(.callout).fixedSize(horizontal: false, vertical: true)
                Text("Pick which apps, and how it unlocks, from the lock in the menu bar (top right).")
                    .font(.callout).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            if !d.open.isEmpty && kind != .breakEarned {
                VStack(alignment: .leading, spacing: 6) {
                    ForEach(Array(d.open.prefix(6).enumerated()), id: \.offset) { _, item in
                        HStack(alignment: .firstTextBaseline, spacing: 6) {
                            Image(systemName: "circle").font(.caption).foregroundStyle(.secondary)
                            VStack(alignment: .leading, spacing: 1) {
                                Text(item.title).lineLimit(2)
                                Text([item.course ?? "", dueWord(item.due)].filter { !$0.isEmpty }
                                        .joined(separator: " · "))
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }
                    if d.openCount > min(6, d.open.count) {
                        Text("+ \(d.openCount - min(6, d.open.count)) more").font(.caption).foregroundStyle(.secondary)
                    }
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(RoundedRectangle(cornerRadius: 10).fill(Color.primary.opacity(0.06)))
            }
            if d.locked && d.open.isEmpty && d.openCount > 0 && kind != .breakEarned {
                Text("Open SillyBus to see the list.").font(.callout).foregroundStyle(.secondary)
            }
            if kind != .welcome {
                Text(d.detail).font(.callout).fixedSize(horizontal: false, vertical: true)
            }
            if d.overdueCount > 0 && kind != .breakEarned {
                Text("Also \(plural(d.overdueCount, "overdue item", "overdue items")) on your board (these don't keep the lock shut).")
                    .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            HStack {
                Spacer()
                Button("OK", action: close).keyboardShortcut(.cancelAction)
                Button("Open SillyBus") { openSillyBus(); close() }
                    .keyboardShortcut(.defaultAction)
            }
        }
        .padding(20)
        .frame(width: 400)
    }
}

@MainActor
final class Card {
    private var panel: CardPanel?
    private var hideTimer: Timer?

    func show(_ kind: CardKind, autoClose: TimeInterval? = nil) {
        if Env.watchOnly { NSLog("SillyBus Lock (watch-only) would show card \(kind)"); return }
        hideTimer?.invalidate()
        let view = LockCard(kind: kind) { [weak self] in self?.close() }
        let host = FirstClickHostingView(rootView: view)
        let p = panel ?? CardPanel(contentRect: NSRect(x: 0, y: 0, width: 400, height: 200),
                                   styleMask: [.titled, .closable, .fullSizeContentView, .nonactivatingPanel],
                                   backing: .buffered, defer: false)
        p.titleVisibility = .hidden
        p.titlebarAppearsTransparent = true
        p.isMovableByWindowBackground = true
        p.level = .floating
        p.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
        p.standardWindowButton(.miniaturizeButton)?.isHidden = true
        p.standardWindowButton(.zoomButton)?.isHidden = true
        p.isReleasedWhenClosed = false
        // [MEASURED] 2026-10-06: a panel hides itself when its app is not
        // frontmost — and this app never is, so the card was there but off
        // screen while he sat in full-screen Chrome. Over another app's
        // full-screen space only a NON-ACTIVATING panel may appear at all.
        p.hidesOnDeactivate = false
        p.contentView = host
        p.setContentSize(host.fittingSize)
        p.center()
        panel = p
        // This app is never frontmost, and makeKeyAndOrderFront from an app
        // that is not active orders nothing: orderFrontRegardless is the call
        // that shows a window over whatever he is using.
        p.orderFrontRegardless()
        p.makeKey()
        if let autoClose {
            hideTimer = Timer.scheduledTimer(withTimeInterval: autoClose, repeats: false) { [weak self] _ in
                MainActor.assumeIsolated { self?.close() }
            }
        }
    }

    func close() { panel?.orderOut(nil) }
    var isShowing: Bool { panel?.isVisible ?? false }
}

// MARK: - Websites (YouTube and friends, in Google Chrome)
//
// [ASKED] 2026-10-06: "make it block youtube too". A website is not an app, so
// the lock asks Chrome — by Apple Events, the one way an app may read another
// app's front tab — what the tab in front is. macOS asks him once to allow it
// (NSAppleEventsUsageDescription). The same eleven sites as SillyBus's Focus
// list (sillybus/focus.py PRESETS), plus the game sites a school Mac sees.

struct Site: Identifiable, Hashable {
    var id: String
    var label: String
    var hosts: [String]
}

enum Sites {
    static let all: [Site] = [
        Site(id: "youtube", label: "YouTube", hosts: ["youtube.com", "youtu.be", "youtube-nocookie.com"]),
        Site(id: "instagram", label: "Instagram", hosts: ["instagram.com"]),
        Site(id: "tiktok", label: "TikTok", hosts: ["tiktok.com"]),
        Site(id: "snapchat", label: "Snapchat", hosts: ["snapchat.com"]),
        Site(id: "x", label: "X / Twitter", hosts: ["x.com", "twitter.com"]),
        Site(id: "reddit", label: "Reddit", hosts: ["reddit.com"]),
        Site(id: "facebook", label: "Facebook", hosts: ["facebook.com"]),
        Site(id: "discord", label: "Discord", hosts: ["discord.com"]),
        Site(id: "twitch", label: "Twitch", hosts: ["twitch.tv"]),
        Site(id: "netflix", label: "Netflix", hosts: ["netflix.com"]),
        Site(id: "pinterest", label: "Pinterest", hosts: ["pinterest.com"]),
        Site(id: "games", label: "Game sites (Roblox, Poki, CrazyGames, Coolmath…)",
             hosts: ["roblox.com", "poki.com", "crazygames.com", "coolmathgames.com", "now.gg", "miniclip.com",
                     "y8.com", "kongregate.com", "armorgames.com", "friv.com", "agame.com"]),
    ]

    /// Suffix match on the host, so m.youtube.com counts and notyoutube.com does not.
    static func match(_ urlString: String) -> Site? {
        guard let url = URL(string: urlString), let scheme = url.scheme, scheme.hasPrefix("http"),
              var host = url.host?.lowercased() else { return nil }
        // "www.youtube.com." (a trailing dot) is the same site.
        while host.hasSuffix(".") { host.removeLast() }
        return all.first { site in site.hosts.contains { host == $0 || host.hasSuffix("." + $0) } }
    }
}

struct ChromeTab { var window: Int; var tab: Int; var url: String }

/// Everything sent to Chrome runs on ONE background lane (`queue`), each
/// script under a 5-second timeout. It used to run on the main thread every
/// two seconds, two Apple events per tab — a beachballing Chrome froze the
/// whole lock (no enforcement, no /status, a dead menu) for up to the
/// two-minute Apple-event default (prosecution 2026-10-06). The lane's state
/// is touched only on the lane; the main thread reads `allowedForUI`.
enum Chrome {
    static let bundleID = "com.google.Chrome"
    static let queue = DispatchQueue(label: "sillybus.lock.chrome", qos: .utility)
    /// nil until known; false once he has said no in the macOS prompt. (lane)
    nonisolated(unsafe) private static var allowed: Bool?
    nonisolated(unsafe) private static var asking = false
    nonisolated(unsafe) private static var askedAt = Date.distantPast
    /// A sweep is queued or running. Set and cleared on the MAIN thread: the
    /// old `busy` flag lived on the lane and was always false by the time the
    /// next block ran, so a hung Chrome piled up sweeps that fired after
    /// unlocking (round 2, 2026-10-07).
    nonisolated(unsafe) private static var sweepPending = false
    /// The same answer, for the menu, Settings and /status. (main thread)
    nonisolated(unsafe) static var allowedForUI: Bool?

    private static func setAllowed(_ value: Bool?) {
        allowed = value
        DispatchQueue.main.async { allowedForUI = value }
    }

    /// The macOS "allow SillyBus Lock to control Google Chrome?" question,
    /// asked on its own thread: the answer can take him minutes. (lane)
    private static func checkPermission(ask: Bool) {
        guard !asking else { return }
        asking = true
        askedAt = Date()
        let id = bundleID
        DispatchQueue.global(qos: .userInitiated).async {
            var addr = AEAddressDesc()
            let status: OSStatus = id.withCString { ptr in
                OSStatus(AECreateDesc(DescType(typeApplicationBundleID), ptr, strlen(ptr), &addr))
            }
            let result: OSStatus = status == noErr
                ? AEDeterminePermissionToAutomateTarget(&addr, AEEventClass(typeWildCard), AEEventID(typeWildCard), ask)
                : status
            AEDisposeDesc(&addr)
            queue.async {
                asking = false
                switch result {
                case noErr: setAllowed(true)
                case OSStatus(procNotFound): break            // Chrome not running: ask when it is
                default: setAllowed(false)                     // -1743 denied, -1744 not asked yet
                }
            }
        }
    }

    /// (lane)
    private static func run(_ source: String) -> NSAppleEventDescriptor? {
        if Env.selfTest { return nil }
        guard allowed == true else {
            // Unknown: ask (once). Denied: look again each minute, quietly, in
            // case he switched it on in System Settings.
            if allowed == nil { checkPermission(ask: true) }
            else if Date().timeIntervalSince(askedAt) > 60 { checkPermission(ask: false) }
            return nil
        }
        var err: NSDictionary?
        let out = NSAppleScript(source: "with timeout of 5 seconds\n\(source)\nend timeout")?.executeAndReturnError(&err)
        if let code = err?[NSAppleScript.errorNumber] as? Int {
            if code == -1743 { setAllowed(false) }
            NSLog("SillyBus Lock: Chrome script failed \(code): \(err?[NSAppleScript.errorMessage] ?? "")")
        }
        return err == nil ? out : nil
    }

    static var isRunning: Bool {
        !NSRunningApplication.runningApplications(withBundleIdentifier: bundleID).isEmpty
    }

    /// (lane)
    private static func tabs() -> [ChromeTab] {
        // Not `tab` for the separator: inside Chrome's dictionary `tab` is a
        // Chrome tab, and the list came back empty ([MEASURED] 2026-10-06).
        let script = """
        set sep to character id 9
        set out to ""
        tell application id "\(bundleID)"
          repeat with w in windows
            set wid to id of w
            repeat with t in tabs of w
              set out to out & wid & sep & (id of t) & sep & (URL of t) & linefeed
            end repeat
          end repeat
        end tell
        return out
        """
        guard let text = run(script)?.stringValue else { return [] }
        return text.split(separator: "\n").compactMap { line in
            let f = line.split(separator: "\t", maxSplits: 2).map(String.init)
            guard f.count == 3, let w = Int(f[0]), let t = Int(f[1]) else { return nil }
            return ChromeTab(window: w, tab: t, url: f[2])
        }
    }

    private static func tabRef(_ t: ChromeTab) -> String {
        "(first tab of (first window whose id is \(t.window)) whose id is \(t.tab))"
    }

    static func limitURL(_ site: Site) -> String { "http://127.0.0.1:\(K.port)/limit?site=\(site.id)" }

    /// [ASKED] 2026-10-06: "only social media and games not chrome I need
    /// chrome for work". A blocked site's TAB becomes the Time Limit page —
    /// the way Screen Time does it in Safari — and every other tab and window
    /// stays his. All tabs, not just the front one: a YouTube tab playing in a
    /// window behind is still YouTube. Skipped while the last sweep still runs.
    static func limitBlockedTabs(blocked: Set<String>) {
        guard !sweepPending else { return }
        sweepPending = true
        queue.async {
            defer { DispatchQueue.main.async { sweepPending = false } }
            for t in tabs() {
                guard let site = Sites.match(t.url), blocked.contains(site.id) else { continue }
                _ = run("tell application id \"\(bundleID)\" to set URL of \(tabRef(t)) to \"\(limitURL(site))\"")
            }
        }
    }

    /// OK on the Time Limit page: "when you hit ok close it".
    static func closeLimitTabs() {
        queue.async {
            for t in tabs() where t.url.hasPrefix("http://127.0.0.1:\(K.port)/limit") {
                _ = run("tell application id \"\(bundleID)\" to close \(tabRef(t))")
            }
        }
    }
}

// MARK: - The Time Limit screen (Screen Time's look)
//
// [ASKED] 2026-10-06, after seeing the first version hide apps: "i want it to
// be screen time for app not this". Real Screen Time can only be driven by an
// app holding Apple's Family Controls entitlement — a paid developer account
// and Apple's approval (IPHONE.md) — so this is Screen Time's SHIELD, drawn by
// us. Then: "work better less glichy and when you hit ok close it" — so a
// blocked APP is put away the instant it comes up (a game in front keeps the
// mouse, and Minecraft grabs it), the screen stays until OK, and OK QUITS the
// app, or closes the site's tabs.

/// What the full-screen Time Limit covers: an app. (A website's tab gets the
/// Time Limit PAGE instead — `limitPage` — so Chrome itself stays usable.)
enum ShieldTarget {
    case app(NSRunningApplication)

    var key: String {
        switch self { case .app(let a): return "app:\(a.processIdentifier)" }
    }
    @MainActor var name: String {
        switch self { case .app(let a): return LockModel.displayName(a) }
    }
    @MainActor var icon: NSImage? {
        switch self { case .app(let a): return LockModel.displayIcon(a) }
    }
}

struct ShieldView: View {
    @ObservedObject var model = LockModel.shared
    var appName: String
    var icon: NSImage?
    var ok: () -> Void
    var more: () -> Void = {}

    var body: some View {
        let d = model.decision
        VStack(spacing: 16) {
            ZStack(alignment: .bottomTrailing) {
                Image(nsImage: icon ?? NSImage(systemSymbolName: "app.dashed", accessibilityDescription: nil)!)
                    .resizable().interpolation(.high).frame(width: 96, height: 96)
                    .opacity(0.8)
                Image(systemName: d.downtimeUntil == nil ? "hourglass" : "moon.fill")
                    .font(.system(size: 20, weight: .bold)).foregroundStyle(.white)
                    .frame(width: 40, height: 40)
                    .background(Circle().fill(Color(red: 0.35, green: 0.34, blue: 0.84)))
                    .overlay(Circle().stroke(Color.white.opacity(0.9), lineWidth: 2))
                    .offset(x: 8, y: 8)
            }
            .padding(.bottom, 6)
            Text(d.downtimeUntil == nil ? "Time Limit" : "Downtime").font(.system(size: 34, weight: .bold))
            Text(d.downtimeUntil.map { "It's Downtime, so \(appName) is closed until \(clockWords($0))." }
                    ?? "You've reached your limit on \(appName).")
                .font(.title3).foregroundStyle(.secondary).multilineTextAlignment(.center)
            Text(d.detail).font(.body).multilineTextAlignment(.center).fixedSize(horizontal: false, vertical: true)

            if !d.open.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(Array(d.open.prefix(5).enumerated()), id: \.offset) { _, item in
                        HStack(alignment: .firstTextBaseline, spacing: 8) {
                            Image(systemName: "circle").font(.caption).foregroundStyle(.secondary)
                            VStack(alignment: .leading, spacing: 1) {
                                Text(item.title).lineLimit(2)
                                Text([item.course ?? "", dueWord(item.due)].filter { !$0.isEmpty }.joined(separator: " · "))
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer(minLength: 0)
                        }
                    }
                    if d.openCount > min(5, d.open.count) {
                        Text("+ \(d.openCount - min(5, d.open.count)) more").font(.caption).foregroundStyle(.secondary)
                    }
                }
                .padding(14)
                .frame(maxWidth: 420, alignment: .leading)
                .background(RoundedRectangle(cornerRadius: 14).fill(Color.primary.opacity(0.07)))
            } else if d.openCount > 0 {
                Text("\(plural(d.openCount, "thing", "things")) due today or tomorrow — open SillyBus to see the list.")
                    .font(.callout).foregroundStyle(.secondary)
            }

            VStack(spacing: 10) {
                // Drawn blue always: the system's prominent style turns grey
                // whenever the card is not the key window, and it looked off.
                Button(action: ok) {
                    Text("OK").font(.headline).foregroundStyle(.white)
                        .frame(width: 240, height: 36)
                        .background(Capsule().fill(Color(red: 0.04, green: 0.52, blue: 1.0)))
                        .contentShape(Capsule())
                }
                .buttonStyle(.plain)
                .keyboardShortcut(.defaultAction)
                Text("SillyBus closed \(appName) for now.")
                    .font(.caption).foregroundStyle(.secondary)
                Button(action: more) {
                    Text("Get More Time").font(.body.weight(.semibold)).foregroundStyle(Color.accentColor)
                }
                .buttonStyle(.plain)
                .padding(.top, 4)
                Text("A short hold gives you a few more minutes, without a chat.")
                    .font(.caption).foregroundStyle(.secondary)
                // Escape does what OK does.
                Button("", action: ok).keyboardShortcut(.cancelAction).opacity(0).frame(width: 0, height: 0)
            }
            .padding(.top, 8)
        }
        .padding(.horizontal, 32).padding(.top, 34).padding(.bottom, 24)
    }
}

func dueWord(_ due: String?) -> String {
    guard let due else { return "" }
    if due == todayString() { return "today" }
    if due == todayString(Date().addingTimeInterval(86400)) { return "tomorrow" }
    return due
}

/// [MEASURED] 2026-10-06, his screen recording: Minecraft runs full screen in
/// its own Space. Hiding a full-screen app leaves its Space behind — he swiped
/// straight back into the game — and a full-screen shield then landed on the
/// Space macOS fell back to, covering Chrome, his work. So a blocked app that
/// comes to the front is QUIT (a normal Quit, the same as ⌘Q: games save), and
/// the Time Limit is a card in the middle of the screen that one click on OK
/// closes. Nothing is covered but the card's own rectangle.
@MainActor
final class Shield {
    private var panel: CardPanel?
    private(set) var target: ShieldTarget?
    private var quitting: Set<pid_t> = []
    // OK'd while the app is still quitting (Minecraft takes seconds to save):
    // the 1-second sweep still saw it in front and put the card straight back
    // (prosecution 2026-10-06 — the "glitchy" he reported).
    private var dismissed: Set<pid_t> = []
    var isShowing: Bool { panel?.isVisible ?? false }

    /// The blocked app came to the front: quit it, then say why.
    func limit(_ app: NSRunningApplication) {
        let pid = app.processIdentifier
        if Env.watchOnly {
            if !quitting.contains(pid) { NSLog("SillyBus Lock (watch-only) would quit \(LockModel.displayName(app))") }
            quitting.insert(pid)
            return
        }
        if !quitting.contains(pid) {
            quitting.insert(pid)
            // An app still starting up ignores Quit ([MEASURED] Chess took
            // 3–6 s), so ask again every half second. Anything that still will
            // not quit (or asks "save changes?") is put away after 4 s — never
            // force-killed, so nothing is lost.
            app.terminate()
            for i in 1...7 {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5 * Double(i)) {
                    if !app.isTerminated { app.terminate() }
                }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 4) { [weak self] in
                MainActor.assumeIsolated {
                    if !app.isTerminated { app.hide() }
                    self?.quitting.remove(pid)
                    self?.dismissed.remove(pid)
                }
            }
        }
        if dismissed.contains(pid) { return }
        show(.app(app))
    }

    func show(_ target: ShieldTarget) {
        if isShowing && self.target?.key == target.key { return }
        self.target = target
        let view = ShieldView(appName: target.name, icon: target.icon,
                              ok: { [weak self] in self?.close() },
                              more: { [weak self] in openTalk(app: target.name); self?.close() })
        let host = FirstClickHostingView(rootView: view.frame(width: 460))
        let p = panel ?? CardPanel(contentRect: NSRect(x: 0, y: 0, width: 460, height: 400),
                                   styleMask: [.titled, .fullSizeContentView, .nonactivatingPanel],
                                   backing: .buffered, defer: false)
        p.titleVisibility = .hidden
        p.titlebarAppearsTransparent = true
        p.isMovableByWindowBackground = true
        p.standardWindowButton(.closeButton)?.isHidden = true
        p.standardWindowButton(.miniaturizeButton)?.isHidden = true
        p.standardWindowButton(.zoomButton)?.isHidden = true
        p.level = .floating
        p.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .ignoresCycle]
        p.hidesOnDeactivate = false
        p.isReleasedWhenClosed = false
        p.contentView = host
        p.setContentSize(host.fittingSize)
        p.center()
        panel = p
        p.orderFrontRegardless()
        p.makeKey()
    }

    func close() {
        if case .app(let a)? = target, quitting.contains(a.processIdentifier) { dismissed.insert(a.processIdentifier) }
        panel?.orderOut(nil)
        target = nil
    }
}

// MARK: - Settings

struct SettingsView: View {
    @ObservedObject var model = LockModel.shared
    @State var apps: [AppInfo] = []
    @State var query = ""
    @State var startAtLogin = LoginItem.isOn

    var shown: [AppInfo] {
        let q = query.trimmingCharacters(in: .whitespaces)
        return q.isEmpty ? apps : apps.filter { $0.name.localizedCaseInsensitiveContains(q) }
    }

    func row(_ app: AppInfo) -> some View {
        let on = model.isBlocked(id: app.id, defaultBlocked: app.defaultBlocked)
        // While locked, the list can only get stricter: a lock you can switch
        // off from inside the lock is not a lock.
        // Frozen during a break too: a break is not a finished day, and
        // switching blocks off during one kept them off for good
        // (prosecution 2026-10-06).
        let frozen = on && model.decision.locked || on && model.decision.breakLeft != nil
        return HStack(spacing: 8) {
            Image(nsImage: NSWorkspace.shared.icon(forFile: app.path)).resizable().frame(width: 20, height: 20)
            Text(app.name)
            if !app.why.isEmpty && app.defaultBlocked {
                Text(app.why).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            if frozen {
                // A greyed-out switch reads as "off"; this one is very much on.
                Image(systemName: "lock.fill").foregroundStyle(.secondary)
                    .help("You can unblock apps once today's work is done.")
            } else {
                Toggle("", isOn: Binding(get: { on }, set: { model.setBlocked(app, $0) }))
                    .labelsHidden().toggleStyle(.switch)
            }
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 6) {
                Text("Unlock").font(.headline)
                Picker("", selection: $model.mode) {
                    ForEach(Mode.allCases, id: \.self) { Text($0.label).tag($0) }
                }
                .pickerStyle(.radioGroup).labelsHidden()
            }
            VStack(alignment: .leading, spacing: 6) {
                Text("Blocked apps").font(.headline)
                Text("Games and social media are blocked to start with. Switch any app on or off.")
                    .font(.callout).foregroundStyle(.secondary)
                if model.decision.locked || model.decision.breakLeft != nil {
                    Text("Locked right now, so you can add apps but not remove them.")
                        .font(.caption).foregroundStyle(.orange)
                }
                TextField("Search apps", text: $query).textFieldStyle(.roundedBorder)
                List {
                    let blocked = shown.filter { model.isBlocked(id: $0.id, defaultBlocked: $0.defaultBlocked) }
                    let allowed = shown.filter { !model.isBlocked(id: $0.id, defaultBlocked: $0.defaultBlocked) }
                    Section("Blocked (\(blocked.count))") { ForEach(blocked) { row($0) } }
                    Section("Allowed (\(allowed.count))") { ForEach(allowed) { row($0) } }
                }
                .frame(minHeight: 200)
            }
            VStack(alignment: .leading, spacing: 6) {
                Text("Blocked websites (Google Chrome)").font(.headline)
                ScrollView {
                    VStack(alignment: .leading, spacing: 4) {
                        ForEach(Sites.all) { site in
                            let on = model.isSiteBlocked(site.id)
                            HStack {
                                Text(site.label)
                                Spacer()
                                if on && (model.decision.locked || model.decision.breakLeft != nil) {
                                    Image(systemName: "lock.fill").foregroundStyle(.secondary)
                                        .help("You can unblock sites once today's work is done.")
                                } else {
                                    Toggle("", isOn: Binding(get: { on }, set: { v in
                                        if v { model.sitesOff.remove(site.id) } else { model.sitesOff.insert(site.id) }
                                    })).labelsHidden().toggleStyle(.switch).controlSize(.small)
                                }
                            }
                        }
                    }
                    .padding(.trailing, 8)
                }
                .frame(height: 120)
                if Chrome.allowedForUI == false {
                    Text("To block sites, allow SillyBus Lock to control Google Chrome in System Settings → Privacy & Security → Automation.")
                        .font(.caption).foregroundStyle(.orange)
                }
            }
            HStack {
                Toggle("Start when I log in", isOn: $startAtLogin)
                    .onChange(of: startAtLogin) { _, on in LoginItem.set(on) }
                Spacer()
                Button("Reset to defaults") {
                    // While locked this may only tighten: the apps he allowed
                    // go back to blocked, the extra blocks he added stay.
                    model.neverBlock = []
                    model.sitesOff = []
                    if !model.decision.locked && model.decision.breakLeft == nil { model.alwaysBlock = [] }
                }
            }
        }
        .padding(18)
        .frame(width: 460, height: 720)
        .onAppear { apps = Catalog.scan() }
    }
}

@MainActor
final class SettingsWindow {
    private var window: NSWindow?

    func show() {
        if window == nil {
            let w = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 460, height: 720),
                             styleMask: [.titled, .closable], backing: .buffered, defer: false)
            w.title = "SillyBus Lock Settings"
            w.isReleasedWhenClosed = false
            window = w
        }
        window!.contentView = NSHostingView(rootView: SettingsView())   // rescan every time it opens
        window!.center()
        NSApp.activate(ignoringOtherApps: true)
        window!.makeKeyAndOrderFront(nil)
    }
}

// MARK: - Start at login (a LaunchAgent, like SillyBus's own jobs)

enum LoginItem {
    static var plistURL: URL {
        FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Library/LaunchAgents/\(K.agentLabel).plist")
    }
    static var isOn: Bool { FileManager.default.fileExists(atPath: plistURL.path) }

    static func set(_ on: Bool) {
        if !on { try? FileManager.default.removeItem(at: plistURL); return }
        guard let exe = Bundle.main.executablePath else { return }
        // KeepAlive only on a crash: Quit from the menu stays quit until the
        // next login, but a force-quit comes straight back.
        let plist: [String: Any] = [
            "Label": K.agentLabel,
            "ProgramArguments": [exe],
            "RunAtLoad": true,
            "KeepAlive": ["SuccessfulExit": false],
            "ProcessType": "Interactive",
        ]
        try? FileManager.default.createDirectory(at: plistURL.deletingLastPathComponent(),
                                                 withIntermediateDirectories: true)
        (plist as NSDictionary).write(to: plistURL, atomically: true)
    }
}

// MARK: - The menu-bar app

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate, NSMenuDelegate {
    let model = LockModel.shared
    let server = LockServer()
    let card = Card()
    let shield = Shield()
    let settings = SettingsWindow()
    var item: NSStatusItem!
    var lastHidden: [pid_t: Date] = [:]
    var lastDay = todayString()

    func applicationDidFinishLaunching(_ note: Notification) {
        item = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        let menu = NSMenu()
        menu.delegate = self
        item.menu = menu

        do { try server.start() } catch { NSLog("SillyBus Lock: \(error)") }

        model.onChange = { [weak self] old, new in self?.changed(old, new) }
        model.onBreakEarned = { [weak self] in
            self?.card.show(.breakEarned, autoClose: 6)
        }

        let ws = NSWorkspace.shared.notificationCenter
        for name in [NSWorkspace.didActivateApplicationNotification, NSWorkspace.didLaunchApplicationNotification] {
            ws.addObserver(forName: name, object: nil, queue: .main) { [weak self] note in
                let app = note.userInfo?[NSWorkspace.applicationUserInfoKey] as? NSRunningApplication
                MainActor.assumeIsolated { if let app { self?.enforce(app) } }
            }
        }
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated {
                // A new day: ask SillyBus at once instead of up to a minute
                // later, so midnight does not run on yesterday's answer.
                let day = todayString()
                if let self, day != self.lastDay { self.lastDay = day; pullFromMacApp() }
                self?.model.refresh(); self?.sweep()
            }
        }
        Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { _ in
            MainActor.assumeIsolated { pullFromMacApp() }
        }
        pullFromMacApp()
        model.refresh()
        updateIcon()
        if !model.defaults.bool(forKey: "welcomed") {
            model.defaults.set(true, forKey: "welcomed")
            // [MEASURED] 2026-10-06: a panel ordered in the first instant after
            // launch reported itself visible and was never drawn.
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { [weak self] in
                MainActor.assumeIsolated { self?.card.show(.welcome) }
            }
        }
        ProcessInfo.processInfo.disableAutomaticTermination("SillyBus Lock watches apps")
    }

    func changed(_ old: Decision, _ new: Decision) {
        guard old != new else { return }
        updateIcon()
        if new.locked && !old.locked { sweep() }
        if !new.locked && shield.isShowing { shield.close() }   // unlocked: let him straight in
    }

    func hide(_ app: NSRunningApplication) {
        if Env.watchOnly {
            if lastHidden[app.processIdentifier] == nil {
                lastHidden[app.processIdentifier] = Date()
                NSLog("SillyBus Lock (watch-only) would hide \(LockModel.displayName(app))")
            }
            return
        }
        app.hide()
    }

    /// An app came to the front (or launched).
    func enforce(_ app: NSRunningApplication) {
        guard app.processIdentifier != getpid(), model.decision.locked else { return }
        if model.blocks(app) {
            shield.limit(app)
            return
        }
        if app.bundleIdentifier == Chrome.bundleID { checkChrome(now: true) }
    }

    /// Turn any blocked site's tab into the Time Limit page.
    private var lastChromeCheck = Date.distantPast
    func checkChrome(now: Bool = false) {
        guard model.decision.locked, Chrome.isRunning else { return }
        if !now && Date().timeIntervalSince(lastChromeCheck) < 2 { return }
        lastChromeCheck = Date()
        Chrome.limitBlockedTabs(blocked: Set(Sites.all.map(\.id).filter { model.isSiteBlocked($0) }))
    }

    /// Every second: the blocked app in front gets the Time Limit screen, a
    /// blocked app showing behind (Discord bringing itself up on a message) is
    /// put away quietly, and Chrome's front tab is checked.
    func sweep() {
        guard model.decision.locked else { return }
        for app in NSWorkspace.shared.runningApplications where model.blocks(app) {
            if app.isActive { shield.limit(app) }
            else if !app.isHidden { hide(app) }
        }
        checkChrome()
    }

    func updateIcon() {
        guard let button = item?.button else { return }
        let d = model.decision
        let symbol = d.downtimeUntil != nil ? "moon.fill"
            : d.locked ? "hourglass" : (d.breakLeft != nil ? "timer" : "checkmark.circle")
        let img = NSImage(systemSymbolName: symbol, accessibilityDescription: d.locked ? "Locked" : "Unlocked")
        img?.isTemplate = true
        button.image = img
        button.imagePosition = .imageLeading
        if let left = d.breakLeft {
            button.title = " \(Int((left / 60).rounded(.up)))m"
        } else {
            button.title = ""
        }
        button.toolTip = "SillyBus Lock — \(d.headline)"
    }

    func menuNeedsUpdate(_ menu: NSMenu) {
        menu.removeAllItems()
        let d = model.decision
        let head = NSMenuItem(title: (d.locked ? "Locked — " : "Unlocked — ") + d.headline, action: nil, keyEquivalent: "")
        head.isEnabled = false
        menu.addItem(head)
        for item in d.open.prefix(5) {
            let i = NSMenuItem(title: "   ○ " + item.title, action: nil, keyEquivalent: "")
            i.isEnabled = false
            menu.addItem(i)
        }
        let heard: String
        if let at = model.lastHeard {
            let mins = Int(Date().timeIntervalSince(at) / 60)
            heard = mins < 1 ? "Heard from SillyBus just now" : "Heard from SillyBus \(mins) min ago"
        } else {
            heard = "Not heard from SillyBus yet — open it once"
        }
        let h = NSMenuItem(title: heard, action: nil, keyEquivalent: "")
        h.isEnabled = false
        menu.addItem(h)
        if Chrome.allowedForUI == false {
            let c = NSMenuItem(title: "Let it see Chrome's tabs, to block YouTube…", action: #selector(openAutomation), keyEquivalent: "")
            c.target = self
            menu.addItem(c)
        }
        menu.addItem(.separator())
        menu.addItem(withTitle: "Open SillyBus", action: #selector(openSB), keyEquivalent: "o").target = self
        let unlock = NSMenuItem(title: "Unlock", action: nil, keyEquivalent: "")
        let sub = NSMenu()
        for m in Mode.allCases {
            let i = NSMenuItem(title: m.label, action: #selector(pickMode(_:)), keyEquivalent: "")
            i.representedObject = m.rawValue
            i.state = model.mode == m ? .on : .off
            i.target = self
            sub.addItem(i)
        }
        unlock.submenu = sub
        menu.addItem(unlock)
        menu.addItem(withTitle: "Choose apps to block…", action: #selector(openSettings), keyEquivalent: ",").target = self
        menu.addItem(.separator())
        menu.addItem(withTitle: "Quit SillyBus Lock", action: #selector(quit), keyEquivalent: "q").target = self
    }

    @objc func openSB() { openSillyBus() }
    @objc func openAutomation() {
        // His switch to flip (Privacy & Security → Automation → SillyBus Lock → Google Chrome).
        NSWorkspace.shared.open(URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_Automation")!)
    }
    @objc func openSettings() { settings.show() }
    @objc func pickMode(_ sender: NSMenuItem) {
        if let raw = sender.representedObject as? String, let m = Mode(rawValue: raw) { model.mode = m }
    }
    @objc func quit() {
        if model.decision.locked {
            NSApp.activate(ignoringOtherApps: true)
            let a = NSAlert()
            a.messageText = "Quit SillyBus Lock?"
            a.informativeText = "Games and social apps will open up until you start it again."
            a.addButton(withTitle: "Keep it on")
            a.addButton(withTitle: "Quit")
            if a.runModal() != .alertSecondButtonReturn { return }
        }
        NSApp.terminate(nil)
    }
}

// MARK: - Self-test

@MainActor
func selfTest() -> Int32 {
    var failed = 0
    func check(_ ok: Bool, _ what: String) {
        print((ok ? "PASS " : "FAIL ") + what)
        if !ok { failed += 1 }
    }
    let now = Date()
    let today = todayString(now)
    func st(_ done: Bool, _ n: Int, date: String? = nil, keys: [String] = [], known: Bool = true) -> LockStatus {
        LockStatus(known: known, done: done, for_date: date ?? today, open_count: n,
                   open: (0..<min(n, 3)).map { OpenItem(title: "Item \($0)", course: "Bio", due: today) },
                   overdue_count: 0, done_keys: keys)
    }
    func h(_ s: LockStatus, changed: TimeInterval = 0, received: TimeInterval = 0) -> Heard {
        Heard(status: s, receivedAt: now.addingTimeInterval(received), changedAt: now.addingTimeInterval(changed))
    }

    check(decide(heard: [:], now: now, mode: .allDone, grantUntil: nil).locked,
          "nothing heard yet is locked")
    check(decide(heard: ["a": h(st(true, 0, date: "2000-01-01"))], now: now, mode: .allDone, grantUntil: nil).locked,
          "a done from another day does not unlock today")
    check(decide(heard: ["a": h(st(true, 0, known: false))], now: now, mode: .allDone, grantUntil: nil).locked,
          "an unknown board is locked")
    check(!decide(heard: ["a": h(st(true, 0))], now: now, mode: .allDone, grantUntil: nil).locked,
          "today's work done unlocks")
    check(decide(heard: ["a": h(st(false, 2))], now: now, mode: .allDone, grantUntil: nil).locked,
          "work left is locked")
    check(decide(heard: ["a": h(st(false, 2))], now: now, mode: .allDone,
                 grantUntil: now.addingTimeInterval(600)).locked,
          "a break does not count in all-done mode")
    let br = decide(heard: ["a": h(st(false, 2))], now: now, mode: .perAssignment,
                    grantUntil: now.addingTimeInterval(600))
    check(!br.locked && br.breakLeft != nil, "a break unlocks in 30-minute mode")
    check(decide(heard: ["a": h(st(false, 2))], now: now, mode: .perAssignment,
                 grantUntil: now.addingTimeInterval(-1)).locked,
          "an expired break locks again")
    check(!decide(heard: ["old": h(st(false, 2), changed: -300), "new": h(st(true, 0), changed: -10)],
                  now: now, mode: .allDone, grantUntil: nil).locked,
          "the source that changed last wins (ticked done in Chrome)")
    check(decide(heard: ["old": h(st(true, 0), changed: -300), "new": h(st(false, 1), changed: -10)],
                 now: now, mode: .allDone, grantUntil: nil).locked,
          "…and a new assignment arriving locks again")

    check(originAllowed("chrome-extension://aocpogmcjokpjfjfhfoeebngbacfoodn"), "the folder extension may send")
    check(originAllowed("chrome-extension://nkglcihnfamdlmkiihoncmikndpmidpa"), "the store extension may send")
    check(originAllowed("http://127.0.0.1:5055"), "the Mac app may send")
    check(!originAllowed("http://127.0.0.1:5079"), "a dev copy on another port may not")
    check(!originAllowed("http://127.0.0.1:5066"), "the lock's own pages may not set its status")
    check(HTTPRequest.parse(Data("POST /status HTTP/1.1\r\nHost: 127.0.0.1:5066\r\nContent-Length: -1\r\n\r\nx".utf8))?.method == "BAD",
          "a negative Content-Length is refused, not a crash")
    check(Sites.match("https://www.youtube.com./watch?v=1")?.id == "youtube", "a trailing dot is still YouTube")
    check(Sites.match("https://www.youtube-nocookie.com/embed/x")?.id == "youtube", "the no-cookie player is YouTube")
    // In winter Phoenix (MST) is an hour AHEAD of Pacific (PST): at 07:30Z
    // it is 23:30 on Nov 10 in Pacific and already 00:30 on Nov 11 in Phoenix.
    let zoneTest = ISO8601DateFormatter().date(from: "2026-11-11T07:30:00Z")!   // 23:30 PST Nov 10 / 00:30 MST Nov 11
    var zoned = st(true, 0, date: "2026-11-11"); zoned.tz = "America/Phoenix"
    check(!decide(heard: ["mac-app": Heard(status: zoned, receivedAt: zoneTest, changedAt: zoneTest)],
                  now: zoneTest, mode: .allDone, grantUntil: nil).locked,
          "the day is counted in SillyBus's time zone, not the Mac's")
    let midnight = Date()
    var yesterday = st(true, 0, date: todayString(midnight.addingTimeInterval(-86400)))
    yesterday.tz = nil
    check(!decide(heard: ["mac-app": Heard(status: yesterday, receivedAt: midnight.addingTimeInterval(-60), changedAt: midnight)],
                  now: midnight, mode: .allDone, grantUntil: nil).locked,
          "just after midnight, a minute-old answer still counts until the next pull")
    check(!decide(heard: [:], now: midnight, mode: .perAssignment, grantUntil: midnight.addingTimeInterval(600)).locked,
          "a break runs to its end even with no answer for the new day")
    check(!originAllowed("https://evil.example"), "a website may not")
    check(!originAllowed("http://127.0.0.1.evil.example"), "a lookalike host may not")
    check(!originAllowed(nil), "no Origin may not")
    check(!originAllowed("null"), "a sandboxed frame may not")
    check(!originAllowed("chrome-extension://../../x"), "a malformed extension id may not")
    check(hostAllowed("127.0.0.1:5066") && !hostAllowed("evil.example:5066"), "Host is checked (DNS rebinding)")

    check(Sites.match("https://www.youtube.com/shorts/abc")?.id == "youtube", "YouTube Shorts is YouTube")
    check(Sites.match("https://m.youtube.com/watch?v=1")?.id == "youtube", "mobile YouTube is YouTube")
    check(Sites.match("https://notyoutube.com/")?.id == nil, "a lookalike site is not")
    check(Sites.match("https://www.google.com/search?q=youtube.com")?.id == nil, "a search for YouTube is not YouTube")
    check(Sites.match("https://docs.google.com/document/d/x")?.id == nil, "school docs are never blocked")
    check(Sites.match("https://www.roblox.com/games/1")?.id == "games", "Roblox in the browser is a game site")
    check(Sites.match("chrome://settings")?.id == nil, "Chrome's own pages are not sites")

    let raw = "POST /status HTTP/1.1\r\nHost: 127.0.0.1:5066\r\nOrigin: http://127.0.0.1:5055\r\nContent-Length: 5\r\n\r\nhel"
    check(HTTPRequest.parse(Data(raw.utf8)) == nil, "a half-arrived body waits")
    check(HTTPRequest.parse(Data((raw + "lo").utf8))?.body == Data("hello".utf8), "a whole body parses")

    // The Time Limit page a YouTube tab becomes.
    let page = handle(HTTPRequest(method: "GET", path: "/limit", headers: ["host": "127.0.0.1:5066"],
                                  query: ["site": "youtube"], body: Data()), model: LockModel.shared)
    let html = String(data: page.body, encoding: .utf8) ?? ""
    check(page.status == 200 && html.contains("limit on YouTube"), "a blocked tab gets the Time Limit page")
    check(esc("<script>") == "&lt;script&gt;", "titles on the page are escaped")
    func press(_ path: String, origin: String) -> Int {
        handle(HTTPRequest(method: "POST", path: path, headers: ["host": "127.0.0.1:5066", "origin": origin],
                           body: Data()), model: LockModel.shared).status
    }
    check(press("/limit/close", origin: "https://evil.example") == 403, "a website cannot press OK")
    check(press("/limit/close", origin: "http://127.0.0.1:5055") == 403, "only the Time Limit page presses its own OK")
    check(press("/limit/close", origin: "http://127.0.0.1:5066") == 204, "the page's OK closes it")

    // "Get More Time" minutes: only the Mac app's /talk page, a few a day.
    LockModel.shared.extraUntil = nil
    LockModel.shared.extraDay = ""
    LockModel.shared.extraCount = 0
    func askMore(_ origin: String) -> Int {
        handle(HTTPRequest(method: "POST", path: "/more-time", headers: ["host": "127.0.0.1:5066", "origin": origin],
                           body: Data(#"{"minutes":60}"#.utf8)), model: LockModel.shared).status
    }
    check(askMore("https://evil.example") == 403, "a website cannot grant itself minutes")
    check(askMore("chrome-extension://aocpogmcjokpjfjfhfoeebngbacfoodn") == 403, "only the talk page grants minutes")
    check(askMore("http://127.0.0.1:5055") == 200, "the talk page can grant minutes")
    let granted = (LockModel.shared.extraUntil ?? Date()).timeIntervalSinceNow
    check(granted <= Double(K.extraMaxMinutes * 60) + 1, "60 minutes asked is capped at \(K.extraMaxMinutes)")
    _ = askMore("http://127.0.0.1:5055"); _ = askMore("http://127.0.0.1:5055")
    check(askMore("http://127.0.0.1:5055") == 429, "no more than \(K.extraPerDay) a day")
    LockModel.shared.extraUntil = nil
    LockModel.shared.extraCount = 0

    // The server, end to end, minus the socket.
    let model = LockModel.shared
    model.heard = [:]
    model.mode = .perAssignment
    model.grantUntil = nil
    model.seenKeys = []
    model.knownSources = []
    func post(_ s: LockStatus, origin: String = "http://127.0.0.1:5055", host: String = "127.0.0.1:5066") -> Int {
        let body = try! JSONEncoder().encode(s)
        return handle(HTTPRequest(method: "POST", path: "/status",
                                  headers: ["origin": origin, "host": host], body: body), model: model).status
    }
    check(post(st(true, 0), origin: "https://evil.example") == 403, "a website's POST is refused")
    check(model.heard.isEmpty, "…and changes nothing")
    check(post(st(true, 0), host: "evil.example:5066") == 403, "a rebinding POST is refused")
    var v1 = st(false, 2, keys: ["old1", "old2"]); v1.key_version = 1
    _ = post(v1)
    var v2 = st(false, 2, keys: ["new1", "new2"]); v2.key_version = 2
    _ = post(v2)
    check(model.grantUntil == nil, "a new key format re-baselines instead of granting a break")
    model.knownSources = []; model.keyVersions = [:]; model.seenKeys = []; model.heard = [:]
    _ = post(st(false, 0, keys: [], known: false))
    check(model.grantUntil == nil && !model.knownSources.contains("mac-app"), "a not-loaded-yet message is no baseline")
    check(post(st(false, 2, keys: ["a", "b"])) == 200 && model.decision.locked, "first contact: locked, no break")
    check(model.grantUntil == nil, "first contact is the baseline, not a reward")
    _ = post(st(false, 1, keys: ["a", "b", "c"]))
    check(!model.decision.locked && model.grantUntil != nil, "one more ticked Done: 30 minutes")
    model.grantUntil = now.addingTimeInterval(-1)
    model.refresh()
    _ = post(st(false, 2, keys: ["a", "b"]))
    _ = post(st(false, 1, keys: ["a", "b", "c"]))
    check(model.decision.locked, "untick and re-tick the same one: no second break")
    _ = post(st(true, 0, keys: ["a", "b", "c", "d"]))
    check(!model.decision.locked, "all done: unlocked")

    // Downtime ([ASKED] 2026-10-07). Phoenix keeps no daylight saving, so
    // these clock times are the same all year. 2026-10-09 is a Friday.
    let phx = "America/Phoenix"
    func at(_ iso: String) -> Date { ISO8601DateFormatter().date(from: iso)! }
    func dt(_ start: String, _ end: String, days: [String]? = nil, on: Bool = true) -> DowntimeInfo {
        DowntimeInfo(on: on, active: nil, until: nil, label: nil, start: start, end: end,
                     days: days ?? WEEKDAYS, tz: phx, set_at: 1)
    }
    func doneDay(_ when: Date) -> [String: Heard] {
        var s = st(true, 0, date: todayString(when, zone: phx)); s.tz = phx
        return ["mac-app": Heard(status: s, receivedAt: when, changedAt: when)]
    }
    func shutAt(_ iso: String, _ d: DowntimeInfo, mode: Mode = .allDone, grant: Date? = nil) -> Decision {
        let when = at(iso)
        return decide(heard: doneDay(when), now: when, mode: mode, grantUntil: grant, downtime: d)
    }
    let night = dt("22:00", "07:00")
    let fri2330 = shutAt("2026-10-09T23:30:00-07:00", night)
    check(fri2330.locked && fri2330.downtimeUntil == "07:00", "Downtime locks a finished day")
    check(fri2330.headline == "Downtime until 7:00 AM", "…and says until when")
    check(!shutAt("2026-10-09T21:59:00-07:00", night).locked, "a finished day is open before Downtime starts")
    check(shutAt("2026-10-10T06:59:00-07:00", night).locked, "Downtime crosses midnight (still on at 6:59 AM)")
    check(!shutAt("2026-10-10T07:00:00-07:00", night).locked, "Downtime ends at its end time")
    check(!shutAt("2026-10-09T23:30:00-07:00", dt("22:00", "07:00", on: false)).locked, "Downtime switched off does nothing")
    let fridays = dt("22:00", "07:00", days: ["fri"])
    check(shutAt("2026-10-09T23:00:00-07:00", fridays).locked, "days: Friday night is Downtime")
    check(shutAt("2026-10-10T02:00:00-07:00", fridays).locked, "days: Saturday 2 AM belongs to Friday's window")
    check(!shutAt("2026-10-10T23:00:00-07:00", fridays).locked, "days: Saturday night is not")
    check(!shutAt("2026-10-09T02:00:00-07:00", fridays).locked, "days: Friday 2 AM belongs to Thursday, so not")
    check(shutAt("2026-10-09T14:00:00-07:00", dt("13:00", "15:00", days: ["fri"])).locked
          && !shutAt("2026-10-08T14:00:00-07:00", dt("13:00", "15:00", days: ["fri"])).locked,
          "a same-day window only on its own days")
    check(shutAt("2026-10-09T23:30:00-07:00", night, mode: .perAssignment,
                 grant: at("2026-10-09T23:50:00-07:00")).locked,
          "a 30-minute break does not open Downtime")
    check(minutesOf("24:00") == nil && minutesOf("7") == nil && downtimeEnd(dt("25:00", "07:00"), now: Date()) == nil,
          "a schedule that cannot be read is not Downtime")
    check(clockWords("00:05") == "12:05 AM" && clockWords("12:00") == "12:00 PM" && clockWords("22:30") == "10:30 PM",
          "times read like a clock")

    // The model: the newest CHANGE of schedule wins, and extra minutes open it.
    let late = at("2026-10-09T23:30:00-07:00")
    model.downtime = nil
    model.heard = doneDay(late)
    var newer = night; newer.set_at = 200
    var older = dt("22:00", "07:00", on: false); older.set_at = 100
    model.takeDowntime(newer, at: late)
    model.takeDowntime(older, at: late)
    check(model.downtime?.on == true, "an older schedule from another source does not undo a newer one")
    model.takeDowntime(nil, at: late)
    check(model.downtime?.on == true, "a message without Downtime keeps the last schedule")
    model.extraUntil = nil
    model.refresh(late)
    check(model.decision.locked && model.decision.downtimeUntil != nil, "the model keeps Downtime on a finished day")
    model.extraUntil = late.addingTimeInterval(5 * 60)
    model.refresh(late)
    check(!model.decision.locked, "Get More Time minutes still open Downtime")
    model.extraUntil = nil
    model.refresh(late)
    let dtPage = String(data: handle(HTTPRequest(method: "GET", path: "/limit", headers: ["host": "127.0.0.1:5066"],
                                                 query: ["site": "youtube"], body: Data()), model: model).body,
                        encoding: .utf8) ?? ""
    check(dtPage.contains("<h1>Downtime</h1>") && dtPage.contains("YouTube is closed until 7:00 AM"),
          "the Time Limit page says Downtime")
    check(NSImage(systemSymbolName: "moon.fill", accessibilityDescription: nil) != nil, "the Downtime icon exists")
    model.downtime = nil
    model.heard = [:]
    model.refresh()
    return failed == 0 ? 0 : 1
}

// MARK: - Pictures of the card, for checking it without putting it on a screen

@MainActor
func renderCards(to dir: String) {
    let model = LockModel.shared
    let today = todayString()
    let tomorrow = todayString(Date().addingTimeInterval(86400))
    let open = [OpenItem(title: "1B-6 and 1B-7, 1B Write", course: "Spanish 1", due: today),
                OpenItem(title: "Textbook notes 8.3", course: "Honors Biology", due: today),
                OpenItem(title: "Unit 3 Test Review", course: "Honors Algebra 1", due: tomorrow),
                OpenItem(title: "Whalefall Details Quiz 1 (pgs 1-41)", course: "Honors English 1", due: tomorrow)]
    model.heard = ["mac-app": Heard(status: LockStatus(known: true, done: false, for_date: today, open_count: 6,
                                                     open: open, overdue_count: 2, done_keys: []),
                                    receivedAt: Date(), changedAt: Date())]
    model.refresh()
    try? limitPage(site: Sites.all.first, decision: model.decision)
        .write(toFile: "\(dir)/limit.html", atomically: true, encoding: .utf8)
    for dark in [false, true] {
        let mc = NSWorkspace.shared.icon(forFile: "/Applications/Minecraft.app")
        let view = ShieldView(appName: "Minecraft", icon: mc, ok: {})
            .frame(width: 460)
            .background(Color(nsColor: .windowBackgroundColor).opacity(0.92))
            .environment(\.colorScheme, dark ? .dark : .light)
        let r = ImageRenderer(content: view)
        r.scale = 1
        if let img = r.nsImage, let tiff = img.tiffRepresentation,
           let png = NSBitmapImageRep(data: tiff)?.representation(using: .png, properties: [:]) {
            try? png.write(to: URL(fileURLWithPath: "\(dir)/shield\(dark ? "-dark" : "").png"))
        }
    }
    for (name, kind) in [("welcome", CardKind.welcome), ("break", .breakEarned)] {
        for dark in [false, true] {
            let view = LockCard(kind: kind) {}
                .background(Color(nsColor: .windowBackgroundColor))
                .environment(\.colorScheme, dark ? .dark : .light)
            let r = ImageRenderer(content: view)
            r.scale = 2
            if let img = r.nsImage, let tiff = img.tiffRepresentation,
               let png = NSBitmapImageRep(data: tiff)?.representation(using: .png, properties: [:]) {
                try? png.write(to: URL(fileURLWithPath: "\(dir)/card-\(name)\(dark ? "-dark" : "").png"))
            }
        }
    }
}

@MainActor
func renderSettings(to file: String, dark: Bool) {
    let w = NSWindow(contentRect: NSRect(x: -3000, y: -3000, width: 460, height: 600),
                     styleMask: [.titled], backing: .buffered, defer: false)
    w.appearance = NSAppearance(named: dark ? .darkAqua : .aqua)
    let host = NSHostingView(rootView: SettingsView())
    w.contentView = host
    w.orderBack(nil)
    RunLoop.main.run(until: Date().addingTimeInterval(1.5))
    guard let rep = host.bitmapImageRepForCachingDisplay(in: host.bounds) else { return }
    host.cacheDisplay(in: host.bounds, to: rep)
    try? rep.representation(using: .png, properties: [:])?.write(to: URL(fileURLWithPath: file))
    w.close()
}

// MARK: - main

if CommandLine.arguments.contains("--list-apps") {
    for a in Catalog.scan() where a.defaultBlocked { print("BLOCK  \(a.name)  (\(a.why), \(a.id))") }
    exit(0)
}

if let i = CommandLine.arguments.firstIndex(of: "--render-cards"), i + 1 < CommandLine.arguments.count {
    let dir = CommandLine.arguments[i + 1]
    MainActor.assumeIsolated {
        renderCards(to: dir)
        _ = NSApplication.shared
        NSApp.setActivationPolicy(.prohibited)
        renderSettings(to: "\(dir)/settings.png", dark: false)
        renderSettings(to: "\(dir)/settings-dark.png", dark: true)
    }
    exit(0)
}

if Env.selfTest {
    UserDefaults.standard.removePersistentDomain(forName: "com.sillybus.lock.selftest")
    let code = MainActor.assumeIsolated { selfTest() }
    exit(code)
}

let me = Bundle.main.bundleIdentifier ?? K.agentLabel
if NSRunningApplication.runningApplications(withBundleIdentifier: me).count > 1 {
    exit(0)   // already running; exit 0 so launchd does not restart us
}

let app = NSApplication.shared
app.setActivationPolicy(.accessory)
let delegate = MainActor.assumeIsolated { AppDelegate() }
app.delegate = delegate
app.run()
