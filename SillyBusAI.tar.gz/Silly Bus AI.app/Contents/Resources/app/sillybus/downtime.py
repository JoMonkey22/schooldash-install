"""Downtime: set hours when SillyBus Lock keeps games and social media shut.

[ASKED] 2026-10-07: "in settings add a thing where you set a down time or
tell the chat to do it". Screen Time's Downtime, applied to SillyBus Lock:
during these hours the apps and sites the lock blocks stay blocked even when
every bit of homework is done. The lock's "Get More Time" minutes still open
it (three a day, after the coach) — that is the escape hatch, on purpose.

Stored in config.json as

    "lock": {"downtime": {"on": bool, "start": "HH:MM", "end": "HH:MM",
                          "days": ["mon", ..., "sun"], "set_at": epoch}}

in the SCHOOL's time zone (`timezones.zone()`), not the Mac's: everything
else about "today" is counted there, and the lock already counts days in
that zone.

Rules, each with a test in tests/test_downtime.py:
  * A window that crosses midnight belongs to the day it STARTS. Friday's
    22:00–07:00 runs into Saturday morning even when Saturday is not ticked;
    Sunday's does not start at all if Sunday is not ticked.
  * Start and end may not be the same time: "from 9 to 9" is either nothing
    or all day, and guessing which is how a lock never opens.
  * `set_at` records when it was last changed. The Mac app and the Chrome
    extension each keep their own config, and both talk to the lock; the lock
    follows the schedule that was changed most recently, wherever that was —
    the same "most recent change wins" rule it uses for homework.

This is the one module that knows what Downtime means. Settings, the chat
(another agent calls `set`), /api/downtime and the lock message (lock.py)
all come through here.
"""

from __future__ import annotations

import re
import time
from datetime import datetime, timedelta

DAYS = ("mon", "tue", "wed", "thu", "fri", "sat", "sun")
_DAY_NAMES = {"monday": "mon", "tuesday": "tue", "wednesday": "wed", "thursday": "thu",
              "friday": "fri", "saturday": "sat", "sunday": "sun",
              "tues": "tue", "weds": "wed", "thur": "thu", "thurs": "thu"}
_DAY_GROUPS = {"weekdays": DAYS[:5], "weekends": DAYS[5:], "weekend": DAYS[5:],
               "every day": DAYS, "everyday": DAYS, "daily": DAYS, "all": DAYS}
_FULL = {"mon": "Monday", "tue": "Tuesday", "wed": "Wednesday", "thu": "Thursday",
         "fri": "Friday", "sat": "Saturday", "sun": "Sunday"}

# "When first turned on": a school night's sleep. Kept here rather than in
# config.DEFAULTS so an install that never touches Downtime has no "lock"
# block written for it at all.
DEFAULT_START = "22:00"
DEFAULT_END = "07:00"

# 24-hour "7:00"/"07:00", or "10 pm"/"10:30pm" — the chat hands over what
# the student typed, and refusing "10 PM" would be refusing English. \Z, not
# $: `$` also matches before a trailing newline (CLAUDE.md).
_TIME_24 = re.compile(r"(\d{1,2}):(\d{2})\Z")
_TIME_12 = re.compile(r"(\d{1,2})(?::(\d{2}))?\s*([ap])\.?\s*m\.?\Z", re.I)


def _off() -> dict:
    return {"on": False, "start": DEFAULT_START, "end": DEFAULT_END,
            "days": list(DAYS), "set_at": None}


# ---------------------------------------------------------------- validation

def parse_time(value) -> str:
    """'7:00', '07:00', '7 am', '10:30 PM' -> 'HH:MM' (24-hour), or ValueError."""
    text = str(value if value is not None else "").strip()
    m = _TIME_24.match(text)
    if m:
        hour, minute = int(m.group(1)), int(m.group(2))
    else:
        m = _TIME_12.match(text)
        if not m:
            raise ValueError(f"{text or 'That'!r} isn't a time I can read. Use one like 22:00 or 10:00 PM.")
        hour, minute = int(m.group(1)), int(m.group(2) or 0)
        if not 1 <= hour <= 12:
            raise ValueError(f"{text!r} isn't a time I can read. Use one like 22:00 or 10:00 PM.")
        hour = hour % 12 + (12 if m.group(3).lower() == "p" else 0)
    if hour > 23 or minute > 59:
        raise ValueError(f"{text!r} isn't a real time of day. Use one like 22:00 or 10:00 PM.")
    return f"{hour:02d}:{minute:02d}"


def parse_days(value) -> list[str]:
    """Day names -> ['mon', ...] in week order, or ValueError.

    Takes 'mon' or 'Monday', and 'weekdays' / 'weekends' / 'every day', as a
    list or as one string."""
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, (list, tuple)):
        raise ValueError("Days must be a list of day names, like mon, tue, wed.")
    # A dict, not a set(): this module's own `set` is the setter.
    picked: dict[str, bool] = {}
    for raw in value:
        name = str(raw).strip().lower()
        if name in _DAY_GROUPS:
            picked.update(dict.fromkeys(_DAY_GROUPS[name], True))
        elif name in DAYS:
            picked[name] = True
        elif name in _DAY_NAMES:
            picked[_DAY_NAMES[name]] = True
        else:
            raise ValueError(f"{str(raw)!r} isn't a day of the week. Use names like mon, tue or Saturday.")
    if not picked:
        raise ValueError("Pick at least one day for Downtime.")
    return [d for d in DAYS if d in picked]


def _clean(stored) -> dict:
    """Whatever is in config.json, made safe to compute with. A hand-edited
    value that does not parse falls back to the default rather than raising:
    the lock message is built from this every minute."""
    out = _off()
    if not isinstance(stored, dict):
        return out
    out["on"] = stored.get("on") is True
    for key, default in (("start", DEFAULT_START), ("end", DEFAULT_END)):
        try:
            out[key] = parse_time(stored.get(key, default))
        except ValueError:
            out[key] = default
    try:
        out["days"] = parse_days(stored.get("days", list(DAYS)))
    except ValueError:
        out["days"] = list(DAYS)
    if out["start"] == out["end"]:
        out["start"], out["end"] = DEFAULT_START, DEFAULT_END
    set_at = stored.get("set_at")
    out["set_at"] = set_at if isinstance(set_at, (int, float)) and not isinstance(set_at, bool) else None
    return out


# ---------------------------------------------------------------- the API

def get() -> dict:
    """{'on', 'start', 'end', 'days', 'set_at'} — the saved schedule."""
    from sillybus import config
    return _clean((config.load().get("lock") or {}).get("downtime"))


def set(on=None, start=None, end=None, days=None) -> dict:  # noqa: A001 — the name the chat calls
    """Change any part of Downtime; what is not given stays as it was.

    Raises ValueError with a sentence a student can read when a value is
    wrong, and writes nothing in that case. Returns the new `get()`.
    """
    from sillybus import config
    current = get()
    new = dict(current)
    if on is not None:
        if not isinstance(on, bool):
            raise ValueError("Downtime is either on or off (true or false).")
        new["on"] = on
    if start is not None:
        new["start"] = parse_time(start)
    if end is not None:
        new["end"] = parse_time(end)
    if days is not None:
        new["days"] = parse_days(days)
    if new["start"] == new["end"]:
        raise ValueError("Downtime has to start and end at different times.")
    if all(new[k] == current[k] for k in ("on", "start", "end", "days")):
        return current
    new["set_at"] = time.time()
    config.save({"lock": {"downtime": new}})
    return get()


def _minutes(hhmm: str) -> int:
    hour, minute = hhmm.split(":")
    return int(hour) * 60 + int(minute)


def _local(now, tz) -> datetime:
    if now is None:
        return datetime.now(tz)
    if now.tzinfo is None:
        return now.replace(tzinfo=tz)
    return now.astimezone(tz)


def _window(schedule: dict, local: datetime) -> bool:
    """Is `local` (already in the school's zone) inside a Downtime window?"""
    if not schedule.get("on"):
        return False
    start, end = _minutes(schedule["start"]), _minutes(schedule["end"])
    now_min = local.hour * 60 + local.minute
    today = DAYS[local.weekday()]
    if start < end:
        return today in schedule["days"] and start <= now_min < end
    # Crosses midnight: the evening part belongs to today, the early-morning
    # part to the day before — the day it started.
    yesterday = DAYS[(local - timedelta(days=1)).weekday()]
    return (now_min >= start and today in schedule["days"]) or \
           (now_min < end and yesterday in schedule["days"])


def active(now: datetime | None = None, schedule: dict | None = None) -> bool:
    """Is it Downtime right now (or at `now`), in the school's zone?"""
    from sillybus import timezones
    schedule = get() if schedule is None else _clean(schedule)
    return _window(schedule, _local(now, timezones.zone()))


def clock(hhmm: str) -> str:
    """'22:00' -> '10:00 PM' (the lock's headline uses the same shape)."""
    hour, minute = divmod(_minutes(hhmm), 60)
    return f"{hour % 12 or 12}:{minute:02d} {'AM' if hour < 12 else 'PM'}"


def _days_words(days: list[str]) -> str:
    if list(days) == list(DAYS):
        return "every day"
    if list(days) == list(DAYS[:5]):
        return "on weekdays"
    if list(days) == list(DAYS[5:]):
        return "on weekends"
    names = [_FULL[d] for d in days]
    if len(names) == 1:
        return f"on {names[0]}s"
    return "on " + ", ".join(n[:3] for n in names[:-1]) + " and " + names[-1][:3]


def describe(schedule: dict | None = None) -> str:
    """'Downtime: 10:00 PM – 7:00 AM every day', or 'Downtime is off'."""
    schedule = get() if schedule is None else _clean(schedule)
    if not schedule["on"]:
        return "Downtime is off"
    return (f"Downtime: {clock(schedule['start'])} – {clock(schedule['end'])} "
            f"{_days_words(schedule['days'])}")


def status(now: datetime | None = None) -> dict:
    """What the lock is sent (lock.py) and what /api/downtime answers.

    `active`/`until`/`label` are worked out here, in the school's zone; the
    schedule itself (`start`/`end`/`days`/`tz`) rides along so the lock can
    work it out for itself when it cannot hear SillyBus."""
    from sillybus import timezones
    schedule = get()
    zone = timezones.zone()
    on_now = _window(schedule, _local(now, zone))
    return {
        "on": schedule["on"],
        "active": on_now,
        "until": schedule["end"] if on_now else None,
        "label": f"Downtime until {clock(schedule['end'])}" if on_now else describe(schedule),
        "start": schedule["start"],
        "end": schedule["end"],
        "days": schedule["days"],
        "tz": getattr(zone, "key", None),
        "set_at": schedule["set_at"],
    }
