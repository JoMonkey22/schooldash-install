"""launchd wiring for the scheduled homework notification (macOS).

The Windows side (schedule_tasks.py) drives refresh+publish through
schtasks. This is the Mac equivalent and covers the piece that was asked for:
a banner a couple of times a day saying what is close or already late.

Design notes:
  - A LaunchAgent, not a LaunchDaemon: it must run as the logged-in user, in
    their GUI session, or a notification has no session to appear in.
  - `StartCalendarInterval` with a list of times, not `StartInterval`. Fixed
    clock times are what a person can reason about ("7am and 5pm"), and they
    survive sleep in the way a repeating countdown does not.
  - launchd runs missed jobs once at wake rather than backfilling each slot,
    which is the same "skipped, not queued" behaviour the Windows side has.
  - The plist is rewritten wholesale on every install so a changed schedule
    never leaves an orphan slot behind.
"""

import os
import plistlib
import subprocess
import sys
from pathlib import Path

from sillybus import config, paths
from sillybus.logging_setup import get

log = get("schedule.mac")

LABEL = "com.sillybus.notify"
DEFAULT_TIMES = ["07:00", "17:00"]


def agents_dir() -> Path:
    return Path.home() / "Library" / "LaunchAgents"


def plist_path() -> Path:
    return agents_dir() / f"{LABEL}.plist"


def _to_mac_clock(hour: int, minute: int, on=None) -> dict:
    """A school-zone clock time as the Mac's own clock reads it today.

    launchd reads Hour/Minute in the Mac's zone, but every date in SillyBus is
    the school's (prosecution round 5, 2026-10-07: this Mac is Los Angeles,
    the school is Phoenix, so from Nov 1 the "7am" banner came at 8:00 school
    time until March). The keepalive agent rewrites the plists when the two
    zones' gap changes (`resync_if_shifted`).
    """
    from datetime import datetime, time as dtime
    from sillybus import timezones
    day = on or datetime.now(timezones.zone()).date()
    school = datetime.combine(day, dtime(hour, minute), tzinfo=timezones.zone())
    mac = school.astimezone()   # the Mac's local zone
    return {"Hour": mac.hour, "Minute": mac.minute}


def _school_times() -> list[tuple[int, int]]:
    configured = (config.load().get("notify") or {}).get("times")
    times = configured if isinstance(configured, list) and configured else DEFAULT_TIMES
    parsed = []
    for value in times:
        try:
            hour, minute = (int(part) for part in str(value).split(":"))
        except (ValueError, AttributeError):
            log.warning("ignoring unreadable notify time %r", value)
            continue
        # "25:00" went into the plist as Hour 25, which launchd loads and
        # never fires (round 5).
        if not (0 <= hour <= 23 and 0 <= minute <= 59):
            log.warning("ignoring impossible notify time %r", value)
            continue
        parsed.append((hour, minute))
    return parsed or [(7, 0), (17, 0)]


def _times() -> list[dict]:
    return [_to_mac_clock(h, m) for h, m in _school_times()]


def _plist() -> dict:
    root = paths.project_root()
    python = Path(sys.executable)
    # sys.executable is whatever invoked this; prefer the project's own venv so
    # the agent keeps working if the installer's shell PATH is not in scope.
    for candidate in (paths.data_root() / "venv" / "bin" / "python",
                      root / ".venv" / "bin" / "python"):
        if candidate.exists():
            python = candidate
            break
    # launchd starts an agent with almost no environment — none of the shell's,
    # and none of the launcher's. Everything the agent needs has to be written
    # into the plist itself.
    #
    # [MEASURED] 2026-08-26: without this block the twice-daily run inherited no
    # SILLYBUS_DATA_HOME, so data_root() fell back to project_root() — which
    # inside the packaged app is the app bundle. Every run at 07:00 and 17:00
    # wrote config.json, data/, cache/, logs/ and a whole browser_profile/
    # INSIDE Silly Bus AI.app, plus __pycache__ next to the source. That broke the
    # code signature ("a sealed resource is missing or invalid"), and it built a
    # second, empty config that the reminder read instead of the real one — so
    # the banner and the dashboard could disagree about the same day.
    environment = {"SILLYBUS_DATA_HOME": str(paths.data_root())}
    if os.environ.get("PYTHONPYCACHEPREFIX"):
        environment["PYTHONPYCACHEPREFIX"] = os.environ["PYTHONPYCACHEPREFIX"]
    else:
        environment["PYTHONPYCACHEPREFIX"] = str(paths.data_root() / "pycache")

    return {
        "Label": LABEL,
        "ProgramArguments": [str(python), str(root / "run.py"), "notify",
                             "--refresh"],
        "EnvironmentVariables": environment,
        # Not the app bundle: a working directory the agent might write into
        # has to be one it is allowed to write into.
        "WorkingDirectory": str(paths.data_root()),
        "StartCalendarInterval": _times(),
        "RunAtLoad": False,
        "ProcessType": "Interactive",
        "StandardOutPath": str(paths.log_file()),
        "StandardErrorPath": str(paths.log_file()),
    }


# ---------------------------------------------------------------------------
# Two more agents: one that refreshes on its own, one that stops the Veracross
# session lapsing.
#
# [MEASURED] 2026-09-01, cookie lifetimes in the app's browser profile:
#   canvas_session       695.0 h left   (~29 days, because "Stay signed in")
#   _gatekeeper_session    0.5 h left   (Veracross: THIRTY MINUTES)
#
# The Veracross window slides — visiting the portal pushed the expiry from 26.8
# minutes back to 29.6 — so touching it more often than every 30 minutes keeps
# it alive, which is what leaving a browser tab open does. Hence keepalive at 20
# minutes: comfortably inside the window, so one missed run (a closed lid, a
# dropped network) does not by itself end the session.
REFRESH_LABEL = "com.sillybus.refresh"
KEEPALIVE_LABEL = "com.sillybus.keepalive"

# The labels these agents carried before the 0.19.0.0 rename. install() and
# remove() boot them out and delete their plists, or a Mac that ran SchoolDash
# would keep two refresh schedules and two keep-alives.
OLD_LABELS = ("com.schooldash.notify", "com.schooldash.refresh",
              "com.schooldash.keepalive")

# Every half hour through the waking day. StartCalendarInterval rather than
# StartInterval for the same reason as the notifier: fixed clock times survive
# sleep, where a repeating countdown drifts, and launchd runs a missed slot once
# at wake instead of backfilling every slot it slept through.
REFRESH_FROM_HOUR = 6
REFRESH_TO_HOUR = 21


def _refresh_slots() -> list[dict]:
    # Not at the notifier's own times: it refreshes before it posts, so a
    # refresh agent at 07:00 and 17:00 too meant two full refreshes at once,
    # and the notifier's lost the lock and posted from old data (round 5).
    notify_at = set(_school_times())
    return [_to_mac_clock(hour, minute)
            for hour in range(REFRESH_FROM_HOUR, REFRESH_TO_HOUR + 1)
            for minute in (0, 30) if (hour, minute) not in notify_at]


def _agent(label: str, args: list[str], schedule: dict) -> dict:
    """One agent sharing the notifier's hard-won environment handling."""
    base = _plist()
    base["Label"] = label
    base["ProgramArguments"] = [base["ProgramArguments"][0],
                                base["ProgramArguments"][1], *args]
    base.pop("StartCalendarInterval", None)
    base.pop("StartInterval", None)
    base.update(schedule)
    # These run unattended and must never put a window in front of anyone.
    base["ProcessType"] = "Background"
    base["LowPriorityIO"] = True
    return base


def refresh_plist() -> dict:
    return _agent(REFRESH_LABEL, ["refresh"],
                  {"StartCalendarInterval": _refresh_slots()})


def keepalive_plist() -> dict:
    return _agent(KEEPALIVE_LABEL, ["keepalive"],
                  {"StartInterval": 20 * 60})


def _launchctl(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(["launchctl", *args], capture_output=True, text=True,
                          shell=False)


def _is_the_real_install() -> bool:
    """Only the installed app's own data home may write the real LaunchAgents.

    Round 5: pressing "Turn on reminders" in a preview copy (dev-serve-copy.sh,
    a temp data home) rewrote ~/Library/LaunchAgents to point at that copy,
    and the real board stopped refreshing on its own — the September outage
    from one click. SILLYBUS_ALLOW_SCHEDULE=1 overrides, deliberately.
    """
    if os.environ.get("SILLYBUS_ALLOW_SCHEDULE") == "1":
        return True
    real = Path.home() / "Library" / "Application Support" / "Silly Bus AI"
    try:
        return paths.data_root().resolve() == real.resolve()
    except OSError:
        return False


def install() -> int:
    if sys.platform != "darwin":
        print("this is the macOS scheduler — on Windows use: python run.py schedule --install")
        return 1
    if not _is_the_real_install():
        print(f"not scheduling from {paths.data_root()} — only the installed app "
              "schedules reminders (set SILLYBUS_ALLOW_SCHEDULE=1 to override)")
        return 1
    agents_dir().mkdir(parents=True, exist_ok=True)
    target = plist_path()
    target.write_bytes(plistlib.dumps(_plist()))

    uid = str(__import__("os").getuid())
    _remove_old_labels(uid)
    # bootout first so a changed schedule replaces the old one cleanly; it
    # fails harmlessly when nothing is loaded yet.
    _launchctl("bootout", f"gui/{uid}/{LABEL}")
    result = _launchctl("bootstrap", f"gui/{uid}", str(target))
    if result.returncode != 0:
        print(f"launchctl refused: {(result.stderr or '').strip()[:200]}")
        print(f"the plist is written at {target} — load it yourself with:")
        print(f"  launchctl bootstrap gui/{uid} {target}")
        return 1

    slots = ", ".join(f"{s['Hour']:02d}:{s['Minute']:02d}" for s in _times())
    print(f"notifications scheduled at {slots} ({target.name})")
    print("first time only: macOS will ask to allow notifications — say yes.")
    failed = False

    for label, builder, description in (
            (REFRESH_LABEL, refresh_plist,
             f"auto-refresh every 30 min, {REFRESH_FROM_HOUR:02d}:00-"
             f"{REFRESH_TO_HOUR:02d}:30"),
            (KEEPALIVE_LABEL, keepalive_plist,
             "Veracross keep-alive every 20 min (its session is 30)")):
        path = agents_dir() / f"{label}.plist"
        path.write_bytes(plistlib.dumps(builder()))
        _launchctl("bootout", f"gui/{uid}/{label}")
        outcome = _launchctl("bootstrap", f"gui/{uid}", str(path))
        if outcome.returncode == 0:
            print(f"{description} ({path.name})")
        else:
            # Not success: a board with no auto-refresh that says "scheduled"
            # is the September outage over again (round 5).
            failed = True
            print(f"could not load {label}: "
                  f"{(outcome.stderr or '').strip()[:120]}")
    print("remove with: python run.py notify --unschedule")
    return 1 if failed else 0


def _remove_old_labels(uid: str) -> None:
    for label in OLD_LABELS:
        _launchctl("bootout", f"gui/{uid}/{label}")
        path = agents_dir() / f"{label}.plist"
        if path.exists():
            path.unlink()


def _remove_extra(uid: str) -> None:
    for label in (REFRESH_LABEL, KEEPALIVE_LABEL):
        _launchctl("bootout", f"gui/{uid}/{label}")
        path = agents_dir() / f"{label}.plist"
        if path.exists():
            path.unlink()


def remove() -> int:
    if sys.platform != "darwin":
        print("this is the macOS scheduler.")
        return 1
    uid = str(__import__("os").getuid())
    _remove_old_labels(uid)
    # The refresh and keep-alive agents go too (round 5: they were left
    # running against whatever they pointed at).
    _remove_extra(uid)
    _launchctl("bootout", f"gui/{uid}/{LABEL}")
    target = plist_path()
    if target.exists():
        target.unlink()
        print(f"removed {target}")
    else:
        print("nothing scheduled")
    return 0


def _last_exit(label: str) -> int | None:
    """The agent's last exit status, or None when it is not loaded."""
    import re
    result = _launchctl("list", label)
    if result.returncode != 0:
        return None
    found = re.search(r'"LastExitStatus"\s*=\s*(-?\d+)', result.stdout or "")
    return int(found.group(1)) if found else 0


def status() -> str:
    """One line for `run.py health`.

    All three agents, and how each last EXITED, not only whether it is loaded
    (round 5: an agent exiting 78 every run for weeks read as "loaded")."""
    if sys.platform != "darwin":
        return "not macOS"
    if not plist_path().exists():
        return "not scheduled — run: python run.py notify --schedule"
    slots = ", ".join(f"{h:02d}:{m:02d}" for h, m in _school_times())
    problems = []
    for label, name in ((LABEL, "reminders"), (REFRESH_LABEL, "auto-refresh"),
                        (KEEPALIVE_LABEL, "keep-alive")):
        code = _last_exit(label)
        if code is None:
            problems.append(f"{name} NOT LOADED")
        elif code != 0:
            # launchd reports a wait status: the exit code is the high byte.
            problems.append(f"{name} last exited {code >> 8 if code > 255 else code}")
    return f"{slots} ({'; '.join(problems) if problems else 'loaded'})"


def resync_if_shifted() -> bool:
    """Rewrite the notify and refresh agents when the school-zone times now
    land on different Mac-clock times (a DST change in one zone only). Run by
    the keep-alive agent, which is on an interval and so never shifts itself,
    and which is not one of the agents it reloads."""
    if sys.platform != "darwin" or not _is_the_real_install():
        return False
    uid = str(os.getuid())
    changed = False
    for label, wanted in ((LABEL, _times), (REFRESH_LABEL, _refresh_slots)):
        path = agents_dir() / f"{label}.plist"
        if not path.exists():
            continue
        try:
            current = plistlib.loads(path.read_bytes())
        except Exception:  # noqa: BLE001
            continue
        slots = wanted()
        if current.get("StartCalendarInterval") == slots:
            continue
        current["StartCalendarInterval"] = slots
        path.write_bytes(plistlib.dumps(current))
        _launchctl("bootout", f"gui/{uid}/{label}")
        _launchctl("bootstrap", f"gui/{uid}", str(path))
        log.info("rescheduled %s for the Mac's clock", label)
        changed = True
    return changed
