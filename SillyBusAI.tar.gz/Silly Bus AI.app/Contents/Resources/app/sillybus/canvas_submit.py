"""Handing an assignment in to Canvas, from the board.

*"find a way be able to submit assignments straight from silly bus no canvas"*
— 2026-09-22. The work still goes TO Canvas; that is where the teacher
collects it. What changes is that the student never has to open Canvas.

This is the **first write this program has ever made to a school system.**
Everything it reads, it reads; nothing until now has changed anything on the
other end. That is worth saying plainly at the top of the file, because the
failure modes here are not "a class shows no homework" — they are "the wrong
file is now in a teacher's gradebook" and "it was handed in twice".

**Four rules, and every one of them has a test.**

*Nothing is sent without a tap on the exact thing that was shown.* `propose()`
builds a description of the submission and stamps it with a `proposal_id`
derived from the fields themselves. `submit()` refuses a proposal_id that does
not match what it is about to send. So a screen that said one thing cannot
submit another, even by accident — the id IS the summary. This is the rule
`tests/test_action_safety.py` already holds for `add_task`, which once wrote
whatever the model emitted.

*Nothing is retried.* A POST that times out has an unknown outcome, and the
one thing worse than a failed submission is two submissions. Every failure
here is final and says so; the student decides whether to try again, knowing
what happened. `extension/bridge.js:263-276` already refuses to replay non-GET
calls on owner handover, for the same reason.

*Nothing runs on its own.* No scheduled job, no refresh hook, no retry timer
may reach this module. `submit()` takes a context and a matching proposal and
is only ever called from a route that a person pressed.

*Off until switched on.* `config.DEFAULTS["submit"]["enabled"]` is False.
[ASKED] 2026-09-22: *"do not test by submiting anything on my canvas I do not
want anything submited unless I say."* The switch exists so that work on this
module cannot submit anything while he is asleep, and so the first real
submission happens with him watching.

**Why session cookies and not an API token.** SPEC §5.2 forbids a Canvas API
access token in this build, and §4.2 records this as "the no-token path". The
app already reads `/api/v1/` through a signed-in browser's cookie jar
(`feeds/canvas.py`), so submitting the same way adds no new credential and no
new permission. It does add one thing the reads never needed: Canvas is Rails,
so a non-GET authenticated by cookie must echo the `_csrf_token` cookie back
as an `X-CSRF-Token` header. Without it Canvas answers in a way that reads
like a login problem, which is a long evening if you do not know.
"""

from __future__ import annotations

import hashlib
import json
import re
import time
from urllib.parse import unquote

from sillybus import config, paths
from sillybus.logging_setup import get

log = get("canvas_submit")

# Canvas's own name for "the person whose session this is". It matters:
# `submission[user_id]` would be submitting on behalf of someone else, which
# needs grading permission and is not what this is.
ME = "self"

# What this build can hand in. [ASKED] 2026-09-22, asked as a multi-select and
# answered with one: *"A file you pick"*. The others are listed in Canvas's
# API and deliberately not implemented — an unimplemented type must refuse
# loudly rather than post a body Canvas will reject.
SUPPORTED = ("online_upload",)

# A submission is the student's own work moving, not the app inventing one.
MAX_BYTES = 40 * 1024 * 1024

# Long, because step 2 is the whole file going up a school's uplink. Still
# finite: a request with no timeout is a hang with no error message.
TIMEOUT_MS = 180_000


class SubmitError(Exception):
    """One sentence for the student, and the fix if there is one.

    Mirrors `feeds/calendars.ConnectionError_`: the message is what goes on
    screen, so it is written for a person and never carries a status code on
    its own.
    """

    def __init__(self, message: str, fix: str = ""):
        super().__init__(message)
        self.message = message
        self.fix = fix


# --------------------------------------------------------------- the switch


def enabled(cfg: dict | None = None) -> bool:
    cfg = cfg if cfg is not None else config.load()
    return bool((cfg.get("submit") or {}).get("enabled", False))


def _require_switch(cfg: dict | None = None) -> None:
    if not enabled(cfg):
        raise SubmitError(
            "handing work in from SillyBus is switched off",
            "turn it on in Settings → Connections, under Handing work in")


# ------------------------------------------------------- what can be sent


def ids_for(item: dict) -> tuple[str, str] | None:
    """(course_id, assignment_id) for a board item, or None.

    Two places carry them and neither is a field on `models.Item`:
    `raw_cell` holds `assignment_id` for items that came from the assignments
    endpoint (`feeds/canvas.py`), and `url` is
    `https://<host>/courses/<cid>/assignments/<aid>` for those and for planner
    items. The url is tried second because a planner item has no assignment_id
    in `raw_cell` at all, so `raw_cell` alone would silently exclude half the
    board.
    """
    if (item or {}).get("source") != "canvas":
        return None
    course_id = assignment_id = ""
    try:
        raw = json.loads(item.get("raw_cell") or "{}")
    except (ValueError, TypeError):
        raw = {}
    if isinstance(raw, dict) and raw.get("assignment_id"):
        assignment_id = str(raw["assignment_id"])
    found = re.search(r"/courses/(\d+)/assignments/(\d+)", item.get("url") or "")
    if found:
        course_id = found.group(1)
        assignment_id = assignment_id or found.group(2)
    if not (course_id and assignment_id):
        return None
    return course_id, assignment_id


def allowed_types(item: dict) -> list[str]:
    """What Canvas says this assignment accepts. Empty means we do not know.

    Carried in `raw_cell` since 0.21.6.0. An older cached board has no such
    key, and the honest answer there is "unknown" rather than "anything" —
    `can_submit()` treats unknown as a refusal: posting a type Canvas does
    not allow fails after the file has already been uploaded.
    """
    try:
        raw = json.loads((item or {}).get("raw_cell") or "{}")
    except (ValueError, TypeError):
        return []
    types = raw.get("submission_types") if isinstance(raw, dict) else None
    return [str(t) for t in types] if isinstance(types, list) else []


def can_submit(item: dict) -> tuple[bool, str]:
    """Should this assignment show a hand-in button at all? (ok, why not)."""
    if (item or {}).get("source") != "canvas":
        return False, "only Canvas assignments can be handed in from here"
    if not ids_for(item):
        return False, "this one has no Canvas assignment link to hand in to"
    types = allowed_types(item)
    if not types:
        return False, ("this assignment was read before SillyBus recorded what "
                       "Canvas accepts — press Refresh and it will know")
    if not set(types) & set(SUPPORTED):
        return False, ("Canvas wants this handed in a way SillyBus cannot do "
                       f"yet ({', '.join(sorted(types))}) — open it in Canvas")
    return True, ""


# ------------------------------------------------------------------- CSRF


def csrf(context) -> str:
    """The `_csrf_token` cookie, URL-decoded, for the `X-CSRF-Token` header.

    Canvas is Rails. A GET authenticated by cookie needs nothing extra; a POST
    is rejected without this. The cookie value is percent-encoded — Rails
    round-trips it — so it has to be decoded or the token does not match.

    Playwright gives the cookie jar directly. The extension runtime's
    `_RequestContext` has no cookie access at all (its XHRs carry cookies the
    browser attaches, which Python never sees), so this returns "" there and
    the caller refuses rather than sending a POST that will fail in a
    confusing way.
    """
    getter = getattr(context, "cookies", None)
    if not callable(getter):
        return ""
    try:
        jar = getter() or []
    except Exception as exc:                    # noqa: BLE001 — any jar failure
        log.warning("could not read cookies: %s", type(exc).__name__)
        return ""
    for cookie in jar:
        if (cookie or {}).get("name") == "_csrf_token":
            return unquote(str(cookie.get("value") or ""))
    return ""


# -------------------------------------------------------------- proposing


def _fingerprint(parts: list[str]) -> str:
    # json.dumps, not a join on a separator: a separator that can appear
    # inside a filename makes two different proposals hash the same.
    body = json.dumps(parts, ensure_ascii=False)
    return hashlib.sha256(body.encode("utf-8")).hexdigest()[:16]


def propose(item: dict, *, file_name: str, file_size: int,
            content_type: str = "", file_note: str = "") -> dict:
    """Describe exactly what would be sent, and stamp it.

    The `proposal_id` is derived from the fields below and nothing else, so
    `submit()` re-deriving it is a real check: if the screen showed one file
    and the tap carries another, the ids differ and nothing is sent. An id
    that is a random token would prove only that a button was pressed.

    Nothing here touches the network. This is the confirm screen's content.
    """
    ok, why = can_submit(item)
    if not ok:
        raise SubmitError(why)
    if file_size <= 0:
        raise SubmitError("that file is empty", "pick the file you meant")
    if file_size > MAX_BYTES:
        raise SubmitError(
            f"that file is bigger than {MAX_BYTES // (1024 * 1024)} MB",
            "hand a file that size in on Canvas itself")
    course_id, assignment_id = ids_for(item)
    proposal = {
        "course_id": course_id,
        "assignment_id": assignment_id,
        "submission_type": "online_upload",
        "course": item.get("course") or "",
        "title": item.get("title") or "",
        "due_date": item.get("due_date") or None,
        "file_name": file_name,
        "file_size": int(file_size),
        "content_type": content_type or "application/octet-stream",
        # Said on the confirm screen in words, because "you have already handed
        # this in" is the single most useful thing to know before pressing a
        # button that cannot be taken back.
        "already_submitted": bool(item.get("submitted")),
        "file_note": file_note,
        "item_id": item.get("item_id") or "",
    }
    proposal["proposal_id"] = _fingerprint(
        [proposal["course_id"], proposal["assignment_id"],
         proposal["submission_type"], proposal["file_name"],
         str(proposal["file_size"]), proposal["item_id"]])
    return proposal


def _rederive(proposal: dict) -> str:
    return _fingerprint(
        [str(proposal.get("course_id") or ""),
         str(proposal.get("assignment_id") or ""),
         str(proposal.get("submission_type") or ""),
         str(proposal.get("file_name") or ""),
         str(proposal.get("file_size") or ""),
         str(proposal.get("item_id") or "")])


# ------------------------------------------------------------ the AI's line


_SPACE = re.compile(r"\s+")


def looks_generated(text: str, assistant_said: list[str]) -> bool:
    """Is this text something the assistant wrote?

    [ASKED] 2026-09-22, in his words: *"The AI can give you tips and
    instructions on how to improve and answer any questions but will not do it
    for you."*

    A rule that lives only in a system prompt lasts until someone rewords the
    prompt, so it lives here instead. Compared on collapsed whitespace and
    case, because a copy-paste through a textarea changes both and changes
    nothing else. Not a similarity score: a threshold invites argument about
    where it sits, and the honest line is "this is the assistant's paragraph,
    moved".
    """
    body = _SPACE.sub(" ", (text or "")).strip().lower()
    if len(body) < 40:            # too short to be an answer being handed in
        return False
    for said in assistant_said or []:
        other = _SPACE.sub(" ", said or "").strip().lower()
        if len(other) < 40:
            continue
        if body == other or body in other or other in body:
            return True
    return False


# --------------------------------------------------------------- the log


def _log_path():
    return paths.data_dir() / "submissions.log"


def record(line: dict) -> None:
    """Append one line per attempt, readable by a person.

    Every submission, successful or not, with what went where and what Canvas
    said back. A write that cannot be audited afterwards is a write nobody can
    argue with when a teacher says they never received it.
    """
    try:
        path = _log_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(line, sort_keys=True) + "\n")
    except OSError as exc:
        log.warning("could not write the submission log: %s", type(exc).__name__)


def history() -> list[dict]:
    try:
        text = _log_path().read_text(encoding="utf-8")
    except (OSError, ValueError):
        return []
    out = []
    for row in text.splitlines():
        try:
            out.append(json.loads(row))
        except ValueError:
            continue                   # one bad line is not the whole log
    return out


# ------------------------------------------------------------- submitting


def _host() -> str:
    return config.load()["canvas"]["host"].rstrip("/")


def _json(response, what: str) -> dict:
    status = getattr(response, "status", 0)
    if status not in (200, 201):
        raise SubmitError(
            f"Canvas refused {what} (HTTP {status})",
            "open the assignment in Canvas and check it is still accepting work")
    try:
        return response.json()
    except Exception as exc:                    # noqa: BLE001
        raise SubmitError(f"Canvas answered {what} with something that was not "
                          "an answer", "try again in a moment") from exc


def submit(context, proposal: dict, data: bytes) -> dict:
    """Perform a proposal. Four requests, in order, no retries.

    [RESEARCHED] 2026-09-22 against Canvas's own API documentation:

      1. POST .../assignments/<aid>/submissions/self/files  {name,size,content_type}
         -> {upload_url, upload_params}
      2. POST <upload_url>  multipart: every upload_param first, `file` LAST,
         and NO auth header — it is usually a signed S3 URL and an Authorization
         header makes it refuse
      3. GET the Location the step-2 redirect gives -> the file object, with id
      4. POST .../assignments/<aid>/submissions
         submission[submission_type]=online_upload&submission[file_ids][]=<id>

    Step 3 is the one that is easy to skip and leaves the file uploaded but
    invisible, which looks exactly like a successful submission of nothing.
    """
    _require_switch()
    if _rederive(proposal) != (proposal.get("proposal_id") or ""):
        # The screen and the tap disagree. Never guess which one was meant.
        raise SubmitError(
            "that does not match what was on the confirm screen",
            "close this and start the hand-in again")
    if proposal.get("submission_type") not in SUPPORTED:
        raise SubmitError("SillyBus cannot hand that kind in yet")
    if len(data) != int(proposal.get("file_size") or -1):
        raise SubmitError(
            "the file changed between the confirm screen and now",
            "start the hand-in again so you can see what is being sent")

    token = csrf(context)
    if not token:
        raise SubmitError(
            "SillyBus could not prove to Canvas that this was really you",
            "open the app on this Mac and sign in to Canvas, then try again")

    host = _host()
    base = (f"{host}/api/v1/courses/{proposal['course_id']}"
            f"/assignments/{proposal['assignment_id']}")
    headers = {"X-CSRF-Token": token}
    started = time.time()

    # 1 — ask where to put it
    told = _json(context.request.post(
        f"{base}/submissions/{ME}/files",
        form={"name": proposal["file_name"], "size": str(proposal["file_size"]),
              "content_type": proposal["content_type"]},
        headers=headers, timeout=TIMEOUT_MS), "the upload")
    upload_url = told.get("upload_url") or ""
    if not upload_url:
        raise SubmitError("Canvas did not say where to put the file",
                          "open the assignment in Canvas and hand it in there")

    # 2 — the bytes. `file` last, and no auth header: both are Canvas's own
    # instruction, and the signed URL rejects the request otherwise.
    fields = dict(told.get("upload_params") or {})
    fields["file"] = {"name": proposal["file_name"],
                      "mimeType": proposal["content_type"], "buffer": data}
    sent = context.request.post(upload_url, multipart=fields, timeout=TIMEOUT_MS)

    # 3 — follow the redirect, authenticated, or the file stays pending and
    # invisible in Canvas while everything here looks like it worked.
    location = (getattr(sent, "headers", {}) or {}).get("location") or ""
    status = getattr(sent, "status", 0)
    if status in (301, 302, 303, 307, 308) and location:
        confirmed = _json(context.request.get(location, timeout=TIMEOUT_MS),
                          "the finished upload")
    elif status in (200, 201):
        confirmed = _json(sent, "the finished upload")
    else:
        raise SubmitError(f"the file did not upload (HTTP {status})",
                          "check the file and try again")
    file_id = confirmed.get("id")
    if not file_id:
        raise SubmitError("Canvas took the file but did not name it",
                          "open the assignment in Canvas and check")

    # 4 — hand it in
    handed = _json(context.request.post(
        f"{base}/submissions",
        form={"submission[submission_type]": "online_upload",
              "submission[file_ids][]": str(file_id)},
        headers=headers, timeout=TIMEOUT_MS), "the hand-in")

    out = {
        "at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "course": proposal.get("course"),
        "title": proposal.get("title"),
        "course_id": proposal["course_id"],
        "assignment_id": proposal["assignment_id"],
        "file_name": proposal["file_name"],
        "file_size": proposal["file_size"],
        "file_id": file_id,
        "attempt": handed.get("attempt"),
        "submitted_at": handed.get("submitted_at"),
        "seconds": round(time.time() - started, 1),
        "ok": True,
    }
    record(out)
    return out
