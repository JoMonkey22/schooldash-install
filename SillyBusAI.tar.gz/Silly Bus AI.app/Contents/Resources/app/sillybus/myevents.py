"""Events the student adds himself — "soccer practice Thursday at 5" in chat,
or a click on an empty hour of the calendar.

[ASKED] 2026-10-06: "make it as easy to add stuff using the chat". Until now a
chat add was always a TASK: an Item, due at 23:59, ranked against his
homework. Practice at 5 is not work he hands in, and filing it as a task put
it on the to-do list and gave it a priority score — the exact failure
models.Event exists to make impossible. So a sentence that names a TIME
becomes an Event, kept here, and joins `state["events"]` beside TeamSnap's in
`pipeline.load_state_overlaid`. It is never scored and never on the to-do
list; it is on the calendar and in Personal.

The date and time are the ones he gave, so the note says so. Nothing is
guessed: no time given means an all-day event, and no date means no event.
"""

import hashlib
import re
import uuid
from datetime import date, datetime, timedelta

from sillybus import db, timezones
from sillybus.models import Event

RE_HHMM = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")
SOURCE = "custom"
CONNECTION_ID = "mine"


def _event_id(title: str, created: str) -> str:
    # Random as well as the title and second: "Practice" Thursday and Friday
    # added in the same second must be two events, not one replacing the other.
    salt = uuid.uuid4().hex
    return "mine-" + hashlib.sha1(f"event|{title}|{created}|{salt}".encode("utf-8")).hexdigest()[:14]


def _hhmm(value) -> str | None:
    text = (value or "").strip() if isinstance(value, str) else ""
    match = RE_HHMM.match(text)
    return f"{int(match.group(1)):02d}:{match.group(2)}" if match else None


def add(conn, title: str, day: str, start: str | None = None,
        end: str | None = None, location: str | None = None) -> dict:
    """Save one. Raises ValueError for a missing title or a date that is not
    a date — the caller turns that into a sentence."""
    title = (title or "").strip()[:140]
    if not title:
        raise ValueError("an event needs a name")
    try:
        day = date.fromisoformat((day or "").strip()).isoformat()
    except ValueError:
        raise ValueError("an event needs a date") from None
    start, end = _hhmm(start), _hhmm(end)
    if end and not start:
        end = None
    if start and end and end <= start:
        end = None                      # "9 to 1" written as 21:00–13:00 — keep the start
    created = datetime.now(timezones.zone()).isoformat(timespec="seconds")
    event_id = _event_id(title, created)
    db.add_custom_event(conn, event_id, title, day, start, end,
                        (location or "").strip()[:120] or None, created)
    return to_event(dict(event_id=event_id, title=title, date=day, start_time=start,
                         end_time=end, location=location, created=created)).to_dict()


def remove(conn, event_id: str) -> bool:
    return db.delete_custom_event(conn, event_id)


def to_event(row: dict) -> Event:
    from sillybus.feeds.calendars import classify
    zone = timezones.zone()
    day = date.fromisoformat(row["date"])
    start = end = None
    if row.get("start_time"):
        h, m = map(int, row["start_time"].split(":"))
        begin = datetime(day.year, day.month, day.day, h, m, tzinfo=zone)
        start = begin.isoformat()
        if row.get("end_time"):
            h2, m2 = map(int, row["end_time"].split(":"))
            end = datetime(day.year, day.month, day.day, h2, m2, tzinfo=zone).isoformat()
        else:
            end = (begin + timedelta(hours=1)).isoformat()
    event = Event(
        source=SOURCE, connection_id=CONNECTION_ID, connection="You",
        title=row["title"], date=day.isoformat(), start=start, end=end,
        all_day=start is None, location=row.get("location") or "",
        kind=classify(row["title"], SOURCE),
        date_note=f"added by you on {(row.get('created') or '')[:10]}"
                  + ("" if start else " (no time given, so all day)"),
        flags=["mine"],
    ).finalize()
    event.event_id = row["event_id"]     # the database's id, so it can be removed
    return event


def all_events(conn) -> list[dict]:
    out = []
    for row in db.list_custom_events(conn):
        try:
            out.append(to_event(row).to_dict())
        except (ValueError, KeyError):
            continue                    # a damaged row costs itself, not the calendar
    return out
