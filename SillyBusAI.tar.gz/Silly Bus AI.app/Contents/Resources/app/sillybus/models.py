"""Data shapes. The dashboard, grounding check, and golden tests bind to these.

Field names follow the spec exactly — do not improvise. Items from docs and
Canvas share one shape so scoring and the dashboard treat both identically.
"""

import hashlib
import re
from dataclasses import dataclass, field, asdict
from datetime import date, datetime

# The closed extractor vocabulary. Golden files bind to it; add a value only by
# adding it here and to the golden files in the same commit.
EXTRACTORS = {
    "canvas_stated",
    # A due date read from the words of the assignment's own description,
    # because Canvas's date field was empty or was the day it was posted.
    # [ASKED] 2026-09-22 — see sillybus/duedates.py.
    "canvas_described",
    "day_n_exact",
    "day_n_end_aligned",
    "weekday_snapped",
    "absolute",
    "absolute_snapped_forward",
    "month_heading",
    "model_adjudicated",
    "unresolved",
    "manual",           # tasks the student adds themselves (chat or API)
    # Inferred dates that used to wear a "stated" label, so the board hid
    # their ◇ marker (hard constraint 5; prosecution round 2, 2026-10-07):
    "doc_dated",            # a Canvas quiz with no date, dated from the class doc
    "relative_to_posted",   # "Thursday" in an announcement, counted from its day
}

LINK_KINDS = {
    "ap_classroom", "canvas", "google_doc", "google_slides", "google_sheet",
    "google_form", "google_drive_file", "youtube", "pdf", "quizlet", "kahoot",
    "desmos", "edpuzzle", "albert", "khan", "turnitin",
    # Sources outside school (spec §4.7): a team's schedule, and a calendar
    # the student subscribed to themselves. "calendar" covers Google Calendar
    # and any pasted iCal URL — the connection carries which one it was, and a
    # link kind that named the vendor would need a new value per vendor.
    "teamsnap", "calendar",
    "other",
}

CATEGORIES = {"test", "project", "essay", "quiz", "reading", "practice", "admin", "neutral",
              # legacy scorer categories kept for parity with legacy/priority.py
              "writing", "problem_set", "discussion", "other"}


def norm_course(name: str) -> str:
    """The predecessor's course normalizer, kept byte-compatible because
    legacy_doc_id depends on it: text before the first '-', lowercased,
    non-alphanumerics stripped."""
    name = (name or "").split("-")[0]
    return re.sub(r"[^a-z0-9 ]", "", name.lower()).strip()


def course_key_from_raw(raw: str) -> str:
    """'AP Chemistry-Mazzolini-YR_26/27' -> 'ap-chemistry'."""
    return norm_course(raw).replace(" ", "-") or "unknown-course"


def make_item_id(source: str, course_key: str, title: str, due_date: str | None) -> str:
    key = f"{source}|{course_key}|{title}|{due_date or ''}"
    return hashlib.sha1(key.encode("utf-8")).hexdigest()[:16]


def make_event_id(source: str, connection_id: str, title: str, when: str) -> str:
    """Stable across refreshes: the same game read twice is one event.

    `when` is the occurrence's own start (or date, for an all-day event), NOT
    the series' start — otherwise every Tuesday practice in a recurring series
    collapses onto one id and the board shows one practice a season.
    """
    key = f"{source}|{connection_id}|{title}|{when}"
    return hashlib.sha1(key.encode("utf-8")).hexdigest()[:16]


def make_legacy_doc_id(course_display: str, title: str, due_date: str | None) -> str:
    """The predecessor's doc_id recipe, verified against legacy/course_docs.py:
    sha1(norm_course(display)|normalized lowercase title|due DATE iso or '')[:16].
    Used ONLY to import an existing doc_done.json once."""
    key = "|".join([
        norm_course(course_display),
        re.sub(r"\s+", " ", (title or "").lower()).strip(),
        due_date or "",
    ])
    return hashlib.sha1(key.encode("utf-8")).hexdigest()[:16]


@dataclass
class Link:
    url: str
    text: str = ""
    kind: str = "other"

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Meeting:
    """One real, dated class period from the class feed (spec §8.1)."""
    course_key: str
    course_raw: str
    start: datetime           # tz-aware, local zone
    end: datetime | None
    date: date
    room: str | None = None
    period: int | None = None
    block_id: str = ""
    day_of_block: int = 0     # 1..N, the Nth meeting of THIS course in THIS block

    def to_dict(self) -> dict:
        return {
            "course_key": self.course_key,
            "course_raw": self.course_raw,
            "start": self.start.isoformat() if self.start else None,
            "end": self.end.isoformat() if self.end else None,
            "date": self.date.isoformat(),
            "room": self.room,
            "period": self.period,
            "block_id": self.block_id,
            "day_of_block": self.day_of_block,
        }


@dataclass
class Item:
    """One thing the student has to do (spec §8.2). Docs and Canvas share this shape."""
    source: str               # canvas | doc | veracross | canvas_ics
    course_key: str
    course: str               # display name
    title: str                # trimmed to ~110 chars at a word boundary
    detail: str = ""
    raw_cell: str = ""
    kind: str = ""            # "homepage doc" for docs; plannable_type for Canvas
    category: str = "neutral"
    due: str | None = None    # tz-aware ISO in the local zone, or None
    due_date: str | None = None
    all_day: bool = False
    # The day the work was SET, when the source says. Not the same thing as
    # due_date, and the board shows both when they differ — [ASKED]
    # 2026-09-28: "when something is assigned versus when it is due".
    assigned_date: str | None = None
    description: str = ""     # the teacher's own instructions, as text, when the source has them
    date_note: str = ""       # REQUIRED non-empty before an item may ship
    confidence: str = "high"  # high | medium | low
    extractor: str = "unresolved"
    points: float | None = None
    submitted: bool | None = None
    done: bool = False
    url: str | None = None
    links: list = field(default_factory=list)      # list[Link] or dicts
    merged_from: list = field(default_factory=list)
    score: float = 0.0
    flags: list = field(default_factory=list)
    item_id: str = ""
    legacy_doc_id: str = ""

    def finalize(self) -> "Item":
        """Stamp ids and enforce invariants. Every item passes through here."""
        if not self.date_note:
            raise ValueError(
                f"item {self.title!r} has no date_note — an item may never ship "
                "without one (spec §5.9)")
        if self.extractor not in EXTRACTORS:
            raise ValueError(f"unknown extractor {self.extractor!r} on {self.title!r}")
        self.item_id = make_item_id(self.source, self.course_key, self.title, self.due_date)
        if self.source == "doc":
            self.legacy_doc_id = make_legacy_doc_id(self.course, self.title, self.due_date)
        return self

    def to_dict(self) -> dict:
        out = asdict(self)
        out["links"] = [l.to_dict() if isinstance(l, Link) else l for l in self.links]
        return out


# What an Event may be, in the student's words. The vocabulary is closed for
# the same reason EXTRACTORS is: the board styles them, and a kind invented at
# a call site is a row that renders as nothing.
EVENT_KINDS = {"game", "practice", "meeting", "appointment", "shift", "travel", "event"}


@dataclass
class Event:
    """Something that HAPPENS to him, that he does not hand in (spec §8.3).

    The third shape, and it exists because the first two both lie about this
    data. An `Item` is one thing the student has to DO: it carries points, a
    submitted flag, a Done toggle and a priority score, and the scorer ranks
    it against every other Item. Put a Saturday soccer game in that list and
    it outranks the lab report, because it happens sooner — which is exactly
    backwards, and is the failure this class is here to make impossible. A
    `Meeting` is a real dated class period from the school's own feed, and the
    schedule strip, the block/Day-N arithmetic and every date strategy in
    docs/dates.py are built on that meaning; a dentist appointment is not a
    class period and must never be counted as one.

    So an Event is neither. It is never scored, never merged with an Item,
    never ranked, and `scoring.rank()` is never shown one. It reaches the
    board through `state["events"]` and appears in Personal and on the
    calendar. Decision log 2026-09-16.

    What it keeps from Item, deliberately: `date_note` is REQUIRED and
    enforced in finalize(), because "nothing may be hidden silently and every
    dated thing says where its date came from" is a property of the board, not
    of one class (spec §5.9).
    """
    source: str                  # google_calendar | teamsnap | ical
    connection_id: str           # which saved connection produced it
    connection: str              # that connection's display name
    title: str
    date: str                    # YYYY-MM-DD local — always present
    start: str | None = None     # tz-aware ISO local; None for an all-day event
    end: str | None = None
    end_date: str | None = None  # last day INCLUSIVE, for a multi-day event
    all_day: bool = False
    location: str = ""
    detail: str = ""
    kind: str = "event"
    date_note: str = ""          # REQUIRED non-empty, enforced in finalize
    confidence: str = "high"     # high | medium | low
    url: str | None = None
    links: list = field(default_factory=list)
    flags: list = field(default_factory=list)
    event_id: str = ""

    def finalize(self) -> "Event":
        if not self.date_note:
            raise ValueError(
                f"event {self.title!r} has no date_note — nothing dated may "
                "ship without one (spec §5.9)")
        if not self.date:
            raise ValueError(f"event {self.title!r} has no date")
        if self.kind not in EVENT_KINDS:
            raise ValueError(f"unknown event kind {self.kind!r} on {self.title!r}")
        self.event_id = make_event_id(self.source, self.connection_id,
                                      self.title, self.start or self.date)
        return self

    def to_dict(self) -> dict:
        out = asdict(self)
        out["links"] = [l.to_dict() if isinstance(l, Link) else l for l in self.links]
        return out


@dataclass
class Course:
    course_key: str
    course_raw: str
    display_name: str = ""
    canvas_course_id: str = ""
    canvas_url: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Profile:
    """A thin wrapper over the profile JSON. profiling/schema.py is the single
    source of truth for the shape; this just carries it around."""
    course_key: str
    raw: dict = field(default_factory=dict)

    def get(self, *path, default=None):
        node = self.raw
        for part in path:
            if not isinstance(node, dict) or part not in node:
                return default
            node = node[part]
        return node

    def to_dict(self) -> dict:
        return self.raw


@dataclass
class Run:
    run_id: str
    started: str
    finished: str | None = None
    ok: bool = False
    counts: dict = field(default_factory=dict)
    warnings: list = field(default_factory=list)
    diagnostics: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)
