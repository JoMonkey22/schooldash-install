"""Personal work time and capacity-limited work dates, never school deadlines."""
from datetime import date, datetime, timedelta, timezone
from statistics import median
import math
import re


def minutes(value, low=1, high=720):
    if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
        raise ValueError(f'Choose a whole number from {low} to {high} minutes.')
    return value


def record(conn, item, value):
    value = minutes(value)
    conn.execute('INSERT INTO study_effort(item_id, minutes, course_key, category) VALUES(?,?,?,?) ON CONFLICT(item_id) DO UPDATE SET minutes=excluded.minutes, course_key=excluded.course_key, category=excluded.category',
                 (item['item_id'], value, item.get('course_key') or '', item.get('category') or 'other'))
    conn.commit()


def timer(conn, item, action, now=None):
    now = now or datetime.now(timezone.utc)
    if action == 'start':
        conn.execute('INSERT OR IGNORE INTO study_timers(item_id, started) VALUES(?,?)', (item['item_id'], now.timestamp()))
        conn.commit()
        return {'running': True}
    if action != 'stop':
        raise ValueError('Use start or stop.')
    row = conn.execute('SELECT started FROM study_timers WHERE item_id=?', (item['item_id'],)).fetchone()
    if row is None:
        raise ValueError('Start the work timer first.')
    elapsed = max(1, math.ceil((now.timestamp() - row['started']) / 60))
    if elapsed > 720:
        raise ValueError('This timer ran over 12 hours. Enter your actual work minutes instead.')
    old = conn.execute('SELECT minutes FROM study_effort WHERE item_id=?', (item['item_id'],)).fetchone()
    total = minutes(elapsed + (old['minutes'] if old else 0))
    record(conn, item, total)
    conn.execute('DELETE FROM study_timers WHERE item_id=?', (item['item_id'],))
    conn.commit()
    return {'running': False, 'minutes': total}


def enrich(conn, items):
    from sillybus import scoring, study_checklists
    efforts = {r['item_id']: dict(r) for r in conn.execute('SELECT * FROM study_effort')}
    running = {r['item_id']: r['started'] for r in conn.execute('SELECT * FROM study_timers')}
    completed = [dict(r) for r in conn.execute('SELECT e.* FROM study_effort e JOIN done d ON d.item_id=e.item_id')]
    for item in items:
        base = item.get('est_minutes') or scoring.estimate_minutes(item.get('category') or 'other')
        samples = [r['minutes'] for r in completed if r['category'] == item.get('category') and r['course_key'] == (item.get('course_key') or '')]
        basis = 'your completed work in this class'
        if len(samples) < 3:
            samples = [r['minutes'] for r in completed if r['category'] == item.get('category')]
            basis = 'your completed work of this kind'
        learned = len(samples) >= 3
        estimate = max(1, round(median(samples))) if learned else base
        preference = study_checklists.preference(conn,item.get('course_key') or '')
        pref_basis = None
        if not learned and item.get('category') in ('test','quiz') and preference['level'] != 'standard':
            estimate = max(10,round(base * (0.65 if preference['level'] == 'lighter' else 1.5)))
            pref_basis = 'your preparation preference; a suggestion, not verified test difficulty'
        item.update(est_minutes=estimate, est_label=scoring.format_minutes(estimate),
                    est_basis=basis if learned else (pref_basis or 'category estimate; record three completed tasks to personalize'),
                    est_samples=len(samples) if learned else 0,
                    actual_minutes=efforts.get(item['item_id'], {}).get('minutes', 0),
                    work_started=running.get(item['item_id']))


def week(state, capacity=60, recovery=False):
    capacity = minutes(capacity, 15, 360)
    today = date.fromisoformat(state['today'])
    days = [{'date': (today + timedelta(days=i)).isoformat(), 'deadline_minutes': 0,
             'planned_minutes': 0, 'blocks': [], 'deadlines': [], 'capacity': capacity} for i in range(7)]
    by_day = {d['date']: d for d in days}
    items = [i for i in state.get('items', []) if not i.get('done')]
    for item in items:
        if item.get('due_date') in by_day:
            day = by_day[item['due_date']]
            day['deadline_minutes'] += item.get('est_minutes') or 15
            day['deadlines'].append({'item_id': item['item_id'], 'title': item['title']})
    unscheduled, late, undated = [], [], []
    for item in sorted(items, key=lambda i: (i.get('due_date') or '9999', -(i.get('score') or 0), i['item_id'])):
        remaining = max(5, (item.get('est_minutes') or 15) - (item.get('actual_minutes') or 0))
        deadline = item.get('due_date')
        if not deadline:
            undated.append(item['item_id'])
        available = [d for d in days if not item.get('assigned_date') or item['assigned_date'] <= d['date']]
        # Earliest deadline first, in chunks small enough to fit a real day.
        for day in available:
            space = max(0, capacity - day['planned_minutes'])
            take = min(space, remaining)
            if take > 0:
                after = bool(deadline and day['date'] > deadline)
                block = {'item_id': item['item_id'], 'title': item['title'], 'minutes': take,
                         'deadline': deadline, 'after_deadline': after, 'date': day['date']}
                day['blocks'].append(block); day['planned_minutes'] += take; remaining -= take
                if after and item['item_id'] not in late:
                    late.append(item['item_id'])
            if remaining <= 0:
                break
        if remaining:
            unscheduled.append({'item_id': item['item_id'], 'title': item['title'], 'minutes': remaining})
    for day in days:
        day['busy'] = day['deadline_minutes'] > capacity
        day['work_ahead'] = [b for b in day['blocks'] if b['deadline'] and b['date'] < b['deadline']]
        day['free_minutes'] = capacity - day['planned_minutes']
    return {'days': days, 'capacity': capacity, 'recovery': recovery, 'late_items': late,
            'unscheduled': unscheduled, 'undated_items': undated,
            'note': 'Suggested work dates only. School deadlines stay unchanged. Daily time is a planning budget, not measured calendar availability.'}


def save_plan(conn, plan):
    conn.execute('DELETE FROM study_blocks WHERE work_date>=?', (plan['days'][0]['date'],))
    for day in plan['days']:
        totals = {}
        for block in day['blocks']:
            totals[block['item_id']] = totals.get(block['item_id'], 0) + block['minutes']
        for item_id, total in totals.items():
            conn.execute('INSERT INTO study_blocks(item_id,work_date,minutes) VALUES(?,?,?)', (item_id, day['date'], total))
    conn.commit()


def chat_request(message, state):
    if not re.search(r"\b(?:i missed (?:a|one|[0-9]+) day|catch[ -]?up plan|weekly workload|workload this week)\b", message, re.I):
        return None
    plan = week(state, recovery='missed' in message.lower() or 'catch' in message.lower())
    text = 'Here is a suggested catch-up plan' if plan['recovery'] else 'Here is your week'
    text += ' (60 minutes per day). School deadlines stay unchanged.\n\n'
    text += '\n'.join(f"{d['date']}: {d['planned_minutes']} minutes planned; {d['deadline_minutes']} minutes of work due" for d in plan['days'])
    if plan['late_items']:
        text += '\nSome work cannot fit before its deadline. The plan flags it; ask your teacher about those deadlines.'
    if plan['unscheduled']:
        text += '\nSome work does not fit this week. Increase your budget or choose priorities in Assignments → Week and catch-up.'
    text += '\n\nOpen Assignments → Week and catch-up to review, adjust the daily budget, and save these work dates.'
    return {'answer': text, 'mode': 'studyplan', 'provider': 'local', 'session_id': None,
            'action': {'intent': 'studyplan'}, 'actions': [], 'grounded': True, 'confidence': 'verified',
            'verified': 0, 'cited': [], 'checked': [], 'violations': []}
