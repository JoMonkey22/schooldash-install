"""Where a fresh install stands, step by step — the data behind the in-app
setup page (/setup) and the "finish setting up" banner.

Setup used to be a chain of macOS dialogs driven from a shell script, with
two browser windows the student had to notice and finish. On the second Mac it
was tried on, it did not finish. So the steps now live in the app itself, where
progress is visible, each step can be retried on its own, and nothing depends
on a dialog that may be hiding behind another window.

Every fact here is read from disk (config, state, credentials, profiles) —
nothing here touches the network, so the page can poll it freely.
"""

from datetime import datetime

from sillybus import config, credentials, paths, pipeline, timezones
from sillybus.logging_setup import get

log = get("onboarding")

# "school" first (prosecution round 5, 2026-10-07): setup never asked which
# school, so a classmate elsewhere was wired to the shipped one — its Canvas,
# its Veracross, its time zone — and their saved Google password went to its
# Veracross. Every later step depends on the answer.
STEPS = ("school", "accounts", "connect", "classes", "first_refresh")


def _state() -> dict:
    return pipeline.load_state() or {}


def _profiles() -> tuple[int, int]:
    """(profiles, of which heuristic-only)."""
    try:
        from sillybus.profiling import store
        profiles, _ = store.load_all()
    except Exception:  # noqa: BLE001
        return 0, 0
    heuristic = sum(1 for p in profiles.values() if p.raw.get("learned_by") == "heuristic")
    return len(profiles), heuristic


def _courses_reviewed() -> tuple[int, int]:
    """(courses with a materials record, of which reviewed by the student)."""
    try:
        from sillybus import courses
        records = courses.load_all()
    except Exception:  # noqa: BLE001
        return 0, 0
    return len(records), sum(1 for r in records.values() if r.get("reviewed_at"))


def status() -> dict:
    cfg = config.load(refresh=True)
    state = _state()
    creds = credentials.status()
    setup_cfg = cfg.get("setup") or {}

    canvas_name = (cfg.get("canvas") or {}).get("name") or ""
    session_ok = state.get("session_ok")
    class_feed = bool(cfg["veracross"]["class_ics"])
    meetings = sum(len(day or []) for day in (state.get("schedule") or {}).values())
    grades = len(state.get("grades") or [])
    error_codes = {e.get("code") for e in state.get("errors") or []}
    profiles, heuristic = _profiles()
    courses_total, courses_reviewed = _courses_reviewed()

    school_done = config.school_confirmed(cfg)
    uses_veracross = config.veracross_in_use(cfg)
    school_cfg = cfg.get("school") or {}
    accounts_done = creds["google"]["configured"] or bool(setup_cfg.get("skipped_accounts"))
    # Veracross is part of connecting only at a school that uses it. A
    # Canvas-only school could otherwise never finish setup: it has no class
    # feed to find (prosecution round 5, 2026-10-07).
    connect_done = bool(session_ok) and (
        not uses_veracross or (class_feed and "veracross_grades" not in error_codes))
    classes_done = profiles > 0 and (courses_reviewed > 0 or bool(setup_cfg.get("classes_seen")))
    refresh_done = bool(state.get("generated_at"))

    canvas_host = (cfg.get("canvas") or {}).get("host") or ""
    portal = (cfg.get("veracross") or {}).get("portal") or ""
    steps = [
        {"key": "school", "title": "Your school",
         "done": school_done,
         "summary": (", ".join(filter(None, [
             school_cfg.get("name") or None,
             canvas_host.replace("https://", ""),
             "Veracross" if uses_veracross else "no Veracross",
             school_cfg.get("time_zone") or None]))
             if school_done else "not chosen yet")},
        {"key": "accounts", "title": "Your sign-ins",
         "done": accounts_done,
         "summary": (f"Google: {creds['google']['username']}" if creds["google"]["configured"]
                     else "skipped — SillyBus AI will ask you to sign in by hand when a "
                          "session runs out" if setup_cfg.get("skipped_accounts")
                     else "not saved yet")},
        {"key": "connect", "title": "Connect Canvas and Veracross" if uses_veracross else "Connect Canvas",
         "done": connect_done,
         "summary": ", ".join(filter(None, [
             f"Canvas: signed in as {canvas_name}" if session_ok and canvas_name
             else "Canvas: signed in" if session_ok
             else "Canvas: not connected",
             f"schedule feed: {meetings} class meetings" if class_feed and meetings
             else "schedule feed: saved" if class_feed
             else "schedule feed: missing" if uses_veracross
             else None,
             f"grades: {grades} courses" if grades else None]))},
        {"key": "classes", "title": "Your classes",
         "done": classes_done,
         "summary": (f"{profiles} class profile(s)"
                     + (f", {heuristic} unlearned" if heuristic else "")
                     + (f"; {courses_reviewed} of {courses_total} reviewed" if courses_total
                        else "; materials not detected yet"))
         if profiles else "no classes set up yet"},
        {"key": "first_refresh", "title": "First pull",
         "done": refresh_done,
         "summary": (f"{len(state.get('items') or [])} items as of "
                     f"{(state.get('generated_at') or '')[:16].replace('T', ' ')}"
                     if refresh_done else "never")},
    ]
    next_step = next((s["key"] for s in steps if not s["done"]), None)
    return {
        "completed_at": setup_cfg.get("completed_at"),
        # The school, the sign-ins and the connection — by key, because the
        # old `steps[:2]` silently changed meaning when a step was added.
        "complete": bool(setup_cfg.get("completed_at")) and all(
            s["done"] for s in steps if s["key"] in ("school", "accounts", "connect")),
        "next": next_step,
        "steps": steps,
        "credentials": creds,
        "canvas": {"signed_in": session_ok, "name": canvas_name,
                   "checked_at": state.get("generated_at")},
        "school": {"confirmed": school_done, "name": school_cfg.get("name") or "",
                   "canvas_host": canvas_host, "uses_veracross": uses_veracross,
                   "veracross_portal": portal,
                   "time_zone": school_cfg.get("time_zone") or ""},
        "veracross": {"in_use": uses_veracross,
                      "class_feed": class_feed, "meetings": meetings, "grades": grades,
                      "signed_in": grades > 0 or ("veracross_grades" not in error_codes
                                                  and refresh_done)},
        "profiles": {"count": profiles, "heuristic": heuristic},
        "courses": {"count": courses_total, "reviewed": courses_reviewed},
        "errors": state.get("errors") or [],
        "data_home": str(paths.data_root()),
    }


def mark(key: str, value=True) -> dict:
    """Record a setup milestone in config (setup.<key>)."""
    stamp = datetime.now(timezones.zone()).isoformat(timespec="seconds")
    config.save({"setup": {key: stamp if value is True else value}})
    log.info("setup: %s = %s", key, stamp if value is True else value)
    return status()
