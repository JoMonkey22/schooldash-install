"""What this teacher actually does: their past quizzes, and how they grade.

[ASKED] 2026-09-28: *"a way to uplod the quiz the teacher actually gave to
train silly bus on predicting what questions the teacher will give you so
it makes quizes that would be closer to the questions on the test and the
same thing for home work the ability to train silly bus on predicting what
grade the teacher will give you to give you better feed back"*.

"Train" here means **examples**, not a model. Nothing is fine-tuned and
nothing leaves this Mac to be learned from; the examples the student adds
are shown to the model, in the prompt, at the moment it writes a quiz or
checks a piece of work — "here are three quizzes this teacher gave, match
their style" and "here are two pieces this teacher graded, with the marks
and comments, so calibrate". That is the honest version of the request and
it works on the first example added.

Two kinds, one store:

* **quiz** — a quiz or test the teacher gave: a photo, a PDF or pasted
  text. Used by quizmaker.py as style exemplars.
* **graded** — a piece of homework with the grade the teacher gave and
  what they wrote on it. Used by workcheck.py to calibrate feedback and,
  when there are enough, to say what grade this teacher would probably
  give — labelled as a guess, never written anywhere a grade lives.

A photo has no text until a model with eyes reads it. That is done lazily,
once, the first time the examples are needed (`transcribe_pending`), and
the text is kept; a student who adds six photos of quizzes pays for six
readings once, not on every quiz.
"""

from __future__ import annotations

import io
import json
import re
import time
import uuid
from pathlib import Path

from sillybus import paths
from sillybus.logging_setup import get

log = get("teacher")

KINDS = ("quiz", "graded")
MAX_TEXT = 20_000
MAX_FILE_BYTES = 12 * 1024 * 1024
# Round 5, 2026-10-07: a photo over the API's 5 MB (encoded) is refused on
# every read; an example could hold any number of files, all sent in ONE
# vision call (173 MB in the reviewer's test), retried on every quiz.
MAX_IMAGE_BYTES = 3_750_000
MAX_FILES_PER_EXAMPLE = 8
MAX_VISION_CALL_BYTES = 15 * 1024 * 1024
MAX_TRANSCRIBE_FAILURES = 3
MAX_EXAMPLES = 60
MAX_PDF_PAGES = 30
EXEMPLAR_CHARS = 9_000          # what one prompt may carry, per kind
SAFE = re.compile(r"[^a-z0-9_-]+")

MAGIC = (
    (b"\xff\xd8\xff", "jpg", "image/jpeg"),
    (b"\x89PNG\r\n\x1a\n", "png", "image/png"),
    (b"RIFF", "webp", "image/webp"),
    (b"%PDF", "pdf", "application/pdf"),
)


class TeacherError(RuntimeError):
    def __init__(self, message: str, fix: str = ""):
        super().__init__(message)
        self.message = message
        self.fix = fix


def _key(course_key: str) -> str:
    key = SAFE.sub("-", (course_key or "").strip().lower()).strip("-")
    if not key:
        raise TeacherError("which class is this for?", "open the class first")
    return key[:80]


def folder(course_key: str, create: bool = False) -> Path:
    path = paths.teacher_dir() / _key(course_key)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def _index_path(course_key: str) -> Path:
    return folder(course_key) / "index.json"


def examples(course_key: str, kind: str | None = None) -> list[dict]:
    """Every example on file for a class, newest first."""
    path = _index_path(course_key)
    if not path.exists():
        return []
    try:
        rows = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    if not isinstance(rows, list):
        return []
    rows = [r for r in rows if isinstance(r, dict)]
    if kind:
        rows = [r for r in rows if r.get("kind") == kind]
    return sorted(rows, key=lambda r: r.get("added_at") or "", reverse=True)


def _write(course_key: str, rows: list[dict]) -> None:
    folder(course_key, create=True)
    target = _index_path(course_key)
    tmp = target.with_suffix(".tmp")
    tmp.write_text(json.dumps(rows, indent=1, ensure_ascii=False), encoding="utf-8")
    tmp.replace(target)


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def _percent(grade, possible):
    try:
        g = float(grade)
        p = float(possible) if possible not in (None, "") else None
    except (TypeError, ValueError):
        return None
    if p and p > 0:
        return round(100.0 * g / p, 1)
    if 0 <= g <= 100 and p is None:
        return round(g, 1)
    return None


def _record(course_key: str, kind: str, title: str, **fields) -> dict:
    if kind not in KINDS:
        raise TeacherError("that is not a kind of example", "quiz or graded")
    rows = examples(course_key)
    if len(rows) >= MAX_EXAMPLES:
        raise TeacherError(f"there are already {MAX_EXAMPLES} examples for this class",
                           "remove one you no longer need")
    row = {"id": uuid.uuid4().hex[:12], "kind": kind,
           "title": (title or "").strip()[:160] or ("a quiz" if kind == "quiz" else "graded work"),
           "added_at": _now(), "text": "", "files": [],
           "needs_transcription": False}
    row.update(fields)
    rows.insert(0, row)
    _write(course_key, rows)
    return row


def add_text(course_key: str, kind: str, title: str, text: str, *,
             grade=None, possible=None, comments: str = "",
             assignment: str = "") -> dict:
    """An example typed or pasted in."""
    text = (text or "").strip()
    if kind == "quiz" and not text:
        raise TeacherError("paste the quiz's questions, or add a photo of it",
                           "the text is what the quiz maker learns from")
    fields: dict = {"text": text[:MAX_TEXT]}
    if kind == "graded":
        fields.update({"assignment": (assignment or "").strip()[:160],
                       "grade": grade, "possible": possible,
                       "percent": _percent(grade, possible),
                       "comments": (comments or "").strip()[:4000]})
        if fields["percent"] is None and not fields["comments"]:
            raise TeacherError("what did the teacher give it?",
                               "a score (like 17/20) or their comments — either helps")
    return _record(course_key, kind, title, **fields)


def sniff(data: bytes) -> tuple[str, str]:
    for magic, ext, media in MAGIC:
        if data.startswith(magic):
            if ext == "webp" and data[8:12] != b"WEBP":
                continue
            return ext, media
    raise TeacherError("that file is not a photo (JPEG/PNG/WebP) or a PDF",
                       "take a photo of it, or export it as a PDF")


def _pdf_text(data: bytes) -> str:
    try:
        from pypdf import PdfReader
    except ImportError:
        return ""
    try:
        reader = PdfReader(io.BytesIO(data))
        return "\n".join((page.extract_text() or "") for page in reader.pages[:MAX_PDF_PAGES])
    except Exception as exc:  # noqa: BLE001
        log.info("pdf unreadable: %s", type(exc).__name__)
        return ""


def add_file(course_key: str, kind: str, title: str, data: bytes, *,
             grade=None, possible=None, comments: str = "",
             assignment: str = "", example_id: str | None = None) -> dict:
    """A photo or PDF of an example. A PDF's text is read now; a photo is
    read by the model the first time the examples are needed."""
    if not data:
        raise TeacherError("the upload was empty", "try again")
    if len(data) > MAX_FILE_BYTES:
        raise TeacherError(f"that file is bigger than {MAX_FILE_BYTES // (1024 * 1024)} MB",
                           "a photo of each page is plenty")
    ext, media = sniff(data)
    if ext != "pdf" and len(data) > MAX_IMAGE_BYTES:
        raise TeacherError(f"that photo is {len(data) / 1e6:.1f} MB and the AI reads at most "
                           f"{MAX_IMAGE_BYTES / 1e6:.2f} MB a photo",
                           "take it again, or export it smaller")
    home = folder(course_key, create=True)
    rows = examples(course_key)
    row = next((r for r in rows if r.get("id") == example_id), None) if example_id else None
    if example_id and row is None:
        # An unknown id used to create a new example, past the 60-example cap.
        raise TeacherError("that example is gone", "add it again")
    if row is not None and len(row.get("files") or []) >= MAX_FILES_PER_EXAMPLE:
        raise TeacherError(f"an example holds at most {MAX_FILES_PER_EXAMPLE} files",
                           "add the rest as a second example")
    if row is None:
        text = _pdf_text(data) if ext == "pdf" else ""
        fields: dict = {"text": text.strip()[:MAX_TEXT],
                        "needs_transcription": ext != "pdf"}
        if kind == "graded":
            fields.update({"assignment": (assignment or "").strip()[:160],
                           "grade": grade, "possible": possible,
                           "percent": _percent(grade, possible),
                           "comments": (comments or "").strip()[:4000]})
        row = _record(course_key, kind, title, **fields)
        rows = examples(course_key)
        row = next(r for r in rows if r["id"] == row["id"])
    name = f"{row['id']}-{len(row.get('files') or []):02d}.{ext}"
    (home / name).write_bytes(data)
    row.setdefault("files", []).append({"name": name, "media": media, "bytes": len(data)})
    if ext != "pdf":
        row["needs_transcription"] = True
    elif not row.get("text"):
        row["text"] = _pdf_text(data).strip()[:MAX_TEXT]
    _write(course_key, rows)
    return row


def remove(course_key: str, example_id: str) -> bool:
    rows = examples(course_key)
    keep = [r for r in rows if r.get("id") != example_id]
    if len(keep) == len(rows):
        return False
    gone = next(r for r in rows if r.get("id") == example_id)
    for f in gone.get("files") or []:
        try:
            (folder(course_key) / f["name"]).unlink()
        except OSError:
            pass
    _write(course_key, keep)
    return True


def file_path(course_key: str, name: str) -> Path:
    if not re.fullmatch(r"[0-9a-f]{12}-\d{2}\.(jpg|png|webp|pdf)", name or ""):
        raise TeacherError("no such file", "")
    path = folder(course_key) / name
    if not path.exists():
        raise TeacherError("no such file", "")
    return path


# --------------------------------------------------------- reading photos

TRANSCRIBE_SYSTEM = (
    "You transcribe a photo of a school quiz, test or graded assignment "
    "EXACTLY as written, so it can be studied later. Copy every question, "
    "every answer choice, every number and every mark or comment the teacher "
    "wrote. Keep the original numbering. Do not solve anything, do not add "
    "commentary, do not correct mistakes. Where a word cannot be read write "
    "[unclear]. Output plain text only.")


def transcribe_pending(course_key: str, provider, *, limit: int = 6,
                       metered: bool = False) -> int:
    """Read the photos that have no text yet. Returns how many were read.

    Never raises for a provider that cannot see: those examples simply stay
    unread and `exemplar_text` says how many were skipped.
    """
    rows = examples(course_key)
    done = 0
    for row in rows:
        if done >= limit:
            break
        if not row.get("needs_transcription"):
            continue
        images, total = [], 0
        for f in row.get("files") or []:
            if not str(f.get("media", "")).startswith("image/"):
                continue
            try:
                data = (folder(course_key) / f["name"]).read_bytes()
            except OSError:
                continue
            if len(data) > MAX_IMAGE_BYTES or total + len(data) > MAX_VISION_CALL_BYTES:
                continue
            images.append((f["media"], data))
            total += len(data)
        if not images:
            row["needs_transcription"] = False
            continue
        if metered:
            from sillybus import allowance, plans
            try:
                allowance.check("chat")
            except allowance.Exhausted:
                log.info("not reading more photos: this month's allowance is used up")
                break
        try:
            text = provider.complete_vision(
                system=TRANSCRIBE_SYSTEM,
                user=f"Transcribe {'this photo' if len(images) == 1 else f'these {len(images)} photos'} "
                     f"of \"{row.get('title') or 'the example'}\" exactly.",
                images=images, max_tokens=2500, timeout=180)
        except Exception as exc:  # noqa: BLE001 — a blind provider is a fact, not a crash
            log.info("could not transcribe %s: %s", row.get("id"), exc)
            # Not pending for ever: a photo that fails three times is left
            # unread (and said so) instead of being re-sent on every quiz.
            row["transcribe_failures"] = int(row.get("transcribe_failures") or 0) + 1
            if row["transcribe_failures"] >= MAX_TRANSCRIBE_FAILURES:
                row["needs_transcription"] = False
                row["transcribe_gave_up"] = True
            _write(course_key, rows)
            break
        if metered:
            for _ in range(plans.work_check_calls() * len(images)):
                allowance.record("chat")
        row["text"] = ((row.get("text") or "") + "\n" + (text or "")).strip()[:MAX_TEXT]
        row["needs_transcription"] = False
        row["transcribed_by"] = getattr(provider, "name", "")
        done += 1
    if done:
        _write(course_key, rows)
    return done


# --------------------------------------------------------- for the prompts

def exemplar_text(course_key: str, kind: str, limit_chars: int = EXEMPLAR_CHARS
                  ) -> tuple[str, int, int]:
    """(text block for a prompt, how many examples it holds, how many were
    skipped for having no text yet). Newest first, bounded."""
    rows = examples(course_key, kind)
    parts: list[str] = []
    used = skipped = 0
    total = 0
    for row in rows:
        text = (row.get("text") or "").strip()
        if not text:
            skipped += 1
            continue
        head = f"--- {row.get('title') or kind} ({(row.get('added_at') or '')[:10]})"
        if kind == "graded":
            score = ""
            if row.get("percent") is not None:
                score = f" — teacher's grade: {row.get('grade')}/{row.get('possible')}" \
                        f" = {row['percent']}%" if row.get("possible") else \
                        f" — teacher's grade: {row['percent']}%"
            head += score
            if row.get("assignment"):
                head += f" — assignment: {row['assignment']}"
        block = head + " ---\n" + text
        if row.get("comments"):
            block += f"\nTEACHER'S COMMENTS: {row['comments']}"
        room = limit_chars - total - (2 if parts else 0)
        if room <= 200:
            break
        block = block[:room]
        parts.append(block)
        total += len(block) + (2 if len(parts) > 1 else 0)
        used += 1
    return "\n\n".join(parts), used, skipped


def summary(course_key: str) -> dict:
    """Counts for the class page. Never text."""
    rows = examples(course_key)
    quizzes = [r for r in rows if r.get("kind") == "quiz"]
    graded = [r for r in rows if r.get("kind") == "graded"]
    percents = [r["percent"] for r in graded if isinstance(r.get("percent"), (int, float))]
    return {"quizzes": len(quizzes), "graded": len(graded),
            "unread_photos": sum(1 for r in rows if r.get("needs_transcription")),
            "average_percent": round(sum(percents) / len(percents), 1) if percents else None}
