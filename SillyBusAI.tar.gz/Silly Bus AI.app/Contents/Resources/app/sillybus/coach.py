"""Preset replies for SillyBus Lock's Get More Time.

This flow is entirely local: no AI provider, metering or external requests.
It points to real unfinished work, asks once after the student's first
message, and offers five minutes after their second. With no visible work,
it offers five minutes after one message while the dashboard catches up.
The lock itself still enforces the time grant and daily limits.
"""

from __future__ import annotations

# [ASKED] 2026-10-08: screen time must use preset code, with no API tokens.
MAX_MINUTES = 10
DEFAULT_MINUTES = 5
MAX_TURNS = 12
MAX_CHARS = 600


def _clean(messages) -> list[dict]:
    out = []
    for m in (messages or [])[-MAX_TURNS:]:
        if not isinstance(m, dict):
            continue
        role = "assistant" if m.get("role") == "assistant" else "user"
        text = str(m.get("text") or "").strip()[:MAX_CHARS]
        if text:
            out.append({"role": role, "text": text})
    return out


def _scripted(status: dict, mine: int, app: str) -> dict:
    items = [] if status.get("signed_out") else (status.get("open") or [])
    first = str(items[0].get("title") or "").strip() if items else ""
    count = int(status.get("open_count") or len(items) or 0)
    if mine == 0:
        if first:
            reply = (f"Real talk: \"{first}\" is still waiting. Knock it out now and "
                     "you can get back to your break. See the dashboard for what remains.")
        elif count:
            reply = (f"You've got {count} thing{'s' if count != 1 else ''} due soon. "
                     "Do one now and you'll feel way better about the rest.")
        else:
            reply = "Nothing's due — the lock should open on its own in a moment."
        return {"reply": reply, "offer_minutes": 0}
    if mine == 1:
        return {"reply": ("Okay, I hear you. But future-you at 11pm is going to wish you'd "
                          "started now. Still want the break?"), "offer_minutes": 0}
    return {"reply": (f"Fine — {DEFAULT_MINUTES} minutes. Then straight to "
                      f"{('“' + first + '”') if first else 'your homework'}, deal?"),
            "offer_minutes": DEFAULT_MINUTES}


def talk(messages, app: str, status: dict) -> dict:
    """The coach's next line: {"reply", "offer_minutes", "by"}."""
    app = (str(app or "").strip() or "that")[:60]
    history = _clean(messages)
    mine = sum(1 for m in history if m["role"] == "user")
    if not (status.get("open_count") or status.get("open")):
        # Nothing due as far as the Mac app knows — but the lock is shut, or
        # he would not be here (a board not loaded yet, or another copy's
        # work). Never a trap (round 6): minutes once he has said anything.
        if mine == 0:
            return {"reply": ("SillyBus doesn't see anything due right now — open it and "
                              "refresh so the lock can catch up. Need a few minutes meanwhile? Say why."),
                    "offer_minutes": 0, "by": "script"}
        return {"reply": f"Fair enough — {DEFAULT_MINUTES} minutes while SillyBus catches up.",
                "offer_minutes": DEFAULT_MINUTES, "by": "script"}

    return {**_scripted(status, mine, app), "by": "script"}
