"""What SillyBus knows, shaped for Canvas's own pages.

*"in the chrome extetion I want it to be like better campus where it changes
and adds the assignments and grade and other info for the class"* —
2026-09-23.

BetterCampus (which was BetterCanvas) is an extension that makes Canvas
better **on Canvas** — grades on the dashboard cards, a usable to-do list,
previews. He wants that, with SillyBus's answers in it: this program already
knows things Canvas's own pages do not, and until now it only ever said them
somewhere else.

Three of those are worth putting on the page:

* **A due date Canvas has wrong.** `duedates.py` reads the deadline out of
  the assignment's own description, and the place that correction matters is
  the page where the wrong date is printed. [ASKED] the corrected date
  replaces it, with Canvas's own on hover.
* **Work Canvas never had.** Homework a teacher typed into their own document
  is most of some classes, and it is invisible on Canvas by definition.
* **The grade, on the dashboard.** Canvas makes you click into each course.

## Why this module exists rather than the route building it

The overlay is served through the **token gate**, not the account gate — an
extension is a browser, not a person, and the account check would refuse every
request (see `routes_api`'s bridge section). A gate that loose deserves a
payload that was decided deliberately, in one readable place, rather than
assembled inline in a route: this is the only thing in the app that hands the
board to something outside it.

So: **an allowlist of fields, not the state with secrets removed.** Everything
here is named. A field added to `models.Item` later does not silently start
travelling, and `tests/test_campus.py` fails if it does.

## What is deliberately not here

No `raw_cell` (a teacher's document, verbatim), no `detail` beyond the title,
no chat, no marks the student has not seen, no mail. The overlay needs to
label a page, not to hold a copy of the board.

Pure: no network, no clock beyond the date passed in.
"""

import json
import re
from urllib.parse import urlparse

# Straight off models.Item, and the list is the point — see the docstring.
ITEM_FIELDS = (
    "item_id", "course_key", "course", "title", "due_date", "date_note",
    "kind", "category", "points", "submitted", "done", "url", "score",
    "confidence", "extractor", "source",
)

# Items that ARE Canvas's own record of a piece of work: the planner and
# assignments readers, and the Canvas calendar feed used when the session is
# down. Everything else may link to Canvas without being Canvas's record.
CANVAS_SOURCES = {"canvas", "canvas_ics"}

# Canvas addresses the overlay has to recognise.
RE_COURSE = re.compile(r"/courses/(\d+)")
RE_ASSIGNMENT = re.compile(r"/courses/\d+/assignments/(\d+)")


def canvas_ids(item: dict) -> tuple[str, str]:
    """(course id, assignment id) for one item, or empty strings.

    `models.Item` carries neither. The assignments endpoint puts
    `assignment_id` into `raw_cell`; planner items do not have one at all; and
    the course id is only ever in the item's URL. So both are dug out here,
    once, rather than in JavaScript on every page load — the shapes are this
    app's own and belong on this side.

    **Only for Canvas's own items** (prosecution round 5, 2026-10-07). A line
    in a teacher's document whose "submit here" link is a Canvas assignment
    used to get that assignment's id too, and the overlay then put the DOC's
    date over Canvas's on the assignment page. A link says where to hand the
    work in; it does not make the line Canvas's record of it.
    """
    if (item.get("source") or "") not in CANVAS_SOURCES:
        return "", ""
    url = item.get("url") or ""
    course_id = ""
    assignment_id = ""
    found = RE_COURSE.search(url)
    if found:
        course_id = found.group(1)
    found = RE_ASSIGNMENT.search(url)
    if found:
        assignment_id = found.group(1)
    if not assignment_id:
        try:
            raw = json.loads(item.get("raw_cell") or "{}")
        except (TypeError, ValueError):
            raw = {}
        if isinstance(raw, dict) and raw.get("assignment_id"):
            assignment_id = str(raw["assignment_id"])
    return course_id, assignment_id


def stated_date(item: dict) -> str:
    """The date Canvas itself shows, when SillyBus is showing a different one.

    Only filled for an item whose date came from the description, because that
    is the only case where the two differ AND SillyBus is confident enough to
    put its own on the page. The overlay puts this on hover, so Canvas's own
    answer is never more than a pointer away — [ASKED] "change it, with the
    old one on hover".
    """
    if "date_from_description" not in (item.get("flags") or []):
        return ""
    try:
        raw = json.loads(item.get("raw_cell") or "{}")
    except (TypeError, ValueError):
        return ""
    stamp = (raw or {}).get("due_at") or ""
    if not isinstance(stamp, str) or not stamp:
        return ""
    # The school's day, not UTC's: a Canvas 11:59 pm deadline is the next
    # day in UTC (prosecution round 2, 2026-10-07).
    from sillybus.feeds import canvas as canvas_mod
    return canvas_mod._local_day(stamp) or stamp[:10]


def item_for_page(item: dict) -> dict:
    out = {field: item.get(field) for field in ITEM_FIELDS}
    course_id, assignment_id = canvas_ids(item)
    out["canvas_course_id"] = course_id
    out["canvas_assignment_id"] = assignment_id
    out["flags"] = list(item.get("flags") or [])
    out["canvas_due_date"] = stated_date(item)
    repeat = item.get("repeat")
    if isinstance(repeat, dict):
        # The sentence and the shape, not the whole series: the overlay says
        # "comes round every week", it does not list the other occurrences.
        out["repeat"] = {k: repeat.get(k) for k in
                         ("says", "which", "count", "every", "weekday",
                          "expected", "expected_note")}
    return out


def grade_for_page(grade: dict, courses: dict | None = None) -> dict:
    """One class's standing, with the Canvas course id it belongs to.

    The id is what lets a dashboard card find its grade: a card carries
    `/courses/123` and nothing else, and matching on the course's NAME would
    break on every class a student renamed (Canvas lets them).
    """
    key = grade.get("course_key") or ""
    record = (courses or {}).get(key) or {}
    return {
        "course_key": key,
        "display_name": grade.get("display_name") or record.get("display_name") or "",
        "percent": grade.get("percent"),
        "letter": grade.get("letter") or "",
        "canvas_course_id": str(record.get("canvas_course_id") or "") or "",
        "source": grade.get("source") or "",
    }


def board(state: dict, courses: dict | None = None, host: str = "") -> dict:
    """Everything the Canvas overlay is given, and nothing else.

    `open_by_course` is the panel's contents, already grouped and already
    sorted by the app's own ranking — a second opinion about what matters
    most, written in JavaScript, is exactly the kind of disagreement this
    codebase keeps having to undo.
    """
    state = state or {}
    courses = courses or {}
    items = [item_for_page(i) for i in (state.get("items") or [])
             if not i.get("done")]
    # Filed by the CLASS the item belongs to, not by the course its link
    # happens to point at (prosecution round 5, 2026-10-07). A Biology line
    # linking to the science department's shared Canvas course was filed
    # under that course, so the Biology card's "N open" never counted it;
    # and doc homework with no link at all was never counted on any card.
    # The class's own Canvas id comes from its course record; the link's
    # course is the fallback only for Canvas's own items (canvas_ids gives
    # nothing else one), where it IS the class.
    class_id = {key: str(rec.get("canvas_course_id"))
                for key, rec in courses.items()
                if isinstance(rec, dict) and rec.get("canvas_course_id")}
    by_course: dict = {}
    for entry in items:
        cid = class_id.get(entry.get("course_key") or "") or entry["canvas_course_id"]
        if not cid:
            # No class record and no Canvas link of its own: a hand-added
            # task, an AP Classroom item. It is still filed by course key
            # below, and the panel finds it there.
            continue
        entry["canvas_course_id"] = cid
        by_course.setdefault(cid, []).append(entry)

    by_key: dict = {}
    for entry in items:
        by_key.setdefault(entry["course_key"], []).append(entry)

    grades = [grade_for_page(g, courses) for g in (state.get("grades") or [])]
    return {
        "generated_at": state.get("generated_at") or "",
        "today": state.get("today") or "",
        "host": (urlparse(host).hostname or "") if host else "",
        "items": items,
        "open_by_course": by_course,
        "open_by_key": by_key,
        "grades": grades,
        # Which class each Canvas course id is, so a page with only an id on
        # it can find work that has no Canvas link at all.
        "course_keys": {str(rec.get("canvas_course_id")): key
                        for key, rec in courses.items()
                        if rec.get("canvas_course_id")},
        "stale": bool(state.get("grades_stale")),
    }
