"""The JSON + SSE API (spec §11). Real status codes; on failure the body is
{"error": {"code", "message", "fix"}} where fix is the one line the student can act
on. Refresh is non-blocking: a background thread, a lock so two can't overlap,
SSE progress, and the previous cache keeps serving meanwhile."""

import json
import re
import threading
import time
import subprocess
import sys
import uuid
from flask import Blueprint, Response, jsonify, request, send_file

from sillybus import config, connectors, db, paths, pipeline, timezones
from sillybus.logging_setup import get, last_error_lines
from sillybus.web import progress

log = get("api")
api = Blueprint("api", __name__)

_refresh_lock = threading.Lock()
_assignment_handoff_lock = threading.Lock()
_runs: dict[str, dict] = {}
_chat_turns: dict[str, dict] = {}


def _error(code: str, message: str, fix: str, status: int = 400):
    return jsonify({"error": {"code": code, "message": message,
                              "fix": paths.runnable(fix)}}), status


# Endpoints reachable before signing in: the gate itself, and the health probe
# the port check uses to tell "SillyBus AI is already serving" from "something
# else has this port".
_OPEN_ENDPOINTS = {"api.get_session", "api.post_session", "api.delete_session",
                   # Recovery has to be reachable by someone who cannot sign
                   # in — that is what it is for. No weaker than post_session:
                   # both turn an email and a secret into a session, and the
                   # server rate-limits a code and a password on one budget.
                   "api.post_session_recover", "api.post_session_forgot",
                   # The Chrome bridge carries its own token instead. An
                   # extension has no account and cannot have one; see the
                   # bridge section below.
                   "api.post_bridge_capture", "api.get_bridge_status",
                   "api.get_bridge_board", "api.post_bridge_calendar", "api.post_bridge_school", "api.post_bridge_assignments",
                   "api.get_health", "api.post_session_refresh",
                   "api.post_session_redeem",
                   # first-run setup happens before anyone has an account
                   "api.get_setup_status", "api.post_setup_mark",
                   "api.get_credentials", "api.put_credentials",
                   "api.delete_credentials", "api.post_login", "api.get_login",
                   "api.post_setup_learn", "api.post_setup_reminders",
                   "api.get_job", "api.post_courses_detect", "api.get_courses",
                   "api.get_course", "api.put_course", "api.post_material",
                   "api.delete_material", "api.get_textbook_search",
                   # SillyBus Lock asks this every minute. Signed out, it is
                   # still told yes/no and a count — a lock that cannot hear
                   # stays shut forever — but no titles (see get_lock).
                   "api.get_lock", "api.post_lock_talk"}
# Deliberately NOT open: /api/state, /api/refresh, chat. The board itself stays
# behind the account gate when one is configured; only the setup wizard's own
# calls run before an account exists.


# ---- cross-site requests -------------------------------------------------
# (prosecution round 5, 2026-10-07) Loopback is not a permission: any web page
# the student opens can make the browser POST to 127.0.0.1:5055. A JSON body
# forces a CORS preflight, and this app answers none, so those never land —
# but a "simple" request (text/plain, a form, no body) is sent without asking,
# and the setup routes, which sit outside the account gate so a fresh install
# can use them, acted on it: [MEASURED] a text/plain POST from another origin
# started /api/setup/learn and /api/courses/detect, each a browser run.
#
# So a state-changing request must show it came from this app's own page. A
# browser marks every request with Sec-Fetch-Site and every POST with Origin;
# either one naming another site refuses it. A request carrying neither is not
# a browser's cross-site request at all — the extension's in-page bridge
# (extension/py/boot.py hands the page's own headers to a test client, never
# an Origin), window.py, curl, the tests — and is let through.
_SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}
_LOOPBACK_NAMES = {"127.0.0.1", "localhost", "[::1]", "::1"}


def _same_origin_request() -> bool:
    from urllib.parse import urlsplit
    fetch_site = (request.headers.get("Sec-Fetch-Site") or "").lower()
    if fetch_site and fetch_site not in ("same-origin", "none"):
        return False
    origin = request.headers.get("Origin")
    if origin is None:
        return True
    try:
        parts = urlsplit(origin)
        theirs = parts.netloc.lower()
        name = (parts.hostname or "").lower()
    except ValueError:
        return False
    return (theirs == (request.host or "").lower()
            and (name in _LOOPBACK_NAMES or name == "[::1]"))


@api.before_request
def _refuse_cross_site():
    if request.method in _SAFE_METHODS:
        return None
    if _same_origin_request():
        return None
    # Only existing token-authenticated courier routes accept extension origins.
    if request.endpoint in {"api.post_bridge_capture", "api.post_bridge_calendar",
                            "api.post_bridge_school", "api.post_bridge_assignments"}:
        from sillybus import bridge
        try:
            bridge.check_token(request.headers.get("X-SillyBus-Token"))
            return None
        except bridge.BridgeError:
            pass
    log.warning("refused a cross-site %s %s", request.method, request.path)
    return _error("cross_site", "this request did not come from SillyBus AI's own page",
                  "use SillyBus AI's own window", 403)


@api.errorhandler(config.ConfigError)
def _config_unreadable(exc):
    # config.save refuses to overwrite a config.json it cannot parse (it used
    # to read it as {} and wipe it); say so instead of a bare 500.
    return _error("config_unreadable", str(exc),
                  "fix the typo in config.json, or move it aside to start setup again", 500)


@api.before_request
def _require_account():
    """The account gate. Off entirely when no account server is configured, so
    a solo install is unaffected."""
    from sillybus import account
    if request.method == "OPTIONS" or request.endpoint in _OPEN_ENDPOINTS:
        return None
    if not account.required():
        return None
    if account.current() is None:
        return _error("signed_out", "sign in to use SillyBus AI",
                      "sign in on the dashboard", 401)
    # Signed in but not paid up. A separate status from 401 on purpose: the page
    # must not throw someone back to a login form they have already completed.
    #
    # Deliberately fail-open in one direction only — the entitlement is read
    # from the cached, server-signed token, so a dead network keeps a paid-up
    # student working (which is the point of caching it) while a lapsed one
    # stays lapsed.
    if not account.entitled():
        sub = account.subscription()
        price = sub.get("price") or {}
        return _error(
            "subscription_needed",
            f"Your SillyBus AI trial has ended. It is "
            f"${price.get('amount', '5.99')} a month to keep using it.",
            "open the dashboard to see how to subscribe", 402)
    return None


# ---- SillyBus AI included: the plan ([ASKED] 2026-10-01) -----------------
# The owner's server keeps the books (sillybus/billing.py); these only pass
# Settings' questions to it. They never decide who has paid.
@api.get("/plan")
def get_plan():
    from sillybus import billing
    return jsonify(billing.status(recheck=request.args.get("recheck") == "1"))


@api.post("/plan/checkout")
def post_plan_checkout():
    from sillybus import billing
    body = request.get_json(silent=True) or {}
    return jsonify(billing.checkout("bundle" if body.get("plan") == "bundle" else "sillybus"))


@api.get("/plan/subscription")
def get_plan_subscription():
    from sillybus import billing
    return jsonify(billing.subscription())


@api.post("/plan/cancel")
def post_plan_cancel():
    from sillybus import billing
    body = request.get_json(silent=True) or {}
    return jsonify(billing.cancel(resume=bool(body.get("resume"))))


@api.get("/session")
def get_session():
    from sillybus import account
    return jsonify(account.status())


@api.post("/session")
def post_session():
    from sillybus import account
    body = request.get_json(silent=True) or {}
    email = (body.get("email") or "").strip()
    password = body.get("password") or ""
    if not email or not password:
        return _error("bad_request", "email and password are required",
                      "fill both boxes", 400)
    action = account.sign_up if body.get("create") else account.sign_in
    try:
        session = action(email, password)
    except account.AccountError as exc:
        status = 401 if exc.code == "bad_credentials" else 400
        if exc.code in ("offline", "server_error"):
            status = 503
        if exc.code == "too_many_attempts":
            status = 429
        return _error(exc.code, str(exc), "check the details and try again",
                      status)
    return jsonify({"email": session["email"], "signed_in": True})


@api.post("/session/recover")
def post_session_recover():
    """Set a new password with the recovery code, and sign in.

    [ASKED] 2026-09-24. Outside the account gate, necessarily: the whole point
    is that the person cannot get past it. It is no weaker than `/session` —
    both turn an email plus a secret into a session, and the server rate-limits
    a code on the same budget as a password, on the same key.

    The fresh code is returned so the page can show it once. Nothing here
    writes it down, and nothing logs it.
    """
    from sillybus import account
    body = request.get_json(silent=True) or {}
    email = (body.get("email") or "").strip()
    code = (body.get("code") or "").strip()
    password = body.get("password") or ""
    if not email or not code or not password:
        return _error("bad_request",
                      "email, recovery code and a new password are all required",
                      "fill all three boxes", 400)
    try:
        session = account.recover(email, code, password)
    except account.AccountError as exc:
        status = {"bad_code": 401, "too_many_attempts": 429,
                  "offline": 503, "server_error": 503}.get(exc.code, 400)
        return _error(exc.code, str(exc), "check the code and try again", status)
    return jsonify({"email": session["email"], "signed_in": True,
                    "recovery_code": session.get("recovery_code") or ""})


@api.post("/session/forgot")
def post_session_forgot():
    """Have a recovery code emailed. Outside the gate, like `/session/recover`
    and for the same reason; the server rate-limits it on its own key."""
    from sillybus import account
    body = request.get_json(silent=True) or {}
    email = (body.get("email") or "").strip()
    if not email:
        return _error("bad_request", "an email address is needed",
                      "type the email you signed up with", 400)
    try:
        answer = account.forgot(email)
    except account.AccountError as exc:
        status = {"mail_not_set_up": 503, "mail_failed": 502,
                  "too_many_attempts": 429, "offline": 503,
                  "server_error": 503}.get(exc.code, 400)
        return _error(exc.code, str(exc), "try again in a minute", status)
    return jsonify({"sent": True, "message": answer.get("message") or ""})


@api.delete("/session")
def delete_session():
    from sillybus import account
    account.sign_out()
    return jsonify({"signed_in": False})


_asset_version_cache: dict = {"key": None, "value": ""}


def _asset_version() -> str:
    """A short digest of the front-end assets, recomputed only when they change.

    Keyed on (size, mtime) rather than content so a page load never re-hashes
    the files; the digest itself is what makes a changed byte visible.
    """
    import hashlib

    static = paths.project_root() / "sillybus" / "web" / "static"
    files = [f for f in (static / "app.js", static / "app.css", static / "views.js")
             if f.exists()]
    if not files:
        return ""
    try:
        key = tuple((f.stat().st_size, f.stat().st_mtime_ns) for f in files)
    except OSError:
        return ""
    if _asset_version_cache["key"] != key:
        digest = hashlib.sha1()
        for f in files:
            try:
                digest.update(f.read_bytes())
            except OSError:
                return ""
        _asset_version_cache["key"] = key
        _asset_version_cache["value"] = digest.hexdigest()[:12]
    return _asset_version_cache["value"]


def _overlay_done(state: dict) -> dict:  # kept for callers inside this module
    overlaid = pipeline.load_state_overlaid()
    return overlaid if overlaid is not None else state


@api.get("/prefs")
def get_prefs():
    """How the board should look and which shape each section is wearing.

    Nothing in here is secret, so it is served verbatim. The page reads this
    once on load; the pre-paint head script works from the localStorage mirror
    because it cannot wait for a fetch, and `applyPrefs()` reconciles the two
    the moment this lands — config wins.
    """
    from sillybus import prefs as ui_prefs
    cfg = config.load()
    # `name` is what the greeting calls the student (prefs.first_name): the
    # name they typed, else their Canvas sign-in's first name.
    return jsonify({"prefs": ui_prefs.load(cfg), "name": ui_prefs.first_name(cfg)})


@api.put("/prefs")
def put_prefs():
    """Write a patch of preferences into config.json.

    Validates by allow-list and writes NOTHING if any key is bad, because
    config.json is read on every request and carries the feed credentials.
    A refusal names the offending key so the page can say which control did
    not take — silently dropping it would report success over a preference
    that never landed.
    """
    from sillybus import prefs as ui_prefs
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return _error("bad_json", "the preferences were not valid JSON",
                      "reload the page and try the setting again")
    try:
        saved = ui_prefs.update(body)
    except ui_prefs.PrefError as exc:
        return _error("bad_pref", str(exc),
                      "pick a different value for that setting", 422)
    return jsonify({"prefs": saved})


@api.get("/focus")
def get_focus():
    """Everything Focus needs to decide, in one object.

    The gate runs as a content script on youtube.com, where there is no Python
    at all -- the dashboard tab is very often closed. So the whole decision
    (the mode, the site list, and what is actually due) has to be readable in
    one go out of `chrome.storage.local`, and this is what `bridge.js` mirrors
    there after boot and after every refresh.

    No secret is in here. The PIN is a hash in the extension's own storage and
    never passes through Python; see `focus.py`.
    """
    from sillybus import focus as focus_mod
    return jsonify({"focus": focus_mod.snapshot(),
                    "presets": [{"id": p["id"], "label": p["label"],
                                 "hosts": list(p["hosts"])}
                                for p in focus_mod.PRESETS]})


# ---- the sources, as switches --------------------------------------------
# Every reader the pipeline has, each with its on/off flag from config.sources.
# What a source knows about a site — how it reads it, whether it needs Chrome,
# what its last error was — is the pipeline's business; this route only says
# which are switched on and lets Settings flip them. The allow-list is the
# DEFAULTS block, so a typo in a PUT is refused rather than written.

# Which sites each switch is about, for the Apps page. The pipeline does not
# need this; a person does, because "canvas_ics_fallback" is not a sentence.
SOURCE_FACTS = {
    "canvas_pages": ("Canvas", "the homework written on each course's front page"),
    "canvas_announcements": ("Canvas", "recent announcements, read for homework in prose"),
    "canvas_discussions": ("Canvas", "ungraded discussion topics that carry real work"),
    "canvas_ics_fallback": ("Canvas", "the personal calendar feed, when the session is dead"),
    "veracross_assignments": ("Veracross", "the assignments feed — thin, and lowest precedence"),
    "ap_classroom": ("AP Classroom", "assigned Progress Checks, read on the site by the extension"),
    "google_classroom": ("Google Classroom", "visible coursework on explicitly linked pages"),
    "albert": ("Albert.io", "assigned practice sets, read on the site by the extension"),
    "connections": ("Your calendars", "every calendar address you have pasted in"),
}


@api.get("/sources")
def get_sources():
    cfg = config.load()
    on = dict(cfg.get("sources") or {})
    out = []
    for name, default in (config.DEFAULTS.get("sources") or {}).items():
        site, what = SOURCE_FACTS.get(name, (name, ""))
        out.append({"name": name, "enabled": bool(on.get(name, default)),
                    "default": bool(default), "site": site, "what": what})
    return jsonify({"sources": out})


@api.put("/sources")
def put_sources():
    """Flip switches. Refuses an unknown name outright — writing it would be a
    key nothing reads, reported as success."""
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return _error("bad_json", "the body must be an object of source -> true/false", "", 400)
    allowed = config.DEFAULTS.get("sources") or {}
    clean = {}
    for name, value in body.items():
        if name not in allowed:
            return _error("no_such_source", f"there is no source called {name!r}",
                          "the switches are the ones the page shows", 400)
        if not isinstance(value, bool):
            return _error("bad_value", f"{name} must be true or false", "", 400)
        clean[name] = value
    if clean:
        config.save({"sources": clean})
    return get_sources()


@api.get("/prefs/background")
def get_prefs_background():
    """The custom board background, served back from the data home.

    Why this is a route and not a data: URL in config.json: config is loaded
    on EVERY request and carries the feed credentials, so a pasted GIF would
    be megabytes of re-parsing per page load. `ui.background.file` is a plain
    file NAME — `prefs.py` refuses a separator or a dot-dot outright — and it
    is resolved here inside one fixed directory, so the name can only ever
    name a file the student dropped on the Appearance page.

    Nothing else under the data home is reachable through it: the name is
    re-validated, the path is resolved, and a result that is not directly
    inside that one directory is a 404 rather than a file.
    """
    from sillybus import prefs as ui_prefs
    name = (ui_prefs.load().get("background") or {}).get("file") or ""
    if not name or not ui_prefs._FILENAME.match(name):
        return _error("no_background", "no background image is set",
                      "drop one on Settings \u2192 Appearance", 404)
    folder = (paths.data_dir() / "background").resolve()
    target = (folder / name).resolve()
    if target.parent != folder or not target.is_file():
        return _error("no_background", "that background is not on this Mac any more",
                      "drop it on Settings \u2192 Appearance again", 404)
    return send_file(target, max_age=0)


# What a background may be, and how big. An image or a short looping video is
# the feature; a 400 MB file is a mistake, and the limit is what turns it into
# a sentence rather than a hang.
BACKGROUND_TYPES = {
    "image/jpeg": ".jpg", "image/png": ".png", "image/gif": ".gif", "image/webp": ".webp",
    "video/mp4": ".mp4", "video/webm": ".webm", "video/quicktime": ".mov",
}
BACKGROUND_MAX_BYTES = 40 * 1024 * 1024


@api.post("/prefs/background")
def post_prefs_background():
    """Save a dropped image, GIF or video as the board's background.

    The bytes go to ONE fixed folder in the data home under a name this route
    chooses (a hash of the content plus the extension the declared type earns),
    and `ui.background.file` gets that name. Nothing the browser sent is used as
    a path, and nothing about the file reaches config.json but its name — that
    file is read on every request and carries the feed credentials.
    """
    from sillybus import prefs as ui_prefs
    import hashlib
    ctype = (request.content_type or "").split(";")[0].strip().lower()
    ext = BACKGROUND_TYPES.get(ctype)
    if not ext:
        return _error("bad_type", "that is not an image or a video the board can show",
                      "drop a JPEG, PNG, GIF, WebP, MP4, WebM or MOV", 415)
    data = request.get_data(cache=False)
    if not data:
        return _error("empty", "the file was empty", "try dropping it again", 400)
    if len(data) > BACKGROUND_MAX_BYTES:
        return _error("too_big", f"that file is {len(data) // (1024 * 1024)} MB",
                      "keep a background under 40 MB", 413)
    folder = paths.data_dir() / "background"
    folder.mkdir(parents=True, exist_ok=True)
    name = "bg-" + hashlib.sha1(data).hexdigest()[:16] + ext
    (folder / name).write_bytes(data)
    # the previous one goes, so the folder never holds more than the board shows
    old = (ui_prefs.load().get("background") or {}).get("file") or ""
    if old and old != name and ui_prefs._FILENAME.match(old):
        try:
            (folder / old).unlink()
        except OSError:
            pass
    saved = ui_prefs.update({"background": {
        "file": name, "kind": "video" if ctype.startswith("video/") else "image"}})
    return jsonify({"prefs": saved, "file": name})


@api.delete("/prefs/background")
def delete_prefs_background():
    """Remove the custom background, file and preference both."""
    from sillybus import prefs as ui_prefs
    current = (ui_prefs.load().get("background") or {}).get("file") or ""
    if current and ui_prefs._FILENAME.match(current):
        try:
            (paths.data_dir() / "background" / current).unlink()
        except OSError:
            pass
    saved = ui_prefs.update({"background": {"file": "", "kind": ""}})
    return jsonify({"prefs": saved})


def _state_fingerprint() -> str:
    """Everything /api/state is built from, as one string: the state file, the
    database (tick-offs, custom tasks), config.json (preferences, joins) and
    the local date (overdue is a function of today). Two calls with the same
    fingerprint would answer the same board.

    [MEASURED] 2026-09-19: the board polls every sixty seconds and rebuilt
    every row from a 173 KB answer each time — including under the mouse, so a
    hover tick vanished on the minute. In the extension the answer is also a
    Python JSON dump of the whole state, sixty times an hour, for nothing."""
    parts = []
    for path in (paths.state_json_path(), paths.data_dir() / "state.db", paths.config_path()):
        try:
            parts.append(str(path.stat().st_mtime_ns))
        except OSError:
            parts.append("-")
    parts.append(str(pipeline.today_local()))
    # And WHICH server answered: the body depends on the code as well as the
    # files, and after an update (or a restart) the same files and day gave
    # the same tag — so the browser kept the old build's answer for good
    # ([MEASURED] 2026-10-07, prosecution round 2: "today" stuck on Oct 6
    # after the fix that recomputes it).
    parts.append(_SERVER_STARTED)
    return "-".join(parts)


_SERVER_STARTED = str(int(__import__("time").time()))


@api.get("/state")
def get_state():
    # Before the 304: most polls end there, and a token that is never renewed
    # signs the student out on day thirty.
    try:
        from sillybus import account
        account.renew_if_due()
    except Exception:  # never let a renewal cost the board
        pass
    tag = 'W/"' + _state_fingerprint() + '"'
    if request.headers.get("If-None-Match") == tag:
        return Response(status=304, headers={"ETag": tag})
    state = pipeline.load_state()
    if not state:
        return jsonify({"empty": True,
                        "message": "no data yet — press Refresh (the first "
                                   "pull takes ~10–20 seconds)",
                        "items": [], "meetings_today": [], "profiles": [],
                        "warnings": [], "errors": [], "diagnostics": {}})
    state = _overlay_done(state)
    cfg = config.load()
    state["stale_after_hours"] = cfg["server"]["stale_after_hours"]
    state["now"] = timezones.to_local(
        __import__("datetime").datetime.now(timezones.zone())).isoformat()
    state["low_priority"] = cfg["scoring"]["low_priority"]
    # Which connectors are on. The strip needs it to know that a chip it
    # earned from old data belongs to a connector that has since been
    # switched off — "off" has to mean the site is gone from the screen, not
    # only that the reader is skipped. [ASKED] 2026-09-20.
    state["sources"] = connectors.flags(cfg)
    try:
        from sillybus.ai import detect
        state["provider"] = detect.describe()[0]
        # Not just the name: whether it is the one that was asked for. A silent
        # demotion is a real drop in answer quality and belongs on screen.
        state["provider_status"] = detect.status("chat")
    except Exception:  # noqa: BLE001
        state["provider"] = "unknown"
        state["provider_status"] = {"active": "unknown", "degraded": True,
                                    "configured": "unknown", "skipped": [],
                                    "model": ""}
    # Which build is being served. A page open since this morning has no way to
    # know the app changed underneath it: it keeps rendering the JS it loaded,
    # so new features are simply absent and — worse — the numbers on screen are
    # whatever was true when the tab was opened. [MEASURED] 2026-09-01: a tab
    # open since 10:14 still showed 93.90% while the data said 92.33%, and the
    # clickable grades added in between were not there at all. The page compares
    # this against the value it first saw and offers a reload.
    state["app_version"] = _asset_version()
    try:
        from sillybus import account
        state["subscription"] = account.subscription()
    except Exception:  # noqa: BLE001 — the board must render regardless
        state["subscription"] = {}
    # What is left of this month's allowance. Sent even when nothing is
    # metered, with `metered: false`, so Settings can say "not limited"
    # instead of showing a bar that means nothing.
    try:
        from sillybus import allowance
        state["allowance"] = allowance.status()
    except Exception:  # noqa: BLE001 — never the board
        state["allowance"] = {}
    # What the Chrome bridge is holding, for Settings. Account-gated with the
    # rest of the page; the extension has its own token-gated route. Its own
    # try, not shared with the allowance above: one of these failing must not
    # blank the other, which is the same lesson as render()'s fault isolation.
    try:
        from sillybus import bridge
        state["bridge"] = bridge.status()
    except Exception:  # noqa: BLE001
        state["bridge"] = {}
    # Where a grade came from, so clicking one can open it at the source.
    state["veracross_portal"] = (cfg.get("veracross") or {}).get("portal") or ""
    state["last_errors"] = last_error_lines(5)
    response = jsonify(state)
    response.headers["ETag"] = tag
    return response


# A sign-in the student can start with a tap.
#
# Why this exists: every session error told them to paste a command. Once the
# command named the real interpreter it became ~150 characters with two quoted
# paths, and pasting that into Terminal is exactly what failed in practice —
# it wraps, bash receives a fragment, and the answer is "command not found".
# Handing a terminal-averse teenager a long command was never the right shape.
# The server already spawns browsers for refresh, so it can spawn this one.
#
# This does not automate a login: it opens the sign-in window and the person
# (or the browser's existing Google session) completes it. No password is
# requested, handled, or stored — spec §5.1 is intact.
_login_lock = threading.Lock()
_logins: dict = {}

LOGIN_KINDS = {
    "canvas": ([], "Canvas"),
    "veracross": (["--veracross"], "Veracross"),
    "all": (["--all"], "Canvas and Veracross"),
}


@api.post("/login")
def post_login():
    body = request.get_json(silent=True) or {}
    kind = (body.get("kind") or "canvas").lower()
    if kind not in LOGIN_KINDS:
        return _error("bad_request", f"unknown sign-in {kind!r}",
                      "ask for canvas, veracross or all", 400)
    extra, label = LOGIN_KINDS[kind]
    # `auto`: use the details saved in Settings (sillybus/autologin.py) and
    # only open a window if a step needs a person. The subprocess ends with a
    # JSON line describing each site's outcome, which the page renders.
    auto = bool(body.get("auto")) or kind == "all"
    if auto:
        extra = [*extra, "--auto", "--json"]

    if not _login_lock.acquire(blocking=False):
        # Pressing again is what someone does when nothing appeared to happen,
        # so it must DO something: lift the window that is already open, and
        # name it. [MEASURED] 2026-09-06 he pressed it repeatedly while a
        # sign-in window sat behind the app window, unraised because the
        # activate call named an application that does not exist.
        from sillybus import browser
        window = "the browser"
        try:
            window = browser.expected_app_name()
            browser.raise_app(window)
        except Exception as exc:  # noqa: BLE001 — cosmetic
            log.debug("could not raise the sign-in window: %s", exc)
        running = next((jid for jid, rec in _logins.items() if not rec["done"]), None)
        return jsonify({"started": False, "already_running": True,
                        "job_id": running, "window": window,
                        "message": f"the sign-in window is already open — it is "
                                   f"called \u201c{window}\u201d. Finish signing "
                                   f"in there and this page will notice."}), 202
    job_id = uuid.uuid4().hex[:12]
    record = {"done": False, "ok": None, "output": "", "label": label,
              "results": [], "auto": auto, "started": time.time()}
    # Same pruning as the job table, for the same reason.
    for stale in sorted((r.get("started", 0), jid) for jid, r in _logins.items()
                        if r["done"])[:-4]:
        _logins.pop(stale[1], None)
    _logins[job_id] = record

    # A list, not a shell string: the paths contain spaces, and the whole point
    # is that nobody has to quote them by hand.
    command = [sys.executable, str(paths.project_root() / "run.py"), "login",
               *extra]

    def work():
        try:
            done = subprocess.run(command, capture_output=True, text=True,
                                  timeout=2400, shell=False)
            stdout = done.stdout or ""
            for line in stdout.splitlines():
                if line.startswith("JSON:"):
                    try:
                        record["results"] = json.loads(line[5:])
                    except ValueError:
                        pass
            record["output"] = "\n".join(l for l in stdout.splitlines()
                                         if not l.startswith("JSON:"))[-800:]
            record["ok"] = done.returncode == 0
            log.info("%s sign-in finished rc=%s", label, done.returncode)
        except Exception as exc:  # noqa: BLE001 — surface, never a dead thread
            log.exception("%s sign-in failed", label)
            record["output"] = str(exc)
            record["ok"] = False
        finally:
            record["done"] = True
            _login_lock.release()

    threading.Thread(target=work, daemon=True).start()
    try:
        from sillybus import browser
        window = browser.expected_app_name()
    except Exception:  # noqa: BLE001
        window = "the browser"
    return jsonify({"started": True, "job_id": job_id, "label": label,
                    "window": window,
                    "message": f"Signing in to {label}. If a window opens it is "
                               f"called \u201c{window}\u201d — finish there."})


@api.get("/login/<job_id>")
def get_login(job_id):
    record = _logins.get(job_id)
    if not record:
        return _error("no_such_job", "that sign-in is not running",
                      "start it again", 404)
    return jsonify({"done": record["done"], "ok": record["ok"],
                    "label": record["label"], "auto": record.get("auto", False),
                    "results": record.get("results") or [],
                    "output": record["output"] if record["done"] else ""})


@api.post("/session/refresh")
def post_session_refresh():
    """Re-ask the account server where this subscription stands.

    Open to the gate on purpose: the person calling it is signed in and locked
    out, and this is the one action that can unlock them. Without it a payment
    would not register until the cached 30-day token expired.
    """
    from sillybus import account
    return jsonify({"subscription": account.refresh_subscription()})


@api.post("/session/redeem")
def post_session_redeem():
    """Redeem a free-access code. Open to the gate, like the refresh above: the
    caller is signed in and locked out, and this is one of the two things that
    can unlock them."""
    from sillybus import account
    code = ((request.get_json(silent=True) or {}).get("code") or "").strip()
    if not code:
        return _error("bad_request", "type the code first", "", 400)
    try:
        return jsonify(account.redeem(code))
    except account.AccountError as exc:
        status = {"too_many_attempts": 429, "already_redeemed": 409,
                  "offline": 503, "server_error": 503}.get(exc.code, 400)
        return _error(exc.code, str(exc), "", status)


@api.post("/refresh")
def post_refresh():
    # Providers are cached for the life of the process, so fixing config.json
    # used to need a restart nobody knew to perform. Refresh is the one button
    # a person already presses when something looks wrong.
    try:
        from sillybus.ai import detect
        detect.reset_cache()
    except Exception:  # noqa: BLE001 — never block a refresh over this
        pass
    if not _refresh_lock.acquire(blocking=False):
        running = next((rid for rid, r in _runs.items() if not r["done"]), None)
        return _error("refresh_running", "a refresh is already running",
                      "wait for it to finish", 409) if not running else (
            jsonify({"run_id": running, "already_running": True}), 202)
    run_id = uuid.uuid4().hex[:12]
    record = {"events": [], "done": False}
    _runs[run_id] = record

    body = request.get_json(silent=True) or {}

    def emit(stage, message, level, course):
        record["events"].append({"stage": stage, "message": message,
                                 "level": level, "course": course})

    def work():
        try:
            pipeline.refresh(pipeline.RefreshOptions(
                docs_only=bool(body.get("docs_only")),
                # `.get(key)` with no default reads a MISSING key as False,
                # which quietly turned this off for every refresh the app's
                # own button makes — it posts "{}". [MEASURED] 2026-09-03:
                # AI Frontiers and Spanish 1 keep their homework in private
                # Google Docs, so pressing Refresh in the app read less than
                # `run.py refresh` did and both classes lost their doc items
                # without anything on screen saying so. The dataclass default
                # is True; only an explicit false may turn it off.
                include_private_docs=bool(body.get("include_private_docs", True)),
                emit=emit))
        except pipeline.AlreadyRunning as busy:
            # Another PROCESS holds the browser profile — the scheduled
            # refresh, a terminal, or a second copy of the app. _refresh_lock
            # above only sees this process, which is COUNT 24. This is a fact
            # about timing, not a failure worth a stack trace or a red banner.
            log.info("refresh skipped: %s", busy)
            record["events"].append({
                "stage": "refresh",
                "message": f"a refresh is already running ({busy.holder or 'another window'}) "
                           "— nothing was changed. Try again when it finishes.",
                "level": "warning", "course": None})
        except Exception as exc:  # noqa: BLE001 — surface, never a dead thread
            log.exception("refresh failed")
            record["events"].append({"stage": "error", "message": str(exc),
                                     "level": "error", "course": None})
        finally:
            record["done"] = True
            _refresh_lock.release()

    threading.Thread(target=work, daemon=True).start()
    return jsonify({"run_id": run_id})


@api.get("/refresh/<run_id>/events")
def refresh_events(run_id):
    record = _runs.get(run_id)
    if not record:
        return _error("no_such_run", f"unknown run {run_id}", "start a refresh", 404)

    def stream():
        sent = 0
        while True:
            while sent < len(record["events"]):
                yield f"data: {json.dumps(record['events'][sent])}\n\n"
                sent += 1
            if record["done"]:
                yield 'data: {"stage": "done"}\n\n'
                return
            time.sleep(0.3)

    return Response(stream(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-store"})


@api.get("/runs")
def get_runs():
    conn = db.connect()
    runs = db.list_runs(conn)
    conn.close()
    return jsonify({"runs": runs})


@api.post("/discover")
def post_discover():
    import contextlib
    import io
    from sillybus.docs import discover
    buffer = io.StringIO()
    try:
        with contextlib.redirect_stdout(buffer):
            code = discover.cli_discover()
    except Exception as exc:  # noqa: BLE001
        return _error("discover_failed", str(exc), "python run.py login", 502)
    return jsonify({"ok": code == 0, "report": buffer.getvalue()})


@api.post("/done")
def post_done():
    body = request.get_json(silent=True) or {}
    item_id = body.get("item_id")
    if not item_id:
        return _error("bad_request", "item_id is required", "pass item_id", 400)
    conn = db.connect()
    db.set_done(conn, item_id, bool(body.get("done", True)))
    conn.close()
    return jsonify({"ok": True, "item_id": item_id,
                    "done": bool(body.get("done", True))})


@api.post("/tasks")
def post_task():
    from sillybus import tasks as tasks_mod
    body = request.get_json(silent=True) or {}
    title = (body.get("title") or "").strip()
    if not title:
        return _error("bad_request", "title is required", "give the task a name", 400)
    conn = db.connect()
    try:
        stored = tasks_mod.add(conn, title=title,
                               due_date=tasks_mod.normalize_due(body.get("due_date")),
                               course=body.get("course"),
                               section=body.get("section"),
                               notes=body.get("notes"),
                               category=body.get("category"))
    finally:
        conn.close()
    return jsonify({"ok": True, "task": stored})


@api.delete("/tasks/<item_id>")
def delete_task(item_id):
    conn = db.connect()
    removed = db.archive_custom_task(conn, item_id)
    db.set_done(conn, item_id, False)
    conn.close()
    if not removed:
        return _error("no_such_task", f"no custom task {item_id}",
                      "only tasks you added can be removed", 404)
    return jsonify({"ok": True})


@api.get("/profiles")
def get_profiles():
    from sillybus.profiling import store
    profiles, problems = store.load_all()
    return jsonify({"profiles": [p.raw for p in profiles.values()],
                    "problems": problems})


@api.get("/profiles/<course_key>")
def get_profile(course_key):
    from sillybus.profiling import store
    profiles, _ = store.load_all()
    if course_key not in profiles:
        return _error("no_such_profile", f"no profile for {course_key}",
                      "python run.py setup --profile-all", 404)
    return jsonify(profiles[course_key].raw)


@api.put("/profiles/<course_key>")
def put_profile(course_key):
    from sillybus.profiling import schema, store
    raw = request.get_json(silent=True)
    if not isinstance(raw, dict):
        return _error("bad_json", "the body must be the profile JSON object",
                      "fix the JSON", 400)
    raw["course_key"] = course_key
    raw["locked"] = True   # a hand edit is never overwritten automatically
    errors = schema.validate(raw)
    if errors:
        return _error("invalid_profile", "; ".join(errors),
                      "fix the listed fields", 422)
    store.save(raw)
    return jsonify({"ok": True, "locked": True})


@api.post("/profiles/<course_key>/relearn")
def relearn_profile(course_key):
    import contextlib
    import io
    from sillybus.profiling import builder
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        code = builder.cli_profile(course=course_key, relearn=True)
    return jsonify({"ok": code == 0, "report": buffer.getvalue()})


@api.get("/item/<item_id>")
def get_item(item_id):
    state = pipeline.load_state()
    if not state:
        return _error("no_state", "no cached state", "python run.py refresh", 404)
    matches = [i for i in state["items"] if i["item_id"] == item_id]
    if not matches:
        return _error("no_such_item", f"no item {item_id} in the last refresh",
                      "refresh and retry", 404)
    return jsonify(matches[0])


@api.get("/health")
def get_health():
    """Cache-only — no network calls, ever. session_valid is the cached verdict
    from the last run; session_checked_at says when that was."""
    state = pipeline.load_state() or {}
    stale_hours = None
    if state.get("generated_at"):
        generated = timezones.to_local(state["generated_at"])
        now = __import__("datetime").datetime.now(timezones.zone())
        stale_hours = round((now - generated).total_seconds() / 3600, 1)
    try:
        from sillybus.ai import detect
        provider = detect.describe()[0]
    except Exception:  # noqa: BLE001
        provider = "unknown"
    from sillybus import __version__
    return jsonify({
        "ok": bool(state) and not state.get("errors"),
        "provider": provider,
        "session_valid": state.get("session_ok"),
        "session_checked_at": state.get("generated_at"),
        "last_run": (state.get("last_run") or {}).get("started"),
        "stale_hours": stale_hours,
        "warnings": state.get("warnings", []),
        "version": __version__,
        # Which sources are switched on. Here rather than in a route of its
        # own because the extension's bridge.js already calls this one, and it
        # needs the answer BEFORE a refresh: a site read by a content script
        # costs a background tab and a sign-in round trip on every pull, and
        # spending that for a student with no Albert.io account is the kind of
        # slow that gets blamed on the whole app. No secret is in here — a
        # switch being on is not a credential.
        "sources": dict(config.load().get("sources") or {}),
    })


# ---- first-run setup ---------------------------------------------------------

@api.get("/setup/status")
def get_setup_status():
    """Where setup stands. Disk-only, so the setup page can poll it."""
    from sillybus import onboarding
    return jsonify(onboarding.status())


@api.post("/setup/mark")
def post_setup_mark():
    from sillybus import onboarding
    body = request.get_json(silent=True) or {}
    key = (body.get("key") or "").strip()
    if key not in ("completed_at", "skipped_accounts", "classes_seen"):
        return _error("bad_request", f"unknown setup milestone {key!r}", "", 400)
    return jsonify(onboarding.mark(key, body.get("value", True)))


@api.post("/setup/learn")
def post_setup_learn():
    """Learn the class profiles that do not exist yet, as a job.

    Calls builder.learn_missing, which takes an `emit` callback — the older
    path redirected sys.stdout, which is process-wide and would have captured
    every other thread's output for the minutes a learn takes.
    """
    def work(say):
        from sillybus.profiling import builder
        return builder.learn_missing(emit=say)
    return jsonify(_start_job("learn", work))


@api.post("/setup/reminders")
def post_setup_reminders():
    """Install the launchd agents: reminders at 07:00/17:00, the half-hourly
    refresh, and the Veracross keep-alive."""
    import contextlib
    import io
    if sys.platform != "darwin":
        return _error("not_mac", "reminders are a macOS feature", "", 400)
    from sillybus import schedule_mac
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        code = schedule_mac.install()
    lines = [l for l in buffer.getvalue().splitlines() if l.strip()]
    return jsonify({"ok": code == 0, "message": lines[0] if lines else "scheduled",
                    "report": buffer.getvalue()})


# ---- saved sign-ins ------------------------------------------------------------
#
# The details SillyBus AI signs back in with (sillybus/credentials.py). GET
# returns presence and usernames only; the secret itself never travels back to
# the page. PUT stores; DELETE forgets.

@api.get("/credentials")
def get_credentials():
    from sillybus import credentials
    return jsonify({"credentials": credentials.status()})


@api.put("/credentials")
def put_credentials():
    from sillybus import credentials
    body = request.get_json(silent=True) or {}
    saved = {}
    try:
        google = body.get("google")
        if isinstance(google, dict):
            saved["google"] = credentials.set(
                "google", email=google.get("email", ""),
                password=google.get("password", ""))
        veracross = body.get("veracross")
        if isinstance(veracross, dict):
            saved["veracross"] = credentials.set(
                "veracross", username=veracross.get("username", ""),
                password=veracross.get("password", ""),
                use_google=bool(veracross.get("use_google")))
    except ValueError as exc:
        return _error("bad_request", str(exc), "", 400)
    return jsonify({"saved": saved, "credentials": credentials.status()})


@api.delete("/credentials")
def delete_credentials():
    from sillybus import credentials
    site = request.args.get("site") or None
    credentials.clear(site)
    return jsonify({"credentials": credentials.status()})


# ---- connections ----------------------------------------------------------------
#
# Calendars and other programs the student connected himself (spec §4.7,
# sillybus/feeds/calendars.py). One rule governs every route here: the URL is
# the credential. It arrives once on POST and is never sent back — GET returns
# `config.redact_connections`, which is every field EXCEPT the URL. DELETE
# removes the entry AND the cached copy of what it downloaded, because
# deleting the address and keeping the data is not deleting anything.

MAX_CONNECTIONS = 24

# How far ahead the connected calendars may be read, in days. The floor is a
# fortnight because anything shorter is the bug this setting exists to fix —
# a season that stopped in two weeks. The ceiling is a bit over a year: past
# that a personal calendar is being asked for a decade of rows, and
# `calendars.MAX_EVENTS_PER_CONNECTION` would be doing all the work anyway.
EVENT_DAYS_MIN = 14
EVENT_DAYS_MAX = 400


def _connection_view() -> dict:
    """What Settings renders: the saved connections, joined to whatever the
    last refresh managed to read from each."""
    from sillybus.feeds import calendars
    saved = config.redact_connections(config.connections())
    state = pipeline.load_state() or {}
    live = {c.get("id"): c
            for c in ((state.get("connections") or {}).get("connections") or [])}
    out = []
    for entry in saved:
        merged = dict(entry)
        merged.update({k: v for k, v in (live.get(entry.get("id")) or {}).items()
                       if k not in ("id", "name", "kind")})
        merged["label"] = calendars.SOURCE_KINDS.get(
            entry.get("kind"), calendars.SOURCE_KINDS[calendars.DEFAULT_KIND])[0]
        out.append(merged)
    return {"connections": out,
            "kinds": [{"kind": k, "label": v[0]}
                      for k, v in calendars.SOURCE_KINDS.items()],
            # How far ahead the calendars are read. Its own setting, not the
            # homework window — a season is months and homework is a fortnight.
            "days_forward": int((config.load().get("event_window") or {})
                                .get("days_forward",
                                     config.DEFAULTS["event_window"]["days_forward"])),
            "days_forward_range": [EVENT_DAYS_MIN, EVENT_DAYS_MAX],
            "read_at": (state.get("connections") or {}).get("read_at")}


@api.get("/connections")
def get_connections():
    return jsonify(_connection_view())


@api.post("/connections")
def post_connection():
    """Add one, and read it once straight away so the answer says whether it
    works. A paste box that accepts anything and reports tomorrow is a paste
    box that quietly holds a typo for a day."""
    from sillybus.feeds import calendars
    body = request.get_json(silent=True) or {}
    url = (body.get("url") or "").strip()
    ok, why = calendars.check_url(url)
    if not ok:
        return _error("bad_url", why,
                      "copy the calendar's iCal address and paste it here", 400)
    entry = calendars.new_connection(url, name=body.get("name") or "",
                                     kind=body.get("kind") or "")
    existing = config.connections()
    # The same calendar however it was written (round 7: webcal:// and
    # https:// of one TeamSnap feed were saved twice).
    if any(calendars.connection_key(e.get("url") or "") == calendars.connection_key(entry["url"])
           for e in existing):
        return _error("already_connected", "that calendar is already connected",
                      "remove it first if you want to add it again", 409)
    if len(existing) >= MAX_CONNECTIONS:
        return _error("too_many", "that is as many calendars as this will hold",
                      "remove one you no longer use", 400)
    # Tried BEFORE it is saved: an address that answers with a sign-in page or
    # a 404 should never reach config.json at all.
    try:
        calendars._fetch(entry["url"])
    except Exception as exc:  # noqa: BLE001 — every failure is the same answer
        message = getattr(exc, "message", None) or calendars._plain(exc)
        return _error("unreachable", message,
                      getattr(exc, "fix", "")
                      or "check you copied the whole address", 400)
    if calendars.is_google_export(entry["url"]):
        ids = calendars.LAST_GOOGLE_IDS.get(entry["url"].strip().rstrip("/")) or []
        # The same Google account under another number in Chrome is the
        # same calendar (round 7).
        if any(calendars.same_google_account(e.get("google_ids"), ids) for e in existing):
            return _error("already_connected", "that Google account is already connected",
                          "remove it first if you want to add it again", 409)
        entry["google_ids"] = ids
    config.save_connections(existing + [entry])
    # Its events go on the board now, not at the next refresh: he linked it
    # to see the games, and "press Refresh" is a step he should not need.
    found = pipeline.read_calendars_now()
    return jsonify({"connection": config.redact_connections([entry])[0],
                    "events_on_board": found, **_connection_view()})


@api.post("/connections/teamsnap")
def post_connection_teamsnap():
    """Link TeamSnap in one step (teamsnap_link.py): a job, because it waits
    for him to sign in to TeamSnap in the app's own window."""
    from sillybus import teamsnap_link
    from sillybus.feeds import calendars

    def work(say):
        url = teamsnap_link.read_feed_address(emit=say)
        existing = config.connections()
        if any(calendars.connection_key(e.get("url") or "") == calendars.connection_key(url)
               for e in existing):
            say("TeamSnap is already linked")
            return {"already": True}
        if len(existing) >= MAX_CONNECTIONS:
            raise RuntimeError("that is as many calendars as this will hold — remove one you no longer use")
        entry = calendars.new_connection(url, name="TeamSnap", kind="teamsnap")
        try:
            calendars._fetch(entry["url"])          # it must answer before it is saved
        except Exception as exc:  # noqa: BLE001
            # Never the address in the words: it is the password (round 7 —
            # an HTTP error carried it into the log and onto the button).
            raise RuntimeError(getattr(exc, "message", None) or calendars._plain(exc)) from None
        config.save_connections(existing + [entry])
        found = pipeline.read_calendars_now()
        say(f"TeamSnap is linked — {found} event(s) on your calendar")
        return {"linked": True, "events_on_board": found}
    return jsonify(_start_job("teamsnap", work))


@api.get("/lock")
def get_lock():
    """Is today's schoolwork done? — what SillyBus Lock is sent (lock.py).

    Open before signing in (it is in `_OPEN_ENDPOINTS`) so the lock is never
    stuck shut by an expired sign-in; the board's own words — the titles of
    what is left — stay behind the gate like the rest of the board."""
    from sillybus import account, lock, timezones
    out = lock.status(pipeline.load_state_overlaid(), pipeline.today_local(),
                      getattr(timezones.zone(), "key", None))
    if account.required() and account.current() is None:
        out["open"] = []
        out["signed_out"] = True
    return jsonify(out)


@api.post("/lock/talk")
def post_lock_talk():
    """The coach's next line for SillyBus Lock's "Get More Time" (coach.py).

    Open like /api/lock, and for the same reason: a lock stuck shut by an
    expired sign-in still needs a way to ask. Titles stay behind the gate —
    signed out, the coach knows only how many things are left."""
    from sillybus import account, coach, lock, timezones
    body = request.get_json(silent=True) or {}
    status = lock.status(pipeline.load_state_overlaid(), pipeline.today_local(),
                         getattr(timezones.zone(), "key", None))
    if account.required() and account.current() is None:
        status["open"] = []
        status["signed_out"] = True
    messages = body.get("messages") if isinstance(body.get("messages"), list) else []
    return jsonify(coach.talk(messages, str(body.get("app") or ""), status))


# [ASKED] 2026-10-07: "in settings add a thing where you set a down time or
# tell the chat to do it". Behind the account gate like every other setting
# (NOT in _OPEN_ENDPOINTS): the lock never calls these — it hears Downtime
# inside /api/lock, which is open. What it means lives in sillybus/downtime.py.
_DOWNTIME_FIELDS = ("on", "start", "end", "days")


@api.get("/downtime")
def get_downtime():
    from sillybus import downtime
    return jsonify(downtime.status())


@api.put("/downtime")
def put_downtime():
    """Change any of on / start / end / days. A wrong value is refused with
    the sentence downtime.set() wrote, and nothing is saved."""
    from sillybus import downtime
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return _error("bad_json", "the body must be an object like {\"on\": true}", "", 400)
    unknown = [k for k in body if k not in _DOWNTIME_FIELDS]
    if unknown:
        return _error("bad_downtime", f"there is no Downtime setting called {unknown[0]!r}",
                      "the settings are on, start, end and days", 400)
    try:
        downtime.set(**{k: body[k] for k in _DOWNTIME_FIELDS if k in body})
    except ValueError as exc:
        return _error("bad_downtime", str(exc), "", 400)
    return jsonify(downtime.status())


@api.post("/events")
def post_event():
    """One event he added himself — from the chat's "Add it" or the calendar.
    The date and time are his; nothing here guesses either."""
    from sillybus import myevents
    body = request.get_json(silent=True) or {}
    conn = db.connect()
    try:
        event = myevents.add(conn, body.get("title") or "", body.get("date") or "",
                             body.get("start"), body.get("end"), body.get("location"))
    except ValueError as exc:
        return _error("bad_event", str(exc), "say what it is and which day", 400)
    finally:
        conn.close()
    return jsonify({"event": event})


@api.delete("/events/<event_id>")
def delete_event(event_id):
    from sillybus import myevents
    conn = db.connect()
    try:
        gone = myevents.remove(conn, event_id)
    finally:
        conn.close()
    if not gone:
        return _error("not_found", "that event is not one you added", "", 404)
    return jsonify({"ok": True})


@api.put("/connections/window")
def put_connection_window():
    """How far ahead the calendars are read.

    A static rule, so Werkzeug matches it ahead of `/connections/<id>` — and
    `test_connections_window` proves that rather than trusting it, because a
    connection whose id happened to be "window" is the kind of thing that is
    only ever found in production.
    """
    body = request.get_json(silent=True) or {}
    days = body.get("days_forward")
    if isinstance(days, bool) or not isinstance(days, int):
        return _error("bad_value", "that must be a whole number of days",
                      f"pick between {EVENT_DAYS_MIN} and {EVENT_DAYS_MAX}", 400)
    if not EVENT_DAYS_MIN <= days <= EVENT_DAYS_MAX:
        return _error("out_of_range",
                      f"that must be between {EVENT_DAYS_MIN} and {EVENT_DAYS_MAX} days",
                      "a school year is about 300 days", 400)
    current = dict(config.load().get("event_window")
                   or config.DEFAULTS["event_window"])
    current["days_forward"] = days
    config.save({"event_window": current})
    return jsonify(_connection_view())


@api.put("/connections/<connection_id>")
def put_connection(connection_id):
    """Rename it, or switch it off without forgetting it."""
    body = request.get_json(silent=True) or {}
    entries = config.connections()
    found = False
    for entry in entries:
        if entry.get("id") == connection_id:
            found = True
            if isinstance(body.get("name"), str) and body["name"].strip():
                entry["name"] = body["name"].strip()[:60]
            if "enabled" in body:
                entry["enabled"] = bool(body["enabled"])
    if not found:
        return _error("not_found", "that connection is not saved here", "", 404)
    config.save_connections(entries)
    return jsonify(_connection_view())


@api.delete("/connections/<connection_id>")
def delete_connection(connection_id):
    """Remove it completely: the stored address goes, and so does the cached
    copy of everything it downloaded."""
    from sillybus.feeds import calendars
    entries = config.connections()
    kept = [e for e in entries if e.get("id") != connection_id]
    if len(kept) == len(entries):
        return _error("not_found", "that connection is not saved here", "", 404)
    config.save_connections(kept)
    calendars.forget(connection_id)
    return jsonify(_connection_view())


# ---- putting the board INTO another calendar -----------------------------------
#
# *"add stuff to google calender based on teamsnap and other things"*
#
# Google Calendar can be written to by its API (OAuth and a Google Cloud
# project — SPEC §5.3 forbids both), by a URL it subscribes to (needs an
# address Google's servers can reach, and §5.7 is loopback-only), or by
# IMPORT. Import is the one that breaks nothing, and it creates real events.
# `feeds/ical_write.py` gives every row a stable UID so importing the file
# again UPDATES rather than duplicates.
#
# This stays BEHIND the account gate on purpose: it is the whole board in one
# file, which is more than /api/state hands out, not less.

# What may be exported. Named rather than free-form so the filename, the
# count and the file can never describe different things.
EXPORT_KINDS = ("all", "events", "work")


def _export_parts(what: str) -> tuple[list, list]:
    state = pipeline.load_state() or {}
    events = state.get("events") or []
    items = state.get("items") or []
    if what == "events":
        return events, []
    if what == "work":
        return [], items
    return events, items


@api.get("/calendar/export/summary")
def get_calendar_export_summary():
    """What the file WOULD hold, so the button can say so before it is
    pressed. A download that turns out to be empty is a download that teaches
    the student not to trust the button."""
    from sillybus.feeds import ical_write
    what = (request.args.get("what") or "all").lower()
    if what not in EXPORT_KINDS:
        what = "all"
    events, items = _export_parts(what)
    out = ical_write.counts(events, items)
    out["what"] = what
    return jsonify(out)


@api.get("/calendar/export.ics")
def get_calendar_export():
    """The board as an .ics file, for importing into Google Calendar."""
    from sillybus.feeds import ical_write
    what = (request.args.get("what") or "all").lower()
    if what not in EXPORT_KINDS:
        return _error("bad_kind", f"there is nothing to export called {what!r}",
                      "choose everything, just events, or just homework", 400)
    events, items = _export_parts(what)
    body = ical_write.build(events, items, name={
        "all": "SillyBus AI", "events": "SillyBus AI — events",
        "work": "SillyBus AI — homework"}[what])
    name = {"all": "sillybus.ics", "events": "sillybus-events.ics",
            "work": "sillybus-homework.ics"}[what]
    return Response(body, mimetype="text/calendar; charset=utf-8", headers={
        "Content-Disposition": f"attachment; filename={name}",
        # It is built from the state on every request and is never a shared
        # artefact; a cached copy would hand back yesterday's homework.
        "Cache-Control": "no-store",
    })


# ---- background jobs -----------------------------------------------------------
#
# Scanning every course or learning a profile takes tens of seconds and must
# not hold an HTTP request open. One small job table: start returns an id, the
# page polls for progress lines and the final result.

# Background jobs, at most one at a time PER KIND.
#
# [PROVEN] tests/test_prosecution.py: a single shared lock refused an
# ⚡ Accelerate whenever a class scan was running — and refused it with the
# SCAN's job id. The page polls whatever id it is handed and renders the result
# as its own, so a course-detection result would have been drawn into the study
# guide panel. Two unrelated features must not share one lock or one id space.
_jobs: dict[str, dict] = {}
_job_locks: dict[str, threading.Lock] = {}
_jobs_guard = threading.Lock()

# Finished jobs are remembered so a page that polls a moment late still gets its
# result — but not forever. The server runs for weeks and an Accelerate result
# is a whole study guide; [PROVEN] nothing ever pruned this table.
MAX_REMEMBERED_JOBS = 24


def _prune_jobs() -> None:
    """Drop the oldest FINISHED jobs once the table is over its cap. A running
    job is never dropped, whatever its age."""
    finished = sorted((record["started"], job_id)
                      for job_id, record in _jobs.items() if record["done"])
    while len(_jobs) > MAX_REMEMBERED_JOBS and finished:
        _, job_id = finished.pop(0)
        _jobs.pop(job_id, None)


# Guides and quizzes take one key each (prosecution round 5, 2026-10-07: one
# lock per KIND made a second guide follow the first's job and draw the first
# one's guide under its own title). They still run one at a time — both use
# the AI allowance and the reader opens the shared browser — so a second
# waits here, saying so, instead of being handed someone else's result.
_writing = threading.Lock()


def _one_writer(work):
    def wrapped(say):
        if not _writing.acquire(blocking=False):
            say("another guide or quiz is being written — this one starts as soon as it is done")
            _writing.acquire()
        try:
            return work(say)
        finally:
            _writing.release()
    return wrapped


def _start_job(kind: str, work) -> dict:
    """Run `work(say)` on a thread; `say(line)` appends a progress line."""
    with _jobs_guard:
        lock = _job_locks.setdefault(kind, threading.Lock())
    if not lock.acquire(blocking=False):
        running = next((job_id for job_id, record in _jobs.items()
                        if record["kind"] == kind and not record["done"]), None)
        return {"started": False, "job_id": running, "kind": kind,
                "already_running": True}
    job_id = uuid.uuid4().hex[:12]
    record = {"kind": kind, "done": False, "ok": None, "lines": [], "result": None,
              "error": None, "started": time.time()}
    with _jobs_guard:
        _jobs[job_id] = record
        _prune_jobs()

    def say(line):
        record["lines"].append(str(line))
        # Also pushed out live, for a host whose jobs cannot really run on a
        # thread — see sillybus/web/progress.py.
        progress.emit(kind, job_id, str(line))

    def run():
        try:
            record["result"] = work(say)
            record["ok"] = True
        except Exception as exc:  # noqa: BLE001 — surface, never a dead thread
            # No web address in what is logged or shown: some are passwords
            # in disguise (calendar feeds). Round 7, 2026-10-07.
            said = re.sub(r"(?:https?|webcal)://[^\s'\"<>)]+", "<address>", str(exc))
            log.error("%s job failed: %s", kind, said[:300])
            log.debug("%s job traceback", kind, exc_info=True)
            record["error"] = said[:300]
            record["ok"] = False
        finally:
            record["done"] = True
            progress.emit(kind, job_id, record["error"] or "", done=True,
                          ok=bool(record["ok"]))
            lock.release()
    threading.Thread(target=run, daemon=True).start()
    return {"started": True, "job_id": job_id, "kind": kind}


@api.get("/jobs/<job_id>")
def get_job(job_id):
    record = _jobs.get(job_id)
    if not record:
        # Either it never existed or it finished long enough ago to have been
        # pruned. The page needs to tell those apart from "still working".
        return _error("no_such_job", "that job is not running any more",
                      "start it again", 404)
    # The failure is reported as "failure", NOT as "error".
    #
    # [MEASURED] 2026-09-20, reported by the student: "it keeps giving me a
    # HTTP 200 error".
    # This is where that came from. Every failed Accelerate said "HTTP 200"
    # and nothing else, so the real reason was never once on screen. This
    # route answers 200 with the job's status, and it used to put the failure
    # text in "error" — but "error" is the key _error() uses for a FAILED
    # request, where it holds an object with a .message. The page's api()
    # helper sees a truthy body.error, reaches for .message on a plain
    # string, gets undefined, and falls back to printing the status code of a
    # response that succeeded. A successful envelope must never use that key.
    return jsonify({"kind": record["kind"], "done": record["done"], "ok": record["ok"],
                    "lines": record["lines"], "result": record["result"] if record["done"] else None,
                    "failure": record["error"]})


# ---- classes: materials, notes, textbooks --------------------------------------

# ---- handing work in to Canvas ---------------------------------------------
# [ASKED] 2026-09-22: *"find a way be able to submit assignments straight from
# silly bus no canvas"*, and in the same breath *"do not test by submiting
# anything on my canvas I do not want anything submited unless I say."*
#
# So there are two routes and they are deliberately not one. `propose` touches
# no network and returns exactly what the confirm screen shows, stamped with
# an id derived from those fields. `submit` refuses an id that does not
# re-derive — the screen and the tap cannot disagree. That is the shape
# `tests/test_action_safety.py` already requires of `add_task`, which once
# wrote whatever the model emitted.
#
# Neither is in `_OPEN_ENDPOINTS`; both sit behind the account gate. And both
# refuse outright while `config.submit.enabled` is False, which is how it
# ships.


def _item_for_submit(item_id):
    state = pipeline.load_state()
    if not state:
        return None, _error("no_state", "no cached state", "press Refresh", 404)
    for item in state["items"]:
        if item["item_id"] == item_id:
            return item, None
    return None, _error("no_such_item", f"no item {item_id} in the last refresh",
                        "press Refresh and try again", 404)


@api.get("/submit/status")
def get_submit_status():
    """Whether handing work in is switched on, said in words.

    A button that is simply absent teaches nothing. This says off, and where
    the switch is.
    """
    from sillybus import canvas_submit

    on = canvas_submit.enabled()
    return jsonify({
        "enabled": on,
        "why_not": "" if on else ("handing work in is switched off — turn it on "
                                  "in Settings → Connections, under Handing work in"),
        "kinds": list(canvas_submit.SUPPORTED),
        "history": canvas_submit.history()[-10:],
    })


@api.put("/submit/switch")
def put_submit_switch():
    """Turn handing work in on or off.

    A static rule, so Werkzeug matches it ahead of `/submit/<item_id>` — the
    same precedence trap `/connections/window` hit in 0.21.1.0, which is why
    there is a test for it rather than a comment alone.
    """
    body = request.get_json(silent=True) or {}
    if "enabled" not in body:
        return _error("bad_request", "say whether to turn it on", "", 400)
    want = bool(body["enabled"])
    cfg = config.load()
    config.save({"submit": dict(cfg.get("submit") or {}, enabled=want)})
    return jsonify({"enabled": want})


@api.post("/submit/<item_id>/propose")
def post_submit_propose(item_id):
    """What would be sent, for the confirm screen. Touches no network.

    The file is one already attached to this assignment through `work.py` —
    the photos and files Check my work already stores — so there is no second
    place to put things and no second copy.
    """
    from sillybus import canvas_submit, work

    item, failed = _item_for_submit(item_id)
    if failed:
        return failed
    body = request.get_json(silent=True) or {}
    name = (body.get("page") or "").strip()
    have = work.pages(item_id)
    if not have:
        return _error("nothing_to_send",
                      "there is nothing attached to this assignment yet",
                      "add a photo or a file under Check my work first", 400)
    chosen = next((p for p in have if p["name"] == name), have[-1])
    try:
        # The type comes from the BYTES, not the name — the same sniff
        # `work.py` does on the way in, for the same reason: a file's
        # extension is not what it is.
        data, media = work.read(item_id, chosen["name"])
        proposal = canvas_submit.propose(
            item, file_name=chosen["name"], file_size=len(data),
            content_type=media,
            file_note=f"added {chosen['at'][:16].replace('T', ' ')}")
    except canvas_submit.SubmitError as exc:
        return _error("cannot_submit", exc.message, exc.fix, 400)
    except Exception as exc:  # noqa: BLE001 — work.py raises its own type
        return _error("no_file", f"that file could not be read ({exc})",
                      "add it again under Check my work", 400)
    proposal["pages"] = have
    proposal["enabled"] = canvas_submit.enabled()
    return jsonify(proposal)


@api.post("/submit/<item_id>")
def post_submit(item_id):
    """Perform a proposal the student has just seen and pressed.

    Everything that could refuse, refuses BEFORE a browser is opened: the
    switch, the proposal id, the item. Opening a browser to then say no would
    be slower and no safer.
    """
    from sillybus import browser, canvas_submit, work

    body = request.get_json(silent=True) or {}
    proposal = body.get("proposal") or {}
    if not canvas_submit.enabled():
        return _error("switched_off",
                      "handing work in from SillyBus is switched off",
                      "turn it on in Settings → Connections", 403)
    item, failed = _item_for_submit(item_id)
    if failed:
        return failed
    if (proposal.get("item_id") or "") != item_id:
        return _error("mismatch", "that proposal is for a different assignment",
                      "start the hand-in again", 400)
    try:
        data, _kind = work.read(item_id, proposal.get("file_name") or "")
    except Exception as exc:  # noqa: BLE001 — work.py raises its own type
        return _error("no_file", "that file is no longer attached",
                      "add it again and start the hand-in", 400)
    # The browser is opened only once everything that could refuse has. Its
    # close goes through `browser.close_context`, never a bare `.close()`:
    # Canvas answers ordinary requests with session-only cookies that REPLACE
    # the persistent ones, and close_context rewrites the expiry first.
    # `tests/test_session_survives_every_browser_exit.py` fails the build if a
    # bare close comes back.
    playwright = context = None
    try:
        from playwright.sync_api import sync_playwright

        playwright = sync_playwright().start()
        context = browser.open_context(playwright, headless=True)
        out = canvas_submit.submit(context, proposal, data)
    except canvas_submit.SubmitError as exc:
        canvas_submit.record({"at": None, "ok": False, "title": item.get("title"),
                              "error": exc.message})
        return _error("refused", exc.message, exc.fix, 400)
    except Exception as exc:  # noqa: BLE001 — never a stack trace on screen
        canvas_submit.record({"at": None, "ok": False, "title": item.get("title"),
                              "error": str(exc)})
        # Deliberately NOT retried, and the wording says what is unknown: a
        # request that timed out may or may not have landed, and handing the
        # same work in twice is worse than handing it in late.
        return _error("failed", f"that did not go through ({exc})",
                      "check the assignment in Canvas before trying again — "
                      "it may have gone through", 502)
    finally:
        if context is not None:
            browser.close_context(context)
        if playwright is not None:
            try:
                playwright.stop()
            except Exception:  # noqa: BLE001 — the submission already happened
                pass
    return jsonify(out)


@api.get("/courses")
def get_courses():
    """Every class on file, each flagged with whether it is running now.

    The flag is computed here rather than in the page because it needs the
    class feed: the current session is READ from the courses that actually
    have meetings this week (courses.current_sessions), never guessed from
    the month. The page still receives the others — a list that quietly drops
    a class would be exactly the silent hiding the spec forbids — and shows
    them behind one line saying how many and from when.
    """
    from sillybus import courses
    records = courses.load_all()
    live = set()
    try:
        state = pipeline.load_state() or {}
        for meetings in (state.get("schedule") or {}).values():
            for meeting in meetings or []:
                if meeting.get("course_key"):
                    live.add(meeting["course_key"])
    except Exception as exc:  # noqa: BLE001 — a missing feed is not an error here
        log.debug("no schedule to date the terms from: %s", exc)
    sessions = courses.current_sessions(records, live)
    for record in records.values():
        record["current"] = courses.is_current(record, sessions)
    return jsonify({"courses": [records[k] for k in sorted(records)],
                    "current_sessions": sorted(sessions),
                    "summaries": {k: courses.summary(r) for k, r in records.items()}})


@api.get("/courses/<course_key>")
def get_course(course_key):
    from sillybus import courses
    record = courses.load(course_key)
    if not record:
        return _error("no_such_course", f"no record for {course_key}",
                      "run Detect materials first", 404)
    return jsonify(record)


def _known_course_keys() -> set[str]:
    """Every class this install has heard of: a record, a profile, or a
    mention on the board (an item, a meeting, a grade)."""
    from sillybus import courses
    from sillybus.profiling import store
    known = set(courses.load_all())
    try:
        profiles, _ = store.load_all()
        known |= set(profiles)
    except Exception:  # noqa: BLE001 — an unreadable profile is not a class
        pass
    state = pipeline.load_state() or {}
    for item in state.get("items") or []:
        known.add(item.get("course_key"))
    for meetings in (state.get("schedule") or {}).values():
        for meeting in meetings or []:
            known.add(meeting.get("course_key"))
    for grade in state.get("grades") or []:
        known.add(grade.get("course_key"))
    known |= set(state.get("gradebook") or {})
    known.discard(None)
    return known


@api.put("/courses/<course_key>")
def put_course(course_key):
    from sillybus import courses
    patch = request.get_json(silent=True)
    if not isinstance(patch, dict):
        return _error("bad_json", "the body must be a JSON object", "", 400)
    # (prosecution round 5, 2026-10-07) A PUT to a key nobody has heard of —
    # a typo, an old link — CREATED a class, which then sat in the Classes
    # list for ever. Editing a class needs the class to exist somewhere: a
    # record, a profile, or the board itself (the grade page sets syllabus
    # weights on classes that have no materials record yet).
    if course_key not in _known_course_keys():
        return _error("no_such_course", f"there is no class called {course_key}",
                      "pick the class from the Classes list", 404)
    try:
        return jsonify(courses.update(course_key, patch))
    except ValueError as exc:      # a connector address that is not one
        return _error("bad_connector", str(exc), "paste the address from the browser's bar", 400)


# ---- the school ------------------------------------------------------------
# Other schools run Canvas and Veracross too, so the school is a setting, not a
# constant: the Canvas address, whether there is a Veracross portal and where,
# and the time zone. Setup asks for it first ("Your school"); Settings can
# change it.
#
# (prosecution round 5, 2026-10-07) What a student pastes is whatever was in
# the address bar — "https://x.instructure.com/courses?login_success=1",
# "x.instructure.com", ".../myschool/student/student/overview" — and every one
# of those used to be refused for not being the bare address, so the advice
# "copy it from the address bar" could not be followed. Addresses are now
# parsed and cut down to what the app needs. Canvas on a school's own domain
# (canvas.myschool.edu) is accepted: the app's own browser signs in anywhere;
# the Chrome extension reads *.instructure.com without asking and needs its
# optional permission for anything else.
_HOST_LABELS = re.compile(r"^(?=.{1,253}\Z)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}\Z")
_SLUG = re.compile(r"^[a-z0-9_-]{1,64}\Z", re.I)


def _https_host(value: str) -> tuple[str, list[str]]:
    """("https://host", path segments) or ValueError."""
    from urllib.parse import urlsplit
    text = value.strip()
    if ".." in text or "\\" in text or any(ch.isspace() for ch in text):
        raise ValueError("not an address")
    if "://" not in text:
        text = "https://" + text
    parts = urlsplit(text)
    if parts.scheme.lower() not in ("https", "http"):
        raise ValueError("not a web address")
    host = (parts.hostname or "").lower()
    if parts.username or parts.password or parts.port or not _HOST_LABELS.match(host):
        raise ValueError("not a plain web address")
    return f"https://{host}", [seg for seg in parts.path.split("/") if seg]


def normalise_canvas_host(value: str) -> str:
    """Scheme and host only. "" means "back to the default"."""
    if not str(value or "").strip():
        return ""
    origin, _path = _https_host(str(value))
    return origin


def normalise_veracross_portal(value: str) -> str:
    """https://<host>.veracross.com/<school>/<student|parent>; "" = no Veracross.

    Everything after the school's own slug and the portal kind is cut: the
    app adds its own paths to this (…/student/overview, the subscribe page),
    so a pasted deep link would have doubled them.
    """
    if not str(value or "").strip():
        return ""
    origin, path = _https_host(str(value))
    if not origin.endswith(".veracross.com"):
        raise ValueError("not a Veracross address")
    if not path or not _SLUG.match(path[0]) or path[0].lower() in ("student", "parent"):
        raise ValueError("no school name in the address")
    kind = path[1].lower() if len(path) > 1 and path[1].lower() in ("student", "parent") else "student"
    return f"{origin}/{path[0]}/{kind}"


def _school_reply():
    cfg = config.load()
    vx = cfg.get("veracross") or {}
    school = cfg.get("school") or {}
    return {"name": school.get("name") or "",
            "canvas_host": (cfg.get("canvas") or {}).get("host") or "",
            "veracross_portal": vx.get("portal") or "",
            "uses_veracross": config.veracross_in_use(cfg),
            # why the shipped portal is not being used, if it is not
            "veracross_held": vx.get("portal_held") or "",
            "time_zone": school.get("time_zone") or "",
            "mac_time_zone": config.mac_time_zone(),
            "confirmed": config.school_confirmed(cfg),
            "default_canvas_host": config.SHIPPED_CANVAS_HOST,
            "default_veracross_portal": config.SHIPPED_PORTAL}


@api.get("/school")
def get_school():
    return jsonify(_school_reply())


@api.put("/school")
def put_school():
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return _error("bad_json", "the body must be an object", "", 400)
    updates = {}
    if "name" in body:
        updates["school"] = {"name": str(body.get("name") or "").strip()[:80]}
    if "canvas_host" in body:
        try:
            host = normalise_canvas_host(str(body.get("canvas_host") or ""))
        except ValueError:
            return _error("bad_host", f"{str(body.get('canvas_host'))[:120]} is not a Canvas address "
                          "like https://yourschool.instructure.com",
                          "copy it from the browser's address bar after signing in", 400)
        # "" is "put the default back" — saved as the default itself, because
        # a merge-write cannot delete a key and "" used to be saved as the
        # host, making the sign-in page "/login".
        updates.setdefault("canvas", {})["host"] = host or config.SHIPPED_CANVAS_HOST
    portal_given = "veracross_portal" in body
    if body.get("uses_veracross") is False:
        updates.setdefault("veracross", {})["portal"] = ""
    elif portal_given:
        try:
            portal = normalise_veracross_portal(str(body.get("veracross_portal") or ""))
        except ValueError:
            return _error("bad_host", f"{str(body.get('veracross_portal'))[:120]} is not a Veracross "
                          "portal address like https://portals.veracross.com/yourschool/student",
                          "copy it from the browser's address bar after signing in", 400)
        if body.get("uses_veracross") is True and not portal:
            return _error("bad_host", "type your school's Veracross portal address, or untick "
                          "\"My school uses Veracross\"", "", 400)
        updates.setdefault("veracross", {})["portal"] = portal
    if "time_zone" in body:
        # (prosecution round 5, 2026-10-07) Ignored until now, so every
        # student was on Phoenix time and a Canvas deadline at 12:30 am in New
        # York landed on the day before. Only a real IANA zone name is
        # accepted — the name is handed to ZoneInfo, which reads it as a path.
        from zoneinfo import available_timezones
        zone_name = str(body.get("time_zone") or "").strip()
        if zone_name not in available_timezones():
            return _error("bad_time_zone", f"{zone_name[:60] or 'that'} is not a time zone name "
                          "like America/New_York", "pick one from the list", 400)
        updates.setdefault("school", {})["time_zone"] = zone_name
    if body.get("confirm"):
        # The "Your school" step's answer: this is the student's word that
        # these are their school's addresses (config._hold_unconfirmed_portal).
        updates.setdefault("school", {})["confirmed_at"] = \
            _now_iso()
    if updates:
        config.save(updates)
        timezones._cache.clear()
    return jsonify(_school_reply())


def _now_iso() -> str:
    from datetime import datetime
    return datetime.now(timezones.zone()).isoformat(timespec="seconds")


@api.post("/courses/<course_key>/materials")
def post_material(course_key):
    from sillybus import courses
    body = request.get_json(silent=True) or {}
    # Every field as text, and bounded (round 5, 2026-10-07: {"title": 5} was a
    # 500, and a 5,000,000-character isbn was stored as given).
    text = lambda key, cap: (str(body.get(key)) if isinstance(body.get(key), (str, int, float)) else "").strip()[:cap]
    title, url = text("title", 300), text("url", 2000)
    if not title and not url:
        return _error("bad_request", "give the link a name or a URL", "", 400)
    record = courses.add_material(course_key, title or url, url or None,
                                  kind=text("kind", 40) or "other",
                                  notes=text("notes", 4000), isbn=text("isbn", 20) or None)
    return jsonify(record)


@api.delete("/courses/<course_key>/materials/<material_id>")
def delete_material(course_key, material_id):
    from sillybus import courses
    record = courses.remove_material(course_key, material_id)
    if record is None:
        return _error("no_such_material", "that link is not on this class", "", 404)
    return jsonify(record)


@api.post("/courses/detect")
def post_courses_detect():
    """Scan Canvas (and the cached course docs) for every class's materials.
    Needs the browser session; runs as a job."""
    from sillybus import courses
    body = request.get_json(silent=True) or {}
    only = (body.get("course_key") or "").strip() or None

    def work(say):
        from playwright.sync_api import sync_playwright
        from sillybus import autologin, browser, credentials
        with sync_playwright() as pw:
            context = browser.open_context(pw, headless=True)
            try:
                if not browser.whoami(context):
                    if credentials.has("google"):
                        say("Canvas session expired — signing back in")
                        fixed = autologin.canvas(context)
                        if not fixed.ok:
                            raise RuntimeError(fixed.message)
                    else:
                        raise RuntimeError("the Canvas session is expired — sign in first")
                results = courses.detect_all(context, only=only, emit=say)
            finally:
                browser.close_context(context)
        say(f"done — {len(results)} class(es) scanned")
        return {"courses": sorted(results),
                "summaries": {k: courses.summary(r) for k, r in results.items()}}
    return jsonify(_start_job("detect", work))


@api.get("/textbooks/search")
def get_textbook_search():
    from sillybus import textbooks
    query = (request.args.get("q") or "").strip()
    if not query:
        return _error("bad_request", "type a title, author or ISBN", "", 400)
    return jsonify(textbooks.search(query))


# ---- accelerate an assignment ---------------------------------------------------

@api.get("/accelerations")
def get_accelerations():
    """Every study guide on file, newest first, as rows for the Recent list.

    A separate path from /accelerate/<item_id> on purpose: "recent" would
    otherwise be a plausible item id.
    """
    conn = db.connect()
    try:
        return jsonify({"guides": db.acceleration_recent(conn, 12)})
    finally:
        conn.close()


@api.get("/accelerate/<item_id>")
def get_accelerate(item_id):
    from sillybus import accelerate
    saved = accelerate.cached(item_id)
    if not saved:
        return _error("no_guide", "no guide has been made for this item yet",
                      "press Accelerate", 404)
    return jsonify(saved)


@api.post("/accelerate/<item_id>")
def post_accelerate(item_id):
    from sillybus import accelerate
    body = request.get_json(silent=True) or {}
    force = bool(body.get("force"))

    def work(say):
        return accelerate.generate(item_id, force=force, emit=say)
    return jsonify(_start_job(f"accelerate:{item_id}", _one_writer(work)))


# ---- what this teacher does: past quizzes and graded work -------------------
#
# [ASKED] 2026-09-28. Examples the student adds, shown to the model when it
# writes a quiz or checks work. sillybus/teacher.py says why "train" means
# examples here and not a model.


def _teacher_error(exc):
    return _error("teacher", exc.message, exc.fix, 400)


@api.get("/teacher/<course_key>")
def get_teacher(course_key):
    from sillybus import teacher
    rows = teacher.examples(course_key)
    # The list carries a preview of each text, never the whole thing — the
    # page shows a line, and the whole text is only ever read by the model.
    out = []
    for r in rows:
        row = {k: v for k, v in r.items() if k != "text"}
        row["preview"] = (r.get("text") or "")[:160]
        row["chars"] = len(r.get("text") or "")
        out.append(row)
    return jsonify({"examples": out, "summary": teacher.summary(course_key)})


@api.post("/teacher/<course_key>")
def post_teacher(course_key):
    from sillybus import teacher
    body = request.get_json(silent=True) or {}
    try:
        row = teacher.add_text(course_key, str(body.get("kind") or ""),
                               str(body.get("title") or ""), str(body.get("text") or ""),
                               grade=body.get("grade"), possible=body.get("possible"),
                               comments=str(body.get("comments") or ""),
                               assignment=str(body.get("assignment") or ""))
    except teacher.TeacherError as exc:
        return _teacher_error(exc)
    return jsonify({"ok": True, "example": row})


@api.post("/teacher/<course_key>/file")
def post_teacher_file(course_key):
    """A photo or PDF, as raw bytes (the same shape as /work/<id>). The
    metadata rides in the query string."""
    from sillybus import teacher
    data = request.get_data(cache=False)
    args = request.args
    try:
        row = teacher.add_file(course_key, args.get("kind") or "quiz",
                               args.get("title") or "", data,
                               grade=args.get("grade"), possible=args.get("possible"),
                               comments=args.get("comments") or "",
                               assignment=args.get("assignment") or "",
                               example_id=args.get("example_id") or None)
    except teacher.TeacherError as exc:
        return _teacher_error(exc)
    return jsonify({"ok": True, "example": row})


@api.get("/teacher/<course_key>/file/<name>")
def get_teacher_file(course_key, name):
    from sillybus import teacher
    try:
        path = teacher.file_path(course_key, name)
    except teacher.TeacherError as exc:
        return _error("no_file", exc.message, "", 404)
    media = {"jpg": "image/jpeg", "png": "image/png", "webp": "image/webp",
             "pdf": "application/pdf"}[path.suffix.lstrip(".")]
    return Response(path.read_bytes(), mimetype=media)


@api.delete("/teacher/<course_key>/<example_id>")
def delete_teacher(course_key, example_id):
    from sillybus import teacher
    return jsonify({"ok": teacher.remove(course_key, example_id)})


# ---- practice quizzes ---------------------------------------------------------


@api.get("/quizzes")
def get_quizzes():
    from sillybus import quizmaker
    return jsonify({"quizzes": quizmaker.recent(request.args.get("course_key") or None)})


@api.get("/quiz/<quiz_id>")
def get_quiz(quiz_id):
    from sillybus import quizmaker
    quiz = quizmaker.get(quiz_id)
    if quiz is None:
        return _error("no_quiz", "that quiz is gone", "make another", 404)
    return jsonify(quiz)


@api.post("/quiz")
def post_quiz():
    """Write a quiz. A job, like Accelerate: the same thinking-on-screen
    lines, the same allowance."""
    from sillybus import quizmaker
    body = request.get_json(silent=True) or {}
    course_key = (body.get("course_key") or "").strip()
    if not course_key:
        return _error("bad_request", "which class?", "open the class first", 400)

    try:
        count = int(body.get("count") or quizmaker.DEFAULT_COUNT)
    except (TypeError, ValueError):
        count = quizmaker.DEFAULT_COUNT
    count = max(1, min(count, 30))
    item_id = body.get("item_id") or None

    def work(say):
        try:
            return quizmaker.generate(course_key=course_key,
                                      item_id=item_id,
                                      topic=str(body.get("topic") or "")[:300],
                                      count=count, emit=say)
        except quizmaker.QuizError as exc:
            raise RuntimeError(str(exc)) from exc
    return jsonify(_start_job(f"quiz:{course_key}:{item_id or ''}", _one_writer(work)))


@api.post("/quiz/<quiz_id>/attempt")
def post_quiz_attempt(quiz_id):
    from sillybus import quizmaker
    body = request.get_json(silent=True) or {}
    answers = body.get("answers") or {}
    if isinstance(answers, list):   # round 5: a list was a 500
        answers = {str(i): a for i, a in enumerate(answers)}
    if not isinstance(answers, dict):
        return _error("bad_request", "answers must be question → choice", "", 400)
    try:
        return jsonify(quizmaker.attempt(quiz_id, answers))
    except quizmaker.QuizError as exc:
        return _error("no_quiz", str(exc), "make another", 404)


@api.delete("/quiz/<quiz_id>")
def delete_quiz(quiz_id):
    from sillybus import quizmaker
    quizmaker.delete(quiz_id)
    return jsonify({"ok": True})


@api.delete("/accelerate/<item_id>")
def delete_accelerate(item_id):
    conn = db.connect()
    db.acceleration_delete(conn, item_id)
    conn.close()
    return jsonify({"ok": True})


# ---- the Chrome bridge --------------------------------------------------------
#
# *"make it also a crome extetion that connects to the app so that it is easier
# for the AI to read it though the extention"*
#
# Pages fetched by an extension in a browser already signed in to Canvas and
# Veracross, handed to the same parsers the refresh uses. See bridge.py for why
# this is worth having at all.
#
# **These four endpoints sit OUTSIDE the account gate and inside a token
# gate.** An extension has no SillyBus AI account and cannot get one — it is a
# browser, not a person — so the account check would refuse every capture. The
# bridge token replaces it: minted by the app, shown once in Settings, pasted
# in by hand, compared in constant time. Loopback is not a permission; anything
# on this Mac can reach 127.0.0.1, so the token is the actual gate.
#
# No CORS headers anywhere, deliberately. An extension service worker holding
# `host_permissions` for 127.0.0.1 is not subject to CORS, so the app needs to
# allow nothing — and a web page therefore still cannot reach these at all,
# whatever token it guessed.


def _bridge_error(exc):
    return _error("bridge", exc.message, exc.fix, exc.status)


@api.post("/bridge/calendar")
def post_bridge_calendar():
    """The regular extension's Link this page handoff, gated by pairing."""
    import base64
    from sillybus import bridge
    from sillybus.feeds import calendars
    try:
        bridge.check_token(request.headers.get("X-SillyBus-Token"))
    except bridge.BridgeError as exc:
        return _bridge_error(exc)
    body = request.get_json(silent=True) or {}
    url = str(body.get("url") or "").strip()
    ok, why = calendars.check_url(url)
    if not ok:
        return _error("bad_url", why, "link the calendar again", 400)
    saved = config.connections()
    entry = next((c for c in saved if calendars.connection_key(c.get("url") or "")
                  == calendars.connection_key(url)), None)
    existing = entry is not None
    if body.get("refresh_only") and not existing:
        return _error("removed", "that calendar was removed from the Mac app",
                      "link it again to reconnect", 410)
    if calendars.is_google_export(url):
        encoded = body.get("export")
        try:
            if not isinstance(encoded, str) or len(encoded) > bridge.MAX_BODY - 20:
                raise ValueError()
            blob = base64.b64decode(encoded, validate=True)
            calendars._unzip_calendars(blob)
            if entry and entry.get("google_ids") and not calendars.same_google_account(
                    entry["google_ids"], calendars.google_ids(blob)):
                return _error("account_changed", "Chrome is showing a different Google account",
                              "open the originally linked Google account and link its page again", 409)
            bridge.store("url", bridge.url_key(url), "sillybus-google-zip:" + encoded, url)
        except Exception:
            # Neither the export nor its address belongs in an error response.
            return _error("bad_export", "Google did not provide a readable calendar export",
                          "sign in to Google Calendar and link that page again", 400)
    if existing:
        total = pipeline.read_calendars_now()
        return _bridge_calendar_result(entry, total)
    # Same validation, duplicate protection and immediate import as the app form.
    response = post_connection()
    if isinstance(response, tuple):
        return response
    result = response.get_json()
    entry = next((c for c in config.connections()
                  if calendars.connection_key(c.get("url") or "") == calendars.connection_key(url)), None)
    return _bridge_calendar_result(entry, result.get("events_on_board"))


def _bridge_calendar_result(entry, total):
    from sillybus.feeds import calendars
    status = next((c for c in calendars.summary().get("connections", [])
                   if entry and c.get("id") == entry.get("id")), None)
    if status and status.get("error"):
        return _error("sync_failed", status["error"], status.get("fix") or "try again", 502)
    count = status.get("events", 0) if status else None
    message = ("Calendar read successfully, but no events are in the configured date window."
               if count == 0 else f"Read {count} events from this calendar."
               if count is not None else "Calendar saved; this calendar's read count is unavailable.")
    return jsonify({"ok": True, "events_on_board": total, "calendar_events": count,
                    "sync_message": message})


@api.post("/bridge/assignments")
def post_bridge_assignments():
    """Import assignment metadata read on an explicitly linked school site."""
    from datetime import datetime, timezone
    from sillybus import bridge
    try:
        bridge.check_token(request.headers.get("X-SillyBus-Token"))
    except bridge.BridgeError as exc:
        return _bridge_error(exc)
    body = request.get_json(silent=True) or {}
    if not isinstance(body, dict):
        return _error("bad_payload", "invalid assignment payload", "link again", 400)
    source = body.get("source")
    if source not in ("apclassroom", "albert", "googleclassroom"):
        return _error("unsupported", "unsupported assignment source", "", 400)
    data = body.get("payload")
    if not isinstance(data, dict) or data.get("error"):
        return _error("read_failed", "the school site could not be read", "sign in and link again", 400)
    rows = data.get("assignments")
    if not isinstance(rows, list) or len(rows) > 5000 or any(not isinstance(row, dict) for row in rows):
        return _error("bad_payload", "invalid assignment list", "link again", 400)
    # Keep metadata only: never persist session tokens or assessment content.
    fields = {"id", "subject", "subject_id", "title", "due", "status", "url",
              "kind", "questions", "completed", "opened_at", "assigned_at",
              "assigned", "submitted", "state", "timer", "score", "max_score", "due_text"}
    record = {"read_at": datetime.now(timezone.utc).isoformat(),
              "assignments": [{k: v for k, v in row.items() if k in fields} for row in rows],
              "error": None}
    with _assignment_handoff_lock:
        if source == "googleclassroom":
            from sillybus.feeds import google_classroom
            record = google_classroom.merge_handoff(data)
        paths.cache_dir().mkdir(parents=True, exist_ok=True)
        target = paths.cache_dir() / f"{source}.json"
        # The existing feed readers merge this metadata with Canvas and teacher docs.
        import os, tempfile
        fd, name = tempfile.mkstemp(dir=target.parent, prefix=f".{source}-")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                json.dump(record, stream)
            os.replace(name, target)
        finally:
            if os.path.exists(name):
                os.unlink(name)
    refresh = post_refresh()
    response = refresh[0] if isinstance(refresh, tuple) else refresh
    return jsonify({"ok": True, "assignments_received": len(rows),
                    "refresh": response.get_json()})


@api.post("/bridge/school")
def post_bridge_school():
    """A deliberate toolbar Connect configures one supported school service."""
    from urllib.parse import urlsplit
    from sillybus import bridge
    try:
        bridge.check_token(request.headers.get("X-SillyBus-Token"))
    except bridge.BridgeError as exc:
        return _bridge_error(exc)
    body = request.get_json(silent=True) or {}
    url = str(body.get("url") or "")
    try:
        parsed = urlsplit(url)
        host = parsed.hostname or ""
        if parsed.scheme != "https" or parsed.username or parsed.password or parsed.port:
            raise ValueError()
        if host.endswith(".instructure.com") and not host.endswith(".login.instructure.com"):
            patch = {"canvas_host": normalise_canvas_host(url)}
        elif host == "portals.veracross.com":
            patch = {"veracross_portal": normalise_veracross_portal(url)}
        else:
            raise ValueError()
    except ValueError:
        return _error("unsupported", "open your Canvas or Veracross student portal first", "", 400)
    # Patch one service only; do not copy defaults over the other account.
    if "canvas_host" in patch:
        config.save({"canvas": {"host": patch["canvas_host"]}})
    else:
        config.save({"veracross": {"portal": patch["veracross_portal"]}})
    return jsonify({"ok": True, "message": "School address saved. Send your pages, then refresh the Mac app."})


@api.get("/bridge/status")
def get_bridge_status():
    """For the extension. Token required, always — this endpoint is outside
    the account gate, so nothing else stands in front of it.

    Settings does NOT call this: it reads the same figures out of
    `/api/state`, which is account-gated like the rest of the page. Two
    callers with two different gates on one endpoint is how an exemption
    written for one of them ends up covering the other.
    """
    from sillybus import bridge
    try:
        bridge.check_token(request.headers.get("X-SillyBus-Token"))
    except bridge.BridgeError as exc:
        return _bridge_error(exc)
    out = bridge.status()
    # What version of ITSELF the extension ought to be running. The app ships
    # the extension inside its own bundle, so when the app updates, the files
    # on disk change under a Chrome that is still running the old ones — and
    # an unpacked extension does not notice until somebody presses Reload.
    #
    # [MEASURED] 2026-09-23: that is exactly how a student ends up being told
    # to go to chrome://extensions to fix something they did nothing to break.
    # The extension compares this with its own manifest and reloads itself.
    try:
        out["extension_version"] = bridge.extension().get("version") or ""
    except Exception:                         # noqa: BLE001 — a nicety
        out["extension_version"] = ""
    # The list of pages to fetch travels WITH the status, so the extension
    # needs exactly one token-gated endpoint and never touches /api/state —
    # which is account-gated and would refuse a browser, correctly.
    try:
        out["wanted"] = bridge.wanted()
    except Exception as exc:  # noqa: BLE001 — an empty list is a fine answer
        out["wanted"] = []
        out["wanted_error"] = str(exc)[:160]
    return jsonify(out)


@api.get("/bridge/board")
def get_bridge_board():
    """What SillyBus knows, for the overlay on Canvas's own pages.

    *"in the chrome extetion I want it to be like better campus where it
    changes and adds the assignments and grade and other info for the class"*
    — 2026-09-23.

    Token-gated, like the other bridge endpoints and for the same reason: an
    extension is a browser, not a person, so the account gate would refuse it.

    **The payload is an allowlist, decided in `sillybus/campus.py`.** This is
    the only place the board leaves the app, and "the state with the secrets
    taken out" is the shape that goes wrong the next time a field is added.
    The route stays this short on purpose — what travels is a decision, not a
    serialisation.
    """
    from sillybus import bridge, campus, config, courses as courses_mod, pipeline
    try:
        bridge.check_token(request.headers.get("X-SillyBus-Token"))
    except bridge.BridgeError as exc:
        return _bridge_error(exc)
    try:
        state = pipeline.load_state_overlaid() or {}
    except Exception as exc:  # noqa: BLE001 — an empty board is a fine answer
        return jsonify({"error_note": str(exc)[:160], "items": [],
                        "grades": [], "open_by_course": {}})
    try:
        known = courses_mod.load_all()
    except Exception:  # noqa: BLE001
        known = {}
    host = (config.load().get("canvas") or {}).get("host") or ""
    return jsonify(campus.board(state, known, host))


@api.post("/bridge/capture")
def post_bridge_capture():
    from sillybus import bridge
    try:
        bridge.check_token(request.headers.get("X-SillyBus-Token"))
    except bridge.BridgeError as exc:
        return _bridge_error(exc)
    body = request.get_json(silent=True) or {}
    try:
        headers = body.get("headers")
        saved = bridge.store(str(body.get("kind") or ""),
                             str(body.get("key") or ""),
                             body.get("body") or "",
                             str(body.get("url") or ""),
                             headers if isinstance(headers, dict) else None)
    except bridge.BridgeError as exc:
        return _bridge_error(exc)
    return jsonify({"ok": True, "saved": saved})


@api.post("/bridge/chrome-extensions")
def post_bridge_chrome_extensions():
    """Open Chrome's own extensions page, for the one click this needs.

    [MEASURED] 2026-09-23: **Chrome refuses to follow a link to a `chrome://`
    page from an ordinary web page**, so the button that would obviously
    belong on the Mail page cannot be a link — it does nothing, every time,
    and that dead control shipped once already.

    From OUTSIDE Chrome it works: `open -a "Google Chrome" chrome://extensions`
    hands the address to the browser as a launch argument, which it accepts.
    The app is outside Chrome, so the app can do what the page cannot.

    The address is a literal. Nothing from the request reaches `open`.
    """
    import subprocess
    if sys.platform != "darwin":
        return jsonify({"ok": False,
                        "message": "open chrome://extensions yourself"})
    try:
        done = subprocess.run(
            ["open", "-a", "Google Chrome", "chrome://extensions/"],
            capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError) as exc:
        return _error("chrome_failed", f"could not open Chrome: {exc}",
                      "open chrome://extensions yourself", 500)
    if done.returncode != 0:
        # Same rule as the reveal button below: a button that lies about a
        # side effect is worse than one that does nothing.
        return _error("chrome_failed",
                      (done.stderr or "Chrome would not open").strip()[:200],
                      "open chrome://extensions yourself", 500)
    return jsonify({"ok": True})


@api.post("/bridge/reveal")
def post_bridge_reveal():
    """Open Finder on the extension folder.

    The point of the whole feature is that nobody has to handle a folder path.
    Chrome's "Load unpacked" opens a native picker, and a picker with the right
    folder already showing in Finder beside it is the difference between one
    click and a typed path. The path is computed here and never comes from the
    request — `open` is given a folder this app owns, or nothing.
    """
    from sillybus import bridge
    where = bridge.extension()
    if not where["present"]:
        return _error("no_extension",
                      "this build does not carry the Chrome extension",
                      "download it from the install page", 404)
    if sys.platform != "darwin":
        return jsonify({"ok": False, "folder": where["folder"],
                        "message": "open this folder yourself"})
    import subprocess
    # The return code is checked, and `ok` is the truth about what happened.
    # [PROSECUTION 2026-09-11, COUNT 6 — found in this same pass] the first
    # version passed `check=False` and then returned `ok: True` regardless, so
    # a failed `open` would still have turned the button into "Finder is
    # showing it" with no Finder anywhere. A button that lies about a side
    # effect is worse than one that does nothing.
    try:
        done = subprocess.run(["open", "-R", where["folder"]],
                              capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError) as exc:
        return _error("reveal_failed", f"could not open Finder: {exc}",
                      "copy the path instead", 500)
    if done.returncode != 0:
        return _error("reveal_failed",
                      (done.stderr or "Finder would not open that folder").strip()[:200],
                      "copy the path instead", 500)
    return jsonify({"ok": True, "folder": where["folder"]})


@api.post("/bridge/pair")
def post_bridge_pair():
    """Mint or re-show the pairing code. Page-side only: the extension can
    never ask for a token, it can only be given one."""
    from sillybus import bridge
    return jsonify({"ok": True, "token": bridge.token()})


@api.delete("/bridge/pair")
def delete_bridge_pair():
    from sillybus import bridge
    bridge.forget_token()
    gone = bridge.clear()
    return jsonify({"ok": True, "captures_removed": gone})


# ---- a photo of finished work, checked ----------------------------------------
#
# *"add a thing in asgnments where you can click on the assginment and take a
# photo of your assignment or uplod the assghinment had the ai will check it"*
#
# The bytes arrive as the raw request body, not multipart: the page has already
# drawn the photo onto a canvas to shrink and re-encode it, so there is one
# image and no form to parse. `sillybus/work.py` owns every path decision —
# no route here joins a caller's string onto a directory.


def _work_error(exc):
    return _error("bad_photo", exc.message, exc.fix, 400)


@api.get("/work/<item_id>")
def get_work(item_id):
    from sillybus import work
    try:
        return jsonify({"pages": work.pages(item_id),
                        "check": work.saved_check(item_id)})
    except work.WorkError as exc:
        return _work_error(exc)


@api.post("/work/<item_id>")
def post_work(item_id):
    from sillybus import work
    data = request.get_data(cache=False)
    try:
        saved = work.save(item_id, data)
    except work.WorkError as exc:
        return _work_error(exc)
    return jsonify({"ok": True, "page": saved, "pages": work.pages(item_id)})


@api.get("/work/<item_id>/photo/<name>")
def get_work_photo(item_id, name):
    from sillybus import work
    try:
        data, media = work.read(item_id, name)
    except work.WorkError as exc:
        return _error("no_photo", exc.message, exc.fix, 404)
    # Loopback only, and never cached by anything in between: it is a picture
    # of his homework with his handwriting on it.
    return Response(data, mimetype=media, headers={
        "Cache-Control": "no-store, private",
        "Content-Disposition": f"inline; filename={name}"})


@api.delete("/work/<item_id>/photo/<name>")
def delete_work_photo(item_id, name):
    from sillybus import work
    try:
        work.delete(item_id, name)
    except work.WorkError as exc:
        return _work_error(exc)
    return jsonify({"ok": True, "pages": work.pages(item_id)})


@api.delete("/work/<item_id>")
def delete_work(item_id):
    from sillybus import work
    try:
        gone = work.clear(item_id)
    except work.WorkError as exc:
        return _work_error(exc)
    return jsonify({"ok": True, "removed": gone, "pages": []})


@api.post("/work/<item_id>/check")
def post_work_check(item_id):
    """Synchronous: measured at ~7s for one page on haiku, which is a spinner
    rather than a job with progress lines."""
    from sillybus import workcheck
    result = workcheck.run(item_id)
    if not result.get("ok"):
        if result.get("allowance"):
            return _error("allowance_used", result.get("message", ""),
                          result.get("fix", ""), 429)
        return _error("check_failed", result.get("message", "the check failed"),
                      result.get("fix", ""), 502)
    return jsonify(result)


# ---- updating the app ---------------------------------------------------------
#
# *"i need an update button to pop up when there is an update to the app"*.
# GET is a cached read and never blocks a page; POST does the swap as a job so
# the progress lines land in the same strip a refresh uses; the restart hands
# the port to the new build. Nothing here runs on its own.

@api.get("/update")
def get_update():
    from sillybus import update
    force = request.args.get("force") in ("1", "true", "yes")
    try:
        return jsonify(update.status(force=force))
    except Exception as exc:  # noqa: BLE001 — an update check may never break the app
        log.warning("update status failed: %s", exc)
        return jsonify({"current": update.current_version(), "available": False,
                        "error": str(exc)[:120], "can_install": False})


@api.post("/update")
def post_update():
    from sillybus import update
    body = request.get_json(silent=True) or {}
    force = bool(body.get("force"))

    def work(say):
        return update.install(emit=say, force=force)
    return jsonify(_start_job("update", work))


@api.post("/update/restart")
def post_update_restart():
    """Start a server on the new build and stand down.

    The app window is a separate process pointed at 127.0.0.1, so it stays
    open and reconnects; the page polls /api/health until the new version
    answers.
    """
    from sillybus import update
    try:
        out = update.restart_server()
    except Exception as exc:  # noqa: BLE001
        return _error("restart_failed", f"could not start the new version: {exc}",
                      "quit SillyBus AI and open it again", 500)
    update.exit_soon(1.0)
    return jsonify(out)


# ---- chat --------------------------------------------------------------------

def _record_turn(conversation_id: str, message: str, user_meta: dict,
                 reply: dict) -> None:
    """Both halves of one turn, into its conversation. Recorded after the
    answer exists, and never allowed to break a reply that already worked.

    Text and a little metadata only — never `action`/`actions`, so reopening
    a conversation can never re-add a task, re-mark something done or
    re-apply a setting."""
    from sillybus import chat_memory
    try:
        conn = db.connect()
        try:
            if chat_memory.RE_SIGN_IN.search(message) or chat_memory.RE_SECRET.search(message):
                message = "(a message about sign-in details or a secret — not kept)"
            db.chat_message_add(conn, "user", message, user_meta,
                                conversation_id=conversation_id)
            db.chat_message_add(conn, "assistant", reply.get("answer") or "", {
                "grounded": reply.get("grounded"),
                "cited": reply.get("cited") or [],
                "provider": reply.get("provider"),
                "confidence": reply.get("confidence"),
                "mode": reply.get("mode"),
            }, conversation_id=conversation_id)
            if reply.get("session_id"):
                db.chat_session_put(conn, chat_memory.session_key(conversation_id),
                                    reply["session_id"])
        finally:
            conn.close()
    except Exception as exc:  # noqa: BLE001 — history is not worth an error
        log.warning("could not record the chat turn: %s", exc)


def _provider_session(body: dict, conversation_id: str) -> str | None:
    """Which provider session (Claude Code's --resume) this turn continues.

    A client that sends `conversation_id` — even null — gets the session the
    server kept for THAT conversation, so a New chat can never carry on a
    different conversation's session because the page still held its id. A
    client that predates conversations (no key at all) keeps the old
    behaviour: its own `session_id`.
    """
    from sillybus import chat_memory
    if "conversation_id" not in body:
        return body.get("session_id")
    if body.get("conversation_id") != conversation_id:
        return None                 # a new conversation starts with no session
    try:
        conn = db.connect()
        try:
            kept = db.chat_session_get(conn, chat_memory.session_key(conversation_id))
        finally:
            conn.close()
    except Exception:  # noqa: BLE001
        kept = None
    return kept or body.get("session_id")


@api.post("/chat")
def post_chat():
    from sillybus import chat_memory
    from sillybus.ai import chat as chat_mod
    body = request.get_json(silent=True) or {}
    message = (body.get("message") or "").strip()
    if not message:
        return _error("bad_request", "message is required", "type a question", 400)
    # Every reply names its conversation; null, a malformed id or the
    # read-only "Earlier chats" starts a new one (chat_memory.resolve_…).
    conversation_id = chat_memory.resolve_conversation_id(body.get("conversation_id"))
    # "remember …" / "forget …" / "what do you remember": read before
    # anything else, with no board and no model, so they work on a fresh
    # install with no AI (chat_memory.py).
    try:
        memory_reply = chat_memory.run(message)
    except Exception as exc:  # noqa: BLE001 — a memory bug must not break chat
        log.warning("memory reader failed: %s", exc)
        memory_reply = None
    if memory_reply is not None:
        memory_reply["conversation_id"] = conversation_id
        # A PIN the memory refused to keep must not be kept by the history
        # instead — that is replayed to the model as the conversation's turns.
        refused = memory_reply["action"].get("refused") == "sensitive"
        _record_turn(conversation_id,
                     "(a message with a PIN, card number or key — not kept)"
                     if refused else message, {}, memory_reply)
        return jsonify(memory_reply)
    # [ASKED] 2026-10-07: "make it so the chat can do anything you ask it like
    # put SillyBus in dark mode or simple mode or dashbord mode". A settings
    # request is read first — before the board is even loaded, because
    # "dark mode" needs no homework and must work on a fresh install — and
    # before the lookup and any model (ai/commands.py says why).
    settings_reply = _settings_turn(message, conversation_id)
    if settings_reply is not None:
        return jsonify(settings_reply)
    state = pipeline.load_state()
    if not state:
        return _error("no_state", "no data to chat about yet",
                      "press Refresh first", 409)
    state = _overlay_done(state)
    session_id = _provider_session(body, conversation_id)

    if body.get("stream"):
        turn_id = uuid.uuid4().hex[:12]
        _chat_turns[turn_id] = {"message": message,
                                "session_id": session_id,
                                "item_id": body.get("item_id"),
                                "conversation_id": conversation_id,
                                "state": state}
        return jsonify({"turn_id": turn_id, "conversation_id": conversation_id})

    try:
        # the action-capable turn: an answer plus (optionally) a verified
        # add-task or mark-done, in one structured call
        result = chat_mod.answer_action(message, state,
                                        session_id=session_id,
                                        item_id=body.get("item_id"),
                                        conversation_id=conversation_id)
    except Exception as exc:  # noqa: BLE001
        # Written for the person who will read it. "check the AI provider
        # (run.py health)" is addressed to a developer, and the reader is a
        # terminal-averse student — the project's own skill file says so in its
        # third paragraph. The technical detail is kept, but as detail.
        log.warning("chat failed: %s", exc)
        return _error("chat_failed",
                      "Chat could not answer just now. Your assignments, "
                      "schedule and grades on this page are unaffected — only "
                      "chat needs the AI.",
                      "Press Refresh and ask again. If it keeps happening, "
                      "show someone this: " + str(exc)[:160], 502)
    # Kept so the conversation survives a reload.
    result["conversation_id"] = conversation_id
    _record_turn(conversation_id, message, {"item_id": body.get("item_id")}, result)
    return jsonify(result)


def _settings_turn(message: str, conversation_id: str | None = None) -> dict | None:
    """The chat's reply to a settings request, or None for everything else.

    Server-side changes (Downtime, reminder times, sources) are already made
    by the time this returns; `actions` are what the page applies through the
    Settings page's own functions. Recorded in the history like any turn —
    the text only, so replaying the conversation never re-applies a change.
    """
    from sillybus.ai import commands
    try:
        out = commands.run(message)
    except Exception as exc:  # noqa: BLE001 — a reader bug must not break chat
        log.warning("settings reader failed: %s", exc)
        return None
    if out is None:
        return None
    reply = {"answer": out["answer"], "actions": out["actions"],
             "choices": out["choices"], "mode": "settings", "provider": "settings",
             "session_id": None, "action": {"intent": "settings"},
             # Nothing in a settings reply is a claim about the board, so there
             # is nothing for grounding to check; "n/a" says so honestly.
             "grounded": True, "cited": [], "violations": [], "confidence": "n/a",
             "verified": 0, "checked": []}
    if conversation_id is None:
        from sillybus import chat_memory
        conversation_id = chat_memory.new_conversation_id()
    reply["conversation_id"] = conversation_id
    _record_turn(conversation_id, message, {}, reply)
    return reply


@api.get("/chat/history")
def chat_history():
    """Previous questions and answers, oldest first.

    *"add previues chat memoreie to the chat page"* — the conversation used to
    live only in the page, so reopening the app showed an empty box even
    though every answer had been given minutes earlier.
    """
    limit = request.args.get("limit", type=int) or 60
    q = (request.args.get("q") or "").strip()[:80]
    conn = db.connect()
    try:
        return jsonify({"messages": db.chat_history(conn, min(limit, db.CHAT_HISTORY_KEEP), q),
                        "total": conn.execute("SELECT count(*) FROM chat_messages").fetchone()[0]})
    finally:
        conn.close()


@api.delete("/chat/history")
def chat_history_clear():
    conn = db.connect()
    try:
        return jsonify({"cleared": db.chat_history_clear(conn)})
    finally:
        conn.close()


@api.get("/chat/conversations")
def get_chat_conversations():
    """{conversations: [{id, title, updated_at, message_count}]}, newest
    first. Messages from before conversations existed are listed last as
    "Earlier chats" (id `db.LEGACY_CONVERSATION`), readable but not resumable."""
    conn = db.connect()
    try:
        return jsonify({"conversations": db.chat_conversations(conn)})
    finally:
        conn.close()


@api.get("/chat/conversations/<conversation_id>")
def get_chat_conversation(conversation_id):
    """{conversation: {id, title, updated_at, message_count}, messages: [{at,
    role, text, meta, conversation_id}]}, messages oldest first. Text only:
    an old turn's action is never sent back to be applied again."""
    conn = db.connect()
    try:
        found = db.chat_conversation(conn, conversation_id[:64])
    finally:
        conn.close()
    if found is None:
        return _error("no_such_conversation", "that conversation is not saved here",
                      "start a new chat", 404)
    return jsonify(found)


@api.get("/chat/memory")
def get_chat_memory():
    """{memories: [{id, text, created_at}]}, oldest first."""
    conn = db.connect()
    try:
        return jsonify({"memories": db.chat_memories(conn)})
    finally:
        conn.close()


@api.delete("/chat/memory/<int:memory_id>")
def delete_chat_memory(memory_id):
    conn = db.connect()
    try:
        if not db.chat_memory_delete(conn, [memory_id]):
            return _error("no_such_memory", f"there is no memory #{memory_id}",
                          "reload the list of memories", 404)
        return jsonify({"deleted": memory_id, "memories": db.chat_memories(conn)})
    finally:
        conn.close()


@api.delete("/chat/memory")
def clear_chat_memory():
    conn = db.connect()
    try:
        return jsonify({"cleared": db.chat_memory_clear(conn), "memories": []})
    finally:
        conn.close()


@api.get("/chat/payload")
def chat_payload():
    """'Show what it was given' — the exact grounded payload, no secrets in it."""
    from sillybus.ai import chat as chat_mod
    state = pipeline.load_state()
    if not state:
        return _error("no_state", "no data yet", "press Refresh first", 409)
    state = _overlay_done(state)
    from sillybus import chat_memory
    payload = chat_mod.build_payload(state, request.args.get("item_id"))
    # The memories and resumed turns travel with every model question, so
    # "what it was given" includes them.
    raw = request.args.get("conversation_id") or ""
    context = chat_memory.model_context(
        raw if chat_memory.CONVERSATION_ID.match(raw) else None)
    return jsonify({"payload": f"{payload}\n\n{context}" if context else payload})


@api.get("/chat/<turn_id>/stream")
def chat_stream(turn_id):
    from sillybus.ai import chat as chat_mod
    turn = _chat_turns.pop(turn_id, None)
    if not turn:
        return _error("no_such_turn", f"unknown turn {turn_id}",
                      "POST /api/chat with stream:true first", 404)

    conversation_id = turn.get("conversation_id")

    def stream():
        text = ""
        try:
            for event in chat_mod.answer_streaming(
                    turn["message"], turn["state"],
                    session_id=turn.get("session_id"),
                    item_id=turn.get("item_id"),
                    conversation_id=conversation_id):
                if event.get("type") == "text":
                    text += event.get("text") or ""
                elif event.get("type") == "grounding" and conversation_id:
                    # The finished turn, recorded like a non-streamed one.
                    event = {**event, "conversation_id": conversation_id}
                    _record_turn(conversation_id, turn["message"],
                                 {"item_id": turn.get("item_id")},
                                 {**event, "answer": text})
                yield f"data: {json.dumps(event)}\n\n"
        except Exception as exc:  # noqa: BLE001
            yield f'data: {json.dumps({"type": "error", "message": str(exc)})}\n\n'

    return Response(stream(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-store"})
