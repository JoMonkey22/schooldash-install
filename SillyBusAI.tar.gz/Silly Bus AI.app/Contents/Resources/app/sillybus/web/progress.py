"""Live progress lines, pushed out of the process while a job is still running.

The Mac app does not need this: `_start_job` runs the work on a real thread
and the page polls `/api/jobs/<id>` every 1.5 s, so a progress line reaches
the screen while the work is still going.

Inside the Chrome extension there are no threads. `extension/py/boot.py`
patches `Thread.start` to run the target immediately, so POST
/api/accelerate/<id> does not answer until the whole guide is written — and
the page cannot poll in the meantime, because the same worker is busy doing
the writing. Every progress line therefore arrived at once, after the fact,
behind a spinner that had been still for a minute and a half.

[ASKED] 2026-09-20: "i want it to show thinking while an accelerate is being
made". So a job's lines are also handed to a sink the host may install. In
the extension that sink posts each line out of the worker (postMessage is not
blocked by the synchronous work), bridge.js turns it into an `sd-progress`
event, and the dashboard draws it as it arrives. When nobody installs a sink
this module costs one `if`.
"""

import logging

log = logging.getLogger(__name__)

_sink = None


def set_sink(fn) -> None:
    """Install (or clear, with None) the callback that receives every line."""
    global _sink
    _sink = fn


def emit(kind: str, job_id: str, line: str, done: bool = False,
         ok: bool | None = None) -> None:
    """Hand one progress line to the sink. A sink that raises is dropped from
    the path rather than allowed to kill the job it is only reporting on."""
    if _sink is None:
        return
    try:
        _sink(kind, job_id, line, done, ok)
    except Exception:  # noqa: BLE001 — reporting must never break the work
        log.exception("progress sink failed; disconnecting it")
        set_sink(None)
