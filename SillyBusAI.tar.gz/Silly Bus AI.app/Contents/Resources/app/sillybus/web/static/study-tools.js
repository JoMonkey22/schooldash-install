/* Planner work dates, personal deadlines and measured effort share API state. */
(() => {
  const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  async function api(path, method = "GET", body) {
    const response = await fetch(path, {method, headers:{"Content-Type":"application/json"}, ...(body ? {body:JSON.stringify(body)} : {})});
    const out = await response.json();
    if (!response.ok) throw new Error(out.error?.message || "Could not save. Try again.");
    return out;
  }
  let budget = 60;
  try { budget = Number(localStorage.getItem("sillybus-study-budget")) || 60; } catch (_) {}
  window.renderStudyWeek = function () {
    const host = document.getElementById("study-week-host");
    if (!host) return;
    host.innerHTML = `<details class="study-tools"><summary>Week and catch-up</summary>
      <p>See busy days, work ahead, or rebuild your plan after missing a day. Work dates never change deadlines.</p>
      <label>Minutes available each day <input data-budget type="number" min="15" max="360" step="1" value="${budget}"></label>
      <div class="study-actions"><button type="button" data-week>Show my week</button><button type="button" data-recovery>I missed a day · preview catch-up</button></div>
      <div data-study-result aria-live="polite"></div></details>`;
    const result = host.querySelector("[data-study-result]");
    async function show(recovery, save = false) {
      budget = Number(host.querySelector("[data-budget]").value);
      if (!Number.isInteger(budget) || budget < 15 || budget > 360) {result.textContent="Choose 15–360 whole minutes per day.";return;}
      try { localStorage.setItem("sillybus-study-budget", String(budget)); } catch (_) {}
      result.textContent = "Building your plan…";
      try {
        const plan = await api(recovery ? "/api/study/recovery" : `/api/study/week?minutes=${budget}`, recovery ? "POST" : "GET", recovery ? {minutes:budget, save} : null);
        if (!host.isConnected) return;
        if (save && typeof STATE !== "undefined" && STATE?.items) {
          for (const item of STATE.items) item.work_plan = plan.days.flatMap(day => day.blocks.filter(block => block.item_id === item.item_id).map(block => ({item_id:item.item_id,work_date:day.date,minutes:block.minutes})));
        }
        result.innerHTML = `<p>${esc(plan.note)}</p>${save ? '<p role="status">Work dates saved. Deadlines unchanged.</p>' : ''}
          <div class="study-week">${plan.days.map(day => `<article class="study-day ${day.busy ? 'busy' : ''}"><h4>${esc(new Date(day.date + "T12:00:00").toLocaleDateString(undefined,{weekday:"short",month:"short",day:"numeric"}))}</h4>
          <p>${day.deadline_minutes}m due · ${day.planned_minutes}/${day.capacity}m planned</p>
          ${day.busy ? '<b>Busy deadline day</b>' : ''}
          ${day.blocks.map(block => `<p><button type="button" data-open="${esc(block.item_id)}">${esc(block.title)}</button> · ${block.minutes}m
          ${block.after_deadline ? '<strong>After deadline — ask your teacher</strong>' : block.deadline && block.date < block.deadline ? '<span>Work ahead</span>' : ''}</p>`).join('')}
          ${day.free_minutes ? `<p>${day.free_minutes}m left in your budget</p>` : ''}</article>`).join('')}</div>
          ${plan.undated_items.length ? `<p>${plan.undated_items.length} assignments have uncertain/no deadlines. Check their sources before relying on the plan.</p>` : ''}
          ${plan.unscheduled.length ? `<p role="status">Does not fit: ${plan.unscheduled.map(i => `${esc(i.title)} (${i.minutes}m)`).join(', ')}. Increase the daily budget or prioritize with your teacher.</p>` : ''}
          ${recovery && !save ? '<button type="button" data-save-plan>Save these work dates</button>' : ''}`;
        result.querySelector("[data-save-plan]")?.addEventListener("click", () => show(true,true));
      } catch (error) { result.textContent = error.message; }
    }
    host.querySelector("[data-week]").onclick = () => show(false);
    host.querySelector("[data-recovery]").onclick = () => show(true);
  };
  window.renderStudyDetail = function (item) {
    const host = document.getElementById("study-detail-host");
    if (!host) return;
    const path = `/api/study/items/${encodeURIComponent(item.item_id)}`;
    host.innerHTML = `<details id="assignment-planning" class="study-tools"><summary>Dates, time and progress</summary>
      <p>Assigned/published: ${esc(item.assigned_date || 'not stated')}. Imported due date: ${esc(item.school_due_date || 'not stated')}.</p>
      <label>Due date in your planner <input data-personal-date type="date" value="${esc(item.due_date || '')}"></label>
      <button type="button" data-save-date>Save due date</button>
      <button type="button" data-check-date>Check date with AI</button>
      <p>${item.manual_due_date ? 'Your manual correction is protected from AI suggestions.' : 'AI checks are suggestions, with source evidence; nothing is changed automatically.'} Source access and your configured provider are required.</p>
      <p>Estimated ${esc(item.est_minutes || '?')} minutes · ${esc(item.est_basis || 'category estimate')}${item.est_samples ? ` (${item.est_samples} completed tasks)` : ''}.</p>
      <p>Recorded work: ${esc(item.actual_minutes || 0)} minutes. ${item.work_started ? 'Timer running; it continues until you stop it.' : ''}</p>
      <div class="study-actions"><button type="button" data-timer>${item.work_started ? 'Stop timer & save work' : 'Start work timer'}</button>
      <label>Actual minutes <input data-actual type="number" min="1" max="720" value="${item.actual_minutes || ''}"></label><button type="button" data-save-effort>Save actual time</button></div>
      <p>Estimates learn from your recorded time only after you mark an assignment done. Timers measure elapsed time; use actual minutes to correct breaks.</p>
      ${item.work_plan?.length ? `<p>Saved work dates: ${item.work_plan.map(b => `${esc(b.work_date)} · ${b.minutes}m`).join('; ')}</p>` : ''}
      <div data-study-checklists></div><div data-study-note role="status" aria-live="polite"></div><div data-deadline-result></div></details>`;
    const note = host.querySelector("[data-study-note]");
    async function change(suffix, method, body) {
      try {
        await api(path + suffix, method, body);
        note.textContent = "Saved.";
        if (typeof loadState === "function") await loadState();
      } catch (error) { note.textContent = error.message; }
    }
    host.querySelector("[data-timer]").onclick = () => change('/effort','POST',{action:item.work_started ? 'stop' : 'start'});
    host.querySelector("[data-save-effort]").onclick = () => change('/effort','POST',{minutes:Number(host.querySelector('[data-actual]').value)});
    host.querySelector("[data-save-date]").onclick = () => change('/date','PUT',{date:host.querySelector('[data-personal-date]').value});
    const checklistHost = host.querySelector("[data-study-checklists]");
    async function checklist(body) {
      try {
        const out = await api(path + '/checklists',body ? 'PUT' : 'GET',body);
        if (!host.isConnected) return;
        const step = (entry, group) => `<label style="display:block"><input type="checkbox" data-check-step="${esc(entry.key)}" ${entry.checked ? 'checked' : ''}>${esc(entry.label)}${group === 'submission' ? ' · your report' : ''}</label>`;
        checklistHost.innerHTML = `${out.is_test ? `<h4>Test preparation</h4><p>Suggested starting budget: ${out.prep_minutes} minutes. ${esc(out.preference.basis)}.</p>
          <label>My class preference <select data-prep-level>${['lighter','standard','more'].map(level => `<option value="${level}" ${out.preference.level === level ? 'selected' : ''}>${level}</option>`).join('')}</select></label>
          <label>My experience <input data-prep-note value="${esc(out.preference.student_note)}" maxlength="1000"></label><button type="button" data-save-prep>Save preference</button>
          ${out.prep.map(entry => step(entry,'prep')).join('')}
          <button type="button" data-ai-prep>Suggest preparation with my AI</button><div data-prep-result></div>` : ''}
          <h4>Submission checklist</h4><p>Finished in SillyBus: ${out.finished ? 'yes' : 'not yet'}. Marking done does not upload work.</p>
          ${out.submission.map(entry => step(entry,'submission')).join('')}
          <p><b>${esc(out.evidence)}</b>. Personal checkmarks do not prove LMS submission.</p>`;
        checklistHost.querySelectorAll('[data-check-step]').forEach(box => box.onchange=()=>checklist({step:box.dataset.checkStep,checked:box.checked}));
        checklistHost.querySelector('[data-save-prep]')?.addEventListener('click',()=>checklist({level:checklistHost.querySelector('[data-prep-level]').value,note:checklistHost.querySelector('[data-prep-note]').value}));
        checklistHost.querySelector('[data-ai-prep]')?.addEventListener('click',async event=>{
          const result=checklistHost.querySelector('[data-prep-result]');event.target.disabled=true;result.textContent='Asking your configured AI…';
          try {const prep=await api(path+'/prep-review','POST',{});result.innerHTML=`<p>${prep.minutes} minute suggestion · ${esc(prep.basis)}</p><p>${esc(prep.suggestion)}</p><ul>${prep.minimum_steps.map(text=>`<li>${esc(text)}</li>`).join('')}</ul>`;}
          catch(error){result.textContent=error.message;}finally{event.target.disabled=false;}
        });
      } catch(error) {note.textContent=error.message;}
    }
    checklist();
    const check = host.querySelector("[data-check-date]");
    check.onclick = async () => {
      check.disabled = true; note.textContent = "Reading the assignment and asking your configured AI…";
      try {
        const out = await api(path + '/deadline-check','POST',{});
        if (!host.isConnected) return;
        note.textContent = out.message;
        const result = host.querySelector('[data-deadline-result]');
        result.innerHTML = out.proposal ? `<p>Suggested due date: <b>${esc(out.proposal.due_date)}</b> · ${esc(out.proposal.interpretation)}</p>
          <blockquote>${esc(out.proposal.quote)}</blockquote><p>Source: ${esc(out.proposal.source_label)} ${/^https?:\/\//.test(out.proposal.source_url) ? `<a target="_blank" rel="noopener" href="${esc(out.proposal.source_url)}">Open source</a>` : ''}</p>
          ${out.manual_correction ? '<p>Your manual date stays in place.</p>' : '<button type="button" data-apply-ai>Use this date in my planner</button>'}` : '';
        if (out.missing?.length) result.insertAdjacentHTML('beforeend',`<p>Could not read: ${out.missing.map(esc).join('; ')}</p>`);
        result.querySelector('[data-apply-ai]')?.addEventListener('click',()=>change('/date','PUT',{date:out.proposal.due_date,ai_proposal:true}));
      } catch(error) {note.textContent=error.message;} finally {check.disabled=false;}
    };
  };
})();
