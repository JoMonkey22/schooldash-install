'use strict';
// A separate browser-local workspace copy. All real-board requests are GETs.
const workspaceFetch=(path,options)=>window.parent.fetch(path,options);
const originalChooseVersion=chooseWorkspaceVersion;
chooseWorkspaceVersion=function(version){if(version==='classic'){if(window.parent!==window)window.parent.postMessage({type:'sillybus-classic-version'},location.origin);else location.href=typeof chrome!=='undefined'&&chrome.runtime?.getURL?chrome.runtime.getURL('index.html'):'/';return;}originalChooseVersion(version);};
importLive=async function(){try{const response=await workspaceFetch('/api/state');const payload=await response.json();if(!response.ok)throw Error('Saved board unavailable');const merged=mergeSavedBoardCopies(state,payload,id);state.tasks=merged.tasks;state.importAudit=merged.audit;state.grades=payload.grades||[];state.gradebook=payload.gradebook||{};state.mode='imported';state.importedAt=merged.audit.copiedAt;consolidateCopiedClasses();persist();closeOverlay();navigate('home');toast('Saved board copied. Workspace edits stay separate.');}catch(error){toast(error.message);}};
askAI=async function(message,context=currentChatContext(message)){
 const task=context.kind==='assignment'?state.tasks.find(t=>t.id===context.id):null;
 state.liveChatHistoryByContext ||= {};
 const scope=context.kind+':'+(task?.importId||context.id||context.course||context.title||'home');
 const history=state.liveChatHistoryByContext[scope]||[];
 const response=await workspaceFetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message,read_only:true,item_id:task?.importId||null,workspace_context:context,workspace_history:history.slice(-6)})});
 const result=await response.json();if(!response.ok||result.error)throw Error(result.error?.message||'AI could not answer just now.');
 const text=(result.answer||'No answer was returned.')+(result.grounded===false?'\n\nCheck the original source: this answer did not pass the assignment grounding check.':'');
 state.liveChatHistoryByContext[scope]=[...history,{role:'user',text:message},{role:'assistant',text}].slice(-6);persist();
 return {text,provider:result.provider||'SillyBus AI'};
};
if(state.mode==='sample')importLive();

const workspaceSettingsWithTools=settings;
settings=function(){workspaceSettingsWithTools();$('.modal-actions').insertAdjacentHTML('beforebegin',`<section><h3>All SillyBus tools</h3><p>Open the full current interface for these tools. Your workspace stays saved.</p><div class="button-row">${[['chat','Chat, voice & history'],['grades','Grades'],['calendar','Calendar'],['connections','Connections'],['focus','Focus'],['classes','Class settings'],['reminders','Desktop reminders']].map(([key,label])=>`<button class="text-button outline" data-live-tool="${key}">${label}</button>`).join('')}</div></section>`);};
document.addEventListener('click',event=>{const tool=event.target.closest('[data-live-tool]')?.dataset.liveTool;if(!tool)return;if(window.parent!==window)window.parent.postMessage({type:'sillybus-open-tool',tool},location.origin);else chooseWorkspaceVersion('classic');});
