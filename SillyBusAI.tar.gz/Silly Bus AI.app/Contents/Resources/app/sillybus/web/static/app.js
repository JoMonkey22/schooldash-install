/* SillyBus AI client — the board. Two modes, one file:
   - local (Flask): live /api/state, chat with actions, Refresh with SSE
   - remote (published snapshot): window.SNAPSHOT embedded, read-only —
     ticks are kept in this browser only and say so.

   0.18: one screen. Left — grades, focus, calendar. Centre — a pane: the
   conversation by default, or whatever was clicked on a side. Right —
   assignments, tests & quizzes, personal work. The chat input is docked under
   the centre pane and never leaves. views.js adds the panes that need a
   server (classes, settings, setup, the study guide, the grade page). */
"use strict";

const $ = (sel) => document.querySelector(sel);
const REMOTE = typeof window.SNAPSHOT === "object" && window.SNAPSHOT !== null;
const REDUCED = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
let STATE = null;
let CHAT_SESSION = null;
let CHAT_CONVERSATION = null;
let CHAT_CONVERSATIONS = [];
let CHAT_MEMORY = [];
let CHAT_MEMORY_OPEN = false;
let CHAT_BUSY = false;
let SELECTED = null;
let SELECTED_CLASS = null;
let SCHED_OFFSET = 0;
let CAL_MODE = "day";
let PANE = "chat";
// The build this page loaded with. Captured once, then compared on every poll:
// a tab left open across an update keeps rendering its original JS.
let APP_VERSION_SEEN = null;

/* Escape for HTML — including quotes, which is the whole point.
   [PROVEN] tests/test_prosecution.py: this used to set textContent on a
   throw-away <div> and read back innerHTML, which escapes & < > and leaves "
   and ' untouched. That is correct for element content and wrong for an
   attribute, and dozens of attributes across this file and views.js
   interpolate it: href, src, title, value, data-id. Every one of those values
   comes from outside — a teacher's Google Doc, a Canvas page, a book
   catalogue. Escaping all five is safe in element content too. */
const HTML_ESCAPES = { "&": "&amp;", "<": "&lt;", ">": "&gt;",
                       '"': "&quot;", "'": "&#39;" };
function esc(text) {
  return text == null ? "" : String(text).replace(/[&<>"']/g,
                                                  (ch) => HTML_ESCAPES[ch]);
}
/* [MEASURED] 2026-09-02: on a brand-new install `/api/state` carries no
   `today` at all, so isoPlus(null, 1) built an Invalid Date and toISOString()
   threw inside render(). The browser's own date is the honest fallback.
   Local, not UTC: toISOString() would roll over to tomorrow for anyone west of
   Greenwich after their afternoon. */
function localIso() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`
       + `-${String(d.getDate()).padStart(2, "0")}`;
}
function todayIso() { return (STATE && STATE.today) || localIso(); }
/* The calendar's "today" is the real date, not the last refresh's: before the
   day's first refresh the page opened on yesterday, highlighted it, and drew
   the red now-line in yesterday's column (prosecution 2026-10-06). */
function calToday() { return localIso(); }
function isoPlus(iso, days) {
  const d = new Date((iso || localIso()) + "T12:00:00");
  if (Number.isNaN(d.getTime())) return localIso();
  d.setDate(d.getDate() + days);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`
       + `-${String(d.getDate()).padStart(2, "0")}`;
}
function niceDate(iso, withYear) {
  if (!iso) return "no date";
  const d = new Date(iso + "T12:00:00");
  return d.toLocaleDateString(undefined, { weekday: "short", month: "short",
    day: "numeric", ...(withYear ? { year: "numeric" } : {}) });
}
/* What a row says about coming round again, and about looking doubled.
   Both are sentences the student can judge for themselves, which is the
   point: neither one has removed, re-dated or re-scored anything, and a
   label they cannot check is a label they stop reading. */
function repeatLineHtml(item) {
  const r = item.repeat;
  if (!r) return "";
  const which = r.which ? ` — ${r.which}` : "";
  const expected = r.expected
    ? ` <span class="kv">Canvas gives this one no date; ${esc(r.expected_note || "")}, so the next would be ${esc(niceDate(r.expected))}. That is not a deadline anyone set.</span>`
    : "";
  return `<div class="note-line repeat-line">\u21BB ${esc(r.says)}${esc(which)}${expected}</div>`;
}
function dupLineHtml(item) {
  if (!(item.flags || []).includes("looks_repeated")) return "";
  return `<div class="note-line dup-line">2\u00D7 this looks like the same work
    listed twice, from two different sources. Nothing has been removed — check
    both rows and tick the one you do not need.</div>`;
}
/* Set on one day, due on another — said as two dates when the source knows
   both and they differ. [ASKED] 2026-09-28: "when something is assigned
   verses when it is due". A one-day gap is still shown: the difference
   between "posted Monday, due Tuesday" and "due Monday" is the whole
   evening. */
function assignedLineHtml(item) {
  if (!item.assigned_date || !item.due_date || item.assigned_date === item.due_date) return "";
  const gap = daysUntil(item.due_date, item.assigned_date);
  return `<div class="kv assigned-line">set ${esc(niceDate(item.assigned_date))} \u00B7 due ${esc(niceDate(item.due_date))}${
    gap > 0 ? ` \u00B7 ${gap} day${gap === 1 ? "" : "s"} to do it` : ""}</div>`;
}
function dueLabel(item) {
  if (!item.due_date) return "undated";
  let label = niceDate(item.due_date);
  if (item.due && !item.all_day) {
    const t = item.due.slice(11, 16);
    if (t && t !== "23:59") label += " " + t;
  }
  return label;
}
function daysUntil(iso, today) {
  if (!iso) return null;
  const a = new Date(iso + "T12:00:00");
  const b = new Date(today + "T12:00:00");
  if (Number.isNaN(a) || Number.isNaN(b)) return null;
  return Math.round((a - b) / 86400000);
}
/* "in 3 days", "tomorrow", "today", "2 days ago" — the same words everywhere. */
function relDays(iso, today) {
  const n = daysUntil(iso, today);
  if (n === null) return "no date";
  if (n === 0) return "today";
  if (n === 1) return "tomorrow";
  if (n === -1) return "yesterday";
  if (n < 0) return `${-n} days ago`;
  return `in ${n} days`;
}
function minutesLabel(minutes) {
  minutes = Math.round(minutes / 5) * 5;
  if (minutes <= 0) return "";
  if (minutes < 60) return `~${minutes}m`;
  const h = Math.floor(minutes / 60), m = minutes % 60;
  return m ? `~${h}h ${m}m` : `~${h}h`;
}
/* Data kept from an earlier refresh, because the source could not be read
   this time. One sentence, shared by every panel that can show carried data. */
function staleNoteHtml(stale, fallbackReason) {
  if (!stale) return "";
  const day = (stale.as_of || "").slice(0, 10);
  const when = day ? niceDate(day) : "an earlier refresh";
  const why = stale.reason || fallbackReason;
  return `<div class="stale-note" title="${esc(`Kept from ${when}: ${why}. Press Refresh to try again.`)}">`
       + `from ${esc(when)} — ${esc(why)}</div>`;
}

function shortCourse(name) {
  return (name || "").split("-")[0].replace("Advanced Placement", "AP").trim();
}
/* Shorter still, for a row's sub-line: the part before a colon, and never
   more than two words past 18 characters. "AI Frontiers: Applications &
   Innovation" took three lines of a 296px column as a chip. */
function nick(name) {
  let short = shortCourse(name).split(":")[0].trim();
  if (short.length > 18) short = short.split(/\s+/).slice(0, 2).join(" ");
  return short;
}
/* A stable colour per class, from its key, so the same class is the same
   colour on a row, a meeting and a grade bar. Hue only — the lightness comes
   from the theme, so it reads on paper and in the dark. */
function classColor(key) {
  /* his own colour for this class wins; the hash below is the fallback */
  const own = (typeof UI !== "undefined" && UI && UI.colors) ? UI.colors[key] : "";
  if (own) return own;
  let h = 0;
  for (const ch of String(key || "")) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return `hsl(${h % 360} 55% 52%)`;
}
function classStyle(key) { return `style="--class-color: ${esc(classColor(key))}"`; }

/* ---------------- preferences ----------------
   Appearance and layout, kept on this Mac. The inline script in the page head
   applies the same keys before first paint; this is the copy that runs when
   something changes while the page is open. */
const PREF_DEFAULTS = {
  theme: "system", accent: "#2563EB", font: "modern", density: "normal",
  textSize: 14, motion: "on", gradeSort: "low", calendar: "day", assignSort: "smart",
  showWeekends: false, leftWidth: 248, rightWidth: 296, hideLeft: false, hideRight: false,
  /* layout is deliberately NOT defaulted: undefined means "never chosen",
     which is what makes the chooser appear once instead of every run. */
  layout: undefined, tab: "todo",
};
let PREFS = { ...PREF_DEFAULTS };
// Until 0.19.0.0 the keys were "schooldash.*". Copy each one over once so a
// theme, open classes and panel layout survive the rename; the old keys are
// left in place, since nothing reads them.
(function migratePrefKeys() {
  try {
    for (const k of ["prefs", "theme", "update.dismissed", "classes", "panels"]) {
      const old = localStorage.getItem("schooldash." + k);
      if (old !== null && localStorage.getItem("sillybus." + k) === null) localStorage.setItem("sillybus." + k, old);
    }
  } catch (e) { /* private mode */ }
})();
function loadPrefs() {
  try {
    const stored = JSON.parse(localStorage.getItem("sillybus.prefs")) || {};
    PREFS = { ...PREF_DEFAULTS, ...stored };
    if (!stored.theme) {
      const old = localStorage.getItem("sillybus.theme");
      if (old === "dark" || old === "light") PREFS.theme = old;
    }
  } catch (e) { PREFS = { ...PREF_DEFAULTS }; }
  return PREFS;
}
function savePrefs(patch) {
  Object.assign(PREFS, patch || {});
  try { localStorage.setItem("sillybus.prefs", JSON.stringify(PREFS)); } catch (e) { /* private mode */ }
  applyPrefs();
}
/* Black or white text on the accent, by luminance — the one derived colour
   CSS color-mix cannot decide on its own. */
function onColor(hex) {
  const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex || "");
  if (!m) return "#FFFFFF";
  const [r, g, b] = [m[1], m[2], m[3]].map((x) => parseInt(x, 16) / 255)
    .map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4));
  const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  return lum > 0.45 ? "#14192B" : "#FFFFFF";
}
function applyPrefs() {
  const root = document.documentElement;
  const theme = PREFS.theme;
  if (theme === "dark" || theme === "light" || theme === "offwhite") root.setAttribute("data-theme", theme);
  else root.removeAttribute("data-theme");
  const meta = document.querySelector('meta[name="color-scheme"]');
  if (meta) meta.content = theme === "dark" ? "dark" : theme === "system" ? "light dark" : "light";
  if (PREFS.font && PREFS.font !== "modern") root.setAttribute("data-font", PREFS.font);
  else root.removeAttribute("data-font");
  if (PREFS.density && PREFS.density !== "normal") root.setAttribute("data-density", PREFS.density);
  else root.removeAttribute("data-density");
  root.style.setProperty("--text-size", `${Number(PREFS.textSize) || 14}px`);
  if (/^#[0-9a-fA-F]{6}$/.test(PREFS.accent || "")) {
    root.style.setProperty("--accent", PREFS.accent);
    root.style.setProperty("--on-brand", onColor(PREFS.accent));
  } else {
    root.style.removeProperty("--accent");
    root.style.removeProperty("--on-brand");
  }
  if (PREFS.motion === "off") root.setAttribute("data-motion", "off");
  else root.removeAttribute("data-motion");
  root.style.setProperty("--left-w", `${Math.max(180, Math.min(440, Number(PREFS.leftWidth) || 248))}px`);
  root.style.setProperty("--right-w", `${Math.max(200, Math.min(480, Number(PREFS.rightWidth) || 296))}px`);
  root.classList.toggle("hide-left", !!PREFS.hideLeft);
  root.classList.toggle("hide-right", !!PREFS.hideRight);
  const tc = document.querySelector('meta[name="theme-color"]');
  if (tc && PREFS.accent) tc.content = PREFS.accent;
  applyLayout();
}

/* ---------------- the two layouts ----------------
   *"make 2 versions of the app, you would pick witch one in start … a
   simpler looking more tabs and less info on one screen at one time"*

   `dash` is the 0.18 board. `simple` shows one page at a time behind a tab
   strip. The panels are NOT rebuilt for it: the same boxes are shown one at a
   time, so every renderer serves both and the two can never disagree about
   the data. See the LAYOUT block in app.css. */
/* FIVE pages, named for what he would be looking for, not for the buckets the
   data happens to sit in. The first cut had nine and he was right that it was
   not simple. Two things were actually wrong, not just crowded:

   1. **"Today" and "Tests" showed the same items.** sections() puts every
      assessment in `tomorrow`/`later` AND in `upcoming` — the Tests strip
      exists to NAME what is coming without repeating the row. As two tabs
      that became the same test on two pages with nothing to say which was
      real. So there is no Tests page: To do holds every piece of work,
      homework and tests together, already sectioned OVERDUE / TODAY /
      TOMORROW, which is the order he would read them in anyway.
   2. **Settings sat next to his homework** as an equal, and Personal had
      nothing in it. Rare things do not belong in the same row as the reason
      the app exists; they are behind More, which is one obvious tap.

   `hidden: true` keeps a page out of the strip while still making it a real
   page — same showTab, same back behaviour, one list driving all of it. */
const SIMPLE_TABS = [
  { key: "todo", label: "To do", icon: "\u{1F4CB}",
    parts: [{ col: "#col-right", panel: "tomorrow" }] },
  { key: "grades", label: "Grades", icon: "\u{1F4CA}",
    parts: [{ col: "#col-left", panel: "grades" }] },
  /* The one page with two boxes, because he asked for it: *"make the calendar
     look like a calendar and on the right side have the assignments that are
     due today or tomorrow"*. `aside: true` puts the second one beside the
     first rather than under it. */
  { key: "calendar", label: "Calendar", icon: "\u{1F4C5}",
    parts: [{ col: "#col-left", panel: "schedule" },
            { col: "#col-right", panel: "duesoon", aside: true }] },
  { key: "chat", label: "Chat", icon: "\u{1F4AC}",
    parts: [{ col: "#col-center", pane: "chat" }] },
  { key: "more", label: "More", icon: "\u22EF",
    parts: [{ col: "#col-center", pane: "more" }] },
  // Reached from More. Real pages, just not in the strip.
  { key: "classes", label: "Classes", icon: "\u{1F4DA}", hidden: true,
    blurb: "Textbooks, syllabi and the documents your teachers post work in",
    parts: [{ col: "#col-center", pane: "classes" }] },
  { key: "personal", label: "Personal", icon: "\u{1F3AF}", hidden: true,
    blurb: "Goals, practices, club things and makeup work \u2014 whatever is not homework",
    parts: [{ col: "#col-right", panel: "personal" }] },
  { key: "done", label: "Done", icon: "\u2714\uFE0F", hidden: true,
    blurb: "Everything you have handed in or ticked off",
    parts: [{ col: "#col-center", pane: "done" }] },
  { key: "settings", label: "Settings", icon: "\u2699\uFE0F", hidden: true,
    blurb: "How it looks, your sign-ins, reminders",
    parts: [{ col: "#col-center", pane: "settings" }] },
];
const TAB_KEYS = SIMPLE_TABS.map((t) => t.key);
/* True only while showTab is resetting the centre; see showTab. */
let TAB_SWITCHING = false;
function isSimple() { return false; }   // 0.20: one layout. Retired in stage 7.
window.isSimple = isSimple;

/* 0.20: there is ONE layout now. Studio replaces both `dash` and `simple`,
   so this no longer chooses between them — it exists until stage 7 deletes
   the 0.18 renderers, and its only remaining job is to make sure nothing the
   old layouts left behind (a `data-layout`, a hidden column, the tab strip)
   is still on the page. `tests/test_two_layouts.py`'s simple-layout contract
   is retired with it, deliberately. */
function applyLayout() {
  const root = document.documentElement;
  root.removeAttribute("data-layout");
  const pick = $("#layout-pick");
  if (pick) pick.hidden = true;
  const bar = $("#tab-bar");
  if (bar) bar.hidden = true;
  PREFS.layout = "studio";
  // Folded/grown mean different things in the two layouts, so the saved
  // states have to be re-read whenever the layout changes.
  try { applyPanelStates(); } catch (e) { /* before the panels exist */ }
  try { placeBrief(); } catch (e) { /* before the panels exist */ }
  document.querySelectorAll(".tab-on").forEach((el) => el.classList.remove("tab-on"));
  document.querySelectorAll(".tab-main").forEach((el) => el.classList.remove("tab-main"));
  applyPageHeadings(null);
  root.removeAttribute("data-tab");
}

/* Which tab a centre pane belongs to, so opening an assignment from Today
   lights up the right tab instead of none. Panes with no tab of their own
   (item, grade, accel, add, setup) are reached BY doing something, and the
   strip keeps showing where you came from. */
function tabForPane(pane) {
  const hit = SIMPLE_TABS.find((t) => t.parts.some((part) => part.pane === pane));
  return hit ? hit.key : null;
}

/* A page is headed by the name on its tab. [MEASURED] 2026-09-10: tapping
   "To do" opened a box headed "Assignments", and the tab strip and the page
   heading disagreeing about what a page is called is exactly the confusion
   this layout exists to remove. The dashboard keeps the template's own
   headings, where several boxes share one screen and "Assignments" says more
   than "To do" would. The original is remembered on the element the first
   time it is changed, so switching back restores it rather than guessing. */
/* Where the brief lives. It is the counts, the one thing to start with and
   the reason it is first — and in the simple layout it sat on top of the
   *conversation*, which is two unrelated things on one page and left the chat
   log 173px tall on his 605px screen. "What should I do first" is answered on
   the page that lists what there is to do, so in the simple layout the brief
   moves to the top of the To-do box and the Chat page becomes only chat.

   It is moved rather than copied: one node, so `renderHero` keeps finding
   `#hero-body` by id wherever it is, and there is never a second stale copy.
   It is inserted BEFORE the To-do box's `.panel-body`, because `renderPanels`
   rewrites that body's innerHTML on every refresh and would wipe a child. */
function placeBrief() {
  const brief = $("#hero-panel");
  if (!brief) return;
  const target = isSimple()
    ? document.querySelector('.panel[data-panel="tomorrow"]')
    : document.querySelector("#chat-panel .panel-body");
  if (!target) return;
  const before = isSimple()
    ? target.querySelector(".panel-body")
    : target.firstElementChild;
  if (brief.parentElement === target && brief.nextElementSibling === before) return;
  target.insertBefore(brief, before);
  brief.classList.toggle("on-todo", isSimple());
}

function applyPageHeadings(tab) {
  document.querySelectorAll(".col.side .panel > header > h2").forEach((h) => {
    if (h.dataset.deskName === undefined) h.dataset.deskName = h.textContent;
    h.textContent = h.dataset.deskName;
  });
  if (!tab) return;
  const main = tab.parts.find((part) => part.panel && !part.aside);
  if (!main) return;
  const head = document.querySelector(
    `.panel[data-panel="${main.panel}"] > header > h2`);
  if (head) head.textContent = tab.label;
}

function showTab(key, opts) {
  if (!isSimple()) return;
  if (!TAB_KEYS.includes(key)) key = "todo";
  const tab = SIMPLE_TABS.find((t) => t.key === key);
  document.documentElement.setAttribute("data-tab", key);
  if (!opts || !opts.fromPrefs) savePrefs({ tab: key });
  else PREFS.tab = key;

  /* Route through showPane FIRST, even for a tab that shows no pane at all.
     [MEASURED] 2026-09-10: without this, tapping an assignment on Today and
     pressing back left `SELECTED` set and `#pane-item` open behind the page.
     Nothing looked wrong until the next refresh, when render() called
     renderDetail(SELECTED) -> showPane("item"), which pulled the CENTRE column
     back in front and left Today showing an assignment nobody had asked for.
     Clearing the centre is part of changing page, not an afterthought.
     TAB_SWITCHING stops showPane's own simple-layout block from fighting the
     column marking that comes after it. */
  const centre = tab.parts.find((part) => part.pane);
  TAB_SWITCHING = true;
  try { showPane(centre ? centre.pane : "chat"); }
  finally { TAB_SWITCHING = false; }

  const wanted = new Map(tab.parts.map((part) => [part.col, part]));
  for (const sel of ["#col-left", "#col-center", "#col-right"]) {
    const col = document.querySelector(sel);
    if (!col) continue;
    const part = wanted.get(sel);
    col.classList.toggle("tab-on", !!part);
    col.classList.toggle("tab-aside", !!(part && part.aside));
  }
  const board = document.querySelector(".board");
  if (board) board.classList.toggle("tab-split", tab.parts.some((part) => part.aside));
  // Inside a side column, only the panels this tab actually names.
  const panels = new Set(tab.parts.map((part) => part.panel).filter(Boolean));
  const main = tab.parts.find((part) => part.panel && !part.aside);
  document.querySelectorAll(".col.side .panel").forEach((el) => {
    el.classList.toggle("tab-on", panels.has(el.dataset.panel));
    // The page's own box, as opposed to something beside it. Its count is
    // already on its tab, so the header does not repeat it.
    el.classList.toggle("tab-main", !!main && main.panel === el.dataset.panel);
  });
  applyPageHeadings(tab);
  renderTabs();
}
window.showTab = showTab;

/* The strip is built from SIMPLE_TABS, with the same counts the panel headers
   show — the number is the reason to open a page, so hiding it here would
   make the layout that shows less also tell you less. */
function renderTabs() {
  const bar = $("#tab-bar");
  if (!bar || !isSimple()) return;
  /* A page reached from More still lights More up, so the strip always shows
     where you are — five tabs and none of them active is the state that makes
     a tabbed app feel broken. */
  const here = SIMPLE_TABS.find((t) => t.key === PREFS.tab);
  const open = here && here.hidden ? "more" : PREFS.tab;
  bar.innerHTML = SIMPLE_TABS.filter((t) => !t.hidden).map((t) => {
    const n = tabCount(t.key);
    return `<button type="button" data-tab="${esc(t.key)}"${t.key === open ? ' class="active"' : ""}>`
      + `<span class="tab-i" aria-hidden="true">${t.icon}</span>${esc(t.label)}`
      + `<span class="tab-n">${n ? esc(String(n)) : ""}</span></button>`;
  }).join("");
  renderMore();
}

/* The More page: the four things that are not why you opened the app. Built
   from the same list, so a page can never be unreachable — if it is hidden
   from the strip it is here. */
function renderMore() {
  const host = $("#more-list");
  if (!host) return;
  host.innerHTML = SIMPLE_TABS.filter((t) => t.hidden).map((t) => {
    const n = tabCount(t.key);
    return `<button type="button" class="more-row" data-tab="${esc(t.key)}">
      <span class="more-i" aria-hidden="true">${t.icon}</span>
      <span class="more-t"><b>${esc(t.label)}</b><span class="more-b">${esc(t.blurb || "")}</span></span>
      ${n ? `<span class="more-n">${esc(String(n))}</span>` : ""}
      <span class="more-go" aria-hidden="true">\u203A</span></button>`;
  }).join("");
}

/* The number on a tab is the number in that panel's own header. It is read
   from sections() — the same bucketing the panels are filled from — because a
   second filter here would eventually disagree with the box it labels, and a
   count that contradicts the list under it is worse than no count. */
function tabCount(key) {
  if (!STATE || !STATE.items) return 0;
  let out;
  try { out = sections().out; } catch (e) { return 0; }
  if (key === "todo") return out.tomorrow.open.length + out.later.open.length;
  if (key === "personal") return out.personal.open.length;
  if (key === "grades") return ((STATE.grades) || []).filter((g) => g.graded).length;
  if (key === "done") return (STATE.items || []).filter((i) => i.done).length;
  return 0;
}
window.savePrefs = savePrefs;
window.getPrefs = () => PREFS;

/* ---------------- local tick overlay (remote mode) ---------------- */
const localTicks = {
  key: "sillybus.remote.done",
  load() { try { return JSON.parse(localStorage.getItem(this.key)) || {}; }
           catch (e) { return {}; } },
  set(id, done) { const t = this.load(); if (done) t[id] = 1; else delete t[id];
    localStorage.setItem(this.key, JSON.stringify(t)); },
};

/* ---------------- boot ---------------- */
let STATE_ETAG = "";
function showOffline(on) {
  let box = document.getElementById("offline-note");
  if (!on) { if (box) box.remove(); return; }
  if (box) return;
  box = document.createElement("div");
  box.id = "offline-note";
  box.setAttribute("role", "alert");
  box.innerHTML = `<b>SillyBus isn't running.</b>
    <span>Open the SillyBus AI app — this page fills in by itself once it is up.</span>
    <button type="button" class="primary" data-offline-retry>Try again</button>`;
  document.body.appendChild(box);
}
document.addEventListener("click", (event) => {
  if (event.target.closest("button[data-offline-retry]")) location.reload();
});

/* SillyBus Lock — the Mac menu-bar app that hides games and social apps
   until today's work is done ([ASKED] 2026-10-06, lock/ in the repo). It
   has no school data of its own; whichever SillyBus is open tells it, here,
   after every load and once a minute: GET /api/lock (sillybus/lock.py, the
   one definition of "done"), POSTed to the lock on 127.0.0.1:5066.
   text/plain, so no preflight; the lock accepts only SillyBus's own origins.
   When the lock is not running the call fails quietly and is retried every
   five minutes rather than every minute. */
let LOCK_NEXT = 0;
let LOCK_UP = false;          // the last try reached it: a change is sent at once
async function tellLock(force) {
  if (REMOTE || (!force && Date.now() < LOCK_NEXT)) return;
  try {
    const status = await (await fetch("/api/lock")).json();
    await fetch("http://127.0.0.1:5066/status", { method: "POST",
      headers: { "Content-Type": "text/plain" }, body: JSON.stringify(status) });
    LOCK_NEXT = Date.now() + 55 * 1000;
    LOCK_UP = true;
  } catch (e) {
    LOCK_NEXT = Date.now() + 5 * 60 * 1000;      // no lock app here, or not yet
    LOCK_UP = false;
  }
}
setInterval(() => tellLock(false), 60 * 1000);

async function loadState() {
  if (REMOTE) {
    STATE = window.SNAPSHOT;
    const ticks = localTicks.load();
    for (const item of STATE.items || []) {
      if (ticks[item.item_id]) item.done = true;
    }
  } else {
    /* The server says whether anything it is built from has changed since
       the last answer (ETag); when nothing has, nothing is re-rendered — so
       the minute-poll no longer rebuilds every row under the mouse. */
    /* [MEASURED] 2026-10-06: with the server stopped, the page in his
       Chrome (an old tab, its shell kept by the service worker) showed the
       toolbar and nothing else — no board, no message, no reason. A page that
       cannot reach SillyBus now says so, and the minute-poll takes the
       message away by itself once it can. */
    let response;
    try {
      response = await fetch("/api/state", STATE_ETAG && STATE
        ? { headers: { "If-None-Match": STATE_ETAG } } : undefined);
    } catch (err) {
      showOffline(true);
      throw err;
    }
    if (response.status >= 500) { showOffline(true); return; }
    showOffline(false);
    if (response.status === 304 && STATE) return;
    if (response.status === 401) { showGate(); return; }
    // 402, not 401: they are signed in, so throwing them back to a login form
    // would be answering a question they have already answered.
    if (response.status === 402) {
      const body = await response.json().catch(() => ({}));
      showPaywall((body.error || {}).message || "");
      return;
    }
    STATE = await response.json();
    STATE_ETAG = response.headers.get("ETag") || "";
  }
  if (!APP_VERSION_SEEN && STATE && STATE.app_version) {
    APP_VERSION_SEEN = STATE.app_version;
  }
  render();
  tellLock(LOCK_UP);
}

/* Every box drawn independently, and a box that fails SAYS SO.

   [MEASURED] 2026-09-10. He sent a screenshot of the Grades page: the panel
   header showed "7/10 · low first" and the body below it was completely
   empty — and the page had no footer either. That second detail is the whole
   diagnosis. These calls used to be eight bare statements in a row, so the
   first one to throw took every one after it with it, silently: grades blank,
   focus blank, the hero gone, the footer never written, and no error anywhere
   a person could see. The data was fine and the same state rendered correctly
   in another browser, which is the worst version of this bug — nothing to
   look at and nothing to read.

   So: each renderer is its own attempt, the failures are collected, and they
   are put on screen with the name of the box and the message. A panel that
   cannot draw is a bug worth reporting; a page that goes blank without
   telling anyone is a bug that cannot be reported at all. */
function render() {
  const steps = [
    ["the top line", renderHead],
    ["the notices", renderBanners],
    /* 0.20: one step draws the board, because the Studio sections share a
       course list, an open-work list and a set of preferences, and computing
       those four times was what made the 0.18 boxes disagree about counts.
       It is still its own attempt, so a section that throws cannot blank the
       rest of the page — that is the lesson this list exists for. */
    ["the board", renderStudio],
    /* Still here, and still guarded: `#pane-done` is the one 0.18 panel the
       Studio middle kept, and fillPanel() no-ops on the ones that are gone. */
    ["what is finished", renderPanels],
    ["the class list", fillCourseList],
  ];
  const broke = [];
  for (const [what, fn] of steps) {
    try {
      fn();
    } catch (err) {   // noqa — the point is that one box cannot take the rest
      broke.push([what, err]);
      console.error(`SillyBus AI: could not draw ${what}`, err);
    }
  }
  if (SELECTED) {
    try { renderDetail(SELECTED); } catch (err) { broke.push(["that assignment", err]); }
  }
  if (SELECTED_CLASS && window.renderGradePane) {
    try { window.renderGradePane(SELECTED_CLASS); } catch (err) { broke.push(["that class", err]); }
  }
  /* The page that is open draws again with the data. [MEASURED] 2026-10-06,
     his screenshot of /calendar: opened straight from the address bar, the
     page was shown before the first /api/state answered, drew nothing
     (`!STATE`), and nothing ever asked it again — a blank Calendar. The same
     was true of a board that changed under an open page. */
  const pageDraw = { calendar: window.renderCalendarPage, life: window.renderLifePage,
                     done: window.renderDonePage, work: window.renderWorkPage,
                     grades: window.renderGradesPage, classlist: window.renderClassListPage }[PANE];
  if (pageDraw) {
    try { pageDraw(); } catch (err) { broke.push([`the ${PANE} page`, err]); }
  }
  try { renderTabStrip(); } catch (err) { broke.push(["the tabs", err]); }
  try { renderFooter(); } catch (err) { console.error("SillyBus AI: footer", err); }
  reportRenderFailures(broke);
}

/* Named, appended, and never thrown from — this is the last thing standing
   between a blank box and a silent one. */
function reportRenderFailures(broke) {
  const box = $("#banners");
  if (!box) return;
  if (!broke.length) return;
  const seen = new Set();
  const lines = broke.filter(([what]) => !seen.has(what) && seen.add(what)).map(([what, err]) => {
    const message = String((err && (err.message || err)) || "unknown").slice(0, 160);
    return `<div>${esc(what)} — <code>${esc(message)}</code></div>`;
  }).join("");
  try {
    box.innerHTML += `<div class="banner warn"><div><b>Part of this page could not be
      drawn.</b> Everything else still works, and the data itself is fine — this is a
      fault in the app, not in your grades or your homework.
      ${lines}
      <span class="muted">Press Refresh, and if it keeps happening send this message.</span>
      </div></div>`;
  } catch (err) { /* a broken banner must not be the thing that breaks */ }
}
window.render = render;

/* The one place the board makes a promise about itself, so it has to be true:
   "N open item(s) — nothing is hidden", or the trimmed total when anything was
   left off. Spec §5.2: a trimmed list states its true total. */
function renderFooter() {
  $("#footer").textContent = REMOTE
    ? "read-only snapshot — checkmarks here stay on this device; the real Done button lives on your PC"
    : footerLine();
}
function footerLine() {
  const open = (STATE.items || []).filter(i => !i.done).length;
  const trimmed = STATE.trimmed || {};
  const parts = [];
  if (trimmed.past) {
    parts.push(`${trimmed.past} older than ${trimmed.grace_days || 3} days`);
  }
  if (trimmed.undated) {
    parts.push(`${trimmed.undated} undated for over `
             + `${Math.round((trimmed.undated_days || 14) / 7)} weeks`);
  }
  if (!parts.length) return `${open} open item(s) — nothing is hidden`;
  return `${open} open item(s) · not shown: ${parts.join(", ")}`
       + " — nothing is deleted";
}

function renderHead() {
  const today = new Date(todayIso() + "T12:00:00");
  $("#today-line").textContent = today.toLocaleDateString(undefined,
    { weekday: "short", month: "short", day: "numeric" })
    + (STATE.block_label ? " · " + STATE.block_label.replace("school day", "day") : "");
  $("#freshness").textContent = STATE.generated_at
    ? "data " + STATE.generated_at.slice(5, 16).replace("T", " ") : "no data";
  const chip = $("#provider-chip");
  if (REMOTE) { chip.hidden = true; $("#refresh").hidden = true; }
  else {
    const status = STATE.provider_status || {};
    const provider = STATE.provider || "none";
    const off = provider === "null" || provider === "none";
    // A demotion is a change in who is answering, so it shows rather than
    // sitting in a log file.
    chip.classList.toggle("chip-warn", !!status.degraded && !off);
    if (status.degraded && !off) {
      chip.title = `Asked for ${status.configured}, actually using `
        + `${status.active}${status.model ? " (" + status.model + ")" : ""}.`
        + (status.skipped && status.skipped.length
           ? " Skipped: " + status.skipped.join(", ") : "")
        + " Answers may be weaker than usual.";
    }
    chip.textContent = off ? "AI: off"
      : (status.degraded ? "AI: " + provider + " (fallback)" : "AI: " + provider);
    chip.title = off
      ? "No AI provider. Assignments and course docs still work — only chat needs one."
      : "AI provider";
    if (off) limitChat();
  }
}

/* No AI installed no longer means no chat: questions about the student's own
   homework and schedule are lookups over data already on the Mac. The box
   stays usable; only the hint changes. */
function limitChat() {
  const hint = $("#chat-hint");
  if (hint) {
    hint.textContent = "no AI on this Mac — I can still answer about your own "
      + "homework, schedule, rooms and grades";
  }
  const input = $("#chat-input");
  if (input) input.placeholder = "what's due tomorrow?";
}

/* Everything that used to be a banner is a MARK in the top bar now — the
   same red box a dead quick link gets, with the sentence as its title and a
   click that takes you where the fix is. The one exception is the empty
   board (no data at all), which is the whole page's state rather than a
   notice about it. */
let MARKS = [];
function renderBanners() {
  const box = $("#banners");
  box.innerHTML = "";
  MARKS = [];
  const mark = (id, text, title, go, cls) => MARKS.push({ id, text, title, go, cls: cls || "warn" });
  if (STATE.empty) {
    box.innerHTML = `<div class="banner warn">${esc(STATE.message || "no data yet")}</div>`;
    return;
  }
  if (STATE.generated_at) {
    const age = (Date.now() - new Date(STATE.generated_at).getTime()) / 3600000;
    const limit = STATE.stale_after_hours || 18;
    if (age > limit) {
      mark("stale", `${age.toFixed(0)}h old`, `this data is ${age.toFixed(0)} hours old`
        + (REMOTE ? " — the next scheduled update will replace it" : " — press Refresh"), "refresh");
    }
  }
  // A subscription that is about to end should never be a surprise. Only the
  // last few days say anything — a fortnight of countdown is nagging.
  const sub = STATE.subscription || {};
  const left = sub.days_left;
  if (!REMOTE && typeof left === "number" && left <= 3
      && (sub.state === "trial" || sub.state === "paid")) {
    const what = sub.state === "trial" ? "free trial" : "subscription";
    const when = left <= 0 ? "today" : left === 1 ? "tomorrow" : `in ${left} days`;
    const price = (sub.price || {}).amount || "5.99";
    mark("trial", `${what} ends ${when}`, `your ${what} ends ${when} — $${price} a month to keep it${
      sub.pay_to ? `, on Venmo to ${sub.pay_to}` : ""}. Your homework stays on this Mac either way.`, "settings:about");
  }
  /* On Free, and out of something. Only when an allowance is actually used
     up — being on the free plan is a status, not a problem, and a permanent
     "you could pay us" strip is the nagging this file already refuses to do
     for a trial that has a fortnight left. The refusal itself appears inside
     chat, which is easy to miss if the last thing you pressed was Accelerate,
     so it is said here too. */
  const allow = (STATE.allowance || {});
  if (!REMOTE && sub.plan === "free" && allow.metered) {
    const spent = Object.entries(allow.kinds || {})
      .filter(([, row]) => row && row.exhausted)
      .map(([kind]) => ({ chat: "chat questions", accelerate: "study guides",
                          profiles: "new classes to learn" })[kind] || kind);
    if (spent.length) {
      mark("allowance", "out of " + spent[0], `You have used this month's ${spent.join(" and ")} on Free. It resets on the 1st, and Basic is $4.99 a month for five times as much. Your board, dates, schedule and grades are not limited and keep working.`, "settings:about");
    }
  }
  // A new version of SillyBus AI itself is published. Distinct from the reload
  // banner below: that one means this TAB is behind the running server; this
  // one means the app on disk is behind what has been released.
  if (UPDATE && UPDATE.available && !REMOTE) {
    mark("update", `${UPDATE.latest} is out`, `SillyBus AI ${UPDATE.latest} is available — you have ${UPDATE.current}. Update from Settings, About.`, "settings:about", "info");
  }
  if (false) {   // the banner form, kept for stage 7 to delete
    box.innerHTML += `<div class="banner update" id="update-banner">
      <div class="banner-head"><span>SillyBus AI ${esc(UPDATE.latest)} is available</span>
        <span class="muted">you have ${esc(UPDATE.current)}</span></div>
      ${UPDATE.notes ? `<div class="banner-fix">${esc(UPDATE.notes)}</div>` : ""}
      <div class="banner-fix">
        ${UPDATE.can_install
          ? `<button type="button" class="banner-signin update-go" id="update-go">Update now</button>`
          : `<span class="muted">${esc(UPDATE.why_not || "update it the way it was installed")}</span>`}
        <button type="button" class="mini-btn" id="update-later">Not now</button>
        <span class="banner-signin-note" id="update-note"></span>
      </div></div>`;
  }
  if (APP_VERSION_SEEN && STATE.app_version
      && STATE.app_version !== APP_VERSION_SEEN) {
    /* Say what it will look like, not just what happened. [MEASURED]
       2026-09-10: he reported "my grades are not popping up in the grades
       page" while this banner was on screen — the Grades page really was
       blank, because his page was running the previous build. A notice that
       names the SYMPTOM gets read; "has been updated" sounds like news. */
    mark("reload", "reload for the new version", "SillyBus AI has been updated, and this page is still running the old version — pages may look empty or behave oddly until you reload. Click to reload.", "reload", "bad");
  }
  if (STATE.kept_previous) {
    const when = (STATE.last_attempt || "").slice(5, 16).replace("T", " ");
    mark("kept", "last good data", `this is your last good data — the update${when ? " at " + when : ""} could not reach anything, so nothing was overwritten. Press Refresh when you are back online.`, "refresh");
  }
  /* Source errors do not get a banner at all any more. [ASKED] 2026-09-18,
     with a screenshot of a strip that had eaten the board: "remove all of
     these popup banners, just make the shortcut at the top have the same
     style box around it". So a dead source marks its OWN quick link in the
     top bar (linksRowHtml), a dead source with no earned link gets a small
     red mark of its own up there, and the sentence and the sign-in button
     live on Settings -> Connections, which the mark opens. */
  wireSignInButtons();
  wireUpdateButton();
  renderQuickLinks();   // the marks live there
}

/* ---------------- updating the app ----------------
   The check is a cached read on the server, so this costs nothing on a page
   load; the banner only appears when a NEWER version is actually published.
   Dismissing hides that version until a newer one turns up — a banner that
   comes back every minute is one nobody reads. */
let UPDATE = null;
let UPDATE_DISMISSED = "";
try { UPDATE_DISMISSED = localStorage.getItem("sillybus.update.dismissed") || ""; }
catch (e) { /* private mode */ }

/* `force` asks the server to skip its own 6-hour cache and re-read the
   published marker. That is a few hundred bytes of JSON, never the archive
   (update.status), so it is cheap enough to do every time the app opens.

   `ignoreDismissed` is a SEPARATE question and must stay separate: forcing a
   fresh read is not a reason to re-raise a banner the student already said
   "Later" to. Only pressing Check for updates yourself means that. They were
   one flag until 0.21.3.0, which is why opening the app could not re-check
   without also undoing every dismissal. */
async function checkUpdate(force, options) {
  if (REMOTE) return null;
  const ignoreDismissed = !!(options && options.ignoreDismissed);
  try {
    const res = await fetch(`/api/update${force ? "?force=1" : ""}`);
    const out = await res.json();
    if (out && out.available && out.latest === UPDATE_DISMISSED && !ignoreDismissed) {
      out.available = false;      // he said not now, and it is the same version
    }
    UPDATE = out;
    return out;
  } catch (e) {
    return null;                  // offline is not news
  }
}
window.checkUpdate = checkUpdate;
window.updateStatus = () => UPDATE;

function wireUpdateButton() {
  const later = $("#update-later");
  if (later) later.addEventListener("click", () => {
    try {
      if (UPDATE && UPDATE.latest) localStorage.setItem("sillybus.update.dismissed", UPDATE.latest);
      UPDATE_DISMISSED = (UPDATE || {}).latest || "";
    } catch (e) { /* fine */ }
    if (UPDATE) UPDATE.available = false;
    renderBanners();
  });
  const go = $("#update-go");
  if (go) go.addEventListener("click", () => runUpdate(go, $("#update-note")));
}

/* Download, swap, restart — with every step on screen, because this replaces
   the app someone is looking at and a silent minute would read as a hang. */
async function runUpdate(button, note) {
  const say = (text) => { if (note) note.textContent = " " + text; };
  button.disabled = true;
  say("downloading…");
  try {
    const started = await (await fetch("/api/update", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })).json();
    if (started.error) throw new Error(started.error.message);
    if (!started.job_id) throw new Error("could not start the update");
    let seen = 0, result = null;
    // Forty minutes, not eight: the download is ~30 MB, and on slow school
    // wifi it ran past the old limit, which left the new copy installed and
    // the old one running (prosecution round 4). A poll that fails is retried.
    for (let n = 0; n < 2000; n++) {
      await new Promise((r) => setTimeout(r, 1200));
      let job;
      try { job = await (await fetch(`/api/jobs/${started.job_id}`)).json(); } catch (e) { continue; }
      for (; seen < (job.lines || []).length; seen++) say(job.lines[seen]);
      if (job.done) {
        if (!job.ok) throw new Error(job.failure || "the update did not finish");
        result = job.result;
        break;
      }
    }
    if (!result) throw new Error("the update is taking too long — try again later");
    say(`installed ${result.installed} — restarting…`);
    // The server is about to be replaced by one running the new code. It
    // answers this call and then exits, so a failure to reach it afterwards
    // is expected rather than an error.
    try {
      const restart = await fetch("/api/update/restart", { method: "POST" });
      if (restart.status >= 500) {
        const why = await restart.json().catch(() => null);
        throw new Error(((why || {}).error || {}).message || "the new version would not start — quit SillyBus AI and open it again");
      }
    } catch (e) {
      if (e instanceof TypeError) { /* it went away, which is the point */ } else throw e;
    }
    for (let n = 0; n < 60; n++) {
      await new Promise((r) => setTimeout(r, 1000));
      try {
        const health = await fetch("/api/health", { cache: "no-store" });
        const body = await health.json();
        if (body.version === result.installed) { location.reload(); return; }
      } catch (e) { /* still down */ }
    }
    say("the new version is installed — quit SillyBus AI and open it again to finish");
    button.disabled = false;
  } catch (err) {
    say("could not update: " + err.message);
    button.disabled = false;
  }
}

window.runUpdateFromSettings = (button, note) => runUpdate(button, note);

/* Which errors a person can clear themselves, and what the button says. */
/* Which SITE an error belongs to, so the collapsed strip can name the thing
   that is broken rather than list four error codes. A code with no entry here
   falls back to the code itself, which is honest if ugly. */
const SOURCE_LABEL = {
  canvas_session: "Canvas", canvas: "Canvas", canvas_pages: "Canvas",
  class_feed: "Veracross", veracross_grades: "Veracross", veracross: "Veracross",
  ap_classroom: "AP Classroom", albert: "Albert.io", google_classroom: "Google Classroom",
  connections: "your calendars", google_docs: "the teacher's documents",
};

const SIGN_IN_FOR = {
  canvas_session: { kind: "canvas", label: "Sign in to Canvas" },
  veracross_grades: { kind: "veracross", label: "Sign in to Veracross" },
  class_feed: { kind: "veracross", label: "Sign in to Veracross" },
  ap_classroom: { kind: "ap_classroom", label: "Open AP Classroom to sign in" },
};

function wireSignInButtons() {
  document.querySelectorAll(".banner-signin[data-kind]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const note = btn.parentElement.querySelector(".banner-signin-note");
      btn.disabled = true;
      const say = (text) => { if (note) note.textContent = " " + text; };
      say("opening the sign-in window…");
      try {
        const res = await fetch("/api/login", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ kind: btn.dataset.kind, auto: true }),
        });
        const out = await res.json();
        if (out.error) throw new Error(out.error.message);
        // "already running" is not a dead end: a window IS open, the server
        // has just raised it, and the job it belongs to is still worth
        // following — otherwise pressing twice loses the sign-in in progress.
        if (!out.started) {
          say(out.message || "a sign-in is already running");
          if (!out.job_id) { btn.disabled = false; return; }
        } else {
          say(out.window
            ? `signing in… if a window opens it is called “${out.window}”`
            : "signing in… a window opens only if a step needs you");
        }
        for (let n = 0; n < 800; n++) {
          await new Promise((r) => setTimeout(r, 3000));
          const check = await fetch(`/api/login/${out.job_id}`);
          const status = await check.json();
          if (!status.done) continue;
          if (status.ok) {
            say("signed in — refreshing…");
            await refresh();
          } else {
            const why = (status.results || []).filter((r) => !r.ok).map((r) => r.message).join("; ");
            say("that did not finish" + (why ? ": " + why : ".") + " Check Settings → your sign-ins, or try again.");
            btn.disabled = false;
          }
          return;
        }
        say("still waiting — finish the sign-in in the other window");
        btn.disabled = false;
      } catch (err) {
        say("could not start it: " + err.message);
        btn.disabled = false;
      }
    });
  });
}

/* ---------------- adding work that is not in Canvas ----------------
   A form, not a chat message: it needs no AI. It lives in its own pane and
   outside every .panel-body, because fillPanel() overwrites those. */
function fillCourseList() {
  const list = $("#add-course-list");
  if (!list) return;
  const names = new Set();
  for (const g of STATE.grades || []) names.add(shortCourse(g.display_name));
  for (const p of STATE.profiles || []) names.add(shortCourse(p.display_name || p.course_raw));
  for (const i of STATE.items || []) names.add(shortCourse(i.course));
  names.delete(""); names.delete("Personal");
  list.innerHTML = [...names].sort().map((n) => `<option value="${esc(n)}">`).join("");
}

function openAdd(section) {
  const form = $("#add-form");
  if (!form) return;
  showPane("add");
  const sel = $("#add-section");
  if (sel && section !== undefined) sel.value = section || "";
  const title = $("#add-title");
  if (title) title.focus();
}
window.openAdd = openAdd;

function wireAddForm() {
  /* [MEASURED] 2026-09-20 from his install: "adding with the add button under
     Life isn't working". The 0.18 board had an #add-open button in the dock;
     Studio removed it, and this function returned before wiring the form
     when that button was missing — so Submit did a plain HTML form post,
     which in the extension navigates the page away. The form is wired
     whether or not any particular opener exists. */
  const form = $("#add-form");
  if (!form) return;
  const note = $("#add-note");
  const title = $("#add-title");
  const open = $("#add-open");
  if (open) open.addEventListener("click", () => openAdd(""));
  const personal = $("#personal-add");
  if (personal) personal.addEventListener("click", () => openAdd("goals"));
  const cancel = $("#add-cancel");
  if (cancel) cancel.addEventListener("click", () => { form.reset(); if (window.openTab) window.openTab("home"); else showPane("home"); });

  form.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const body = {
      title: title.value.trim(),
      due_date: $("#add-due").value || null,
      category: $("#add-category").value || null,
      course: $("#add-course").value.trim() || null,
      section: ($("#add-section") || {}).value || null,
      notes: (($("#add-notes") || {}).value || "").trim() || null,
    };
    if (!body.title) { title.focus(); return; }
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true; button.textContent = "Adding…";
    note.hidden = true;
    try {
      const res = await fetch("/api/tasks", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const out = await res.json();
      if (out.error) throw new Error(out.error.message);
      form.reset();
      note.hidden = false;
      // Say what it was filed as: the type decides whether this becomes a
      // study reminder, and a silent guess is one the person cannot correct.
      const filed = (out.task || {}).category;
      const asWhat = filed && filed !== "other" && filed !== "assignment" ? ` as a ${filed.replace("_", " ")}` : "";
      note.textContent = `Added${asWhat}. Add another, or press ‹ to go back.`;
      await loadState();
    } catch (err) {
      note.hidden = false;
      note.textContent = "could not add it: " + err.message;
    }
    button.disabled = false; button.textContent = "Add it";
  });
}

/* ---------------- study nudges ----------------
   A quiz is not homework you hand in; it is homework you must have done
   BEFORE the day. This is a hint attached to a real item, never a new one:
   inventing a "study for X" task would be inventing an assignment. */
const STUDY_LEAD_DAYS = { test: 3, quiz: 2, project: 3, essay: 2 };

function studyHint(item, today) {
  const lead = STUDY_LEAD_DAYS[item.category];
  if (!lead || item.done) return null;
  const days = daysUntil(item.due_date, today);
  if (days === null || days < 0 || days > lead) return null;
  const what = item.category === "quiz" ? "quiz"
    : item.category === "test" ? "test" : item.category;
  if (days === 0) return `${what} is today`;
  if (days === 1) return `${what} tomorrow — study tonight`;
  return `${what} in ${days} days — start studying`;
}

/* The most urgent thing to revise, if anything. Drives one line in the brief. */
function nextStudy(state) {
  const today = state.today;
  let best = null;
  for (const item of state.items || []) {
    const hint = studyHint(item, today);
    if (!hint) continue;
    const days = daysUntil(item.due_date, today);
    if (best === null || days < best.days) best = { item, hint, days };
  }
  return best;
}

/* ---------------- section logic ---------------- */
function clubCourseKeys() {
  const keys = new Set();
  for (const p of STATE.profiles || []) {
    if (["club", "community"].includes(p.course_type)) keys.add(p.course_key);
  }
  return keys;
}
const HEAVY = new Set(["test", "project", "essay", "quiz"]);
/* A test or a quiz is an event, not something handed in, so once it is past
   there is nothing to be late for. It stays on the board — labelled as past —
   and stops inflating the overdue count. */
const ASSESSMENTS = new Set(["test", "quiz"]);
function isPastAssessment(item, today) {
  return ASSESSMENTS.has(item.category) && !!item.due_date
    && item.due_date < today && !item.done;
}
/* Personal work: a goal, a practice, makeup, a club — anything the student
   filed somewhere other than "school work" when adding it. Homework never
   lands here by accident: only an explicit section flag qualifies. */
const PERSONAL_SECTIONS = { goals: "Goals", practice: "Practice", makeup: "Makeup work",
                            clubs: "Clubs", personal: "Personal" };
function personalSection(item) {
  for (const flag of item.flags || []) {
    if (flag.startsWith("section:")) return flag.slice(8);
    if (flag === "clubs" && item.source === "custom") return "clubs";
  }
  return null;
}

/* ---------------- events ----------------
   Things that HAPPEN — a game, a practice, a shift, an appointment — from the
   calendars he connected himself (TeamSnap, Google Calendar, any iCal URL).

   They live in STATE.events, NOT in STATE.items, and that is the whole point.
   Every function above that reads STATE.items — the scorer's output, the
   Assignments box, "what first?", the focus card — therefore cannot see one,
   so a Saturday game can never outrank a lab report by being sooner. They
   appear in two places and no others: the Personal box, beside the goals and
   practices he types in himself, and the calendar. */
const EVENT_ICONS = { game: "\u{1F3C6}", practice: "\u{1F3C3}", meeting: "\u{1F465}",
                      appointment: "\u{1F4CD}", shift: "\u{1F4BC}", travel: "\u{1F697}",
                      event: "\u{1F4C5}" };
const EVENT_LABELS = { game: "Game", practice: "Practice", meeting: "Meeting",
                       appointment: "Appointment", shift: "Shift", travel: "Travel",
                       event: "Event" };

function allEvents() {
  return (STATE.events || []).filter(e => e && e.date && e.title);
}
/* Everything happening on one day, including a multi-day event's middle days.
   An event is never "done" and never has a score, so the only order that
   means anything is when it starts. */
function eventsOn(day) {
  return allEvents()
    .filter(e => e.date === day || (e.end_date && e.date <= day && day <= e.end_date))
    .sort((a, b) => (a.all_day === b.all_day)
      ? String(a.start || "").localeCompare(String(b.start || ""))
      : (a.all_day ? -1 : 1));
}
function eventTime(e) {
  if (e.all_day || !e.start) return "all day";
  const from = e.start.slice(11, 16);
  const to = e.end && e.end.slice(0, 10) === e.date ? e.end.slice(11, 16) : "";
  return to ? `${from}–${to}` : from;
}
/* One event row. Deliberately not rowHtml(): that row carries a score chip, a
   Done toggle, points and an Accelerate button, and none of them mean
   anything here. Clicking opens the day rather than a detail pane, because
   there is nothing more to say about a game than the calendar already says. */
function eventRowHtml(e, today) {
  const when = eventTime(e);
  const days = daysUntil(e.date, today);
  return `<div class="event-row" data-event-day="${esc(e.date)}" title="${esc(e.date_note || "")}">
    <span class="event-icon" aria-hidden="true">${EVENT_ICONS[e.kind] || EVENT_ICONS.event}</span>
    <span class="event-what">
      ${safeHref(e.url) ? `<a href="${esc(e.url)}" target="_blank" rel="noopener">${esc(e.title)}</a>`
              : esc(e.title)}
      <small>${esc(when)}${e.location ? ` · ${esc(e.location)}` : ""}${e.connection ? ` · ${esc(e.connection)}` : ""}</small>
      <small class="date-note">${esc(e.date_note || "")}</small>
    </span>
    <span class="event-when">${esc(days === null ? "" : relDays(e.date, today))}<b>${esc(niceDate(e.date))}</b></span>
  </div>`;
}

function sections() {
  const today = todayIso();
  const tomorrow = isoPlus(today, 1);
  const clubs = clubCourseKeys();
  const isClub = (i) => clubs.has(i.course_key)
    || (i.flags || []).includes("clubs");
  const items = STATE.items || [];
  const out = {
    tomorrow: { open: [], done: [] },
    later: { open: [], done: [] },
    upcoming: { open: [], done: [] },
    clubs: { open: [], done: [] },
    personal: { open: [], done: [] },
  };
  /* One item, one place. An assessment lives in exactly one time bucket, and
     "upcoming" is built from the same objects for a strip that NAMES what is
     coming without repeating the row. */
  for (const i of items) {
    if (personalSection(i)) {
      (i.done ? out.personal.done : out.personal.open).push(i);
      continue;
    }
    const d = i.due_date;
    const when = (d && d <= tomorrow) ? "tomorrow" : "later";
    const names = [when];
    if (isClub(i)) names.push("clubs");
    for (const name of names) {
      (i.done ? out[name].done : out[name].open).push(i);
    }
    if (HEAVY.has(i.category) && !i.done && (!d || d >= today)) {
      out.upcoming.open.push(i);
    }
  }
  out.upcoming.open.sort((a, b) => (a.due_date || "9999") < (b.due_date || "9999") ? -1 : 1);
  out.clubs.open.sort((a, b) => (a.due_date || "9999") < (b.due_date || "9999") ? -1 : 1);
  return { out, today, tomorrow };
}

function rowHtml(item, context, firstId) {
  const today = todayIso();
  const past = isPastAssessment(item, today);
  const overdue = item.due_date && item.due_date < today && !item.done && !past;
  const tags = [];
  if (overdue) tags.push(`<span class="tag overdue">overdue</span>`);
  if (past) tags.push(`<span class="tag was">was ${esc(niceDate(item.due_date))}</span>`);
  if (HEAVY.has(item.category) && context !== "upcoming")
    tags.push(`<span class="tag ${esc(item.category)}">${esc(item.category)}</span>`);
  if (context === "upcoming")
    tags.push(`<span class="tag ${esc(item.category)}">${esc(item.category)}</span>`);
  if (item.source === "custom" && context !== "personal") tags.push(`<span class="tag custom">yours</span>`);
  if (item.source === "ap_classroom") tags.push(`<span class="tag apclassroom">AP Classroom</span>`);
  const study = studyHint(item, today);
  if (study) tags.push(`<span class="tag study">${esc(study)}</span>`);
  /* The one to start with, marked on the row rather than shown again above
     it. [MEASURED] 2026-09-10: the simple layout put a "START HERE" card at
     the top of the To-do page and the same assignment appeared as a row a
     hundred pixels below — one title, twice, on the page whose whole purpose
     was to stop showing things twice. The recommendation belongs on the thing
     it recommends: same tick box, same tap, and the reason underneath it. */
  const first = !!firstId && item.item_id === firstId && !item.done;
  if (first) tags.unshift(`<span class="tag first">start here</span>`);
  const why = first ? focusWhy(item) : "";
  /* A checkbox beside a real <button>, not a div pretending to be one.
     [PROVEN] tests/test_prosecution.py: role="button" wrapped around an
     <input> is invalid, the row had no accessible name, and every checkbox
     said the same word. A real button brings Enter and Space for free. */
  const label = item.title || "this item";
  const due = context === "personal" && !item.due_date ? "" : dueLabel(item);
  const course = context === "personal" && shortCourse(item.course) === "Personal" ? "" : nick(item.course);
  return `<div class="row${item.done ? " done-row" : ""}${overdue ? " is-overdue" : ""}${first ? " is-first" : ""}${SELECTED === item.item_id ? " selected" : ""}" ${classStyle(item.course_key)}>
    <input type="checkbox" class="tick" ${item.done ? "checked" : ""}
           aria-label="Mark ${esc(label)} done" data-id="${esc(item.item_id)}">
    <button type="button" class="row-open" data-id="${esc(item.item_id)}">
      <span class="row-title">${esc(item.title)}</span>
      <span class="row-sub">${due ? `<span>${esc(due)}</span>` : ""}
        ${course ? `<span class="row-course">${esc(course)}</span>` : ""}
        ${item.est_label ? `<span>${esc(item.est_label)}</span>` : ""}
        ${item.points ? `<span>${esc(item.points)} pts</span>` : ""}${tags.join("")}</span>
      ${why ? `<span class="row-why">${why}</span>` : ""}
    </button>
    ${REMOTE || item.done ? "" : `<button type="button" class="row-accel" data-id="${esc(item.item_id)}"
       title="Accelerate: a study guide from the actual material" aria-label="Accelerate ${esc(label)}">⚡</button>`}</div>`;
}

function listHtml(groups, context, firstId) {
  let html = "";
  for (const [label, list, meta, urgent] of groups) {
    if (!list.length) continue;
    if (label) html += `<div class="group-label${urgent ? " urgent" : ""}">${esc(label)}
      <span class="gl-meta">${esc(meta || "")}</span></div>`;
    html += list.map(i => rowHtml(i, context, firstId)).join("");
  }
  return html || `<div class="empty-note">nothing here — enjoy it ✓</div>`;
}

/* How the Assignments box is ordered. "smart" is the pipeline's ranking —
   urgency, kind, points, the grade nudge — inside due-date sections, with
   longer work first when two things tie; the others are for when he wants a
   different question answered. */
const SORT_MODES = ["smart", "due", "class", "time"];
const SORT_LABEL = { smart: "smart", due: "by date", class: "by class", time: "longest first" };

function renderPanels() {
  const { out, today, tomorrow } = sections();
  const open = [...out.tomorrow.open, ...out.later.open];
  const bySmart = (a, b) => (b.score || 0) - (a.score || 0)
    || (b.est_minutes || 0) - (a.est_minutes || 0) || String(a.title).localeCompare(b.title);
  const byDate = (a, b) => (a.due_date || "9999") === (b.due_date || "9999")
    ? bySmart(a, b) : ((a.due_date || "9999") < (b.due_date || "9999") ? -1 : 1);
  const byTime = (a, b) => (b.est_minutes || 0) - (a.est_minutes || 0) || bySmart(a, b);
  const est = (list) => minutesLabel(list.reduce((s, i) => s + (i.est_minutes || 0), 0));
  const meta = (list) => [list.length, est(list)].filter(Boolean).join(" · ");
  const mode = SORT_MODES.includes(PREFS.assignSort) ? PREFS.assignSort : "smart";
  const sortBtn = $("#assign-sort");
  // A bare word ("smart") does not read as something you can press. The
  // sort glyph says it is a control and what kind.
  if (sortBtn) sortBtn.textContent = "\u21C5 " + SORT_LABEL[mode];
  /* Only the simple layout marks it, and only in the To-do list. On the
     dashboard the brief's card sits in a different column from Assignments,
     where a callout is not a repetition of the row beside it. */
  const firstId = isSimple() ? ((currentFocus() || {}).item_id || null) : null;

  let assignHtml = "";
  if (mode === "class") {
    /* One dropdown per class, headed by the nearest thing due. <details>
       rather than a click handler: keyboard support and the open state come
       free, and which classes are open is remembered because render() runs on
       every refresh. */
    const groups = new Map();
    for (const item of [...open].sort(byDate)) {
      const name = shortCourse(item.course) || "no class";
      if (!groups.has(name)) groups.set(name, []);
      groups.get(name).push(item);
    }
    /* A quiz that already happened is not the "next" thing in its class: it
       headed the class with "yesterday" in late red and sorted the class to
       the top, ahead of classes with real work due. Skipped here exactly as
       the ring skips it. (prosecution round 4, 2026-10-07) */
    const live = (i) => i.due_date && !isPastAssessment(i, today);
    const soonest = (list) => list.reduce(
      (best, i) => (live(i) && (!best || i.due_date < best)) ? i.due_date : best, null);
    const ordered = [...groups.entries()].sort((a, b) => {
      const da = soonest(a[1]) || "9999", db = soonest(b[1]) || "9999";
      return da === db ? a[0].localeCompare(b[0]) : (da < db ? -1 : 1);
    });
    const openClasses = classesOpen();
    assignHtml = ordered.map(([name, items]) => {
      const next = items.find(live) || items.find(i => !isPastAssessment(i, today)) || items[0];
      const when = next && next.due_date ? relDays(next.due_date, today) : "no date yet";
      return `<details class="class-group" data-class="${esc(name)}" ${openClasses.has(name) ? "open" : ""}>
        <summary ${classStyle(items[0].course_key)}>
          <span class="cg-name" title="${esc(name)}">${esc(name)}</span>
          <span class="cg-next">${next ? esc(next.title) : ""}</span>
          <span class="cg-when">${esc(when)}</span>
          <span class="cg-count">${items.length}</span>
        </summary>
        <div class="cg-rows">${listHtml([["", items]], "upcoming", firstId)}</div>
      </details>`;
    }).join("") || `<div class="empty-note">nothing open — enjoy it ✓</div>`;
  } else if (mode === "due") {
    assignHtml = listHtml([["", [...open].sort(byDate)]], "due", firstId);
  } else {
    const within = (a, b) => (mode === "time" ? byTime : bySmart)(a, b);
    const week = isoPlus(today, 7);
    const past = open.filter(i => isPastAssessment(i, today));
    const live = open.filter(i => !isPastAssessment(i, today));
    const pick = (test) => live.filter(test).sort(within);
    const overdue = pick(i => i.due_date && i.due_date < today);
    const todayL = pick(i => i.due_date === today);
    const tomorrowL = pick(i => i.due_date === tomorrow);
    const weekL = pick(i => i.due_date && i.due_date > tomorrow && i.due_date <= week);
    const laterL = pick(i => i.due_date && i.due_date > week);
    const undated = pick(i => !i.due_date);
    assignHtml = listHtml([
      ["overdue", overdue, meta(overdue), true],
      ["today", todayL, meta(todayL)],
      ["tomorrow", tomorrowL, meta(tomorrowL)],
      ["this week", weekL, meta(weekL)],
      ["later", laterL, meta(laterL)],
      ["no date", undated, meta(undated)],
      ["already happened", past.sort(byDate), "make-up?"],
    ], "due", firstId);
  }
  const doneCount = (STATE.items || []).filter(i => i.done && !personalSection(i)).length;
  const tonight = open.filter(i => i.due_date && i.due_date <= tomorrow && !isPastAssessment(i, today));
  const tonightMin = tonight.reduce((s, i) => s + (i.est_minutes || 0), 0);
  assignHtml += `<div class="panel-foot">
      <span>${tonight.length ? `by tomorrow: ${tonight.length} · ${esc(minutesLabel(tonightMin) || "~0m")}` : "nothing due by tomorrow ✓"}</span>
      ${doneCount ? `<button type="button" class="mini-btn" data-pane="done">${doneCount} done ›</button>` : ""}
    </div>`;
  fillPanel("tomorrow", assignHtml, open.length, []);
  /* Whether the card at the top of the page may be hidden: only when the row
     it would have duplicated is really on this list. A club or a personal
     item can be the pick and not appear in Assignments at all, and hiding the
     card unconditionally would have deleted the recommendation instead of
     moving it. Set as a class on <body> so the two renderers can run in
     either order — CSS is applied after both. */
  document.body.classList.toggle("first-on-row",
    !!firstId && open.some((i) => i.item_id === firstId && !i.done));

  /* "Due now" — the Calendar page's side list. Same rows, same sections, same
     sections() buckets as Assignments: `out.tomorrow` IS overdue + today +
     tomorrow, so this is that bucket and not a fourth definition of "soon". */
  const soonOverdue = out.tomorrow.open.filter((i) => i.due_date && i.due_date < today
    && !isPastAssessment(i, today)).sort(bySmart);
  const soonToday = out.tomorrow.open.filter((i) => i.due_date === today).sort(bySmart);
  const soonTomorrow = out.tomorrow.open.filter((i) => i.due_date === tomorrow).sort(bySmart);
  const soonCount = soonOverdue.length + soonToday.length + soonTomorrow.length;
  fillPanel("duesoon", soonCount ? listHtml([
    ["overdue", soonOverdue, meta(soonOverdue), true],
    ["today", soonToday, meta(soonToday)],
    ["tomorrow", soonTomorrow, meta(soonTomorrow)],
  ], "due", firstId) : `<div class="empty-note">nothing due today or tomorrow \u2713</div>`,
    soonCount, []);

  /* Tests & quizzes: what is coming, how many days there are to prepare, and
     a Study button that writes the guide. The row itself lives in
     Assignments, one click away; this strip names it without repeating it. */
  const ahead = out.upcoming.open;
  fillPanel("upcoming", ahead.length
    ? `<div class="ahead">` + ahead.map(i => {
        const days = daysUntil(i.due_date, today);
        const soon = days !== null && days <= 2;
        return `<div class="ahead-row" ${classStyle(i.course_key)}>
          <span class="ahead-when${soon ? " soon" : ""}"><b>${esc(i.due_date ? relDays(i.due_date, today) : "no date")}</b>${esc(i.due_date ? niceDate(i.due_date) : "")}</span>
          <button type="button" class="row-open ahead-what" data-id="${esc(i.item_id)}">${esc(i.title)}
            <small>${esc(nick(i.course))}${i.points ? ` · ${esc(i.points)} pts` : ""}</small></button>
          <span class="tag ${esc(i.category)}">${esc(i.category)}</span>
          ${REMOTE ? "" : `<button type="button" class="ahead-study row-accel-btn" data-id="${esc(i.item_id)}" title="Accelerate: a study guide for this">⚡</button>`}
        </div>`;
      }).join("") + `</div>`
    : `<div class="empty-note">nothing big coming up ✓</div>`,
    out.upcoming.open.length, out.upcoming.done);
  fillPanel("clubs", listHtml([["", out.clubs.open]], "clubs"),
            out.clubs.open.length, out.clubs.done);

  /* Personal: goals, practices, makeup, clubs — grouped by where he filed
     them. Empty is not an error; it is an invitation. */
  const personalGroups = new Map();
  for (const i of [...out.personal.open].sort(byDate)) {
    const key = personalSection(i) || "personal";
    if (!personalGroups.has(key)) personalGroups.set(key, []);
    personalGroups.get(key).push(i);
  }
  /* Life: games, practices, shifts and appointments from the connected
     calendars, from today forward. Grouped by kind, above the things he typed
     in himself, and counted in the box's badge — but never merged into the
     item list, and never ranked. `events_stale` is the same amber note the
     schedule and grades use when a refresh could not reach their source. */
  const upcomingEvents = allEvents().filter(e => (e.end_date || e.date) >= today)
    .sort((a, b) => (a.date === b.date
      ? String(a.start || "").localeCompare(String(b.start || ""))
      : (a.date < b.date ? -1 : 1)));
  const eventGroups = new Map();
  for (const e of upcomingEvents) {
    const key = EVENT_LABELS[e.kind] || EVENT_LABELS.event;
    if (!eventGroups.has(key)) eventGroups.set(key, []);
    eventGroups.get(key).push(e);
  }
  const eventsHtml = upcomingEvents.length
    ? staleNoteHtml(STATE.events_stale, "the last refresh could not reach one of your calendars")
      + [...eventGroups.entries()].map(([label, list]) =>
        `<div class="group-label">${esc(label)}<span class="gl-meta">${list.length}</span></div>`
        + list.map(e => eventRowHtml(e, today)).join("")).join("")
    : "";
  const personalHtml = personalGroups.size
    ? listHtml([...personalGroups.entries()].map(([k, list]) => [PERSONAL_SECTIONS[k] || k, list, meta(list)]), "personal")
    : "";
  fillPanel("personal", (eventsHtml + personalHtml)
    || `<div class="empty-note">nothing here yet — a goal, a practice, makeup work, a club.
       ${REMOTE ? "" : `<button type="button" class="mini-btn" data-add="goals">+ add one</button>`}</div>`,
    out.personal.open.length + upcomingEvents.length, out.personal.done);
  document.querySelectorAll('[data-panel="personal"] [data-event-day]').forEach((row) =>
    row.addEventListener("click", (ev) => {
      if (ev.target.closest("a")) return;   // the link opens the thing itself
      CAL_MODE = "day";
      SCHED_OFFSET = daysUntil(row.dataset.eventDay, todayIso()) || 0;
      renderSchedule();
    }));

  /* The Done pane: Canvas knows what was handed in, so those arrive without
     him ticking anything. Newest first. */
  const finished = (STATE.items || []).filter(i => i.done);
  finished.sort((a, b) => (b.due_date || "") < (a.due_date || "") ? -1 : 1);
  const byWho = (list, submitted) => list.filter(i => !!i.submitted === submitted);
  fillPanel("done", finished.length
    ? listHtml([
        ["handed in on Canvas", byWho(finished, true), String(byWho(finished, true).length)],
        ["ticked off here", byWho(finished, false), String(byWho(finished, false).length)],
      ], "done")
    : `<div class="empty-note">nothing finished yet — tick something off, or
       hand it in on Canvas and it will appear here</div>`,
    finished.length, []);

  document.querySelectorAll(".class-group").forEach((group) =>
    group.addEventListener("toggle", () => {
      const openSet = classesOpen();
      if (group.open) openSet.add(group.dataset.class);
      else openSet.delete(group.dataset.class);
      try {
        localStorage.setItem("sillybus.classes", JSON.stringify([...openSet]));
      } catch (e) { /* a private window is not a reason to break the page */ }
    }));
  document.querySelectorAll(".row-open").forEach((openBtn) => {
    openBtn.addEventListener("click", () => openDetail(openBtn.dataset.id));
  });
  document.querySelectorAll(".row-accel, .row-accel-btn").forEach((btn) => {
    btn.addEventListener("click", (ev) => {
      ev.stopPropagation();
      const item = (STATE.items || []).find(i => i.item_id === btn.dataset.id);
      if (item && window.openAccelerate) window.openAccelerate(item.item_id, item.title);
    });
  });
  document.querySelectorAll(".tick").forEach((tick) => {
    tick.addEventListener("click", (ev) => {
      ev.stopPropagation();
      toggleDone(tick.dataset.id, tick.checked);
    });
  });
  // The body records the active pane; it is not a navigation control.
  // Binding it redraws Calendar before its delegated button handler runs.
  document.querySelectorAll("button[data-pane]").forEach((b) =>
    b.addEventListener("click", () => {
      // "12 done >" and friends: a real move to another page in the simple
      // layout, where showPane alone would draw into a hidden column.
      if (isSimple() && TAB_KEYS.includes(b.dataset.pane)) showTab(b.dataset.pane);
      else showPane(b.dataset.pane);
    }));
  document.querySelectorAll("[data-add]").forEach((b) =>
    b.addEventListener("click", () => openAdd(b.dataset.add)));
}

/* How much of a column's spare height each box earns per item it holds. */
const PANEL_WEIGHT = { tomorrow: 3, upcoming: 3, personal: 1.2, grades: 1.3, focus: 1, schedule: 1.5 };

/* Which class dropdowns are open, remembered across refreshes. */
function classesOpen() {
  try {
    return new Set(JSON.parse(localStorage.getItem("sillybus.classes")) || []);
  } catch (e) {
    return new Set();
  }
}

function fillPanel(name, html, openCount, doneList) {
  const panel = document.querySelector(`[data-panel="${name}"]`);
  /* A panel that is not on the page any more is not an error: the bucket
     behind it may still be computed for a count elsewhere. Without this
     guard, retiring a panel throws here and blanks the whole app. */
  if (!panel) return;
  const body = panel.querySelector(".panel-body");
  const badge = panel.querySelector(".count");
  if (badge) {
    badge.textContent = String(openCount);
    badge.classList.toggle("zero", openCount === 0);
  }
  panel.classList.toggle("is-empty",
    openCount === 0 && !(doneList && doneList.length) && name !== "tomorrow");
  // Share out the column's spare height by content, sublinear, weighted by
  // urgency: what is due now beats how much is queued behind it.
  panel.style.setProperty(
    "--grow",
    (PANEL_WEIGHT[name] || 1) * (1 + Math.sqrt(Math.min(openCount, 36))));
  let doneHtml = "";
  if (doneList && doneList.length) {
    doneHtml = `<details class="done-group"><summary>done (${doneList.length})</summary>
      ${doneList.map(i => rowHtml(i, "due")).join("")}</details>`;
  }
  if (body) body.innerHTML = html + doneHtml;
}

/* ---------------- calendar ----------------
   Day: the timetable for one day, each class with what is due for it that
   day. Week: five (or seven) columns of the same. Both read the same
   `schedule` map from the class feed; nothing here is invented. */
/* How many rows the month cell is NOT showing. Each list is capped at two
   INDEPENDENTLY, so the count is per list — `dues + evs - 4` undercounts
   whenever one of them is short, and a board that understates what it is
   hiding is the thing spec §5.5 exists to prevent. */
/* An event's URL comes from a third party's calendar file, which is the first
   attacker-controllable link on this board — everything else comes from Canvas
   or Veracross. esc() stops markup but not a scheme, and `javascript:` in an
   href is a click away from running in this page. So the scheme is checked,
   and anything else renders as plain text rather than a link. */
function safeHref(url) {
  return typeof url === "string" && /^https?:\/\//i.test(url.trim());
}
/* The address itself when it is safe to link, else "#". [MEASURED] 2026-09-18
   from his install: "clicking most links opens to an error" — a tab at
   chrome-extension://…/true, ERR_FILE_NOT_FOUND. Ten links on the class page
   and the item pane put safeHref's answer straight into the href, and
   safeHref answers a yes/no, so every one of them linked to the word "true". The
   question ("may I link this?") and the answer ("link to this") are two
   functions now, and tests/test_class_setup.py refuses the first inside an
   href. */
function hrefOf(url) {
  return safeHref(url) ? url.trim() : "#";
}

function hiddenInCell(dues, events) {
  return Math.max(0, dues - 2) + Math.max(0, events - 2);
}

function dueOn(day) {
  return (STATE.items || []).filter(i => i.due_date === day && !personalSection(i));
}
function mondayOf(iso) {
  const d = new Date(iso + "T12:00:00");
  const back = (d.getDay() + 6) % 7;
  return isoPlus(iso, -back);
}
/* The 1st of the month `offset` months from today, as an ISO date. Built from
   the parts rather than by adding days, because months are 28-31 days long and
   "a month from the 31st" has no answer worth guessing. */
function monthStart(todayIso, offset) {
  const d = new Date(todayIso + "T12:00:00");
  const m = new Date(d.getFullYear(), d.getMonth() + (offset || 0), 1, 12);
  return `${m.getFullYear()}-${String(m.getMonth() + 1).padStart(2, "0")}-01`;
}

function renderSchedule() {
  const today = todayIso();
  const list = $("#schedule-list");
  const label = $("#day-label");
  if (!list || !label) return;
  document.querySelectorAll("[data-cal]").forEach((b) => b.classList.toggle("active", b.dataset.cal === CAL_MODE));
  const schedule = STATE.schedule || {};
  const now = STATE.now ? STATE.now.slice(11, 16) : "";
  const stale = staleNoteHtml(STATE.schedule_stale, "the last refresh could not read the class feed");
  const schedPanel = document.querySelector('[data-panel="schedule"]');

  if (CAL_MODE === "month") {
    /* *"make the calendar look like a calendar"* — a real grid, seven columns,
       weeks as rows. The day and week views are lists, which is right for the
       248px-wide dashboard column but is not what anyone means by a calendar.
       Month only earns its keep on a page that is the whole width, so the
       simple layout defaults to it and the dashboard keeps Day.

       SCHED_OFFSET counts MONTHS here, the way it counts days in Day and
       weeks in Week — the same three arrows drive all three. */
    const base = monthStart(today, SCHED_OFFSET);
    const first = new Date(base + "T12:00:00");
    label.textContent = first.toLocaleDateString(undefined, { month: "long", year: "numeric" })
      + (SCHED_OFFSET === 0 ? " · this month" : "");
    // Monday-first, and the grid always starts on the Monday on or before the
    // 1st so the columns line up with the weekday headings.
    const gridStart = mondayOf(base);
    const cells = [];
    for (let n = 0; n < 42; n++) {
      const iso = isoPlus(gridStart, n);
      if (n >= 35 && iso.slice(0, 7) !== base.slice(0, 7)) break;   // no empty 6th row
      cells.push(iso);
    }
    const names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    list.innerHTML = stale
      + `<div class="cal-head">${names.map((n) => `<span>${n}</span>`).join("")}</div>`
      + `<div class="cal-grid">` + cells.map((iso) => {
        const meetings = schedule[iso] || (iso === today ? STATE.meetings_today : null) || [];
        const dues = dueOn(iso).filter((i) => !i.done);
        const evs = eventsOn(iso);
        const outside = iso.slice(0, 7) !== base.slice(0, 7);
        const d = new Date(iso + "T12:00:00");
        return `<button type="button" class="cal-cell${iso === today ? " today" : ""}${outside ? " outside" : ""}"
            data-day="${esc(iso)}" title="${esc(niceDate(iso))} — ${meetings.length} class(es), ${dues.length} due${evs.length ? `, ${evs.length} on your calendar` : ""}">
          <span class="cal-n">${d.getDate()}</span>
          ${dues.length ? `<span class="cal-due">${dues.length}</span>` : ""}
          <span class="cal-dots">${meetings.slice(0, 6).map((m) =>
            `<i ${classStyle(m.course_key)}></i>`).join("")}</span>
          ${dues.slice(0, 2).map((i) => `<span class="cal-item ${esc(i.category)}"
             ${classStyle(i.course_key)}>${esc(i.title)}</span>`).join("")}
          ${evs.slice(0, 2).map((e) => `<span class="cal-item cal-event"
             title="${esc(e.date_note || "")}">${esc(EVENT_ICONS[e.kind] || EVENT_ICONS.event)} ${esc(e.title)}</span>`).join("")}
          ${hiddenInCell(dues.length, evs.length)
            ? `<span class="cal-more">+${hiddenInCell(dues.length, evs.length)} more</span>` : ""}
        </button>`;
      }).join("") + `</div>`;
    if (schedPanel) {
      const inMonth = cells.filter((c) => c.slice(0, 7) === base.slice(0, 7));
      const total = inMonth.reduce((sum, c) => sum + (schedule[c] || []).length, 0);
      schedPanel.querySelector(".schedule-day").textContent = String(total);
      schedPanel.classList.toggle("is-empty", false);
      schedPanel.style.setProperty("--grow", PANEL_WEIGHT.schedule * (1 + Math.sqrt(8)));
    }
    // Tapping a day opens that day, which is the whole point of a month view.
    list.querySelectorAll(".cal-cell").forEach((b) => b.addEventListener("click", () => {
      CAL_MODE = "day";
      SCHED_OFFSET = daysUntil(b.dataset.day, today);
      renderSchedule();
    }));
  } else if (CAL_MODE === "week") {
    const monday = mondayOf(isoPlus(today, SCHED_OFFSET * 7));
    const days = [];
    for (let n = 0; n < 7; n++) days.push(isoPlus(monday, n));
    const shown = days.filter((d, n) => n < 5 || PREFS.showWeekends
      || (schedule[d] || []).length || dueOn(d).length);
    const md = (iso) => new Date(iso + "T12:00:00").toLocaleDateString(undefined, { month: "short", day: "numeric" });
    label.textContent = `${md(monday)} – ${md(shown[shown.length - 1])}` + (SCHED_OFFSET === 0 ? " · this week" : "");
    list.innerHTML = stale + `<div class="week">` + shown.map((day) => {
      const meetings = schedule[day] || (day === today ? STATE.meetings_today : null) || [];
      const dues = dueOn(day);
      const evs = eventsOn(day);
      const d = new Date(day + "T12:00:00");
      return `<div class="week-day">
        <button type="button" class="week-head${day === today ? " today" : ""}" data-day="${esc(day)}"
                title="open this day">${esc(d.toLocaleDateString(undefined, { weekday: "short" }))}<b>${d.getDate()}</b></button>
        ${meetings.map((m) => `<button type="button" class="week-meet" data-course="${esc(m.course_key)}"
            ${classStyle(m.course_key)} title="${esc(shortCourse(m.course_raw))}${m.room ? " · " + esc(m.room) : ""}">${esc(nick(m.course_raw))}
            <small>${esc((m.start || "").slice(11, 16))}</small></button>`).join("")}
        ${dues.map((i) => `<button type="button" class="week-due ${esc(i.category)}${i.done ? " done-row" : ""}"
            data-id="${esc(i.item_id)}" title="${esc(i.title)} · ${esc(shortCourse(i.course))}">${esc(i.title)}</button>`).join("")}
        ${evs.map((e) => `<span class="week-event" title="${esc(e.date_note || "")}">${esc(EVENT_ICONS[e.kind] || EVENT_ICONS.event)} ${esc(e.title)}
            <small>${esc(eventTime(e))}</small></span>`).join("")}
        ${!meetings.length && !dues.length && !evs.length ? `<div class="week-none">—</div>` : ""}
      </div>`;
    }).join("") + `</div>`;
    const total = shown.reduce((s, d) => s + (schedule[d] || []).length, 0);
    if (schedPanel) {
      schedPanel.querySelector(".schedule-day").textContent = String(total);
      schedPanel.classList.toggle("is-empty", false);
      schedPanel.style.setProperty("--grow", PANEL_WEIGHT.schedule * (1 + Math.sqrt(6)));
    }
    list.querySelectorAll(".week-head").forEach((b) => b.addEventListener("click", () => {
      CAL_MODE = "day";
      SCHED_OFFSET = daysUntil(b.dataset.day, today);
      renderSchedule();
    }));
  } else {
    const day = isoPlus(today, SCHED_OFFSET);
    label.textContent = niceDate(day) + (SCHED_OFFSET === 0 ? " (today)" : SCHED_OFFSET === 1 ? " (tomorrow)" : "");
    const meetings = schedule[day] || (SCHED_OFFSET === 0 ? STATE.meetings_today : null) || [];
    const dues = dueOn(day);
    const dueFor = (key) => dues.filter(i => i.course_key === key && !i.done);
    list.innerHTML = stale + (meetings.length ? meetings.map((m) => {
      const start = (m.start || "").slice(11, 16);
      const end = (m.end || "").slice(11, 16);
      const current = SCHED_OFFSET === 0 && start && now >= start && now <= end;
      const past = SCHED_OFFSET === 0 && end && now > end;
      const due = dueFor(m.course_key);
      return `<button type="button" class="meeting${current ? " now" : ""}${past ? " past" : ""}" data-course="${esc(m.course_key)}"
          ${classStyle(m.course_key)} title="open ${esc(shortCourse(m.course_raw))}">
        <span class="when">${esc(start)}–${esc(end)}</span>
        <span class="what">${esc(nick(m.course_raw))}</span>
        <span class="where">${esc(m.room || "")}</span>
        ${due.length ? `<span class="due-badge">${due.length} due: ${esc(due.map(i => i.title).join(" · ").slice(0, 70))}</span>` : ""}</button>`;
    }).join("") : `<div class="empty-note">no classes ${SCHED_OFFSET === 0 ? "today" : "that day"}</div>`);
    const other = dues.filter(i => !meetings.some(m => m.course_key === i.course_key) && !i.done);
    if (other.length) {
      list.innerHTML += `<div class="group-label">also due</div>` + other.map(i =>
        `<button type="button" class="week-due ${esc(i.category)}" data-id="${esc(i.item_id)}" style="width:100%;font-size:.7rem;padding:3px 6px">${esc(i.title)} · ${esc(shortCourse(i.course))}</button>`).join("");
    }
    /* The rest of the day: what the connected calendars say is happening.
       Its own group under the timetable, because a practice is not a class
       period and putting it in the strip would make it look like one. */
    const dayEvents = eventsOn(day);
    if (dayEvents.length) {
      list.innerHTML += `<div class="group-label">also on your calendar</div>`
        + dayEvents.map(e => eventRowHtml(e, today)).join("");
    }
    if (schedPanel) {
      schedPanel.querySelector(".schedule-day").textContent = String(meetings.length);
      schedPanel.classList.toggle("is-empty",
        meetings.length === 0 && !dues.length && !eventsOn(day).length);
      // Earns height like the other boxes; without this it sat at the floor
      // showing one class of five.
      schedPanel.style.setProperty("--grow",
        PANEL_WEIGHT.schedule * (1 + Math.sqrt(Math.max(3, meetings.length + other.length))));
    }
  }
  list.querySelectorAll("[data-course]").forEach((b) => b.addEventListener("click", () => {
    if (window.openGradePane) window.openGradePane(b.dataset.course);
  }));
  list.querySelectorAll(".week-due").forEach((b) => b.addEventListener("click", () => openDetail(b.dataset.id)));
}
function setCalMode(mode) {
  CAL_MODE = ["week", "month"].includes(mode) ? mode : "day";
  SCHED_OFFSET = 0;
  savePrefs({ calendar: CAL_MODE });
  renderSchedule();
}

/* ---------------- grades (sidebar) ----------------
   Read from the Veracross portal. Two things this must never do: show an
   ungraded course as 0% (the portal reports exactly that), or compute a GPA
   (needs the school's scale and credit weights, which it does not publish). */
function gradeBand(percent) {
  if (percent == null) return "none";
  return percent >= 90 ? "a" : percent >= 80 ? "b" : percent >= 70 ? "c" : "d";
}
function renderGrades() {
  const panel = document.querySelector('[data-panel="grades"]');
  if (!panel) return;
  const grades = STATE.grades || [];
  const summary = STATE.grades_summary || {};
  const list = $("#grades-list");
  const badge = panel.querySelector(".grades-count");
  const sortBtn = $("#grades-sort");
  if (sortBtn) sortBtn.textContent = PREFS.gradeSort === "name" ? "\u21C5 a–z" : "\u21C5 lowest first";

  if (REMOTE) {
    panel.classList.add("is-empty");
    if (badge) badge.textContent = "";
    list.innerHTML = `<div class="empty-note">grades stay on your Mac — they are not part of this shared snapshot</div>`;
    return;
  }
  if (!grades.length) {
    panel.classList.add("is-empty");
    if (badge) badge.textContent = "";
    // "press Refresh" is only true when a refresh could actually help.
    const dead = (STATE.errors || []).find(e => e.code === "veracross_grades");
    const tried = (STATE.warnings || []).some(w => String(w).startsWith("grades:"));
    list.innerHTML = dead
      ? `<div class="empty-note">Veracross needs signing in again — grades cannot
         load until then. Refreshing will not fix it; see the banner above.</div>`
      : tried
      ? `<div class="empty-note">could not read your grades on the last refresh —
         the school portal did not load. Press Refresh to try again.</div>`
      : `<div class="empty-note">no grades read yet — press Refresh</div>`;
    return;
  }
  panel.classList.remove("is-empty");
  /* Height in proportion to how many courses there are, like the homework
     panels: ten rows must not be squeezed to two and a half. */
  panel.style.setProperty("--grow", (PANEL_WEIGHT.grades || 1) * (1 + Math.sqrt(Math.min(grades.length, 16))));
  if (badge) badge.textContent = `${summary.graded || 0}/${summary.courses || grades.length}`;

  /* A letter with no percentage ("A" on Studio Art, "P" on a pass/fail
     class) IS a grade. It used to land in "not graded yet", which told him a
     graded class had no grade. It is shown with its letter and no bar — a bar
     needs a number, and none is invented. (prosecution round 4, 2026-10-07) */
  const scored = grades.filter(g => g.graded && g.percent != null);
  const lettered = grades.filter(g => g.graded && g.percent == null);
  const pending = grades.filter(g => !g.graded);
  scored.sort(PREFS.gradeSort === "name"
    ? (a, b) => shortCourse(a.display_name).localeCompare(shortCourse(b.display_name))
    : (a, b) => a.percent - b.percent);
  lettered.sort((a, b) => shortCourse(a.display_name).localeCompare(shortCourse(b.display_name)));
  const openCount = (key) => (STATE.items || []).filter(i => i.course_key === key && !i.done).length;
  // Where a grade came from, so it can be opened at the source. The portal
  // gives a per-course link on some schools' pages and none on others, so this
  // falls back to the portal front page rather than a dead link.
  const portal = STATE.veracross_portal || "";
  const linkFor = (g) => g.detail_url || portal || "";
  const ext = (g) => linkFor(g)
    ? `<a class="grade-ext" href="${esc(linkFor(g))}" target="_blank" rel="noopener"
        title="open ${esc(shortCourse(g.display_name))} in Veracross" aria-label="open in Veracross">↗</a>` : "";
  const row = (g) => {
    const open = openCount(g.course_key);
    return `<div class="grade-row${SELECTED_CLASS === g.course_key ? " selected" : ""}" ${classStyle(g.course_key)}>
      <button type="button" class="grade-open" data-course="${esc(g.course_key)}"
        title="${esc(shortCourse(g.display_name))}${open ? ` · ${open} open` : ""} — every mark, and what each is worth">
        <span class="grade-course">${esc(nick(g.display_name))}</span>
        <span class="grade-letter band-${gradeBand(g.percent)}">${esc(g.letter || "")}</span>
        ${g.percent != null
          ? `<span class="grade-pct">${esc(g.percent.toFixed(1))}%</span>
        <span class="grade-bar"><i style="width:${Math.max(2, Math.min(100, g.percent))}%"></i></span>`
          : `<span class="grade-pct" title="Veracross shows a letter only for this class"></span>`}
        <span class="grade-go" aria-hidden="true">\u203A</span>
      </button>${ext(g)}</div>`;
  };
  const pendingRow = (g) => `<div class="grade-row pending" ${classStyle(g.course_key)}>
      <button type="button" class="grade-open" data-course="${esc(g.course_key)}">
        <span class="grade-course">${esc(nick(g.display_name))}</span>
        <span class="grade-none">${g.portal_text ? esc(g.portal_text) : "not graded yet"}</span></button>${ext(g)}</div>`;
  const mean = scored.length ? scored.reduce((t, g) => t + g.percent, 0) / scored.length : null;
  list.innerHTML =
    staleNoteHtml(STATE.grades_stale, "the last refresh could not read them") +
    scored.map(row).join("") + lettered.map(row).join("") +
    (pending.length ? `<details class="grade-pending"><summary>${pending.length} not graded yet</summary>${pending.map(pendingRow).join("")}</details>` : "") +
    (mean !== null && scored.length > 1
      ? `<div class="grade-summary-line" title="a plain average of the class percentages — not a GPA, which needs the school's scale and credit weights">avg ${mean.toFixed(1)}% · lowest ${scored[0] && PREFS.gradeSort !== "name" ? esc(shortCourse(scored[0].display_name)) : esc(shortCourse(scored.slice().sort((a, b) => a.percent - b.percent)[0].display_name))}</div>`
      : "");
  list.querySelectorAll(".grade-open").forEach((b) => b.addEventListener("click", () => {
    if (window.openGradePane) window.openGradePane(b.dataset.course);
  }));
}

/* ---------------- focus ----------------
   What deserves attention, worked out from the marks and the board — never a
   guess. Each line names its evidence, and each opens the class it is about.
   Rules kept from the strengths summary: two marks minimum before a kind is
   called weak, zeros flagged rather than averaged, and nothing here claims a
   kind is "dragging the grade down" — that needs weights. */
function focusAreas() {
  const today = todayIso();
  const items = (STATE.items || []).filter(i => !i.done && !personalSection(i));
  const grades = (STATE.grades || []).filter(g => g.graded && g.percent != null);
  const gradeOf = (key) => grades.find(g => g.course_key === key);
  const nameOf = (key) => {
    const g = (STATE.grades || []).find(x => x.course_key === key);
    const i = (STATE.items || []).find(x => x.course_key === key);
    const p = (STATE.profiles || []).find(x => x.course_key === key);
    return shortCourse((g && g.display_name) || (i && i.course) || (p && (p.display_name || p.course_raw)) || key);
  };
  const out = [];
  // 1. overdue work, by class
  const overdueBy = new Map();
  for (const i of items) {
    if (i.due_date && i.due_date < today && !isPastAssessment(i, today)) {
      overdueBy.set(i.course_key, (overdueBy.get(i.course_key) || 0) + 1);
    }
  }
  for (const [key, n] of [...overdueBy.entries()].sort((a, b) => b[1] - a[1])) {
    out.push({ icon: "!", urgent: true, course: key, weight: 100 + n,
               text: `${n} overdue in ${nameOf(key)}`, sub: "past its date and not ticked off" });
  }
  // 2. a weak kind of work, from real marks
  const byCourseKind = new Map();
  for (const s of STATE.scores || []) {
    // Only marks with a percent: an excused row (percent null) averaged in as
    // 0 made a kind look weak that was never marked, and extra credit (out of
    // 0) has no percent of its own. (prosecution round 4, 2026-10-07)
    if (typeof s.percent !== "number") continue;
    const k = `${s.course_key}|${s.category || "other"}`;
    if (!byCourseKind.has(k)) byCourseKind.set(k, []);
    byCourseKind.get(k).push(s);
  }
  const weak = [];
  for (const [k, marks] of byCourseKind) {
    if (marks.length < STRENGTH_MIN_MARKS) continue;
    const [course, kind] = k.split("|");
    const nonzero = marks.filter(m => m.percent > 0);
    const mean = marks.reduce((t, m) => t + m.percent, 0) / marks.length;
    const zeros = marks.length - nonzero.length;
    if (mean < 80) weak.push({ course, kind, mean, n: marks.length, zeros });
  }
  weak.sort((a, b) => a.mean - b.mean);
  for (const w of weak.slice(0, 3)) {
    out.push({ icon: "◔", course: w.course, weight: 80 - w.mean,
               text: `${nameOf(w.course)} · ${kindName(w.kind)} average ${w.mean.toFixed(0)}%`,
               sub: `over ${w.n} marks${w.zeros ? ` · ${w.zeros} scored 0 — missed, or not graded?` : ""}` });
  }
  // 3. a test or quiz soon in a class under 90
  for (const i of items) {
    if (!HEAVY.has(i.category) || !i.due_date) continue;
    const days = daysUntil(i.due_date, today);
    if (days === null || days < 0 || days > 7) continue;
    const g = gradeOf(i.course_key);
    if (!g || g.percent >= 90) continue;
    out.push({ icon: "◆", item: i.item_id, course: i.course_key, weight: 60 - days,
               text: `${i.category} ${relDays(i.due_date, today)} in ${nameOf(i.course_key)}`,
               sub: `${i.title.slice(0, 60)} · class at ${g.percent.toFixed(1)}%` });
  }
  // 4. the lowest graded class with work open
  const lowest = grades.filter(g => items.some(i => i.course_key === g.course_key))
    .sort((a, b) => a.percent - b.percent)[0];
  if (lowest && lowest.percent < 93 && !out.some(o => o.course === lowest.course_key)) {
    const n = items.filter(i => i.course_key === lowest.course_key).length;
    out.push({ icon: "▽", course: lowest.course_key, weight: 40,
               text: `${nameOf(lowest.course_key)} is your lowest at ${lowest.percent.toFixed(1)}%`,
               sub: `${n} thing${n === 1 ? "" : "s"} open there — the board already ranks them higher` });
  }
  out.sort((a, b) => b.weight - a.weight);
  return out.slice(0, 6);
}
function renderFocus() {
  const panel = document.querySelector('[data-panel="focus"]');
  const list = $("#focus-list");
  if (!panel || !list) return;
  const areas = REMOTE ? [] : focusAreas();
  const badge = panel.querySelector(".focus-count");
  if (badge) { badge.textContent = String(areas.length); badge.classList.toggle("zero", !areas.length); }
  panel.classList.toggle("is-empty", !areas.length);
  panel.style.setProperty("--grow", (PANEL_WEIGHT.focus || 1) * (1 + Math.sqrt(areas.length)));
  list.innerHTML = areas.length ? areas.map((a) => `
    <button type="button" class="focus-row${a.urgent ? " urgent" : ""}" data-course="${esc(a.course || "")}" data-item="${esc(a.item || "")}"
            title="${esc(a.sub || a.text)}">
      <span class="focus-icon">${esc(a.icon)}</span>
      <span class="focus-text">${esc(a.text)}${a.sub ? `<small>${esc(a.sub)}</small>` : ""}</span></button>`).join("")
    : `<div class="empty-note">nothing stands out — keep going ✓</div>`;
  list.querySelectorAll(".focus-row").forEach((b) => b.addEventListener("click", () => {
    if (b.dataset.item) openDetail(b.dataset.item);
    else if (b.dataset.course && window.openGradePane) window.openGradePane(b.dataset.course);
  }));
}

/* Shared with the grade pane in views.js. */
const STRENGTH_MIN_MARKS = 2;
const GRADE_KINDS = ["test", "quiz", "project", "essay", "problem_set",
                     "reading", "discussion", "other"];
/* "quiz" pluralises to "quizzes", not "quizs". He calls problem sets,
   worksheets and notes "homework", so that is the word the grade page uses. */
const PLURALS = { quiz: "quizzes", essay: "essays", test: "tests",
                  project: "projects", reading: "readings",
                  problem_set: "homework", discussion: "discussions",
                  assignment: "assignments", other: "other work" };
const kindName = (kind) => PLURALS[kind]
  || String(kind).replace("_", " ") + (String(kind).endsWith("s") ? "" : "s");
/* 18 rather than 18.0, but 17.5 stays 17.5 — points are sometimes halves. */
const trimNum = (n) => Number(n).toFixed(2).replace(/\.?0+$/, "");
window.SD = { gradeBand, kindName, trimNum, STRENGTH_MIN_MARKS, GRADE_KINDS, classColor,
              relDays, minutesLabel, isPastAssessment, personalSection, rowHtml, studyHint };

/* ---------------- the brief ----------------
   The top of the conversation answers one question — "what do I do first?" —
   with a single item. The pick is whatever the pipeline ranked highest
   (scoring.py); never a second opinion computed here. */
function focusItem(open) {
  let best = null;
  for (const item of open) {
    if (!best || (item.score || 0) > (best.score || 0)) best = item;
  }
  return best;
}

/* Canvas names a link after the assignment, so link.text is usually the item
   title character-for-character. The label says where the link goes instead. */
const LINK_LABELS = {
  canvas: "Open in Canvas",
  assignment: "Open the assignment",
  google_doc: "Open the Doc",
  google_form: "Open the Form",
  google_slides: "Open the Slides",
  ap_classroom: "AP Classroom",
  google_classroom: "Google Classroom",
};
function linkLabel(link, item) {
  const text = (link.text || "").trim();
  const title = (item.title || "").trim();
  const dup = text && title
    && text.toLowerCase().replace(/\s+/g, " ") === title.toLowerCase().replace(/\s+/g, " ");
  if (link.courseWide && LINK_LABELS[link.kind]) return LINK_LABELS[link.kind];
  if (!text || dup) return LINK_LABELS[link.kind] || "Open link";
  return text;
}

/* Why this one is first, in words, when the ranking used the class's grade to
   decide. Shared by the brief's card and by the To-do row, so the two can
   never give different reasons for the same choice. The percentage is read
   from the same place the Grades list reads it — the card cannot claim a mark
   the board does not hold. Empty when the grade played no part. */
function focusWhy(item) {
  if (!item) return "";
  const classGrade = (STATE.grades || []).find(
    g => g.course_key === item.course_key && g.graded && g.percent != null);
  if (!classGrade || !/weaker class|behind in/.test(item.reason || "")) return "";
  return `first because ${esc(shortCourse(item.course))} is your `
    + `lowest graded class with work due — ${esc(classGrade.percent.toFixed(1))}%`;
}

/* The one thing to start with. One function, so the brief and the To-do list
   cannot disagree: they used to call focusItem() with differently filtered
   lists, which was two answers waiting to happen. */
function currentFocus() {
  return focusItem((STATE.items || []).filter((i) => !i.done && !personalSection(i)));
}

function focusCardHtml(item, today) {
  if (!item) {
    return `<div class="focus-card is-clear">
      <div class="focus-kicker">nothing open</div>
      <div class="focus-title">All caught up ✓</div>
      <div class="focus-sub">every item on the board is ticked off.</div></div>`;
  }
  const past = isPastAssessment(item, today);
  const overdue = item.due_date && item.due_date < today && !past;
  const bits = [dueLabel(item), shortCourse(item.course)];
  if (item.est_label) bits.push(item.est_label);
  /* Why this one, when the class's grade is part of the answer. The grade is
     read from the same place the Grades list reads it, so the card cannot
     claim a mark the board does not hold. */
  const why = focusWhy(item);
  const link = (item.links || [])[0];
  return `<div class="focus-card${overdue ? " is-overdue" : ""}">
    <div class="focus-kicker">${past ? "this one has already happened"
      : overdue ? "overdue — start here" : "start here"}</div>
    <div class="focus-title">${esc(item.title)}</div>
    <div class="focus-sub">${bits.map(esc).join(" · ")}</div>
    ${why ? `<div class="focus-why">${why}</div>` : ""}
    ${item.date_note ? `<div class="focus-note">${esc(item.date_note)}</div>` : ""}
    <div class="focus-actions">
      <button class="focus-open" type="button">Details</button>
      ${link ? `<a class="linkbtn ${esc(link.kind || "")}" href="${esc(link.url)}" target="_blank" rel="noopener">${esc(linkLabel(link, item))}</a>` : ""}
      ${REMOTE ? "" : `<button class="focus-done primary" type="button">Mark done</button>`}
    </div></div>`;
}

function renderHero() {
  const host = $("#hero-body");
  if (!host) return;
  const { out, today, tomorrow } = sections();
  const dueTomorrow = out.tomorrow.open.filter(i => i.due_date === tomorrow).length;
  const overdue = out.tomorrow.open.filter(
    i => i.due_date < today && !isPastAssessment(i, today)).length;
  const tests = out.upcoming.open.filter(i => ["test", "quiz"].includes(i.category)).length;
  const totalMinutes = out.tomorrow.open.filter(i => !isPastAssessment(i, today))
    .reduce((s, i) => s + (i.est_minutes || 0), 0);
  const nowMeetings = (STATE.meetings_today || []);
  const nowStr = STATE.now ? STATE.now.slice(11, 16) : "";
  const next = nowMeetings.find(m => (m.start || "").slice(11, 16) > nowStr);
  const focus = currentFocus();

  /* One line, not three tiles: a count of zero is good news and reads better
     as an absence than as a number. */
  const counts = [
    overdue ? `<b class="tone-urgent">${overdue}</b> overdue` : "",
    dueTomorrow ? `<b>${dueTomorrow}</b> due tomorrow` : "",
    tests ? `<b>${tests}</b> test${tests === 1 ? "" : "s"} &amp; quizzes ahead` : "",
    totalMinutes ? `<b>${esc(minutesLabel(totalMinutes))}</b> by tomorrow` : "",
  ].filter(Boolean);
  if (next) {
    counts.push(`next <b>${esc(nick(next.course_raw))}</b> ${esc((next.start || "").slice(11, 16))}${next.room ? " · " + esc(next.room) : ""}`);
  }
  // The nudge names the most urgent thing to revise — unless that is already
  // the card above it, in which case saying it twice is just noise.
  const soon = nextStudy(STATE);
  const nudge = soon && (!focus || soon.item.item_id !== focus.item_id)
    ? `<div class="study-nudge">📚 <strong>${esc(nick(soon.item.course))}</strong>
        ${esc(soon.hint)} — ${esc(soon.item.title)}</div>` : "";
  host.innerHTML = `
    <div class="hero-line">${counts.length
      ? counts.join(`<span class="dot">·</span>`)
      : "nothing overdue, nothing due tomorrow \u2713"}</div>
    ${focusCardHtml(focus, today)}
    ${nudge}`;

  if (focus) {
    const card = host.querySelector(".focus-card");
    const details = card && card.querySelector(".focus-open");
    if (details) details.addEventListener("click", () => openDetail(focus.item_id));
    const done = card && card.querySelector(".focus-done");
    if (done) done.addEventListener("click", () => toggleDone(focus.item_id, true));
  }
}

/* ---------------- panes ----------------
   One pane shows at a time in the centre. Everything that opens something —
   a row, a grade, a meeting, a focus line — comes through here. */
/* "home" is the greeting and the priority cards — the board's own front,
   and its own pane rather than a mode of the chat pane, because
   `ui.open_with` lets the middle open on either one. */
const PANES = ["home", "work", "grades", "classlist", "life", "calendar", "chat", "chat-history", "item", "grade", "accel", "quiz", "done", "add", "more", "classes", "settings", "setup"];
function paneElement(name) {
  return document.getElementById(["classes", "settings", "setup"].includes(name) ? `view-${name}` : `pane-${name}`);
}
function showPane(name) {
  if (!PANES.includes(name)) name = "home";
  if (REMOTE && !["home", "chat", "item", "done"].includes(name)) name = "home";
  PANE = name;
  renderPreviousChats();
  for (const p of PANES) {
    const el = paneElement(p);
    if (el) el.hidden = p !== name;
  }
  document.querySelectorAll("#view-nav button").forEach((b) =>
    b.classList.toggle("active", b.dataset.view === name));
  const dockBtn = $("#dock-chat");
  if (dockBtn) dockBtn.hidden = name === "chat";
  /* The greeting's big "Chat" label goes to `visibility: hidden` rather than
     out of the layout when the middle is showing something else, so the dock
     keeps exactly the same height and nothing on the board moves. */
  document.body.classList.toggle("home", name === "home");
  document.body.dataset.pane = name;
  const extra = $("#home-extra");
  if (extra) extra.hidden = !(name === "home" && simpleLook() && STATE);
  /* A class or Settings takes the WHOLE screen. [ASKED] 2026-09-18. So does
     the Calendar: [ASKED] 2026-10-06 "take up the whole page". The
     columns are hidden, not unmounted, so the geometry they come back to is
     the geometry they left. */
  const full = ["grade", "settings", "classes", "setup", "done", "work", "calendar"].includes(name)
    || simpleLook();          // the simple look has no side columns at all
  const board = $("main.studio");
  if (board) board.classList.toggle("fullpage", full);
  document.body.classList.toggle("fullpage", full);
  /* The page that just opened plays the transition chosen in Settings; the
     class is removed when the animation ends so the next open plays it again.
     [ASKED] 2026-09-18: "add transition types and strengths to settings". */
  const shownEl = paneElement(name);
  if (shownEl && (UI.motion || "auto") !== "off") {
    shownEl.classList.remove("entering");
    void shownEl.offsetWidth;
    shownEl.classList.add("entering");
    const done = () => shownEl.classList.remove("entering");
    shownEl.addEventListener("animationend", done, { once: true });
    setTimeout(done, 600);   // reduced-motion plays no animation and fires no end
  }
  if (name === "home" || name === "chat") {
    setChatContext(null);
    if (SELECTED) SELECTED = null;
    if (SELECTED_CLASS) SELECTED_CLASS = null;
    const log = $("#chat-log");
    if (log && name === "chat") log.scrollTop = log.scrollHeight;
  }
  if (name !== "item" && SELECTED) SELECTED = null;
  if (name !== "grade" && SELECTED_CLASS) SELECTED_CLASS = null;
  /* One repaint of the sections, after the selection has settled — the class
     strip and the Assignments bands both light up the open class. Calling
     renderPanels()/renderGrades() here (which is what 0.18 did) redrew boxes
     that no longer exist and did nothing about the ones that do. */
  try { if (STATE) renderStudio(); } catch (err) { console.error("SillyBus AI: board", err); }
  /* The strip follows the pane. A detail pane — an assignment, the study
     guide, the add form — has no tab of its own and leaves lit whichever tab
     it was opened from, which is where the back button goes. */
  try {
    const lit = tabForView(name);
    if (lit) OPEN_TAB = lit;
    renderTabStrip();
  } catch (err) { /* before the strip exists */ }
  // Settings is not "about" the assignment that was open a moment ago. Only
  // the panes that set a context of their own keep one.
  if (!["item", "grade", "accel"].includes(name) && CHAT_CONTEXT && !CHAT_CONTEXT.sticky) setChatContext(null);
  document.body.classList.toggle("setup-mode", name === "setup");
  /* In the simple layout the centre column is hidden unless its tab is open,
     so a pane opened by DOING something — tapping an assignment on Today,
     tapping a class on Grades — would render into a hidden column and look
     like nothing happened. Bring the centre forward, and light up the tab
     this pane belongs to when it has one. */
  /* In the simple layout the visible column must always match the open page.
     showPane may only take the screen when it is opening something that HAS no
     page of its own — an assignment, a class grade, the study guide, the add
     form — or when it is the current page's own pane.

     [MEASURED] 2026-09-10: it used to take the screen and adopt the pane's tab
     unconditionally, and `showPane("chat")` is the reset target used all over
     the app — including once during boot. So the app opened on Chat however
     the saved page was set, and the To-do list he had left open was replaced
     by the conversation. Deliberate navigation to a page goes through
     showTab(), which is the only thing allowed to change which page is open. */
  if (isSimple() && !TAB_SWITCHING) {
    const owner = tabForPane(name);
    const isDetail = !owner;
    if (isDetail || owner === PREFS.tab) {
      for (const sel of ["#col-left", "#col-center", "#col-right"]) {
        const col = document.querySelector(sel);
        if (col) col.classList.toggle("tab-on", sel === "#col-center");
      }
      document.documentElement.setAttribute("data-tab", PREFS.tab);
      renderTabs();
    }
  }
  if (window.onPaneShown) window.onPaneShown(name);
}
window.showPane = showPane;
window.currentPane = () => PANE;
/* The grade pane (views.js) owns which class is open; the sidebar row just
   has to light up and the item selection has to clear. */
window.selectClass = (key) => {
  SELECTED_CLASS = key || null;
  SELECTED = null;
  renderGrades();
  renderPanels();
};

function openDetail(itemId) {
  SELECTED = itemId;
  SELECTED_CLASS = null;
  renderDetail(itemId);
  renderPanels();
  renderGrades();
}
window.openDetail = openDetail;

/* An extractive preview keeps the teacher's words; opening an assignment
   does not need an AI call or guess at missing requirements. */
function assignmentInstructionsHtml(item) {
  const full = String(item.description || "").trim();
  if (!full) return item.source === "canvas" ? `<section class="detail-instructions"><h4>What to do</h4><p class="muted">This saved assignment has no instructions yet. Open the original in Canvas for the full details.</p></section>` : "";
  const chunks = full.split(/\n+|(?<=[.!?;])\s+(?=[A-Z0-9])/).map(s => s.replace(/\s+/g," ").trim()).filter(Boolean);
  const ranked = chunks.map((text,index) => ({text,index,score:
    (/\b(submit|upload|turn in|hand in|deliver)\b/i.test(text) ? 40 : 0) +
    (/\b(include|must|required|do not|minimum|at least|words?|pages?|format|rubric|every)\b/i.test(text) ? 30 : 0) +
    (/\b(read|write|complete|answer|create|watch|solve|finish|prepare|review|record|take|bring|choose|explain|show|calculate)\b/i.test(text) ? 20 : 0)}));
  const useful = ranked.filter(x => x.score > 0).sort((a,b) => b.score-a.score || a.index-b.index);
  const selected = (useful.length ? useful : ranked).slice(0,3).sort((a,b) => a.index-b.index);
  const preview = text => {
    if (text.length <= 200) return text;
    const part = text.slice(0,200), end = part.lastIndexOf(" ");
    return part.slice(0,end > 150 ? end : 200) + "…";
  };
  return `<section class="detail-instructions"><h4>What to do</h4>
    <ul>${selected.map(x => `<li>${esc(preview(x.text))}</li>`).join("")}</ul>
    <small class="muted">${item.source === "canvas" ? "Highlights from Canvas instructions" : "Highlights from the assignment instructions"}</small>
    <details><summary>Read all instructions</summary><div class="full-text">${esc(full)}</div></details></section>`;
}

function renderDetail(itemId) {
  const item = (STATE.items || []).find(i => i.item_id === itemId);
  if (!item) { closeDetail(); return; }
  showPane("item");
  SELECTED = itemId;
  // The course, not the word "Details": which class this belongs to is the
  // thing that orients you.
  $("#detail-title").textContent = shortCourse(item.course) || "Details";
  const profile = (STATE.profiles || []).find(p => p.course_key === item.course_key);
  const perCourse = ((STATE.diagnostics || {}).per_course || {})[item.course_key] || {};
  const resources = [...(item.links || [])];
  const seen = new Set(resources.map(l => l.url));
  for (const link of (perCourse.course_links || [])) {
    if (!seen.has(link.url) && ["ap_classroom", "google_doc", "canvas"].includes(link.kind)) {
      resources.push({ ...link, courseWide: true });
      seen.add(link.url);
    }
  }
  if (profile && profile.canvas_url && !seen.has(profile.canvas_url)) {
    resources.push({ url: profile.canvas_url, text: "Canvas course page",
                     kind: "canvas", courseWide: true });
  }
  // [MEASURED] 2026-09-04: the course links and the profile both offered the
  // Canvas course page, so "Open in Canvas ·course" was drawn twice. One label,
  // one button.
  const seenLabels = new Set();
  const linkBtns = resources.map((l) => {
    const label = l.kind === "ap_classroom" ? "AP Classroom"
      : (l.courseWide ? linkLabel(l, item) : (l.text || l.kind)).slice(0, 34);
    const key = `${label}|${l.courseWide ? "c" : "i"}`;
    if (seenLabels.has(key)) return "";
    seenLabels.add(key);
    return `<a class="linkbtn ${esc(l.kind)}" target="_blank" rel="noopener" href="${esc(hrefOf(l.url))}"
       >${esc(label)}${l.courseWide ? " ·course" : ""}</a>`;
  }).join("");
  /* One copy of the sentence, not two: a doc item's title is the sentence
     trimmed to 110 characters and its detail is the SAME sentence in full.
     When the detail is just the untruncated title, it BECOMES the title. */
  const trimmed = (item.title || "").replace(/…$/, "").trim();
  const detailIsFullerTitle = !!item.detail && !!trimmed
    && item.detail.length > (item.title || "").length
    && item.detail.includes(trimmed);
  const headline = detailIsFullerTitle ? item.detail : item.title;
  const extraText = item.detail && item.detail !== item.title && !detailIsFullerTitle
    ? item.detail : "";
  const today = todayIso();
  const grade = (STATE.grades || []).find(g => g.course_key === item.course_key && g.graded && g.percent != null);
  const siblings = (STATE.items || []).filter(i => i.course_key === item.course_key && i.item_id !== item.item_id && !i.done)
    .sort((a, b) => (a.due_date || "9999") < (b.due_date || "9999") ? -1 : 1).slice(0, 6);
  /* When it is due comes FIRST, then how that date was worked out, then the
     assignment's own words. The sentence can be long and is free to scroll;
     the date cannot afford to. */
  $("#detail-body").innerHTML = `
    <div class="detail-course"><span class="chip" ${classStyle(item.course_key)}>${esc(nick(item.course))}</span>
      <span class="tag ${esc(item.category)}">${esc(item.category)}</span>
      ${grade ? `<span class="grade-letter band-${gradeBand(grade.percent)}" title="your grade in this class">${esc(grade.letter || "")} ${esc(grade.percent.toFixed(1))}%</span>` : ""}
      <span class="kv">${esc(item.kind || item.source)}${item.points != null ? ` · ${esc(item.points)} pts` : ""}${item.est_label ? ` · ${esc(item.est_label)}` : ""}</span></div>
    <div class="due-line detail-due">${esc(dueLabel(item))}${item.due_date ? ` <span class="kv">· ${esc(relDays(item.due_date, today))}</span>` : ""}</div>
    ${assignedLineHtml(item)}
    <div class="note-line">${esc(item.date_note)}${item.confidence !== "high" ? ` (confidence: ${esc(item.confidence)})` : ""}</div>
    ${repeatLineHtml(item)}
    ${dupLineHtml(item)}
    <div class="due-line detail-headline">${esc(headline)}</div>
    ${extraText ? `<div class="full-text">${esc(extraText)}</div>` : ""}
    ${assignmentInstructionsHtml(item)}
    ${linkBtns ? `<div class="linkbtns">${linkBtns}</div>`
      : `<div class="kv">no links in this entry</div>`}
    ${REMOTE ? "" : `<div class="detail-section work-section">
      <h4>Check my work</h4>
      <div id="work-body" class="wc-body"></div>
    </div>`}
    ${item.raw_cell && item.raw_cell !== item.detail
      ? `<details><summary class="kv">exactly what the doc said</summary>
         <div class="full-text">${esc(item.raw_cell)}</div></details>` : ""}
    ${!REMOTE && window.courseMaterialsHtml ? window.courseMaterialsHtml(item.course_key) : ""}
    ${siblings.length ? `<div class="detail-section"><h4>also open in ${esc(shortCourse(item.course))}</h4>
      ${siblings.map(i => rowHtml(i, "sibling")).join("")}</div>` : ""}
    <div class="detail-actions">
      <button id="detail-done" class="primary">${item.done ? "Undo done" : "Mark done"}</button>
      ${REMOTE || item.done ? "" : `<button id="detail-accel" class="accel-btn"
          title="a condensed version, the key ideas, and how to do the work — from the actual material">⚡ Accelerate</button>
        <button id="detail-quiz" class="ghost" title="a practice quiz on this, in your teacher's style">📝 Practice quiz</button>`}
      ${REMOTE ? "" : `<button id="detail-ask" class="ghost">Ask about this</button>`}
      ${grade || !REMOTE ? `<button id="detail-class" class="ghost">Class grades</button>` : ""}
      ${item.source === "custom" && !REMOTE
        ? `<button id="detail-delete" class="ghost">Remove</button>` : ""}
    </div>`;
  $("#detail-done").onclick = () => toggleDone(item.item_id, !item.done);
  const accel = $("#detail-accel");
  if (accel) accel.onclick = () => {
    if (window.openAccelerate) window.openAccelerate(item.item_id, item.title);
  };
  const quiz = $("#detail-quiz");
  if (quiz) quiz.onclick = () => {
    if (window.openQuiz) window.openQuiz(item.course_key, item.item_id);
  };
  const ask = $("#detail-ask");
  if (ask) ask.onclick = () => {
    setChatContext({ itemId: item.item_id, label: item.title.slice(0, 50), sticky: true });
    const input = $("#chat-input");
    input.placeholder = `ask about “${item.title.slice(0, 40)}”…`;
    input.focus();
  };
  const cls = $("#detail-class");
  if (cls) cls.onclick = () => { if (window.openGradePane) window.openGradePane(item.course_key); };
  const del = $("#detail-delete");
  if (del) del.onclick = async () => {
    await fetch(`/api/tasks/${item.item_id}`, { method: "DELETE" });
    closeDetail();
    await loadState();
  };
  $("#detail-body").querySelectorAll(".row-open").forEach((b) =>
    b.addEventListener("click", () => openDetail(b.dataset.id)));
  $("#detail-body").querySelectorAll(".row-accel").forEach((b) =>
    b.addEventListener("click", () => {
      const sib = (STATE.items || []).find(i => i.item_id === b.dataset.id);
      if (sib && window.openAccelerate) window.openAccelerate(sib.item_id, sib.title);
    }));
  $("#detail-body").querySelectorAll(".tick").forEach((tick) =>
    tick.addEventListener("click", () => toggleDone(tick.dataset.id, tick.checked)));
  /* The photo box, after the rest of the pane exists: it fetches its own
     pages, so it must not be built before its host element is in the DOM. */
  if (!REMOTE && window.mountWorkCheck) window.mountWorkCheck(item.item_id);
  if (!REMOTE) setChatContext({ itemId: item.item_id, label: item.title.slice(0, 50) });
}

function closeDetail() {
  SELECTED = null;
  // A live camera preview must not survive the pane that opened it — the
  // green light staying on after you leave is alarming and correct to fix.
  if (window.unmountWorkCheck) window.unmountWorkCheck();
  /* Back goes to the page it was opened FROM in the simple layout. Sending
     someone to the chat because they closed an assignment they tapped on
     Today throws away where they were — and the three back buttons in the
     app must not disagree about what back means. */
  if (isSimple()) showTab(PREFS.tab && PREFS.tab !== "chat" ? PREFS.tab : "todo");
  else showPane("chat");
  renderPanels();
}

/* ---------------- done ---------------- */
async function toggleDone(itemId, done) {
  if (REMOTE) {
    localTicks.set(itemId, done);
    const item = (STATE.items || []).find(i => i.item_id === itemId);
    if (item) item.done = done;
    render();
    return;
  }
  /* A tick that did not save says so (prosecution round 2, 2026-10-07): a
     401 or a 500 used to drop it silently, and the row snapped back on the
     next load as if he had never ticked it. */
  let saved = false;
  try {
    const res = await fetch("/api/done", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ item_id: itemId, done }),
    });
    saved = res.ok;
  } catch (e) { saved = false; }
  await loadState();
  // After the reload, which redraws the banners: shown until the next one.
  const box = $("#banners");
  if (!saved && box) {
    box.insertAdjacentHTML("afterbegin",
      `<div class="banner warn">That tick did not save — try again, or check SillyBus is still running.</div>`);
  }
}
window.toggleDone = toggleDone;

/* ---------------- chat ---------------- */
/* What the next question is about. Set while an item or a class is open in
   the pane; the dock shows it so nothing is sent with a hidden context. */
let CHAT_CONTEXT = null;
function setChatContext(ctx) {
  CHAT_CONTEXT = ctx;
  const box = $("#chat-context");
  const name = $("#chat-context-name");
  const input = $("#chat-input");
  if (!box || !name) return;
  box.hidden = !ctx;
  if (ctx) name.textContent = ctx.label;
  if (input) {
    if (ctx) input.placeholder = `ask about “${ctx.label.slice(0, 36)}”…`;
    else if (!(STATE && (STATE.provider === "null" || STATE.provider === "none"))) {
      input.placeholder = "what should I do first tonight?";
    }
  }
}
window.setChatContext = setChatContext;

/* An answer's citations are for the app, not for him. [MEASURED] 2026-09-10:
   a lookup answer read `• Quiz 3 [0dd4d1d0b4aecbba] — Thu 03 Sep` on his
   screen. That id is what `grounding.py` checks the answer against, and the
   check has already run by the time a bubble renders — so the id rides in on
   the text and goes out as the thing it names: a tap that opens the
   assignment. Stripping it and dropping it would have been easier and worse,
   because a line that names your homework should be able to open it.

   Only an id the board actually holds becomes a button; an id that matches
   nothing is removed rather than offered, so a tap can never dead-end. */
function chatHtml(text) {
  const cite = /\s*\[([0-9a-f]{8,40})\]/g;
  /* STATE is null until the first load lands, and the saved conversation is
     replayed at boot — so this runs with no board at all. [MEASURED]
     2026-09-10: reading STATE.items there threw, loadChatHistory swallowed it,
     and every earlier question vanished from the log. With no board, no line
     gets a button; the text still reads correctly, which is the part that
     matters. */
  const known = new Set(((STATE || {}).items || []).map((i) => i.item_id));
  return String(text == null ? "" : text).split("\n").map((line) => {
    const ids = [...line.matchAll(cite)].map((m) => m[1]).filter((id) => known.has(id));
    const body = esc(line.replace(cite, ""));
    const go = ids.length === 1
      ? ` <button type="button" class="cite" data-item="${esc(ids[0])}"
          title="open this assignment">open \u203A</button>` : "";
    return `<div class="chat-line">${body}${go}</div>`;
  }).join("");
}

/* One handler for every bubble there will ever be, wired once. */
function wireChatCites() {
  const log = $("#chat-log");
  if (!log) return;
  log.addEventListener("click", (event) => {
    const button = event.target.closest(".cite");
    if (button && button.dataset.item) openDetail(button.dataset.item);
  });
}

/* Previous questions, replayed on load. Stored on their own Mac
   (db.chat_messages), trimmed to the last 200 rather than kept forever. */
async function loadChatHistory() {
  const logBox = $("#chat-log");
  if (!logBox || REMOTE) return;
  try {
    const res = await fetch("/api/chat/history?limit=40");
    const out = await res.json();
    const messages = out.messages || [];
    /* The left column's "Recent chats" reads the SAME history this replays,
       newest first, so the two can never disagree about what was asked. */
    CHAT_RECENT = messages.filter((m) => m.role === "user").reverse();
    CHAT_PAIRS = [];
    for (let n = 0; n < messages.length; n++) {
      if (messages[n].role !== "user") continue;
      const reply = messages[n + 1];
      CHAT_PAIRS.unshift({ q: messages[n].text,
                           a: reply && reply.role !== "user" ? reply.text : "" });
    }
    try { renderStudio(); } catch (err) { /* the board is already drawn */ }
    if (simpleLook()) { showChatEmpty(); return; }
    if (!messages.length) { showChatEmpty(); return; }
    const parts = [`<div class="chat-earlier">earlier questions</div>`];
    for (const message of messages) {
      const when = (message.at || "").slice(11, 16);
      if (message.role === "user") {
        parts.push(`<div class="msg user">${esc(message.text)}</div>`);
      } else {
        const grounded = (message.meta || {}).grounded;
        parts.push(`<div class="msg assistant">${chatHtml(message.text)}`
          + (grounded === false
              ? `<div class="grounding warn">was not fully checked</div>` : "")
          + (when ? `<div class="msg-when">${esc(when)}</div>` : "")
          + `</div>`);
      }
    }
    logBox.insertAdjacentHTML("afterbegin", parts.join(""));
    redrawPendingProposal();
    logBox.scrollTop = logBox.scrollHeight;
  } catch (err) {
    /* no history is not an error worth a message in the log */
  }
}
function showChatEmpty() {
  const logBox = $("#chat-log");
  if (!logBox || logBox.children.length) return;
  logBox.innerHTML = `<div class="chat-empty">Ask anything about your work — <b>what should I do first?</b>,
    <b>how do I bring up Biology?</b>, <b>what room is Spanish in?</b> — or tell me something a
    teacher said and I will offer to add it. Click an assignment or a class on either side and
    ask about that.</div>`;
}

/* The history pane: every saved turn, newest day first, with a search box.
   *"i want a chat history"* — the chat pane replays the last 40 messages
   above the conversation, which is a memory, not a record. This is the
   record: grouped by day, searchable (the server keeps a question and its
   answer together), up to the last 1,000 messages. */
let HISTORY_LIMIT = 120;
let HISTORY_TIMER = null;
async function renderChatHistory() {
  const body = $("#chat-history-body");
  if (!body) return;
  const q = ($("#chat-history-search") || {}).value || "";
  body.innerHTML = `<div class="muted" style="padding:8px">loading…</div>`;
  let out;
  try {
    const res = await fetch(`/api/chat/history?limit=${HISTORY_LIMIT}&q=${encodeURIComponent(q.trim())}`);
    out = await res.json();
  } catch (err) {
    body.innerHTML = `<div class="muted" style="padding:8px">could not load the history</div>`;
    return;
  }
  // Newest TURN first, but a question stays above its answer: pair each user
  // message with the assistant messages that follow it, then reverse the pairs.
  const turns = [];
  for (const m of out.messages || []) {
    if (m.role === "user" || !turns.length) turns.push([m]); else turns[turns.length - 1].push(m);
  }
  const messages = turns.reverse().flat();
  const count = $("#chat-history-count");
  if (count) count.textContent = out.total ? `${out.total} message${out.total === 1 ? "" : "s"} saved` : "";
  if (!messages.length) {
    body.innerHTML = `<div class="chat-empty">${q.trim() ? "Nothing matches that." : "No questions yet. Ask anything in the chat and it is kept here."}</div>`;
    return;
  }
  const parts = [];
  let day = "";
  for (const m of messages) {
    const at = m.at || "";
    const thisDay = at.slice(0, 10);
    if (thisDay !== day) {
      day = thisDay;
      parts.push(`<div class="history-day">${esc(niceDate(thisDay))}</div>`);
    }
    const when = at.slice(11, 16);
    if (m.role === "user") {
      parts.push(`<div class="history-turn"><div class="msg user">${esc(m.text)}</div>${when ? `<div class="msg-when">${esc(when)}</div>` : ""}</div>`);
    } else {
      const grounded = (m.meta || {}).grounded;
      parts.push(`<div class="history-turn"><div class="msg assistant">${chatHtml(m.text)}${grounded === false ? `<div class="grounding warn">was not fully checked</div>` : ""}</div></div>`);
    }
  }
  if ((out.total || 0) > messages.length && !q.trim()) {
    parts.push(`<div class="history-more"><button type="button" class="ghost" id="chat-history-more">show earlier</button></div>`);
  }
  body.innerHTML = parts.join("");
  const more = $("#chat-history-more");
  if (more) more.addEventListener("click", () => { HISTORY_LIMIT = Math.min(HISTORY_LIMIT + 200, 1000); renderChatHistory(); });
}
function wireChatHistory() {
  const button = $("#chat-history-btn");
  if (button) {
    if (REMOTE) button.hidden = true;
    button.addEventListener("click", () => { showPane("chat-history"); renderChatHistory(); });
  }
  const search = $("#chat-history-search");
  if (search) search.addEventListener("input", () => {
    clearTimeout(HISTORY_TIMER);
    HISTORY_TIMER = setTimeout(renderChatHistory, 250);
  });
}

function wireChatClear() {
  const button = $("#chat-clear");
  if (!button) return;
  button.addEventListener("click", async () => {
    button.disabled = true;
    try {
      const response = await fetch("/api/chat/history", { method: "DELETE" });
      if (!response.ok) return;
      CHAT_CONVERSATION = null; CHAT_SESSION = null; PENDING_PROPOSAL = null;
      await loadPreviousChats();
      const logBox = $("#chat-log");
      if (logBox) { logBox.innerHTML = ""; showChatEmpty(); }
      if (PANE === "chat-history") renderChatHistory();
    } finally {
      button.disabled = false;
    }
  });
}

async function sendChat(event) {
  event.preventDefault();
  if (CHAT_BUSY) return;
  const input = $("#chat-input");
  let message = input.value.trim();
  if (simpleLook() && PANE === "home") PENDING_PROPOSAL = null;
  if (message && await answerPendingProposal(message)) { input.value = ""; return; }
  if (message && await answerUndo(message)) { input.value = ""; return; }
  if (!message) return;
  CHAT_BUSY = true;
  renderPreviousChats();
  const ctx = CHAT_CONTEXT;
  const itemId = (ctx && ctx.itemId) || input.dataset.itemId || null;
  if (ctx && !ctx.itemId && ctx.label && !message.toLowerCase().includes(ctx.label.toLowerCase())) {
    // A class context has no id the API knows; it rides in the sentence, in
    // the open, so what was sent is exactly what is shown.
    message = `About ${ctx.label}: ${message}`;
  }
  input.value = ""; delete input.dataset.itemId;
  setChatContext(null);
  /* Sent from the New chat screen in the simple look: a fresh conversation,
     like Claude's. The old ones are not deleted — they stay in the history,
     and the server keeps them; only the log on screen and the session start
     over. */
  if (simpleLook() && PANE === "home") {
    CHAT_SESSION = null;
    CHAT_CONVERSATION = null;
    PENDING_PROPOSAL = null;
    const log = $("#chat-log");
    if (log) log.innerHTML = "";
  }
  showPane("chat");
  const logBox = $("#chat-log");
  const empty = logBox.querySelector(".chat-empty");
  if (empty) empty.remove();
  logBox.insertAdjacentHTML("beforeend", `<div class="msg user">${esc(message)}</div>`);
  const bubble = document.createElement("div");
  bubble.className = "msg assistant pending";
  bubble.textContent = "thinking";
  logBox.appendChild(bubble);
  logBox.scrollTop = logBox.scrollHeight;
  try {
    const res = await fetch("/api/chat", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, session_id: CHAT_SESSION, item_id: itemId, conversation_id: CHAT_CONVERSATION }),
    });
    const out = await res.json();
    bubble.classList.remove("pending");
    if (out.error) {
      bubble.textContent = out.error.message + " — fix: " + out.error.fix;
      return;
    }
    CHAT_SESSION = out.session_id || CHAT_SESSION;
    CHAT_CONVERSATION = out.conversation_id || CHAT_CONVERSATION;
    loadPreviousChats();
    if (out.mode === "memory") {
      bubble.innerHTML = chatHtml(out.answer);
      bubble.insertAdjacentHTML("beforeend", '<div class="grounding ok">✓ local memory</div>');
      loadChatMemory();
      logBox.scrollTop = logBox.scrollHeight;
      return;
    }
    bubble.innerHTML = chatHtml(out.answer);
    // Three outcomes, three stamps: an answer nothing could check says so,
    // rather than earning the green tick by making no checkable claim.
    const stamp = document.createElement("div");
    if (out.mode === "settings") {
      /* [ASKED] 2026-10-07: a settings change, read by ai/commands.py with no
         AI; applied through the Settings page's own functions. */
      stamp.className = "grounding ok";
      stamp.textContent = "✓ answered by SillyBus itself — no AI involved";
      bubble.appendChild(stamp);
      await applyChatActions(bubble, out);
      logBox.scrollTop = logBox.scrollHeight;
      return;
    }
    if (out.mode === "quickadd") {
      stamp.className = "grounding ok";
      stamp.textContent = "✓ read straight from what you typed — check it, then tap Add";
      bubble.appendChild(stamp);
      if ((out.action || {}).proposed) renderTaskProposal(bubble, out.action);
      logBox.scrollTop = logBox.scrollHeight;
      return;
    }
    if (out.mode === "lookup" && !(out.violations || []).length) {
      stamp.className = "grounding ok";
      stamp.textContent = "✓ From your homework and schedule";
      stamp.title = "Read from your saved data. Open an assignment for its full instructions and date details.";
      bubble.appendChild(stamp);
      const action0 = out.action || {};
      if (action0.proposed) renderTaskProposal(bubble, action0);
      logBox.scrollTop = logBox.scrollHeight;
      return;
    }
    const level = out.confidence
      || (out.grounded ? (out.verified ? "verified" : "unverified") : "failed");
    if (level === "failed") {
      stamp.className = "grounding warn-mark";
      stamp.textContent = "⚠ mentioned something not in your data: "
        + (out.violations || []).join("; ");
    } else if (level === "verified") {
      const n = out.verified || 0;
      stamp.className = "grounding ok";
      stamp.textContent = "✓ Checked against your data";
      if (out.checked && out.checked.length) stamp.title = out.checked.join("\n");
    } else {
      stamp.className = "grounding unverified";
      stamp.textContent = "no verifiable claims in this answer — read it carefully";
      stamp.title = "Nothing here quoted an assignment id, room, time or grade, "
        + "so there was nothing to check against your data.";
    }
    bubble.appendChild(stamp);
    const action = out.action || {};
    // A proposed task is not homework yet. Nothing is written until tapped.
    if (action.proposed) renderTaskProposal(bubble, action);
    // A preference the model proposed, already held to the server's whitelist.
    if ((out.actions || []).length) await applyChatActions(bubble, out);
    if (action.added || action.marked_done) await loadState();
  } catch (err) {
    bubble.classList.remove("pending");
    bubble.textContent = "chat failed: " + err.message;
  } finally {
    CHAT_BUSY = false;
    renderPreviousChats();
  }
  logBox.scrollTop = logBox.scrollHeight;
}

/* ---------------- a proposed task, awaiting one tap ---------------- */
/* The proposal the chat is waiting on. [MEASURED] 2026-09-20 from his
   install: "add make frosh hype video to clubs" got "Got it — add …?" and
   nothing else — the buttons had been drawn under the bubble, the log was
   rebuilt from history (which stores text, not buttons), and typing "yes"
   went to the model as a new question. The pending proposal is kept here,
   redrawn under the last bubble whenever the log is rebuilt, and a plain
   yes/no typed into the box answers it without a round trip. */
let PENDING_PROPOSAL = null;
const SAYS_YES = /^(y|yes|yep|yeah|ya|sure|ok|okay|add it|do it|please|go ahead|yes please)[.! ]*$/i;
const SAYS_NO = /^(n|no|nah|nope|cancel|never mind|nevermind|don'?t)[.! ]*$/i;
async function addProposedTask(task) {
  const res = await fetch("/api/tasks", {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(task),
  });
  const out = await res.json();
  if (out.error) throw new Error(out.error.message);
  return (out.task || {}).item_id;
}
/* Called by the chat form before anything is sent. True when the text was an
   answer to the pending proposal and has been handled here. */
async function answerPendingProposal(text) {
  if (!PENDING_PROPOSAL) return false;
  const logBox = $("#chat-log");
  const say = (html) => { if (logBox) { logBox.insertAdjacentHTML("beforeend", `<div class="msg assistant">${html}</div>`); logBox.scrollTop = logBox.scrollHeight; } };
  if (SAYS_YES.test(text)) {
    const pending = PENDING_PROPOSAL; PENDING_PROPOSAL = null;
    if (logBox) logBox.insertAdjacentHTML("beforeend", `<div class="msg user">${esc(text)}</div>`);
    try {
      if (pending.event) {
        await addProposedEvent(pending.task);
        say(`\u2714 \u201c${esc(pending.task.title)}\u201d is on your calendar.`);
        await loadState();
        return true;
      }
      await addProposedTask(pending.task);
      say(`\u271a Added \u201c${esc(pending.task.title)}\u201d${pending.task.section ? " to " + esc(pending.task.section) : ""}.`);
      await loadState();
    } catch (err) { say(`could not add it: ${esc(err.message)}`); }
    return true;
  }
  if (SAYS_NO.test(text)) {
    PENDING_PROPOSAL = null;
    if (logBox) logBox.insertAdjacentHTML("beforeend", `<div class="msg user">${esc(text)}</div>`);
    say("Not added.");
    document.querySelectorAll(".proposal").forEach((b) => { b.innerHTML = `<div class="proposal-note">Not added.</div>`; });
    return true;
  }
  return false;
}
function redrawPendingProposal() {
  if (!PENDING_PROPOSAL) return;
  const logBox = $("#chat-log");
  const last = logBox && [...logBox.querySelectorAll(".msg.assistant")].pop();
  if (last && !last.querySelector(".proposal")) renderTaskProposal(last, PENDING_PROPOSAL.action);
}
/* "Soccer practice Thursday at 5" — an EVENT for the calendar, not a task.
   [ASKED] 2026-10-06: "make it as easy to add stuff using the chat". Same
   shape as the task card: everything editable, nothing written until Add. */
async function addProposedEvent(ev) {
  const res = await fetch("/api/events", {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(ev),
  });
  const out = await res.json();
  if (out.error) throw new Error(out.error.message);
  return out.event || {};
}
function renderEventProposal(bubble, action) {
  const ev = { ...(action.proposed || {}) };
  PENDING_PROPOSAL = { action, task: ev, event: true };
  const box = document.createElement("div");
  box.className = "proposal";
  box.innerHTML = `
    <div class="proposal-head">Put this on your calendar?</div>
    <div class="proposal-edit">
      <input type="text" class="pe-title" maxlength="140" value="${esc(ev.title || "")}" aria-label="what">
      <div class="pe-row">
        <input type="date" class="pe-due" value="${esc(ev.date || "")}" aria-label="day">
        <input type="time" class="pe-start" value="${esc(ev.start || "")}" aria-label="starts">
        <input type="time" class="pe-end" value="${esc(ev.end || "")}" aria-label="ends">
      </div>
      <input type="text" class="pe-where" maxlength="120" value="${esc(ev.location || "")}"
             placeholder="where? (optional)" aria-label="where">
    </div>
    <div class="proposal-actions">
      <button type="button" class="primary proposal-yes">Add it</button>
      <button type="button" class="proposal-no">No thanks</button>
    </div>`;
  bubble.appendChild(box);
  box.querySelector(".proposal-no").addEventListener("click", () => {
    PENDING_PROPOSAL = null;
    box.innerHTML = `<div class="proposal-note">Not added.</div>`;
  });
  box.querySelector(".proposal-yes").addEventListener("click", async () => {
    const yes = box.querySelector(".proposal-yes");
    yes.disabled = true; yes.textContent = "Adding…";
    try {
      const saved = await addProposedEvent({
        title: box.querySelector(".pe-title").value || ev.title,
        date: box.querySelector(".pe-due").value || ev.date,
        start: box.querySelector(".pe-start").value || null,
        end: box.querySelector(".pe-end").value || null,
        location: box.querySelector(".pe-where").value.trim() || null,
      });
      PENDING_PROPOSAL = null;
      box.innerHTML = `<div class="proposal-note">\u2714 On your calendar.</div>`;
      const open = document.createElement("button");
      open.type = "button"; open.className = "proposal-undo"; open.textContent = "See it";
      open.addEventListener("click", () => {
        CAL_PAGE_DAY = saved.date || ev.date;
        CAL_FOCUS_MIN = calMinutes(saved.start);     // scrolled to it, not to the morning
        window.showView ? window.showView("calendar") : showPane("calendar");
      });
      const undo = document.createElement("button");
      undo.type = "button"; undo.className = "proposal-undo"; undo.textContent = "Undo";
      undo.addEventListener("click", async () => {
        undo.disabled = true;
        await fetch(`/api/events/${encodeURIComponent(saved.event_id)}`, { method: "DELETE" });
        box.innerHTML = `<div class="proposal-note">Removed again.</div>`;
        await loadState();
      });
      box.append(open, undo);
      await loadState();
    } catch (err) {
      box.innerHTML = `<div class="proposal-note">could not add it: ${esc(err.message)}</div>`;
    }
  });
}
function renderTaskProposal(bubble, action) {
  if (action.intent === "add_event") return renderEventProposal(bubble, action);
  const task = action.proposed || {};
  /* "to clubs" / "for practice" in the sentence files it where he said;
     the section is what the Life page groups by. */
  if (!task.section) {
    const said = (task.notes || "") + " " + (task.title || "");
    const m = /\b(?:to|in|under|for)\s+(clubs?|goals?|practice|makeup|personal)\b/i.exec(said);
    if (m) {
      task.section = { club: "clubs", clubs: "clubs", goal: "goals", goals: "goals", practice: "practice", makeup: "makeup", personal: "goals" }[m[1].toLowerCase()];
      // "…video to clubs" names the shelf, not the task
      task.title = (task.title || "").replace(/\s+(?:to|in|under|for)\s+(?:clubs?|goals?|practice|makeup|personal)\s*$/i, "").trim() || task.title;
    }
  }
  PENDING_PROPOSAL = { action, task };
  const box = document.createElement("div");
  box.className = "proposal";
  const when = task.due_date ? niceDate(task.due_date) : "no date";
  const categories = ["", "assignment", "quiz", "test", "project", "essay", "reading",
                      "problem_set", "discussion"];
  box.innerHTML = `
    <div class="proposal-head">Add this to your list?</div>
    <div class="proposal-edit">
      <input type="text" class="pe-title" maxlength="110" value="${esc(task.title)}" aria-label="title">
      <div class="pe-row">
        <input type="date" class="pe-due" value="${esc(task.due_date || "")}" aria-label="due date">
        <select class="pe-cat" aria-label="type">${categories.map((c) =>
          `<option value="${esc(c)}" ${(task.category || "") === c ? "selected" : ""}>${
            c ? c.replace("_", " ") : "what kind?"}</option>`).join("")}</select>
      </div>
      <input type="text" class="pe-course" maxlength="60" value="${esc(task.course || "")}"
             placeholder="which class? (optional)" aria-label="class">
    </div>
    <div class="proposal-sub">${esc(when)}${task.course ? " · " + esc(task.course) : ""}${
      task.section ? " · " + esc(task.section) : ""}</div>
    ${action.date_dropped
      ? `<div class="proposal-note">I left the date off on purpose — you did not
         say one, and ${esc(action.date_dropped)} would have been my guess.</div>`
      : ""}
    <div class="proposal-actions">
      <button type="button" class="primary proposal-yes">Add it</button>
      <button type="button" class="proposal-no">No thanks</button>
    </div>`;
  bubble.appendChild(box);

  box.querySelector(".proposal-no").addEventListener("click", () => {
    PENDING_PROPOSAL = null;
    box.innerHTML = `<div class="proposal-note">Not added.</div>`;
  });
  box.querySelector(".proposal-yes").addEventListener("click", async () => {
    const yes = box.querySelector(".proposal-yes");
    yes.disabled = true; yes.textContent = "Adding…";
    try {
      const edited = {
        ...task,
        title: (box.querySelector(".pe-title") || {}).value || task.title,
        due_date: (box.querySelector(".pe-due") || {}).value || null,
        category: (box.querySelector(".pe-cat") || {}).value || task.category || null,
        course: ((box.querySelector(".pe-course") || {}).value || "").trim() || null,
      };
      const id = await addProposedTask(edited);
      PENDING_PROPOSAL = null;
      box.innerHTML = `<div class="proposal-note">✚ Added.</div>`;
      if (id) {
        const undo = document.createElement("button");
        undo.type = "button"; undo.className = "proposal-undo"; undo.textContent = "Undo";
        undo.addEventListener("click", async () => {
          undo.disabled = true;
          await fetch(`/api/tasks/${encodeURIComponent(id)}`, { method: "DELETE" });
          box.innerHTML = `<div class="proposal-note">Removed again.</div>`;
          await loadState();
        });
        box.appendChild(undo);
      }
      await loadState();
    } catch (err) {
      box.innerHTML = `<div class="proposal-note">could not add it: ${esc(err.message)}</div>`;
    }
  });
}

/* ---------------- auto-refresh ----------------
   Re-read /api/state every 60s so a scheduled refresh appears on a page that
   has been open all day; trigger a real refresh when the data is stale AND the
   page is visible. document.hidden gates both. */
const POLL_MS = 60 * 1000;
const AUTO_REFRESH_AFTER_MINUTES = 35;   // just past the 30-minute schedule
let LAST_AUTO_REFRESH = 0;

function dataAgeMinutes() {
  if (!STATE || !STATE.generated_at) return Infinity;
  const at = new Date(STATE.generated_at).getTime();
  if (Number.isNaN(at)) return Infinity;
  return (Date.now() - at) / 60000;
}

async function autoTick() {
  if (REMOTE || document.hidden) return;
  try {
    await loadState();
  } catch (e) { return; }          // offline: try again on the next tick
  const btn = $("#refresh");
  if (!btn || btn.disabled) return;
  const sinceOurs = (Date.now() - LAST_AUTO_REFRESH) / 60000;
  if (dataAgeMinutes() > AUTO_REFRESH_AFTER_MINUTES && sinceOurs > 10) {
    LAST_AUTO_REFRESH = Date.now();
    await refresh();
  }
}

function startAutoRefresh() {
  if (REMOTE) return;             // the published snapshot has no server
  setInterval(autoTick, POLL_MS);
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) autoTick();
  });
}

/* ---------------- refresh (local only) ---------------- */
/* After signing in, old data is refreshed at once. [MEASURED] 2026-10-07 in
   his recording: signed back in to a board "306h old", and nothing read it
   again — the read on open had run while he was signed out and was refused. */
function refreshIfOld() {
  const made = STATE && STATE.generated_at ? Date.parse(STATE.generated_at) : 0;
  if (!made || Date.now() - made > 3 * 3600 * 1000) {
    refresh().catch(() => { /* the Refresh button still works */ });
  }
}

async function refresh() {
  const btn = $("#refresh");
  btn.disabled = true; btn.textContent = "Refreshing…";
  const progress = $("#progress");
  progress.hidden = false; progress.innerHTML = "";
  try {
    const res = await fetch("/api/refresh", { method: "POST",
      headers: { "Content-Type": "application/json" }, body: "{}" });
    const out = await res.json();
    if (!out.error) {
      await new Promise((resolve) => {
        const source = new EventSource(`/api/refresh/${out.run_id}/events`);
        source.onmessage = (event) => {
          const data = JSON.parse(event.data);
          if (data.stage === "done") { source.close(); resolve(); return; }
          const line = document.createElement("div");
          line.textContent = `[${data.stage}] ${data.course ? data.course + ": " : ""}${data.message}`;
          progress.appendChild(line);
          if (!REDUCED) progress.scrollTop = progress.scrollHeight;
        };
        source.onerror = () => { source.close(); resolve(); };
      });
    }
  } finally {
    btn.disabled = false; btn.textContent = "Refresh";
    setTimeout(() => { progress.hidden = true; }, 4000);
    await loadState();
  }
}
window.refresh = refresh;

/* ---------------- panel fold/grow ---------------- */
function panelStates() {
  try { return JSON.parse(localStorage.getItem("sillybus.panels")) || {}; }
  catch (e) { return {}; }
}
function applyPanelStates() {
  const states = panelStates();
  /* Folded and grown are DASHBOARD states. In the simple layout a panel IS a
     page: there is nothing beside it to give room to, and both buttons are
     hidden — so applying a state saved months ago in the dashboard is not a
     preference being honoured, it is a page that cannot be opened.

     [MEASURED] 2026-09-10, and it took four rounds to find because it lives in
     localStorage and so reproduced on his machine and nowhere else. He had
     collapsed the Grades box in the dashboard at some point. On the simple
     layout's Grades page that left `.panel.collapsed` with its body
     `display: none`, while `.panel.tab-on { flex: 1 1 auto }` stretched it to
     fill the page — a full-height panel with a heading, a live "7/10" count,
     nine grade rows in the DOM at zero height, and no fold button to press.
     Nothing threw, nothing logged, and the data was perfect. */
  const simple = typeof isSimple === "function" && isSimple();
  document.querySelectorAll(".panel[data-panel]").forEach((panel) => {
    const name = panel.dataset.panel;
    panel.classList.toggle("collapsed", !simple && states[name] === "collapsed");
    panel.classList.toggle("grown", !simple && states[name] === "grown");
    const fold = panel.querySelector(".fold-btn");
    if (fold) fold.textContent = states[name] === "collapsed" ? "▸" : "▾";
  });
}
/* Kept as a no-op guard: the element may linger in a cached page after an
   upgrade, and a missing element must never stop the script. */
function wireQuickAsk() {
  const form = document.getElementById("ask-quick");
  const input = document.getElementById("ask-input");
  const chatInput = document.getElementById("chat-input");
  const chatForm = document.getElementById("chat-form");
  if (!form || !input || !chatInput || !chatForm) return;
  form.addEventListener("submit", (ev) => {
    ev.preventDefault();
    const question = input.value.trim();
    if (!question) return;
    input.value = "";
    chatInput.value = question;
    chatForm.dispatchEvent(new Event("submit", { cancelable: true }));
  });
}

function wirePanels() {
  /* Not every panel has the fold/grow controls. [MEASURED] 2026-09-03: one
     missing button, unguarded, took out the whole board at startup. */
  const on = (panel, selector, handler) => {
    const button = panel.querySelector(selector);
    if (button) button.addEventListener("click", handler);
  };
  document.querySelectorAll(".panel[data-panel]").forEach((panel) => {
    const name = panel.dataset.panel;
    const set = (value) => {
      const states = panelStates();
      states[name] = states[name] === value ? "normal" : value;
      localStorage.setItem("sillybus.panels", JSON.stringify(states));
      applyPanelStates();
    };
    on(panel, ".fold-btn", () => set("collapsed"));
    on(panel, ".grow-btn", () => set("grown"));
  });
}

/* ---------------- resizable columns, hideable sides ---------------- */
function wireResizers() {
  document.querySelectorAll(".resizer").forEach((bar) => {
    const side = bar.dataset.side;
    bar.addEventListener("dblclick", () => savePrefs(side === "left"
      ? { leftWidth: PREF_DEFAULTS.leftWidth } : { rightWidth: PREF_DEFAULTS.rightWidth }));
    bar.addEventListener("pointerdown", (ev) => {
      ev.preventDefault();
      const startX = ev.clientX;
      const start = side === "left" ? PREFS.leftWidth : PREFS.rightWidth;
      bar.classList.add("dragging");
      document.body.classList.add("resizing");
      const move = (e) => {
        const delta = side === "left" ? e.clientX - startX : startX - e.clientX;
        const width = Math.round(Math.max(180, Math.min(480, start + delta)));
        document.documentElement.style.setProperty(side === "left" ? "--left-w" : "--right-w", `${width}px`);
        bar.dataset.width = width;
      };
      const up = () => {
        window.removeEventListener("pointermove", move);
        window.removeEventListener("pointerup", up);
        bar.classList.remove("dragging");
        document.body.classList.remove("resizing");
        if (bar.dataset.width) savePrefs(side === "left"
          ? { leftWidth: Number(bar.dataset.width) } : { rightWidth: Number(bar.dataset.width) });
        delete bar.dataset.width;
      };
      window.addEventListener("pointermove", move);
      window.addEventListener("pointerup", up);
    });
  });
  const tl = $("#toggle-left"), tr = $("#toggle-right");
  if (tl) tl.onclick = () => savePrefs({ hideLeft: !PREFS.hideLeft });
  if (tr) tr.onclick = () => savePrefs({ hideRight: !PREFS.hideRight });
}

/* ---------------- wiring ---------------- */
loadPrefs();
applyPrefs();
$("#refresh").onclick = refresh;
$("#theme-toggle").onclick = () => {
  const root = document.documentElement;
  // With nothing pinned the page follows the system, so read what is actually
  // on screen — otherwise the first click is a no-op for anyone already dark.
  const showing = root.getAttribute("data-theme")
    || (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
  const next = showing === "dark" ? (PREFS.lightChoice || "light") : "dark";
  if (showing !== "dark") PREFS.lightChoice = showing;
  savePrefs({ theme: next });
  if (window.renderAppearance) window.renderAppearance();
};
const detailClose = $("#detail-close");
if (detailClose) detailClose.onclick = closeDetail;
/* Back means "the page I came from" in the simple layout, and the chat in the
   dashboard. Sending someone from an assignment to the chat when they tapped
   it on the Today tab loses their place for no reason. */
document.querySelectorAll("[data-back]").forEach((b) => b.addEventListener("click", () => {
  if (isSimple()) { showTab(PREFS.tab === "chat" ? "todo" : PREFS.tab); return; }
  showPane("chat");
}));
/* One listener on the strip rather than one per button: renderTabs() rewrites
   its innerHTML on every refresh, which would drop per-button handlers. */
/* One listener each, delegated: both are rewritten on every refresh, which
   would drop per-button handlers. */
const tabBar = $("#tab-bar");
if (tabBar) tabBar.addEventListener("click", (ev) => {
  const btn = ev.target.closest("button[data-tab]");
  if (btn) showTab(btn.dataset.tab);
});
const moreList = $("#more-list");
if (moreList) moreList.addEventListener("click", (ev) => {
  const btn = ev.target.closest("button[data-tab]");
  if (btn) showTab(btn.dataset.tab);
});
document.querySelectorAll("#layout-pick .lp-opt").forEach((b) => b.addEventListener("click", () => {
  savePrefs({ layout: b.dataset.layout, tab: PREFS.tab || "today" });
  if (window.renderLayoutPrefs) window.renderLayoutPrefs();
  render();
}));
const dockChat = $("#dock-chat");
if (dockChat) dockChat.onclick = () => showPane("chat");
const ctxClear = $("#chat-context-clear");
if (ctxClear) ctxClear.onclick = () => setChatContext(null);
document.addEventListener("keydown", (ev) => {
  const typing = ["INPUT", "TEXTAREA", "SELECT"].includes((ev.target || {}).tagName)
    || (ev.target && ev.target.isContentEditable);
  if (ev.key === "Escape") {
    const palette = $("#palette");
    if (palette && !palette.hidden) return;   // the palette closes itself
    if (isSimple()) {
      // Esc backs out of a detail to the page it was opened from.
      if (!tabForPane(PANE)) { showTab(PREFS.tab); return; }
      if (CHAT_CONTEXT) setChatContext(null);
      return;
    }
    if (typing) { ev.target.blur(); return; }
    if (PANE !== "home") { if (window.openTab) window.openTab("home"); else showPane("home"); return; }
    if (CHAT_CONTEXT) setChatContext(null);
  }
  if (typing || ev.metaKey || ev.ctrlKey || ev.altKey) return;
  if (ev.key === "/") { ev.preventDefault(); const i = $("#chat-input"); if (i) i.focus(); }
  /* [ and ] step through the tab strip, the same as the arrow keys; they
     used to hide a column, which this board no longer has a preference for. */
  if (ev.key === "[" && window.stepTab) stepTab(-1);
  if (ev.key === "]" && window.stepTab) stepTab(1);
  if (ev.key === "r" && !REMOTE) refresh();
});
/* The 0.18 calendar panel and its day-stepper are gone from the page; the
   Studio calendar section replaces them and gains its own controls with the
   format registry in stage 2b. Guarded rather than deleted, because
   renderSchedule() and setCalMode() are still what the week and month formats
   will be built on — and an unguarded lookup here is what threw on the first
   run of this board and stopped every wiring line after it. */
const on = (sel, fn) => { const el = $(sel); if (el) el.onclick = fn; };
on("#day-prev", () => { SCHED_OFFSET -= 1; renderSchedule(); });
on("#day-next", () => { SCHED_OFFSET += 1; renderSchedule(); });
on("#day-today", () => { SCHED_OFFSET = 0; renderSchedule(); });
document.querySelectorAll("button[data-cal]").forEach((b) => b.addEventListener("click", () => setCalMode(b.dataset.cal)));
/* The simple layout's Calendar page is the full width of the window, so a
   month grid fits and is what "calendar" means; the dashboard's 248px column
   cannot hold one, so it keeps Day unless he says otherwise. */
CAL_MODE = ["week", "month"].includes(PREFS.calendar) ? PREFS.calendar
  : (PREFS.layout === "simple" ? "month" : "day");
const gradesSort = $("#grades-sort");
if (gradesSort) gradesSort.onclick = () => { savePrefs({ gradeSort: PREFS.gradeSort === "name" ? "low" : "name" }); renderGrades(); };
const assignSort = $("#assign-sort");
if (assignSort) assignSort.onclick = () => {
  const next = SORT_MODES[(SORT_MODES.indexOf(PREFS.assignSort) + 1) % SORT_MODES.length];
  savePrefs({ assignSort: next }); renderPanels();
};
if (REMOTE) {
  const dock = $("#chat-dock");
  if (dock) dock.innerHTML =
    `<span class="muted">chat and live refresh run on your PC — this page is
     the anywhere-view, updated on the schedule</span>`;
  const hint = $("#chat-hint");
  if (hint) hint.textContent = "";
  document.querySelectorAll("#view-nav, .resizer, #toggle-left, #toggle-right, #palette-open").forEach((el) => { el.hidden = true; });
} else {
  $("#chat-form").onsubmit = sendChat;
}
/* ---------------- the account gate ----------------
   Shown only when the server says 401. A solo install with no account server
   configured never sees it, because the gate is off server-side. */
let GATE_CREATING = false;

/* ---------------- the paywall ----------------
   Shown when the trial has run out. Say the price and the exact thing to do
   next, in one screen; never pretend the money moves through this app. */
function showPaywall(message) {
  const gate = $("#gate");
  if (!gate) return;
  gate.hidden = false;
  const sub = (STATE && STATE.subscription) || {};
  const price = sub.price || { amount: "5.99", currency: "USD", period: "month" };
  const payTo = sub.pay_to || "";
  const email = sub.email || "";
  gate.innerHTML = `
    <div class="gate-card paywall">
      <img src="/static/brand/icon.svg" alt="" width="52" height="52" class="gate-mark">
      <h2>Your free trial has ended</h2>
      <p class="muted">${esc(message
        || `SillyBus AI is $${price.amount} a ${price.period} after the trial.`)}</p>
      <div class="paywall-price">$${esc(price.amount)}<span>/${esc(price.period)}</span></div>
      <ol class="paywall-steps">
        ${payTo
          ? `<li>Send <strong>$${esc(price.amount)}</strong> on Venmo to
               <strong>${esc(payTo)}</strong></li>`
          : `<li>Ask whoever gave you SillyBus AI how to pay them</li>`}
        <li>Put your sign-in email in the note:
            <code>${esc(email || "your email")}</code></li>
        <li>Press the button below once it is sent</li>
      </ol>
      <button type="button" class="primary" id="paywall-check">I've paid — check now</button>
      <div class="paywall-code">
        <label for="paywall-code-input">Got a code?</label>
        <div class="paywall-code-row">
          <input id="paywall-code-input" type="text" autocomplete="off"
                 spellcheck="false" placeholder="type it here">
          <button type="button" id="paywall-redeem">Use code</button>
        </div>
      </div>
      <p class="gate-error" id="paywall-note" hidden></p>
      <button type="button" class="ghost" id="paywall-signout">Sign out</button>
      <p class="muted paywall-small">Your homework, grades and schedule are still
        on this Mac and nothing has been deleted. Paying unlocks the page again.</p>
    </div>`;

  $("#paywall-signout").addEventListener("click", async () => {
    await fetch("/api/session", { method: "DELETE" });
    location.reload();
  });

  const redeemBtn = $("#paywall-redeem");
  const codeInput = $("#paywall-code-input");
  const useCode = async () => {
    const note = $("#paywall-note");
    const code = (codeInput.value || "").trim();
    if (!code) { codeInput.focus(); return; }
    redeemBtn.disabled = true; redeemBtn.textContent = "Checking…";
    note.hidden = true;
    try {
      const res = await fetch("/api/session/redeem", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code }),
      });
      const out = await res.json();
      if (out.error) throw new Error(out.error.message);
      if (((out.subscription) || {}).state === "paid") { location.reload(); return; }
      throw new Error("that code did not unlock anything");
    } catch (err) {
      note.hidden = false;
      note.textContent = err.message;
    }
    redeemBtn.disabled = false; redeemBtn.textContent = "Use code";
  };
  redeemBtn.addEventListener("click", useCode);
  codeInput.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter") { ev.preventDefault(); useCode(); }
  });

  $("#paywall-check").addEventListener("click", async () => {
    const btn = $("#paywall-check");
    const note = $("#paywall-note");
    btn.disabled = true; btn.textContent = "Checking…";
    note.hidden = true;
    try {
      const res = await fetch("/api/session/refresh", { method: "POST" });
      const out = await res.json();
      const state = ((out.subscription) || {}).state;
      if (state === "paid" || state === "trial") { location.reload(); return; }
      note.hidden = false;
      note.textContent = "Not showing as paid yet. It is switched on by hand, "
        + "so give it a little while, then check again.";
    } catch (err) {
      note.hidden = false;
      note.textContent = "Could not reach the account server — check your internet.";
    }
    btn.disabled = false; btn.textContent = "I've paid — check now";
  });
}

function showGate() {
  const gate = $("#gate");
  if (!gate || !gate.hidden) return;
  gate.hidden = false;
  $("#gate-email").focus();
}

/* Three modes now, not two. [ASKED] 2026-09-24: *"add a way for password
   recovery"*, after the licence check locked him out of homework that was
   already on his own Mac, with no way back at all.

   `recovering` shows one extra box and changes what the form posts. The
   ordinary sign-in is untouched — two boxes and a button — because the
   recovery path is the rare one and should not cost the common one. */
let GATE_RECOVERING = false;

function setGateMode(creating, recovering = false) {
  GATE_CREATING = creating;
  GATE_RECOVERING = recovering;
  $("#gate-title").textContent = recovering
    ? "Get back into SillyBus AI"
    : (creating ? "Create your SillyBus AI account" : "Sign in to SillyBus AI");
  $("#gate-submit").textContent = recovering
    ? "Set a new password" : (creating ? "Create account" : "Sign in");
  $("#gate-toggle").textContent = creating
    ? "I already have an account" : "Create an account instead";
  $("#gate-toggle").hidden = recovering;
  $("#gate-forgot").textContent = recovering
    ? "Back to signing in" : "I forgot my password";
  $("#gate-code-field").hidden = !recovering;
  $("#gate-code").required = recovering;
  $("#gate-password-label").textContent = recovering ? "New password" : "Password";
  $("#gate-confirm-field").hidden = !(creating || recovering);
  $("#gate-about").hidden = !(creating && !recovering);
  $("#gate-name").required = creating && !recovering;
  $("#gate-confirm").required = creating || recovering;
  $("#gate-confirm").value = "";
  $("#gate-password").setAttribute(
    "autocomplete", (creating || recovering) ? "new-password" : "current-password");
  $("#gate-sub").textContent = recovering
    ? "Press Email me a code, type the 6 digits from the email (or the long code "
      + "you wrote down), and pick a new password. Your "
      + "homework is on this Mac either way — the account is only how SillyBus "
      + "AI runs on more than one."
    : "Your homework stays on this Mac. The account just lets you use SillyBus "
      + "AI on any Mac you install it on.";
  $("#gate-error").hidden = true;
  $("#gate-note").hidden = true;
}

function gateError(message) {
  const box = $("#gate-error");
  box.textContent = message;
  box.hidden = false;
}

if (!REMOTE) {
  $("#gate-toggle").onclick = () => setGateMode(!GATE_CREATING);
  $("#gate-forgot").onclick = () => setGateMode(false, !GATE_RECOVERING);
  /* The code arrives by mail, to the address on the account. The server says
     the same thing whether or not the address exists; the one thing it says
     out loud is when it has no way to send mail at all. */
  $("#gate-send-code").onclick = async () => {
    const button = $("#gate-send-code");
    const email = $("#gate-email").value.trim();
    if (!email) { gateError("type your email first, then press this"); $("#gate-email").focus(); return; }
    button.disabled = true;
    const said = button.textContent;
    button.textContent = "sending…";
    $("#gate-error").hidden = true;
    try {
      const response = await fetch("/api/session/forgot", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const body = await response.json();
      if (!response.ok) { gateError(body.error?.message || "that did not work"); return; }
      const note = $("#gate-note");
      note.textContent = `Check ${email} for a 6-digit code (it works for 15 minutes), then type it above with a new password.`;
      note.hidden = false;
      $("#gate-code").focus();
    } catch (err) {
      gateError("could not reach SillyBus AI — is it still running?");
    } finally {
      button.disabled = false;
      button.textContent = said;
    }
  };
  $("#gate-form").onsubmit = async (ev) => {
    ev.preventDefault();
    // Typed twice when it is being chosen, so a typo cannot lock him out of
    // the password he thinks he set. [ASKED] 2026-10-07.
    if ((GATE_CREATING || GATE_RECOVERING) && $("#gate-password").value !== $("#gate-confirm").value) {
      gateError("the two passwords don't match — type the same one in both boxes");
      $("#gate-confirm").focus();
      return;
    }
    const button = $("#gate-submit");
    button.disabled = true;
    $("#gate-error").hidden = true;
    try {
      const response = await fetch(
        GATE_RECOVERING ? "/api/session/recover" : "/api/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(GATE_RECOVERING ? {
          email: $("#gate-email").value.trim(),
          code: $("#gate-code").value.trim(),
          password: $("#gate-password").value,
        } : {
          email: $("#gate-email").value.trim(),
          password: $("#gate-password").value,
          create: GATE_CREATING,
        }),
      });
      const body = await response.json();
      if (!response.ok) {
        gateError(body.error?.message || "that did not work");
        return;
      }
      /* The code just used is spent, and the server minted a fresh one. It is
         shown HERE and nowhere else — nothing stores it — so it has to be
         shown before the gate closes, and the gate stays open until it is
         read. */
      if (GATE_RECOVERING && body.recovery_code) {
        const note = $("#gate-note");
        note.innerHTML = `You are back in. Your next recovery code is
          <b>${esc(body.recovery_code)}</b> — write it down now, it is not
          shown again.
          <button type="button" class="linkbtn" id="gate-got-it">Got it</button>`;
        note.hidden = false;
        $("#gate-error").hidden = true;
        $("#gate-password").value = "";
        $("#gate-confirm").value = "";
        $("#gate-code").value = "";
        $("#gate-got-it").onclick = async () => {
          $("#gate").hidden = true;
          await loadState();
          refreshIfOld();
        };
        await loadState();
        return;
      }
      /* A new account: keep what they told us about themselves, on this Mac.
         The account server never saw it — it went in no request above. */
      if (GATE_CREATING) {
        const about = { greeting_name: $("#gate-name").value.trim() };
        if ($("#gate-birthday").value) about.birthday = $("#gate-birthday").value;
        if ($("#gate-grade").value) about.grade_level = $("#gate-grade").value;
        if (about.greeting_name) STUDENT_NAME = about.greeting_name;
        try { await saveUiPrefs(about); } catch (err) { /* Settings can set it later */ }
      }
      $("#gate").hidden = true;
      $("#gate-password").value = "";
      $("#gate-confirm").value = "";
      await loadState();
      refreshIfOld();
    } catch (err) {
      gateError("could not reach SillyBus AI — is it still running?");
    } finally {
      button.disabled = false;
    }
  };
}

(() => {
  const close = document.getElementById("grade-detail-close");
  // The third back button. All three mean "the page I came from" now.
  if (close) close.addEventListener("click", () => {
    if (isSimple()) showTab(PREFS.tab && PREFS.tab !== "chat" ? PREFS.tab : "grades");
    else showPane("chat");
  });
})();

/* After the board has painted, not before it: an update is never more urgent
   than the homework, and the check must not delay the first render. */
if (!REMOTE) {
  /* [ASKED] 2026-09-21: *"check the GitHub every time I open it for updates"*.
     Opening the app forces a real read of the published marker; the server's
     own 6-hour cache used to mean a student could open the app the morning
     after a release and still be told they were up to date. A dismissed
     version stays dismissed — `force` is the network, not the banner. */
  setTimeout(() => { checkUpdate(true).then((out) => { if (out) renderBanners(); }); }, 2500);
  /* Left on the cache on purpose: this fires in an app that has been open for
     six hours, where the startup read has already happened and nothing is
     waiting on the answer. */
  setInterval(() => { checkUpdate(false).then((out) => { if (out) renderBanners(); }); }, 6 * 3600 * 1000);
}

wirePanels();
wireQuickAsk();
wireChatClear();
wireChatHistory();
wireChatCites();
applyPanelStates();
wireAddForm();
wireResizers();
startAutoRefresh();
/* The saved conversation is replayed AFTER the board, not beside it: a line
   in an old answer becomes a tap that opens the assignment it names, and it
   can only do that once the board is loaded and there is something to check
   the id against. The board is what he came for, so it still goes first. */
loadState().finally(() => { loadChatHistory(); loadPreviousChats(); loadChatMemory(); loadAccelRecent().then(paintChats); });

/* ---------------- installing as an app ----------------
   Only on the live local server: the published snapshot does not own its
   origin, so a root-scoped worker there is wrong. */
if (!REMOTE && "serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch((err) => {
      console.warn("[sillybus] service worker did not register", err);
    });
  });
}

if (!REMOTE) {
  const installBtn = $("#install");
  let deferredPrompt = null;
  window.addEventListener("beforeinstallprompt", (ev) => {
    ev.preventDefault();
    deferredPrompt = ev;
    installBtn.hidden = false;
  });
  installBtn.onclick = async () => {
    if (!deferredPrompt) return;
    installBtn.disabled = true;
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    deferredPrompt = null;
    installBtn.hidden = true;
    installBtn.disabled = false;
  };
  window.addEventListener("appinstalled", () => {
    deferredPrompt = null;
    installBtn.hidden = true;
  });
}

/* ==========================================================================
   0.20 — HEARTH · STUDIO
   ==========================================================================

   The board itself: the top bar, the three sections down the left, the class
   strip across the top, the middle that sits straight on the background, and
   the Assignments column where every class gets an equal band.

   This lives in app.js and not in a file of its own for the same reason the
   Studio CSS lives in app.css: `routes_api._asset_version` hashes exactly
   app.js + app.css + views.js, and that hash is what raises the "this app has
   been updated, reload" nudge. A fourth file would leave the nudge blind. */

/* ---------------- the preferences, as the server holds them ---------------
   The twin of `config.DEFAULTS["ui"]` and `sillybus/prefs.py`. Kept here as
   well because the board has to draw before /api/prefs answers, and a board
   that waits for a preference is a board that flashes. */
const UI_DEFAULTS = {
  theme: "system", accent: "#E8A317", pattern: "glow",
  font_body: "Inter", font_head: "Fraunces", text_size: 14,
  density: "compact", motion: "auto",
  background: { file: "", kind: "", opacity: 0.35 },
  formats: { calendar: ["day", "week"], chats: ["list"], life: ["kinds"],
             classes: ["strip"], work: ["byclass"], priority: ["cards"], links: ["full"] },
  active: { calendar: "day", chats: "list", life: "kinds", classes: "strip",
            work: "byclass", priority: "cards", links: "full" },
  abbr: {}, hidden: [], order: [],
  date_notes: "hover", show_estimates: true, hide_low_priority: false,
  open_with: "greeting", start_tab: "home",
  week_starts: "monday", show_weekends: false,
  colors: {}, grade_display: "percent", tab_labels: "codes", shortcuts: [], hidden_links: [],
  merge: {}, keep_apart: [], names: {},
  periods: {}, sort: "period", status_marks: "symbols", ticks: "hover",
  surface: "open", tabs_off: [],
  transition: "fade", transition_strength: "normal", greeting_name: "",
  birthday: "", grade_level: "", look: "simple",
  pattern_color: "", pattern_strength: "normal", tour_seen: false,
  /* Focus is off until it is turned on, and the default has to be here as
     well as on the server: the Settings page draws before /api/prefs answers,
     and a page that starts on "Block" and jumps to "Off" would be read as the
     setting having changed by itself. */
  focus: { mode: "off", sites_off: [], custom: [], remind_every: "visit",
           bypass_minutes: 15, when_clear: "allow" },
};
let UI = JSON.parse(JSON.stringify(UI_DEFAULTS));
window.uiPrefs = () => UI;
/* What the greeting calls the student, from GET /api/prefs: the name they
   typed, else the first name their school Google sign-in gave Canvas. */
let STUDENT_NAME = "";

/* 0.23: the simple look is the default — the app opens like a new chat, with
   the pages across the top. `board` is the 0.20 Studio board. A published
   read-only snapshot has no chat to open on, so it always shows the board. */
function simpleLook() { return !REMOTE && (UI.look || "simple") === "simple"; }
window.simpleLook = simpleLook;
let LOOK_DRAWN = null;
function applyLook() {
  const look = simpleLook() ? "simple" : "board";
  document.documentElement.setAttribute("data-look", look);
  /* The page strip sits IN the top bar in the simple look — one row, like
     the mockup he chose — and under it on the board. Moved, never copied:
     renderTabStrip finds it by id wherever it is. */
  const bar = $("#tab-bar"), top = $(".topbar"), meta = $(".topbar-meta");
  if (bar && top && meta) {
    if (look === "simple" && bar.parentElement !== top) top.insertBefore(bar, meta);
    if (look === "board" && bar.parentElement === top) top.after(bar);
  }
  if (LOOK_DRAWN === look) return;
  const first = LOOK_DRAWN === null;
  LOOK_DRAWN = look;
  if (first) return;
  // Switched in Settings: redraw what the two looks draw differently.
  try { renderTabStrip(); if (STATE) renderStudio(); } catch (err) { /* before the board */ }
}

/* Only the keys the pre-paint head script needs. Everything else is read from
   the server on load, because a mirror of the whole block would be a second
   copy of the truth that could disagree with it. */
const UI_MIRRORED = ["look", "theme", "accent", "pattern", "font_body", "font_head",
                     "text_size", "density", "motion", "date_notes", "surface", "ticks",
                     "transition", "transition_strength", "pattern_color", "pattern_strength"];

async function loadUiPrefs() {
  if (REMOTE) return;                       // a snapshot has no config to read
  try {
    const res = await fetch("/api/prefs");
    if (!res.ok) return;
    const out = await res.json();
    if (out && out.prefs) UI = { ...UI, ...out.prefs };
    if (out && typeof out.name === "string") STUDENT_NAME = out.name;
  } catch (err) { /* the shipped defaults are a working board */ }
  applyUiPrefs();
  /* The mirror in localStorage carries only the appearance keys, so the
     strip and the board may already be drawn from the defaults — hidden
     classes showing, the saved order ignored — by the time the real
     preferences land. [MEASURED] 2026-09-20 in a store screenshot: two
     switched-off classes in the strip while the section said "10 of 12".
     Anything drawn before this answer is drawn again with it. */
  if (STATE) { try { renderStudio(); renderTabStrip(); } catch (err) { /* the board is already drawn */ } }
  /* The page itself too. [MEASURED] 2026-10-07 on his install: a direct load
     of /grades or /classlist drew every class — "Aerospace Club", "2030
     Technology Training" — because `hidden` had not landed yet, and nothing
     redrew the page when it did. */
  if (STATE) {
    const pageDraw = { grades: window.renderGradesPage, classlist: window.renderClassListPage,
                       work: window.renderWorkPage, life: window.renderLifePage }[PANE];
    if (pageDraw) { try { pageDraw(); } catch (err) { /* the next refresh draws it */ } }
  }
}

/* Everything appearance-ish is a custom property or a data-* attribute on
   <html>, so changing one re-paints without re-rendering a single row. */
function applyUiPrefs() {
  const root = document.documentElement;
  applyLook();
  if (UI.theme === "system") root.removeAttribute("data-theme");
  else root.setAttribute("data-theme", UI.theme);
  root.setAttribute("data-pattern", UI.pattern || "none");
  root.setAttribute("data-density", UI.density || "compact");
  root.setAttribute("data-motion", UI.motion || "auto");
  root.setAttribute("data-date-notes", UI.date_notes || "hover");
  root.setAttribute("data-surface", UI.surface || "open");
  root.setAttribute("data-ticks", UI.ticks || "hover");
  root.setAttribute("data-marks", UI.status_marks || "symbols");
  root.setAttribute("data-transition", UI.transition || "fade");
  root.setAttribute("data-transition-strength", UI.transition_strength || "normal");
  root.setAttribute("data-pattern-strength", UI.pattern_strength || "normal");
  if (/^#[0-9a-fA-F]{6}$/.test(UI.pattern_color || "")) root.style.setProperty("--pat", UI.pattern_color);
  else root.style.removeProperty("--pat");
  if (/^#[0-9a-fA-F]{6}$/.test(UI.accent || "")) {
    root.style.setProperty("--accent", UI.accent);
    root.style.setProperty("--on-brand", onColor(UI.accent));
    const meta = $('meta[name="theme-color"]');
    if (meta) meta.content = UI.accent;
  }
  root.style.setProperty("--text-size", (UI.text_size || 14) + "px");
  root.style.setProperty("--font-body", `"${UI.font_body}", system-ui, sans-serif`);
  root.style.setProperty("--font-display", `"${UI.font_head}", Georgia, serif`);
  const scheme = $('meta[name="color-scheme"]');
  if (scheme) scheme.content = UI.theme === "dark" ? "dark"
    : UI.theme === "system" ? "light dark" : "light";
  paintBackground();
  try {
    const mirror = {};
    for (const key of UI_MIRRORED) mirror[key] = UI[key];
    localStorage.setItem("sillybus.ui", JSON.stringify(mirror));
  } catch (err) { /* private mode: the next first paint uses the defaults */ }
}
window.applyUiPrefs = applyUiPrefs;

/* Validated and merged by the server, which is also the thing that refuses a
   bad value — so the reply is the truth and is what we keep, not the patch. */
async function saveUiPrefs(patch) {
  /* Optimistic: the board re-paints before the round trip, because a theme
     that changes 200ms after the click reads as lag. But optimistic has to be
     UNDONE when the server refuses — [MEASURED] 2026-09-18: an http:// shortcut
     was refused with the right sentence and stayed in the page's own state
     until reload, so the Apps page showed a shortcut config.json did not have.
     The snapshot is what makes a refusal leave no trace. */
  const before = UI;
  UI = { ...UI, ...patch };
  applyUiPrefs();
  if (REMOTE) return null;
  try {
    const res = await fetch("/api/prefs", { method: "PUT",
      headers: { "Content-Type": "application/json" }, body: JSON.stringify(patch) });
    const out = await res.json();
    if (res.ok && out.prefs) { UI = { ...UI, ...out.prefs }; applyUiPrefs(); return null; }
    UI = before; applyUiPrefs();
    return (out.error || {}).message || "that setting was not saved";
  } catch (err) {
    UI = before; applyUiPrefs();
    return "that setting was not saved — the app may have restarted";
  }
}
window.saveUiPrefs = saveUiPrefs;

/* The custom background is a FILE in the data home, never bytes in config.json:
   config is read on every request and a pasted GIF would be megabytes of it. */
let BG_URL = "", BG_FILE = "";
function paintBackground() {
  const host = $("#bgmedia");
  if (!host) return;
  const bg = UI.background || {};
  if (!bg.file) {
    host.innerHTML = ""; document.body.classList.remove("has-media");
    if (BG_URL) { URL.revokeObjectURL(BG_URL); BG_URL = ""; BG_FILE = ""; }
    return;
  }
  const opacity = 1 - (typeof bg.opacity === "number" ? bg.opacity : 0.35);
  const show = (src) => {
    host.innerHTML = bg.kind === "video"
      ? `<video src="${esc(src)}" autoplay muted loop playsinline style="opacity:${opacity}"></video>`
      : `<img src="${esc(src)}" alt="" style="opacity:${opacity}">`;
    const media = host.firstElementChild;
    /* if the bytes will not decode, the board must not go black over it */
    media.addEventListener("error", () => {
      host.innerHTML = ""; document.body.classList.remove("has-media");
      appearanceNote("that background could not be shown \u2014 try a JPEG, PNG, GIF, WebP or MP4", true);
    }, { once: true });
    document.body.classList.add("has-media");
  };
  /* [MEASURED] 2026-09-18 from his install: "when I switch between tabs it
     flashes black and white". Opening a tab saves start_tab, which re-applies
     every preference, which repainted the background by rebuilding the <img>
     — and for one frame the black body.has-media showed through. The same
     file on screen keeps its element; only the dim changes. */
  if (BG_URL && BG_FILE === bg.file) {
    const media = host.firstElementChild;
    if (media && media.getAttribute("src") === BG_URL) { media.style.opacity = String(opacity); return; }
    show(BG_URL); return;
  }
  /* [MEASURED] 2026-09-18 from his install: "the custom background just gives
     me a black screen instead of the image". In the extension the app has no
     server: fetch("/api/…") is routed to the Python worker by bridge.js, but an
     <img src="/api/…"> is the BROWSER loading a resource, which the bridge
     never sees — a 404 from the extension origin, a broken image, and the
     black body.has-media paints underneath it. So the bytes come through
     fetch(), which both installs route correctly, and the element gets a
     blob: URL. Loaded once per file and kept. */
  fetch(`/api/prefs/background?v=${encodeURIComponent(bg.file)}`)
    .then((res) => { if (!res.ok) throw new Error(`HTTP ${res.status}`); return res.blob(); })
    .then((blob) => {
      if (BG_URL) URL.revokeObjectURL(BG_URL);
      BG_URL = URL.createObjectURL(blob); BG_FILE = bg.file;
      show(BG_URL);
    })
    .catch((err) => {
      host.innerHTML = ""; document.body.classList.remove("has-media");
      appearanceNote(`the background did not load (${err && err.message ? err.message : err})`, true);
    });
}

/* ---------------- the classes the board is about -------------------------
   A class is on the board when it is an academic course or has open work.
   Free periods and the community period are courses in the feed but are not
   homework, which is what `ui.hidden` is for — and the board SAYS how many it
   is hiding, because nothing may be hidden silently (SPEC §5.5). */
/* What he calls a class. The key never changes, so nothing filed under it
   moves; only the word on the strip, the tab, the band and the page does. */
function displayNameOf(key, fallback) {
  const own = (UI.names || {})[key];
  return own || fallback || key;
}

/* Built once per (state, preferences) pair and reused: ten call sites, and a
   render walks several of them. Both `STATE` and `UI` are replaced wholesale
   when they change (never patched in place for anything this reads), so
   identity is the cache key. */
let COURSE_MEMO = { state: null, ui: null, value: null };
function courseRecords() {
  if (COURSE_MEMO.value && COURSE_MEMO.state === STATE && COURSE_MEMO.ui === UI) return COURSE_MEMO.value;
  const value = courseRecordsUncached();
  COURSE_MEMO = { state: STATE, ui: UI, value };
  return value;
}
function courseRecordsUncached() {
  const byKey = new Map();
  const grades = (STATE && STATE.grades) || [];
  const profiles = (STATE && STATE.profiles) || [];
  const items = (STATE && STATE.items) || [];
  for (const p of profiles) {
    if (!p.course_key) continue;
    byKey.set(p.course_key, {
      key: p.course_key, name: p.display_name || p.course_raw || p.course_key,
      nick: shortName(p.display_name || p.course_raw || p.course_key),
      type: p.course_type || "academic", teacher: p.teacher || "",
      room: (p.meeting || {}).typical_room || "", canvas_url: p.canvas_url || "",
      graded: false, percent: null, letter: "", detail_url: "",
    });
  }
  for (const g of grades) {
    const row = byKey.get(g.course_key) || {
      key: g.course_key, name: g.display_name || g.course_key,
      nick: shortName(g.display_name || g.course_key), type: "academic",
      teacher: "", room: "", canvas_url: "",
    };
    row.graded = !!g.graded; row.percent = g.percent;
    row.letter = g.letter || ""; row.detail_url = g.detail_url || "";
    byKey.set(row.key, row);
  }
  for (const i of items) {
    /* His own items are filed under a course called "Personal" by
       tasks.add(). They belong in Life stuff, and a band for them in the
       Assignments column would rank a run against a lab report — which is
       exactly the separation SPEC §4.7 argues for. */
    if (personalSection(i)) continue;
    if (!i.course_key || byKey.has(i.course_key)) continue;
    byKey.set(i.course_key, { key: i.course_key, name: i.course || i.course_key,
      nick: shortName(i.course || i.course_key), type: "academic", teacher: "", room: "",
      canvas_url: "", graded: false, percent: null, letter: "", detail_url: "" });
  }
  for (const c of byKey.values()) {
    const own = (UI.names || {})[c.key];
    if (own) { c.school_name = c.name; c.name = own; c.nick = shortName(own); }
  }
  const withWork = new Set(items.filter((i) => !i.done && i.course_key && !personalSection(i))
    .map((i) => i.course_key));
  /* [MEASURED] 2026-09-18 from his own install: the tab strip carried "1PF"
     and "5PF" — 1st and 5th Period Free. A free period is a course in the
     class feed and it is not a class: it has no work, no grade and nothing to
     open. `course_type` already says so, and so does a name that is literally
     "Free". Excluded unless it somehow has work or a grade, in which case the
     data disagrees with the label and the data wins. */
  const NOT_A_CLASS = new Set(["free", "lunch", "study_hall"]);
  const looksFree = (c) => /\b(free period|free|lunch|study hall|advisory)\b/i.test(c.name || "");
  return [...byKey.values()].filter((c) => {
    if (c.graded || withWork.has(c.key)) return true;
    if (NOT_A_CLASS.has(c.type) || looksFree(c)) return false;
    return c.type === "academic";
  });
}

/* Order: what he set, then by the period the class meets today or next, then
   by name. A stable order matters more than a clever one — the band a class
   lives in is how it is found without reading. */
/* Which period a class meets: his own word first (Settings -> Classes), then
   the schedule — the next meeting that names a period, or failing that the
   most recent one. 8 is the school's word for a class with no set hours
   (Materials Science, College Counseling); 99 means nothing knows yet. */
function detectedPeriod(key) {
  const sched = (STATE && STATE.schedule) || {};
  const days = Object.keys(sched).sort();
  const today = todayIso();
  const ordered = days.filter((d) => d >= today).concat(days.filter((d) => d < today).reverse());
  for (const day of ordered) {
    for (const m of sched[day] || []) {
      if (m.course_key === key && m.period) return m.period;
    }
  }
  return 99;
}
function coursePeriod(key) {
  const own = (UI.periods || {})[key];
  if (own >= 1 && own <= 9) return own;
  return detectedPeriod(key);
}
function periodLabel(key) {
  const p = coursePeriod(key);
  if (p === 99) return "no period yet";
  if (p === 9) return "every day \u00b7 no period";
  return "period " + p;
}
/* One sort for the board, the strip, the tabs and the Classes page. */
function sortCourses(list) {
  const order = UI.order || [];
  const by = UI.sort || "period";
  return list.slice().sort((a, b) => {
    if (by === "custom") {
      const ia = order.indexOf(a.key), ib = order.indexOf(b.key);
      if (ia !== -1 || ib !== -1) return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib);
    }
    if (by !== "name") {
      const pa = coursePeriod(a.key), pb = coursePeriod(b.key);
      if (pa !== pb) return pa - pb;
    }
    return a.nick.localeCompare(b.nick);
  });
}
function boardCourses() {
  const hidden = new Set(UI.hidden || []);
  const all = courseRecords();
  const shown = sortCourses(all.filter((c) => !hidden.has(c.key)));
  return { shown, hiddenCount: all.length - shown.length, all };
}

/* 3–4 characters, because the column is that wide. His own short code wins;
   otherwise the first letters of the words, which reads better than the first
   three letters of a name ("AP Chemistry" -> "APC", not "AP "). */
/* [MEASURED] 2026-09-18 from his own install: two classes both showed "AEL"
   in the tab strip, because both derive to the same three letters. A code that
   names two things names neither, and the strip is the only label those tabs
   have. His own code always wins; a derived one that collides gains a digit,
   in a stable order so it does not move between refreshes. */
function abbrOf(key, name) {
  const set = UI.abbr || {};
  if (set[key]) return set[key];
  const mine = derivedAbbr(key, name);
  const clash = [];
  for (const c of courseRecords()) {
    if (set[c.key]) continue;                    // his own code, not in the pool
    if (derivedAbbr(c.key, c.name) === mine) clash.push(c.key);
  }
  clash.sort();
  const at = clash.indexOf(key);
  if (clash.length < 2 || at <= 0) return mine;
  return (mine.slice(0, 3) + String(at + 1)).slice(0, 4);
}
function derivedAbbr(key, name) {
  const set = UI.abbr || {};
  if (set[key]) return set[key];
  const words = String(name || key).replace(/[^A-Za-z0-9 ]/g, " ")
    .split(/\s+/).filter((w) => w && !/^(the|and|of|in|to|a|i|ii|iii|iv)$/i.test(w));
  if (words.length >= 3) return words.slice(0, 3).map((w) => w[0]).join("").toUpperCase();
  if (words.length === 2) return (words[0].slice(0, 2) + words[1][0]).toUpperCase();
  return String(words[0] || key).slice(0, 3).toUpperCase();
}

/* nick() trims a long course name to two words, which is right for a row's
   sub-line and wrong for a class's own name: "Science and Religion" becomes
   "Science and", left hanging on a conjunction. This keeps trimming until the
   name ends on a word that can end one. */
const DANGLING = /\s+(and|or|of|the|to|in|for|a|an|&)$/i;
function shortName(name) {
  let out = nick(name);
  while (DANGLING.test(out)) out = out.replace(DANGLING, "");
  return out || nick(name);
}

const KIND_DOT = { test: "t-test", quiz: "t-test", project: "t-project",
                   essay: "t-essay" };
const KIND_WORD = { test: "test", quiz: "quiz", project: "project", essay: "essay",
                    reading: "reading", problem_set: "problem set",
                    assignment: "assignment" };
function kindDot(item) { return KIND_DOT[item.category] || "t-home"; }

function openItems() {
  return ((STATE && STATE.items) || [])
    .filter((i) => !i.done && !personalSection(i))
    .sort((a, b) => (a.due_date || "9999") < (b.due_date || "9999") ? -1 : 1);
}
function openFor(key) { return openItems().filter((i) => i.course_key === key); }

/* The ring colour is how soon the next thing in that class is due — not the
   grade. A 98% with something overdue is not a class to feel good about. */
function urgencyOf(key) {
  /* A quiz or test that already happened is not overdue — there is nothing to
     hand in — so it does not colour the ring. A quiz yesterday turned Biology
     red "overdue" while its real next thing was five days away; the rest of
     the board already skips these (isPastAssessment).
     (prosecution round 4, 2026-10-07) */
  const today = todayIso();
  const open = openFor(key).filter((i) => !isPastAssessment(i, today));
  if (!open.length) return { band: "green", words: "nothing due" };
  const first = open.find((i) => i.due_date);
  if (!first) return { band: "yellow", words: "open work with no date" };
  const away = daysUntil(first.due_date, today);
  if (away < 0) return { band: "red", words: "overdue" };
  if (away === 0) return { band: "red", words: "due today" };
  if (away === 1) return { band: "orange", words: "due tomorrow" };
  if (away <= 7) return { band: "yellow", words: "due this week" };
  return { band: "green", words: "clear for a week" };
}
function statusEmoji(key) {
  const open = openFor(key);
  if (!open.length) return "✅";
  if (open.some((i) => ASSESSMENTS.has(i.category))) return "\u{1F4D5}";
  if (open.some((i) => i.category === "project")) return "\u{1F9E9}";
  return "\u{1F4DD}";
}
/* In the published read-only snapshot, views.js is not shipped: there is no
   server to ask for a gradebook, so `openGradePane` does not exist. A control
   that cannot do anything is worse than no control — it reads as broken
   rather than as absent — so anything that opens a class is a plain label
   there. [PROVEN] tests/test_prosecution.py COUNT 4. */
function classControl(key, inner, cls, title) {
  const attrs = `class="${cls}" title="${esc(title || "")}" data-cls="${esc(title || "")}"`;
  return REMOTE ? `<span ${attrs}>${inner}</span>`
                : `<button type="button" ${attrs} data-class="${esc(key)}">${inner}</button>`;
}

/* `ui.grade_display`: what sits beside a class's name. "none" is a real
   answer — the grade is one click away on the class page, and a live
   percentage in the corner all day is not neutral for everyone. The ring is
   never affected: it is about how soon work is due, not about the grade. */
function gradeWords(c) {
  const mode = UI.grade_display || "percent";
  if (mode === "none") return "";
  // A letter-only grade has nothing else to say. (prosecution round 4, 2026-10-07)
  if (c.graded && typeof c.percent !== "number" && c.letter) return " \u00b7 " + c.letter;
  if (!c.graded || typeof c.percent !== "number") return "";
  if (mode === "letter") return c.letter ? " \u00b7 " + c.letter : "";
  if (mode === "both") return " \u00b7 " + (c.letter ? c.letter + " " : "") + c.percent.toFixed(1) + "%";
  return " \u00b7 " + c.percent.toFixed(1) + "%";
}

function ringHtml(course, size) {
  const u = urgencyOf(course.key);
  const pct = course.graded && typeof course.percent === "number" ? course.percent : 0;
  const r = size / 2 - 2.6, circ = 2 * Math.PI * r, on = (pct / 100) * circ;
  const half = size / 2;
  return `<span class="ring band-${u.band}" style="width:${size}px;height:${size}px"
      title="${esc(u.words)}">
    <svg viewBox="0 0 ${size} ${size}" width="${size}" height="${size}" aria-hidden="true">
      <circle cx="${half}" cy="${half}" r="${r}" fill="none" stroke="var(--track)" stroke-width="3"/>
      <circle cx="${half}" cy="${half}" r="${r}" fill="none" stroke="var(--band)" stroke-width="3"
        stroke-linecap="round" stroke-dasharray="${on.toFixed(2)} ${circ.toFixed(2)}"
        transform="rotate(-90 ${half} ${half})"/>
    </svg><b style="font-size:${Math.round(size * 0.34)}px">${course.graded ? esc(course.letter || "?") : "–"}</b>
    <span class="em">${statusEmoji(course.key)}</span></span>`;
}

/* ---------------- date_note in a column with no room for the sentence -----
   SPEC §5.9: an inferred date is never presented as a stated one. These four
   extractors were TOLD the date — Canvas said it, the doc wrote it out, or he
   typed it himself. Everything else worked it out from a day number, a
   weekday letter, a month heading or a model, and gets the marker. */
const STATED_DATE = new Set(["canvas_stated", "absolute", "manual", "quickadd"]);
function dateWasInferred(item) {
  if (!item.date_note) return false;
  return !STATED_DATE.has(item.extractor);
}
function dateNoteHtml(item) {
  if (!item.date_note) return "";
  if ((UI.date_notes || "hover") === "always") {
    return `<span class="dnote-full">${esc(item.date_note)}</span>`;
  }
  if (!dateWasInferred(item)) return "";
  /* tabindex, not just title: a marker reachable only with a mouse is a
     marker that is not there for anyone using a keyboard. */
  return `<i class="dnote" tabindex="0" role="note"
    title="${esc(item.date_note)}" aria-label="${esc("where this date came from: " + item.date_note)}">◇</i>`;
}

/* ---------------- quick links -------------------------------------------
   Drawn in house at this board's own stroke weight and corner radius, tinted
   from each service's colour — not pasted brand art. Ported from the mockup's
   LOGOS as they stand. */
const LOGOS = {
  canvas: { hue: "#d64027", svg: `<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="4.1" stroke="currentColor" stroke-width="2"/>${
    [0, 45, 90, 135, 180, 225, 270, 315].map((a) => {
      const r = 9.2, x = 12 + r * Math.cos(a * Math.PI / 180), y = 12 + r * Math.sin(a * Math.PI / 180);
      return `<circle cx="${x.toFixed(2)}" cy="${y.toFixed(2)}" r="${a % 90 === 0 ? 1.9 : 1.3}" fill="currentColor"/>`;
    }).join("")}</svg>` },
  veracross: { hue: "#1f6feb", svg: `<svg viewBox="0 0 24 24" fill="none">
    <path d="M4 4.5 12 19 20 4.5" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"/>
    <path d="M12 7.5v6M9 10.5h6" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>` },
  ap: { hue: "#6d4aff", svg: `<svg viewBox="0 0 24 24" fill="none">
    <rect x="2.6" y="3.6" width="18.8" height="16.8" rx="4.4" stroke="currentColor" stroke-width="1.9"/>
    <path d="M6.6 15.6 9.1 8.4l2.5 7.2M7.4 13.4h3.4" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M13.9 15.6V8.4h2.3a2.2 2.2 0 0 1 0 4.4h-2.3" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>` },
  docs: { hue: "#2b74e0", svg: `<svg viewBox="0 0 24 24" fill="none">
    <path d="M6 2.8h7.4L19 8.4v12.8H6z" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round"/>
    <path d="M13.2 2.9v5.6H18.8" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round"/>
    <path d="M9 12.4h7M9 15.4h7M9 18.4h4.4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>` },
  drive: { hue: "#12a150", svg: `<svg viewBox="0 0 24 24" fill="none">
    <path d="M9.4 3.2h5.2l6.2 10.7h-5.2z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>
    <path d="M9.4 3.2 3.2 13.9l2.6 4.5 6.2-10.7z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>
    <path d="M5.8 18.4h12.4l2.6-4.5H8.4z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>` },
  onshape: { hue: "#0f8a8a", svg: `<svg viewBox="0 0 24 24" fill="none">
    <path d="M12 2.9 20.2 7v10L12 21.1 3.8 17V7z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>
    <path d="M3.9 7 12 11.3 20.1 7M12 11.3V21" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>` },
  quizlet: { hue: "#4255ff", svg: `<svg viewBox="0 0 24 24" fill="none">
    <circle cx="11" cy="11" r="7.6" stroke="currentColor" stroke-width="1.9"/>
    <path d="M14.4 14.6 20 20.4" stroke="currentColor" stroke-width="2.1" stroke-linecap="round"/></svg>` },
  library: { hue: "#a1571f", svg: `<svg viewBox="0 0 24 24" fill="none">
    <path d="M3.6 5.2h6.1a2.3 2.3 0 0 1 2.3 2.3v11a1.8 1.8 0 0 0-1.8-1.8H3.6z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>
    <path d="M20.4 5.2h-6.1A2.3 2.3 0 0 0 12 7.5v11a1.8 1.8 0 0 1 1.8-1.8h6.6z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>` },
  khan: { hue: "#14bf96", svg: `<svg viewBox="0 0 24 24" fill="none">
    <path d="M12 2.6 20.4 7v10L12 21.4 3.6 17V7z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>
    <path d="M9 9.2a3 3 0 1 1 6 0c0 2.2-3 2.6-3 4.8" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>
    <circle cx="12" cy="16.9" r=".9" fill="currentColor"/></svg>` },
  school: { hue: "#7a5af5", svg: `<svg viewBox="0 0 24 24" fill="none">
    <path d="M3.5 9.5 12 5l8.5 4.5L12 14z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>
    <path d="M6.5 11.3v4.2c0 1.4 2.5 2.8 5.5 2.8s5.5-1.4 5.5-2.8v-4.2M20.5 9.5v5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>` },
  /* [ASKED] 2026-09-20: "update the albert.io icon to not be the same as
     APCR". A lowercase a in a circle, in amber — nothing else in the strip
     is amber, and the AP mark keeps its violet, so the two read apart. */
  albert: { hue: "#c4831c", svg: `<svg viewBox="0 0 24 24" fill="none">
    <circle cx="12" cy="12" r="9.2" stroke="currentColor" stroke-width="1.9"/>
    <path d="M14.6 9.6v6.2M14.6 12.7a2.9 2.9 0 1 1-5.8 0 2.9 2.9 0 0 1 5.8 0" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>` },
  /* The programs a calendar address comes out of. Drawn here at the same
     stroke weight as the rest rather than pasted brand art, for the same
     reason the note above gives — and because a tile grid of real logos
     reads as an advert for them rather than a list of what this can read. */
  gcal: { hue: "#2b74e0", svg: `<svg viewBox="0 0 24 24" fill="none">
    <rect x="3.2" y="4.6" width="17.6" height="16.2" rx="3.2" stroke="currentColor" stroke-width="1.9"/>
    <path d="M3.4 9.4h17.2M8 2.9v3.6M16 2.9v3.6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
    <path d="M10.2 13.4h3.4l-2.4 2.6a1.9 1.9 0 1 1-1.6 2.9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>` },
  classroom: { hue: "#12a150", svg: `<svg viewBox="0 0 24 24" fill="none">
    <rect x="2.8" y="4.4" width="18.4" height="15.2" rx="3" stroke="currentColor" stroke-width="1.9"/>
    <circle cx="12" cy="10.6" r="2.1" stroke="currentColor" stroke-width="1.7"/>
    <path d="M7.6 16.6a4.6 4.6 0 0 1 8.8 0" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>
    <path d="M5.9 15.4v-2.2M18.1 15.4v-2.2" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>` },
  teamsnap: { hue: "#c4831c", svg: `<svg viewBox="0 0 24 24" fill="none">
    <circle cx="12" cy="12" r="9.1" stroke="currentColor" stroke-width="1.9"/>
    <path d="M4.4 8.2c3.4 1.1 5.6 3.5 6.6 7.1M19.6 8.2c-3.4 1.1-5.6 3.5-6.6 7.1M12 2.9v4.2"
      stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>` },
  apple: { hue: "#6b7280", svg: `<svg viewBox="0 0 24 24" fill="none">
    <rect x="3.2" y="4.6" width="17.6" height="16.2" rx="3.2" stroke="currentColor" stroke-width="1.9"/>
    <path d="M3.4 9.4h17.2M8 2.9v3.6M16 2.9v3.6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
    <path d="M8.6 17.2v-4.4l-1.4.9M13 17.2h3.4l-2-2.6a1.7 1.7 0 1 0-1.4-2.4"
      stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>` },
  link: { hue: "#6b7280", svg: `<svg viewBox="0 0 24 24" fill="none">
    <path d="M10 14a4 4 0 0 1 0-5.6l2.4-2.4a4 4 0 0 1 5.6 5.6L16.8 12.8" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
    <path d="M14 10a4 4 0 0 1 0 5.6l-2.4 2.4a4 4 0 0 1-5.6-5.6l1.2-1.2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>` },
  gear: { hue: "#6b7280", svg: `<svg viewBox="0 0 24 24" fill="none">
    <circle cx="12" cy="12" r="3.2" stroke="currentColor" stroke-width="1.9"/>
    <path d="M12 2.8v2.4M12 18.8v2.4M21.2 12h-2.4M5.2 12H2.8M18.5 5.5l-1.7 1.7M7.2 16.8l-1.7 1.7M18.5 18.5l-1.7-1.7M7.2 7.2 5.5 5.5"
      stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>` },
};
function markHtml(id) {
  const l = LOGOS[id] || LOGOS.docs;
  return `<span class="lmark" style="--brand:${l.hue};color:${l.hue}">${l.svg}</span>`;
}

/* Only what the data gives evidence for. A quick link to a site this student
   does not use would be an invented link, and the board does not invent
   (SPEC §5.10) — so each one is keyed off something really in the state. */
const LINK_SITES = [
  ["instructure.com", "canvas", "Canvas"],
  ["veracross.com", "veracross", "Veracross"],
  ["collegeboard.org", "ap", "AP Classroom"],
  ["docs.google.com", "docs", "Google Docs"],
  ["drive.google.com", "drive", "Drive"],
  ["cad.onshape.com", "onshape", "Onshape"],
  ["quizlet.com", "quizlet", "Quizlet"],
  ["khanacademy.org", "khan", "Khan Academy"],
  ["schoology.com", "school", "Schoology"],
  ["powerschool.com", "school", "PowerSchool"],
  ["myschoolapp.com", "school", "Blackbaud"],
  ["albert.io", "albert", "Albert.io"],
];
/* Which hostnames belong to a connector that is switched off.

   [ASKED] 2026-09-20: "you should be able to turn off connectors/shortcuts
   entirely (like apcr and albert) bc not everyone uses all of them and its
   annoying if you don't." A quick link is EARNED from the data, which meant
   a site a teacher linked to once kept its chip forever — so switching AP
   Classroom off still left AP Classroom in the strip. The map is the same
   one Python uses (sillybus/connectors.py); it is short enough to say twice
   and a test holds the two together. */
const CONNECTOR_HOSTS = {
  google_classroom: ["classroom.google.com"],
  ap_classroom: ["collegeboard.org"],
  albert: ["albert.io"],
  veracross_assignments: ["veracross.com"],
};
function connectorOff() {
  const on = (STATE && STATE.sources) || {};
  const hosts = [];
  for (const [name, list] of Object.entries(CONNECTOR_HOSTS)) {
    if (on[name] === false) hosts.push(...list);
  }
  return hosts;
}
const hiddenLinkNames = () => new Set((UI.hidden_links || []).map((n) => String(n).toLowerCase()));

function quickLinks() {
  const seen = new Map();
  const dead = connectorOff();
  const hidden = hiddenLinkNames();
  const add = (url) => {
    if (!url || !/^https?:/i.test(url)) return;
    let host = "";
    try { host = new URL(url).hostname; } catch (err) { return; }
    if (dead.some((h) => host === h || host.endsWith("." + h))) return;
    for (const [needle, logo, name] of LINK_SITES) {
      if (!host.endsWith(needle) && host !== needle) continue;
      if (hidden.has(name.toLowerCase())) return;
      if (!seen.has(name)) seen.set(name, { name, logo, url: `https://${host}/`, host });
      return;
    }
  };
  add((STATE && STATE.veracross_portal) || "");
  for (const p of (STATE && STATE.profiles) || []) add(p.canvas_url);
  const per = ((STATE && STATE.diagnostics) || {}).per_course || {};
  for (const key of Object.keys(per)) {
    for (const l of (per[key] || {}).course_links || []) add(l.url);
  }
  for (const i of (STATE && STATE.items) || []) {
    add(i.url);
    for (const l of i.links || []) add(l.url);
    if (seen.size >= LINK_SITES.length) break;
  }
  /* His own shortcuts, after the earned ones. A quick link is otherwise a
     FACT the data carries; these are marked as his so the two never blur. */
  for (const sc of UI.shortcuts || []) {
    if (!sc || !/^https:/i.test(sc.url || "")) continue;
    if (hidden.has(String(sc.name || "").toLowerCase())) continue;
    let host = "";
    try { host = new URL(sc.url).hostname; } catch (err) { continue; }
    const known = LINK_SITES.find(([needle]) => host === needle || host.endsWith("." + needle) || host.endsWith(needle));
    if (!seen.has(sc.name)) seen.set(sc.name, { name: sc.name, logo: known ? known[1] : "link", url: sc.url, host, mine: true });
  }
  return [...seen.values()];
}
function linksRowHtml(mode) {
  const links = quickLinks();
  const counts = countPerSite(links);
  /* A site that is not answering is marked HERE, on the thing itself, which is
     the other half of collapsing the banners: the count is in the strip, the
     name is on the link, and the sentence is one hover away. */
  const broken = {};
  for (const err of (STATE && STATE.errors) || []) {
    const site = SOURCE_LABEL[err.code];
    if (site) broken[site] = String(err.message || "").replace(/\s*(?:[\u2014-]\s*)?fix:.*$/i, "").trim();
  }
  /* Every chip carries its own off switch. The switches were already on
     Settings → Apps, which is two clicks and a scroll away from the thing
     that is annoying you; [ASKED] 2026-09-20, "its annoying if you don't
     [use them]", so it is here, where you are looking at it. Hidden on
     hover/focus only, so the strip is unchanged until you go for it, and
     everything hidden is listed with a "show again" in Settings. */
  return `<div class="links ${esc(mode || "")}">${links.map((l) =>
    `<span class="qwrap"><a class="qlink ${broken[l.name] ? "bad" : ""}" href="${esc(l.url)}" target="_blank" rel="noopener"
      title="${esc(broken[l.name] ? l.name + " is not answering: " + broken[l.name] : l.name + " \u00b7 " + l.host + (l.mine ? " \u00b7 yours" : ""))}">
      ${markHtml(l.logo)}<span class="txt"><b>${esc(l.name)}</b>${
        broken[l.name] ? `<i class="badnote">not answering</i>`
          : l.mine ? `<i>yours</i>` : counts[l.name] ? `<i>${esc(counts[l.name])}</i>` : ""}</span>
      <span class="arr">${broken[l.name] ? "!" : "\u2197"}</span></a>${REMOTE ? "" :
      `<button type="button" class="qhide" data-hide-link="${esc(l.name)}"
        title="${esc("Hide " + l.name + " — Settings → Apps puts it back")}"
        aria-label="${esc("Hide " + l.name)}">×</button>`}</span>`).join("")
    }${deadWithoutLink(broken, links).map((site) => `<button type="button" class="qlink bad" data-open-settings="connections"
        title="${esc(site + " is not answering: " + broken[site] + " — opens Connections, where the fix is")}">
        ${markHtml(siteLogoFor(site))}<span class="txt"><b>${esc(site)}</b><i class="badnote">not answering</i></span>
        <span class="arr">!</span></button>`).join("")
    }${setupMarkHtml()}${MARKS.concat(sessionMarks()).map((m) => `<button type="button" class="qlink mark ${esc(m.cls)}" data-mark="${esc(m.go)}"
        title="${esc(m.title)}"><span class="txt"><b>${esc(m.text)}</b></span><span class="arr">${m.cls === "bad" ? "!" : "\u2192"}</span></button>`).join("")
    }${REMOTE ? "" : `<button type="button" class="qlink" data-view="settings" title="settings">
      ${markHtml("gear")}<span class="txt"><b>Settings</b></span></button>`}</div>`;
}
function deadWithoutLink(broken, links) {
  const have = new Set(links.map((l) => l.name));
  return Object.keys(broken).filter((site) => !have.has(site));
}
function siteLogoFor(site) {
  return { "Canvas": "canvas", "Veracross": "veracross", "AP Classroom": "ap", "Albert.io": "albert" }[site] || "link";
}
/* the setup nudge, as a mark rather than a banner */
/* The extension's keep-alive noticed a school portal signed him out. The
   mark is the sentence and the link; Chrome's password manager does the
   typing on the page it opens, and the next keep-alive clears the mark. */
function sessionMarks() {
  const sessions = (window.sdChrome && window.sdChrome.sessions) || {};
  return Object.entries(sessions).filter(([, r]) => !r.ok && r.url).map(([name, r]) => ({
    id: "session:" + name, text: `${name} signed you out`, cls: "bad",
    title: `${name} closed the session. Click to open its sign-in page in a new tab; Chrome fills your saved password and this tab stays warm.`,
    go: "open:" + r.url }));
}
function setupMarkHtml() {
  const pending = (window.setupPending && window.setupPending()) || [];
  if (!pending.length || REMOTE) return "";
  return `<button type="button" class="qlink mark warn" data-view="setup"
    title="${esc("Not fully set up yet: " + pending.join(", ") + ". Click to finish.")}">
    <span class="txt"><b>finish setting up</b><i>${esc(pending.length + " step" + (pending.length === 1 ? "" : "s"))}</i></span>
    <span class="arr">\u2192</span></button>`;
}
document.addEventListener("click", (event) => {
  const m = event.target.closest("button[data-mark]");
  if (m) {
    const go = m.dataset.mark;
    if (go === "reload") location.reload();
    else if (go === "refresh") refresh();
    else if (go.startsWith("open:")) window.open(hrefOf(go.slice(5)), "_blank", "noopener");
    else if (go.startsWith("settings:")) { if (window.showView) window.showView("settings"); if (window.showSetPage) window.showSetPage(go.split(":")[1]); }
    return;
  }
  const os = event.target.closest("button[data-open-settings]");
  if (os) { if (window.showView) window.showView("settings"); if (window.showSetPage) window.showSetPage(os.dataset.openSettings); }
  const hide = event.target.closest("button[data-hide-link]");
  if (hide) {
    event.preventDefault();
    hideQuickLink(hide.dataset.hideLink);
  }
});
/* Switching a chip off, and back on. One writer for both, so the strip and
   the Settings list can never disagree about what is hidden. */
async function hideQuickLink(name) {
  const list = (UI.hidden_links || []).slice();
  if (!list.some((n) => String(n).toLowerCase() === String(name).toLowerCase())) list.push(name);
  const problem = await saveUiPrefs({ hidden_links: list });
  renderQuickLinks();
  if (PANE === "settings") keepScroll(renderAppsPage);
  return problem;
}
async function showQuickLink(name) {
  const list = (UI.hidden_links || []).filter((n) => String(n).toLowerCase() !== String(name).toLowerCase());
  const problem = await saveUiPrefs({ hidden_links: list });
  renderQuickLinks();
  if (PANE === "settings") keepScroll(renderAppsPage);
  return problem;
}
function renderQuickLinks() {
  const host = $("#toplinks");
  if (!host) return;
  /* the format tabs for this one sit beside it in the top bar, not in a
     section header — there is no section header up there */
  host.innerHTML = sectionHtml("links") + formatTabsHtml("links");
}
/* The small line under a quick link says what is really behind it — how many
   classes Canvas is carrying, when Veracross was last read. Never a guess. */
function countPerSite(links) {
  const out = {};
  const courses = ((STATE && STATE.profiles) || []).filter((p) => p.course_type === "academic").length;
  for (const l of links) {
    if (l.name === "Canvas" && courses) out[l.name] = `${courses} courses`;
    if (l.name === "Veracross" && STATE && STATE.grades_read_at) {
      out[l.name] = "grades " + relDays((STATE.grades_read_at || "").slice(0, 10), todayIso());
    }
    if (l.name === "AP Classroom") {
      const n = ((STATE && STATE.items) || []).filter((i) => i.source === "ap_classroom" && !i.done).length;
      if (n) out[l.name] = `${n} open`;
    }
  }
  return out;
}

/* ---------------- the sections ------------------------------------------ */
function secCalendarHtml() {
  const today = todayIso();
  const sched = ((STATE && STATE.schedule) || {})[today] || [];
  const now = (STATE && STATE.now) || "";
  const due = openItems().filter((i) => i.due_date === today);
  if (!sched.length) {
    return `<div class="secempty">No classes today.</div>`
      + (due.length ? `<div class="cal-day">${due.slice(0, 4).map((i) =>
        `<button type="button" class="perrow" data-open="${esc(i.item_id)}">
          <span class="t">due</span><span class="grow"><span class="n">${esc(i.title)}</span></span></button>`).join("")}</div>` : "");
  }
  return `<div class="cal-day">${sched.map((m) => {
    const key = m.course_key;
    const name = nick(m.course_raw || key);
    const mine = due.filter((i) => i.course_key === key);
    const on = now && m.start <= now && now <= m.end;
    return classControl(key, `<span class="t">${esc((m.start || "").slice(11, 16))}</span>
      <span class="grow"><span class="n">${esc(name)}</span>
      ${m.room ? `<span class="rm"> ${esc(m.room)}</span>` : ""}
      ${mine.map((i) => `<span class="due">▸ ${esc(i.title)}</span>`).join("")}</span>`,
      `perrow ${on ? "now" : ""}`, name);
  }).join("")}</div>`;
}

/* Recent chats reads the same history the chat pane replays, so the two can
   never disagree about what was asked. */
let CHAT_RECENT = [];
/* question paired with the answer it got, for the "With answer" format. Built
   from the same fetch as CHAT_RECENT so the two cannot disagree. */
let CHAT_PAIRS = [];

/* ---- Accelerates belong in the Recent list too -------------------------------
 *
 * [ASKED] 2026-09-20: "i want it to show thinking while an accelerate is being
 * made and those should show up in the recent chats section." Two things, and
 * both are about the same blind spot: pressing ⚡ used to open a panel that sat
 * on one unchanging sentence for a minute and a half, and once it finished the
 * guide existed only behind the assignment it came from. Nothing on the board
 * ever said a guide had been written, so the way back to one was to remember
 * which assignment it was.
 *
 * So the section is a feed of everything asked of the AI — questions and study
 * guides, newest first — and a guide being written right now sits at the top of
 * it with its thinking on screen as it happens.
 */
let ACCEL_RECENT = [];   // finished guides, newest first
let ACCEL_LIVE = null;   // the one being written: {itemId, title, lines, failed}

async function loadAccelRecent() {
  if (REMOTE) return;
  try {
    const res = await fetch("/api/accelerations");
    if (!res.ok) return;
    ACCEL_RECENT = (await res.json()).guides || [];
  } catch (err) { /* the list is a convenience; the board is not */ }
}
window.loadAccelRecent = loadAccelRecent;

/* Redraw the one section, not the board: a guide emits a line every few
   seconds and rebuilding every row under the mouse for each of them is how
   the minute-poll used to make the board twitch. */
function paintChats() {
  const box = $("#sec-chats");
  if (box) box.innerHTML = sectionHtml("chats");
  const note = document.querySelector("#head-chats .note");
  if (note) note.textContent = chatsNote();
}
function chatsNote() {
  if (ACCEL_LIVE && !ACCEL_LIVE.failed) return "writing a study guide…";
  const bits = [];
  if (CHAT_RECENT.length) bits.push(`${CHAT_RECENT.length} asked`);
  if (ACCEL_RECENT.length) bits.push(`${ACCEL_RECENT.length} guide${ACCEL_RECENT.length === 1 ? "" : "s"}`);
  return bits.join(" · ");
}

/* views.js drives these three while a guide is being written. They are on
   window because the accelerate panel lives in the other file. */
window.accelLiveStart = (itemId, title) => {
  ACCEL_LIVE = { itemId, title: title || "this assignment", lines: [], failed: "" };
  paintChats();
};
window.accelLiveLine = (line) => {
  if (!ACCEL_LIVE || !line) return;
  const text = String(line).trim();
  if (!text || ACCEL_LIVE.lines[ACCEL_LIVE.lines.length - 1] === text) return;
  ACCEL_LIVE.lines.push(text);
  paintChats();
};
window.accelLiveEnd = async (failure) => {
  if (!ACCEL_LIVE) return;
  if (failure) {
    /* A failure stays on the board for a moment rather than vanishing: the
       panel it happened in may already be closed. */
    ACCEL_LIVE.failed = String(failure);
    paintChats();
    const stale = ACCEL_LIVE;
    setTimeout(() => { if (ACCEL_LIVE === stale) { ACCEL_LIVE = null; paintChats(); } }, 20000);
    return;
  }
  ACCEL_LIVE = null;
  await loadAccelRecent();
  paintChats();
};

/* Questions and guides interleaved by when they happened. Both timestamps are
   local ISO seconds (db._now and chat_messages.asked_at), so they sort as
   text. */
function recentFeed(limit) {
  const rows = CHAT_RECENT.map((m) => ({
    kind: "chat", at: m.at || "", text: m.text || "", sub: "" }));
  for (const g of ACCEL_RECENT) {
    if (ACCEL_LIVE && ACCEL_LIVE.itemId === g.item_id) continue;
    rows.push({ kind: "accel", at: g.created || "", itemId: g.item_id,
                text: g.title || "study guide", sub: g.headline || "" });
  }
  rows.sort((a, b) => (b.at || "").localeCompare(a.at || ""));
  return rows.slice(0, limit);
}
const clockOf = (at) => (at || "").slice(11, 16);

function feedRowHtml(row, withSub) {
  const when = clockOf(row.at) ? `<i>${esc(clockOf(row.at))}</i>` : "";
  if (row.kind === "accel") {
    return `<button type="button" class="thread guide" data-open-accel="${esc(row.itemId)}"
      title="open the study guide for ${esc(row.text)}">
      <b><span class="bolt">⚡</span>${esc(row.text)}</b>
      ${withSub && row.sub ? `<u>${esc(row.sub)}</u>` : ""}${when}</button>`;
  }
  return `<button type="button" class="thread" data-view="chat">
    <b>${esc(row.text)}</b>${when}</button>`;
}

/* The guide being written right now: the line it is on, large, with the ones
   it has already passed dimmed underneath. This is the "thinking". */
function accelLiveHtml() {
  if (!ACCEL_LIVE) return "";
  const title = esc(ACCEL_LIVE.title);
  if (ACCEL_LIVE.failed) {
    return `<div class="thinking failed">
      <b><span class="bolt">⚡</span>${title}</b>
      <u>${esc(ACCEL_LIVE.failed)}</u>
      <button type="button" class="lchip" data-open-accel="${esc(ACCEL_LIVE.itemId)}">try again ›</button>
    </div>`;
  }
  const lines = ACCEL_LIVE.lines;
  const now = lines[lines.length - 1] || "reading the assignment…";
  const before = lines.slice(Math.max(0, lines.length - 3), lines.length - 1);
  return `<button type="button" class="thinking" data-open-accel="${esc(ACCEL_LIVE.itemId)}"
    title="open the guide being written">
    <b><span class="bolt spin">⚡</span>${title}</b>
    <u class="think-now">${esc(now)}</u>
    ${before.length ? `<span class="think-past">${before.reverse().map((l) =>
      `<span>${esc(l)}</span>`).join("")}</span>` : ""}
    <span class="think-bar"><i></i></span></button>`;
}

function secChatsHtml() {
  const rows = recentFeed(5);
  if (!rows.length && !ACCEL_LIVE) {
    return `<div class="secempty">Nothing asked yet — the box below is the way in.</div>`;
  }
  return `${accelLiveHtml()}<div class="threads">${rows.map((r) =>
    feedRowHtml(r, false)).join("")}</div>`;
}

/* Life stuff: his own items, the ones a refresh never overwrites. Backed by
   POST/DELETE /api/tasks with extractor "manual" — no new store. */
const LIFE_KINDS = [["goals", "goals"], ["practice", "practice"],
                    ["clubs", "clubs"], ["makeup", "makeup"]];
function lifeOpen() {
  return ((STATE && STATE.items) || []).filter((i) => !i.done && personalSection(i));
}
function secLifeHtml() {
  const mine = lifeOpen();
  return `<div class="lifekinds">${LIFE_KINDS.map(([key, label]) => {
    const list = mine.filter((i) => (i.flags || []).includes("section:" + key)
      || (key === "goals" && !LIFE_KINDS.some(([k]) => (i.flags || []).includes("section:" + k))));
    return `<div><div class="kindlab">${esc(label)}</div>${
      list.map((i) => `<button type="button" class="lchip" data-open="${esc(i.item_id)}">
        <span class="grow trunc">${esc(i.title)}</span>
        <em>${esc(i.due_date ? relDays(i.due_date, todayIso()) : "someday")}</em></button>`).join("")
      || `<div class="secempty">—</div>`}</div>`;
  }).join("")}</div>`;
}

function secClassesHtml() {
  const { shown } = boardCourses();
  if (!shown.length) return `<div class="secempty">No classes read yet — press Refresh.</div>`;
  return `<div class="clsstrip">${shown.map((c) => classControl(c.key,
    `${ringHtml(c, 28)}
      <span class="grow"><span class="clsname">${esc(c.nick)}</span>
      <span class="clsmeta">${esc(openFor(c.key).length + " open")}${esc(gradeWords(c))}</span></span>`,
    `clschip ${SELECTED_CLASS === c.key ? "on" : ""}`, c.name)).join("")}</div>`;
}

/* ---------------- the Assignments column -------------------------------
   Every class gets the same band, so how many of its items fit depends on
   what else is on the board. Rather than guess a cap, the rows are laid out
   with `minmax(0, 1fr)` — a plain `1fr` grows past its share, so nothing ever
   overflows and the counter reads zero forever — and fitBands() measures
   after paint and says how many did not fit. */
/* Every status a row has, as a small mark with the word on hover. [ASKED]
   2026-09-18: "show all applicable status symbols (hw, test, overdue, etc.)".
   The kind is always first and keeps the kind colour the dot had, so the
   column still reads at a glance; the rest appear only when true. Under
   `status_marks: "dot"` the CSS collapses this back to the one dot. */
const KIND_GLYPH = { test: "T", quiz: "Q", project: "P", essay: "E", reading: "R",
                     problem_set: "PS", assignment: "HW" };
/* [ASKED] 2026-09-18: "show all applicable status symbols (hw, test, overdue,
   etc.)" — and they are all still here. But there were six possible marks
   then and there are ten now, and [MEASURED] 2026-09-22 at 995x605, which is
   the window he actually has: a row carrying nine of them spent 140px of a
   175px column on badges and rendered the assignment's NAME at zero pixels
   wide. A row you cannot read the title of is not a row.

   So: the kind always survives, the next few in the order they were added,
   and whatever is left folds into one chip that names them on hover. Nothing
   is dropped — the count and the words are both still there — and the title
   keeps its width. The CSS floor under `.ttl` is the second half of this and
   exists so the next mark anyone adds cannot bring the bug back.

   The budget is 4 because 5 did not fit. [MEASURED] 2026-09-22, same window:
   at 5 the badges plus the title floor plus the date came to more than the
   column, and the first fix for THAT — letting `.smarks` shrink and clip —
   was worse than the bug, because a clipped badge is a status that is simply
   gone with nothing on screen saying so, which is the silent hiding SPEC §5.5
   exists to forbid. Marks never shrink and never clip; the count is what
   bounds them. */
const MARK_BUDGET = 4;
/* Named `statusMarkHtml`, not `markHtml`. [MEASURED] 2026-09-23: it WAS
   `markHtml`, which is also the name of the logo writer 400 lines above — and
   a redeclared function is legal JavaScript, so nothing complained and the
   later one simply won. Every logo in the app broke at once: the site chips
   in the top bar, the Settings button, the Apps list, the Veracross row, the
   quick links, and all thirteen connector tiles, each rendering the literal
   word "undefined". `node --check` passes on it, and no test looked. */
function statusMarkHtml(m) {
  return `<i class="sm ${esc(m.cls)}" title="${esc(m.hover)}">${m.glyph}</i>`;
}
function trimMarks(marks) {
  if (marks.length <= MARK_BUDGET) return marks.map(statusMarkHtml).join("");
  const hidden = marks.slice(MARK_BUDGET);
  const words = [...new Set(hidden.map((m) => m.word))].join(" \u00B7 ");
  return marks.slice(0, MARK_BUDGET).map(statusMarkHtml).join("")
    + `<i class="sm more" title="${esc(words)}">+${hidden.length}</i>`;
}

function statusMarksHtml(item, today) {
  const kind = item.category || "assignment";
  /* Each mark is (glyph, the word on hover, the short word the overflow chip
     uses). The third is not the second truncated: `date_note` is a whole
     sentence, and an overflow tooltip built from sentences read "no date on
     Canvas; inferred · no date on Canvas; inferred · …" — the same long line
     twice, naming nothing. A chip that says what is hidden has to say it in
     one or two words. */
  const marks = [];
  const add = (cls, glyph, hover, word) =>
    marks.push({ cls, glyph, hover, word: word || hover });
  add(`k ${kindDot(item)}`, KIND_GLYPH[kind] || "HW",
      KIND_WORD[kind] || "homework", KIND_WORD[kind] || "homework");
  const away = item.due_date ? daysUntil(item.due_date, today) : null;
  if (away !== null && away < 0 && !item.done)
    add("late", "!", `overdue by ${-away} day${away === -1 ? "" : "s"}`, "overdue");
  const study = studyHint(item, today);
  if (study) add("study", "S", study, "start early");
  if (item.submitted) add("in", "\u2713", "handed in on Canvas", "handed in");
  if (item.source === "custom") add("yours", "\u2605", "you added this", "yours");
  if (item.source === "ap_classroom") add("ap", "AP", "AP Classroom", "AP Classroom");
  if (item.date_note && /inferred|guess|assumed|no date/i.test(item.date_note))
    add("guess", "?", item.date_note, "date worked out, not stated");
  /* Where a date came from, when it did not simply come from Canvas.
     [ASKED] 2026-09-22: "it is not always the day it was assigned some times
     is says it in the discriptions". A date read out of a teacher's own words,
     and a date the words disagree with, are both worth seeing from the column
     rather than only after opening the row — the whole point of the
     correction is the one that is wrong at a glance. */
  const flags = item.flags || [];
  if (flags.includes("date_moved"))
    add("moved", "\u21B3", item.date_note, "date moved by the description");
  else if (flags.includes("date_from_description"))
    add("fromtext", "\u201C\u201D", item.date_note, "date from the description");
  if (flags.includes("date_conflict"))
    add("clash", "\u2260", item.date_note, "Canvas and the description disagree");
  if (flags.includes("looks_repeated"))
    add("twice", "2\u00D7", "this looks like the same work listed twice — "
        + "nothing has been removed", "looks listed twice");
  if (item.repeat)
    add("again", "\u21BB", item.repeat.says, "comes round again");
  return `<span class="smarks">${trimMarks(marks)}</span>`;
}
/* A row is a tick and a button side by side — not a button inside a button,
   which is invalid and which Chrome silently un-nests. The tick appears on
   hover (or always: `ticks`), sitting over the marks so the compact column
   gives up no width for it. */
function workItemHtml(item) {
  const today = todayIso();
  return `<div class="asitem" data-item="${esc(item.item_id)}">
    <button type="button" class="astick" data-tick="${esc(item.item_id)}"
      aria-label="mark ${esc(item.title)} done" title="mark done"></button>
    <button type="button" class="asgo" data-open="${esc(item.item_id)}">
    ${statusMarksHtml(item, today)}
    <span class="ttl">${esc(item.title)}</span>${dateNoteHtml(item)}
    <em class="${esc(urgencyWord(item.due_date, today, item))}">${esc(item.due_date
      ? relDays(item.due_date, today) : undatedWord(item))}</em></button></div>`;
}
/* Ticking is optimistic: the row goes at once and the server is told after,
   because a tick that waits for a round trip feels broken. toggleDone()
   reloads the state, so a refused tick comes back on its own. */
async function tickItem(itemId, done) {
  const item = (STATE && STATE.items || []).find((i) => i.item_id === itemId);
  if (item) { item.done = done; renderStudio(); if (PANE === "done" && window.renderDonePage) window.renderDonePage(); if (PANE === "work" && window.renderWorkPage) window.renderWorkPage(); }
  await toggleDone(itemId, done);
}
/* "no date" on a thing that has landed on a Tuesday four weeks running is
   true and useless. This says what the pattern is WITHOUT claiming a
   deadline: the word "usually", and no due_date is ever written — see
   repeats.predict, which says why arithmetic about other assignments is not
   a date anybody set. */
function undatedWord(item) {
  const r = item.repeat;
  if (r && r.expected) {
    const day = new Date(r.expected + "T12:00:00");
    if (!Number.isNaN(day)) return "usually " + DAY_SHORT[day.getDay()];
  }
  return "no date";
}
const DAY_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
/* `item`, when given, lets a past quiz or test escape "late": it happened, and
   there is nothing to be late with. (prosecution round 4, 2026-10-07) */
function urgencyWord(due, today, item) {
  if (!due) return "";
  if (item && isPastAssessment(item, today)) return "";
  const away = daysUntil(due, today);
  if (away < 0) return "late";
  if (away === 0) return "today";
  if (away === 1) return "tomorrow";
  return "";
}
function secWorkHtml(tight) {
  const { shown } = boardCourses();
  if (!shown.length) return `<div class="secempty">Nothing to show yet.</div>`;
  const today = todayIso();
  const rows = shown.map((c) => {
    const open = openFor(c.key);
    const soon = open.filter((i) => i.due_date && daysUntil(i.due_date, today) <= 7);
    return { c, open, quiet: open.length > 0 && soon.length === 0 };
  });
  /* A class with NOTHING open does not get a band.

     [MEASURED] 2026-09-18, twelve classes at 995x605: six of them were clear,
     and their six identical "nothing due" rows took 150px of a 478px column
     — a third of the Assignments column spent saying nothing six times, while
     the classes that did have work showed one item each. They are counted and
     named on one line instead, which is the same answer the overflow counter
     gives: say how many, and say where they are. Nothing is hidden silently
     (SPEC §5.5).

     If EVERY class is clear the line is the whole answer, and that is the
     right thing for the column to say. */
  const working = rows.filter((r) => r.open.length);
  const clear = rows.filter((r) => !r.open.length);
  if (!working.length) {
    return `<div class="asallclear">Nothing open in any class. \u2705</div>`;
  }
  /* A class with work but none of it inside a week gives some of its band
     back — still there, still counted, just not taking room from a class with
     a test on Friday. `minmax(0, …)`: a plain `1fr` row grows past its share
     to fit a long list, so nothing would ever overflow and the counter would
     read zero forever.

     "Even" gives every class the SAME share regardless — which is the point of
     it, and why it is a format of its own rather than a synonym. */
  const template = working.map((r) => (!tight && r.quiet) ? "minmax(0,.7fr)" : "minmax(0,1fr)").join(" ");
  const bands = `<div class="asgrid ${tight ? "tight" : ""}" style="grid-template-rows:${template}">${working.map((r) => `
    <div class="asrow ${r.quiet ? "quiet" : ""} ${SELECTED_CLASS === r.c.key ? "on" : ""}" data-band="${esc(r.c.key)}">
      <div class="asmarks">
        ${classControl(r.c.key, `<span class="clstag">${esc(abbrOf(r.c.key, r.c.name))}</span>`,
          "asmark", r.c.name)}
        ${classControl(r.c.key, "", "asmore", r.c.name)}
      </div>
      <div class="asbody">
        <div class="aslist">${r.open.map(workItemHtml).join("")}</div>
      </div></div>`).join("")}</div>`;
  const names = clear.map((r) => esc(abbrOf(r.c.key, r.c.name))).join(" \u00b7 ");
  const full = clear.map((r) => r.c.name).join(", ");
  return bands + (clear.length ? `<div class="asclearline" title="${esc(full)}">
    <b>${clear.length} clear \u2705</b> ${names}</div>` : "");
}

/* ---------------- the middle: the greeting and the priority cards -------- */
/* ---------------- heads-ups -----------------------------------------------
   What changed since the board was last drawn (sillybus/notices.py): a date
   that moved, two rows that look like one assignment, a new thing due in a
   day or two. [ASKED] 2026-09-28: "give you notifications accordingly".

   Dismissed once, gone for good — the ids are stable across refreshes so a
   dismissal sticks. The list is short by construction (the pipeline caps it)
   and every line opens the item it is about, because a heads-up that cannot
   be checked is one that gets ignored. */
const NOTICE_KEY = "sillybus.notices.seen";
function seenNotices() {
  try { return new Set(JSON.parse(localStorage.getItem(NOTICE_KEY)) || []); }
  catch (e) { return new Set(); }
}
function liveNotices() {
  const seen = seenNotices();
  return ((STATE && STATE.notices) || []).filter((n) => n && n.id && !seen.has(n.id));
}
function dismissNotice(id) {
  const seen = seenNotices();
  seen.add(id);
  /* Bounded: a year of dismissals is still a few hundred ids. */
  try { localStorage.setItem(NOTICE_KEY, JSON.stringify([...seen].slice(-400))); }
  catch (e) { /* private mode */ }
  renderStudio();
}
const NOTICE_GLYPH = { moved: "\u21B3", twice: "2\u00D7", new: "\u2605" };
function noticesHtml() {
  const live = liveNotices();
  announceNotices(live);
  if (!live.length) return "";
  return `<div class="headsup" role="status">
    ${live.map((n) => `<div class="hu-row hu-${esc(n.kind)}">
      <i class="hu-glyph" aria-hidden="true">${NOTICE_GLYPH[n.kind] || "\u2022"}</i>
      ${n.item_id ? `<button type="button" class="hu-text" data-open="${esc(n.item_id)}">${esc(n.text)}</button>`
                  : `<span class="hu-text">${esc(n.text)}</span>`}
      <button type="button" class="hu-x" data-dismiss="${esc(n.id)}" title="got it"
        aria-label="dismiss: ${esc(n.text)}">\u00D7</button></div>`).join("")}
  </div>`;
}
/* Beyond the page: a number on the extension's toolbar icon, and — only if
   the student has said yes to Chrome's own prompt — a system notification
   for a heads-up the page has not shown before. Never a prompt on its own;
   the button below asks, once, from a click. */
let ANNOUNCED = null;
function announceNotices(live) {
  if (window.sdChrome && window.sdChrome.badge) window.sdChrome.badge(live.length);
  if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
  if (ANNOUNCED === null) {
    try { ANNOUNCED = new Set(JSON.parse(sessionStorage.getItem("sillybus.notices.told")) || []); }
    catch (e) { ANNOUNCED = new Set(); }
  }
  const fresh = live.filter((n) => !ANNOUNCED.has(n.id));
  if (!fresh.length) return;
  for (const n of fresh) ANNOUNCED.add(n.id);
  try { sessionStorage.setItem("sillybus.notices.told", JSON.stringify([...ANNOUNCED])); } catch (e) { /* fine */ }
  try {
    const body = fresh.length === 1 ? fresh[0].text
      : `${fresh.length} heads-ups: ${fresh.map((n) => n.text.split(" \u2014 ")[0]).join(" \u00B7 ").slice(0, 180)}`;
    new Notification("SillyBus AI", { body, tag: "sillybus-headsup", silent: true });
  } catch (e) { /* a page that cannot notify still shows the strip */ }
}
async function askForAlerts(button) {
  if (typeof Notification === "undefined") return;
  button.disabled = true;
  try { await Notification.requestPermission(); } catch (e) { /* refused */ }
  renderStudio();
}
function alertsOfferHtml() {
  if (typeof Notification === "undefined" || Notification.permission !== "default") return "";
  if (!liveNotices().length) return "";
  return `<button type="button" class="hu-offer" id="hu-alerts">also tell me in Chrome</button>`;
}

function homeHtml() {
  if (simpleLook()) return simpleHomeHtml();
  const open = openItems();
  const today = todayIso();
  const tomorrow = isoPlus(today, 1);
  const soon = open.filter((i) => i.due_date && i.due_date <= tomorrow);
  const minutes = soon.reduce((t, i) => t + (i.est_minutes || 0), 0);
  const overdue = open.filter((i) => i.due_date && i.due_date < today).length;
  const next = ((STATE && STATE.meetings_today) || []).find((m) => !STATE.now || m.start >= STATE.now);
  const bits = [`${open.length} open`];
  if (UI.show_estimates && minutes) bits.push(`${minutesLabel(minutes)} of it before tomorrow ends`);
  else if (soon.length) bits.push(`${soon.length} of it due by tomorrow`);
  const tail = overdue ? ` — ${overdue} already late.`
    : open.some((i) => i.due_date === today) ? " — and one has a clock on it tonight." : ".";
  return `<div class="greet">${noticesHtml()}${alertsOfferHtml()}
    <div class="hello"><h2>${UI.greeting_name ? `Hello ${esc(UI.greeting_name)}` : "Hello"}</h2>
      <p>${esc(bits.join(", "))}${tail}${next
        ? ` Next up: ${esc(nick(next.course_raw || next.course_key))} at ${esc((next.start || "").slice(11, 16))}${
            next.room ? ", " + esc(next.room) : ""}.` : ""}</p></div>
    <div>${formatTabsHtml("priority")}
      <div class="plabel">${esc(priorityLabel())}</div>${sectionHtml("priority")}</div>
  </div>`;
}
/* The label says what is actually below it, so switching format does not
   leave "First four" over a single card. */
function priorityLabel() {
  const id = activeFormat("priority").id;
  return id === "one" ? "Do this next" : id === "timeline" ? "Tonight, laid out"
    : id === "list" ? "Next six" : "First four";
}
function priorityCardsHtml() {
  /* Ranked by the pipeline's own score, which is the same ranking the rest of
     the board uses — never a second opinion computed in the browser. */
  const open = openItems().slice().sort((a, b) => (b.score || 0) - (a.score || 0));
  if (!open.length) return `<div class="secempty" style="text-align:center">All caught up ✅</div>`;
  const today = todayIso();
  return `<div class="pcards">${open.slice(0, 4).map((i) => `
    <button type="button" class="pcard ${kindDot(i)}" data-open="${esc(i.item_id)}">
      <span class="pctop"><i class="kdot"></i><span class="pcclass">${esc(shortName(i.course))}</span>
        <em class="${esc(urgencyWord(i.due_date, today, i))}">${esc(dueLabel(i))}</em></span>
      <b>${esc(i.title)}</b>
      <span class="pcfoot">${UI.show_estimates && i.est_label ? esc(i.est_label) : ""}${
        i.points ? " · " + esc(i.points) + " pts" : ""}
        <u>${esc(KIND_WORD[i.category] || "work")}</u></span></button>`).join("")}</div>`;
}

/* ---------------- painting ---------------------------------------------- */
/* One small button in the Classes header: by period, A–Z, or the order set
   with the arrows on the Classes page (offered only once an order exists,
   because "my order" with no order is the period order wearing a hat).
   [ASKED] 2026-09-18: "a button to order alphabetically or by order". */
const SORT_WORDS = { period: ["1\u20137", "by period"], name: ["A\u2013Z", "A to Z"], custom: ["mine", "my order"] };
function sortChoices() {
  return (UI.order || []).length ? ["period", "name", "custom"] : ["period", "name"];
}
function sortToggleHtml() {
  const now = UI.sort || "period";
  const choices = sortChoices();
  const next = choices[(choices.indexOf(now) + 1) % choices.length];
  return `<button type="button" class="sortbtn" data-sort-cycle aria-label="classes ordered ${esc(SORT_WORDS[now][1])}; click for ${esc(SORT_WORDS[next][1])}"
    title="${esc(SORT_WORDS[now][1])} \u2014 click for ${esc(SORT_WORDS[next][1])}">${esc(SORT_WORDS[now][0])}</button>`;
}
async function setSort(value) {
  UI = { ...UI, sort: value };
  renderStudio(); renderTabStrip();
  if (PANE === "settings") keepScroll(renderClassesPage);
  await saveUiPrefs({ sort: value });
}
document.addEventListener("click", (event) => {
  const b = event.target.closest("button[data-sort-cycle]");
  if (b) {
    const choices = sortChoices();
    setSort(choices[(choices.indexOf(UI.sort || "period") + 1) % choices.length]);
    return;
  }
  const pick = event.target.closest("button[data-sort]");
  if (pick) setSort(pick.dataset.sort);
});

function renderStudio() {
  if (!STATE) return;
  const { shown, hiddenCount } = boardCourses();
  const put = (id, html) => { const el = $(id); if (el) el.innerHTML = html; };
  const note = (id, text) => { const el = $(id); if (el) el.textContent = text; };
  /* The header of each section carries its note and, when two or more formats
     are ticked on, its tabs. One writer for both, so a section can never end
     up with tabs that do not match what it is showing. */
  const head = (key, text, extra) => {
    const host = $(`#head-${key}`);
    if (host) host.innerHTML = `<span class="note">${esc(text)}</span>` + (extra || "") + formatTabsHtml(key);
  };

  put("#sec-calendar", sectionHtml("calendar"));
  head("calendar", niceDate(todayIso()));
  put("#sec-chats", sectionHtml("chats"));
  head("chats", chatsNote());
  put("#sec-life", sectionHtml("life"));
  head("life", `${lifeOpen().length} things`);
  /* The count of switched-off classes is on Settings -> Classes, where the
     switching happens, and in this section's note — not as a line on the
     board. [ASKED] 2026-09-18: "it just wastes space for something I know
     about." Still said, once, where he can see it if he looks. */
  put("#sec-classes", sectionHtml("classes"));
  head("classes", shown.length + (hiddenCount ? ` of ${shown.length + hiddenCount}` : "") + " showing", sortToggleHtml());
  put("#sec-work", sectionHtml("work"));
  head("work", openItems().length + " open");
  put("#home-body", homeHtml());
  renderQuickLinks();
  fitBands();
  fitTabs();
}
window.renderStudio = renderStudio;

/* What does not fit is COUNTED, not dropped. Measured after paint with
   getBoundingClientRect, never a guessed cap: the band a class gets depends
   on how many classes there are, how many of them are clear this week, the
   text size and the window — none of which a constant can know. */
function fitBands() {
  for (const list of document.querySelectorAll(".asrow .aslist")) {
    /* The counter sits in the class-tag column, not under the list. Under the
       list it cost a whole item's row in every band that had one — [MEASURED]
       2026-09-18 at twelve classes that was five of twenty-six open items
       pushed off the board by the thing announcing that items were off it. */
    const more = list.closest(".asrow").querySelector(".asmore");
    const kids = [...list.querySelectorAll(".asitem")];
    for (const k of kids) k.hidden = false;
    if (!kids.length) { if (more) more.hidden = true; continue; }
    /* measure everything BEFORE hiding anything: hiding one moves the rest,
       so a hide-as-you-go loop counts the wrong number */
    const floor = list.getBoundingClientRect().bottom;
    const over = kids.filter((k) => k.getBoundingClientRect().bottom > floor + 1);
    /* never leave a band with nothing in it — an empty band reads as a class
       with no work, which is the opposite of what an overflow means */
    const hide = over.length === kids.length ? over.slice(1) : over;
    for (const k of hide) k.hidden = true;
    if (!more) continue;
    if (hide.length) {
      more.hidden = false;
      more.textContent = `+${hide.length}`;
      /* "+6" is what fits beside a three-character class code. The sentence
         still has to reach anyone who cannot infer it from two characters, so
         it is the accessible name and the tooltip. */
      const sentence = `${hide.length} more in ${more.dataset.cls || "this class"}`
        + " — open the class to see them";
      more.setAttribute("aria-label", sentence);
      more.title = sentence;
    } else {
      more.hidden = true;
      more.removeAttribute("aria-label");
    }
  }
}
window.fitBands = fitBands;

/* Fonts land after the first paint and change every row's height, and the
   window can be dragged. Both re-measure; neither re-renders. */
if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => fitBands());
window.addEventListener("resize", () => { clearTimeout(window.__fitTimer);
  window.__fitTimer = setTimeout(fitBands, 120); });

/* ---------------- wiring -------------------------------------------------
   Every delegated handler is scoped to a REAL control — `button[data-class]`,
   never a bare `[data-class]`. The runtime stamps data-* attributes on <html>
   itself, so an unscoped closest() matches every click in the document; that
   bug has silently disabled every checkbox on this board once and every tile
   another time. */
document.addEventListener("click", (event) => {
  const tick = event.target.closest("button[data-tick]");
  if (tick) { tickItem(tick.dataset.tick, tick.dataset.undo !== "1"); return; }
  const dismissBtn = event.target.closest("button[data-dismiss]");
  if (dismissBtn) { dismissNotice(dismissBtn.dataset.dismiss); return; }
  if (event.target.closest("#hu-alerts")) { askForAlerts(event.target.closest("#hu-alerts")); return; }
  const openBtn = event.target.closest("button[data-open]");
  if (openBtn) { openDetail(openBtn.dataset.open); return; }
  const classBtn = event.target.closest("button[data-class]");
  if (classBtn && window.openGradePane) { window.openGradePane(classBtn.dataset.class); return; }
});

/* Preferences last, and deliberately not at the boot block above: `UI` is a
   `let` declared in this section, so a call from earlier in the file would
   land in its temporal dead zone. The pre-paint head script has already put
   the localStorage mirror on screen; this is the reconciliation with
   config.json, which is the copy that follows him from the Mac app into the
   Chrome extension. It does not block the state fetch — a board that waits
   for a preference is a board that is blank for a moment. */
loadUiPrefs();

/* The middle opens where he asked it to. Only on "/" — a bookmark or a reload
   on /settings means he asked for that page, and a preference must not argue
   with an address he typed. */
if (!REMOTE && location.pathname === "/") {
  loadUiPrefs().then(() => {
    setTimeout(maybeStartTour, 2500);
    if (simpleLook()) return;            // it opens like a new chat, always
    if (UI.open_with === "chat") { showPane("chat"); return; }
    if (UI.open_with !== "last") return;
    /* "last" is the tab he was on, which may be a class — start_tab is a tab
       name OR a course key, which is why prefs.py cannot validate it against a
       closed list. A class that no longer exists falls back to Home rather
       than lighting a tab that is not there. */
    const want = UI.start_tab || "home";
    if (want && want !== "home") openTab(want);
  });
}

/* ==========================================================================
   0.20 stage 2b — the section registry
   ==========================================================================

   Every section can wear more than one shape. SECTIONS is the single list of
   them: a section's title, and one entry per format with the function that
   draws it. Settings -> Main page ticks them on and off; two or more ticked
   gives that section small tabs, one ticked and the tabs disappear.

   The server knows the same list — `sillybus/prefs.py: SECTION_FORMATS` —
   because a typo in a PUT should be caught by the endpoint rather than by a
   section that silently draws nothing. `tests/test_studio_board.py` asserts
   the two agree exactly, in both directions.

   The per-format helper functions all take no arguments and return HTML; they
   read the same `openItems()` / `boardCourses()` the rest of the board does,
   so two formats of the same section can never disagree about a count. */

/* ---- a category's average, used by the Classes formats that name a weak one.
   Same rule as focusAreas(): at least STRENGTH_MIN_MARKS marks before ranking
   a kind, because one bad mark is not a pattern. ---- */
function categoryMeans(key) {
  const byKind = new Map();
  for (const s of (STATE && STATE.scores) || []) {
    // Same rule as focusAreas(): no percent, not averaged — `|| 0` counted an
    // excused mark as a zero. (prosecution round 4, 2026-10-07)
    if (s.course_key !== key || s.omit || typeof s.percent !== "number") continue;
    const kind = s.category || "other";
    if (!byKind.has(kind)) byKind.set(kind, []);
    byKind.get(kind).push(s);
  }
  const out = [];
  for (const [kind, marks] of byKind) {
    if (marks.length < STRENGTH_MIN_MARKS) continue;
    out.push({ kind, n: marks.length,
               mean: marks.reduce((t, m) => t + m.percent, 0) / marks.length });
  }
  return out.sort((a, b) => a.mean - b.mean);
}
function weakestCategory(key) { return categoryMeans(key)[0] || null; }

/* ---- calendar: five ways to read the same schedule ---- */
function calWeekHtml() {
  const today = todayIso();
  const start = weekStart(today);
  const days = [];
  for (let n = 0; n < 7; n++) days.push(isoPlus(start, n));
  const show = UI.show_weekends ? days : days.filter((d) => {
    const w = new Date(d + "T12:00:00").getDay();
    return w !== 0 && w !== 6;
  });
  const sched = (STATE && STATE.schedule) || {};
  return `<div class="cal-week">${show.map((k) => {
    const per = sched[k] || [];
    const due = openItems().filter((i) => i.due_date === k).length;
    return `<button type="button" class="wkrow ${k === today ? "now" : ""}" data-day="${esc(k)}">
      <span class="d">${esc(dayName(k))}<b>${new Date(k + "T12:00:00").getDate()}</b></span>
      <span class="bars">${per.map((p) =>
        `<i style="--hue:${esc(classColor(p.course_key))}" title="${esc(nick(p.course_raw || p.course_key))}"></i>`).join("")}</span>
      <span class="n">${due || "—"}</span></button>`;
  }).join("")}</div>`;
}
function calMonthHtml() {
  const today = todayIso();
  const first = new Date(today.slice(0, 8) + "01T12:00:00");
  const start = new Date(first);
  /* Monday-first unless he says otherwise: the school week is Mon–Fri and a
     Sunday column on the left puts the weekend either side of it. */
  const lead = UI.week_starts === "sunday" ? first.getDay() : (first.getDay() + 6) % 7;
  start.setDate(1 - lead);
  const heads = UI.week_starts === "sunday"
    ? ["S", "M", "T", "W", "T", "F", "S"] : ["M", "T", "W", "T", "F", "S", "S"];
  let cells = heads.map((d) => `<i class="hd">${d}</i>`).join("");
  /* Up to six weeks, not five. A month that starts late in the week spills
     into a sixth row — November 2026, Monday-first, ends on Monday the 30th —
     and a fixed 35 cells simply left the 30th (and anything due on it) off
     the calendar. A row is drawn only if it starts inside the month, so no
     row is ever a whole week of next month. (prosecution round 4, 2026-10-07) */
  for (let n = 0; n < 42; n++) {
    const cell = new Date(start);
    cell.setDate(start.getDate() + n);
    const off = cell.getMonth() !== first.getMonth();
    if (n >= 28 && n % 7 === 0 && off) break;
    const k = cell.toISOString().slice(0, 10);
    const due = openItems().filter((i) => i.due_date === k).length;
    cells += `<button type="button" class="${off ? "off" : ""} ${k === today ? "now" : ""}"
      data-day="${esc(k)}" title="${esc(niceDate(k))}${due ? ` — ${due} due` : ""}">${cell.getDate()}${
        due ? "<u></u>" : ""}</button>`;
  }
  return `<div class="cal-month">${cells}</div>`;
}
function calThreeHtml() {
  const today = todayIso();
  return `<div class="cal-three">${[0, 1, 2].map((n) => {
    const k = isoPlus(today, n);
    const due = openItems().filter((i) => i.due_date === k).length;
    const meets = ((STATE && STATE.schedule) || {})[k] || [];
    return `<button type="button" data-day="${esc(k)}"><b>${esc(dayName(k))}</b>
      <em>${new Date(k + "T12:00:00").getDate()}</em>
      <span>${due} due${meets.length ? ` · ${meets.length}p` : ""}</span></button>`;
  }).join("")}</div>`;
}
function calAgendaHtml() {
  const open = openItems().filter((i) => i.due_date);
  if (!open.length) return `<div class="secempty">Nothing dated is open. ✅</div>`;
  const today = todayIso();
  return `<div class="cal-agenda">${open.slice(0, 8).map((i) =>
    `<button type="button" class="agrow" data-open="${esc(i.item_id)}">
      <span class="w ${esc(urgencyWord(i.due_date, today, i))}">${esc(relDays(i.due_date, today))}</span>
      <span class="grow trunc">${esc(i.title)}</span>
      <i class="kdot ${kindDot(i)}"></i></button>`).join("")}</div>`;
}
function weekStart(iso) {
  const d = new Date(iso + "T12:00:00");
  const back = UI.week_starts === "sunday" ? d.getDay() : (d.getDay() + 6) % 7;
  return isoPlus(iso, -back);
}
function dayName(iso) {
  return new Date(iso + "T12:00:00").toLocaleDateString(undefined, { weekday: "short" });
}

/* ---- recent chats: three ways in ---- */
const ASK_SUGGESTIONS = ["what should I do first tonight?", "what's due tomorrow?",
                         "any tests coming up?", "which class should I put the most time into?"];
function chatsAnswerHtml() {
  /* A guide's headline is its answer, the same way a reply is a question's,
     so this format shows both with the line underneath. */
  const rows = CHAT_PAIRS.slice(0, 3).map((t) => ({
    kind: "chat", at: "", text: t.q,
    sub: (t.a || "").slice(0, 88) + (t.a && t.a.length > 88 ? "…" : "") }));
  for (const g of ACCEL_RECENT.slice(0, 3)) {
    if (ACCEL_LIVE && ACCEL_LIVE.itemId === g.item_id) continue;
    rows.push({ kind: "accel", at: g.created || "", itemId: g.item_id,
                text: g.title || "study guide", sub: g.headline || "" });
  }
  if (!rows.length && !ACCEL_LIVE) return secChatsEmpty();
  return `${accelLiveHtml()}<div class="threads">${rows.slice(0, 4).map((r) =>
    `<button type="button" class="thread${r.kind === "accel" ? " guide" : ""}"
      ${r.kind === "accel" ? `data-open-accel="${esc(r.itemId)}"` : `data-view="chat"`}>
      <b>${r.kind === "accel" ? `<span class="bolt">⚡</span>` : ""}${esc(r.text)}</b>
      ${r.sub ? `<u>${esc(r.sub)}</u>` : ""}</button>`).join("")}</div>`;
}
function chatsAskHtml() {
  const rows = recentFeed(2);
  return `${accelLiveHtml()}<div class="newask">${ASK_SUGGESTIONS.slice(0, 3).map((s) =>
    `<button type="button" data-fill-send="${esc(s)}">${esc(s)}</button>`).join("")}
    ${rows.length ? `<div class="threads" style="margin-top:4px">${rows.map((r) =>
      feedRowHtml(r, false)).join("")}</div>` : ""}</div>`;
}
function secChatsEmpty() {
  return `<div class="secempty">Nothing asked yet — the box below is the way in.</div>`;
}

/* ---- life stuff: three ways ---- */
function lifeListHtml() {
  const mine = lifeOpen().slice().sort((a, b) => (a.due_date || "9999") < (b.due_date || "9999") ? -1 : 1);
  if (!mine.length) return `<div class="secempty">Nothing of your own open. ✅</div>`;
  const today = todayIso();
  return `<div class="lifelist">${mine.map((i) => `<div class="liferow">
    <input type="checkbox" class="tick bx" aria-label="Mark ${esc(i.title)} done" data-id="${esc(i.item_id)}">
    <button type="button" class="grow" data-open="${esc(i.item_id)}">
      <span class="t">${esc(i.title)}</span>
      <span class="m">${esc(lifeKindOf(i))} · ${esc(i.due_date ? relDays(i.due_date, today) : "someday")}</span>
    </button></div>`).join("")}
    <button type="button" class="lchip" data-add="goals" style="margin-top:5px">＋ add something</button></div>`;
}
function lifeNextHtml() {
  const next = lifeOpen().slice().sort((a, b) => (a.due_date || "9999") < (b.due_date || "9999") ? -1 : 1)[0];
  if (!next) return `<div class="secempty">All of your own things are done. ✅</div>`;
  const rest = lifeOpen().length - 1;
  return `<div class="lifebig"><b>${esc(next.title)}</b>
    <span>${esc(lifeKindOf(next))} · ${esc(next.due_date ? relDays(next.due_date, todayIso()) : "someday")}</span>
    ${rest > 0 ? `<button type="button" class="lchip" style="margin-top:8px"
      data-fmt-go="life:kinds">and ${rest} more ›</button>` : ""}</div>`;
}
function lifeKindOf(item) {
  for (const [key] of LIFE_KINDS) if ((item.flags || []).includes("section:" + key)) return key;
  return "yours";
}

/* ---- classes: five ways to read the same grades ---- */
const bandOfPercent = (p) => p >= 90 ? "green" : p >= 83 ? "yellow" : p >= 80 ? "orange" : "red";
/* Graded AND carrying a number. A letter-only class ("P") is graded with
   percent null, and `c.graded ? c.percent.toFixed(1)` threw on it and blanked
   the Classes section. (prosecution round 4, 2026-10-07) */
function hasPercent(c) { return !!c.graded && typeof c.percent === "number"; }
function gradedCourses() {
  return boardCourses().shown.filter((c) => c.graded && typeof c.percent === "number");
}
function clsBarsHtml() {
  const { shown } = boardCourses();
  return `<div class="clsbars">${shown.map((c) => classControl(c.key,
    `<span class="top"><b class="trunc">${esc(c.nick)}</b>
      <em>${hasPercent(c) ? c.percent.toFixed(1) + "%" : c.graded && c.letter ? esc(c.letter) : "—"}</em></span>
     <span class="tr"><i style="width:${hasPercent(c) ? Math.max(0, Math.min(100, c.percent)) : 0}%"></i></span>`,
    `clsbar band-${hasPercent(c) ? bandOfPercent(c.percent) : "green"}`, c.name)).join("")}</div>`;
}
function clsRowsHtml() {
  const { shown } = boardCourses();
  return `<div class="clsrows">${shown.map((c) => {
    const u = urgencyOf(c.key);
    return classControl(c.key,
      `<span class="pip"></span><span class="g">${c.graded ? esc(c.letter || "?") : "–"}</span>
       <span class="grow clsname">${esc(c.nick)}</span>
       <span class="clsmeta">${hasPercent(c) ? c.percent.toFixed(1) + "%" : "—"}</span>
       <span class="em">${statusEmoji(c.key)}</span>`,
      `clsrowline band-${u.band}`, `${c.name} — ${u.words}`);
  }).join("")}</div>`;
}
function clsTableHtml() {
  const { shown } = boardCourses();
  return `<div class="clstable">${shown.map((c) => {
    const weak = weakestCategory(c.key);
    return classControl(c.key,
      `<span class="nm trunc">${esc(c.nick)}</span>
       <span class="lt band-${hasPercent(c) ? bandOfPercent(c.percent) : "green"}">${c.graded ? esc(c.letter || "?") : "–"}</span>
       <span class="pc">${hasPercent(c) ? c.percent.toFixed(1) + "%" : "—"}</span>
       <span class="wk trunc">${weak ? esc(kindName(weak.kind)) + " " + Math.round(weak.mean) + "%" : "no marks"}</span>
       <span class="op">${openFor(c.key).length} open</span>`,
      "clstrow", c.name);
  }).join("")}</div>`;
}
function clsAverageHtml() {
  const g = gradedCourses().slice().sort((a, b) => a.percent - b.percent);
  if (!g.length) return `<div class="secempty">No graded classes showing.</div>`;
  const avg = g.reduce((t, c) => t + c.percent, 0) / g.length;
  return `<div class="clsavg"><div class="big">${avg.toFixed(1)}%</div>
    <div class="side"><span>average of ${g.length} classes — a plain average of the
      percentages, <b>not a GPA</b></span>
    ${classControl(g[0].key, `lowest · ${esc(g[0].nick)} ${g[0].percent.toFixed(1)}%`, "ln", g[0].name)}
    ${classControl(g[g.length - 1].key,
      `highest · ${esc(g[g.length - 1].nick)} ${g[g.length - 1].percent.toFixed(1)}%`,
      "ln", g[g.length - 1].name)}
    </div></div>`;
}

/* ---- the work: four ways ---- */
function wkByDayHtml() {
  const open = openItems().filter((i) => i.due_date);
  const days = [...new Set(open.map((i) => i.due_date))].sort().slice(0, 6);
  if (!days.length) return `<div class="secempty">Nothing dated is open. ✅</div>`;
  const today = todayIso();
  return `<div class="asdays">${days.map((k) => {
    const list = open.filter((i) => i.due_date === k);
    return `<div class="asday">
      <div class="asdayhead">${esc(relDays(k, today))}<em>${list.length}</em></div>
      ${list.map((i) => `<button type="button" class="asitem" data-open="${esc(i.item_id)}">
        <i class="kdot ${kindDot(i)}"></i><span class="ttl">${esc(i.title)}</span>${dateNoteHtml(i)}
        <em>${esc(abbrOf(i.course_key, i.course))}</em></button>`).join("")}</div>`;
  }).join("")}</div>`;
}
function wkFlatHtml() {
  const open = openItems();
  if (!open.length) return `<div class="secempty">Nothing open in any class. ✅</div>`;
  return `<div class="asflat">${open.map(workItemHtml).join("")}</div>`;
}

/* ---- priority: four ways ---- */
function byScore() {
  return openItems().slice().sort((a, b) => (b.score || 0) - (a.score || 0));
}
function priListHtml() {
  const open = byScore().slice(0, 6);
  if (!open.length) return `<div class="secempty" style="text-align:center">All caught up ✅</div>`;
  const today = todayIso();
  return `<div class="plist">${open.map((i) => `<div class="plrow ${kindDot(i)}">
    <input type="checkbox" class="tick bx" aria-label="Mark ${esc(i.title)} done" data-id="${esc(i.item_id)}">
    <button type="button" class="grow" data-open="${esc(i.item_id)}">
      <span class="t">${esc(i.title)}</span>
      <span class="m">${esc(shortName(i.course))} · ${esc(dueLabel(i))}${
        UI.show_estimates && i.est_label ? " · " + esc(i.est_label) : ""}</span></button>
    <span class="m">${esc(KIND_WORD[i.category] || "work")}</span></div>`).join("")}</div>`;
}
function priOneHtml() {
  const i = byScore()[0];
  if (!i) return `<div class="pone"><h3>Nothing left. ✅</h3></div>`;
  return `<div class="pone">
    <div class="k">do this next · ${esc(shortName(i.course))}</div>
    <h3>${esc(i.title)}</h3>
    <div class="m"><span>${esc(dueLabel(i))}</span>${
      UI.show_estimates && i.est_label ? `<span>${esc(i.est_label)}</span>` : ""}${
      i.points ? `<span>${esc(i.points)} pts</span>` : ""}</div>
    ${i.date_note ? `<div class="ponote">${esc(i.date_note)}</div>` : ""}
    <div class="acts" style="justify-content:center">
      <button type="button" class="primary" data-open="${esc(i.item_id)}">Open it</button>
      <button type="button" class="ghost tickbtn" data-tick="${esc(i.item_id)}">Mark done</button></div>
    <div class="rest">then ${esc(byScore().slice(1, 4).map((x) => shortName(x.course)).join(" · ")) || "nothing"}</div></div>`;
}
function priTimelineHtml() {
  const today = todayIso();
  const list = openItems().filter((i) => i.due_date && daysUntil(i.due_date, today) <= 1).slice(0, 5);
  if (!list.length) {
    return `<div class="secempty" style="text-align:center">Nothing due tonight or tomorrow. ✅</div>`;
  }
  const total = list.reduce((t, i) => t + (i.est_minutes || 20), 0);
  return `<div><div class="plabel">tonight · ${esc(minutesLabel(total))}</div>
    <div class="ptl">${list.map((i) => `<button type="button" class="seg ${kindDot(i)}"
      style="--w:${i.est_minutes || 20}" data-open="${esc(i.item_id)}"
      title="${esc(i.title)}"><b>${esc(shortName(i.course))}</b>
      <i>${esc(minutesLabel(i.est_minutes || 20))}</i></button>`).join("")}</div></div>`;
}

/* ---- the registry itself ---- */
const SECTIONS = {
  calendar: { title: "Calendar", formats: [
    { id: "day", name: "Day", hint: "today's periods", render: secCalendarHtml },
    { id: "week", name: "Week", hint: "the week at a glance", render: calWeekHtml },
    { id: "month", name: "Month", hint: "dots on the days with work", render: calMonthHtml },
    { id: "three", name: "3-day", hint: "today and the next two", render: calThreeHtml },
    { id: "agenda", name: "Agenda", hint: "next eight things, in order", render: calAgendaHtml }] },
  chats: { title: "Recent chats", formats: [
    { id: "list", name: "List", hint: "recent questions", render: secChatsHtml },
    { id: "answer", name: "With answer", hint: "with the last answer", render: chatsAnswerHtml },
    { id: "ask", name: "Ask", hint: "suggestions first", render: chatsAskHtml }] },
  life: { title: "Life stuff", formats: [
    { id: "kinds", name: "By kind", hint: "goals, practice, clubs, makeup", render: secLifeHtml },
    { id: "list", name: "List", hint: "one list with tick boxes", render: lifeListHtml },
    { id: "next", name: "Next up", hint: "just the next one", render: lifeNextHtml }] },
  classes: { title: "Classes", formats: [
    { id: "strip", name: "Strip", hint: "circle, name, percent", render: secClassesHtml },
    { id: "bars", name: "Bars", hint: "grades side by side", render: clsBarsHtml },
    { id: "rows", name: "Rows", hint: "one line each, with status", render: clsRowsHtml },
    { id: "table", name: "Table", hint: "letter, percent, weakest kind", render: clsTableHtml },
    { id: "average", name: "Average", hint: "one number", render: clsAverageHtml }] },
  work: { title: "Assignments", formats: [
    { id: "byclass", name: "By class", hint: "an equal band per class", render: secWorkHtml },
    { id: "even", name: "Even", hint: "every class the same share", render: () => secWorkHtml(true) },
    { id: "byday", name: "By day", hint: "grouped by the day it is due", render: wkByDayHtml },
    { id: "flat", name: "Flat", hint: "one list, soonest first", render: wkFlatHtml }] },
  priority: { title: "Priority", formats: [
    { id: "cards", name: "Cards", hint: "four cards", render: priorityCardsHtml },
    { id: "list", name: "List", hint: "six lines with tick boxes", render: priListHtml },
    { id: "one", name: "One thing", hint: "just the next thing", render: priOneHtml },
    { id: "timeline", name: "Tonight", hint: "tonight, by how long each takes", render: priTimelineHtml }] },
  links: { title: "Quick links", formats: [
    { id: "full", name: "Full", hint: "mark, name, status", render: () => linksRowHtml("") },
    { id: "labels", name: "Labels", hint: "mark and name", render: () => linksRowHtml("labels") },
    { id: "icons", name: "Icons", hint: "marks only", render: () => linksRowHtml("icons") }] },
};

/* Which format a section is wearing. `active` can name one that has since been
   ticked off, so the first one that IS ticked wins rather than an empty box. */
function activeFormat(key) {
  const on = (UI.formats || {})[key] || [];
  const want = (UI.active || {})[key];
  const id = on.includes(want) ? want : on[0];
  const sec = SECTIONS[key];
  return sec.formats.find((f) => f.id === id) || sec.formats[0];
}
function sectionHtml(key) {
  try {
    return activeFormat(key).render();
  } catch (err) {
    /* one section, not the page — the same rule render() follows */
    console.error("SillyBus AI: could not draw " + key, err);
    return `<div class="secempty">This section could not be drawn: <code>${
      esc(String((err && err.message) || err).slice(0, 120))}</code></div>`;
  }
}
/* Tabs only when there is something to switch between. */
function formatTabsHtml(key) {
  const on = (UI.formats || {})[key] || [];
  if (on.length < 2) return "";
  const live = SECTIONS[key].formats.filter((f) => on.includes(f.id));
  const now = activeFormat(key).id;
  return `<div class="fmt" role="group" aria-label="${esc(SECTIONS[key].title)} format">${live.map((f) =>
    `<button type="button" class="${f.id === now ? "on" : ""}" data-fmt-go="${esc(key)}:${esc(f.id)}"
      aria-pressed="${f.id === now}">${esc(f.name)}</button>`).join("")}</div>`;
}

/* ---------------- the format tabs, and the mockup bug they had -----------
   [MEASURED] in the mockup at 995x605 with several formats ticked on, SIX of
   the twenty-seven tabs were physically unclickable: the tab row overflowed
   its section header and the next section's heading painted on top of it.
   `document.elementFromPoint` at each tab's centre returned the heading, not
   the tab — calendar:three, calendar:agenda, life:next, work:even, work:byday
   and work:flat.

   The header wraps now (`flex-wrap: wrap` on `.sechead`, and the tab strip is
   allowed to take a line of its own), which fixes it structurally. This checks
   the result rather than trusting it: after paint, any tab whose own centre
   belongs to something else gets the section's tabs put on their own row. */
function fitTabs() {
  for (const strip of document.querySelectorAll(".sec .fmt")) {
    strip.classList.remove("stacked");
    const covered = [...strip.querySelectorAll("button")].some((b) => {
      const r = b.getBoundingClientRect();
      if (!r.width || !r.height) return true;
      const hit = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
      return !hit || !strip.contains(hit);
    });
    if (covered) strip.classList.add("stacked");
  }
}
window.fitTabs = fitTabs;

/* ---------------- Settings -> Main page ----------------
   The multi-select. Ticking is immediate and saved through /api/prefs — there
   is no Save button, because a preference that needs confirming is one more
   thing to get wrong, and the board shows the answer as you tick it. */
function renderMainPage() {
  const host = $("#main-page-host");
  if (!host) return;
  const sections = Object.keys(SECTIONS);
  host.innerHTML = `<div class="setcard"><h4>Show me around</h4>
      <p class="fieldnote">A short walkthrough of the pages and buttons you see. You can leave at any time with Esc or Skip.</p>
      <div class="acts"><button type="button" class="ghost" data-start-tour>Take the tour again</button></div></div>
    <p class="muted">Every section can show more than one format.
    Tick as many as you want and that section grows small tabs, so you can flip
    between them without coming back here. Tick one and the tabs disappear.</p>
    ${sections.map((key) => {
      const sec = SECTIONS[key];
      const on = (UI.formats || {})[key] || [];
      return `<div class="fmtsec"><h4>${esc(sec.title)}
        <span class="fmtcount">${on.length} of ${sec.formats.length} on</span></h4>
        <div class="fmtgrid">${sec.formats.map((f) => `
          <label class="fmtpick ${on.includes(f.id) ? "on" : ""}">
            <input type="checkbox" data-fmt="${esc(key)}:${esc(f.id)}" ${on.includes(f.id) ? "checked" : ""}>
            <span class="grow">${esc(f.name)}<i>${esc(f.hint)}</i></span></label>`).join("")}</div></div>`;
    }).join("")}
    <p class="muted" id="main-page-note"></p>`;
}
window.renderMainPage = renderMainPage;

async function toggleFormat(key, id, wanted) {
  const on = [...(((UI.formats || {})[key]) || [])];
  /* The message is written AFTER the re-render, not before it: renderMainPage()
     rebuilds this card's innerHTML — the note element included — so a message
     set first is erased by the redraw that was meant to show it. [MEASURED]
     2026-09-18: the "keep at least one" guard fired correctly and said nothing
     at all, which reads as a tick that simply refused to move. */
  const done = (text, bad) => {
    renderMainPage();
    const note = $("#main-page-note");
    if (!note) return;
    note.textContent = text || "";
    note.classList.toggle("bad", !!bad);
  };
  let next;
  if (wanted) {
    next = on.includes(id) ? on : on.concat([id]);
  } else {
    /* A section with nothing ticked would be a blank box with no way back to
       itself from the board — the tabs it would need are the thing that just
       disappeared. The server refuses this too; this is the readable half. */
    if (on.length <= 1) {
      done("Keep at least one format \u2014 a section with none has no way back to itself.", true);
      return;
    }
    next = on.filter((f) => f !== id);
  }
  const patch = { formats: { ...(UI.formats || {}), [key]: next } };
  /* if what was showing has just been ticked off, show something that is on */
  if (!next.includes((UI.active || {})[key])) {
    patch.active = { ...(UI.active || {}), [key]: next[0] };
  }
  const problem = await saveUiPrefs(patch);
  done(problem, !!problem);
  renderStudio();
}

/* ---------------- the board's own handlers ----------------
   Scoped to real controls, every one of them. */
document.addEventListener("click", (event) => {
  const tab = event.target.closest("button[data-fmt-go]");
  if (tab) {
    const [key, id] = tab.dataset.fmtGo.split(":");
    saveUiPrefs({ active: { ...(UI.active || {}), [key]: id } });
    renderStudio();
    return;
  }
  const day = event.target.closest("button[data-day]");
  if (day) {
    /* a day in the week or month grid opens the calendar ON that day, which
       means the Day format and the offset that lands on it */
    const target = day.dataset.day;
    SCHED_OFFSET = daysUntil(target, todayIso()) || 0;
    saveUiPrefs({ active: { ...(UI.active || {}), calendar: "day" } });
    renderStudio();
    return;
  }
  const tick = event.target.closest("button[data-tick]");
  if (tick) { toggleDone(tick.dataset.tick, true); return; }
  const send = event.target.closest("button[data-fill-send]");
  if (send) {
    const box = $("#chat-input");
    if (box) { box.value = send.dataset.fillSend; box.focus(); }
    return;
  }
  const add = event.target.closest("button[data-add]");
  if (add && window.openAdd) { window.openAdd(add.dataset.add); return; }
});

document.addEventListener("change", (event) => {
  const pick = event.target.closest("input[data-fmt]");
  if (pick) {
    const [key, id] = pick.dataset.fmt.split(":");
    toggleFormat(key, id, pick.checked);
  }
});

/* ==========================================================================
   0.20 stage 3 — the tab strip
   ==========================================================================

   The student's change to the mockup, which opens a class by clicking its
   chip:
   *"studio replaces it but it has tabs for each class, life, calendar,
   settings, etc."*

   Home · one tab per visible class · Life · Calendar · Settings.

   The class tabs are SHORT CODES, and that was measured rather than chosen.
   [MEASURED] 2026-09-18 at his 995x605 window, 963px of usable width:

       twelve full class names + the four fixed tabs   2296px
       the same, names trimmed to 12 characters        1579px
       short codes                                      846px
       short codes, tighter                             717px

   He picked the codes over scrolling the strip (full names, ~5 classes
   visible, the rest behind a scroll — on a board whose point is that
   everything is visible at once) and over an overflow menu (~4 real names and
   eight in a dropdown whose contents shift as names change).

   What makes a three-letter code workable rather than a puzzle: the full name
   is on hover AND on keyboard focus, the tab you are ON shows its full name
   inline, and the codes are `ui.abbr` — editable in Settings -> Classes, so
   HIM and CP2 become whatever he actually calls them. */

const FIXED_TABS = [
  { key: "home", label: "Home", view: "home" },
  { key: "work", label: "Assignments", view: "work" },
  { key: "life", label: "Life", view: "life" },
  { key: "calendar", label: "Calendar", view: "calendar" },
  { key: "done", label: "Done", view: "done" },
  { key: "settings", label: "Settings", view: "settings" },
  // The simple look's own pages. Not on the board's strip, which has a tab
  // per class and the class ring for grades.
  { key: "grades", label: "Grades", view: "grades", simpleOnly: true },
  { key: "classlist", label: "Classes", view: "classlist", simpleOnly: true },
];
/* Home and Settings always; the rest unless `tabs_off` names them. A tab
   switched off the strip is still a page — a link or a key still opens it. */
function fixedTabsShown() {
  const off = new Set(UI.tabs_off || []);
  return FIXED_TABS.filter((t) => !t.simpleOnly
    && (t.key === "home" || t.key === "settings" || !off.has(t.key)));
}
/* Every tab in strip order, for the arrow keys and the sideways scroll. */
function tabOrder() {
  if (simpleLook()) return [...SIMPLE_STRIP.map((t) => t.key), "settings"];
  const { shown } = boardCourses();
  return ["home", ...shown.map((c) => c.key), ...fixedTabsShown().slice(1).map((t) => t.key)];
}
function stepTab(delta) {
  const order = tabOrder();
  const at = Math.max(0, order.indexOf(OPEN_TAB));
  const key = order[(at + delta + order.length) % order.length];
  openTab(key);
  const button = Array.from(document.querySelectorAll("#tab-bar button[data-tab]"))
    .find((b) => b.dataset.tab === key);
  if (button) { button.focus({ preventScroll: true }); button.scrollIntoView({ block: "nearest", inline: "nearest" }); }
}

/* Which tab is lit. A class pane lights that class's tab; every other pane
   belongs to whichever fixed tab opened it, and a detail pane (an assignment,
   the study guide, the add form) leaves the strip showing where it came from
   rather than nothing. */
let OPEN_TAB = "home";
function tabForView(name) {
  if (name === "grade" && SELECTED_CLASS) return SELECTED_CLASS;
  if (FIXED_TABS.some((t) => t.view === name)) return name;
  return null;               // a detail pane: keep whatever was lit
}

/* "auto" measures: the strip's width against what the names would need, at
   this window, with these classes. [MEASURED] 2026-09-18: names need ~2.4x the
   width at twelve classes and fit at five, so a constant would be wrong on one
   of his two screens. */
function tabLabelsAreNames(shown) {
  const mode = UI.tab_labels || "codes";
  if (mode === "names") return true;
  if (mode === "codes") return false;
  const bar = $("#tab-bar");
  if (!bar) return false;
  const probe = document.createElement("div");
  probe.style.cssText = "position:fixed;left:-9999px;top:0;display:flex;gap:3px;white-space:nowrap;";
  probe.innerHTML = ["Home", "Life", "Calendar", "Settings"].concat(shown.map((c) => c.nick))
    .map((l) => `<span class="tb">${esc(l)}</span>`).join("");
  document.body.appendChild(probe);
  const need = probe.getBoundingClientRect().width + 40;
  probe.remove();
  return need <= bar.clientWidth;
}

function renderTabStrip() {
  const bar = $("#tab-bar");
  if (!bar) return;
  if (REMOTE) { bar.hidden = true; return; }
  if (simpleLook()) { renderSimpleStrip(bar); return; }
  const { shown } = boardCourses();
  const parts = [];
  const tab = (key, label, full, on, cls) =>
    `<button type="button" class="tb ${cls || ""} ${on ? "on" : ""}" data-tab="${esc(key)}"
      title="${esc(full || label)}" aria-current="${on ? "page" : "false"}"
      ><span class="tb-l">${esc(label)}</span>${
        on && full && full !== label ? `<span class="tb-full">${esc(full)}</span>` : ""}</button>`;
  parts.push(tab("home", "Home", "Home", OPEN_TAB === "home"));
  parts.push(`<span class="tb-sep" aria-hidden="true"></span>`);
  const names = tabLabelsAreNames(shown);
  for (const c of shown) {
    parts.push(tab(c.key, names ? c.nick : abbrOf(c.key, c.name), c.name, OPEN_TAB === c.key, "tb-class"));
  }
  /* The fixed pages sit against the right edge, the classes against the left:
     two groups, read as two groups. [ASKED] 2026-09-20. */
  parts.push(`<span class="tb-sep tb-push" aria-hidden="true"></span>`);
  for (const t of fixedTabsShown().slice(1)) {
    parts.push(tab(t.key, t.label, t.label, OPEN_TAB === t.key));
  }
  bar.innerHTML = parts.join("");
  bar.hidden = false;
}
window.renderTabStrip = renderTabStrip;

/* The simple look's strip: New chat, then the four pages, then Settings as a
   word on the right. [ASKED] 2026-10-07: "across the top have assignments
   grades ext" and "add the word settings up top". The count on Assignments
   is the open work, the same openItems() the page lists. */
const SIMPLE_STRIP = [
  { key: "home", label: "New chat", icon: "\u270E" },
  { key: "work", label: "Assignments" },
  { key: "grades", label: "Grades" },
  { key: "calendar", label: "Calendar" },
  { key: "classlist", label: "Classes" },
];
function renderSimpleStrip(bar) {
  /* Pages reached FROM New chat (the conversation, its history, Personal,
     Completed) keep New chat lit; a class page lights Grades. Five tabs and
     none lit is the state that makes a tabbed app feel broken. */
  const lit = ["chat", "chat-history", "life", "done"].includes(PANE) ? "home"
    : PANE === "grade" ? "grades" : OPEN_TAB;
  const btn = (t, cls) => {
    const n = t.key === "work" && STATE ? openItems().length : 0;
    return `<button type="button" class="tb ${cls || ""} ${lit === t.key ? "on" : ""}" data-tab="${esc(t.key)}"
      aria-current="${lit === t.key ? "page" : "false"}">${t.icon ? `<span class="tb-i" aria-hidden="true">${t.icon}</span>` : ""}<span class="tb-l">${esc(t.label)}</span>${
        n ? `<span class="tb-n">${n}</span>` : ""}</button>`;
  };
  // Settings sits right after Classes. [ASKED] 2026-10-07 "add the word
  // setting next to classes up top".
  bar.innerHTML = SIMPLE_STRIP.map((t) => btn(t)).join("")
    + btn({ key: "settings", label: "Settings", icon: "\u2699" }, "tb-settings");
  bar.hidden = false;
}

/* "Good morning, Sam" — morning until noon, afternoon until five, night
   after. [ASKED] 2026-10-07: "make it say good morning/afternoon/night" and
   "and the persons name". On the birthday he gave when he made his account
   it says so instead. */
function greetingWords() {
  const now = new Date();
  const h = now.getHours();
  const name = UI.greeting_name || STUDENT_NAME || "";
  const md = String(now.getMonth() + 1).padStart(2, "0") + "-" + String(now.getDate()).padStart(2, "0");
  if (UI.birthday && UI.birthday.slice(5) === md) {
    return name ? `Happy birthday, ${name}` : "Happy birthday";
  }
  const part = h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good night";
  return name ? `${part}, ${name}` : part;
}

async function loadPreviousChats() {
  if (REMOTE) return;
  try {
    const res = await fetch("/api/chat/conversations");
    if (!res.ok) throw new Error("Could not load chats");
    CHAT_CONVERSATIONS = (await res.json()).conversations || [];
    renderPreviousChats();
  } catch (err) {
    const host = $("#home-chats");
    if (host) host.innerHTML = '<p class="muted">Could not load previous chats.</p><button type="button" data-chat-retry>Try again</button>';
  }
}

async function openPreviousChat(id) {
  if (CHAT_BUSY) return;
  try {
    const res = await fetch(`/api/chat/conversations/${encodeURIComponent(id)}`);
    if (!res.ok) throw new Error("Could not open this chat");
    const out = await res.json();
    CHAT_CONVERSATION = out.conversation.id;
    CHAT_SESSION = null;
    PENDING_PROPOSAL = null;
    const log = $("#chat-log");
    if (!log) return;
    // Saved answers are replayed as text; their old actions never run again.
    log.innerHTML = (out.messages || []).map(m => m.role === "user"
      ? `<div class="msg user">${esc(m.text)}</div>`
      : `<div class="msg assistant">${chatHtml(m.text)}</div>`).join("");
    showPane("chat");
    renderPreviousChats();
    log.scrollTop = log.scrollHeight;
    $("#chat-input")?.focus();
  } catch (err) {
    const host = $("#home-chats");
    if (host) host.insertAdjacentHTML("beforeend", `<p role="alert">${esc(err.message)}. Try again.</p>`);
  }
}

async function loadChatMemory() {
  if (REMOTE) return;
  try {
    const res = await fetch("/api/chat/memory");
    if (!res.ok) return;
    CHAT_MEMORY = (await res.json()).memories || [];
    renderPreviousChats();
  } catch (err) { /* conversations still work if memory is unavailable */ }
}

function renderPreviousChats() {
  const host = $("#home-chats");
  if (!host) return;
  host.hidden = REMOTE || !simpleLook() || !["home", "chat"].includes(PANE);
  host.innerHTML = `<button type="button" class="nc-new" data-new-conversation ${CHAT_BUSY ? "disabled" : ""}>✎ New chat</button>
    <h2>Previous chats</h2>
    <nav class="nc-chat-list" aria-label="Saved conversations">
      ${CHAT_CONVERSATIONS.length ? CHAT_CONVERSATIONS.map(c => `<button type="button"
        data-conversation="${esc(c.id)}" ${CHAT_BUSY ? "disabled" : ""} class="nc-chat-row ${CHAT_CONVERSATION === c.id && PANE === "chat" ? "on" : ""}"
        ${CHAT_CONVERSATION === c.id && PANE === "chat" ? 'aria-current="true"' : ""}
        title="${esc(c.title || "Conversation")}"><span>${esc(c.title || "Conversation")}</span></button>`).join("")
        : '<p class="muted nc-no-chats">Your conversations will appear here.</p>'}
    </nav>
    <button type="button" class="nc-all" id="nc-all-history">View all history</button>
    <div class="nc-memory"><button type="button" class="nc-memory-toggle" aria-expanded="${CHAT_MEMORY_OPEN}" aria-controls="nc-memory-content">Memory <span>${CHAT_MEMORY.length}</span></button>
      <div id="nc-memory-content" ${CHAT_MEMORY_OPEN ? "" : "hidden"}>
      <p class="muted">Say “remember that…” in chat. Your saved preferences stay on this device.</p>
      ${CHAT_MEMORY.length ? `<ul>${CHAT_MEMORY.map(m => `<li><span>${esc(m.text)}</span><button type="button"
        data-forget-memory="${esc(m.id)}" aria-label="Forget: ${esc(m.text)}">×</button></li>`).join("")}</ul>`
        : '<p class="muted">Nothing saved yet.</p>'}
      </div>
    </div>`;
}

document.addEventListener("click", async event => {
  const memoryToggle = event.target.closest(".nc-memory-toggle");
  if (memoryToggle) {
    event.preventDefault();
    CHAT_MEMORY_OPEN = !CHAT_MEMORY_OPEN;
    renderPreviousChats();
    return;
  }
  const recent = event.target.closest("button[data-conversation]");
  if (recent) { await openPreviousChat(recent.dataset.conversation); return; }
  if (event.target.closest("button[data-chat-retry]")) { await loadPreviousChats(); return; }
  if (event.target.closest("button[data-new-conversation]")) {
    if (CHAT_BUSY) return;
    CHAT_CONVERSATION = null; CHAT_SESSION = null;
    PENDING_PROPOSAL = null;
    showPane("home"); $("#chat-input")?.focus(); return;
  }
  if (event.target.closest("#nc-all-history")) { showPane("chat-history"); renderChatHistory(); return; }
  const forget = event.target.closest("button[data-forget-memory]");
  if (forget) {
    forget.disabled = true;
    try {
      const res = await fetch(`/api/chat/memory/${encodeURIComponent(forget.dataset.forgetMemory)}`, {method: "DELETE"});
      if (!res.ok) throw new Error("Could not forget this memory");
      await loadChatMemory();
    } catch (err) { forget.disabled = false; forget.textContent = "Retry"; }
  }
});

function simpleHomeHtml() {
  renderPreviousChats();
  const open = openItems();
  const today = todayIso();
  const tomorrow = isoPlus(today, 1);
  const actionable = open.filter((i) => !isPastAssessment(i, today));
  const late = actionable.filter((i) => i.due_date && i.due_date < today && !isPastAssessment(i, today)).length;
  const soon = actionable.filter((i) => i.due_date && i.due_date >= today && i.due_date <= tomorrow);
  const tests = soon.filter((i) => ASSESSMENTS.has(i.category)).length;
  const bits = [];
  if (soon.length) bits.push(`${soon.length} due by tomorrow${tests ? `, ${tests} of them ${tests === 1 ? "a test" : "tests"}` : ""}`);
  if (late) bits.push(`${late} late`);
  const undated = actionable.filter((i) => !i.due_date).length;
  if (undated) bits.push(`${undated} without a due date`);
  const unread = !((STATE && STATE.items) || []).length && !((STATE && STATE.grades) || []).length;
  const line = unread ? "No schoolwork loaded yet — connect your school to get started."
    : !actionable.length ? "Nothing open \u2014 you're all caught up."
    : bits.length ? bits.join(" \u00b7 ") : `${actionable.length} open, nothing due today or tomorrow`;
  const next = ((STATE && STATE.meetings_today) || []).find((m) => !STATE.now || m.start >= STATE.now);
  const nextLine = next
    ? `Next up: ${esc(nick(next.course_raw || next.course_key))} at ${esc((next.start || "").slice(11, 16))}${
        next.room ? ", " + esc(next.room) : ""}.` : "";
  const logo = (document.querySelector(".brand-mark") || {}).src || "";
  renderSimpleExtra();
  return `<div class="newchat">
    ${logo ? `<img class="nc-logo" src="${esc(logo)}" alt="">` : ""}
    <h2 class="nc-hello">${esc(greetingWords())}</h2>
    <p class="nc-line">${esc(line)}${open.length
      ? ` \u00b7 <button type="button" class="linkbtn" data-tab="work">see them</button>` : ""}${
      nextLine ? `<br>${nextLine}` : ""}</p>
  </div>`;
}

/* A restrained school snapshot uses the board already loaded: two real
   items, their source date notes, and a route to the complete list. */
function homeSnapshotHtml() {
  if (!STATE) return '<p class="nc-snapshot-note">Loading your schoolwork…</p>';
  const items = (STATE.items || []).filter(i => !i.done && !personalSection(i) && !isPastAssessment(i, todayIso()));
  const sorted = items.slice().sort((a,b) => (b.score || 0) - (a.score || 0));
  const unread = !(STATE.items || []).length && !(STATE.grades || []).length;
  if (unread) return `<section class="nc-snapshot" aria-label="Get started">
    <b>Let's connect your school</b><p>Your assignments and grades will appear after setup and your first refresh.</p>
    <button type="button" class="linkbtn" data-view="setup">Set up my school</button>
    <button type="button" class="linkbtn" data-start-tour>Show me around</button></section>`;
  return `<section class="nc-snapshot" aria-label="School snapshot">
    <div class="nc-snapshot-top"><b>Start here</b><button type="button" class="linkbtn" data-tab="work">All assignments · ${items.length}</button></div>
    ${sorted.slice(0,2).map(i => `<button type="button" class="nc-snapshot-item" data-home-item="${esc(i.item_id)}">
      <span>${esc(i.title)}</span><small>${esc(shortCourse(i.course || i.course_key || "Schoolwork"))} · ${esc(dueLabel(i))}</small>
      ${i.date_note ? `<small class="nc-date-note">${esc(i.date_note)}</small>` : ""}</button>`).join("") || '<p>No unfinished schoolwork on your board. Check Assignments for the full picture.</p>'}
    <button type="button" class="linkbtn nc-guide" data-start-tour>Show me around</button></section>`;
}
function renderSimpleExtra() {
  const host = $("#home-extra");
  if (!host) return;
  if (!simpleLook() || !STATE) { host.hidden = true; return; }
  const open = openItems();
  // Cards first: [MEASURED] 2026-10-07 at 995x605 eight heads-ups put the
  // first card at 730px, below the window. What to do beats what changed.
  const completed = ((STATE.items) || []).filter((i) => i.done).length;
  const personal = lifeOpen().length;
  host.innerHTML = `<div class="nc-shortcuts" aria-label="More information">
    <button type="button" data-tab="life">Personal tasks <span>${personal}</span></button>
    <button type="button" data-tab="done">Completed <span>${completed}</span></button>
    <button type="button" id="nc-history">Chat history</button>
  </div>${homeSnapshotHtml()}
    ${noticesHtml()}${alertsOfferHtml()}`;
  host.hidden = PANE !== "home";
}

/* Grades: one row per class, the letter, a bar and the percent. A class
   with no grade yet says so instead of showing 0% (the portal reports
   exactly that for an ungraded class). Clicking a row opens the class. */
function renderGradesPage() {
  const host = $("#grades-body");
  if (!host || !STATE) return;
  const { shown, hiddenCount } = boardCourses();
  const rows = shown.map((c) => {
    const pct = hasPercent(c) ? c.percent : null;
    const band = pct == null ? "none" : gradeBand(pct);
    return classControl(c.key, `<span class="gp-letter">${c.graded && c.letter ? esc(c.letter) : "\u2013"}</span>
      <span class="gp-name">${esc(c.name)}</span>
      <span class="gp-bar"><i class="band-${band}" style="width:${pct == null ? 0 : Math.max(0, Math.min(100, pct))}%"></i></span>
      <span class="gp-pct">${pct == null ? (c.graded && c.letter ? "" : "no grade yet") : pct.toFixed(1) + "%"}</span>`,
      "gp-row", c.name);
  }).join("");
  host.innerHTML = `<div class="sp-page"><h2 class="sp-title">Grades</h2>
    ${hiddenCount ? `<p class="sp-foot">${hiddenCount} hidden class${hiddenCount === 1 ? "" : "es"}. <button type="button" class="linkbtn" data-tab="settings">Manage in Settings</button></p>` : ""}
    <div class="gp-list">${rows || `<p class="secempty">No grades read yet \u2014 press Refresh.</p>`}</div>
    ${STATE.grades_read_at ? `<p class="sp-foot">From Veracross, read ${esc(String(STATE.grades_read_at).slice(0, 16).replace("T", " "))}. Click a class for every mark.</p>` : ""}</div>`;
}
window.renderGradesPage = renderGradesPage;

/* Classes: one card per class — its open work and the next thing due. The
   board's per-class tabs, as a page. */
function renderClassListPage() {
  const host = $("#classlist-body");
  if (!host || !STATE) return;
  const { shown, hiddenCount } = boardCourses();
  const today = todayIso();
  const cards = shown.map((c) => {
    const open = openFor(c.key).filter((i) => !isPastAssessment(i, today));
    const next = open.find((i) => i.due_date);
    const u = urgencyOf(c.key);
    return classControl(c.key, `<span class="cl-top"><b>${esc(c.name)}</b>${
        c.graded && c.letter ? `<em>${esc(c.letter)}</em>` : ""}</span>
      <span class="cl-sub band-${u.band}"><i></i>${open.length ? `${open.length} open` : "nothing open"}${
        next ? ` \u00b7 next: ${esc(next.title)} (${esc(dueLabel(next))})` : ""}</span>
      ${next && next.date_note ? `<span class="cl-date-note">${esc(next.date_note)}</span>` : ""}`,
      "cl-card", c.name);
  }).join("");
  host.innerHTML = `<div class="sp-page"><h2 class="sp-title">Classes</h2>
    <div class="cl-grid">${cards || `<p class="secempty">No visible classes yet. <button type="button" class="linkbtn" data-tab="settings">Manage classes in Settings</button></p>`}</div>
    ${hiddenCount ? `<p class="sp-foot">${hiddenCount} class${hiddenCount === 1 ? " is" : "es are"} switched off in Settings \u2192 Classes.</p>` : ""}</div>`;
}
window.renderClassListPage = renderClassListPage;

/* A class switched off in Settings -> Classes loses its tab. If it was the
   open one, the strip does not just go blank — it goes home, because a tab
   that is lit and gone is worse than no tab. */
function openTab(key) {
  const fixed = FIXED_TABS.find((t) => t.key === key);
  if (fixed) {
    OPEN_TAB = key;
    if (window.showView) window.showView(fixed.view);
    else showPane(fixed.view);
    renderTabStrip();
    saveUiPrefs({ start_tab: key });
    return;
  }
  const { shown } = boardCourses();
  if (!shown.some((c) => c.key === key)) { openTab("home"); return; }
  OPEN_TAB = key;
  if (window.openGradePane) window.openGradePane(key);
  renderTabStrip();
  saveUiPrefs({ start_tab: key });
}
window.openTab = openTab;

/* Scoped to real controls: `data-tab` is stamped on <html> by the 0.18 runtime
   as well, so a bare [data-tab] here would match every click in the document. */
document.addEventListener("click", (event) => {
  const snapshot = event.target.closest("button[data-home-item]");
  if (snapshot) { openDetail(snapshot.dataset.homeItem); return; }
  if (event.target.closest("#nc-history")) {
    const button = $("#chat-history-btn");
    if (button) button.click();
    return;
  }
  const hit = event.target.closest("button[data-tab]");
  if (hit) openTab(hit.dataset.tab);
});

/* ---------------- the two pages the strip adds ---------------- */

/* Life: everything that is his rather than the school's, at full width. The
   left column's section is the short version of this same list. */
function renderLifePage() {
  const host = $("#life-body");
  if (!host || !STATE) return;
  const today = todayIso();
  const open = lifeOpen().slice().sort((a, b) => (a.due_date || "9999") < (b.due_date || "9999") ? -1 : 1);
  const done = ((STATE.items) || []).filter((i) => i.done && personalSection(i));
  const row = (i) => `<div class="workrow">
    <input type="checkbox" class="tick" ${i.done ? "checked" : ""}
      aria-label="Mark ${esc(i.title)} done" data-id="${esc(i.item_id)}">
    <button type="button" class="grow" data-open="${esc(i.item_id)}">
      <span class="t ${i.done ? "struck" : ""}">${esc(i.title)}</span>
      <span class="m"><span>${esc(lifeKindOf(i))}</span>
        <span class="${esc(urgencyWord(i.due_date, today, i))}">${esc(i.due_date ? relDays(i.due_date, today) : "someday")}</span>
        <span>${esc(i.date_note || "you added this")}</span></span></button></div>`;
  host.innerHTML = `<div class="page">
    <div class="kick">Yours, not the school's</div>
    <h2>Life stuff</h2>
    <p class="muted">Work that is not in Canvas, a goal, a practice, makeup work, a club.
      Every one carries the note saying you added it, and a refresh never overwrites one.</p>
    ${LIFE_KINDS.map(([key, label]) => {
      const list = open.filter((i) => lifeKindOf(i) === key);
      if (!list.length) return "";
      return `<div class="sech">${esc(label)} · ${list.length}</div>${list.map(row).join("")}`;
    }).join("") || `<div class="secempty">Nothing of your own is open. ✅</div>`}
    ${open.some((i) => lifeKindOf(i) === "yours")
      ? `<div class="sech">Other · ${open.filter((i) => lifeKindOf(i) === "yours").length}</div>`
        + open.filter((i) => lifeKindOf(i) === "yours").map(row).join("") : ""}
    <div class="acts"><button type="button" class="primary" data-add="goals">Add something</button></div>
    ${done.length ? `<details class="done-group"><summary>done (${done.length})</summary>
      ${done.map(row).join("")}</details>` : ""}
  </div>`;
}
window.renderLifePage = renderLifePage;

/* Calendar — the whole window, laid out like Google Calendar.

   [ASKED] 2026-10-06: "make the calender on silly bus page look more like
   google calender and take up the whole page when you click it make it as
   easy to add stuff using the chat". So: Day / Week / Month with Today and
   arrows; an hour grid where each class sits at its real time in its own
   colour; homework in the all-day row of the day it is due; games and
   practices from TeamSnap (and anything he added) as their own blocks; a red
   line at now. It opens full page (showPane's `full` list).

   Adding is the chat's job, not a form's: "+ Add" and a click on an empty
   hour put the start of a sentence in the chat box under the calendar
   ("on Thu, Oct 8 at 5 PM") with the cursor in front, so he types what it is
   and presses Send — quick-add reads the day and the time, and the card it
   answers with is the one confirmation. One way to add, everywhere.

   What is drawn is only what the board already holds. Classes come from the
   timetable (`STATE.schedule`, about a week back and three ahead — outside
   that a day says so rather than looking free), homework from `STATE.items`
   with its date_note on hover, events from `STATE.events`. */
let CAL_PAGE_DAY = null;
let CAL_LINK_HELP = false;      /* the Mac app's how-to-link note; see calLinkTeamSnap */
let CAL_VIEW = (() => {
  /* Week, as Google opens — except on a phone-width screen, where seven
     columns are 40px each and Day is what Google's own phone app opens on. */
  const first = (typeof innerWidth === "number" && innerWidth < 600) ? "day" : "week";
  try { const v = localStorage.getItem("sillybus.calview"); return ["day", "week", "month"].includes(v) ? v : first; }
  catch (e) { return first; }
})();
const CAL_HOUR_PX = 48;
let CAL_SCROLLED = "";            // which view+range was last scrolled into place
let CAL_FOCUS_MIN = null;         // a time to bring into view once ("See it")
const CAL_MONTHS = ["January", "February", "March", "April", "May", "June", "July",
  "August", "September", "October", "November", "December"];

function calSetView(view) {
  CAL_VIEW = view;
  try { localStorage.setItem("sillybus.calview", view); } catch (e) { /* private window */ }
  renderCalendarPage();
}
function calDate(iso) { return new Date(iso + "T12:00:00"); }
function calWeekStart(iso) {
  const first = (UI && UI.week_starts === "monday") ? 1 : 0;   // Google's default is Sunday
  const dow = calDate(iso).getDay();
  return isoPlus(iso, -((dow - first + 7) % 7));
}
function calDays(view, anchor) {
  if (view === "day") return [anchor];
  if (view === "week") { const s = calWeekStart(anchor); return [0, 1, 2, 3, 4, 5, 6].map((n) => isoPlus(s, n)); }
  const d = calDate(anchor);
  const firstOfMonth = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-01`;
  const s = calWeekStart(firstOfMonth);
  /* Only the weeks the month touches — five for most, six for a few — so
     a 605px window does not spend a row on next month. */
  const all = Array.from({ length: 42 }, (_, n) => isoPlus(s, n));
  const month = d.getMonth();
  const weeks = all.slice(35, 42).some((x) => calDate(x).getMonth() === month) ? 6
    : all.slice(28, 35).some((x) => calDate(x).getMonth() === month) ? 5 : 4;
  return all.slice(0, weeks * 7);
}
function calStep(view, anchor, dir) {
  if (view === "day") return isoPlus(anchor, dir);
  if (view === "week") return isoPlus(anchor, 7 * dir);
  const d = calDate(anchor);
  const m = new Date(d.getFullYear(), d.getMonth() + dir, 1, 12);
  return `${m.getFullYear()}-${String(m.getMonth() + 1).padStart(2, "0")}-01`;
}
function calTitle(view, anchor, days) {
  const d = calDate(anchor);
  if (view === "month") return `${CAL_MONTHS[d.getMonth()]} ${d.getFullYear()}`;
  if (view === "day") return d.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric", year: "numeric" });
  const a = calDate(days[0]), b = calDate(days[days.length - 1]);
  const short = (x) => x.toLocaleDateString(undefined, { month: "short" });
  return a.getMonth() === b.getMonth()
    ? `${CAL_MONTHS[a.getMonth()]} ${a.getFullYear()}`
    : `${short(a)} – ${short(b)} ${b.getFullYear()}`;
}
function calMinutes(isoTime) {
  const t = String(isoTime || "").slice(11, 16);
  if (!/^\d\d:\d\d$/.test(t)) return null;
  return Number(t.slice(0, 2)) * 60 + Number(t.slice(3, 5));
}
function calClock(min) {
  const h = Math.floor(min / 60), m = min % 60;
  return `${h % 12 || 12}${m ? ":" + String(m).padStart(2, "0") : ""}${h >= 12 ? " PM" : " AM"}`;
}
/* Everything on one day, split the way Google splits it: the timed blocks
   for the grid, and the rest (homework due, all-day events) for the top row. */
function calDayContent(day) {
  const blocks = [], allDay = [];
  for (const m of (STATE.schedule || {})[day] || []) {
    const s = calMinutes(m.start), e = calMinutes(m.end);
    if (s === null) continue;
    blocks.push({ s, e: e && e > s ? e : s + 50, type: "class", m });
  }
  for (const ev of eventsOn(day)) {
    const s = calMinutes(ev.start);
    const sameDay = (ev.start || "").slice(0, 10) === day;
    if (ev.all_day || s === null || !sameDay) { allDay.push({ type: "event", ev }); continue; }
    /* No end at all (a feed event with DURATION, or a bare start) is an hour,
       not "until midnight": it was drawn to 24:00 and squeezed every evening
       event beside it into half width (prosecution 2026-10-06). */
    const endsToday = (ev.end || "").slice(0, 10) === day;
    const e = !ev.end ? s + 60 : endsToday ? calMinutes(ev.end) : 24 * 60;
    blocks.push({ s, e: e && e > s ? e : s + 60, type: "event", ev });
  }
  for (const i of STATE.items || []) {
    if (i.due_date === day) allDay.push({ type: "item", i });
  }
  allDay.sort((a, b) => (a.type === "item") - (b.type === "item")
    || Number(!!(a.i && a.i.done)) - Number(!!(b.i && b.i.done)));
  return { blocks, allDay };
}
/* Side by side when they overlap, the way Google draws a clash. */
function calLanes(blocks) {
  const sorted = [...blocks].sort((a, b) => a.s - b.s || b.e - a.e);
  let cluster = [], end = -1;
  const flush = () => {
    const lanes = [];
    for (const b of cluster) {
      let i = lanes.findIndex((free) => free <= b.s);
      if (i < 0) { i = lanes.length; lanes.push(0); }
      lanes[i] = b.e; b.lane = i;
    }
    for (const b of cluster) b.lanes = lanes.length;
    cluster = [];
  };
  for (const b of sorted) {
    if (cluster.length && b.s >= end) flush();
    cluster.push(b); end = Math.max(end, b.e);
  }
  if (cluster.length) flush();
  return sorted;
}
function calEventColor(ev) {
  if ((ev.flags || []).includes("mine")) return "var(--accent)";
  return ev.source === "teamsnap" ? "#E8710A" : ev.source === "google_calendar" ? "#4285F4" : "#7B61C9";
}
function calChipHtml(c) {
  if (c.type === "item") {
    const i = c.i;
    return `<button type="button" class="gc-chip gc-due${i.done ? " is-done" : ""}" data-open="${esc(i.item_id)}"
      style="--c:${esc(classColor(i.course_key))}" title="${esc(`${i.title} — ${shortName(i.course || "")} · ${i.date_note || ""}`)}">
      <span class="gc-dot" aria-hidden="true"></span><span class="gc-t">${esc(i.title)}</span></button>`;
  }
  const ev = c.ev;
  return `<button type="button" class="gc-chip gc-allday" data-cal-event="${esc(ev.event_id)}"
    style="--c:${esc(calEventColor(ev))}" title="${esc(`${ev.title} — ${ev.date_note || ""}`)}">
    <span class="gc-t">${esc(EVENT_ICONS[ev.kind] || "")} ${esc(ev.title)}</span></button>`;
}
function calBlockHtml(b, top) {
  const pos = `top:${(b.s - top) / 60 * CAL_HOUR_PX}px;height:${Math.max(18, (b.e - b.s) / 60 * CAL_HOUR_PX - 2)}px;`
    + `left:calc(${b.lane} * 100% / ${b.lanes});width:calc(100% / ${b.lanes} - 3px);`;
  const when = `${calClock(b.s)} – ${calClock(b.e)}`;
  const short = (b.e - b.s) < 45 ? " is-short" : "";
  if (b.type === "class") {
    const m = b.m;
    const name = shortName(m.course_raw || m.course_key);
    /* Through classControl, the one builder of a class button, so the
       published snapshot gets a plain block instead of a dead button. */
    return `<div class="gc-slot" style="${pos}--c:${esc(classColor(m.course_key))}">${classControl(m.course_key,
      `<b>${esc(name)}</b><span>${esc(when)}${m.room ? ` · ${esc(m.room)}` : ""}</span>`,
      `gc-ev gc-class${short}`, `${name} · ${when}${m.room ? " · " + m.room : ""}`)}</div>`;
  }
  const ev = b.ev;
  return `<button type="button" class="gc-ev gc-event${short}" data-cal-event="${esc(ev.event_id)}"
    style="${pos}--c:${esc(calEventColor(ev))}" title="${esc(`${ev.title} · ${when} — ${ev.date_note || ""}`)}">
    <b>${esc(EVENT_ICONS[ev.kind] || "")} ${esc(ev.title)}</b><span>${esc(when)}${ev.location ? ` · ${esc(ev.location)}` : ""}</span></button>`;
}
function calHeadHtml(day, today) {
  const d = calDate(day);
  return `<button type="button" class="gc-dayhead${day === today ? " is-today" : ""}" data-cal-goto="${esc(day)}"
    aria-label="${esc(niceDate(day, true))}">
    <span class="gc-dow">${esc(d.toLocaleDateString(undefined, { weekday: "short" }).toUpperCase())}</span>
    <span class="gc-num">${d.getDate()}</span></button>`;
}
function calGridHtml(days, today) {
  const content = days.map((day) => ({ day, ...calDayContent(day) }));
  let top = 7 * 60, bottom = 22 * 60;
  for (const c of content) for (const b of c.blocks) { top = Math.min(top, b.s); bottom = Math.max(bottom, b.e); }
  top = Math.floor(top / 60) * 60; bottom = Math.min(24 * 60, Math.ceil(bottom / 60) * 60);
  const hours = [];
  for (let m = top; m < bottom; m += 60) hours.push(m);
  const height = (bottom - top) / 60 * CAL_HOUR_PX;
  const known = STATE.schedule || {};
  const cols = content.map((c) => {
    const nowLine = c.day === today
      ? (() => { const n = new Date(); const min = n.getHours() * 60 + n.getMinutes();
          return min >= top && min <= bottom ? `<div class="gc-now" style="top:${(min - top) / 60 * CAL_HOUR_PX}px"></div>` : ""; })()
      : "";
    const unknown = !(c.day in known) && !c.blocks.length
      ? `<div class="gc-unknown">no timetable this far out</div>` : "";
    return `<div class="gc-col${c.day === today ? " is-today" : ""}" data-cal-slot="${esc(c.day)}" data-top="${top}">
      ${calLanes(c.blocks).map((b) => calBlockHtml(b, top)).join("")}${nowLine}${unknown}</div>`;
  }).join("");
  const many = days.length === 1 ? content[0].allDay.length : 0;
  return `<div class="gc-week" style="--days:${days.length}">
    <div class="gc-heads"><div class="gc-gutter"></div>${days.map((d) => calHeadHtml(d, today)).join("")}</div>
    <div class="gc-allrow${many > 3 ? " is-tall" : ""}"><div class="gc-gutter gc-alllabel">due</div>
      ${content.map((c) => {
        /* Three a day and "N more", as Google does: a week of homework in
           the top row used to push the hours off a 605px window. A single
           day has the room, so it shows them all. */
        const cap = days.length === 1 ? c.allDay.length : 3;
        const more = c.allDay.length - cap;
        return `<div class="gc-allcell">${c.allDay.slice(0, cap).map(calChipHtml).join("")}${
          more > 0 ? `<button type="button" class="gc-more" data-cal-goto="${esc(c.day)}">${more} more</button>` : ""}</div>`;
      }).join("")}</div>
    <div class="gc-scroll" id="gc-scroll">
      <div class="gc-body" style="height:${height}px">
        <div class="gc-gutter gc-hours">${hours.map((m) => `<span style="top:${(m - top) / 60 * CAL_HOUR_PX}px">${m === top ? "" : esc(calClock(m))}</span>`).join("")}</div>
        <div class="gc-lines" style="background-size:100% ${CAL_HOUR_PX}px"></div>
        ${cols}
      </div>
    </div>
  </div>`;
}
function calMonthGridHtml(days, anchor, today) {
  const month = calDate(anchor).getMonth();
  const heads = days.slice(0, 7).map((d) =>
    `<div class="gc-mdow">${esc(calDate(d).toLocaleDateString(undefined, { weekday: "short" }).toUpperCase())}</div>`).join("");
  const cells = days.map((day) => {
    const { blocks, allDay } = calDayContent(day);
    const timed = blocks.filter((b) => b.type === "event").map((b) => ({ type: "event", ev: b.ev, s: b.s }));
    const chips = [...allDay.filter((c) => c.type === "event"), ...timed, ...allDay.filter((c) => c.type === "item")];
    const shown = chips;          // calFitMonth trims to the box after drawing
    const more = 0;
    const chip = (c) => (c.s !== undefined
      ? `<button type="button" class="gc-mchip" data-cal-event="${esc(c.ev.event_id)}" style="--c:${esc(calEventColor(c.ev))}"
           title="${esc(c.ev.title)}"><span class="gc-dot"></span>${esc(calClock(c.s))} ${esc(c.ev.title)}</button>`
      : calChipHtml(c));
    const d = calDate(day);
    return `<div class="gc-mcell${d.getMonth() !== month ? " is-other" : ""}${day === today ? " is-today" : ""}" data-cal-mday="${esc(day)}">
      <button type="button" class="gc-mnum" data-cal-goto="${esc(day)}" aria-label="${esc(niceDate(day, true))}">${d.getDate() === 1 ? esc(d.toLocaleDateString(undefined, { month: "short" })) + " " : ""}${d.getDate()}</button>
      ${shown.map(chip).join("")}
      <button type="button" class="gc-more" data-cal-goto="${esc(day)}" hidden>${more} more</button>
    </div>`;
  }).join("");
  return `<div class="gc-month"><div class="gc-mheads">${heads}</div>
    <div class="gc-mgrid" style="grid-template-rows: repeat(${days.length / 7}, minmax(0, 1fr))">${cells}</div></div>`;
}
/* As many as the box holds, then "N more" — measured, because how many fit
   depends on the window, not on a number chosen here. */
function calFitMonth() {
  for (const cell of document.querySelectorAll("#calendar-body .gc-mcell")) {
    const chips = [...cell.querySelectorAll(".gc-chip, .gc-mchip")];
    const more = cell.querySelector(".gc-more");
    chips.forEach((c) => { c.hidden = false; });
    if (more) more.hidden = true;
    let hiddenCount = 0;
    for (let i = chips.length - 1; i >= 0 && cell.scrollHeight > cell.clientHeight + 1; i--) {
      chips[i].hidden = true; hiddenCount++;
      if (more) { more.hidden = false; more.textContent = `${hiddenCount} more`; }
    }
  }
}
window.addEventListener("resize", () => { if (CAL_VIEW === "month") calFitMonth(); });
function renderCalendarPage() {
  const host = $("#calendar-body");
  if (!host || !STATE) return;
  const today = calToday();
  const anchor = CAL_PAGE_DAY || today;
  const days = calDays(CAL_VIEW, anchor);
  const old = $("#gc-scroll");
  const keep = old ? old.scrollTop : null;
  const views = [["day", "Day"], ["week", "Week"], ["month", "Month"]];
  host.innerHTML = `<div class="gcal">
    <div class="gc-bar">
      <button type="button" class="gc-today" data-cal-day="${esc(today)}">Today</button>
      <button type="button" class="gc-arrow" data-cal-day="${esc(calStep(CAL_VIEW, anchor, -1))}" aria-label="back">‹</button>
      <button type="button" class="gc-arrow" data-cal-day="${esc(calStep(CAL_VIEW, anchor, 1))}" aria-label="forward">›</button>
      <h2 class="gc-title">${esc(calTitle(CAL_VIEW, anchor, days))}</h2>
      <span class="gc-legend">
        <span><i style="--c:#E8710A"></i>TeamSnap</span><span><i style="--c:#4285F4"></i>Google</span><span><i style="--c:var(--accent)"></i>yours</span>
      </span>
      <div class="gc-views" role="group" aria-label="calendar view">
        ${views.map(([v, label]) => `<button type="button" data-cal-view="${v}" class="${CAL_VIEW === v ? "on" : ""}" aria-pressed="${CAL_VIEW === v}">${label}</button>`).join("")}
      </div>
      <button type="button" class="ghost gc-link" data-cal-link="teamsnap"
        title="Link TeamSnap: put your games and practices on this calendar">🔗 TeamSnap</button>
      <button type="button" class="ghost gc-link" data-cal-link="google"
        title="Link Google Calendar: put its events on this calendar">🔗 Google</button>
      <button type="button" class="primary gc-add" data-cal-add="${esc(anchor === today ? "" : anchor)}">+ Add</button>
    </div>
    ${CAL_LINK_HELP ? calLinkHelpHtml() : ""}
    ${(STATE && (STATE.schedule_hidden || []).length) ? `<p class="fine gc-hidden">Not from Veracross — its times for these are wrong, so they come from TeamSnap: ${esc(STATE.schedule_hidden.join(", "))}.</p>` : ""}
    ${CAL_VIEW === "month" ? calMonthGridHtml(days, anchor, today) : calGridHtml(days, today)}
    <div class="gc-pop" id="gc-pop" hidden></div>
  </div>`;
  if (CAL_VIEW === "month") { calFitMonth(); CAL_FOCUS_MIN = null; }
  const scroller = $("#gc-scroll");
  if (scroller) {
    const key = `${CAL_VIEW}|${days[0]}`;
    const col0 = scroller.querySelector(".gc-col");
    if (CAL_FOCUS_MIN !== null && col0) {
      scroller.scrollTop = Math.max(0, (CAL_FOCUS_MIN - Number(col0.dataset.top) - 60) / 60 * CAL_HOUR_PX);
      CAL_FOCUS_MIN = null; CAL_SCROLLED = key;
    } else if (keep !== null && CAL_SCROLLED === key) scroller.scrollTop = keep;
    else {
      /* Open on the morning, or on now when now is in view. */
      const col = scroller.querySelector(".gc-col");
      const top = col ? Number(col.dataset.top) : 7 * 60;
      const n = new Date();
      const at = days.includes(today) ? Math.max(top, n.getHours() * 60 + n.getMinutes() - 90) : 7 * 60;
      scroller.scrollTop = Math.max(0, (at - top) / 60 * CAL_HOUR_PX);
      CAL_SCROLLED = key;
    }
  }
}
window.renderCalendarPage = renderCalendarPage;

/* The start of a sentence in the chat box, cursor in front: he types WHAT,
   presses Send, and quick-add reads the rest. */
function calAskChat(day, minutes) {
  const input = $("#chat-input");
  if (!input) return;
  const d = day ? calDate(day) : null;
  /* "on Oct 8", never "on Thu, Oct 8": quick-add removes ONE day phrase, and
     the weekday stayed in the name ("Tutor on Tue"). A day with no hour is
     "all day", which quick-add reads as an all-day event. */
  /* The ISO date, so the year comes along: "on Sep 10" for a click on
     Sep 10 2027 landed on Sep 10 2026 (prosecution 2026-10-06). */
  const when = d ? ` on ${day}` : "";
  const at = minutes != null ? ` at ${calClock(minutes).replace(" ", "").toLowerCase()}` : (d ? " all day" : "");
  /* Put the composer where it is unmistakable. The dock is always present,
     but on a full-screen calendar it was easy to miss; open the conversation
     before focusing it, including in the simple layout. */
  if (window.showView) window.showView("chat");
  else showPane("chat");
  input.value = when || at ? `${when}${at}` : "";
  input.placeholder = "Type what to add before the date, then press Send";
  input.focus();
  try { input.setSelectionRange(0, 0); } catch (e) { /* not a text input */ }
  input.classList.add("gc-asking");
  setTimeout(() => input.classList.remove("gc-asking"), 1600);
}
/* "Link TeamSnap", on the calendar itself.

   [ASKED] 2026-10-06: "make at least one for the ability to link in the app
   right here". Two builds, two honest answers:

   In the Chrome extension (window.sdChrome exists only there) the page IS
   the extension, so it can read TeamSnap's export page with the session
   Chrome already has: bridge.js's linkTeamSnap() asks Chrome for TeamSnap,
   finds the "All games and events" address and saves it — one click. It is
   called straight from the click with nothing awaited first, because Chrome
   shows a permission prompt only inside the click that asked for it.

   In the Mac app nothing can read TeamSnap for him: its feed host sends no
   CORS header ([MEASURED] 2026-10-06) and this window has no TeamSnap
   session. So the button opens TeamSnap in his browser and says the two ways
   that work from there — the extension's "Link this page", or the address
   pasted into Settings → Connections, opened on the TeamSnap steps. No
   chrome.* call is made here; this file never touches Chrome's APIs itself. */
function calLinkHelpHtml() {
  if (CAL_LINK_HELP === "google") {
    return `<div class="gc-linkhelp" role="note">
    <button type="button" class="gc-popx" data-cal-linkhelp="close" aria-label="close">×</button>
    <b>Google Calendar opened in your browser. Connect it here:</b>
    <ol>
      <li>Keep the Mac app running. The extension connects automatically; approve Chrome site access if asked.</li>
      <li>On Google Calendar, click the puzzle piece in Chrome's toolbar → <b>SillyBus AI</b> →
        <b>Link this page</b> → <b>Connect it</b> — no address to copy.</li>
      <li>Or, under your calendar → <b>Integrate calendar</b>, copy the
        <b>Secret address in iCal format</b> and paste it in Settings → Connections.</li>
    </ol>
    <div class="gc-popact">
      <button type="button" class="ghost" data-cal-linkhelp="settings">Open Settings → Connections</button>
    </div>
  </div>`;
  }
  return `<div class="gc-linkhelp" role="note">
    <button type="button" class="gc-popx" data-cal-linkhelp="close" aria-label="close">×</button>
    <b>TeamSnap opened in your browser. Connect it here:</b>
    <ol>
      <li>Keep the Mac app running. The extension connects automatically; approve Chrome site access if asked.</li>
      <li>On that TeamSnap page, click the puzzle piece in Chrome's toolbar →
        <b>SillyBus AI</b> → <b>Link this page</b> → <b>Connect it</b>.</li>
      <li>Or copy TeamSnap's schedule address (<b>Schedule</b> → <b>Go to My Full Schedule</b> →
        <b>Subscribe/Export</b> → <b>All games and events</b>) and paste it in Settings → Connections.</li>
    </ol>
    <div class="gc-popact">
      <button type="button" class="ghost" data-cal-linkhelp="settings">Open Settings → Connections</button>
    </div>
  </div>`;
}
/* Google Calendar: one click in the extension (its Export, read with the
   Google sign-in Chrome has — bridge.js linkGoogleCalendar). The Mac app has
   no Google session, so there it opens Google Calendar's settings and says
   where the secret address is. [ASKED] 2026-10-06. */
function calLinkGoogle(btn) {
  const ext = window.sdChrome;
  if (ext && typeof ext.linkGoogleCalendar === "function") {
    btn.disabled = true;
    Promise.resolve(ext.linkGoogleCalendar()).catch(() => false).finally(() => { btn.disabled = false; });
    return;
  }
  window.open("https://calendar.google.com/calendar/", "_blank", "noopener");
  CAL_LINK_HELP = "google";
  renderCalendarPage();
}
function calLinkTeamSnap(btn) {
  const ext = window.sdChrome;
  if (ext && typeof ext.linkTeamSnap === "function") {
    btn.disabled = true;
    Promise.resolve(ext.linkTeamSnap()).catch(() => false).finally(() => { btn.disabled = false; });
    return;
  }
  window.open("https://go.teamsnap.com/team/export_schedule", "_blank", "noopener");
  CAL_LINK_HELP = "teamsnap";
  renderCalendarPage();
}

function calEventPopHtml(ev) {
  const mine = (ev.flags || []).includes("mine");
  return `<div class="gc-popcard" role="dialog" aria-label="${esc(ev.title)}">
    <button type="button" class="gc-popx" data-cal-popclose aria-label="close">×</button>
    <div class="gc-pophead"><i style="--c:${esc(calEventColor(ev))}"></i><b>${esc(ev.title)}</b></div>
    <div>${esc(niceDate(ev.date, true))} · ${esc(eventTime(ev))}</div>
    ${ev.location ? `<div>📍 ${esc(ev.location)}</div>` : ""}
    ${mine ? "" : `<div class="gc-popsrc">from ${esc(ev.connection || "a connected calendar")}</div>`}
    <div class="date-note">${esc(ev.date_note || "")}</div>
    <div class="gc-popact">
      ${safeHref(ev.url) ? `<a href="${esc(ev.url)}" target="_blank" rel="noopener">open in ${esc(ev.connection || "its calendar")}</a>` : ""}
      ${mine ? `<button type="button" class="ghost" data-cal-delete="${esc(ev.event_id)}">Delete</button>` : ""}
    </div></div>`;
}

document.addEventListener("click", async (event) => {
  const hit = event.target.closest("button[data-cal-day]");
  if (hit) { CAL_PAGE_DAY = hit.dataset.calDay; renderCalendarPage(); return; }
  if (!event.target.closest("#calendar-body")) return;
  const view = event.target.closest("button[data-cal-view]");
  if (view) { calSetView(view.dataset.calView); return; }
  const go = event.target.closest("button[data-cal-goto]");
  if (go) { CAL_PAGE_DAY = go.dataset.calGoto; calSetView("day"); return; }
  const add = event.target.closest("button[data-cal-add]");
  if (add) { calAskChat(add.dataset.calAdd || null, null); return; }
  /* Before any await in this handler: the extension's permission prompt
     needs the click to still be live. */
  const link = event.target.closest("button[data-cal-link]");
  if (link) { (link.dataset.calLink === "google" ? calLinkGoogle : calLinkTeamSnap)(link); return; }
  const help = event.target.closest("button[data-cal-linkhelp]");
  if (help) {
    CAL_LINK_HELP = false;
    renderCalendarPage();
    if (help.dataset.calLinkhelp === "settings") {
      if (window.showView) window.showView("settings");
      if (window.showSetPage) window.showSetPage("connections");
      if (window.showConnectGuide) window.showConnectGuide("teamsnap");
    }
    return;
  }
  const pop = $("#gc-pop");
  if (event.target.closest("button[data-cal-popclose]")) { if (pop) pop.hidden = true; return; }
  const del = event.target.closest("button[data-cal-delete]");
  if (del) {
    del.disabled = true;
    await fetch(`/api/events/${encodeURIComponent(del.dataset.calDelete)}`, { method: "DELETE" });
    if (pop) pop.hidden = true;
    await loadState();
    renderCalendarPage();
    return;
  }
  const evBtn = event.target.closest("button[data-cal-event]");
  if (evBtn && pop) {
    const ev = allEvents().find((e) => e.event_id === evBtn.dataset.calEvent);
    if (!ev) return;
    pop.innerHTML = calEventPopHtml(ev);
    pop.hidden = false;
    const box = $(".gcal").getBoundingClientRect(), r = evBtn.getBoundingClientRect();
    const left = Math.min(Math.max(8, r.right - box.left + 6), box.width - 290);
    pop.style.left = `${left < r.left - box.left - 280 ? r.left - box.left - 290 : left}px`;
    pop.style.top = `${Math.min(Math.max(8, r.top - box.top), box.height - 200)}px`;
    return;
  }
  if (pop && !pop.hidden && !event.target.closest("#gc-pop")) pop.hidden = true;
  /* An empty hour: the chat, already holding that day and time. */
  const col = event.target.closest(".gc-col[data-cal-slot]");
  if (col && !event.target.closest(".gc-ev")) {
    const y = event.clientY - col.getBoundingClientRect().top;
    const minutes = Number(col.dataset.top) + Math.floor(y / CAL_HOUR_PX * 2) * 30;
    calAskChat(col.dataset.calSlot, minutes);
    return;
  }
  const cell = event.target.closest(".gc-mcell[data-cal-mday]");
  if (cell && !event.target.closest("button")) calAskChat(cell.dataset.calMday, null);
});
/* Keys, only while the calendar is the page and nothing is being typed:
   T today, W/M week or month, J/N forward, K/P back — Google's letters. Not D
   or the arrows: those are the board's own shortcuts (Done, and stepping
   tabs), and a page must not quietly take them over. */
document.addEventListener("keydown", (event) => {
  if (typeof PANE === "undefined" || PANE !== "calendar") return;
  if (event.metaKey || event.ctrlKey || event.altKey) return;
  if (event.target.closest && event.target.closest("input, textarea, select, [contenteditable]")) return;
  const anchor = CAL_PAGE_DAY || calToday();
  const k = event.key;
  if (k === "t" || k === "T") { CAL_PAGE_DAY = calToday(); renderCalendarPage(); }
  else if (k === "w" || k === "W") calSetView("week");
  else if (k === "m" || k === "M") calSetView("month");
  else if (k === "k" || k === "p") { CAL_PAGE_DAY = calStep(CAL_VIEW, anchor, -1); renderCalendarPage(); }
  else if (k === "j" || k === "n") { CAL_PAGE_DAY = calStep(CAL_VIEW, anchor, 1); renderCalendarPage(); }
  else return;
  event.preventDefault();
  event.stopImmediatePropagation();
}, true);
/* The red line keeps up with the clock. */
setInterval(() => {
  const line = document.querySelector("#calendar-body .gc-now");
  const col = line && line.closest(".gc-col");
  if (!line || !col) return;
  const n = new Date();
  line.style.top = `${(n.getHours() * 60 + n.getMinutes() - Number(col.dataset.top)) / 60 * CAL_HOUR_PX}px`;
}, 60000);

/* ==========================================================================
   0.20 stage 5 — Settings, as six pages
   ==========================================================================

   The 0.18 Settings was nine cards in an auto-fit grid, which put "Connect
   Chrome" next to "Appearance" and made the page a search rather than a place.
   Six pages now — Classes · Textbooks · Appearance · Main page · Connections ·
   About — with the existing cards MOVED rather than rewritten: every one has
   wiring in views.js that looks its nodes up by id, and a node keeps its id
   when it changes parents. */

let SET_PAGE = "classes";
const SET_PAGES = ["classes", "textbooks", "appearance", "mainpage", "focus", "connections", "about"];

function showSetPage(key) {
  if (!SET_PAGES.includes(key)) key = "classes";
  SET_PAGE = key;
  for (const page of document.querySelectorAll(".setpage")) {
    page.hidden = page.dataset.page !== key;
  }
  for (const b of document.querySelectorAll(".setnav button[data-setpage]")) {
    const on = b.dataset.setpage === key;
    b.classList.toggle("on", on);
    b.setAttribute("aria-current", on ? "page" : "false");
  }
  if (key === "classes") renderClassesPage();
  if (key === "textbooks") renderTextbooksPage();
  if (key === "appearance") renderAppearancePage();
  /* the switches come from /api/sources; the page is drawn once they land,
     and drawn empty-handed first so the nav feels instant rather than stuck */
  if (key === "connections") { renderAppsPage(); Promise.all([loadSources(), loadSchool()]).then(renderAppsPage); }
  /* Same shape as Connections: drawn at once from what is saved, then redrawn
     when the site list and Chrome's own permission answer land. */
  if (key === "focus") { renderFocusPage(); loadFocus().then(renderFocusPage); }
  /* Downtime sits under Focus: both are "keep me off the distracting stuff". */
  if (key === "focus") { renderDowntimeCard(); loadDowntime().then(() => renderDowntimeCard()); }
  const host = $("#setpages");
  if (host) host.scrollTop = 0;
}
window.showSetPage = showSetPage;
window.SET_PAGE_NOW = () => SET_PAGE;
window.loadCourseRecords = loadCourseRecords;

document.addEventListener("click", (event) => {
  const hit = event.target.closest(".setnav button[data-setpage]");
  if (hit) showSetPage(hit.dataset.setpage);
});

/* Re-rendering a settings page on every tick resets its scroll, which reads as
   "this control is broken". Everything below re-renders one page in place, so
   the scroll is captured and put back around it. */
function keepScroll(fn) {
  const host = $("#setpages");
  const top = host ? host.scrollTop : 0;
  const focusId = document.activeElement && document.activeElement.id;
  const caret = document.activeElement && document.activeElement.selectionStart;
  fn();
  if (host) host.scrollTop = top;
  if (focusId) {
    const back = document.getElementById(focusId);
    if (back) {
      back.focus();
      if (caret != null && back.setSelectionRange) {
        try { back.setSelectionRange(caret, caret); } catch (err) { /* not a text input */ }
      }
    }
  }
}

/* ---------------- Settings -> Classes ----------------
   Per class: what it is called on the board, what colour it is, whether it is
   on the board at all, where its work is posted, his own notes, and every
   resource it points at. `COURSE_RECORDS` is the per-class record from
   /api/courses — materials, notes, textbook — which is a different thing from
   the profile (how the homework is READ) and from the grade. */
let COURSE_RECORDS = {};
let OPEN_CLASS_CARD = null;

async function loadCourseRecords() {
  try {
    const res = await fetch("/api/courses");
    const out = await res.json();
    COURSE_RECORDS = out.summaries || {};
    for (const rec of out.courses || []) COURSE_RECORDS[rec.course_key] = { ...COURSE_RECORDS[rec.course_key], ...rec };
  } catch (err) { /* the page still works without the records; it says so */ }
}

const MATERIAL_KINDS = [
  ["textbook", "Textbook"], ["syllabus", "Syllabus"], ["schedule_doc", "The teacher's homework doc"],
  ["tool", "A tool or site"], ["doc", "A document"], ["video", "Video"],
  ["canvas_page", "A Canvas page"], ["website", "A website"], ["other", "Something else"],
];

function renderClassesPage() {
  const host = $("#classes-page");
  if (!host || !STATE) return;
  const { shown, all, hiddenCount } = boardCourses();
  const ordered = sortCourses(all);
  const hidden = new Set(UI.hidden || []);
  const sortNow = UI.sort || "period";
  host.innerHTML = `<h3>Classes</h3>
    <p class="lede">One card per class. Tell SillyBus AI what to call it on the board,
      what colour it is, which period it meets, where the teacher actually puts the work,
      anything it should know, and every resource that class points at. Switch one off and
      it leaves the board and the tab strip — the board says how many are off, never just fewer.</p>
    <div class="setnote setline">
      <span>${shown.length} on the board${hiddenCount ? ` · ${hiddenCount} switched off` : ""} · ${all.length} in total</span>
      <span class="grow"></span>
      <span class="segrow" role="group" aria-label="how the classes are ordered">
        ${[["period", "By period"], ["name", "A\u2013Z"], ["custom", "My order"]].map(([v, t]) =>
          `<button type="button" class="segbtn ${sortNow === v ? "on" : ""}" data-sort="${v}" aria-pressed="${sortNow === v}"
            ${v === "custom" && !(UI.order || []).length ? `title="use the arrows on a card to make one"` : ""}>${t}</button>`).join("")}
      </span></div>
    <div class="clsgrid">
    ${ordered.map((c, n) => classCardHtml(c, n, ordered.length, hidden.has(c.key))).join("")}
    </div>
    <p class="muted" id="classes-note"></p>`;
}
window.renderClassesPage = renderClassesPage;
document.addEventListener("change", async (event) => {
  const sel = event.target.closest("select[data-period]");
  if (!sel) return;
  const key = sel.dataset.period;
  const periods = { ...(UI.periods || {}) };
  if (sel.value) periods[key] = Number(sel.value); else delete periods[key];
  const problem = await saveUiPrefs({ periods });
  renderStudio(); renderTabStrip();
  keepScroll(renderClassesPage);
  const note = $("#classes-note");
  if (note) { note.textContent = problem || (sel.value ? `${periodLabel(key)} \u2014 the board is in that order now` : "back to what the schedule says"); note.classList.toggle("bad", !!problem); }
});

function classCardHtml(c, index, total, isHidden) {
  const rec = COURSE_RECORDS[c.key] || {};
  const open = OPEN_CLASS_CARD === c.key;
  const mats = (rec.materials || []).filter((m) => !m.hidden);
  const colour = (UI.colors || {})[c.key] || "";
  const books = mats.filter((m) => m.kind === "textbook");
  return `<details class="clsedit ${isHidden ? "off" : ""}" ${open ? "open" : ""} data-cls-card="${esc(c.key)}">
    <summary>
      ${ringHtml(c, 24)}
      <b>${esc(c.name)}</b>
      <span class="clschipmini" style="${colour ? `--own:${esc(colour)}` : ""}">${esc(abbrOf(c.key, c.name))}</span>
      <span class="tag">${esc(periodLabel(c.key))}</span>
      ${books.length ? `<span class="tag">${books.length} textbook${books.length === 1 ? "" : "s"}</span>`
        : `<span class="tag">no textbook</span>`}
      <span class="tag">${mats.length} resource${mats.length === 1 ? "" : "s"}</span>
      <span class="grow"></span>
      ${c.teacher ? `<span class="tag">${esc(c.teacher)}</span>` : ""}
      <span class="onoff ${isHidden ? "" : "on"}" data-show="${esc(c.key)}" role="img"
        aria-label="${esc(isHidden ? c.name + " is off the board" : c.name + " is on the board")}"></span>
    </summary>
    <div class="clsbody">
      <div class="row2">
        <label class="field" for="name-${esc(c.key)}">What you call it
          <span class="fieldnote">${c.school_name ? "the school calls it " + esc(c.school_name) : "blank means the school's name"}</span>
          <input id="name-${esc(c.key)}" data-rename="${esc(c.key)}" maxlength="60"
            value="${esc((UI.names || {})[c.key] || "")}" placeholder="${esc(c.school_name || c.name)}"></label>
        <div class="field">Where the work is
          <span class="fieldnote">${esc(classProfileLine(c.key))}</span>
          <div class="row2" style="margin-top:4px">
            <input data-conn="canvas_url:${esc(c.key)}" type="url" placeholder="Canvas course address"
              value="${esc((rec.connectors || {}).canvas_url || rec.canvas_url || "")}" aria-label="Canvas course address">
            <input data-conn="doc_url:${esc(c.key)}" type="url" placeholder="Homework doc address (Google Docs)"
              value="${esc((rec.connectors || {}).doc_url || "")}" aria-label="homework doc address"></div>
          <div class="acts" style="margin-top:6px"><button type="button" class="ghost" data-conn-save="${esc(c.key)}">Save where the work is</button>
            <span class="muted">a doc address is read on the next refresh, Canvas or not</span></div></div>
      </div>
      <div class="row4">
        <label class="field" for="abbr-${esc(c.key)}">Short label (optional)
          <span class="fieldnote">Your choice, like AI or AR. Used in compact views; full class names stay on Assignments. Clear to use the automatic label.</span>
          <input id="abbr-${esc(c.key)}" data-abbr="${esc(c.key)}" maxlength="4"
            value="${esc(abbrOf(c.key, c.name))}" style="max-width:110px"></label>
        <label class="field" for="colour-${esc(c.key)}">Colour
          <span class="fieldnote">on the calendar and the week bars</span>
          <span class="colourrow">
            <input id="colour-${esc(c.key)}" type="color" data-colour="${esc(c.key)}"
              value="${esc(colour || hexOfClass(c.key))}">
            ${colour ? `<button type="button" class="mini-btn" data-colour-clear="${esc(c.key)}"
              >use the automatic one</button>` : `<span class="muted">automatic</span>`}</span></label>
        <label class="field" for="period-${esc(c.key)}">Period
          <span class="fieldnote">${(UI.periods || {})[c.key] ? "your word" : detectedPeriod(c.key) < 99 ? "read from the schedule" : "nothing in the schedule says"}</span>
          <select id="period-${esc(c.key)}" data-period="${esc(c.key)}">
            <option value="" ${(UI.periods || {})[c.key] ? "" : "selected"}>${detectedPeriod(c.key) < 99 ? "detected: period " + detectedPeriod(c.key) : "let the schedule decide"}</option>
            ${[1, 2, 3, 4, 5, 6, 7].map((n) => `<option value="${esc(String(n))}" ${(UI.periods || {})[c.key] === n ? "selected" : ""}>Period ${n}</option>`).join("")}
            <option value="8" ${(UI.periods || {})[c.key] === 8 ? "selected" : ""}>Period 8</option>
            <option value="9" ${(UI.periods || {})[c.key] === 9 ? "selected" : ""}>Meets every day \u2014 no period</option>
          </select></label>
        <label class="field" for="order-${esc(c.key)}">Where it sits
          <span class="fieldnote">${(UI.sort || "period") === "custom" ? "on the board and in the strip" : "arrows switch the order to yours"}</span>
          <span class="orderrow" id="order-${esc(c.key)}">
            <button type="button" class="mini-btn" data-move="up:${esc(c.key)}"
              ${index === 0 ? "disabled" : ""} aria-label="move ${esc(c.name)} earlier">↑</button>
            <button type="button" class="mini-btn" data-move="down:${esc(c.key)}"
              ${index === total - 1 ? "disabled" : ""} aria-label="move ${esc(c.name)} later">↓</button>
            <span class="muted">${index + 1} of ${total}</span></span></label>
      </div>

      <label class="field" for="notes-${esc(c.key)}">Anything it should know about this class
        <span class="fieldnote">the chat reads this, so say the things a teacher says out loud</span>
        <textarea id="notes-${esc(c.key)}" data-notes="${esc(c.key)}"
          placeholder="e.g. labs are due at the start of the period; he says test dates out loud a week ahead"
          >${esc(rec.notes || "")}</textarea></label>

      <div class="field">Resources
        <span class="fieldnote">the book, the syllabus, the homework doc, the tools. ✓ means you confirmed it. The class's every Canvas page is folded below — the course itself is assumed to have them.</span></div>
      <div class="reslist">${primaryMaterials(mats).length ? primaryMaterials(mats).map((m) => materialRowHtml(c.key, m)).join("")
        : `<div class="secempty">Nothing found yet for this class.</div>`}</div>
      ${secondaryMaterials(mats).length ? `<details class="hiddenres"><summary>${secondaryMaterials(mats).length} more link${secondaryMaterials(mats).length === 1 ? "" : "s"} (Canvas pages, videos, sites)</summary>
        <div class="reslist" style="margin-top:4px">${secondaryMaterials(mats).map((m) => materialRowHtml(c.key, m)).join("")}</div></details>` : ""}
      ${(rec.materials || []).some((m) => m.hidden)
        ? `<details class="hiddenres"><summary>${(rec.materials || []).filter((m) => m.hidden).length} hidden</summary>
            ${(rec.materials || []).filter((m) => m.hidden).map((m) =>
              `<div class="resrow"><span class="grow">${esc(m.title || m.url)}</span>
                <button type="button" class="mini-btn" data-res-show="${esc(c.key)}:${esc(m.id)}">put it back</button></div>`).join("")}
          </details>` : ""}

      <div class="row2" style="margin-top:10px">
        <label class="field" for="resname-${esc(c.key)}">Add a resource
          <input id="resname-${esc(c.key)}" data-resname="${esc(c.key)}"
            placeholder="what is it called?"></label>
        <label class="field" for="resurl-${esc(c.key)}">Link
          <input id="resurl-${esc(c.key)}" data-resurl="${esc(c.key)}" type="url"
            placeholder="https://… (optional)"></label>
      </div>
      <div class="row2">
        <label class="field" for="reskind-${esc(c.key)}">What kind
          <select id="reskind-${esc(c.key)}" data-reskind="${esc(c.key)}">${MATERIAL_KINDS.map(([v, t]) =>
            `<option value="${esc(v)}">${esc(t)}</option>`).join("")}</select></label>
        <div class="field"><span style="visibility:hidden">.</span>
          <button type="button" class="primary" data-addres="${esc(c.key)}">Add it</button></div>
      </div>

      <div class="field" style="margin-top:12px">Find the textbook
        <span class="fieldnote">searches Google Books, Open Library, the Internet Archive and OpenStax</span></div>
      <div class="row2">
        <label class="field" for="tb-${esc(c.key)}"><span style="visibility:hidden">q</span>
          <input id="tb-${esc(c.key)}" data-tbq="${esc(c.key)}"
            placeholder="title, author or ISBN"></label>
        <div class="field"><span style="visibility:hidden">.</span>
          <button type="button" class="ghost" data-tbfind="${esc(c.key)}">Search</button></div>
      </div>
      <div class="tbresults" id="tbres-${esc(c.key)}"></div>

      ${joinLineHtml(c)}
      <div class="clsfoot">
        <span class="muted">${esc(classProfileLine(c.key))}</span>
        <button type="button" class="mini-btn" data-open-class="${esc(c.key)}">open this class ›</button>
      </div>
    </div></details>`;
}

/* One class, one key — the join coursejoin.py made, shown where it can be
   undone. A class the grades page spells differently says so here ("also
   known as …, on the Veracross grades page"), with a button that keeps them
   apart if the join is wrong. A class that matched NOTHING and carries only a
   grade offers the merge by hand: a picker of the classes with work. */
function joinsFor(key) {
  return ((STATE && STATE.course_joins) || []).filter((j) => j.to === key);
}
function joinLineHtml(c) {
  const joins = joinsFor(c.key);
  const hasWork = ((STATE && STATE.profiles) || []).some((p) => p.course_key === c.key)
    || ((STATE && STATE.items) || []).some((i) => i.course_key === c.key && i.source !== "custom");
  if (joins.length) {
    return `<div class="joinline">${joins.map((j) => `<span>also known as
      <b>${esc(j.name)}</b> on the Veracross grades page${j.how === "merge" ? " \u2014 you said so" : ""}.
      <button type="button" class="mini-btn" data-unjoin="${esc(j.from)}"
        title="if these are two different classes">not the same class</button></span>`).join("")}</div>`;
  }
  if (!hasWork && c.graded) {
    const options = courseRecords().filter((k) => k.key !== c.key
      && (((STATE && STATE.profiles) || []).some((p) => p.course_key === k.key)));
    return `<div class="joinline"><span>This class has a grade but no work on the board \u2014
      the grades page may spell it differently from Canvas.</span>
      <label class="joinpick">Same class as
        <select data-merge-into="${esc(c.key)}"><option value="">\u2014 pick one \u2014</option>${
          options.map((k) => `<option value="${esc(k.key)}">${esc(k.name)}</option>`).join("")}</select></label></div>`;
  }
  return "";
}

/* The derived colour as a hex, so the colour input has something real to open
   on rather than black. classColor() returns hsl(), which <input type=color>
   will not take. */
function hexOfClass(key) {
  let h = 0;
  for (const ch of String(key || "")) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  const hue = h % 360, s = 0.55, l = 0.52;
  const f = (n) => {
    const k = (n + hue / 30) % 12;
    const a = s * Math.min(l, 1 - l);
    const v = l - a * Math.max(-1, Math.min(k - 3, Math.min(9 - k, 1)));
    return Math.round(v * 255).toString(16).padStart(2, "0");
  };
  return `#${f(0)}${f(8)}${f(4)}`;
}

/* The links that ARE the class — the book, the syllabus, the homework doc,
   the tools — first; every Canvas page it points at behind a fold. [ASKED]
   2026-09-18: "shouldn't have every canvas assignment for me to see, just
   the main page and I can assume it has everything else." */
const PRIMARY_KINDS = new Set(["textbook", "textbook_mention", "syllabus", "schedule_doc", "tool"]);
function primaryMaterials(mats) { return mats.filter((m) => PRIMARY_KINDS.has(m.kind)); }
function secondaryMaterials(mats) { return mats.filter((m) => !PRIMARY_KINDS.has(m.kind)); }

function materialRowHtml(key, m) {
  const label = m.title || m.text || m.url || "untitled";
  return `<div class="resrow">
    <span class="reskind">${esc((m.kind || "other").replace(/_/g, " "))}</span>
    ${m.url ? `<a class="grow trunc" href="${esc(hrefOf(m.url))}" target="_blank" rel="noopener"
        title="${esc(m.url)}">${esc(label)}</a>`
      : `<span class="grow trunc">${esc(label)}</span>`}
    <button type="button" class="mini-btn ${m.confirmed ? "on" : ""}"
      data-res-ok="${esc(key)}:${esc(m.id)}"
      title="${esc(m.confirmed ? "you confirmed this one" : "mark this as the right one")}"
      aria-pressed="${!!m.confirmed}">✓</button>
    <button type="button" class="mini-btn" data-res-hide="${esc(key)}:${esc(m.id)}"
      aria-label="hide ${esc(label)}">×</button></div>`;
}

/* What the board knows about how this class's homework is read — the honest
   version, including when it does not know. */
function classProfileLine(key) {
  const p = ((STATE && STATE.profiles) || []).find((x) => x.course_key === key);
  if (!p) return "no profile for this class yet";
  const where = { doc: "the teacher's document", canvas: "Canvas", both: "Canvas and the teacher's document",
                  none: "nowhere it can read" }[p.homework_source] || "not worked out yet";
  const how = p.learned_by === "model" ? "learned" : p.learned_by === "heuristic" ? "guessed at" : "not learned";
  return `homework read from ${where} · ${how}${
    typeof p.confidence === "number" ? ` · ${Math.round(p.confidence * 100)}% sure` : ""}`;
}

/* ---------------- Settings -> Classes: the controls ----------------
   Every write goes to the server and the page redraws in place with its scroll
   and focus kept, so a keystroke in a notes box does not throw him to the top. */
async function putCourse(key, patch) {
  try {
    const res = await fetch(`/api/courses/${encodeURIComponent(key)}`, { method: "PUT",
      headers: { "Content-Type": "application/json" }, body: JSON.stringify(patch) });
    const out = await res.json();
    if (res.ok) COURSE_RECORDS[key] = { ...COURSE_RECORDS[key], ...out };
    return res.ok ? "" : ((out.error || {}).message || "that did not save");
  } catch (err) { return "that did not save — the app may have restarted"; }
}
function classesNote(text, bad) {
  const n = $("#classes-note");
  if (!n) return;
  n.textContent = text || "";
  n.classList.toggle("bad", !!bad);
}
const debounced = {};
function debounce(id, fn, ms) {
  clearTimeout(debounced[id]);
  debounced[id] = setTimeout(fn, ms);
}

document.addEventListener("input", (event) => {
  const abbr = event.target.closest("input[data-abbr]");
  if (abbr) {
    const key = abbr.dataset.abbr;
    const code = abbr.value.replace(/[^A-Za-z0-9]/g, "").slice(0, 4);   // his casing
    debounce("abbr:" + key, async () => {
      const set = { ...(UI.abbr || {}) };
      if (code) set[key] = code; else delete set[key];
      const problem = await saveUiPrefs({ abbr: set });
      renderStudio(); renderTabStrip();
      classesNote(problem || (code ? `Short label saved: ${code}` : "Using the automatic short label"), !!problem);
      const chip = abbr.closest(".clsedit").querySelector(".clschipmini");
      if (chip) chip.textContent = abbrOf(key, (courseRecords().find((c) => c.key === key) || {}).name);
    }, 350);
    return;
  }
  const rename = event.target.closest("input[data-rename]");
  if (rename) {
    const key = rename.dataset.rename;
    debounce("rename:" + key, async () => {
      const names = { ...(UI.names || {}) };
      const value = rename.value.trim();
      if (value) names[key] = value; else delete names[key];
      const problem = await saveUiPrefs({ names });
      renderStudio(); renderTabStrip();
      classesNote(problem || (value ? `it is ${value} now, everywhere` : "back to the school's name"), !!problem);
    }, 450);
    return;
  }
  const notes = event.target.closest("textarea[data-notes]");
  if (notes) {
    const key = notes.dataset.notes;
    debounce("notes:" + key, async () => {
      const problem = await putCourse(key, { notes: notes.value });
      classesNote(problem || "notes saved", !!problem);
    }, 600);
    return;
  }
  const colour = event.target.closest("input[data-colour]");
  if (colour) {
    const key = colour.dataset.colour;
    debounce("colour:" + key, async () => {
      const problem = await saveUiPrefs({ colors: { ...(UI.colors || {}), [key]: colour.value } });
      renderStudio();
      keepScroll(renderClassesPage);
      classesNote(problem || "colour saved", !!problem);
    }, 250);
  }
});

document.addEventListener("click", async (event) => {
  const t = (sel) => event.target.closest(sel);
  let el;
  if ((el = t(".clsedit > summary .onoff[data-show]"))) {
    event.preventDefault();                       // the switch, not the disclosure
    const key = el.dataset.show;
    const hidden = new Set(UI.hidden || []);
    if (hidden.has(key)) hidden.delete(key); else hidden.add(key);
    const problem = await saveUiPrefs({ hidden: [...hidden] });
    const c = courseRecords().find((x) => x.key === key) || { nick: key };
    renderStudio(); renderTabStrip();
    keepScroll(renderClassesPage);
    /* after the redraw, not before it: renderClassesPage() rebuilds the note
       element, so a message written first is erased by the redraw meant to
       show it (the Main page guard had the same bug) */
    classesNote(problem || (hidden.has(key) ? `${c.nick} is off the board — still here, still counted`
                                            : `${c.nick} is back on the board`), !!problem);
    return;
  }
  if ((el = t("button[data-colour-clear]"))) {
    const set = { ...(UI.colors || {}) }; delete set[el.dataset.colourClear];
    await saveUiPrefs({ colors: set });
    renderStudio(); keepScroll(renderClassesPage);
    return;
  }
  if ((el = t("button[data-move]"))) {
    const [dir, key] = el.dataset.move.split(":");
    const { all } = boardCourses();
    const current = (UI.order && UI.order.length) ? UI.order.slice()
      : all.slice().sort((a, b) => coursePeriod(a.key) - coursePeriod(b.key) || a.nick.localeCompare(b.nick)).map((c) => c.key);
    for (const c of all) if (!current.includes(c.key)) current.push(c.key);
    const at = current.indexOf(key);
    const to = dir === "up" ? at - 1 : at + 1;
    if (at < 0 || to < 0 || to >= current.length) return;
    [current[at], current[to]] = [current[to], current[at]];
    /* Moving a class with the arrows is choosing "my order" — otherwise the
       move would save and nothing on the board would change. */
    const problem = await saveUiPrefs({ order: current, sort: "custom" });
    OPEN_CLASS_CARD = key;
    renderStudio(); renderTabStrip();
    keepScroll(renderClassesPage);
    /* the card moved under the pointer, which is easy to miss; say where it went */
    const c = courseRecords().find((x) => x.key === key) || { nick: key };
    classesNote(problem || `${c.nick} is now ${to + 1} of ${current.length}`, !!problem);
    return;
  }
  if ((el = t("button[data-res-ok]"))) {
    const [key, id] = el.dataset.resOk.split(":");
    const m = ((COURSE_RECORDS[key] || {}).materials || []).find((x) => x.id === id) || {};
    const problem = await putCourse(key, { materials: [{ id, confirmed: !m.confirmed }] });
    OPEN_CLASS_CARD = key; keepScroll(renderClassesPage);
    classesNote(problem || (m.confirmed ? "unconfirmed" : "confirmed — the chat can trust it now"), !!problem);
    return;
  }
  if ((el = t("button[data-res-hide]"))) {
    const [key, id] = el.dataset.resHide.split(":");
    try { await fetch(`/api/courses/${encodeURIComponent(key)}/materials/${encodeURIComponent(id)}`, { method: "DELETE" }); }
    catch (err) { /* said below */ }
    await loadCourseRecords();
    OPEN_CLASS_CARD = key; keepScroll(renderClassesPage);
    classesNote("hidden — it is under “hidden” if you want it back");
    return;
  }
  if ((el = t("button[data-res-show]"))) {
    const [key, id] = el.dataset.resShow.split(":");
    await putCourse(key, { materials: [{ id, hidden: false }] });
    OPEN_CLASS_CARD = key; keepScroll(renderClassesPage);
    return;
  }
  if ((el = t("button[data-addres]"))) {
    const key = el.dataset.addres;
    const name = ($(`#resname-${CSS.escape(key)}`) || {}).value || "";
    const url = ($(`#resurl-${CSS.escape(key)}`) || {}).value || "";
    const kind = ($(`#reskind-${CSS.escape(key)}`) || {}).value || "other";
    if (!name.trim() && !url.trim()) { classesNote("give it a name or a link", true); return; }
    try {
      const res = await fetch(`/api/courses/${encodeURIComponent(key)}/materials`, { method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: name.trim(), url: url.trim(), kind }) });
      const out = await res.json();
      if (!res.ok) { classesNote((out.error || {}).message || "that did not save", true); return; }
      COURSE_RECORDS[key] = { ...COURSE_RECORDS[key], ...out };
    } catch (err) { classesNote("that did not save — the app may have restarted", true); return; }
    OPEN_CLASS_CARD = key; keepScroll(renderClassesPage);
    classesNote("added");
    return;
  }
  if ((el = t("button[data-tbfind]"))) {
    const key = el.dataset.tbfind;
    const q = (($(`#tb-${CSS.escape(key)}`) || {}).value || "").trim();
    const out = $(`#tbres-${CSS.escape(key)}`);
    if (!q || !out) { classesNote("type a title, author or ISBN", true); return; }
    out.innerHTML = `<div class="muted">searching…</div>`;
    try {
      const res = await fetch(`/api/textbooks/search?q=${encodeURIComponent(q)}`);
      const data = await res.json();
      out.innerHTML = textbookResultsHtml(key, data);
    } catch (err) { out.innerHTML = `<div class="muted">the search did not answer</div>`; }
    return;
  }
  if ((el = t("button[data-tbadd]"))) {
    const [key, n] = el.dataset.tbadd.split(":");
    const book = (TB_LAST[key] || [])[Number(n)];
    if (!book) return;
    try {
      const res = await fetch(`/api/courses/${encodeURIComponent(key)}/materials`, { method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: book.title, url: book.free_url || book.preview_url || book.catalog_url || "",
                               kind: "textbook", isbn: book.isbn || "", notes: (book.authors || []).join(", ") }) });
      const out = await res.json();
      if (res.ok) { COURSE_RECORDS[key] = { ...COURSE_RECORDS[key], ...out }; classesNote(`${book.title} attached`); }
      else classesNote((out.error || {}).message || "that did not save", true);
    } catch (err) { classesNote("that did not save", true); }
    OPEN_CLASS_CARD = key; keepScroll(renderClassesPage);
    return;
  }
  if ((el = t("button[data-open-class]"))) { openTab(el.dataset.openClass); return; }
  if ((el = t("button[data-conn-save]"))) {
    const key = el.dataset.connSave;
    const get = (f) => (document.querySelector(`input[data-conn="${f}:${CSS.escape(key)}"]`) || {}).value || "";
    const problem = await putCourse(key, { connectors: { canvas_url: get("canvas_url").trim(), doc_url: get("doc_url").trim() } });
    OPEN_CLASS_CARD = key; keepScroll(renderClassesPage);
    classesNote(problem || "saved — the next refresh reads from there", !!problem);
    return;
  }
  if ((el = t("button[data-unjoin]"))) {
    const from = el.dataset.unjoin;
    const merge = { ...(UI.merge || {}) }; delete merge[from];
    const apart = [...new Set([...(UI.keep_apart || []), from])];
    const problem = await saveUiPrefs({ merge, keep_apart: apart });
    await loadState();                       // the join is applied on read
    await loadCourseRecords();
    keepScroll(renderClassesPage);
    classesNote(problem || "kept apart \u2014 they are two classes on the board now", !!problem);
    return;
  }
});
document.addEventListener("change", async (event) => {
  const pick = event.target.closest("select[data-merge-into]");
  if (!pick || !pick.value) return;
  const from = pick.dataset.mergeInto, to = pick.value;
  const apart = (UI.keep_apart || []).filter((k) => k !== from);
  const problem = await saveUiPrefs({ merge: { ...(UI.merge || {}), [from]: to }, keep_apart: apart });
  await loadState();
  await loadCourseRecords();
  keepScroll(renderClassesPage);
  classesNote(problem || "joined \u2014 one class on the board, with its grade", !!problem);
});

/* the last search per class, so "attach" can find the book it names */
const TB_LAST = {};
function textbookResultsHtml(key, data) {
  const list = (data && data.results) || [];
  TB_LAST[key] = list;
  if (!list.length) {
    return `<div class="muted">Nothing matched${data && data.unavailable ? " — " + esc(data.unavailable) : ""}.
      ${(data && data.search_links || []).map((l) => `<a href="${esc(hrefOf(l.url))}" target="_blank" rel="noopener">${esc(l.label || l.url)}</a>`).join(" · ")}</div>`;
  }
  return list.slice(0, 6).map((b, n) => `<div class="tbrow">
    ${b.cover ? `<img src="${esc(hrefOf(b.cover))}" alt="">` : `<span class="tbnocover"></span>`}
    <div class="grow"><span class="t">${esc(b.title)}${b.subtitle ? ": " + esc(b.subtitle) : ""}</span>
      <span class="a">${esc((b.authors || []).join(", "))}${b.year ? " · " + esc(b.year) : ""}${b.publisher ? " · " + esc(b.publisher) : ""}</span>
      <span class="a">${b.free_url ? (b.borrowable ? "borrowable online" : "free online")
        : b.preview_url ? "preview only" : "no free copy found — a catalogue entry"}</span></div>
    <button type="button" class="mini-btn" data-tbadd="${esc(key)}:${n}">attach</button></div>`).join("");
}

/* ---------------- Settings -> Textbooks ----------------
   Every attached book across every class, in one place. The per-class search
   is on the Classes page beside the class it is for. */
function renderTextbooksPage() {
  const host = $("#textbooks-page");
  if (!host) return;
  const rows = [];
  for (const c of courseRecords()) {
    const rec = COURSE_RECORDS[c.key] || {};
    for (const m of (rec.materials || [])) {
      if (m.hidden || m.kind !== "textbook") continue;
      rows.push({ c, m });
    }
  }
  host.innerHTML = `<h3>Textbooks</h3>
    <p class="lede">The book each class actually uses. Attach one from a class's card under
      Classes — search by title, author or ISBN — and it appears here and on that
      class's page with an <em>open online</em> button when a readable copy really exists.
      When there is no free copy the board says so rather than pretending.</p>
    ${rows.length ? rows.map(({ c, m }) => `<div class="card tbcard">
      <div class="tbrow"><div class="grow">
        <span class="t">${esc(m.title || m.url)}</span>
        <span class="a">${esc(c.name)}${m.notes ? " · " + esc(m.notes) : ""}${m.isbn ? " · ISBN " + esc(m.isbn) : ""}</span>
        <span class="a">${m.url ? `<a href="${esc(hrefOf(m.url))}" target="_blank" rel="noopener">open ${esc(m.confirmed ? "— confirmed" : "")}</a>`
          : "no link — named by the teacher but not found online"}</span></div>
        <button type="button" class="mini-btn" data-res-hide="${esc(c.key)}:${esc(m.id)}">remove</button></div></div>`).join("")
      : `<div class="secempty">No textbooks attached yet. Open a class under Classes and search for its book.</div>`}`;
}
window.renderTextbooksPage = renderTextbooksPage;

/* ---------------- Settings -> Appearance ----------------
   Everything here is a CSS custom property or a data-* attribute on <html>, so
   a change repaints without redrawing a single row. The page redraws itself
   only for the things that change its own controls (the "on" swatch), with
   scroll and focus kept. */
const ACCENTS_UI = ["#0f766e", "#2563eb", "#4f46e5", "#7c3aed", "#db2777", "#e11d48",
  "#ea580c", "#ca8a04", "#16a34a", "#0891b2", "#475569", "#b45309"];
/* Four that hold still, six that move — slowly. [ASKED] 2026-09-20: "remove
   everything after grid … put in good animated backgrounds. just subtle
   animations". */
const PATTERNS_UI = [["none", "None"], ["glow", "Glow"], ["dots", "Dots"], ["grid", "Grid"],
  ["aurora", "Aurora"], ["drift", "Drift"], ["waves", "Waves"], ["orbit", "Orbit"], ["tide", "Tide"], ["breathe", "Breathe"]];
const PATTERN_COLORS_UI = ["#0f766e", "#2563eb", "#7c3aed", "#db2777", "#dc2626", "#ea580c", "#ca8a04", "#16a34a", "#0891b2", "#475569", "#111827", "#ffffff"];
const FONTS_BODY_UI = [["Inter", "Inter"], ["Source Serif 4", "Source Serif"], ["Space Grotesk", "Space Grotesk"],
  ["Nunito", "Nunito"], ["JetBrains Mono", "JetBrains Mono"], ["system-ui", "System"]];
const FONTS_HEAD_UI = [["Fraunces", "Fraunces"], ["Plus Jakarta Sans", "Plus Jakarta"], ["DM Serif Display", "DM Serif"],
  ["Space Grotesk", "Space Grotesk"], ["Inter", "Inter"], ["Nunito", "Nunito"]];

function renderAppearancePage() {
  const host = $("#appearance-host");
  if (!host) return;
  const seg = (name, options, current) => `<div class="segrow" role="group" aria-label="${esc(name)}">${
    options.map(([v, t, why]) => `<button type="button" class="segbtn ${current === v ? "on" : ""}"
      data-pref="${esc(name)}" data-value="${esc(v)}" aria-pressed="${current === v}"
      ${why ? `title="${esc(why)}"` : ""}>${esc(t)}</button>`).join("")}</div>`;
  const bg = UI.background || {};
  const stripOff = new Set(UI.tabs_off || []);
  host.innerHTML = `<div class="setgrid">
    <div class="setcard"><h4>Theme</h4>
      ${seg("theme", [["system", "Follow the Mac"], ["light", "Light"], ["warm", "Warm"], ["dark", "Dark"]], UI.theme)}</div>
    <div class="setcard"><h4>Accent</h4>
      <p class="fieldnote">Runs through every ring, dot, button and the open tab.</p>
      <div class="swatches">${ACCENTS_UI.map((a) => `<button type="button" class="sw ${(UI.accent || "").toLowerCase() === a ? "on" : ""}"
        style="background:${esc(a)}" data-pref="accent" data-value="${esc(a)}" aria-label="${esc(a)}"></button>`).join("")}
        <label class="swpick" title="pick any colour"><input type="color" value="${esc(UI.accent || "#0f766e")}" data-pref-live="accent">
          <span>+</span></label></div></div>
    <div class="setcard"><h4>Background pattern</h4>
      <p class="fieldnote">The middle of the board sits straight on the background; the pattern is what keeps it from reading as empty. The last six move, slowly; "No animation" under Density &amp; motion freezes them.</p>
      <div class="patgrid">${PATTERNS_UI.map(([v, t]) => `<button type="button" class="pat ${UI.pattern === v ? "on" : ""}"
        data-pref="pattern" data-value="${esc(v)}"><span class="pv" data-pv="${esc(v)}"></span><span class="pn">${esc(t)}</span></button>`).join("")}</div>
      <div class="patcolor" role="group" aria-label="pattern colour">
        <button type="button" class="segbtn ${UI.pattern_color ? "" : "on"}" data-pref="pattern_color" data-value="" aria-pressed="${!UI.pattern_color}" title="the accent, dimmed">Match accent</button>
        ${PATTERN_COLORS_UI.map((c) => `<button type="button" class="sw ${(UI.pattern_color || "").toLowerCase() === c ? "on" : ""}"
          style="background:${esc(c)}" data-pref="pattern_color" data-value="${esc(c)}" aria-label="pattern colour ${esc(c)}"></button>`).join("")}
        <label class="swpick" title="any colour"><input type="color" value="${esc(UI.pattern_color || UI.accent || "#0f766e")}" data-pref-live="pattern_color"><span>+</span></label></div>
      ${seg("pattern_strength", [["subtle", "Subtle", "what it used to be"], ["normal", "Visible"], ["bold", "Bold", "a poster, not a texture"]], UI.pattern_strength)}</div>
    <div class="setcard wide"><h4>Your own background</h4>
      <p class="fieldnote">An image, a GIF or a short video. It is kept on this computer, never uploaded anywhere, and the pattern fades over it.</p>
      <div class="drop" id="bgdrop" tabindex="0" role="button" aria-label="drop a background file here, or press to choose one">
        <b>Drop an image, GIF or video here</b> or <button type="button" class="ghost" id="bgpick">choose a file</button>
        <input type="file" id="bgfile" accept="image/*,video/*" hidden>
        <div class="muted" id="bgnote" style="margin-top:6px">${bg.file ? `showing <code>${esc(bg.file)}</code>` : "nothing set — the pattern above is the background"}</div></div>
      ${bg.file ? `<div class="slider" style="margin-top:10px"><span>Dim</span>
          <input type="range" min="0" max="90" value="${esc(String(Math.round((typeof bg.opacity === "number" ? bg.opacity : 0.35) * 100)))}" data-pref-live="bgdim" aria-label="how much to dim the background">
          <b id="bgdim-out">${Math.round((typeof bg.opacity === "number" ? bg.opacity : 0.35) * 100)}%</b></div>
        <div class="acts"><button type="button" class="ghost" id="bgclear">Remove the background</button></div>` : ""}</div>
    <div class="setcard wide"><h4>Type</h4>
      <div class="row2">
        <label class="field">Headings<select data-pref="font_head">${FONTS_HEAD_UI.map(([v, t]) =>
          `<option value="${esc(v)}" ${UI.font_head === v ? "selected" : ""} style="font-family:'${esc(v)}'">${esc(t)}</option>`).join("")}</select></label>
        <label class="field">Everything else<select data-pref="font_body">${FONTS_BODY_UI.map(([v, t]) =>
          `<option value="${esc(v)}" ${UI.font_body === v ? "selected" : ""} style="font-family:'${esc(v)}'">${esc(t)}</option>`).join("")}</select></label></div>
      <div class="slider"><span>Text size</span>
        <input type="range" min="11" max="22" step="0.5" value="${esc(UI.text_size)}" data-pref-live="text_size" aria-label="text size">
        <b id="textsize-out">${esc(UI.text_size)}px</b></div>
      <p class="fieldnote">Below 11 the date sentences stop being readable; above 22 the twelve classes stop fitting and the board would have to hide work to make room — the one thing it may not do.</p>
      <div class="fontpreview"><b style="font-family:var(--font-display);font-size:1.4rem">${UI.greeting_name ? `Hello ${esc(UI.greeting_name)}` : "Hello"}</b>
        <span>26 open, about 5h of it before tomorrow ends — and one has a clock on it tonight.</span></div></div>
    <div class="setcard"><h4>Density &amp; motion</h4>
      ${seg("density", [["compact", "Compact", "twelve classes in a 995px window"], ["roomy", "Roomy", "for when the laptop is on a monitor"]], UI.density)}
      ${seg("motion", [["auto", "Follow the Mac", "prefers-reduced-motion is honoured"], ["off", "No animation"]], UI.motion)}</div>
    <div class="setcard"><h4>Changing tabs</h4>
      <p class="fieldnote">How a page comes in when you switch to it. Off if the Mac asks for reduced motion.</p>
      ${seg("transition", [["none", "Cut"], ["fade", "Fade"], ["slide", "Slide"], ["rise", "Rise"], ["zoom", "Zoom"]], UI.transition)}
      ${seg("transition_strength", [["subtle", "Subtle", "120 ms, barely there"], ["normal", "Normal", "220 ms"], ["strong", "Strong", "380 ms, and further"]], UI.transition_strength)}</div>
    <div class="setcard"><h4>Pages</h4>
      <p class="fieldnote">A class, Settings, Life, Calendar and Done can sit straight on the background, in a card, or on frosted glass — glass is for a photo background, where text on the photo is unreadable but a solid card would hide it.</p>
      ${seg("surface", [["open", "On the background"], ["cards", "In a card"], ["glass", "On glass"]], UI.surface)}</div>
    <div class="setcard"><h4>Status marks on assignments</h4>
      <p class="fieldnote">Every status a row has — the kind, overdue, study now, handed in, yours, AP, a guessed date — as small marks with the word on hover. Or the one kind-coloured dot.</p>
      ${seg("status_marks", [["symbols", "All the marks"], ["dot", "One dot"]], UI.status_marks)}</div>
    <div class="setcard"><h4>Ticking things off</h4>
      <p class="fieldnote">The tick that marks a row done. On hover keeps the column compact; a touch screen has no hover.</p>
      ${seg("ticks", [["hover", "Show on hover"], ["always", "Always show"]], UI.ticks)}</div>
    <div class="setcard"><h4>Tabs in the strip</h4>
      <p class="fieldnote">Home and Settings are always there. Each of these is still one key away when its tab is off (A, L, C, D).</p>
      <div class="checkrow">${[["work", "Assignments"], ["life", "Life"], ["calendar", "Calendar"], ["done", "Done"]].map(([v, t]) =>
        `<label class="appswitch"><input type="checkbox" data-strip-tab="${v}" ${stripOff.has(v) ? "" : "checked"}><span>${t}</span></label>`).join("")}</div></div>

    <div class="setcard"><h4>What the board says about grades</h4>
      <p class="fieldnote">Beside each class's name. A live percentage in the corner all day is not neutral for everyone; the ring is never affected — it is about how soon work is due.</p>
      ${seg("grade_display", [["percent", "84.6%"], ["letter", "B"], ["both", "B 84.6%"], ["none", "Nothing"]], UI.grade_display)}</div>
    <div class="setcard"><h4>Where a date came from</h4>
      <p class="fieldnote">Every assignment carries the sentence saying where its date came from. In the compact Assignments column the sentence costs about one item per class.</p>
      ${seg("date_notes", [["hover", "A marker on inferred dates, sentence on hover", "the class page and the open item always show it in full"], ["always", "The whole sentence, always"]], UI.date_notes)}</div>
    <div class="setcard"><h4>Time estimates</h4>
      <p class="fieldnote">The “~40m” beside work is a guess scaled by ×0.4 to match how fast you actually work. Some days a guess is noise.</p>
      ${seg("show_estimates", [["true", "Show them"], ["false", "Hide them"]], String(UI.show_estimates))}</div>
    <div class="setcard"><h4>The tab strip</h4>
      <p class="fieldnote">Twelve full names need about 2.4× the width of a 13″ window; short codes fit. “Measure” picks by what fits on the screen it is on.</p>
      ${seg("tab_labels", [["codes", "Short codes"], ["names", "Full names"], ["auto", "Measure and pick"]], UI.tab_labels)}</div>
    <div class="setcard"><h4>The screen</h4>
      <p class="fieldnote">Simple opens like a new chat, with Assignments, Grades, Calendar and Classes across the top. The board shows every column at once.</p>
      ${seg("look", [["simple", "Simple"], ["board", "The whole board"]], UI.look || "simple")}</div>
    <div class="setcard"><h4>What the greeting calls you</h4>
      <p class="fieldnote">Blank uses the first name from your school sign-in${STUDENT_NAME && !UI.greeting_name ? ` (${esc(STUDENT_NAME)})` : ""}.</p>
      <input id="greeting-name" maxlength="40" value="${esc(UI.greeting_name || "")}" placeholder="your first name" aria-label="what the greeting calls you"></div>
    <div class="setcard"><h4>About you</h4>
      <p class="fieldnote">Stays on this Mac. Your birthday only ever changes the greeting.</p>
      <label class="fieldnote">Birthday <input id="about-birthday" type="date" value="${esc(UI.birthday || "")}"></label>
      ${seg("grade_level", [["9", "9th"], ["10", "10th"], ["11", "11th"], ["12", "12th"], ["college", "College"], ["other", "Other"]], UI.grade_level || "")}</div>
    <div class="setcard"><h4>When the app opens</h4>
      ${seg("open_with", [["greeting", "The greeting"], ["last", "Where I left it"], ["chat", "Straight into chat"]], UI.open_with)}</div>
    <div class="setcard"><h4>Calendar</h4>
      ${seg("week_starts", [["monday", "Weeks start Monday"], ["sunday", "Weeks start Sunday"]], UI.week_starts)}
      ${seg("show_weekends", [["false", "Weekdays only"], ["true", "Show weekends"]], String(UI.show_weekends))}</div>
    <div class="setcard"><h4>Low-priority work</h4>
      <p class="fieldnote">Opt in only, and the board says how many it is hiding. Nothing is deleted.</p>
      ${seg("hide_low_priority", [["false", "Show everything"], ["true", "Fold away work scoring under " + esc(String((STATE && STATE.low_priority) || 20))]], String(UI.hide_low_priority))}</div>
    <div class="setcard wide"><h4>Keyboard</h4>
      <p class="fieldnote">Nothing here needs the mouse. Keys work anywhere you are not typing.</p>
      <div class="keys">${SHORTCUTS.map(([k, what]) => `<span><kbd>${esc(k)}</kbd> ${esc(what)}</span>`).join("")}</div></div>
    </div>
    <p class="muted" id="appearance-note"></p>`;
}
window.renderAppearancePage = renderAppearancePage;

function appearanceNote(text, bad) {
  const n = $("#appearance-note");
  if (n) { n.textContent = text || ""; n.classList.toggle("bad", !!bad); }
}
const BOOL_PREFS = new Set(["show_estimates", "show_weekends", "hide_low_priority"]);
async function setPref(name, raw) {
  const value = BOOL_PREFS.has(name) ? raw === "true" : name === "text_size" ? Number(raw) : raw;
  const problem = await saveUiPrefs({ [name]: value });
  appearanceNote(problem || "", !!problem);
  /* tabs_off and greeting_name are also set from the chat (applyChatActions),
     so the redraw they need lives here, in the one function both use. */
  if (["grade_display", "tab_labels", "date_notes", "show_estimates", "week_starts",
       "show_weekends", "hide_low_priority", "sort", "tabs_off", "greeting_name"].includes(name)) { renderStudio(); renderTabStrip(); }
  keepScroll(renderAppearancePage);
  return problem;
}
document.addEventListener("change", async (event) => {
  const name = event.target.closest("#greeting-name");
  if (!name) return;
  const problem = await saveUiPrefs({ greeting_name: name.value });
  appearanceNote(problem || (name.value.trim() ? `the board says hello to ${name.value.trim()}` : "the board just says hello"), !!problem);
  renderStudio();
  keepScroll(renderAppearancePage);
});
document.addEventListener("change", async (event) => {
  const day = event.target.closest("#about-birthday");
  if (!day) return;
  const problem = await saveUiPrefs({ birthday: day.value });
  appearanceNote(problem || (day.value ? "saved \u2014 it stays on this Mac" : "birthday cleared"), !!problem);
});
document.addEventListener("change", async (event) => {
  const box = event.target.closest("input[data-strip-tab]");
  if (!box) return;
  const off = new Set(UI.tabs_off || []);
  if (box.checked) off.delete(box.dataset.stripTab); else off.add(box.dataset.stripTab);
  const problem = await saveUiPrefs({ tabs_off: ["work", "life", "calendar", "done"].filter((t) => off.has(t)) });
  appearanceNote(problem || "", !!problem);
  renderTabStrip();
  keepScroll(renderAppearancePage);
});
document.addEventListener("click", (event) => {
  const b = event.target.closest("button[data-pref][data-value]");
  if (b) { setPref(b.dataset.pref, b.dataset.value); return; }
  if (event.target.closest("#bgpick")) { const f = $("#bgfile"); if (f) f.click(); return; }
  if (event.target.closest("#bgclear")) { clearBackground(); return; }
});
document.addEventListener("keydown", (event) => {
  if (event.target.id === "bgdrop" && (event.key === "Enter" || event.key === " ")) {
    event.preventDefault(); const f = $("#bgfile"); if (f) f.click();
  }
});
document.addEventListener("change", (event) => {
  const sel = event.target.closest("select[data-pref]");
  if (sel) { setPref(sel.dataset.pref, sel.value); return; }
  if (event.target.id === "bgfile" && event.target.files && event.target.files[0]) {
    uploadBackground(event.target.files[0]);
  }
});
document.addEventListener("input", (event) => {
  /* input[…], not bare [data-…]: tests/test_studio_board.py's scope rule. It
     had been hidden from that test by `accept="image/*,video/*"` above, which
     its comment-stripper read as the start of a comment (found 2026-10-07). */
  const live = event.target.closest("input[data-pref-live]");
  if (!live) return;
  const name = live.dataset.prefLive;
  if (name === "text_size") {
    document.documentElement.style.setProperty("--text-size", live.value + "px");
    const out = $("#textsize-out"); if (out) out.textContent = live.value + "px";
    debounce("pref:text_size", () => setPref("text_size", live.value), 300);
  } else if (name === "accent") {
    document.documentElement.style.setProperty("--accent", live.value);
    debounce("pref:accent", () => setPref("accent", live.value), 300);
  } else if (name === "bgdim") {
    const out = $("#bgdim-out"); if (out) out.textContent = live.value + "%";
    UI.background = { ...(UI.background || {}), opacity: Number(live.value) / 100 };
    paintBackground();
    debounce("pref:bgdim", () => saveUiPrefs({ background: { opacity: Number(live.value) / 100 } }), 300);
  }
});

/* Drag-and-drop for the background. Scoped to the drop zone: a file dropped
   anywhere else on the page does what the browser does with it. */
for (const type of ["dragenter", "dragover"]) {
  document.addEventListener(type, (event) => {
    const zone = event.target.closest("#bgdrop");
    if (!zone) return;
    event.preventDefault(); zone.classList.add("hot");
  });
}
document.addEventListener("dragleave", (event) => {
  const zone = event.target.closest("#bgdrop");
  if (zone) zone.classList.remove("hot");
});
document.addEventListener("drop", (event) => {
  const zone = event.target.closest("#bgdrop");
  if (!zone) return;
  event.preventDefault(); zone.classList.remove("hot");
  const file = event.dataTransfer && event.dataTransfer.files && event.dataTransfer.files[0];
  if (file) uploadBackground(file);
});
async function uploadBackground(file) {
  const note = $("#bgnote");
  if (note) note.textContent = `sending ${file.name}…`;
  try {
    const res = await fetch("/api/prefs/background", { method: "POST",
      headers: { "Content-Type": file.type || "application/octet-stream" }, body: file });
    const out = await res.json();
    if (!res.ok) { appearanceNote((out.error || {}).message + (out.error && out.error.fix ? " — " + out.error.fix : ""), true); if (note) note.textContent = "not set"; return; }
    UI = { ...UI, ...out.prefs };
    applyUiPrefs();
    appearanceNote(`${file.name} is the background now`);
  } catch (err) { appearanceNote("the file did not send — the app may have restarted", true); }
  keepScroll(renderAppearancePage);
}
async function clearBackground() {
  try {
    const res = await fetch("/api/prefs/background", { method: "DELETE" });
    const out = await res.json();
    if (res.ok) { UI = { ...UI, ...out.prefs }; applyUiPrefs(); appearanceNote("background removed"); }
  } catch (err) { appearanceNote("that did not save", true); }
  keepScroll(renderAppearancePage);
}

/* ==========================================================================
   The tour
   [ASKED] 2026-09-20: "make it do a tour each time on setup". Plays once,
   the first time the board opens with data after setup; Settings -> Main
   page runs it again. Each step lights one real part of the board (a hole
   in a dimmed sheet, positioned from the element's own rectangle, re-measured
   on resize) and says what it is in two sentences. Esc or Skip leaves; the
   preference is written when it ends either way, so it never nags.
   ========================================================================== */
const DASH_TOUR_STEPS = [
  { at: ".topbar", title: "The top bar", text: "Quick links to the sites your work actually lives on \u2014 earned, never invented: a site appears only when your data links to it. Anything that needs you (a sign-in, a stale board) shows here as a red mark; click it to fix it." },
  { at: "#tab-bar", title: "The strip", text: "One tab per class, plus Assignments, Life, Calendar, Done and Settings. Arrow keys and [ ] step through them; 1\u20139 jump to a class; H goes home." },
  { at: "#sec-classes", title: "Your classes", text: "Each chip is a class: the ring is how soon its next thing is due, the letter and percent are the grade. Click a chip for the class page \u2014 grade breakdown, what's open, links, notes." },
  { at: "#col-right", title: "Assignments", text: "Everything open, by class. The marks say what each row is (HW, T, Q, PS\u2026) and what's wrong with it (! overdue). Hover a row and tick it done; a tick is undoable from Done." },
  { at: "#home-body", title: "Home", text: "The four things to do first, chosen by due date, size and kind. The date marker on a row says where its date came from \u2014 nothing on this board is guessed silently." },
  { at: "#chat-dock", title: "Ask", text: "Press Space and type. On a class page the question is about that class; on an open assignment it's about that assignment. \"Add chem quiz Friday\" adds it. \"Teacher said\u2026\" is the fastest way in." },
  { at: '#tab-bar .tb[data-tab="settings"]', title: "Make it yours", text: "Settings: rename classes, set short codes, colours and periods, pick the pattern and its colour, choose what each part of the page shows. Press ? anywhere for the keys." },
];
const SIMPLE_TOUR_STEPS = [
  {at:"#home-body", title:"Your school day, at a glance", text:"This is home. The greeting shows what is due soon, and Start here below chat picks two real things to work on. Tap an assignment to see its details."},
  {at:"#tab-bar", title:"Find what you need", text:"Assignments shows all your work. Grades shows your marks. Calendar shows your schedule, and Classes groups work by class. These buttons always stay at the top."},
  {at:"#chat-dock", title:"Ask a question", text:"Try ‘what’s due tomorrow?’ or ‘help me plan tonight’. Teacher said… lets you record homework mentioned in class. You can also ask chat to remember a preference."},
  {at:"#home-chats", title:"Come back to a conversation", text:"Previous chats lets you continue where you left off. New chat starts fresh. Memory shows preferences you asked to save, with a Forget button for each."},
  {at:'#tab-bar .tb[data-tab="settings"]', title:"Connect and make it yours", text:"Open Settings → Connections to link your school and calendars. Settings → Appearance changes the look. Press Refresh after connecting to load your work."},
];
let TOUR_STEPS = DASH_TOUR_STEPS;
let TOUR = null;
function startTour(fromSettings) {
  TOUR_STEPS = simpleLook() ? SIMPLE_TOUR_STEPS : DASH_TOUR_STEPS;
  endTour(false);
  if (fromSettings) openTab("home");
  TOUR = { i: 0, fromSettings: !!fromSettings, returnFocus: document.activeElement };
  const sheet = document.createElement("div");
  sheet.id = "tour"; sheet.innerHTML = `<div class="tour-hole"></div><div class="tour-card" role="dialog" aria-modal="true" aria-labelledby="tour-title" aria-describedby="tour-text" aria-live="polite">
    <div class="tour-kick"></div><h3 id="tour-title"></h3><p id="tour-text"></p>
    <div class="tour-acts"><span class="tour-dots"></span><span class="grow"></span>
      <button type="button" class="ghost" data-tour="skip">Skip</button>
      <button type="button" class="ghost" data-tour="back">\u2039 Back</button>
      <button type="button" class="primary" data-tour="next">Next \u203a</button></div></div>`;
  document.body.appendChild(sheet);
  sheet.addEventListener("click", (e) => {
    const b = e.target.closest("button[data-tour]");
    if (!b) return;
    if (b.dataset.tour === "skip") endTour(true);
    else if (b.dataset.tour === "back") { TOUR.i = Math.max(0, TOUR.i - 1); showTourStep(); }
    else if (TOUR.i >= TOUR_STEPS.length - 1) endTour(true); else { TOUR.i += 1; showTourStep(); }
  });
  window.addEventListener("resize", placeTour);
  showTourStep();
  sheet.querySelector('[data-tour="next"]').focus();
}
function showTourStep() {
  if (!TOUR) return;
  const step = TOUR_STEPS[TOUR.i];
  const sheet = $("#tour");
  sheet.querySelector(".tour-kick").textContent = `${TOUR.i + 1} of ${TOUR_STEPS.length}`;
  sheet.querySelector("h3").textContent = step.title;
  sheet.querySelector("p").textContent = step.text;
  sheet.querySelector(".tour-dots").innerHTML = TOUR_STEPS.map((_, n) => `<i class="${n === TOUR.i ? "on" : ""}"></i>`).join("");
  sheet.querySelector('[data-tour="back"]').disabled = TOUR.i === 0;
  sheet.querySelector('[data-tour="next"]').textContent = TOUR.i >= TOUR_STEPS.length - 1 ? "Done \u2713" : "Next \u203a";
  placeTour();
}
function placeTour() {
  if (!TOUR) return;
  const step = TOUR_STEPS[TOUR.i];
  const target = document.querySelector(step.at);
  const hole = $("#tour .tour-hole"), card = $("#tour .tour-card");
  if (!target || !hole) return;
  const r = target.getBoundingClientRect();
  const pad = 6;
  Object.assign(hole.style, { left: `${r.left - pad}px`, top: `${r.top - pad}px`, width: `${r.width + pad * 2}px`, height: `${r.height + pad * 2}px` });
  /* the card goes below the hole when there is room, else above, else beside */
  const cw = Math.min(360, innerWidth - 32), ch = card.offsetHeight || 170;
  let left = Math.min(Math.max(16, r.left), innerWidth - cw - 16);
  let top = r.bottom + pad + 12;
  if (top + ch > innerHeight - 12) top = r.top - pad - 12 - ch;
  if (top < 12) { top = Math.max(12, Math.min(innerHeight - ch - 12, r.top)); left = r.right + pad + 12 <= innerWidth - cw - 16 ? r.right + pad + 12 : Math.max(16, r.left - cw - 12); }
  Object.assign(card.style, { left: `${left}px`, top: `${top}px`, width: `${cw}px` });
}
async function endTour(remember) {
  const sheet = $("#tour");
  if (sheet) sheet.remove();
  window.removeEventListener("resize", placeTour);
  const was = TOUR; TOUR = null;
  if (was) {
    const focus = was.returnFocus && was.returnFocus.isConnected ? was.returnFocus : document.querySelector("button[data-start-tour]");
    if (focus) focus.focus();
  }
  if (remember && was && !UI.tour_seen) await saveUiPrefs({ tour_seen: true });
}
/* Once, the first time the board has data after setup. Waits for the state
   so the holes have something to point at. */
function maybeStartTour() {
  if (REMOTE || UI.tour_seen || TOUR) return;
  if (!STATE || STATE.empty || !(STATE.items || []).length) { setTimeout(maybeStartTour, 1500); return; }
  // Not while the sign-in screen is up. [ASKED] 2026-10-07: "It gave me the
  // tutorial before I was in" — signing in through recovery loads the board
  // while the gate stays open to show the new code, and the tour started
  // over it. It waits until he is really in.
  const gate = $("#gate");
  if (gate && !gate.hidden) { setTimeout(maybeStartTour, 1500); return; }
  if (PANE !== "home") return;
  startTour(false);
}
window.startTour = startTour;
window.maybeStartTour = maybeStartTour;
document.addEventListener("keydown", (ev) => {
  if (!TOUR) return;
  if (ev.key === "Escape") { ev.preventDefault(); endTour(true); }
  else if (ev.key === "Tab") {
    const buttons = Array.from(document.querySelectorAll("#tour button:not(:disabled)"));
    const at = buttons.indexOf(document.activeElement);
    ev.preventDefault(); buttons[(at + (ev.shiftKey ? -1 : 1) + buttons.length) % buttons.length].focus();
  }
  else if (ev.key === "ArrowRight" || (ev.key === "Enter" && !ev.target.closest("#tour button"))) { ev.preventDefault(); $('#tour [data-tour="next"]').click(); }
  else if (ev.key === "ArrowLeft") { ev.preventDefault(); $('#tour [data-tour="back"]').click(); }
}, true);
document.addEventListener("click", (e) => { if (e.target.closest("button[data-start-tour]")) startTour(true); });

/* ==========================================================================
   Keys, arrows and the sideways scroll
   [ASKED] 2026-09-18: "you should be able to scroll sideways between classes
   and use arrows. there should be shortcuts. space should make you start
   typing in the context of whatever is open or just in a generic chat if
   you're on the home page."
   ========================================================================== */
const SHORTCUTS = [
  ["Space", "type to the chat \u2014 about the class or item that is open, or in general from Home"],
  ["\u2190 \u2192", "previous / next tab (also [ and ], also a sideways scroll)"],
  ["1\u20139", "the nth class"],
  ["H", "Home"], ["A", "Assignments"], ["L", "Life"], ["C", "Calendar"], ["D", "Done"], ["S", "Settings"],
  ["R", "refresh"], ["Esc", "back to Home, or out of a text box"], ["?", "this list"],
];
function focusChat() {
  const input = $("#chat-input");
  if (!input) return;
  /* On Home the question is general; a class page or an open item has
     already set the context, and it is left exactly as it is. */
  if (PANE === "home" && CHAT_CONTEXT && !CHAT_CONTEXT.sticky) setChatContext(null);
  input.focus();
}
function toggleKeysHelp() {
  let box = $("#keyshelp");
  if (box) { box.remove(); return; }
  box = document.createElement("div");
  box.id = "keyshelp"; box.className = "keyshelp"; box.setAttribute("role", "dialog"); box.setAttribute("aria-label", "keyboard shortcuts");
  box.innerHTML = `<b>Keys</b><div class="keys">${SHORTCUTS.map(([k, what]) => `<span><kbd>${esc(k)}</kbd> ${esc(what)}</span>`).join("")}</div>
    <div class="muted">press ? or Esc to close</div>`;
  document.body.appendChild(box);
}
document.addEventListener("keydown", (ev) => {
  const t = ev.target || {};
  const typing = ["INPUT", "TEXTAREA", "SELECT"].includes(t.tagName) || t.isContentEditable;
  if (ev.key === "Escape" && $("#keyshelp")) { $("#keyshelp").remove(); return; }
  if (typing || ev.metaKey || ev.ctrlKey || ev.altKey || REMOTE) return;
  /* Space on a focused button is that button's click; only a space with
     nothing in particular focused is a request to type. */
  if (ev.key === " " && !["BUTTON", "A", "SUMMARY"].includes(t.tagName)) { ev.preventDefault(); focusChat(); return; }
  if (ev.key === "ArrowLeft") { stepTab(-1); return; }
  if (ev.key === "ArrowRight") { stepTab(1); return; }
  if (ev.key === "?") { toggleKeysHelp(); return; }
  if (/^[1-9]$/.test(ev.key)) {
    const { shown } = boardCourses();
    const c = shown[Number(ev.key) - 1];
    if (c) openTab(c.key);
    return;
  }
  const page = { h: "home", a: "work", l: "life", c: "calendar", d: "done", s: "settings" }[ev.key.toLowerCase()];
  if (page && !ev.shiftKey) openTab(page);
});
/* A sideways wheel (two fingers on the trackpad) on a full page steps to the
   next or previous tab. Debounced to one step per gesture, and only when the
   page itself does not scroll sideways, so a wide table keeps its own scroll. */
let WHEEL_AT = 0;
document.addEventListener("wheel", (ev) => {
  if (!document.body.classList.contains("fullpage")) return;
  if (Math.abs(ev.deltaX) < 24 || Math.abs(ev.deltaX) < Math.abs(ev.deltaY) * 1.5) return;
  const scroller = ev.target.closest && ev.target.closest(".gd-table, table, pre, .reslist");
  if (scroller && scroller.scrollWidth > scroller.clientWidth) return;
  const now = Date.now();
  if (now - WHEEL_AT < 700) return;
  WHEEL_AT = now;
  stepTab(ev.deltaX > 0 ? 1 : -1);
}, { passive: true });
window.stepTab = stepTab;
window.focusChat = focusChat;

/* ==========================================================================
   The Assignments page
   [ASKED] 2026-09-20: "an Assignments page with an add button". Every open
   school item, full width: by class in the board's order or by due date, a
   search box, the tick, the marks, and the add button — which opens the same
   form Life uses, filed as school work.
   ========================================================================== */
let WORK_SORT = "class";
let WORK_FILTER = "";
function renderWorkPage() {
  const host = $("#work-body");
  if (!host || !STATE) return;
  const today = todayIso();
  const needle = WORK_FILTER.trim().toLowerCase();
  const all = openItems();
  const items = needle ? all.filter((i) => `${i.title} ${i.course || ""} ${nick(i.course_key || "")}`.toLowerCase().includes(needle)) : all;
  const { shown, all: courses } = boardCourses();
  const byKey = new Map(courses.map((c) => [c.key, c]));
  const row = (i) => `<div class="workrow">
    <button type="button" class="astick" style="position:static;opacity:1;pointer-events:auto;flex:none;margin-top:3px" data-tick="${esc(i.item_id)}" aria-label="mark ${esc(i.title)} done" title="mark done"></button>
    <button type="button" class="grow" data-open="${esc(i.item_id)}">
      <span class="t">${esc(i.title)}</span>
      <span class="m">${statusMarksHtml(i, today)}<span>${esc((byKey.get(i.course_key) || {}).name || i.course || "")}</span>
        <span class="${esc(urgencyWord(i.due_date, today, i))}">${esc(i.due_date ? relDays(i.due_date, today) + " \u00b7 " + niceDate(i.due_date) : "no date")}</span>
        ${UI.show_estimates && i.est_minutes ? `<span>${esc(minutesLabel(i.est_minutes))}</span>` : ""}
        ${i.date_note ? `<span class="dn">${esc(i.date_note)}</span>` : ""}</span></button></div>`;
  let groups = "";
  if (WORK_SORT === "due") {
    const buckets = [["Overdue", (i) => i.due_date && i.due_date < today], ["Today", (i) => i.due_date === today],
      ["Tomorrow", (i) => i.due_date === isoPlus(today, 1)], ["This week", (i) => i.due_date && i.due_date <= isoPlus(today, 7)],
      ["Later", (i) => !!i.due_date], ["No date", () => true]];
    const left = items.slice();
    groups = buckets.map(([label, test]) => {
      const take = left.filter(test); for (const t of take) left.splice(left.indexOf(t), 1);
      return take.length ? `<div class="workgroup"><div class="sech">${label} \u00b7 ${take.length}</div>${take.map(row).join("")}</div>` : "";
    }).join("");
  } else {
    const order = shown.map((c) => c.key).concat(courses.filter((c) => !shown.includes(c)).map((c) => c.key));
    const keys = [...new Set(items.map((i) => i.course_key))].sort((a, b) => (order.indexOf(a) === -1 ? 999 : order.indexOf(a)) - (order.indexOf(b) === -1 ? 999 : order.indexOf(b)));
    groups = keys.map((k) => { const c = byKey.get(k); const list = items.filter((i) => i.course_key === k);
      return `<div class="workgroup"><div class="sech">${c ? classControl(k, esc(c.name), "work-class-name", c.name) : esc(list[0].course || "Other")} \u00b7 ${list.length}</div>${list.map(row).join("")}</div>`; }).join("");
  }
  const seg = (v, t) => `<button type="button" class="segbtn ${WORK_SORT === v ? "on" : ""}" data-work-sort="${v}" aria-pressed="${WORK_SORT === v}">${t}</button>`;
  host.innerHTML = `<div class="workpage">
    <div class="kick">Everything open</div>
    <div class="workhead"><h2>Assignments \u00b7 ${all.length}</h2>
      <span class="segrow" role="group" aria-label="order">${seg("class", "By class")}${seg("due", "By due date")}</span>
      <input type="search" id="work-filter" value="${esc(WORK_FILTER)}" placeholder="find\u2026" aria-label="find an assignment">
      <button type="button" class="primary" data-add="">\uFF0B Add an assignment</button></div>
    ${groups || `<div class="secempty">${needle ? "Nothing matches." : "Nothing open in any class. \u2705"}</div>`}
    ${needle && all.length !== items.length ? `<p class="muted">${all.length - items.length} not matching \u201c${esc(needle)}\u201d</p>` : ""}
  </div>`;
}
window.renderWorkPage = renderWorkPage;
document.addEventListener("click", (event) => {
  const b = event.target.closest("button[data-work-sort]");
  if (b) { WORK_SORT = b.dataset.workSort; renderWorkPage(); }
});
document.addEventListener("input", (event) => {
  if (event.target.id !== "work-filter") return;
  WORK_FILTER = event.target.value;
  const at = event.target.selectionStart;
  renderWorkPage();
  const again = $("#work-filter"); if (again) { again.focus(); again.setSelectionRange(at, at); }
});

/* ==========================================================================
   The Done page
   [ASKED] 2026-09-18: "a complete tab to see already complete things".
   Handed in on Canvas, or ticked here; grouped by class in the board's own
   order, newest first. Nothing is deleted — the tick puts one back.
   ========================================================================== */
let DONE_SPAN = "month";
function renderDonePage() {
  const host = $("#done-body");
  if (!host || !STATE) return;
  const today = todayIso();
  const since = DONE_SPAN === "week" ? isoPlus(today, -7) : DONE_SPAN === "month" ? isoPlus(today, -31) : "0000";
  const all = (STATE.items || []).filter((i) => i.done && !personalSection(i));
  const list = all.filter((i) => !i.due_date || i.due_date >= since)
    .sort((a, b) => (b.due_date || "") < (a.due_date || "") ? -1 : 1);
  const { shown, all: courses } = boardCourses();
  const byKey = new Map(shown.map((c) => [c.key, c]));
  for (const c of courses) if (!byKey.has(c.key)) byKey.set(c.key, c);
  const groups = new Map();
  for (const i of list) {
    const k = byKey.has(i.course_key) ? i.course_key : "_other";
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push(i);
  }
  const row = (i) => `<div class="workrow done">
    <button type="button" class="tick2 on" data-tick="${esc(i.item_id)}" data-undo="1"
      aria-label="put ${esc(i.title)} back on the board" title="put it back">\u2713</button>
    <button type="button" class="grow" data-open="${esc(i.item_id)}">
      <span class="t struck">${esc(i.title)}</span>
      <span class="m"><span>${esc(KIND_WORD[i.category] || "homework")}</span>
        <span>${esc(i.due_date ? "was due " + niceDate(i.due_date) : "no date")}</span>
        <span>${i.submitted ? "handed in on Canvas" : "ticked off here"}</span></span></button></div>`;
  const spanBtn = (v, t) => `<button type="button" class="segbtn ${DONE_SPAN === v ? "on" : ""}" data-done-span="${v}" aria-pressed="${DONE_SPAN === v}">${t}</button>`;
  host.innerHTML = `<div class="page">
    <div class="kick">Finished</div>
    <div class="setline"><h2>Done \u00b7 ${list.length}</h2><span class="grow"></span>
      <span class="segrow" role="group" aria-label="how far back">${spanBtn("week", "This week")}${spanBtn("month", "This month")}${spanBtn("all", "Everything")}</span></div>
    <p class="muted">Handed in on Canvas, or ticked off here. Nothing is deleted \u2014 the tick puts one back on the board.${
      all.length !== list.length ? ` ${all.length - list.length} older not shown.` : ""}</p>
    ${[...groups.entries()].map(([k, items]) => {
      const c = byKey.get(k);
      return `<div class="sech">${esc(c ? c.name : "Other")} \u00b7 ${items.length}</div>${items.map(row).join("")}`;
    }).join("") || `<div class="secempty">Nothing finished ${DONE_SPAN === "all" ? "yet" : "in that time"}. Tick something off, or hand it in on Canvas and it lands here.</div>`}
  </div>`;
}
window.renderDonePage = renderDonePage;
document.addEventListener("click", (event) => {
  const b = event.target.closest("button[data-done-span]");
  if (b) { DONE_SPAN = b.dataset.doneSpan; renderDonePage(); }
});

/* ==========================================================================
   Settings -> Connections: every app, as a switch
   ==========================================================================

   "in the resource settings you should be able to set up all the apps, select
   which ones you want, put in login credentials, add shortcuts, etc."

   Three honest shapes, and the page says which each app is:
     · READ by the app — a source the pipeline has, with an on/off switch and
       its live status. Sign-in details belong to two of these only (Canvas via
       Google, Veracross), in the sign-ins card below, because those are the
       two the app can actually sign in to (autologin.py). A password box for a
       site the app cannot use it on would be a password box for nothing.
     · READ in your Chrome — AP Classroom and Albert.io: you sign in there
       yourself, the extension reads only assignment metadata on the page.
     · A CALENDAR ADDRESS you paste — Google Calendar, TeamSnap, Schoology,
       PowerSchool, Blackbaud, Canvas's own feed, anything iCal.
   Anything that is none of those — Khan Academy, Quizlet — is a SHORTCUT: a
   link in the top bar that he adds himself, marked as his. */
let SOURCES = [];
let SCHOOL = {};
async function loadSchool() {
  try { SCHOOL = await (await fetch("/api/school")).json(); } catch (err) { SCHOOL = {}; }
}
/* A <select> of every IANA time zone this browser knows, `selected` chosen —
   or a plain box where the list is not available. Shared by Settings and the
   setup page's "Your school" step (prosecution round 5, 2026-10-07: the zone
   was fixed to Phoenix, and nothing anywhere could change it). */
function timeZoneSelect(id, selected, attrs) {
  let zones = [];
  try { zones = Intl.supportedValuesOf("timeZone"); } catch (err) { zones = []; }
  if (selected && !zones.includes(selected)) zones = [selected, ...zones];
  if (!zones.length) return `<input id="${esc(id)}" ${attrs || ""} value="${esc(selected || "")}" placeholder="America/New_York">`;
  return `<select id="${esc(id)}" ${attrs || ""}>${zones.map((z) =>
    `<option value="${esc(z)}"${z === selected ? " selected" : ""}>${esc(z.replace(/_/g, " "))}</option>`).join("")}</select>`;
}
async function loadSources() {
  try {
    const res = await fetch("/api/sources");
    const out = await res.json();
    SOURCES = out.sources || [];
  } catch (err) { SOURCES = []; }
}

/* What else could be connected, with the truth about each as of the research
   on 2026-09-18. "free to test" means a person can make an account and try it
   without a school or a card; it is what decides which the next session can
   actually verify. */
/* Named rather than an object literal inside the template: a dollar-brace
   followed by an object literal's own brace is legal JavaScript and is also
   the two characters the snapshot test reads as an unresolved Jinja tag,
   because app.js is inlined into the published page — and that goes for a
   comment quoting it as well. */
const HOW_WORDS = { shortcut: "shortcut", calendar: "paste a calendar address",
                    api: "an API — not built", none: "nothing to read" };
const MORE_APPS = [
  { name: "Khan Academy", how: "shortcut", free: true,
    note: "No public API since 2020, and its terms forbid scraping tools and bots. Linking to it is allowed, so it is a shortcut here — and any Khan link a teacher puts in a doc already shows on that assignment.", url: "https://www.khanacademy.org/" },
  { name: "Google Classroom", how: "Chrome extension", free: true,
    note: "Open Classwork in Chrome and use SillyBus → Link this page. Visible coursework is imported as assignments; it does not read grades or claim every class was scanned." },
  { name: "Schoology", how: "calendar", free: true,
    note: "Account Settings -> Share Your Schoology Calendar gives an iCal address (once the calendar has at least one entry). Paste it above." },
  { name: "PowerSchool", how: "calendar", free: false,
    note: "Class Assignments -> Subscribe gives an iCal address. Needs a school account to test." },
  { name: "Blackbaud", how: "calendar", free: false,
    note: "The calendar's RSS/iCal button gives an address. Needs a school account to test." },
  { name: "Canvas (another school)", how: "calendar", free: true,
    note: "Canvas's own Calendar Feed works for any Canvas school; a Free-for-Teacher account at canvas.instructure.com is enough to test it." },
  { name: "Todoist", how: "api", free: true,
    note: "A real, free, documented API with a personal token — the best candidate for his own to-dos to land in Life stuff. Not built yet." },
  { name: "Notion", how: "api", free: true,
    note: "Free API, but a page has no fixed shape; useful only once he says which database is his to-do list. Not built yet." },
  { name: "Microsoft To Do", how: "api", free: false,
    note: "Needs an Entra app registration and OAuth, which this app does not do (SPEC 5.3 spirit). Not planned." },
  { name: "Quizlet", how: "shortcut", free: true,
    note: "No public API, and none announced. A shortcut; any Quizlet link on an assignment already shows there." },
  { name: "Gradescope / Turnitin", how: "none", free: false,
    note: "No student-facing API or feed. Its due dates usually also appear in Canvas, which the board already reads." },
  { name: "DeltaMath / Edpuzzle", how: "none", free: true,
    note: "No API, no feed, and both are graded question banks — reading them would need a content script and the same metadata-only boundary as Albert. Not planned until asked for by name." },
];

/* Chips switched off from the strip itself (the × on a quick link). Listed
   here because a control that hides something has to have a visible way
   back, or the site is simply gone and nobody remembers why. */
function hiddenLinksHtml() {
  const hidden = UI.hidden_links || [];
  if (!hidden.length) return "";
  return `<div class="reslist" style="margin-top:8px">${hidden.map((name) => `<div class="resrow">
    ${markHtml((LINK_SITES.find(([, , n]) => n === name) || [])[1] || "link")}
    <span class="grow trunc">${esc(name)}</span>
    <button type="button" class="mini-btn" data-show-link="${esc(name)}">show again</button>
  </div>`).join("")}</div>
  <p class="fieldnote">Hidden from the top bar with the × on the chip. Nothing about them is
    deleted — this only decides whether the link is drawn.</p>`;
}

/* AP Classroom and Albert.io are LINKED, and then read each time he opens
   them in Chrome — never opened for him in a background tab. [ASKED]
   2026-10-07. The state lives in the extension (bridge.js sdChrome.sites). */
let SITE_LINKS = null;
const SITE_KEYS = { "AP Classroom": "apclassroom", "Albert.io": "albert" };
function siteLinkHtml(site) {
  const key = SITE_KEYS[site];
  if (!key || !(window.sdChrome && window.sdChrome.sites)) return "";
  const st = (SITE_LINKS || {})[key] || {};
  const when = st.readAt ? new Date(st.readAt).toLocaleString([], { weekday: "short", hour: "numeric", minute: "2-digit" }) : "";
  const words = st.linked
    ? (st.state === "signed-out" ? `linked — signed out on your last visit; open ${site} and sign in`
       : `linked — read each time you open ${site}${when ? ` (last ${when})` : ""}`)
    : st.pending ? `waiting for ${site} to open — sign in there if it asks`
    : "not linked — nothing is opened for you";
  return `<div class="appmeta">${esc(words)}</div>
    ${st.linked
      ? `<button type="button" class="mini-btn" data-site-unlink="${key}">Unlink</button>`
      : `<button type="button" class="primary" data-site-link="${key}">Link ${esc(site)}</button>`}`;
}
document.addEventListener("click", async (event) => {
  const link = event.target.closest("button[data-site-link]");
  if (link && window.sdChrome && window.sdChrome.sites) {
    window.sdChrome.sites.link(link.dataset.siteLink);     // opens the tab inside this click
    SITE_LINKS = await window.sdChrome.sites.status();
    renderAppsPage();
    return;
  }
  const unlink = event.target.closest("button[data-site-unlink]");
  if (unlink && window.sdChrome && window.sdChrome.sites) {
    await window.sdChrome.sites.unlink(unlink.dataset.siteUnlink);
    SITE_LINKS = await window.sdChrome.sites.status();
    renderAppsPage();
  }
});
window.addEventListener("sd-sites", async () => {
  if (!(window.sdChrome && window.sdChrome.sites)) return;
  SITE_LINKS = await window.sdChrome.sites.status();
  renderAppsPage();
});

function renderAppsPage() {
  const host = $("#apps-page");
  if (!host || !STATE) return;
  if (SITE_LINKS === null && window.sdChrome && window.sdChrome.sites) {
    SITE_LINKS = {};
    window.sdChrome.sites.status().then((st) => { SITE_LINKS = st; renderAppsPage(); });
  }
  const errors = {};
  for (const err of STATE.errors || []) errors[SOURCE_LABEL[err.code] || err.code] = err;
  const bySite = new Map();
  for (const s of SOURCES) {
    if (!bySite.has(s.site)) bySite.set(s.site, []);
    bySite.get(s.site).push(s);
  }
  const chromeRead = new Set(["AP Classroom", "Albert.io"]);
  const siteLogo = { "Canvas": "canvas", "Veracross": "veracross", "AP Classroom": "ap",
                     "Albert.io": "albert", "Your calendars": "link" };
  const siteRow = (site, switches) => {
    const err = errors[site];
    const anyOn = switches.some((s) => s.enabled);
    const signIn = Object.values(SIGN_IN_FOR).find((v) => SOURCE_LABEL[Object.keys(SIGN_IN_FOR).find((k) => SIGN_IN_FOR[k] === v)] === site);
    return `<div class="approw ${err ? "bad" : ""}">
      <div class="apphead">${markHtml(siteLogo[site] || "link")}
        <div class="grow"><b>${esc(site)}</b>
          <span class="appmeta">${err ? `<span class="bad">${esc(String(err.message || "").replace(/\s*(?:[—-]\s*)?fix:.*$/i, ""))}</span>`
            : anyOn ? (chromeRead.has(site) ? "read in your Chrome, by the extension" : "read by the app") : "switched off"}</span></div>
        ${err && signIn && !REMOTE ? `<button type="button" class="banner-signin" data-kind="${esc(signIn.kind)}">${esc(signIn.label)}</button><span class="banner-signin-note"></span>` : ""}
        ${chromeRead.has(site) && !SITE_KEYS[site] ? `<span class="tag" title="you sign in on the site itself; only assignment metadata is read">sign in on the site</span>` : ""}
      </div>
      ${chromeRead.has(site) ? `<div class="appswitches">${siteLinkHtml(site)}</div>` : ""}
      <div class="appswitches">${switches.map((s) => `<label class="appswitch">
        <input type="checkbox" data-source="${esc(s.name)}" ${s.enabled ? "checked" : ""}>
        <span class="grow">${esc(s.what || s.name)}</span></label>`).join("")}</div>
      ${err && err.fix ? `<details class="banner-cmd"><summary>or do it in Terminal</summary><code>${esc(err.fix)}</code></details>` : ""}
    </div>`;
  };
  // Veracross has no switch of its own — the schedule feed is what the whole
  // board stands on — but it is an app with a status, so it gets a row.
  const vxErr = errors["Veracross"];
  const veracrossRow = `<div class="approw ${vxErr ? "bad" : ""}"><div class="apphead">${markHtml("veracross")}
      <div class="grow"><b>Veracross</b><span class="appmeta">${vxErr
        ? `<span class="bad">${esc(String(vxErr.message || "").replace(/\s*(?:[—-]\s*)?fix:.*$/i, ""))}</span>`
        : "the class schedule and the grades — the feed the whole board stands on"}</span></div>
      ${vxErr && !REMOTE ? `<button type="button" class="banner-signin" data-kind="veracross">Sign in to Veracross</button><span class="banner-signin-note"></span>` : ""}
    </div></div>`;
  const shortcuts = UI.shortcuts || [];
  host.innerHTML = `<h3>Apps</h3>
    <p class="lede">Everything the board can read, and whether it is on. <b>Off means off</b>: its
      items leave the board at once, its link leaves the top bar, it is skipped on every refresh,
      and in this Chrome the extension stops opening its site altogether. Nothing is deleted —
      switch it back on and the next refresh brings it back. Sign-in details live in the card
      below and are used for exactly two sites — the ones the app can really sign in to.
      Everything else you sign in to yourself, in your own Chrome.</p>
    <div class="applist">
      ${veracrossRow}
      ${[...bySite.entries()].filter(([site]) => site !== "Your calendars").map(([site, sw]) => siteRow(site, sw)).join("")}
    </div>
    <div class="setcard" id="school-card"><h4>Your school</h4>
      <p class="fieldnote">Other schools run Canvas and Veracross too, and this extension can already read both
        (any <code>*.instructure.com</code> and any <code>*.veracross.com</code>). Type the addresses once and everything
        else here works for that school. A school on Schoology, PowerSchool or Blackbaud pastes its calendar address in the
        card below instead.</p>
      <div class="row3">
        <label class="field">School<input id="school-name" maxlength="80" value="${esc(SCHOOL.name || "")}" placeholder="Brophy College Preparatory"></label>
        <label class="field">Canvas address<input id="school-canvas" type="url" value="${esc(SCHOOL.canvas_host || "")}" placeholder="https://yourschool.instructure.com"></label>
        <label class="field">Veracross portal<input id="school-veracross" type="url" value="${esc(SCHOOL.veracross_portal || "")}" placeholder="blank if your school has no Veracross"></label>
      </div>
      <div class="row3">
        <label class="field">Time zone${timeZoneSelect("school-tz", SCHOOL.time_zone || SCHOOL.mac_time_zone || "")}</label>
      </div>
      <div class="acts"><button type="button" class="primary" id="school-save">Save the school</button>
        <span class="muted" id="school-note"></span></div></div>
    ${runningCardHtml()}
    <div class="setcard"><h4>Your calendars</h4>
      <p class="fieldnote">Google Calendar, TeamSnap, Schoology, PowerSchool, Blackbaud, another school's Canvas — anything with an iCal address. The paste box is in the card below; the address is a password in disguise and never shown again once saved.</p>
      ${(bySite.get("Your calendars") || []).map((s) => `<label class="appswitch">
        <input type="checkbox" data-source="${esc(s.name)}" ${s.enabled ? "checked" : ""}>
        <span class="grow">read every calendar you have connected</span></label>`).join("")}</div>
    <div class="setcard"><h4>Shortcuts</h4>
      <p class="fieldnote">The top bar only shows a site when your data actually links to it — an invented link is an invented fact. Khan Academy and Quizlet never appear in a teacher's doc, so this is how you add one: say so yourself. Marked as yours up there.</p>
      ${hiddenLinksHtml()}
      ${shortcuts.length ? `<div class="reslist">${shortcuts.map((sc, n) => `<div class="resrow">
        ${markHtml((LINK_SITES.find(([needle]) => (sc.url || "").includes(needle)) || [])[1] || "link")}
        <a class="grow trunc" href="${esc(sc.url)}" target="_blank" rel="noopener">${esc(sc.name)}</a>
        <button type="button" class="mini-btn" data-sc-remove="${n}" aria-label="remove ${esc(sc.name)}">×</button></div>`).join("")}</div>` : ""}
      <div class="row2" style="margin-top:8px">
        <label class="field">Name<input id="sc-name" maxlength="40" placeholder="Khan Academy"></label>
        <label class="field">Address<input id="sc-url" type="url" placeholder="https://www.khanacademy.org/"></label></div>
      <div class="acts"><button type="button" class="primary" id="sc-add">Add the shortcut</button>
        <span class="muted">${shortcuts.length} of ${8}</span></div></div>
    <div class="setcard"><h4>More apps, and the truth about each</h4>
      <p class="fieldnote">Researched 2026-09-18. "Free to test" means a person can try it without a school account or a card.</p>
      <div class="morelist">${MORE_APPS.map((a) => `<div class="morerow">
        <b>${esc(a.name)}</b>
        <span class="tag">${esc(HOW_WORDS[a.how] || a.how)}</span>
        ${a.free ? `<span class="tag ok">free to test</span>` : `<span class="tag">needs a school account</span>`}
        <span class="morenote">${esc(a.note)}</span>
        ${a.url ? `<button type="button" class="mini-btn" data-sc-quick="${esc(a.name)}|${esc(a.url)}">add as a shortcut</button>` : ""}
      </div>`).join("")}</div></div>
    <p class="muted" id="apps-note"></p>`;
}
window.renderAppsPage = renderAppsPage;

/* The extension only. The whole app lives in the dashboard tab, so "always
   running" means keeping that tab: opened pinned when Chrome starts, and
   told to Chrome's Memory Saver as a tab it must not discard — a discarded
   tab is a fresh minute-long boot the next time it is looked at. The session
   keep-alives report here too, so a school portal that signed him out is a
   sentence and a link, not a mystery on the next refresh. The Mac app has
   launchd for all of this and shows nothing here. */
function runningCardHtml() {
  const ch = window.sdChrome;
  if (!ch) return "";
  const sessions = Object.entries(ch.sessions || {});
  const ago = (t) => { const m = Math.round((Date.now() - t) / 60000); return m < 1 ? "just now" : m === 1 ? "a minute ago" : `${m} minutes ago`; };
  return `<div class="setcard" id="running-card"><h4>Always running</h4>
      <p class="fieldnote">The app is this tab. Chrome unloads tabs it thinks you have forgotten, and every unload is a cold start; this tab is now marked as one it must keep.
        Opening it pinned when Chrome starts means it is already warm by the time you look.</p>
      <label class="appswitch"><input type="checkbox" id="autostart" ${ch.autostart ? "checked" : ""}>
        <span class="grow">Open SillyBus AI in a pinned tab when Chrome starts</span></label>
      <p class="fieldnote" style="margin-top:8px">Signing in: Chrome's own password manager fills the school sites when you open them, so save each password in Chrome once. Every twenty minutes this tab touches each site to keep the session warm and says here if one has signed you out.</p>
      <p class="fieldnote" style="margin-top:8px">${ch.backup
        ? `Backup: ${esc(ago(ch.backup.at))}, ${esc(String((ch.backup.info || {}).items ?? "?"))} items, ${Math.round(ch.backup.size / 1024)} KB, kept in a second place inside Chrome and put back by itself if the data store ever comes up empty.`
        : "No automatic backup yet \u2014 the first is made about twenty seconds after the dashboard opens."}</p>
      <div class="acts"><button type="button" class="ghost" id="backup-now">Back up now</button>
        <button type="button" class="ghost" id="backup-download" ${ch.backup ? "" : "disabled"}>Download a copy</button></div>
      ${sessions.length ? `<div class="sesslist">${sessions.map(([name, r]) => `<div class="sessrow ${r.ok ? "" : "bad"}">
          <b>${esc(name)}</b><span>${r.ok ? "signed in" : "signed out"} \u00b7 checked ${esc(ago(r.at))}</span>
          ${!r.ok && r.url ? `<a href="${esc(hrefOf(r.url))}" target="_blank" rel="noopener">sign in \u2197</a>` : ""}</div>`).join("")}</div>`
        : `<p class="muted">No session check yet \u2014 the first one runs twenty minutes after the tab opens.</p>`}
    </div>`;
}
document.addEventListener("change", (event) => {
  const box = event.target.closest("#autostart");
  if (!box || !window.sdChrome) return;
  window.sdChrome.setAutostart(box.checked).then(() => appsNote(box.checked
    ? "Chrome will open the app pinned when it starts" : "the app opens only when you open it"));
});
/* Another tab wrote something.

   [ASKED] 2026-09-20: "all the tabs should be in perfect sink but can be in
   different windows." The extension now runs one Python for every open tab
   (extension/bridge.js) and says so whenever anything is written — from any
   window. Without this the other windows would sit on their own minute-poll
   and show yesterday's board for up to a minute after a tick.

   Debounced, because one action can write more than once (ticking an item
   writes the tick and then the board), and STATE_ETAG means a reload that
   finds nothing new costs a 304 and no re-render at all. */
let syncTimer = null;
window.addEventListener("sd-changed", () => {
  clearTimeout(syncTimer);
  syncTimer = setTimeout(() => {
    loadState().catch(() => {});
    loadChatHistory().catch(() => {});
    loadAccelRecent().then(paintChats).catch(() => {});
  }, 250);
});
window.addEventListener("sd-sessions", () => { if (PANE === "settings") keepScroll(renderAppsPage); renderQuickLinks(); });
window.addEventListener("sd-backup", () => { if (PANE === "settings") keepScroll(renderAppsPage); });
document.addEventListener("click", async (event) => {
  if (!window.sdChrome) return;
  if (event.target.closest("#backup-now")) { appsNote("backing up\u2026"); const b = await window.sdChrome.backupNow(); appsNote(b ? "backed up just now" : "the backup did not finish \u2014 try again in a moment", !b); return; }
  if (event.target.closest("#backup-download")) { const ok = await window.sdChrome.downloadBackup(); appsNote(ok ? "saved to your Downloads folder" : "no backup to download yet", !ok); }
});

function appsNote(text, bad) {
  const n = $("#apps-note");
  if (n) { n.textContent = text || ""; n.classList.toggle("bad", !!bad); }
}

document.addEventListener("change", async (event) => {
  const sw = event.target.closest("input[data-source]");
  if (!sw) return;
  const name = sw.dataset.source, on = sw.checked;
  try {
    const res = await fetch("/api/sources", { method: "PUT",
      headers: { "Content-Type": "application/json" }, body: JSON.stringify({ [name]: on }) });
    const out = await res.json();
    if (!res.ok) { appsNote((out.error || {}).message || "that did not save", true); sw.checked = !on; return; }
    SOURCES = out.sources || SOURCES;
    keepScroll(renderAppsPage);
    /* Off is immediate now: pipeline.load_state_overlaid drops a switched-off
       connector's items and errors as the board is read, and the strip drops
       its link. So say what actually happened. */
    if (window.loadState) loadState().catch(() => {});
    if (window.renderQuickLinks) renderQuickLinks();
    appsNote(`${name.replace(/_/g, " ")} is ${on
      ? "on — the next refresh reads it again"
      : "off — it is gone from the board and the top bar, and no refresh will read it"}`);
  } catch (err) { appsNote("that did not save — the app may have restarted", true); sw.checked = !on; }
});
document.addEventListener("click", async (event) => {
  const back = event.target.closest("button[data-show-link]");
  if (back) {
    const problem = await showQuickLink(back.dataset.showLink);
    appsNote(problem || `${back.dataset.showLink} is back in the top bar`, !!problem);
    return;
  }
  const quick = event.target.closest("button[data-sc-quick]");
  const add = event.target.closest("#sc-add");
  const rm = event.target.closest("button[data-sc-remove]");
  if (!quick && !add && !rm) return;
  let list = (UI.shortcuts || []).slice();
  if (quick) {
    const [name, url] = quick.dataset.scQuick.split("|");
    if (!list.some((s) => s.url === url)) list.push({ name, url });
  } else if (add) {
    const name = ($("#sc-name") || {}).value || "", url = ($("#sc-url") || {}).value || "";
    if (!name.trim() || !url.trim()) { appsNote("a shortcut needs a name and an https:// address", true); return; }
    list.push({ name: name.trim(), url: url.trim() });
  } else {
    list.splice(Number(rm.dataset.scRemove), 1);
  }
  const problem = await saveUiPrefs({ shortcuts: list });
  renderStudio();
  keepScroll(renderAppsPage);
  appsNote(problem || (rm ? "shortcut removed" : "added to the top bar, marked as yours"), !!problem);
});

/* ==========================================================================
   The class page — a class takes the whole dashboard
   ==========================================================================

   "When I click a class or the settings, it should take up the entire screen
   with a better homepage for that class with everything relevant for that
   class. be creative with that part."

   Three columns under a header. LEFT: what is open, each line carrying the
   sentence saying where its date came from; when it meets this week; his
   notes; where the work is read from. MIDDLE: the weighted gradebook — drawn
   by renderGradePane, which is the ONE grade formula (gradeShares) and the
   what-if calculator that goes through it; this file does not compute a
   grade. RIGHT: the textbook, the links that ARE the class, what came back
   lately, and the ways in — ask the chat about it, open it where it lives. */
function renderClassPage(key) {
  const head = $("#class-head-meta"), left = $("#class-left"), right = $("#class-right");
  if (!head || !left || !right || !STATE) return;
  const c = courseRecords().find((x) => x.key === key)
    || { key, name: key, nick: key, graded: false, teacher: "", room: "" };
  const rec = COURSE_RECORDS[key] || {};
  const today = todayIso();
  const open = openFor(key);
  const u = urgencyOf(key);
  const marks = ((STATE.scores || []).filter((m) => m.course_key === key && !m.omit))
    .slice().sort((a, b) => String(b.graded_at || b.due || "") < String(a.graded_at || a.due || "") ? -1 : 1);
  const weekStartIso = weekStart(today);
  const meets = [];
  for (let n = 0; n < 7; n++) {
    const day = isoPlus(weekStartIso, n);
    for (const m of (STATE.schedule || {})[day] || []) if (m.course_key === key) meets.push({ day, m });
  }
  const period = coursePeriod(key);
  const mats = (rec.materials || []).filter((m) => !m.hidden);
  const books = mats.filter((m) => m.kind === "textbook" || m.kind === "textbook_mention");
  const conns = rec.connectors || {};
  const canvasUrl = conns.canvas_url || rec.canvas_url
    || (((STATE.profiles || []).find((p) => p.course_key === key) || {}).canvas_url) || "";
  const docUrl = conns.doc_url || (((STATE.profiles || []).find((p) => p.course_key === key) || {}).doc || {}).url || "";
  const joins = joinsFor(key);
  head.innerHTML = `${ringHtml(c, 44)}
    <div class="grow">
      <div class="cpsub">${esc([c.teacher, c.room, period < 99 ? "period " + period : "", u.words].filter(Boolean).join(" · "))}${
        c.school_name ? ` · <span title="what the school calls it">${esc(c.school_name)}</span>` : ""}${
        joins.length ? ` · <span title="on the Veracross grades page">also ${esc(joins.map((j) => j.name).join(", "))}</span>` : ""}</div>
    </div>
    <div class="cpstats">
      <div class="cpstat"><b>${c.graded && typeof c.percent === "number" ? c.percent.toFixed(1) + "%" : "—"}</b><span>grade</span></div>
      <div class="cpstat"><b>${c.graded ? esc(c.letter || "—") : "—"}</b><span>letter</span></div>
      <div class="cpstat"><b>${open.length}</b><span>open</span></div>
      <div class="cpstat"><b>${marks.length}</b><span>marks in</span></div>
      <div class="cpstat"><b>${meets.length}</b><span>this week</span></div>
    </div>
    <div class="cpacts">
      <button type="button" class="ghost" data-ask-class="${esc(key)}">Ask about ${esc(c.nick)}</button>
      ${canvasUrl ? `<a class="primary btnlink" href="${esc(hrefOf(canvasUrl))}" target="_blank" rel="noopener">Open in Canvas ↗</a>` : ""}
      ${docUrl ? `<a class="ghost btnlink" href="${esc(hrefOf(docUrl))}" target="_blank" rel="noopener">Homework doc ↗</a>` : ""}
      <button type="button" class="ghost" data-open-settings-class="${esc(key)}">Set up this class</button>
    </div>`;
  const row = (i) => `<div class="workrow">
    <input type="checkbox" class="tick" ${i.done ? "checked" : ""} aria-label="Mark ${esc(i.title)} done" data-id="${esc(i.item_id)}">
    <button type="button" class="grow" data-open="${esc(i.item_id)}">
      <span class="t ${i.done ? "struck" : ""}">${esc(i.title)}</span>
      <span class="m"><span class="${esc(urgencyWord(i.due_date, today, i))}">${esc(dueLabel(i))}</span>
        ${i.points ? `<span>${esc(i.points)} pts</span>` : ""}
        ${UI.show_estimates && i.est_label ? `<span>${esc(i.est_label)}</span>` : ""}
        <span class="kind">${esc(KIND_WORD[i.category] || "work")}</span>
        <span class="dn">${esc(i.date_note || "")}</span></span></button>
    ${REMOTE || i.done ? "" : `<button type="button" class="row-accel" data-accel="${esc(i.item_id)}" title="Accelerate: a study guide from the actual material" aria-label="Accelerate ${esc(i.title)}">⚡</button>`}</div>`;
  left.innerHTML = `<div class="sech">What is open <span class="muted">${open.length}</span></div>
    ${open.map(row).join("") || `<div class="secempty">Nothing open. ✅</div>`}
    <div class="sech">When it meets this week</div>
    ${meets.map(({ day, m }) => `<div class="markrow"><span>${esc(dayName(day))} ${esc(niceDate(day))}<i>${esc(m.room || c.room || "")}</i></span>
      <b>${esc((m.start || "").slice(11, 16))}</b><em>${esc((m.end || "").slice(11, 16))}</em></div>`).join("")
      || `<div class="secempty">Not on the schedule this week.</div>`}
    <div class="sech">Your notes</div>
    ${rec.notes ? `<div class="instr">${esc(rec.notes)}</div>`
      : `<div class="secempty">Nothing yet — <button type="button" class="lnk" data-open-settings-class="${esc(key)}">add a note</button> and the chat will read it.</div>`}
    <div class="sech">Where the work is read from</div>
    <div class="secempty">${esc(classProfileLine(key))}${docUrl ? "" : canvasUrl ? "" : " — no Canvas course and no doc address yet; set one up and the next refresh reads it"}</div>`;
  const recent = marks.slice(0, 6);
  right.innerHTML = `<div class="sech">Textbook</div>
    ${books.length ? books.map((b) => `<div class="book"><div class="grow"><div class="t">${esc(b.title || "the textbook")}</div>
        <div class="a">${esc(b.notes || "")}${b.isbn ? " · ISBN " + esc(b.isbn) : ""}</div>
        <div class="go">${b.url ? `<a href="${esc(hrefOf(b.url))}" target="_blank" rel="noopener">${esc(b.kind === "textbook" ? "Open online ↗" : "Find it ↗")}</a>`
          : `<span class="muted">named by the teacher, no readable copy found — none pretended</span>`}</div></div></div>`).join("")
      : `<div class="secempty">No textbook attached. <button type="button" class="lnk" data-open-settings-class="${esc(key)}">Search for one ›</button></div>`}
    <div class="sech">Links for this class</div>
    <div class="reslist">${primaryMaterials(mats).filter((m) => !/textbook/.test(m.kind)).map((m) => `<a class="res" href="${esc(hrefOf(m.url || "#"))}" target="_blank" rel="noopener">
        <span class="grow"><b>${esc(m.title || m.url)}</b><i>${esc((m.kind || "").replace(/_/g, " "))}${m.confirmed ? " · confirmed" : ""}</i></span><span class="arr">↗</span></a>`).join("")
      || `<div class="secempty">Only Canvas, so far.</div>`}</div>
    ${secondaryMaterials(mats).length ? `<details class="hiddenres"><summary>${secondaryMaterials(mats).length} more link${secondaryMaterials(mats).length === 1 ? "" : "s"}</summary>
      <div class="reslist" style="margin-top:4px">${secondaryMaterials(mats).map((m) => `<a class="res" href="${esc(hrefOf(m.url || "#"))}" target="_blank" rel="noopener"><span class="grow"><b>${esc(m.title || m.url)}</b></span><span class="arr">↗</span></a>`).join("")}</div></details>` : ""}
    <div class="sech">Came back lately</div>
    ${recent.length ? recent.map((m) => `<div class="markrow"><span>${esc(m.title || m.category)}<i>${esc(kindName(m.category || "other"))}${m.graded_at || m.due ? " · " + esc(String(m.graded_at || m.due).slice(0, 10)) : ""}</i></span>
        <b class="${typeof m.percent === "number" && m.percent < 75 ? "low" : ""}">${esc(String(m.score))}/${esc(String(m.possible))}</b>
        <em>${typeof m.percent === "number" ? Math.round(m.percent) + "%" : ""}</em></div>`).join("")
      : `<div class="secempty">Nothing marked yet.</div>`}
    ${(rec.announcements || []).length ? `<div class="sech">Announcements</div>${(rec.announcements || []).slice(0, 3).map((a) => `<div class="ann">
        ${a.url ? `<a href="${esc(hrefOf(a.url))}" target="_blank" rel="noopener">${esc(a.title || "announcement")}</a>` : `<b>${esc(a.title || "announcement")}</b>`}
        <span class="muted"> ${esc((a.posted_at || "").slice(0, 10))}</span>
        <div class="anntext">${esc((a.text || "").slice(0, 220))}</div></div>`).join("")}` : ""}`;
}
window.renderClassPage = renderClassPage;

document.addEventListener("click", (event) => {
  const ask = event.target.closest("button[data-ask-class]");
  if (ask) {
    const c = courseRecords().find((x) => x.key === ask.dataset.askClass);
    const input = $("#chat-input"), form = $("#chat-form");
    if (!input || !form) return;
    setChatContext({ label: c ? c.nick : ask.dataset.askClass, sticky: true });
    input.value = `from the work on my board, what should I do for ${c ? c.nick : "this class"} this week?`;
    form.dispatchEvent(new Event("submit", { cancelable: true }));
    return;
  }
  const set = event.target.closest("button[data-open-settings-class]");
  if (set) {
    OPEN_CLASS_CARD = set.dataset.openSettingsClass;
    if (window.showView) window.showView("settings");
    if (window.showSetPage) window.showSetPage("classes");
    return;
  }
  const acc = event.target.closest("button[data-accel]");
  if (acc && window.openAccelerate) {
    const it = (STATE.items || []).find((i) => i.item_id === acc.dataset.accel);
    if (it) window.openAccelerate(it.item_id, it.title);
  }
});

document.addEventListener("click", async (event) => {
  if (!event.target.closest("#school-save")) return;
  const note = $("#school-note");
  const body = { name: ($("#school-name") || {}).value || "",
                 canvas_host: ($("#school-canvas") || {}).value || "",
                 veracross_portal: ($("#school-veracross") || {}).value || "",
                 // Saving here is the student's own word about the school, as
                 // the setup step is (config._hold_unconfirmed_portal).
                 confirm: true };
  const tz = ($("#school-tz") || {}).value;
  if (tz) body.time_zone = tz;
  try {
    const res = await fetch("/api/school", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const out = await res.json();
    if (!res.ok) { if (note) { note.textContent = (out.error || {}).message + (out.error && out.error.fix ? " — " + out.error.fix : ""); note.classList.add("bad"); } return; }
    SCHOOL = out;
    if (note) { note.textContent = "saved — the next refresh reads from there"; note.classList.remove("bad"); }
  } catch (err) { if (note) { note.textContent = "that did not save — the app may have restarted"; note.classList.add("bad"); } }
});

/* ==========================================================================
   Settings -> Focus
   ==========================================================================

   [ASKED] 2026-09-20: "i just want the option of self dicipline built into the
   sillybus chrome extension. in settings have 3 modes (off, reminder …, and
   block … but there is a bypass pin). just for helping yourself do homework."

   One decision at the top — Off, Reminder, Block — and only the settings that
   decision actually uses underneath it, because a page that shows the PIN row
   while the mode is Off is a page that reads as broken. What the modes mean,
   the site list and the reasoning live in `sillybus/focus.py`.

   Three things this page has to be honest about, and says on screen:

   - The gate runs in the Chrome extension. In the Mac app these are real
     preferences that nothing enforces, and the page says so rather than
     implying a block that will never happen.
   - Chrome, not SillyBus, decides whether it may see a site. The permission
     prompt is asked for the student's OWN list, and a site that has not been
     granted is shown as waiting rather than drawn as if it were live.
   - Block is friction, not security. chrome://extensions is always there.
     A blocker that pretends otherwise is lying to the person who set it. */

let FOCUS_PRESETS = [];
let FOCUS_STATUS = null;

const focusNow = () => (UI.focus || {});
const focusOrigins = (hosts) => (hosts || []).map((h) => `*://*.${h}/*`);

/* Every host the current list covers, presets first — the same order and the
   same shape `focus.py` builds, so what Chrome is asked for matches what the
   worker registers. */
function focusHosts(focus) {
  const gone = new Set((focus.sites_off) || []);
  const out = [];
  for (const p of FOCUS_PRESETS) if (!gone.has(p.id)) out.push(...p.hosts);
  for (const h of focus.custom || []) if (!out.includes(h)) out.push(h);
  return out;
}

async function loadFocus() {
  try {
    const res = await fetch("/api/focus");
    const out = await res.json();
    FOCUS_PRESETS = out.presets || [];
  } catch (err) { /* the page says it could not read the list */ }
  if (window.sdChrome && window.sdChrome.focus) {
    try { FOCUS_STATUS = await window.sdChrome.focus.status(); } catch (err) { FOCUS_STATUS = null; }
  }
}

function focusNote(message, bad) {
  const note = $("#focus-note");
  if (!note) return;
  note.textContent = message || "";
  note.hidden = !message;
  note.classList.toggle("bad", !!bad);
}

/* Saving is the easy half. The hard half is the ORDER: Chrome grants a
   permission only from a user gesture, and an `await` on our own fetch spends
   that gesture — [MEASURED] the request is refused outright if the save goes
   first. So the caller asks Chrome first, synchronously in the click, and
   only writes the preference once the answer is in. */
async function saveFocus(patch, message) {
  const problem = await saveUiPrefs({ focus: { ...focusNow(), ...patch } });
  if (window.sdChrome && window.sdChrome.focus) {
    try {
      await window.sdChrome.focus.mirror();
      await window.sdChrome.focus.sync();
      FOCUS_STATUS = await window.sdChrome.focus.status();
    } catch (err) { /* Settings still shows what is saved */ }
  }
  // The note is written AFTER the redraw, not before it. [MEASURED]
  // 2026-09-20: adding docs.google.com was correctly refused and the page
  // said nothing at all, because renderFocusPage() rebuilds the whole
  // section and took the sentence with it.
  keepScroll(renderFocusPage);
  focusNote(problem || message || "", !!problem);
  return !problem;
}

/* With Block on and a PIN set, anything that loosens Block takes the current
   PIN (prosecution #7, 2026-10-07) — otherwise the way past the gate was to
   open Settings and switch it off, or set a new PIN, with no effort at all.
   Friction, like the PIN itself; the worker checks the hash. */
function focusCurrentPin() {
  const field = $("#focus-pin-current");
  return field ? (field.value || "").trim() : "";
}
async function focusPinAllows() {
  const focus = focusNow();
  if ((focus.mode || "off") !== "block") return true;
  if (!(FOCUS_STATUS && FOCUS_STATUS.pinSet)) return true;
  if (!(window.sdChrome && window.sdChrome.focus && window.sdChrome.focus.verifyPin)) return true;
  const reply = await window.sdChrome.focus.verifyPin(focusCurrentPin());
  if (reply && reply.ok) return true;
  focusNote(focusCurrentPin() ? "That is not your PIN, so Block stayed as it was."
    : "Type your current PIN in the box under \u201cYour bypass PIN\u201d first.", true);
  const field = $("#focus-pin-current");
  if (field) field.focus();
  return false;
}

const FOCUS_MODES = [
  ["off", "Off", "Nothing watches anything. No site permission is held and no code runs on any page."],
  ["remind", "Reminder", "Opening a site on your list slides in a card saying what is actually due. It can be waved away; the page is never touched."],
  ["block", "Block", "A site on your list is covered until you type your PIN. The gate names the work, and pauses whatever was playing."],
];

const REMIND_EVERY = [
  ["visit", "Once per visit", "one card each time you open the site"],
  ["hourly", "Once an hour", "quieter, for a site you dip into all day"],
  ["always", "Every page", "a card on every video or post"],
];

function renderFocusPage() {
  const host = $("#focus-page");
  if (!host) return;
  const focus = focusNow();
  const mode = focus.mode || "off";
  const gone = new Set(focus.sites_off || []);
  const inChrome = !!(window.sdChrome && window.sdChrome.focus);
  const missing = (FOCUS_STATUS && FOCUS_STATUS.missing) || [];
  const pinSet = !!(FOCUS_STATUS && FOCUS_STATUS.pinSet);
  const custom = focus.custom || [];
  const onCount = FOCUS_PRESETS.filter((p) => !gone.has(p.id)).length + custom.length;

  const chip = (id, label, on, hosts) => `
    <button type="button" class="fsite ${on ? "on" : ""}" data-focus-site="${esc(id)}"
      aria-pressed="${on}" title="${esc(hosts.join(", "))}">
      <span class="fmark" aria-hidden="true">${on ? "✓" : "+"}</span>${esc(label)}</button>`;

  host.innerHTML = `<h3>Focus</h3>
    <p class="lede">One question: what should happen when you open something distracting
      while you still have homework? Nothing here is on until you turn it on, and Focus
      never touches your school sites — Canvas, Google Docs, AP Classroom and Albert.io
      cannot be blocked.</p>

    ${inChrome ? "" : `<div class="setnote bad">Focus runs in the Chrome extension.
      This is the Mac app, so these are real settings that nothing here will enforce —
      they take effect in Chrome.</div>`}

    <div class="fmodes" role="group" aria-label="Focus mode">
      ${FOCUS_MODES.map(([value, label, why]) => `
        <button type="button" class="fmode ${mode === value ? "on" : ""}" data-focus-mode="${value}"
          aria-pressed="${mode === value}">
          <b>${esc(label)}</b><span>${esc(why)}</span></button>`).join("")}
    </div>
    <p class="note" id="focus-note" hidden></p>

    ${mode === "off" ? `<p class="muted fquiet">Pick Reminder or Block and the rest of this
      page appears — the sites, and for Block, your PIN.</p>` : `

    <div class="card fcard">
      <h4>Which sites</h4>
      <p class="muted">${onCount} on the list. Tap one to take it off; add anything else below.
        Chrome will ask your permission for these, and only these.</p>
      <div class="fsites">
        ${FOCUS_PRESETS.map((p) => chip(p.id, p.label, !gone.has(p.id), p.hosts)).join("")}
      </div>
      ${custom.length ? `<div class="fsites fown">
        ${custom.map((h) => `<span class="fsite on own">${esc(h)}
          <button type="button" class="fx" data-focus-drop="${esc(h)}"
            aria-label="take ${esc(h)} off the list">×</button></span>`).join("")}
      </div>` : ""}
      <form id="focus-add" class="fadd">
        <input id="focus-host" type="text" autocomplete="off" spellcheck="false"
               placeholder="another site, like example.com" aria-label="add a site">
        <button type="submit" class="ghost">Add</button>
      </form>
      ${inChrome && missing.length ? `<div class="setnote bad fgrant">
        <span>${missing.length} site${missing.length === 1 ? "" : "s"} on your list
          ${missing.length === 1 ? "is" : "are"} waiting for Chrome's permission —
          until you allow ${missing.length === 1 ? "it" : "them"}, Focus cannot see
          ${missing.length === 1 ? "it" : "them"}.</span>
        <button type="button" class="primary" id="focus-grant">Allow in Chrome</button>
      </div>` : ""}
    </div>

    ${mode === "remind" ? `
    <div class="card fcard">
      <h4>How often</h4>
      <p class="muted">A card on every single page trains you to dismiss it without reading,
        which is the one thing a reminder must not become.</p>
      <div class="segrow" role="group" aria-label="how often to remind">
        ${REMIND_EVERY.map(([value, label, why]) => `
          <button type="button" class="segbtn ${(focus.remind_every || "visit") === value ? "on" : ""}"
            data-focus-every="${value}" aria-pressed="${(focus.remind_every || "visit") === value}"
            title="${esc(why)}">${esc(label)}</button>`).join("")}
      </div>
    </div>` : ""}

    ${mode === "block" ? `
    <div class="card fcard">
      <h4>Your bypass PIN</h4>
      <p class="muted">${pinSet
        ? "A PIN is set. Typing it on a blocked site opens that site for a while."
        : "No PIN yet. Without one the gate has no way through except turning Focus off here."}</p>
      ${pinSet ? `<div class="frow">
        <label for="focus-pin-current">Current PIN</label>
        <input id="focus-pin-current" type="password" inputmode="numeric" maxlength="8"
               autocomplete="off" placeholder="needed to change or loosen Block"
               aria-label="current PIN">
      </div>` : ""}
      <form id="focus-pin" class="fadd">
        <input id="focus-pin-value" type="password" inputmode="numeric" maxlength="8"
               autocomplete="off" placeholder="${pinSet ? "new PIN, 4–8 digits" : "4–8 digits"}" aria-label="bypass PIN">
        <button type="submit" class="primary">${pinSet ? "Change it" : "Set it"}</button>
        ${pinSet ? `<button type="button" class="ghost" id="focus-pin-clear">Remove</button>` : ""}
      </form>
      <p class="fine">This is friction, not a lock. Anyone — you, in a weak moment — can
        open <code>chrome://extensions</code> and switch SillyBus off, and the gate says so
        out loud. What it buys you is that getting past it has to be a deliberate act
        instead of a reflex.</p>
    </div>

    <div class="card fcard">
      <h4>How the gate behaves</h4>
      <div class="frow">
        <label for="focus-minutes">A correct PIN opens the site for</label>
        <input id="focus-minutes" type="number" min="1" max="60" step="1"
               value="${esc(focus.bypass_minutes == null ? 15 : focus.bypass_minutes)}">
        <span class="muted">minutes — about a minute for a video a teacher linked,
          an hour for an evening off.</span>
      </div>
      <div class="frow">
        <label>When nothing is due</label>
        <span class="segrow" role="group" aria-label="when nothing is due">
          ${[["allow", "Let me through"], ["block", "Still block"]].map(([value, label]) => `
            <button type="button" class="segbtn ${(focus.when_clear || "allow") === value ? "on" : ""}"
              data-focus-clear="${value}" aria-pressed="${(focus.when_clear || "allow") === value}">${esc(label)}</button>`).join("")}
        </span>
      </div>
      <p class="fine">The point of this is homework, so an empty board lets go by default.
        A board SillyBus has not read yet counts as work outstanding — the alternative is
        Focus quietly letting everything through the first time you install it.</p>
    </div>` : ""}
    `}`;
}
window.renderFocusPage = renderFocusPage;

/* ---- the handlers ----
   Chrome first, then the save. See saveFocus() for why the order is not a
   matter of taste. */
/* One way to change the mode, used by the buttons below AND by the chat
   ([ASKED] 2026-10-07, applyChatActions), so the two cannot disagree about
   the permission order or the PIN. `granted` is the chat's button having
   already asked Chrome inside its own click. Resolves true when it saved. */
async function setFocusMode(mode, opts) {
  const focus = focusNow();
  if (mode === (focus.mode || "off")) return true;
  if (!(await focusPinAllows())) return false;
  if (mode === "off") {
    // Off means absent: hand the site permissions back, so a student who
    // turned Focus off is not left with an extension that may still read
    // youtube.com. Chrome keeps nothing once they are removed.
    if (window.sdChrome && window.sdChrome.focus) {
      try { await window.sdChrome.focus.drop(focusOrigins(focusHosts(focus))); } catch (err) { /* it may already be gone */ }
    }
    return saveFocus({ mode }, "Focus is off — the site permissions were handed back.");
  }
  const origins = focusOrigins(focusHosts(focus));
  if (window.sdChrome && window.sdChrome.focus && !(opts && opts.granted)) {
    const allowed = await window.sdChrome.focus.request(origins);
    if (!allowed) {
      focusNote("Chrome did not allow those sites, so Focus stayed off. It cannot see a site you have not allowed.", true);
      return false;
    }
  }
  return saveFocus({ mode }, mode === "block"
    ? "Block is on. Set a PIN below if you want a way through."
    : "Reminders are on.");
}
window.setFocusMode = setFocusMode;

document.addEventListener("click", async (event) => {
  const modeBtn = event.target.closest("button[data-focus-mode]");
  if (modeBtn) {
    await setFocusMode(modeBtn.dataset.focusMode);
    return;
  }

  const site = event.target.closest("button[data-focus-site]");
  if (site) {
    const id = site.dataset.focusSite;
    const focus = focusNow();
    const off = new Set(focus.sites_off || []);
    const turningOn = off.has(id);
    if (turningOn) {
      off.delete(id);
      const preset = FOCUS_PRESETS.find((p) => p.id === id);
      if (preset && window.sdChrome && window.sdChrome.focus) {
        const allowed = await window.sdChrome.focus.request(focusOrigins(preset.hosts));
        if (!allowed) { focusNote(`Chrome did not allow ${preset.label}, so it was not added.`, true); return; }
      }
    } else {
      if (!(await focusPinAllows())) return;
      off.add(id);
    }
    await saveFocus({ sites_off: FOCUS_PRESETS.map((p) => p.id).filter((p) => off.has(p)) });
    return;
  }

  const drop = event.target.closest("button[data-focus-drop]");
  if (drop) {
    const host = drop.dataset.focusDrop;
    const focus = focusNow();
    if (!(await focusPinAllows())) return;
    if (window.sdChrome && window.sdChrome.focus) {
      try { await window.sdChrome.focus.drop(focusOrigins([host])); } catch (err) { /* already gone */ }
    }
    await saveFocus({ custom: (focus.custom || []).filter((h) => h !== host) });
    return;
  }

  const every = event.target.closest("button[data-focus-every]");
  if (every) { await saveFocus({ remind_every: every.dataset.focusEvery }); return; }

  const clear = event.target.closest("button[data-focus-clear]");
  if (clear) {
    if (clear.dataset.focusClear === "allow" && !(await focusPinAllows())) return;
    await saveFocus({ when_clear: clear.dataset.focusClear });
    return;
  }

  if (event.target.closest("#focus-grant")) {
    if (!(window.sdChrome && window.sdChrome.focus)) return;
    const allowed = await window.sdChrome.focus.request((FOCUS_STATUS || {}).missing || []);
    if (!allowed) { focusNote("Chrome did not allow those sites.", true); return; }
    await window.sdChrome.focus.sync();
    FOCUS_STATUS = await window.sdChrome.focus.status();
    keepScroll(renderFocusPage);
    focusNote("Allowed — Focus is watching those sites now.");
    return;
  }

  if (event.target.closest("#focus-pin-clear")) {
    if (!(window.sdChrome && window.sdChrome.focus)) return;
    const gone = await window.sdChrome.focus.clearPin(focusCurrentPin());
    if (gone && gone.ok === false) { focusNote(gone.message || "the PIN was not removed", true); return; }
    FOCUS_STATUS = await window.sdChrome.focus.status();
    keepScroll(renderFocusPage);
    focusNote("The PIN is gone. The gate has no way through now except turning Focus off here.");
  }
});

document.addEventListener("submit", async (event) => {
  const add = event.target.closest("#focus-add");
  if (add) {
    event.preventDefault();
    const field = $("#focus-host");
    const typed = (field.value || "").trim();
    if (!typed) return;
    // The hostname is cleaned by prefs.py, which is the one place that knows
    // what a refusal should say; the page asks Chrome for the tidied form it
    // sends, so a pasted URL still produces a valid match pattern.
    const host = typed.toLowerCase().replace(/^[a-z]+:\/\//, "").split("/")[0].replace(/^www\./, "");
    const focus = focusNow();
    if (window.sdChrome && window.sdChrome.focus) {
      const allowed = await window.sdChrome.focus.request(focusOrigins([host]));
      if (!allowed) { focusNote(`Chrome did not allow ${host}, so it was not added.`, true); return; }
    }
    const ok = await saveFocus({ custom: [...(focus.custom || []), host] }, `${host} is on the list.`);
    if (ok) { const f = $("#focus-host"); if (f) f.value = ""; }
    return;
  }

  const pin = event.target.closest("#focus-pin");
  if (pin) {
    event.preventDefault();
    if (!(window.sdChrome && window.sdChrome.focus)) {
      focusNote("The PIN is kept by the Chrome extension, so it can be set only there.", true);
      return;
    }
    const field = $("#focus-pin-value");
    const reply = await window.sdChrome.focus.setPin((field.value || "").trim(), focusCurrentPin());
    if (!reply || !reply.ok) { focusNote((reply && reply.message) || "that PIN was not set", true); return; }
    field.value = "";
    FOCUS_STATUS = await window.sdChrome.focus.status();
    keepScroll(renderFocusPage);
    focusNote("PIN set. It is stored hashed, in this Chrome only, and never leaves it.");
  }
});

document.addEventListener("change", async (event) => {
  const minutes = event.target.closest("#focus-minutes");
  if (!minutes) return;
  const value = Math.round(Number(minutes.value));
  if (!Number.isFinite(value)) return;
  const before = focusNow().bypass_minutes == null ? 15 : focusNow().bypass_minutes;
  if (value > before && !(await focusPinAllows())) { minutes.value = before; return; }
  await saveFocus({ bypass_minutes: Math.min(60, Math.max(1, value)) });
});

/* ==========================================================================
   Settings -> Focus -> Downtime
   ==========================================================================

   [ASKED] 2026-10-07: "in settings add a thing where you set a down time or
   tell the chat to do it". Screen Time's Downtime for SillyBus Lock: during
   these hours the games and social media the lock blocks stay blocked even
   when all the homework is done. What it means — the zone, the window past
   midnight belonging to the day it starts — is `sillybus/downtime.py`; this
   card only shows it and saves through PUT /api/downtime, then tells the lock
   at once rather than at the next minute's push. */
let DOWNTIME = null;
let DOWNTIME_FAILED = false;
const DT_DAYS = [["mon", "M", "Monday"], ["tue", "T", "Tuesday"], ["wed", "W", "Wednesday"],
  ["thu", "T", "Thursday"], ["fri", "F", "Friday"], ["sat", "S", "Saturday"], ["sun", "S", "Sunday"]];

async function loadDowntime() {
  if (REMOTE) return;
  try {
    const res = await fetch("/api/downtime");
    if (!res.ok) throw new Error(String(res.status));
    DOWNTIME = await res.json();
    DOWNTIME_FAILED = false;
  } catch (err) { DOWNTIME_FAILED = true; }
}

function downtimeNote(message, bad) {
  const note = $("#dt-note");
  if (!note) return;
  note.textContent = message || "";
  note.hidden = !message;
  note.classList.toggle("bad", !!bad);
}

function renderDowntimeCard() {
  const host = $("#downtime-card");
  if (!host) return;
  if (REMOTE) { host.innerHTML = ""; return; }
  if (!DOWNTIME) {
    host.innerHTML = `<div class="card fcard"><h4>Downtime</h4>
      <p class="muted">${DOWNTIME_FAILED ? "Downtime could not be read — the app may have restarted. Open this page again."
        : "Reading Downtime…"}</p></div>`;
    return;
  }
  const d = DOWNTIME;
  const days = new Set(d.days || []);
  host.innerHTML = `<div class="card fcard" id="downtime">
    <h4>Downtime</h4>
    <p class="muted">During these hours SillyBus Lock keeps games and social media closed,
      even when all your homework is done — Get More Time still works, a few minutes at a time.</p>
    <label class="appswitch"><input type="checkbox" id="dt-on" ${d.on ? "checked" : ""}>
      Downtime is ${d.on ? "on" : "off"}</label>
    <div class="frow">
      <label for="dt-start">From</label>
      <input type="time" id="dt-start" value="${esc(d.start)}" required>
      <label for="dt-end">to</label>
      <input type="time" id="dt-end" value="${esc(d.end)}" required>
    </div>
    <div class="segrow dt-days" role="group" aria-label="Downtime days">
      ${DT_DAYS.map(([key, letter, name]) => `
        <button type="button" class="segbtn ${days.has(key) ? "on" : ""}" data-dt-day="${esc(key)}"
          aria-pressed="${days.has(key) ? "true" : "false"}" title="${esc(name)}" aria-label="${esc(name)}">${esc(letter)}</button>`).join("")}
    </div>
    <p class="muted dt-label" id="dt-label">${esc(d.label || "")}</p>
    <p class="note" id="dt-note" hidden></p>
  </div>`;
}
window.renderDowntimeCard = renderDowntimeCard;

/* `redraw` is false for the time pickers: a time input fires change while it
   is still being typed in, and rebuilding the card under it would throw the
   cursor out of the box. Those only update the sentence. */
async function saveDowntime(patch, redraw = true) {
  let problem = "";
  try {
    const res = await fetch("/api/downtime", { method: "PUT",
      headers: { "Content-Type": "application/json" }, body: JSON.stringify(patch) });
    const out = await res.json().catch(() => ({}));
    if (res.ok) DOWNTIME = out;
    else problem = (out.error || {}).message || "Downtime was not saved.";
  } catch (err) { problem = "Downtime was not saved — the app may have restarted."; }
  if (redraw || problem) keepScroll(renderDowntimeCard);
  else {
    const label = $("#dt-label");
    if (label) label.textContent = DOWNTIME.label || "";
  }
  downtimeNote(problem, !!problem);
  if (!problem) tellLock(true);       // the lock hears it now, not in a minute
}

document.addEventListener("change", async (event) => {
  const on = event.target.closest("#dt-on");
  if (on) { await saveDowntime({ on: on.checked }); return; }
  const time = event.target.closest("#dt-start, #dt-end");
  if (time && time.value) await saveDowntime({ [time.id === "dt-start" ? "start" : "end"]: time.value }, false);
});

document.addEventListener("click", async (event) => {
  const day = event.target.closest("button[data-dt-day]");
  if (!day || !DOWNTIME) return;
  const picked = new Set(DOWNTIME.days || []);
  if (picked.has(day.dataset.dtDay)) picked.delete(day.dataset.dtDay);
  else picked.add(day.dataset.dtDay);
  if (!picked.size) { downtimeNote("Pick at least one day for Downtime.", true); return; }
  await saveDowntime({ days: DT_DAYS.map(([key]) => key).filter((key) => picked.has(key)) });
});

/* ==========================================================================
   Settings changed from the chat
   ==========================================================================

   [ASKED] 2026-10-07: "make it so the chat can do anything you ask it like put
   SillyBus in dark mode or simple mode or dashbord mode ext".

   The server reads the sentence (`sillybus/ai/commands.py`) and makes the
   changes that live on the server itself — Downtime, reminder times, which
   sources are read. Everything the PAGE owns comes back as `actions`, and is
   applied here THROUGH THE SETTINGS PAGE'S OWN FUNCTIONS: `setPref` for a
   preference (the same call a Settings button makes, so the same PUT, the same
   validation and the same redraw), `setFocusMode` / `saveFocus` for Focus,
   `openTab` / `showSetPage` to go somewhere. Chat and Settings therefore cannot
   disagree about what a setting is or what changing it does.

   A replayed conversation never re-applies anything: history stores the text
   only, and this runs only on a fresh reply. */
let LAST_CHAT_UNDO = null;

function chatPrefRaw(value) {
  /* setPref reads the Settings buttons' strings: "true"/"false" for a switch */
  return typeof value === "boolean" ? String(value) : value;
}

function openFromChat(action) {
  if (action.view === "settings") {
    if (window.openTab) window.openTab("settings");
    else if (window.showView) window.showView("settings");
    if (action.page && window.showSetPage) window.showSetPage(action.page);
    return;
  }
  if (action.tab && window.openTab) { window.openTab(action.tab); return; }
  if (action.view && window.showView) window.showView(action.view);
}

/* The Focus change the chat read, applied with the Settings page's own
   pieces. Chrome grants a site only inside a click, and the reply arrives
   long after the student's Enter, so in Chrome anything that needs a grant is
   a button the student presses — which asks Chrome FIRST, in the click, as
   the Settings buttons do. */
function focusChangeOrigins(action) {
  const hosts = [];
  for (const id of action.add_presets || []) {
    const p = FOCUS_PRESETS.find((x) => x.id === id);
    if (p) hosts.push(...p.hosts);
  }
  hosts.push(...(action.add_custom || []));
  if (action.mode && action.mode !== "off" && (focusNow().mode || "off") === "off") {
    hosts.push(...focusHosts({ ...focusNow(),
      sites_off: (focusNow().sites_off || []).filter((id) => !(action.add_presets || []).includes(id)),
      custom: [...(focusNow().custom || []), ...(action.add_custom || [])] }));
  }
  return focusOrigins([...new Set(hosts)]);
}

async function applyFocusChange(action, opts) {
  const focus = focusNow();
  const off = new Set(focus.sites_off || []);
  for (const id of action.add_presets || []) off.delete(id);
  for (const id of action.drop_presets || []) off.add(id);
  const custom = (focus.custom || []).filter((h) => !(action.drop_custom || []).includes(h));
  for (const h of action.add_custom || []) if (!custom.includes(h)) custom.push(h);
  const dropped = [];
  for (const id of action.drop_presets || []) {
    const p = FOCUS_PRESETS.find((x) => x.id === id);
    if (p) dropped.push(...p.hosts);
  }
  dropped.push(...(action.drop_custom || []));
  if (dropped.length && window.sdChrome && window.sdChrome.focus) {
    try { await window.sdChrome.focus.drop(focusOrigins(dropped)); } catch (err) { /* already gone */ }
  }
  const sitesChanged = (action.add_presets || []).length || (action.drop_presets || []).length
    || (action.add_custom || []).length || (action.drop_custom || []).length;
  if (sitesChanged) {
    const ok = await saveFocus({ sites_off: FOCUS_PRESETS.map((p) => p.id).filter((p) => off.has(p)), custom });
    if (!ok) return "that Focus change was not saved";
  }
  if (action.mode) {
    const ok = await setFocusMode(action.mode, opts);
    if (!ok) return "Focus stayed as it was — Settings → Focus says why";
  }
  return null;
}

async function focusFromChat(action, box) {
  if (!FOCUS_PRESETS.length) await loadFocus();
  const inChrome = !!(window.sdChrome && window.sdChrome.focus);
  if (inChrome && action.loosens && (focusNow().mode || "off") === "block"
      && FOCUS_STATUS && FOCUS_STATUS.pinSet) {
    /* Loosening Block takes the PIN (prosecution #7) — from chat as well. */
    const open = document.createElement("button");
    open.type = "button"; open.className = "proposal-undo"; open.textContent = "Open Settings → Focus";
    open.addEventListener("click", () => openFromChat({ view: "settings", page: "focus" }));
    box.append(open);
    return "Block has a PIN, so I didn't loosen it from chat — that would skip the PIN. Type it in Settings → Focus.";
  }
  const origins = focusChangeOrigins(action);
  if (inChrome && origins.length) {
    const go = document.createElement("button");
    go.type = "button"; go.className = "primary proposal-yes"; go.textContent = "Allow in Chrome and turn it on";
    go.addEventListener("click", async () => {
      go.disabled = true;
      const allowed = await window.sdChrome.focus.request(origins);
      if (!allowed) { go.replaceWith(Object.assign(document.createElement("div"),
        { className: "proposal-note", textContent: "Chrome did not allow those sites, so nothing changed." })); return; }
      const problem = await applyFocusChange(action, { granted: true });
      go.replaceWith(Object.assign(document.createElement("div"),
        { className: "proposal-note", textContent: problem || "✔ Done." }));
    });
    box.append(go);
    return "One more tap: Chrome has to allow those sites itself.";
  }
  return applyFocusChange(action);
}

async function undoChatChange(entry) {
  for (const a of [...entry.actions].reverse()) {
    await setPref(a.key, chatPrefRaw(a.previous));
  }
}

/* Called for every reply. Applies what it carries, then draws its buttons:
   Undo for preferences, the "open …" pointers, and the choices a question
   offers, each of which simply sends that sentence. */
async function applyChatActions(bubble, out) {
  const actions = Array.isArray(out.actions) ? out.actions : [];
  const choices = Array.isArray(out.choices) ? out.choices : [];
  if (!actions.length && !choices.length) return;
  const box = document.createElement("div");
  box.className = "chat-acts";
  bubble.appendChild(box);
  const done = [];
  const notes = [];
  for (const a of actions) {
    try {
      if (a.kind === "set_pref") {
        const problem = await setPref(a.key, chatPrefRaw(a.value));
        if (problem) notes.push(`That didn't save: ${problem}`); else done.push(a);
      } else if (a.kind === "focus") {
        const note = await focusFromChat(a, box);
        if (note) notes.push(note);
      } else if (a.kind === "open") {
        if (a.auto) openFromChat(a);
        else {
          const b = document.createElement("button");
          b.type = "button"; b.className = "proposal-undo"; b.textContent = `Open ${a.label || "Settings"}`;
          b.addEventListener("click", () => openFromChat(a));
          box.append(b);
        }
      }
    } catch (err) { notes.push(`That didn't save: ${err.message}`); }
  }
  if (done.length) {
    const entry = { actions: done };
    const undo = document.createElement("button");
    undo.type = "button"; undo.className = "proposal-undo"; undo.textContent = "Undo";
    undo.addEventListener("click", async () => {
      undo.disabled = true;
      await undoChatChange(entry);
      if (LAST_CHAT_UNDO === entry) LAST_CHAT_UNDO = null;
      undo.replaceWith(Object.assign(document.createElement("div"),
        { className: "proposal-note", textContent: "Put back as it was." }));
    });
    entry.button = undo;
    box.prepend(undo);
    LAST_CHAT_UNDO = entry;
  }
  for (const c of choices) {
    const b = document.createElement("button");
    b.type = "button"; b.className = "proposal-undo chat-choice"; b.textContent = c.label;
    b.addEventListener("click", () => {
      const input = $("#chat-input"), form = $("#chat-form");
      if (!input || !form) return;
      input.value = c.say;
      form.dispatchEvent(new Event("submit", { cancelable: true }));
    });
    box.append(b);
  }
  for (const n of notes) {
    box.insertAdjacentHTML("beforeend", `<div class="proposal-note">${esc(n)}</div>`);
  }
  if (!box.children.length) box.remove();
}

/* "undo" typed into the box undoes the last change chat made, without a
   round trip — the same as pressing its Undo. True when it was handled. */
const SAYS_UNDO = /^(undo|undo (that|it)|change it back|put it back|revert( that| it)?)[.! ]*$/i;
async function answerUndo(text) {
  if (!LAST_CHAT_UNDO || !SAYS_UNDO.test(text)) return false;
  const entry = LAST_CHAT_UNDO; LAST_CHAT_UNDO = null;
  const logBox = $("#chat-log");
  if (logBox) logBox.insertAdjacentHTML("beforeend", `<div class="msg user">${esc(text)}</div>`);
  await undoChatChange(entry);
  if (entry.button) entry.button.replaceWith(Object.assign(document.createElement("div"),
    { className: "proposal-note", textContent: "Put back as it was." }));
  if (logBox) {
    logBox.insertAdjacentHTML("beforeend", `<div class="msg assistant">Put back as it was.</div>`);
    logBox.scrollTop = logBox.scrollHeight;
  }
  return true;
}
