/* A deliberate local pause for Get More Time. No chat, model or allowance. */
(function (scope) {
  "use strict";
  function holdConfirm(button, progress, status, confirm, options = {}) {
    const now = options.now || (() => performance.now());
    const every = options.every || ((fn) => setInterval(fn, 100));
    const stop = options.stop || clearInterval;
    let started = null, timer = null, pending = false, key = null, pointer = null;
    let said = -1;
    const duration = 5000;
    function cancel(message = "Hold for 5 seconds when you're ready.") {
      if (timer !== null) stop(timer);
      timer = null; started = null; key = null; pointer = null; said = -1;
      progress.value = 0;
      if (!pending) status.textContent = message;
    }
    async function tick() {
      if (started === null || pending) return;
      const elapsed = Math.max(0, now() - started);
      progress.value = Math.min(duration, elapsed);
      const left = Math.max(0, Math.ceil((duration - elapsed) / 1000));
      if (left !== said) { said = left; status.textContent = left ? `Keep holding… ${left} second${left === 1 ? "" : "s"}` : "Opening your break…"; }
      if (elapsed < duration) return;
      pending = true; cancel(); button.disabled = true;
      try { await confirm(); }
      catch (e) { status.textContent = "The lock couldn't be reached. You can try again."; }
      finally { pending = false; button.disabled = false; }
    }
    function begin() {
      if (started !== null || pending || button.disabled) return;
      started = now(); said = -1; tick(); timer = every(tick);
    }
    button.addEventListener("pointerdown", e => {
      if (e.button !== 0 || pending) return;
      e.preventDefault(); button.focus(); pointer = e.pointerId;
      try { button.setPointerCapture(e.pointerId); } catch (e) { /* synthetic or old browser */ }
      begin();
    });
    for (const type of ["pointerup", "pointercancel", "lostpointercapture", "pointerleave"])
      button.addEventListener(type, e => { if (pointer === e.pointerId) cancel(); });
    button.addEventListener("keydown", e => {
      if (e.key === "Escape") { e.preventDefault(); cancel("Cancelled. No extra time was requested."); return; }
      if (e.key !== " " && e.key !== "Enter") return;
      e.preventDefault(); e.stopPropagation();
      if (e.repeat || key !== null || pending) return;
      key = e.key; begin();
    });
    button.addEventListener("keyup", e => {
      if (e.key === key) { e.preventDefault(); e.stopPropagation(); cancel(); }
    });
    button.addEventListener("click", e => e.preventDefault());
    button.addEventListener("blur", () => cancel());
    const onBlur = () => cancel();
    const onHidden = () => { if (document.hidden) cancel(); };
    scope.addEventListener("blur", onBlur);
    document.addEventListener("visibilitychange", onHidden);
    return { cancel, destroy() { cancel(); scope.removeEventListener("blur", onBlur); document.removeEventListener("visibilitychange", onHidden); } };
  }
  scope.sillybusHoldConfirm = holdConfirm;
})(window);
