/* Voice turns share the same chat actions and history as typed turns. */
(() => {
  "use strict";
  const button = document.getElementById("chat-voice");
  const status = document.getElementById("voice-status");
  const input = document.getElementById("chat-input");
  const form = document.getElementById("chat-form");
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!button || !status || !input || !form) return;
  if (!Recognition || !window.speechSynthesis || !window.SpeechSynthesisUtterance) {
    button.disabled = true;
    button.title = "Voice chat is unavailable in this browser. You can still type.";
    return;
  }
  let active = false, rec = null, waiting = false, generation = 0;
  const note = text => { status.textContent = text; };
  function stop(message = "Voice chat ended.") {
    active = false; waiting = false; generation++;
    const previous = rec; rec = null;
    if (previous) { previous.onend = null; try { previous.abort(); } catch (_) {} }
    window.speechSynthesis.cancel();
    button.textContent = "Voice chat";
    button.setAttribute("aria-pressed", "false");
    const mic = document.getElementById("chat-mic");
    if (mic) mic.disabled = false;
    note(message);
  }
  function listen() {
    if (!active || waiting || document.hidden) return;
    const epoch = generation;
    let transcript = "", failed = false;
    const recognition = new Recognition(); rec = recognition;
    recognition.lang = navigator.language || "en-US";
    recognition.interimResults = false; recognition.continuous = false;
    note("Listening… Speak, then pause to send. Your browser may process speech online. End voice chat to stop.");
    recognition.onresult = event => {
      if (!active || epoch !== generation) return;
      transcript = Array.from(event.results).filter(r => r.isFinal).map(r => r[0].transcript).join(" ").trim();
    };
    recognition.onerror = event => {
      failed = true;
      const message = event.error === "not-allowed" || event.error === "service-not-allowed"
        ? "Microphone or speech access is unavailable. Allow it in your browser settings, or type instead."
        : "Could not hear you. Start voice chat to try again, or type instead.";
      stop(message);
    };
    recognition.onend = () => {
      rec = null;
      if (!active || failed || epoch !== generation) return;
      if (!transcript) { stop("No speech heard. Start voice chat when you’re ready."); return; }
      if (input.value.trim()) { stop("Your typed draft is still here. Send it before starting voice chat."); return; }
      input.value = transcript;
      waiting = true;
      note("Thinking…");
      form.requestSubmit();
    };
    try { recognition.start(); } catch (_) { stop("Could not start the microphone. You can still type."); }
  }
  button.addEventListener("click", () => {
    if (active) { stop(); return; }
    if (input.value.trim()) { note("Send or clear your typed draft first."); return; }
    if (document.querySelector("#chat-log .pending") || document.getElementById("chat-mic")?.classList.contains("listening")) {
      note("Wait for the current chat or dictation to finish."); return;
    }
    active = true; generation++;
    button.textContent = "End voice chat";
    button.setAttribute("aria-pressed", "true");
    const mic = document.getElementById("chat-mic"); if (mic) mic.disabled = true;
    listen();
  });
  window.addEventListener("sillybus-chat-reply", event => {
    if (!active || !waiting) return;
    waiting = false;
    const text = String(event.detail?.text || "").replace(/\[([^\]]+)\]\([^)]*\)/g, "$1").replace(/[*#`]/g, "").trim();
    if (event.detail?.error || !text) { stop("The reply could not be read. See the chat and try again."); return; }
    note("Speaking…");
    const epoch = generation;
    const speech = new window.SpeechSynthesisUtterance(text.slice(0, 6000));
    speech.lang = navigator.language || "en-US";
    // Prefer the enhanced voices installed by Chrome/macOS; never impersonate a person.
    const voices = window.speechSynthesis.getVoices?.() || [];
    const language = speech.lang.toLowerCase().split("-")[0];
    const ranked = voices.filter(v => v.lang.toLowerCase().startsWith(language))
      .map(v => ({v, score: (/natural|neural|enhanced|premium/i.test(v.name) ? 8 : 0)
        + (/Google|Samantha|Ava|Serena/i.test(v.name) ? 4 : 0)
        + (v.lang.toLowerCase() === speech.lang.toLowerCase() ? 2 : 0) + (v.default ? 1 : 0)}))
      .sort((a,b) => b.score-a.score);
    if (ranked.length) speech.voice = ranked[0].v;
    speech.rate = 1; speech.pitch = 1;
    speech.onend = () => { if (active && epoch === generation) listen(); };
    speech.onerror = () => { if (epoch === generation) stop("Spoken reply unavailable. Your answer is in the chat."); };
    try { window.speechSynthesis.speak(speech); } catch (_) { stop("Spoken reply unavailable. Your answer is in the chat."); }
  });
  document.addEventListener("visibilitychange", () => { if (document.hidden && active) stop("Voice chat paused while this page is hidden."); });
  window.addEventListener("pagehide", () => stop());
  document.addEventListener("keydown", event => { if (event.key === "Escape" && active) stop(); });
})();
