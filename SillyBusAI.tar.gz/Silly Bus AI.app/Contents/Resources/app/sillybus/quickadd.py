"""Turning a sentence into a task — no model needed.

Homework that never reaches Canvas or the teacher's doc is the homework a
teacher SAID: "read chapter 4 by Friday", "quiz on Tuesday", "bring the lab
notebook tomorrow". The chat used to hand those to the AI, which meant no AI,
no way to note them. This module reads the common shapes deterministically:

    "teacher said read ch 4 by friday"        -> title, due Friday
    "add bio quiz on the 12th"                -> title, course Biology, due the 12th
    "remember: spanish worksheet tomorrow"    -> title, course Spanish, due tomorrow
    "hw: problems 1-20 due next class"        -> title, due at the next meeting

Two rules from the rest of the app carry over. A date is never guessed: only a
phrase that actually names one produces a due date, and the note says how it
was read. And nothing is written here — the result is a PROPOSAL the person
confirms with a tap (chat.py's action path), exactly like the model's.
"""

import re
from datetime import date, timedelta

WEEKDAYS = {"monday": 0, "mon": 0, "tuesday": 1, "tue": 1, "tues": 1, "wednesday": 2,
            "wed": 2, "thursday": 3, "thu": 3, "thur": 3, "thurs": 3, "friday": 4,
            "fri": 4, "saturday": 5, "sat": 5, "sunday": 6, "sun": 6}
MONTHS = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6, "jul": 7,
          "aug": 8, "sep": 9, "sept": 9, "oct": 10, "nov": 11, "dec": 12}

# Something the person is telling us to remember, as opposed to asking.
LEAD_IN = re.compile(
    r"^\s*(?:(?:please\s+)?(?:add|remember|note|record|put down|write down|log)"
    r"(?:\s+(?:that|this|down))?\s*[:\-–]?\s*"
    r"|(?:my\s+)?(?:teacher|mr\.?|ms\.?|mrs\.?|dr\.?)\s*\w*\s*(?:said|says|told us|assigned|"
    r"gave us|wants|mentioned)\s*(?:that\s+)?(?:we\s+(?:have|need to|should)\s+)?[:\-–]?\s*"
    r"|(?:hw|homework|assignment|task|todo|to-do|reminder)\s*[:\-–]\s*"
    r"|(?:we|i)\s+(?:have|got|need to|should)\s+(?:a\s+|an\s+|to\s+)?"
    r"|new\s+(?:hw|homework|assignment)\s*[:\-–]?\s*)",
    re.I)

# A sentence that is chat, not a plan: an answer, a thank-you, an opinion, or
# something that already happened. [MEASURED] 2026-10-06, review pass: "no,
# tomorrow at 5" became an event called "No", and "lol my game was on
# saturday at 3" was proposed for the calendar.
NOT_A_PLAN = re.compile(
    r"^\s*(?:i|i'm|im|my|no|nope|yes|yeah|yep|ok|okay|thanks|thank|lol|so|but|and|"
    r"also|oh|well|maybe|remind)\b|\b(?:was|were|went|had|did)\b", re.I)

# Work, not an event: a deadline ("due", "by", "turn in") or a kind of
# schoolwork. "Essay due Friday at 11:59" is homework with a time on it, and
# a calendar event would take it off the to-do list and out of the ranking.
# "by" is a deadline only with a when after it: "essay by friday", never
# "dinner by the lake friday at 6" (prosecution 2026-10-06 — that became a
# task called "Dinner by the lake at 6", with no time).
RE_DEADLINE_WORDS = re.compile(
    r"\b(?:due|turn(?:ed)? in|hand(?:ed)? in|submit)\b|"
    r"\bby\s+(?=(?:tomorrow|tonight|today|next|this|end\b|noon|midnight|the\s+\d|\d|"
    r"(?:mon|tue|tues|wed|thu|thur|thurs|fri|sat|sun)(?:day|sday|nesday|rsday|urday)?\b|"
    r"(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s*\d))", re.I)

# Work whatever else the sentence says: an event noun never turns these into
# an event. Round 2 (2026-10-07) of the prosecution: "practice test for chem
# friday at 3" became an event because "practice" is an event noun — a
# practice test is homework.
STRONG_WORK = re.compile(
    r"\b(?:test|exam|midterm|quiz(?:zes)?|essay|project|worksheet|problem set|lab report|"
    r"homework|hw|assignment|study guide)\b", re.I)

# Something that happens, not work you hand in: with one of these in the
# sentence a schoolwork-ish word ("final", "post", "#3") does not make it a
# task — "game vs #3 seed saturday at 4" is a game (prosecution 2026-10-06).
EVENT_NOUNS = re.compile(
    r"\b(?:game|practice|match|meet|tournament|scrimmage|race|dinner|lunch|breakfast|party|"
    r"concert|rehearsal|recital|appointment|meeting|show|movie|sleepover|trip|camp|tryouts?|"
    r"banquet|ceremony|service|mass|dance|fundraiser|car wash|birthday|wedding)\b", re.I)
RE_ALL_DAY = re.compile(r"\ball[- ]day\b", re.I)


def is_work(text: str) -> bool:
    text = text or ""
    if RE_DEADLINE_WORDS.search(text) or STRONG_WORK.search(text):
        return True
    return bool((category_of(text) or re.search(r"\blab\b", text, re.I)) and not EVENT_NOUNS.search(text))


# How a question starts. A sentence that opens like this is asked, not told.
# …and a sentence that opens with a command is asking for something to be
# DONE: "cancel practice friday at 5" is not a new event called "Cancel
# practice", nor is "make me a study plan for friday at 4" (prosecution
# 2026-10-06 — both took over the chat).
# Round 2 (2026-10-07): words that are also nouns ("Mark's party", "set crew
# rehearsal", "plan B meeting", "check-up") count as commands only with an
# object after them, and no command word counts before an apostrophe or a
# hyphen ("move-in day", "Mark's").
QUESTION_LEAD = re.compile(
    r"^\s*(?:(?:what|when|where|which|who|how)(?:['’]s|s)?\b"
    r"|(?:why|do|does|did|is|are|was|were|can|"
    r"could|should|will|would|have|has|am|tell|show|list|explain|help|"
    r"cancel|move|delete|remove|reschedule|change|make|give|create|find|tick|undo|"
    r"update|rename|edit)\b(?![-'’])"
    r"|(?:mark|set|plan|check|quiz|push|skip)\s+(?:my|the|a|an|it|that|this|me|all|up|out|off)\b)",
    re.I)

WHEN = re.compile(
    r"(?P<lead>\b(?:due|by|for|before|on|until|this|next|coming)\s+)?"
    r"(?P<when>"
    r"tomorrow|tonight|today|day after tomorrow|"
    r"(?:next|this)\s+(?:class|meeting|period|week|monday|tuesday|wednesday|thursday|friday|saturday|sunday)|"
    r"end of (?:the |this )?week|"
    r"in\s+(?:a|an|\d+)\s+(?:day|days|week|weeks)|"
    r"(?:mon|tue|tues|wed|thu|thur|thurs|fri|sat|sun)(?:day|sday|nesday|rsday|urday)?\b\.?|"
    r"\d{4}-\d{2}-\d{2}|"
    r"\d{1,2}/\d{1,2}(?:/\d{2,4})?|"
    r"(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s+\d{1,2}(?:st|nd|rd|th)?|"
    r"\d{1,2}(?:st|nd|rd|th)\s+(?:of\s+)?(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*|"
    r"the\s+\d{1,2}(?:st|nd|rd|th)"
    r")\b", re.I)

CATEGORY_WORDS = [
    ("test", re.compile(r"\b(test|exam|midterm|final)\b", re.I)),
    ("quiz", re.compile(r"\bquiz(?:zes)?\b", re.I)),
    ("project", re.compile(r"\bproject\b", re.I)),
    ("essay", re.compile(r"\b(essay|paper|composition)\b", re.I)),
    ("problem_set", re.compile(r"\b(problems?|problem set|worksheet|ws|exercises?|#\s?\d)\b", re.I)),
    ("reading", re.compile(r"\b(read|reading|chapter|ch\.?|pages?|pp\.?)\b", re.I)),
    ("discussion", re.compile(r"\b(discussion|post|reply)\b", re.I)),
]


def _school_year_date(month: int, day: int, today: date) -> date | None:
    """A month/day with no year lands in the school year that contains today:
    August–December in the year that started, January–July in the next."""
    for year in (today.year, today.year + 1, today.year - 1):
        try:
            candidate = date(year, month, day)
        except ValueError:
            continue
        # prefer the nearest date that is not far in the past
        if candidate >= today - timedelta(days=45):
            return candidate
    try:
        return date(today.year, month, day)
    except ValueError:
        return None


def parse_when(phrase: str, today: date, meetings=None, course: str | None = None
               ) -> tuple[str | None, str]:
    """(ISO date or None, note). `meetings` is a MeetingIndex for "next class"."""
    text = (phrase or "").strip().lower().rstrip(".")
    if not text:
        return None, "no date given"
    if text in ("today", "tonight"):
        return today.isoformat(), f"'{phrase}' = {today:%a %b %d}"
    if text == "tomorrow":
        when = today + timedelta(days=1)
        return when.isoformat(), f"'tomorrow' = {when:%a %b %d}"
    if text == "day after tomorrow":
        when = today + timedelta(days=2)
        return when.isoformat(), f"'{phrase}' = {when:%a %b %d}"
    if text in ("next class", "next meeting", "next period", "this class"):
        if meetings is not None and course:
            try:
                following = meetings.next_after(course, today)
            except Exception:  # noqa: BLE001
                following = None
            if following:
                return following.isoformat(), f"next {course} class = {following:%a %b %d}"
        return None, "'next class' — say which class so the date can be looked up"
    if text in ("end of week", "end of the week", "end of this week"):
        ahead = (4 - today.weekday()) % 7
        when = today + timedelta(days=ahead)
        return when.isoformat(), f"end of the week = {when:%a %b %d}"
    if text in ("next week", "this week"):
        return None, f"'{phrase}' is not a day — say which day"
    match = re.fullmatch(r"in\s+(a|an|\d+)\s+(day|days|week|weeks)", text)
    if match:
        count = 1 if match.group(1) in ("a", "an") else int(match.group(1))
        days = count * (7 if match.group(2).startswith("week") else 1)
        when = today + timedelta(days=days)
        return when.isoformat(), f"'{phrase}' = {when:%a %b %d}"
    match = re.fullmatch(r"(next|this)\s+([a-z]+)", text)
    if match and match.group(2) in WEEKDAYS:
        target = WEEKDAYS[match.group(2)]
        ahead = (target - today.weekday()) % 7 or 7
        when = today + timedelta(days=ahead)
        if match.group(1) == "next" and ahead < 7 and today.weekday() >= 4:
            pass  # "next Tuesday" said on a Friday means the coming one; keep
        return when.isoformat(), f"'{phrase}' = {when:%a %b %d}"
    word = re.sub(r"\.$", "", text)
    if word in WEEKDAYS:
        target = WEEKDAYS[word]
        ahead = (target - today.weekday()) % 7 or 7
        when = today + timedelta(days=ahead)
        return when.isoformat(), f"'{phrase}' = the coming {when:%A}, {when:%b %d}"
    match = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", text)
    if match:
        try:
            when = date(int(match.group(1)), int(match.group(2)), int(match.group(3)))
        except ValueError:
            return None, f"'{phrase}' is not a real date"
        return when.isoformat(), f"date given as {when:%a %b %d %Y}"
    match = re.fullmatch(r"(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?", text)
    if match:
        month, day = int(match.group(1)), int(match.group(2))
        if match.group(3):
            year = int(match.group(3))
            year += 2000 if year < 100 else 0
            try:
                when = date(year, month, day)
            except ValueError:
                return None, f"'{phrase}' is not a real date"
        else:
            when = _school_year_date(month, day, today)
            if when is None:
                return None, f"'{phrase}' is not a real date"
        return when.isoformat(), f"'{phrase}' = {when:%a %b %d %Y}"
    match = re.fullmatch(r"([a-z]+)\.?\s+(\d{1,2})(?:st|nd|rd|th)?", text)
    if match and match.group(1)[:3] in MONTHS and (
            match.group(1)[:4] in ("sept",) or match.group(1)[:3] in MONTHS):
        month = MONTHS.get(match.group(1)[:4], MONTHS.get(match.group(1)[:3]))
        when = _school_year_date(month, int(match.group(2)), today)
        if when is None:
            return None, f"'{phrase}' is not a real date"
        return when.isoformat(), f"'{phrase}' = {when:%a %b %d %Y}"
    match = re.fullmatch(r"(\d{1,2})(?:st|nd|rd|th)\s+(?:of\s+)?([a-z]+)", text)
    if match and match.group(2)[:3] in MONTHS:
        month = MONTHS.get(match.group(2)[:4], MONTHS.get(match.group(2)[:3]))
        when = _school_year_date(month, int(match.group(1)), today)
        if when is None:
            return None, f"'{phrase}' is not a real date"
        return when.isoformat(), f"'{phrase}' = {when:%a %b %d %Y}"
    match = re.fullmatch(r"the\s+(\d{1,2})(?:st|nd|rd|th)", text)
    if match:
        day = int(match.group(1))
        month, year = today.month, today.year
        if day < today.day:
            month = month % 12 + 1
            year += 1 if month == 1 else 0
        try:
            when = date(year, month, day)
        except ValueError:
            return None, f"'{phrase}' is not a real date"
        return when.isoformat(), f"'{phrase}' = the next {day}th, {when:%a %b %d}"
    return None, f"could not read '{phrase}' as a date"


def _short(name: str) -> str:
    return (name or "").split("-")[0].replace("Advanced Placement", "AP").strip()


COURSE_ALIASES = {
    "bio": "biology", "chem": "chemistry", "phys": "physics", "alg": "algebra",
    "geo": "geometry", "calc": "calculus", "eng": "english", "lit": "literature",
    "hist": "history", "gov": "government", "econ": "economics", "span": "spanish",
    "psych": "psychology", "comp sci": "computer science", "cs": "computer science",
    "apush": "united states history", "scrip": "scripture", "theo": "theology",
    "rel": "religion", "pe": "physical education", "s&c": "strength and conditioning",
}


def match_course(text: str, state: dict) -> tuple[str | None, str | None]:
    """(display name, course_key) of the one course the text names, or Nones.
    Two matches is ambiguous and gets no course rather than a coin-flip."""
    lowered = f" {(text or '').lower()} "
    for alias, full in COURSE_ALIASES.items():
        lowered = re.sub(rf"\b{re.escape(alias)}\b", full, lowered)
    words = set(re.findall(r"[a-z&]+", lowered))
    names: dict[str, str] = {}
    for profile in state.get("profiles") or []:
        display = profile.get("display_name") or profile.get("course_raw") or ""
        if profile.get("course_key") and display:
            names[profile["course_key"]] = display
    for item in state.get("items") or []:
        if item.get("course_key") and item.get("course") and item["course_key"] not in names:
            names[item["course_key"]] = _short(item["course"])
    hits = []
    for key, display in names.items():
        tokens = {w for w in re.findall(r"[a-z&]+", display.lower())
                  if len(w) > 2 and w not in ("honors", "advanced", "placement", "and", "the",
                                              "period", "training", "essentials")}
        if tokens and tokens & words:
            hits.append((len(tokens & words), key, display))
    if not hits:
        return None, None
    hits.sort(reverse=True)
    if len(hits) > 1 and hits[0][0] == hits[1][0]:
        return None, None
    return _short(hits[0][2]), hits[0][1]


# A time of day. [ASKED] 2026-10-06: "make it as easy to add stuff using the
# chat" — on the calendar, which means "practice Thursday at 5" has to land AT
# 5. Recognised only with something that makes it a time: "at"/"@"/"from"
# before it, a.m./p.m. after it, or minutes ("4:30"). So "problems 1-20" and
# "chapter 4" are never read as times.
RE_TIME = re.compile(
    r"(?:(?P<lead>\b(?:at|from)\s+|@\s*)|(?<![\w/:#.-]))"
    r"(?P<h1>\d{1,2})(?::(?P<m1>[0-5]\d))?\s*(?P<ap1>[ap]\.?m\.?)?"
    r"(?:\s*(?:-|–|to|until|till)\s*"
    r"(?P<h2>\d{1,2})(?::(?P<m2>[0-5]\d))?\s*(?P<ap2>[ap]\.?m\.?)?)?"
    r"(?![\w/]|[:.]\d)", re.I)


# "tonight at 8", "saturday night at 8", "this evening at 7": the hour is
# p.m. whatever the student default says (prosecution 2026-10-06 — "movie
# tonight at 8" landed at 8 in the morning).
# Only an evening said OF A DAY: "Night of the Arts rehearsal saturday at 10"
# is not 10 at night (round 2, 2026-10-07).
RE_EVENING = re.compile(
    r"\btonight\b|\b(?:this|tomorrow|mon|tues|wednes|thurs|fri|satur|sun)(?:day)?\s+(?:night|evening)\b"
    r"|\bin the evening\b|\bat night\b", re.I)
RE_NOON = re.compile(r"(?P<lead>\b(?:at|by)\s+)?\b(?P<word>noon|midday|midnight)\b", re.I)


def _as_24(hour: int, meridiem: str | None, after: int | None = None,
           evening: bool = False) -> tuple[int, bool] | None:
    """(hour 0-23, was it guessed). With a.m./p.m. it is read as written.
    Without, a student's hour: 1-7 is afternoon or evening, 8-11 morning, 12
    noon; an END hour with none keeps to the afternoon when its start did."""
    if meridiem:
        if not 1 <= hour <= 12:
            return None
        return (hour % 12) + (12 if meridiem.lower().startswith("p") else 0), False
    if hour > 23:
        return None
    if hour > 12 or hour == 0:
        return hour, False
    if after is not None:
        # The first clock reading after the start: "11 to 1" ends at 13:00.
        for candidate in (hour % 12, hour % 12 + 12):
            if candidate > after:
                return candidate, True
        return None
    if hour == 12:
        return 12, True
    if evening:
        return hour + 12, True
    return hour + (12 if hour <= 7 else 0), True


def read_time(text: str):
    """(start "HH:MM", end "HH:MM" or None, the phrase, a note) or None.

    A bare hour is read the way a student means it (see _as_24), and the note
    SAYS it was read that way — "at 8" meaning 8 at night is then one edit,
    not a silent wrong time."""
    evening = bool(RE_EVENING.search(text or ""))
    for match in RE_TIME.finditer(text or ""):
        h1, m1, ap1 = match.group("h1"), match.group("m1"), match.group("ap1")
        h2, m2, ap2 = match.group("h2"), match.group("m2"), match.group("ap2")
        # Something has to make it a time rather than a number.
        if not (match.group("lead") or ap1 or ap2 or m1 or m2):
            continue
        # "from" also opens a page range: "problems from 1-20", "notes from 3
        # sources" ([MEASURED] 2026-10-06, review pass — both became events).
        # A bare-number "from" is a time only as a short span of clock hours.
        lead = (match.group("lead") or "").strip().lower()
        if lead == "from" and not (ap1 or ap2 or m1 or m2):
            if not h2 or int(h1) > 12 or int(h2) > 12:
                continue
            if (int(h2) - int(h1)) % 12 > 4:
                continue
        # "4-6pm": the start takes whichever reading comes just BEFORE the end
        # — 4 p.m. for "4-6pm", but 10 a.m. for "10-12pm", which used to read
        # as 10 at night with the end thrown away (prosecution 2026-10-06).
        if not ap1 and h2 and ap2:
            end_said = _as_24(int(h2), ap2)
            if end_said is None or not 1 <= int(h1) <= 12:
                continue
            end_minutes = end_said[0] * 60 + int(m2 or 0)
            options = [h for h in (int(h1) % 12, int(h1) % 12 + 12) if h * 60 + int(m1 or 0) < end_minutes]
            if not options:
                continue
            first = (max(options), False)
        else:
            first = _as_24(int(h1), ap1, evening=evening)
        if first is None:
            continue
        start_h, guessed = first
        start = f"{start_h:02d}:{int(m1 or 0):02d}"
        end = None
        if h2:
            second = _as_24(int(h2), ap2, after=None if ap2 else start_h)
            if second is not None:
                end = f"{second[0]:02d}:{int(m2 or 0):02d}"
                if end <= start:
                    end = None
        phrase = match.group(0).strip()
        pretty = _pretty(start) + (f"–{_pretty(end)}" if end else "")
        note = (f"'{phrase}' read as {pretty}" if guessed else f"at {pretty}, as you said")
        return start, end, phrase, note
    # "at noon", "midnight" — words, not numbers (prosecution 2026-10-06:
    # "lunch with grandma saturday at noon" became a to-do).
    for word in RE_NOON.finditer(text or ""):
        before = (text or "")[:word.start()].rstrip().lower()
        # "until midnight", "8 to midnight": an end, not a start.
        if re.search(r"\b(?:until|till|til|to)$|-$", before):
            continue
        if word.group("word").lower() == "midnight":
            # "Friday at midnight" is the end of Friday, not the start of it —
            # 00:00 put it a day early (round 2, 2026-10-07). Only after at/by.
            if not word.group("lead"):
                continue
            return "23:59", None, word.group(0).strip(), "at midnight (11:59 PM), as you said"
        return "12:00", None, word.group(0).strip(), f"at {_pretty('12:00')}, as you said"
    return None


def _pretty(hhmm: str) -> str:
    h, m = map(int, hhmm.split(":"))
    return f"{h % 12 or 12}:{m:02d} {'PM' if h >= 12 else 'AM'}"


def category_of(title: str) -> str | None:
    for name, pattern in CATEGORY_WORDS:
        if pattern.search(title or ""):
            return name
    return None


# After an "i have / i need to / remember / add" lead-in, what is clearly not
# a thing to do: a question, wanting to KNOW something, a grade, "a question
# about…", "nothing". Round 3 (2026-10-07): "i got a 90 on my bio quiz" became
# a task "90 on my quiz", "i need to know what's due tomorrow" a task "Know
# what's", "add up my grades" a task "Up my grades".
NOT_A_TASK_BODY = re.compile(
    r"^\s*(?:know|ask|find out|see (?:if|what|when)|check (?:if|what|when)|figure out|"
    r"understand|wonder|question|questions|problem|idea|doubt|nothing|no\s|none|"
    r"up\b|a\s+(?:\d+|[a-f][+-]?)\b|an?\s+[a-f][+-]?\s+on\b|\d+\s*(?:%|percent|/|out of|on)\b)", re.I)


def parse(message: str, state: dict, today: date, meetings=None) -> dict | None:
    """A task proposal from a sentence, or None when the sentence is not one.

    Returns {"title", "due_date", "date_note", "course", "course_key",
    "category", "when_phrase", "start", "end", "time_note"}. A sentence that
    names a TIME is an event for the calendar, not a task (chat.py decides). Only fires on a lead-in ("add…", "teacher
    said…", "hw:…") so ordinary questions are never mistaken for tasks.
    """
    text = (message or "").strip()
    lead = LEAD_IN.match(text)
    if lead:
        body = text[lead.end():].strip().strip('"\'')
        if QUESTION_LEAD.match(body) or NOT_A_TASK_BODY.match(body) or body.endswith("?"):
            return None
        # "i have / we got / i need to…" is a statement first and a plan only
        # when it names a day or a piece of work.
        if re.match(r"\s*(?:we|i)\s", text, re.I) and not (WHEN.search(body) or is_work(body)):
            return None
    elif ((read_time(text) or RE_ALL_DAY.search(text)) and WHEN.search(text)
          and not text.endswith("?") and not QUESTION_LEAD.match(text)
          and not NOT_A_PLAN.search(text) and not is_work(text)):
        # "soccer practice thursday at 5" — a day AND a time, said as a
        # statement, is something to put on the calendar even without "add".
        # Still only a proposal: nothing is written until he taps Add.
        body = text.strip('"\'')
    else:
        return None
    if len(body) < 3 or body.endswith("?"):
        return None

    course, course_key = match_course(body, state)
    # A time first, so "at 5" is out of the title before the date is read.
    start = end = time_note = None
    all_day = False
    work = is_work(body)
    clock = read_time(body)
    if clock and work:
        # Homework keeps no start time (it is a to-do, ranked by its date),
        # but "at 3" is not part of its name either: "Practice test for chem
        # at 3" (round 2, 2026-10-07).
        body = re.sub(r"\s+", " ", body.replace(clock[2], " ", 1)).strip()
        clock = None
    if clock:
        start, end, phrase, time_note = clock
        body = re.sub(r"\s+", " ", body.replace(phrase, " ", 1)).strip()
    elif RE_ALL_DAY.search(body) and not work:
        # "Race on Oct 10 all day" — the calendar's own wording for a day
        # with no time; an event, not a task.
        all_day = True
        body = re.sub(r"\s+", " ", RE_ALL_DAY.sub(" ", body)).strip()
        time_note = "all day, as you said"
    due_date, note, when_phrase = None, "no date given", None
    # take the LAST date phrase — "read ch 4 (assigned today) by friday"
    matches = list(WHEN.finditer(body))
    if matches:
        match = matches[-1]
        when_phrase = match.group("when")
        due_date, note = parse_when(when_phrase, today, meetings, course)
        if due_date or "could not read" not in note:
            body = (body[:match.start()] + body[match.end():]).strip()
            # "on Fri, Oct 9" names one day twice; every phrase that lands on
            # the same day comes out of the title, not just the last one.
            # A phrase naming a DIFFERENT day stays — it is part of the work.
            if due_date:
                for other in reversed(list(WHEN.finditer(body))):
                    if parse_when(other.group("when"), today, meetings, course)[0] == due_date:
                        body = (body[:other.start()] + body[other.end():]).strip()
    title = re.sub(r"\s+", " ", body).strip(" ,.;:-–")
    plain_title = title
    # drop the course's own name from the title when it was recognised —
    # "bio quiz" is a quiz filed under Biology, not a quiz called "bio quiz"
    if course:
        course_words = {w.lower() for w in re.findall(r"[A-Za-z&]+", course)
                        if len(w) > 2 and w.lower() not in ("honors", "advanced", "placement")}
        aliases = {alias for alias, full in COURSE_ALIASES.items()
                   if set(full.split()) & course_words}
        pattern = r"\b(?:for|in)?\s*(?:" + "|".join(
            re.escape(w) for w in sorted(course_words | aliases, key=len, reverse=True)) \
            + r")\b\s*[:\-–]?\s*"
        stripped = re.sub(pattern, " ", title, flags=re.I)
        stripped = re.sub(r"\s+", " ", stripped).strip(" ,.;:-–")
        title = stripped or title
    if not title:
        return None
    title = title[0].upper() + title[1:]
    return {"title": title[:110], "due_date": due_date, "date_note": note,
            "course": course, "course_key": course_key,
            "category": category_of(title), "when_phrase": when_phrase,
            "start": start, "end": end, "time_note": time_note, "all_day": all_day,
            # An event keeps every word he said: "Mountain bike race" is the
            # name of the race even when he is on a Mountain Bike team.
            "plain_title": (plain_title[:1].upper() + plain_title[1:])[:140]}
