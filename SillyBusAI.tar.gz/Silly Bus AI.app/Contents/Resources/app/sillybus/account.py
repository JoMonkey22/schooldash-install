"""The account gate: SillyBus AI requires a signed-in account to open.

What lives where, and why:
  - The account itself is online, so one login works on any Mac you install on.
  - The token it hands back is cached in data/session.json and trusted until
    it expires, so the dashboard still opens on the school wifi, on a plane,
    or whenever the account server is down. A homework list that refuses to
    load because a server 2000 miles away is having a bad day would be worse
    than no gate at all.
  - No homework ever goes the other way. This module sends an email and a
    password, and receives a token. That is the whole conversation.
"""

import json
import time
import httpx

from sillybus import config, paths, plans
from sillybus.logging_setup import get
from sillybus import plans

log = get("account")

TIMEOUT = 15


class AccountError(RuntimeError):
    """Carries the server's own wording so the UI never invents a reason."""

    def __init__(self, message: str, code: str = "error"):
        super().__init__(message)
        self.code = code


# Shown before anyone has signed in, when the server has not said its price yet.
# The price and the plan live in plans.py, which is also where the allowance
# is computed from — two files holding one price disagree eventually, and the
# amount on the paywall has to be the amount the allowance was sized against.
PRICE_FALLBACK = plans.price_of(plans.DEFAULT_PLAN)


def server_url() -> str:
    url = (config.load().get("account") or {}).get("server") or ""
    return url.rstrip("/")


def _call(method: str, action: str, payload: dict | None = None,
          token: str | None = None) -> dict:
    """One request to the account server, whichever build this is.

    Through `httpx`, deliberately. [MEASURED] 2026-09-28: this used
    `urllib.request`, which the Chrome extension build cannot use at all —
    WebAssembly Python has no sockets, and `extension/py/_shims/httpx.py` is
    the one transport the extension replaces with the browser's own XHR. So
    inside Chrome every call here failed before it left the page, and the
    gate said "could not reach SillyBus AI" to a person typing the right
    password. Every other network call in the app already goes through
    httpx; this was the last one that did not.
    """
    base = server_url()
    if not base:
        raise AccountError(
            "no account server is configured — set account.server in config.json",
            "not_configured")
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        # `json=`, not pre-encoded bytes. [MEASURED] 2026-09-28: Python bytes
        # handed to the browser's XHR through Pyodide arrive as an object, not
        # a body, and the server answered "expected JSON" to a perfectly good
        # request. Letting the transport encode it is right for both builds.
        response = httpx.request(method, f"{base}/api/{action}", headers=headers,
                                 json=payload, timeout=TIMEOUT)
    except httpx.HTTPError as exc:
        raise AccountError(
            "could not reach the account server — check your internet",
            "offline") from exc
    except OSError as exc:
        raise AccountError("could not reach the account server", "offline") from exc
    try:
        body = json.loads(response.text or "{}")
    except ValueError as exc:
        if response.status_code >= 400:
            raise AccountError(f"the account server said {response.status_code}",
                               "server_error") from exc
        raise AccountError("the account server sent something unreadable",
                           "server_error") from exc
    if response.status_code >= 400:
        raise AccountError((body.get("message") if isinstance(body, dict) else None)
                           or f"the account server said {response.status_code}",
                           (body.get("error") if isinstance(body, dict) else None)
                           or "server_error")
    return body if isinstance(body, dict) else {}


def _get(action: str, token: str) -> dict:
    """An authenticated GET. Only /me needs one, and only to learn whether a
    payment has landed since the cached token was issued."""
    return _call("GET", action, token=token)


def _post(action: str, payload: dict) -> dict:
    return _call("POST", action, payload)


def _store(data: dict) -> dict:
    # The subscription travels inside the signed token, so it is cached with it
    # and enforced offline. Nothing here is trusted for being in the file: the
    # server signed these claims, and `subscription()` re-reads them from the
    # token rather than from the convenience copy below.
    session = {"email": data["email"], "token": data["token"],
               "expires": int(data.get("expires") or 0),
               "subscription": data.get("subscription") or {},
               "price": data.get("price") or {},
               "pay_to": data.get("pay_to") or ""}
    target = paths.session_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(".tmp")
    tmp.write_text(json.dumps(session, indent=2), encoding="utf-8")
    tmp.replace(target)
    # the token is a credential; nothing about it is logged beyond who signed in
    log.info("signed in as %s", session["email"])
    return session


def _claims(token: str) -> dict:
    """The token's payload, read WITHOUT verifying the signature.

    Verification needs the server's secret, which by design never leaves the
    server, so this cannot be a security check and is not used as one: the
    server re-checks the signature on every call, and the worst a locally-edited
    token achieves is a dashboard that shows itself as paid while the server
    refuses it. Kept because the offline gate has to read `paid_until` from
    somewhere, and the token is the only copy the server actually signed.
    """
    import base64
    try:
        payload = token.split(".")[0]
        padding = "=" * (-len(payload) % 4)
        return json.loads(base64.urlsafe_b64decode(payload + padding))
    except (ValueError, IndexError, TypeError):
        return {}


def subscription() -> dict:
    """Where this account stands: trial, paid, lapsed, or no account at all.

    `days_left` is what the UI counts down; it is deliberately floor-ed, so
    "1 day left" never means "expired four hours ago".
    """
    session = current()
    if session is None:
        # The PRICE shown is the default plan's, because that is what the
        # paywall is offering. The PLAN is Free, because that is what an
        # account with no session is entitled to — `allowance._plan_key()`
        # reads this field, and returning "basic" here handed Basic's
        # allowance to anyone not signed in. Harmless while only
        # `anthropic_api` is metered and the gate is on; not something to
        # leave sitting there. [PROSECUTION 2026-09-11, COUNT 4]
        return {"state": "signed_out", "days_left": None, "until": None,
                "price": PRICE_FALLBACK, "pay_to": "",
                "plan": plans.FREE_PLAN,
                "plan_name": plans.plan(plans.FREE_PLAN)["name"],
                "plans": plans.for_display()}
    claims = _claims(session.get("token") or "")
    state = claims.get("sub") or "trial"
    paid_until = claims.get("paid_until")
    trial_until = claims.get("trial_until")
    now_ms = time.time() * 1000
    # Recomputed from the dates, not taken on trust: a token minted three weeks
    # ago said "trial" when it was issued and must not still say so today.
    if paid_until and paid_until > now_ms:
        state, until = "paid", paid_until
    elif trial_until and trial_until > now_ms:
        state, until = "trial", trial_until
    elif paid_until or trial_until:
        state, until = "lapsed", None
    else:
        until = None
    days = int((until - now_ms) // 86_400_000) if until else None
    # `plan` comes from the signed token when the account server sets one, so
    # it cannot be edited locally to buy a bigger allowance for free.
    # A lapsed account is on the FREE plan, not on nothing. Before the free
    # tier this function's caller locked the whole dashboard when a trial ran
    # out — the board, the schedule and the grades along with the AI, none of
    # which cost anyone anything to run. Now the plan resolves to `free` and
    # `allowance.py` is what limits them, which is the only thing that ever
    # actually costs money. *"lest do 10c for the free one"*, 2026-09-10.
    #
    # The signed token still decides a PAID plan, so this cannot be edited
    # locally to buy a bigger allowance: `free` is the floor, never a promotion.
    plan_key = claims.get("plan") or session.get("plan") or plans.DEFAULT_PLAN
    # `signed_out` is NOT checked here: that state returns from the top of
    # this function, above, so naming it was dead code pretending to cover a
    # case. [PROSECUTION 2026-09-11, COUNT 4]
    if state == "lapsed":
        plan_key = plans.FREE_PLAN
    return {"state": state, "days_left": days, "until": until,
            # plans.py wins over whatever the account server last said. The
            # two must agree, and only one of them also decides how much AI
            # the plan includes — a paywall showing $5.99 for an allowance
            # priced at $4.99 is worse than either number alone. [MEASURED]
            # 2026-09-03: the server still returns 5.99 and cannot be
            # redeployed while Netlify refuses deploys, so this is not
            # hypothetical.
            "price": plans.price_of(plan_key),
            "server_price": session.get("price"),
            "pay_to": session.get("pay_to") or "",
            "plan": plan_key,
            "plan_name": plans.plan(plan_key)["name"],
            "plans": plans.for_display(),
            "email": session.get("email")}


def entitled() -> bool:
    """Whether the dashboard should open.

    Anyone signed in, since the free tier. What a lapsed account loses is the
    model allowance, not the app: the board, every date on it, the schedule,
    grades, links, ticking work off and the three-in-five chat questions
    answered without a model all cost nothing to serve, so taking them away
    was punishing someone for not paying rather than declining to spend on
    them. `allowance.py` holds the line where the line actually is.

    Signing OUT still closes it — that is the account gate, not the paywall.
    """
    return subscription()["state"] in ("trial", "paid", "lapsed")


def refresh_subscription() -> dict:
    """Ask the server where things stand and cache the answer.

    Needed because the token is trusted for thirty days: without this, someone
    who paid five minutes ago would stay locked out until it expired. Failing is
    fine and silent — the cached token is still valid, which is the whole point
    of caching it.
    """
    session = current()
    if session is None or not server_url():
        return subscription()
    try:
        fresh = _get("me", session["token"])
    except AccountError as exc:
        if exc.code == "invalid_token":
            # The server refused this token outright — the password was reset
            # somewhere else, or the account is gone. Keeping it would leave a
            # Mac signed in that the owner meant to sign out (round 3).
            log.info("the account server refused the cached token — signing out")
            sign_out()
            return subscription()
        log.info("could not refresh the subscription (%s) — using the cached token",
                 exc.code)
        return subscription()
    if fresh.get("token"):
        _store({"email": fresh.get("email") or session["email"], **fresh})
    return subscription()


RENEW_WITHIN_MS = 7 * 24 * 3600 * 1000
RENEW_RETRY_S = 6 * 3600
_last_renew_try = 0.0


def renew_if_due() -> None:
    """Swap the cached token for a fresh one when it has under a week left.

    Prosecution round 3, 2026-10-07: nothing called `refresh_subscription()`
    in normal use — only the paywall's "I've paid" button — so every student
    was signed out thirty days after signing in, however often they opened
    the app. Cheap when not due (one file read); at most one try every six
    hours when it is, and failing is silent: the cached token still works.
    """
    global _last_renew_try
    session = current()
    if session is None or not server_url():
        return
    expires = int(session.get("expires") or 0)
    if not expires or expires - time.time() * 1000 > RENEW_WITHIN_MS:
        return
    if time.time() - _last_renew_try < RENEW_RETRY_S:
        return
    _last_renew_try = time.time()
    try:
        import threading
        threading.Thread(target=refresh_subscription, daemon=True,
                         name="renew-session").start()
    except RuntimeError:
        # WebAssembly Python (the Chrome extension build) has no threads.
        refresh_subscription()


def sign_up(email: str, password: str) -> dict:
    return _store(_post("signup", {"email": email, "password": password}))


def sign_in(email: str, password: str) -> dict:
    return _store(_post("login", {"email": email, "password": password}))


def recover(email: str, code: str, password: str) -> dict:
    """Set a new password with the recovery code, and sign in.

    [ASKED] 2026-09-24: *"add a way for password recovery"*, after the licence
    check locked him out of the Chrome extension while his homework — all of
    it already on his own Mac — sat behind it. There was no way back: no
    reset, no "forgot password", nothing at all.

    Recovering **signs you in**, deliberately. Being locked out is the problem
    being solved; finishing by asking the person to type the password they
    just chose, into the screen that would not let them in, is the problem
    again with an extra step.

    The server hands back a FRESH code, because the one just used is spent and
    nobody should come out of recovery with no way to do it again. It is
    returned to the caller to show once; nothing here writes it down.
    """
    answer = _post("reset", {"email": email, "code": code, "password": password})
    # The fresh code goes back to the caller to show once, and is NOT stored:
    # `_store` keeps only what the session needs (round 3 — it used to drop
    # the code here too, so the "write it down" note never appeared).
    return {**_store(answer), "recovery_code": answer.get("recovery_code") or ""}


def forgot(email: str) -> dict:
    """Ask the server to email a recovery code to the address on the account.

    [ASKED] 2026-09-28: *"I want the code to be sent to an email not a need
    for a terminal prompt"*. The server answers the same whether or not the
    address has an account; the one thing it is not quiet about is having no
    mail provider, because a person waiting for a mail that can never come is
    the worse outcome. Nothing comes back here but a sentence.
    """
    return _post("forgot", {"email": email})


def sign_out() -> None:
    target = paths.session_path()
    if target.exists():
        target.unlink()
    log.info("signed out")


def current() -> dict | None:
    """The signed-in account, or None. Expiry is enforced here, offline."""
    target = paths.session_path()
    if not target.exists():
        return None
    try:
        session = json.loads(target.read_text(encoding="utf-8"))
    except ValueError:
        log.warning("session.json is unreadable — treating as signed out")
        return None
    if not session.get("token") or not session.get("email"):
        return None
    expires = int(session.get("expires") or 0)
    if expires and expires < time.time() * 1000:
        log.info("the cached session expired")
        return None
    return session


def required() -> bool:
    """Whether the gate is on. Off means no account server is configured, which
    is how a solo install keeps working."""
    account = config.load().get("account") or {}
    if not account.get("server"):
        return False
    return bool(account.get("required", True))


def redeem(code: str) -> dict:
    """Trade a free-access code for a subscription.

    Identified by the signed token rather than a posted email: the person is
    already signed in when they see the paywall, and asking for their password
    again to type a promo code would be theatre.
    """
    session = current()
    if session is None:
        raise AccountError("sign in first", "signed_out")
    try:
        body = _call("POST", "redeem", {"code": code}, token=session["token"])
    except AccountError as exc:
        if exc.code in ("offline", "not_configured"):
            raise
        raise AccountError(str(exc) if exc.code != "server_error"
                           else "that code did not work",
                           exc.code if exc.code != "server_error" else "bad_code") from exc
    _store({"email": body.get("email") or session["email"], **body})
    return {"subscription": subscription(), "message": body.get("message") or ""}


def cli_grant(email: str, months: int = 1, plan: str | None = None) -> int:
    """Switch a classmate's subscription on after they have paid you.

    The admin secret lives in the environment, never in config.json: config.json
    is read by every install and this secret grants access to all of them.

    `plan` is what they paid for — the allowance rides in the signed token, so
    a bigger allowance cannot be granted locally by editing a file.
    """
    import os

    secret = os.environ.get("SILLYBUS_ADMIN_SECRET", "")
    if not secret:
        print("SILLYBUS_ADMIN_SECRET is not set in this shell.")
        print("It is the password that switches subscriptions on, so it lives in")
        print("the environment rather than in config.json — every install reads")
        print("config.json, and this must not be one of the things they read.")
        print("\n  export SILLYBUS_ADMIN_SECRET='the value set on Netlify'")
        return 1
    try:
        chosen = plans.plan(plan)["key"]
        if plan and chosen != (plan or "").strip().lower():
            print(f"'{plan}' is not a plan — using {chosen}. "
                  f"Choices: {', '.join(plans.PLANS)}")
        result = _post("grant", {"email": email, "months": months,
                                 "plan": chosen, "admin_secret": secret})
    except AccountError as exc:
        # A wrong secret answers 404 on purpose, so say both possibilities
        # rather than guessing which one it was.
        if exc.code == "server_error":
            print(f"the server refused it. Either {email} has no account yet, "
                  "or SILLYBUS_ADMIN_SECRET does not match the one on Netlify.")
        else:
            print(f"could not reach the account server: {exc}")
        return 1
    print(result.get("message") or "done")
    subscription_state = (result.get("subscription") or {}).get("state")
    print(f"{email} is now: {subscription_state}")
    return 0


def status() -> dict:
    session = current()
    return {
        "required": required(),
        "configured": bool(server_url()),
        "signed_in": session is not None,
        "email": session["email"] if session else None,
        "subscription": subscription(),
    }
