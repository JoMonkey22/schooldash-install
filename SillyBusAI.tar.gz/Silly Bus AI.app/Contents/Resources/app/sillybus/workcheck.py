"""Reading a photo of finished work and saying what looks wrong.

*"add a thing in asgnments where you can click on the assginment and take a
photo of your assignment or uplod the assghinment had the ai will check it"*

Four decisions, all of them about what this must NOT become.

**It is not a grade and it never touches one.** Nothing here is written to
`db`, to `grades`, or to the what-if calculator. A model reading a phone photo
of handwriting is a second opinion, and the app's rule everywhere else is that
a number on screen can be traced to the school's own data. So this returns
prose and per-answer verdicts, labelled as an opinion, and the page says whose
it is and that it can be wrong.

**It does not hand him the answers.** The prompt asks for the mistake and the
reason — *"you subtracted 3x from the left and not the right"* — and refuses
the corrected result. That is the difference between checking his work and
doing it, and it is also the more useful of the two: a wrong answer he can
find is a wrong answer he will remember.

**It says what it cannot read.** A dark photo, a cut-off page, handwriting it
cannot make out: those are reported as `UNSURE` with the reason, because the
failure this app is built to avoid is a confident answer about data that was
never there.

**Structured output is not available on this path.** `--json-schema` needs
`--output-format json` and an image needs `--input-format stream-json`, which
forces `--output-format stream-json` — the two cannot be combined (measured,
2026-09-10; see `claude_code.complete_vision`). So the prompt asks for one
fixed line per answer and `parse()` reads them. When a line does not parse it
is kept as prose rather than dropped, and the raw reply is always returned and
always shown: nothing the model said is hidden because a regex missed it.
"""

from __future__ import annotations

import re
import time

from sillybus import allowance, pipeline, work
from sillybus.ai import detect
from sillybus.ai.base import ProviderError
from sillybus.logging_setup import get

log = get("workcheck")

SYSTEM = (
    "You are marking a high-school student's own finished homework from a "
    "photo, so they can find their mistakes before they hand it in.\n"
    "\n"
    "RULES, in order of importance:\n"
    "1. Describe every mistake IN WORDS ONLY. Do not write a corrected "
    "number, expression, equation or answer anywhere in your reply — not the "
    "final result and not an intermediate step. Say WHICH step went wrong and "
    "WHY it is wrong (\"you collected the like terms on the left but not on "
    "the right\"), and stop there. The student fixes it themselves; that is "
    "the entire point, and handing over the working removes it.\n"
    "2. Only judge what you can actually see. If the photo is dark, cut off, "
    "blurred, or the handwriting is unclear, say UNSURE and say why. Never "
    "guess at a number you cannot read.\n"
    "3. Do not invent problems that are not in the picture, and do not "
    "comment on anything you were not shown.\n"
    "4. You are not giving a grade. Do not award marks, points or "
    "percentages.\n"
)

FORMAT = (
    "Reply in exactly this shape and nothing else:\n"
    "\n"
    "LINE <label> | RIGHT or WRONG or UNSURE | <one short sentence>\n"
    "...one LINE per answer you can see, in the order they appear...\n"
    "NOTES: <one or two sentences on the work as a whole, or the word none>\n"
    "\n"
    "<label> is the question's own number or name as written on the page "
    "(\"4\", \"2b\", \"Part II\"). For WRONG, the sentence names the step "
    "that went wrong, in words, with no corrected value in it. For RIGHT, say "
    "so in three or four words and do not restate the working. For UNSURE, "
    "say what you could not see."
)

# The `LINE ` prefix is optional. [MEASURED] 2026-09-10 on a deliberately
# unreadable photo: the reply came back as `UNSURE | UNSURE | the image is
# blank`, with the prefix dropped, and the one line that mattered fell into
# the leftovers where it was collapsed behind a `<details>`. Two pipes with
# one of the three verdict words between them is distinctive enough on its
# own — prose does not look like that.
LINE = re.compile(r"^(?:LINE\s+)?(.{1,24}?)\s*\|\s*(RIGHT|WRONG|UNSURE)\s*\|\s*(.*)$",
                  re.IGNORECASE)
NOTES = re.compile(r"^NOTES:\s*(.*)$", re.IGNORECASE)


def _assignment_context(item: dict) -> str:
    """What the assignment actually is, from the board — never invented. The
    model is told the title and class so it can tell whether the page in front
    of it is even the right assignment."""
    bits = [f"Assignment: {item.get('title') or '(untitled)'}"]
    if item.get("course"):
        bits.append(f"Class: {item['course']}")
    if item.get("category"):
        bits.append(f"Kind: {item['category']}")
    if item.get("points"):
        bits.append(f"Worth: {item['points']} points")
    if item.get("due_date"):
        bits.append(f"Due: {item['due_date']}")
    # The assignment's own instructions, whole. [ASKED] 2026-09-28: "make it
    # better on reading the assignments". Canvas items carry `description`
    # (the teacher's text) since 0.21.21.0; doc items carry the line in
    # `detail`. Whatever is there is what the work is judged against.
    words = (item.get("description") or "").strip()
    detail = (item.get("detail") or "").strip()
    if words:
        bits.append(f"The assignment's instructions, as the teacher wrote them:\n{words[:5000]}")
    elif detail and detail != (item.get("title") or ""):
        bits.append(f"What the teacher wrote: {detail[:1200]}")
    return "\n".join(bits)


# --- how THIS teacher marks --------------------------------------------------
#
# [ASKED] 2026-09-28: *"the ability to train silly bus on predicting what
# grade the teacher will give you to give you better feed back"*. Examples
# the student added (teacher.py, kind "graded") are shown to the model with
# the marks and comments the teacher actually gave, so the feedback is in
# that teacher's terms — and, only when there are examples, one extra line
# says what grade this teacher would probably give. It is labelled a guess
# on screen, kept out of every place a grade lives, and never appears when
# there is nothing to base it on: a guess from nothing is a number.

ESTIMATE_RULE = (
    "5. You have been shown work this same teacher graded before, with their "
    "marks and comments. Judge in THEIR terms: what they rewarded, what they "
    "took points for, how strict they were. Then add ONE final line:\n"
    "ESTIMATE: <the grade this teacher would probably give, as a percentage or "
    "a score out of the points> | <one sentence: what it rests on>\n"
    "This is a prediction from the examples, not a mark, and you say so in the "
    "sentence. Never write it when you were shown no graded examples.\n"
)
ESTIMATE = re.compile(r"^ESTIMATE:\s*(.+?)\s*\|\s*(.*)$", re.IGNORECASE)


def _calibration(item: dict) -> tuple[str, int]:
    """The teacher's graded examples for this class, for the prompt."""
    try:
        from sillybus import teacher
        text, used, _skipped = teacher.exemplar_text(item.get("course_key") or "", "graded")
    except Exception as exc:                          # noqa: BLE001 — never the check
        log.info("no calibration: %s", exc)
        return "", 0
    if not used:
        return "", 0
    return (f"=== {used} PIECE(S) OF WORK THIS TEACHER GRADED BEFORE, WITH THEIR MARKS "
            f"AND COMMENTS ===\nBEGIN\n{text}\nEND"), used


def parse(text: str) -> dict:
    """{'verdicts': [...], 'notes': str, 'stray': [str]} from the reply."""
    verdicts: list[dict] = []
    notes = ""
    stray: list[str] = []
    estimate = None
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        guess = ESTIMATE.match(line)
        if guess:
            estimate = {"grade": guess.group(1).strip(), "why": guess.group(2).strip()}
            continue
        hit = LINE.match(line)
        if hit:
            verdict = hit.group(2).upper()
            label = hit.group(1).strip()
            # `UNSURE | UNSURE | …` — the label slot filled with the verdict
            # again carries nothing, and printing it twice reads as a bug.
            if label.upper() == verdict:
                label = ""
            verdicts.append({"label": label, "verdict": verdict,
                             "why": hit.group(3).strip()})
            continue
        note = NOTES.match(line)
        if note:
            body = note.group(1).strip()
            notes = "" if body.lower() in ("none", "none.") else body
            continue
        stray.append(line)
    return {"verdicts": verdicts, "notes": notes, "stray": stray, "estimate": estimate}


def summary(verdicts: list[dict]) -> str:
    """A count, only of what was actually read. Says nothing when nothing
    parsed — a made-up "0 of 0" would look like a verdict of its own."""
    if not verdicts:
        return ""
    wrong = sum(1 for v in verdicts if v["verdict"] == "WRONG")
    unsure = sum(1 for v in verdicts if v["verdict"] == "UNSURE")
    right = sum(1 for v in verdicts if v["verdict"] == "RIGHT")
    look = lambda n: "looks" if n == 1 else "look"
    parts = []
    if right:
        parts.append(f"{right} {look(right)} right")
    if wrong:
        parts.append(f"{wrong} {look(wrong)} wrong")
    if unsure:
        parts.append(f"{unsure} could not be read")
    return " · ".join(parts)


def check(item_id: str) -> dict:
    """Look at every saved page of one assignment. Raises WorkError with a
    sentence a student can act on; ProviderError for a model that cannot."""
    pages = work.pages(item_id)
    if not pages:
        raise work.WorkError("there is no photo on this assignment yet",
                             "take a photo or choose a file first")

    state = pipeline.load_state_overlaid() or {}
    item = next((i for i in state.get("items") or []
                 if i.get("item_id") == item_id), None)
    if item is None:
        raise work.WorkError(
            "that assignment is not on the board any more",
            "press Refresh — the photo is still saved")

    images: list[tuple[str, bytes]] = []
    total = 0
    for page in pages:
        data, media = work.read(item_id, page["name"])
        total += len(data)
        if total > work.MAX_CHECK_BYTES:
            raise work.WorkError(
                f"these {len(pages)} pages come to more than "
                f"{work.MAX_CHECK_BYTES // (1024 * 1024)} MB together, which "
                "is more than can be read in one go",
                "delete a page, or re-take the photos")
        images.append((media, data))

    provider = detect.provider_for("chat")
    from sillybus import allowance, plans
    # Only a metered API key costs the person who sold the plan anything; on
    # `claude_code` the student's own Claude access pays and capping it would
    # invent a limit for nobody. See allowance.METERED_PROVIDERS.
    metered = provider.name in allowance.METERED_PROVIDERS
    if metered:
        allowance.check("chat")

    calibration, graded_examples = _calibration(item)
    user = (
        f"{_assignment_context(item)}\n\n"
        + (f"{calibration}\n\n" if calibration else "")
        + f"{'This is one photo' if len(images) == 1 else f'These are {len(images)} photos'}"
        " of the student's own finished work for that assignment.\n\n"
        f"{FORMAT}"
    )
    system = SYSTEM + (ESTIMATE_RULE if graded_examples else "")
    started = time.time()
    text = provider.complete_vision(system=system, user=user, images=images,
                                    timeout=240)
    took = round(time.time() - started, 1)
    if metered:
        # An image is about 2.5 chat questions' worth of tokens, so charging
        # it as one would quietly make the plan's ceiling untrue — and that
        # ceiling is what the price was set against. plans.py owns the sum.
        #
        # PER PAGE, not per check. [PROSECUTION 2026-09-11, COUNT 3] this
        # charged a flat three calls however many photos went in the same
        # request, so eight pages cost eight times the tokens and a third of
        # one page's allowance. The figure in plans.py is measured for ONE
        # image; multiplying is the only reading of it that stays true.
        for _ in range(plans.work_check_calls() * len(images)):
            allowance.record("chat")

    parsed = parse(text)
    # Nothing readable is a real answer, not a failure: it means the photo
    # needs retaking, and saying so is the whole of rule 2. It is distinguished
    # here rather than left for the page to infer from an empty list.
    unreadable = (not parsed["verdicts"]
                  or all(v["verdict"] == "UNSURE" for v in parsed["verdicts"]))
    result = {
        "unreadable": unreadable,
        "ok": True,
        "item_id": item_id,
        "pages": [p["name"] for p in pages],
        "provider": provider.name,
        "model": getattr(provider, "model", "") or "",
        "seconds": took,
        "at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "text": text,
        "verdicts": parsed["verdicts"],
        "notes": parsed["notes"],
        "stray": parsed["stray"],
        "summary": summary(parsed["verdicts"]),
        # Only with examples behind it; a guess from nothing is dropped
        # even if the model wrote one.
        "estimate": parsed.get("estimate") if graded_examples else None,
        "graded_examples": graded_examples,
    }
    work.save_check(item_id, result)
    log.info("checked %d page(s) of %s in %ss: %s",
             len(images), item_id, took, result["summary"] or "no lines parsed")
    return result


def run(item_id: str) -> dict:
    """The route's entry point: never raises, always returns something the
    page can render."""
    try:
        return check(item_id)
    except work.WorkError as exc:
        return {"ok": False, "message": exc.message, "fix": exc.fix}
    except ProviderError as exc:
        return {"ok": False, "message": str(exc),
                "fix": "chat and this both need an AI — see Settings"}
    except allowance.Exhausted as exc:
        # Round 5, 2026-10-07: this escaped as a raw 500 "Internal Server
        # Error" page instead of saying the month's checks are used up.
        return {"ok": False, "message": exc.message, "allowance": True,
                "fix": "it comes back on the 1st"}
