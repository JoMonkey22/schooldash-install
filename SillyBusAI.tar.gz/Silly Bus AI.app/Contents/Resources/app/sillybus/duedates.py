"""The due date a teacher wrote in the words, when the date field is wrong.

*"make it way better with due dates it is not always the day it was assigned
some times is says it in the discriptions"* — 2026-09-22.

That sentence names a real and specific failure. A teacher builds a Canvas
assignment on the day they set the work, and Canvas stamps `due_at` with that
day — or leaves it empty — while the description says **"due next Friday"**.
The board then shows the work due the day it was handed out, which is not a
small error: it is due *today*, in red, at the top, and the thing that is
actually due today is below it.

Canvas already ships the sentence that says so. `/api/v1/…/assignments`
returns `description` on every entry and this program threw it away entirely.
So nothing new has to be fetched and no new permission is needed — the
correction is sitting in data already in hand.

Three rules this module keeps, and they are the whole reason it is safe:

**It only reads a date that is attached to an obligation.** "Assigned Monday,
due Friday" yields Friday, because "assigned" is not a word that creates a
deadline and "due" is. A bare date in a paragraph produces nothing at all. The
opposite design — find any date, hope it is the deadline — is how a syllabus
link dated last August becomes a due date.

**It refuses a sentence that is about a different deadline.** "Late work
accepted until Oct 1", "retakes by Friday", "if you are absent, hand it in the
Monday after" each name a real date that is not this assignment's due date.
Those sentences are recognised and skipped, not parsed (`RE_OTHER_DEADLINE`).

**It never silently overrules Canvas.** Canvas is authoritative (SPEC §10.9),
so a disagreement is shown rather than resolved — with one exception, narrow
on purpose and stated in `reconcile()`: when Canvas's due date is the same day
the assignment was created, that date is a side effect of posting rather than
a deadline anyone chose, and a later date in the description beats it. Every
outcome writes a `date_note` saying which sentence it came from (SPEC §5.9).

Pure: no network, no clock, no config. `today` is passed in, and the date
phrases are read by `quickadd.parse_when`, which is the app's one reader for
"Friday"/"9/26"/"Sept 26" and is already tested. A second date parser in this
repo would be a second set of answers to the same question.
"""

import re
from dataclasses import dataclass, field
from datetime import date

from sillybus import quickadd

# How much of a description is read. A Canvas description can carry a whole
# unit plan; the deadline is never in the twentieth paragraph, and scanning a
# 200KB body once per assignment per refresh is time spent for nothing.
MAX_TEXT = 4000

# How much of the sentence a date_note quotes back.
QUOTE_CHARS = 90

# How far past the obligation word a date may sit and still belong to it.
# [MEASURED] 2026-09-22: a ladder of one-to-three filler words missed "due at
# the end of the day Thursday", which is six. A bounded search is both simpler
# and better behaved — the window cannot cross a sentence, because the text is
# split into sentences first, and a sentence that mentions a second deadline
# has already been thrown out by RE_OTHER_DEADLINE.
LOOK_AHEAD = 44

# The weak words get a shorter one. "by" and "before" are ordinary English as
# often as they are deadlines, and 44 characters is room for a whole clause:
# [MEASURED] 2026-09-28 on his real board, "Before you leave, show where you
# got today" was read as *due today* — "before" found "today" thirty
# characters on, and an exit ticket from September 1st moved to the top of a
# board four weeks later. "By Friday" and "before class on Friday" both fit
# in twenty-four; a sentence that needs more than that is not naming a
# deadline with the word "before", it is just using the word.
LOOK_AHEAD_WEAK = 24


# The words that create an obligation, strongest first. The strength is used
# to choose between two candidates, so the order is load-bearing: "due Friday
# (you may turn it in by Monday for half credit)" has to answer Friday.
#
# "by"/"before" on their own are deliberately WEAK rather than absent. They
# carry deadlines on their own often enough to matter — "finish the lab write
# up before Thursday" — but they also appear in "graded by Friday" and "we
# will be joined by Dr Lee on the 4th", so they never beat a "due".
OBLIGATION = [
    ("due", 3, re.compile(r"\bdue\s*(?:date)?\s*[:\-–]?\s*(?:on|by|at)?\s*", re.I)),
    ("hand in", 2, re.compile(
        r"\b(?:turn(?:ed)?\s+(?:it\s+)?in|hand(?:ed)?\s+(?:it\s+)?in|submit(?:ted)?|"
        r"upload(?:ed)?|post(?:ed)?)\s+(?:this\s+|it\s+|them\s+|by\s+|on\s+|before\s+)*",
        re.I)),
    ("deadline", 3, re.compile(r"\bdeadline\s*(?:is|:)?\s*(?:on|by)?\s*", re.I)),
    ("no later than", 2, re.compile(r"\bno\s+later\s+than\s+", re.I)),
    ("by", 1, re.compile(r"\b(?:by|before)\s+", re.I)),
]

# A sentence about SOMEBODY ELSE'S deadline, or a second chance at this one.
# Each of these names a real date that is not this assignment's due date, and
# every one of them was found in the wild rather than imagined:
#
#   "Late work will be accepted until Oct 1 for half credit."
#   "Retakes must be scheduled by Friday."
#   "If you are absent, turn it in the Monday you return."
#   "Extra credit is due Nov 3."
#   "This was assigned Monday."
#   "Corrections are due one week after the test is returned."
#
# Recognised and skipped whole. A sentence like this is not a weaker signal to
# be outweighed — it is an answer to a different question.
RE_OTHER_DEADLINE = re.compile(
    r"\b(?:late(?:\s+work)?|makeups?|make-?ups?|retakes?|re-?takes?|redos?|re-?dos?|"
    r"resubmi\w*|revisions?|revise[ds]?|corrections?|extra\s+credit|"
    r"optional|bonus|if\s+you\s+(?:are\s+)?(?:absent|miss|were\s+out)|"
    r"absent|excused|extensions?|extended\s+to|"
    r"handed\s+out|passed\s+out|distributed|"
    r"last\s+day\s+to|will\s+be\s+graded|returned|"
    r"next\s+(?:unit|chapter|assignment)|"
    r"final\s+exam|semester\s+exam)\b", re.I)

# **"assigned" and "posted" are deliberately NOT in that list**, though they
# were at first. Skipping their sentence throws away "Posted Monday, due
# Friday" — one sentence carrying both the wrong date and the right one, which
# is the exact shape this module exists for. They do not need to be skipped:
# neither word is an obligation, so a date sitting behind one is never read,
# and the "due" three words later still is.

# A date phrase, reusing the one alternation the app already reads. The lead
# is dropped — the obligation word in front of it is what this module matches
# on — and the trailing \b is kept so "may" inside "maybe" is not a month.
RE_WHEN = re.compile(r"(?P<when>" + quickadd.WHEN.pattern.split("(?P<when>")[1],
                     re.I)

# A date phrase that names a calendar day outright, as opposed to one that is
# relative to now ("Friday", "tomorrow", "next week"). When a sentence carries
# both — "Due Friday, Sept 25" — the explicit one is preferred, because it is
# the one the teacher actually typed and it cannot drift. It also decides
# "Due Friday, Sept 26", where the two disagree and one of them is a typo:
# taking the weekday would answer with a date nobody wrote.
RE_EXPLICIT = re.compile(
    r"^(?:\d{4}-\d{2}-\d{2}"
    r"|\d{1,2}/\d{1,2}(?:/\d{2,4})?"
    r"|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s+\d{1,2}"
    r"|\d{1,2}(?:st|nd|rd|th)\s+(?:of\s+)?(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)"
    r"|the\s+\d{1,2}(?:st|nd|rd|th))", re.I)

# Sentences, roughly. A description is written by a person in a rich-text box,
# so a "sentence" ends at a full stop, a line break, or a bullet — and a
# paragraph that ran together into one line is split on the semicolon too.
RE_SENTENCE = re.compile(r"[^.!?;\n]+[.!?;\n]?")

# Blocks whose text is never prose a teacher wrote to the student.
DROP_TAGS = ("script", "style", "head", "title", "noscript")


@dataclass
class Found:
    """One deadline a description states, and the evidence for it."""
    due_date: str                  # ISO
    phrase: str                    # the words that gave the date: "next Friday"
    sentence: str                  # the sentence it sat in, trimmed
    word: str                      # which obligation word found it
    strength: int
    note: str = ""                 # how the phrase was read, from parse_when
    relative: bool = False         # "Friday", not "Oct 14": counted from a day


@dataclass
class Verdict:
    """What the description changes about an item's date, and why."""
    due_date: str | None = None
    date_note: str = ""
    extractor: str | None = None   # set only when this module supplied the date
    flags: list = field(default_factory=list)
    described: Found | None = None
    canvas_date: str | None = None
    changed: bool = False


def text_from_html(html: str) -> str:
    """A description as the student reads it, with block boundaries kept.

    The boundaries matter more than the prettiness: `<li>Due Friday</li><li>
    Bring a calculator</li>` run together reads as one sentence claiming a
    deadline for the calculator, and a `<br>` between "assigned Monday" and
    "due Friday" is the only thing separating the wrong answer from the right
    one.
    """
    raw = (html or "")
    if not raw.strip():
        return ""
    if "<" not in raw:
        return " ".join(raw.split())[:MAX_TEXT]
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(raw, "lxml")
        for tag in soup.find_all(DROP_TAGS):
            tag.decompose()
        # A newline separator, not a space: every block becomes its own line,
        # which is what RE_SENTENCE then splits on.
        text = soup.get_text("\n", strip=True)
    except Exception:                                        # noqa: BLE001
        # bs4 or lxml missing, or markup that breaks the parser. A regex strip
        # is worse but it is not nothing, and this module must never be the
        # reason a refresh fails.
        text = re.sub(r"<[^>]+>", "\n", raw)
        text = re.sub(r"&nbsp;?", " ", text)
        text = re.sub(r"&amp;?", "&", text)
    lines = [" ".join(line.split()) for line in text.split("\n")]
    return "\n".join(line for line in lines if line)[:MAX_TEXT]


def _trim(sentence: str, limit: int = QUOTE_CHARS) -> str:
    text = " ".join((sentence or "").split()).strip(" -–—•*")
    return text if len(text) <= limit else text[:limit - 1].rstrip() + "…"


def find(text: str, today: date, meetings=None, course: str | None = None,
         anchor: date | None = None) -> list[Found]:
    """Every deadline the text states, in the order it states them.

    A candidate needs three things in a row: a sentence that is not about
    somebody else's deadline, an obligation word, and a date phrase that
    follows that word within a few words. "Due" with no date after it is not a
    deadline, and a date with no obligation word in front of it is not one
    either.

    **`anchor` is the day the words were written**, and a relative phrase is
    counted from it — not from `today`. [MEASURED] 2026-09-28, all three date
    flags on his real board were this one mistake: "Due Tuesday at midnight",
    posted on a Friday for the Tuesday after it, was being read on the
    following Monday as the Tuesday after *that*, and the board reported
    Canvas and the teacher disagreeing when they agreed to the minute. A
    teacher who writes "Friday" on a Monday means that week's Friday
    forever; the refresh clock has nothing to do with it. `today` still
    decides which school year a bare "Oct 14" lands in.
    """
    base = anchor or today
    out: list[Found] = []
    for sentence in RE_SENTENCE.findall(text or ""):
        clean = sentence.strip()
        if len(clean) < 3:
            continue
        if RE_OTHER_DEADLINE.search(clean):
            continue
        for word, strength, pattern in OBLIGATION:
            for hit in pattern.finditer(clean):
                window = LOOK_AHEAD_WEAK if strength < 2 else LOOK_AHEAD
                tail = clean[hit.end():hit.end() + window]
                candidates = list(RE_WHEN.finditer(tail))
                if not candidates:
                    continue
                # The first phrase, unless a later one in the same window
                # names a calendar day outright.
                when = candidates[0]
                for other in candidates[1:]:
                    if RE_EXPLICIT.match(other.group("when")):
                        when = other
                        break
                phrase = when.group("when")
                relative = not RE_EXPLICIT.match(phrase.strip())
                iso, note = quickadd.parse_when(
                    phrase, base if relative else today, meetings, course)
                if not iso:
                    continue
                if relative and anchor and anchor != today:
                    note = f"{note}, counted from the day it was posted ({anchor:%a %b %d})"
                out.append(Found(due_date=iso, phrase=phrase.strip(),
                                 sentence=_trim(clean), word=word,
                                 strength=strength, note=note,
                                 relative=relative))
                break                      # one deadline per obligation word
    return out


def _strongest(found: list) -> Found | None:
    """The strongest obligation, and among equals the one stated EARLIEST.

    One function rather than one per caller, because there were two for an
    afternoon and they differed only in a lambda's parameter name — which is
    invisible in a diff and made a mutation test poison the wrong one and
    report a pass.
    """
    if not found:
        return None
    return max(enumerate(found),
               key=lambda pair: (pair[1].strength, -pair[0]))[1]


def best(text: str, today: date, meetings=None, course: str | None = None,
         anchor: date | None = None) -> Found | None:
    """The one deadline to believe, or None.

    Strongest obligation first ("due" beats "by"), and among equals the one
    stated EARLIEST. A teacher puts the deadline at the top and the caveats
    underneath; taking the last would answer with the caveat.
    """
    return _strongest(find(text, today, meetings, course, anchor))


def _as_date(iso: str | None) -> date | None:
    try:
        return date.fromisoformat(iso) if iso else None
    except (TypeError, ValueError):
        return None


def choose(found: list, canvas_due_date: str | None) -> Found | None:
    """Which of several stated deadlines this assignment's own date is about.

    `best()` answers "what does this text say" with no other information.
    Once Canvas's date is in hand there is a better question, and it has to be
    asked first: **does any of them agree with it?** A Canvas assignment due
    Friday whose description reads "hand the draft in by Wednesday, the final
    is due Friday" states two real deadlines, and taking the earlier one turns
    a project that is fine into one that is two days late.

    So: a candidate that matches Canvas wins outright, because a match is
    confirmation and confirmation beats any amount of wording. Only when none
    of them matches is there a disagreement to resolve, and `best()` resolves
    it.
    """
    if canvas_due_date:
        agreeing = [f for f in found or [] if f.due_date == canvas_due_date]
        if agreeing:
            return _strongest(agreeing)
    return _strongest(found)


def reconcile(*, described: Found | None = None, canvas_due_date: str | None,
              found: list | None = None,
              created_on: str | None = None, unlock_on: str | None = None,
              canvas_note: str = "Canvas due date") -> Verdict:
    """What the item's date and note become once the description is read.

    Canvas is authoritative and stays authoritative (SPEC §10.9). The four
    outcomes, and the one that is a judgement call:

    1. **Canvas has no date.** The description's date is the only one there
       is, so it wins outright. Today those items sit on the board saying
       "Canvas lists this with no due date" — which is true and useless.

    2. **They agree.** Nothing changes except the note, which now says two
       sources agree. That is worth one line: it is the difference between a
       date nobody checked and a date that was checked.

    3. **Canvas's date is the day the assignment was created, and the
       description names a LATER day.** The description wins, and this is the
       only case where it overrules Canvas. The reasoning is narrow: a due
       date equal to the creation date is what a teacher gets by not choosing
       one, not a deadline they set — it is the day they posted the work. The
       description is the day they typed on purpose. Both dates go in the
       note and the item is flagged, so the swap is never invisible.

       The rule refuses to run backwards. A description naming an EARLIER day
       than Canvas does not win, because "hand in the draft by Wednesday" in a
       project due Friday is a milestone inside the work, and moving the
       deadline earlier turns an assignment that is fine into one that is
       late.

    4. **They disagree otherwise.** Canvas keeps the date, the item is flagged
       `date_conflict`, and the note carries both. Showing the disagreement is
       the point — §5.5 forbids hiding it, and the board offers the swap as a
       tap rather than taking it.
    """
    if found:
        described = choose(found, canvas_due_date)
    out = Verdict(due_date=canvas_due_date, date_note=canvas_note,
                  canvas_date=canvas_due_date, described=described)
    if described is None:
        return out

    said = _as_date(described.due_date)
    stated = _as_date(canvas_due_date)
    quote = f"the description says “{described.sentence}”"

    if stated is None:
        out.due_date = described.due_date
        out.extractor = "canvas_described"
        out.changed = True
        out.flags = ["date_from_description"]
        out.date_note = (f"Canvas gives no due date; {quote} — read as "
                         f"{said:%a %b %d}" if said else quote)
        return out

    if said == stated:
        out.date_note = f"{canvas_note}, and {quote}"
        return out

    posted = {d for d in (_as_date(created_on), _as_date(unlock_on)) if d}
    if said and stated in posted and said > stated:
        out.due_date = described.due_date
        out.extractor = "canvas_described"
        out.changed = True
        out.flags = ["date_from_description", "date_moved"]
        out.date_note = (
            f"{quote} — read as {said:%a %b %d}. Canvas's own due date is "
            f"{stated:%a %b %d}, which is the day the assignment was put up, "
            f"so the description is the one that was chosen")
        return out

    # A step inside the work, not a rival deadline. "Hand the draft in by
    # Wednesday" in a project due Friday is the teacher pacing the work, and
    # calling that a conflict puts a warning on an item where nothing is
    # wrong — which is how a warning stops meaning anything. Narrow: the date
    # has to be EARLIER than Canvas's, and stated with a hand-in verb rather
    # than the word "due".
    if said and stated and said < stated and described.strength < 3:
        out.date_note = (f"{canvas_note} ({stated:%a %b %d}). There is a step "
                         f"before it: {quote}")
        return out

    out.flags = ["date_conflict"]
    out.date_note = (
        f"{canvas_note} ({stated:%a %b %d}), but {quote}"
        + (f" — read as {said:%a %b %d}" if said else ""))
    return out


# ------------------------------------------------------ a doc line's own words
#
# The docs extractors date a line from the column or heading it sits under,
# and most of the time that is right. It is wrong exactly when the line names
# its own deadline: [MEASURED] 2026-09-28, "SARA: By 8 AM October 14, 100% of
# all lessons must be completed" sat on the board dated Tue Sep 29 — the class
# day whose row it was typed into — with a note explaining the snapping. The
# sentence said the date in so many words and the date on the row was the
# one thing about it that was not read.

# Extractors whose date is a position on the page rather than words in the
# line. A line under a "Monday" heading is dated Monday because of where it
# is; a line reading "by Oct 14" is dated by what it says, and says so.
POSITIONAL = {"weekday_snapped", "day_n_exact", "day_n_end_aligned",
              "month_heading", "absolute_snapped_forward"}


def restate(item, today: date, meetings=None) -> Verdict:
    """What a doc line's own words change about its date, if anything.

    Narrower than `reconcile`, on purpose. Canvas is a second source with its
    own date to weigh against; here there is one source, and the only
    question is whether the extractor read the words or the layout. So:

    * The line names a **calendar day** ("Oct 14", "10/8") and the extractor
      dated it from position → the words win. A typed date cannot drift and
      nobody types one by accident.
    * The line names a **relative day** ("by Sunday") and the extractor dated
      it from position → counted from the row's own day, which is when the
      teacher wrote it, and the words win.
    * The extractor already read words (`absolute`) → nothing changes, even
      when this reading would differ. Two readings of the same words is a
      disagreement to show, not a coin to flip.
    """
    out = Verdict(due_date=item.due_date, date_note=item.date_note,
                  canvas_date=item.due_date)
    if item.extractor not in POSITIONAL or not item.due_date:
        return out
    row_day = _as_date(item.due_date)
    text = f"{item.title or ''}. {item.detail or ''}"
    found = find(text, today, meetings, item.course, anchor=row_day)
    said = _strongest(found)
    if said is None or said.due_date == item.due_date:
        return out
    when = _as_date(said.due_date)
    if when is None:
        return out
    out.due_date = said.due_date
    out.extractor = "absolute" if not said.relative else item.extractor
    out.changed = True
    out.flags = ["date_from_description", "date_moved"]
    out.described = said
    out.date_note = (f"the line itself says \u201c{said.sentence}\u201d \u2014 read as "
                     f"{when:%a %b %d}. It sits under {row_day:%a %b %d} on the "
                     f"class doc, which is the day it was set, not the day it is due")
    return out
