"""Is there a newer SillyBus AI, and can this one become it?

The app installs to `~/Applications/Silly Bus AI.app` (the one-line installer)
or `/Applications/Silly Bus AI.app` (dragged out of the .dmg), and its Python
environment lives OUTSIDE the bundle, in the data home — which is what makes
updating in place possible at all: the bundle is just files, and swapping it
does not disturb the venv, the browser profile, the database or the config.

The native shell (2026-10-07): from then on the bundle's executable is the
Swift app `Contents/MacOS/SillyBusAI`, and the old shell launcher lives at
`Contents/Resources/setup.sh`. Nothing here depends on either name — the
swap is of the whole bundle, the checks read `Contents/Resources/app/VERSION`
and whatever executable the new bundle's own Info.plist names — so an old
bundle updates to a native one, and a native one could be put back over by an
old one, with the same code. A pywebview window from the old bundle keeps
running (out of `.previous`) until the student quits it; it is pointed at
127.0.0.1, so it simply talks to the new server.

Three rules this module keeps:

* **It never updates on its own.** The check is a read; the swap happens only
  when someone presses the button. An app that replaces itself while a student
  is mid-refresh is a bug, not a feature.
* **It never destroys the working copy until the new one is proven.** The
  download is verified as a real archive holding a real bundle with a VERSION
  strictly newer than this one, unpacked to a temporary directory, and only
  then swapped. The old bundle is moved aside, not deleted, and is put back if
  anything fails.
* **It is honest about not knowing.** No network, a site that has never been
  deployed, a missing marker file: all of these mean "could not check", which
  is a different sentence from "you are up to date", and neither is a banner.

What it deliberately does NOT do: download and execute `install.sh`. That
script exists for the first install, where there is nothing to run the work.
Here there is — this process — so the update is done in Python where every
step can be checked, rather than by piping a shell script from the internet.
"""

import json
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
from pathlib import Path

import httpx

from sillybus import config, paths
from sillybus.logging_setup import get

log = get("update")

# Where the published build lives. His own installer site by default; the same
# environment variable install.sh honours, so a test can point both at a local
# copy without editing anyone's config.
DEFAULT_BASE = "https://jomonkey22.github.io/schooldash-install"
MARKER = "version.json"
ARCHIVE = "SillyBusAI.tar.gz"

# A check is worth making a few times a day, not on every page load.
CHECK_EVERY_S = 6 * 3600
HTTP_TIMEOUT = 20.0
# The real archive is ~500 KB. The cap is generous enough to survive the app
# growing and small enough that a redirect to something enormous is refused
# rather than written to his disk.
MAX_ARCHIVE_BYTES = 80 * 1024 * 1024


def base_url() -> str:
    env = os.environ.get("SILLYBUS_INSTALL_BASE")
    if env:
        return env.rstrip("/")
    configured = (config.load().get("update") or {}).get("base") or ""
    return (configured or DEFAULT_BASE).rstrip("/")


def enabled() -> bool:
    """Update checks can be switched off entirely in config."""
    section = config.load().get("update") or {}
    return section.get("check", True) is not False


def current_version() -> str:
    try:
        return (paths.project_root() / "VERSION").read_text(encoding="utf-8").strip()
    except OSError:
        return "unknown"


def recover_interrupted() -> bool:
    """Put the previous copy back when an update died part-way through.

    Prosecution round 4, 2026-10-07: killed mid-copy, the live bundle was left
    with 19 of 56 files and no VERSION, `.previous` beside it, and
    `bundle_path()` then called it a source checkout, so no update could ever
    repair it. The copy now goes to `.incoming` and is renamed into place, but
    an older half-copy (or an `.incoming` left by a crash) is cleaned up here.
    """
    root = paths.project_root()
    candidates = [c for c in list(root.parents)[:3] if c.name == "Silly Bus AI.app"]
    recovered = False
    for bundle in candidates:
        incoming = bundle.with_name(bundle.name + ".incoming")
        if incoming.exists():
            shutil.rmtree(incoming, ignore_errors=True)
        aside = bundle.with_name(bundle.name + ".previous")
        whole = (bundle / "Contents" / "Resources" / "app" / "VERSION").exists()
        if not whole and (aside / "Contents" / "Resources" / "app" / "VERSION").exists():
            broken = bundle.with_name(bundle.name + ".broken")
            shutil.rmtree(broken, ignore_errors=True)
            if bundle.exists():
                os.rename(bundle, broken)
            os.rename(aside, bundle)
            shutil.rmtree(broken, ignore_errors=True)
            log.warning("an interrupted update was rolled back to the previous copy")
            recovered = True
    return recovered


def bundle_path() -> Path | None:
    """The `.app` this code is running from, or None in a dev checkout.

    project_root() inside the bundle is `Silly Bus AI.app/Contents/Resources/app`,
    so the bundle is three levels up. Returning None for a checkout is the
    point: `~/Projects/sillybus-ai` must never be overwritten by an installer.
    """
    root = paths.project_root()
    for candidate in list(root.parents)[:3]:
        if candidate.suffix != ".app" or not candidate.is_dir():
            continue
        # It must be OUR bundle, laid out the way build_app.sh lays one out.
        # [PROVEN] tests/test_prosecution.py: a checkout that merely happens to
        # sit inside some other `.app` — `~/Some App.app/sillybus` — matched
        # on the suffix alone, and `install()` would then have moved that
        # application aside and unpacked SillyBus AI over it.
        if candidate.name != "Silly Bus AI.app":
            continue
        if not (candidate / "Contents" / "Resources" / "app" / "VERSION").exists():
            continue
        return candidate
    return None


def _cannot_write(bundle: Path) -> str:
    """Why this copy can't update itself, in words that say what to do.

    2026-10-07: with the .dmg as the main download, two new cases — the app
    opened straight off the mounted disk image (read-only, under /Volumes),
    or opened before it was moved out of Downloads, which macOS runs from a
    random read-only "AppTranslocation" folder. Both are fixed by dragging it
    to Applications, not by anything here.
    """
    where = str(bundle)
    if where.startswith("/Volumes/") or "/AppTranslocation/" in where:
        return ("SillyBus AI can't write to the place it is running from — "
                "drag it into the Applications folder, open it from there, "
                "and update again")
    return (f"SillyBus AI can't write to {bundle.parent} — move it "
            "to the Applications folder in your home folder, or "
            "install the new version with the one-line installer")


def parse_version(text: str) -> tuple:
    """'0.18.0.1' -> (0, 18, 0, 1). Anything unparseable sorts lowest, so a
    corrupt marker can never look like an upgrade."""
    parts = []
    for chunk in str(text or "").strip().split("."):
        digits = "".join(ch for ch in chunk if ch.isdigit())
        if not digits:
            return ()
        parts.append(int(digits))
    return tuple(parts)


def is_newer(remote: str, local: str) -> bool:
    left, right = parse_version(remote), parse_version(local)
    if not left or not right:
        return False
    return left > right


def _cache_path() -> Path:
    return paths.cache_dir() / "update.json"


def _read_cache() -> dict:
    try:
        return json.loads(_cache_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _write_cache(record: dict) -> None:
    try:
        _cache_path().write_text(json.dumps(record, indent=1), encoding="utf-8")
    except OSError as exc:  # noqa: BLE001 — a cache that cannot be written is not an error
        log.debug("could not write the update cache: %s", exc)


def _fetch_marker() -> dict:
    """The published `version.json`. Raises on anything that is not one."""
    url = f"{base_url()}/{MARKER}"
    response = httpx.get(url, timeout=HTTP_TIMEOUT,
                         follow_redirects=True,
                         headers={"Cache-Control": "no-cache"})
    response.raise_for_status()
    # Netlify answers a missing file with a 200 HTML page, so the status alone
    # proves nothing — the shape of the body is what proves it.
    data = response.json()
    if not isinstance(data, dict) or not data.get("version"):
        raise ValueError("the published version marker has no version in it")
    return data


def status(force: bool = False) -> dict:
    """What is known about updates, without ever raising.

    Cached: a page load reads the cache, and the network is touched only when
    the cache is older than CHECK_EVERY_S or `force` is set.
    """
    local = current_version()
    bundle = bundle_path()
    record = _read_cache()
    # What this server is RUNNING, read when it started, against what is on
    # disk (prosecution round 4): after a swap without a restart, the disk
    # said "up to date" while the old code kept serving, and nothing offered
    # the restart again.
    from sillybus import __version__ as running
    writable = bundle is not None and os.access(bundle.parent, os.W_OK)
    result = {
        "current": local,
        "running": running,
        "restart_required": bool(bundle is not None and running != local),
        "latest": record.get("latest"),
        "available": False,
        "checked_at": record.get("checked_at"),
        "error": record.get("error"),
        "notes": record.get("notes") or "",
        "can_install": writable,
        # A dev checkout is not a thing to update, and saying why beats a
        # button that would overwrite the source tree.
        "why_not": "" if writable
                   else ("this is a source checkout, not an installed app — "
                         "update it with git") if bundle is None
                   else _cannot_write(bundle),
        "enabled": enabled(),
    }
    if not enabled():
        result["why_not"] = "update checks are switched off in config.json"
        return result

    fresh = False
    if record.get("checked_at"):
        try:
            fresh = (time.time() - float(record["checked_at"])) < CHECK_EVERY_S
        except (TypeError, ValueError):
            fresh = False
    if force or not fresh:
        try:
            marker = _fetch_marker()
            record = {"checked_at": time.time(),
                      "latest": str(marker.get("version")).strip(),
                      "notes": str(marker.get("notes") or "")[:400],
                      "error": None}
        except Exception as exc:  # noqa: BLE001 — never let a check break a page
            log.info("update check failed: %s", exc)
            record = {"checked_at": time.time(),
                      "latest": record.get("latest"),
                      "notes": record.get("notes") or "",
                      "error": f"{type(exc).__name__}"}
        _write_cache(record)
        result.update({"latest": record.get("latest"),
                       "checked_at": record.get("checked_at"),
                       "notes": record.get("notes") or "",
                       "error": record.get("error")})

    result["available"] = bool((result["latest"]
                                and is_newer(result["latest"], local))
                               or result["restart_required"])
    if result["restart_required"] and not (result["latest"] and is_newer(result["latest"], local)):
        # Shown as an update so the same button finishes it; install() sees
        # that the new copy is already in place and only restarts.
        result["latest"] = local
    return result


def _download(url: str, target: Path, emit=None) -> None:
    say = emit or (lambda _line: None)
    say(f"downloading {url}")
    written = 0
    with httpx.stream("GET", url, timeout=HTTP_TIMEOUT,
                      follow_redirects=True) as response:
        response.raise_for_status()
        with target.open("wb") as handle:
            for chunk in response.iter_bytes():
                written += len(chunk)
                if written > MAX_ARCHIVE_BYTES:
                    raise ValueError("the download is far larger than a "
                                     "SillyBus AI build — refusing it")
                handle.write(chunk)
    say(f"downloaded {written // 1024} KB")


def _unpack(archive: Path, into: Path, emit=None) -> Path:
    """Unpack and return the bundle inside, refusing anything else."""
    say = emit or (lambda _line: None)
    if not tarfile.is_tarfile(archive):
        raise ValueError("that download is not an archive — the site may have "
                         "answered with an error page")
    with tarfile.open(archive, "r:gz") as tar:
        names = tar.getnames()
        if not any(name.split("/")[0] == "Silly Bus AI.app" for name in names):
            raise ValueError("the archive does not contain Silly Bus AI.app")
        # filter="data" refuses absolute paths, "..", links out of the tree
        # and device files. Extracting an archive from the network without it
        # is how a downloader writes outside the directory it meant to.
        # macOS tar adds a "._" twin for every file's extended attributes;
        # Python writes them out as real files, which broke the bundle's code
        # signature (prosecution round 4). They are never part of the app.
        members = [m for m in tar.getmembers()
                   if not m.name.rsplit("/", 1)[-1].startswith("._")]
        tar.extractall(into, members=members, filter="data")
    new_bundle = into / "Silly Bus AI.app"
    if not (new_bundle / "Contents" / "Resources" / "app" / "VERSION").exists():
        raise ValueError("the unpacked app has no VERSION file")
    _check_launchable(new_bundle)
    say("unpacked")
    return new_bundle


def _check_launchable(bundle: Path) -> None:
    """Refuse a bundle macOS could not open: its Info.plist must name an
    executable, and that file must be in Contents/MacOS and runnable.

    2026-10-07, the native shell: the executable changed from the shell script
    `sillybus` to the Swift binary `SillyBusAI`. Reading the name from the new
    bundle's own Info.plist — never assuming either — means a build whose
    Swift compile failed (a plist naming a binary that is not there) is turned
    away here, before the working copy is touched, instead of being swapped in
    as an app that will not open.
    """
    import plistlib

    info = bundle / "Contents" / "Info.plist"
    try:
        plist = plistlib.loads(info.read_bytes())
    except (OSError, ValueError, plistlib.InvalidFileException) as exc:
        raise ValueError("the unpacked app has no readable Info.plist") from exc
    name = str(plist.get("CFBundleExecutable") or "").strip()
    if not name or "/" in name:
        raise ValueError("the unpacked app's Info.plist names no executable")
    exe = bundle / "Contents" / "MacOS" / name
    if not exe.is_file() or not os.access(exe, os.X_OK):
        raise ValueError(f"the unpacked app is missing its program "
                         f"(Contents/MacOS/{name})")


def install(emit=None, force: bool = False) -> dict:
    """Download the published build and swap this bundle for it.

    Returns {"installed": version, "restart_required": True}. Raises with a
    sentence a student can read on any failure, having left the working copy
    exactly as it was.
    """
    say = emit or (lambda _line: None)
    recover_interrupted()
    bundle = bundle_path()
    if bundle is None:
        raise RuntimeError("this is a source checkout, not an installed app — "
                           "update it with git, not from here")
    local = current_version()
    from sillybus import __version__ as running
    if running != local and not force:
        # Already installed by an earlier run whose restart never happened.
        say(f"SillyBus AI {local} is already installed — restarting into it")
        return {"installed": local, "previous": running,
                "restart_required": True, "bundle": str(bundle)}
    if not os.access(bundle.parent, os.W_OK):
        raise RuntimeError(_cannot_write(bundle))
    work = Path(tempfile.mkdtemp(prefix="sillybus-update-"))
    aside = bundle.with_name(bundle.name + ".previous")
    incoming = bundle.with_name(bundle.name + ".incoming")
    try:
        archive = work / ARCHIVE
        _download(f"{base_url()}/{ARCHIVE}", archive, say)
        new_bundle = _unpack(archive, work / "unpacked", say)
        new_version = (new_bundle / "Contents" / "Resources" / "app"
                       / "VERSION").read_text(encoding="utf-8").strip()
        say(f"downloaded version {new_version}, this one is {local}")
        if not force and not is_newer(new_version, local):
            raise RuntimeError(
                f"the published build is {new_version}, which is not newer "
                f"than the {local} already installed — nothing to do")

        # The new copy is built BESIDE the app and checked there, then two
        # renames swap it in: dying part-way leaves the working app untouched
        # (prosecution round 4 — a copy straight into the live path, killed at
        # file 20, left an app with no VERSION that nothing could repair).
        shutil.rmtree(incoming, ignore_errors=True)
        say("putting the new version in place")
        shutil.copytree(new_bundle, incoming, symlinks=True)
        _sign(incoming, say)
        if aside.exists():
            shutil.rmtree(aside, ignore_errors=True)
            if aside.exists():
                raise RuntimeError(f"could not clear the old backup at {aside}")
        os.rename(bundle, aside)
        try:
            os.rename(incoming, bundle)
        except Exception:
            # Put it back exactly as it was. A student left with no app
            # because an update failed halfway is the worst outcome here.
            os.rename(aside, bundle)
            raise
        _refresh_launch_services(bundle)
        say(f"SillyBus AI {new_version} is installed")
        # The old bundle stays as .previous until the next update, so there is
        # always one working copy to fall back to.
        return {"installed": new_version, "previous": local,
                "restart_required": True, "bundle": str(bundle)}
    finally:
        shutil.rmtree(work, ignore_errors=True)
        shutil.rmtree(incoming, ignore_errors=True)


LSREGISTER = ("/System/Library/Frameworks/CoreServices.framework/Frameworks/"
              "LaunchServices.framework/Support/lsregister")


def _refresh_launch_services(bundle: Path) -> None:
    """Tell macOS the app at this path has changed. Best effort, never fatal.

    LaunchServices keeps its own record of every app — including which file
    in Contents/MacOS to run. The 2026-10-07 native shell renamed that file
    (`sillybus` -> `SillyBusAI`), so a record left over from the old bundle
    names a program that no longer exists. Touching the bundle makes its
    date differ from the record, and `lsregister -f` re-reads it now rather
    than on the next Dock click.
    """
    try:
        os.utime(bundle)
    except OSError:
        pass
    if sys.platform != "darwin" or not os.path.exists(LSREGISTER):
        return
    try:
        subprocess.run([LSREGISTER, "-f", str(bundle)], capture_output=True,
                       timeout=60, check=False)
    except Exception as exc:  # noqa: BLE001 — the next launch re-reads it anyway
        log.debug("lsregister failed: %s", exc)


def _sign(bundle: Path, say) -> None:
    """Ad-hoc sign the new copy and check it, as install.sh does. An unsigned
    or broken signature is how macOS once refused to open the app at all."""
    if sys.platform != "darwin" or not shutil.which("codesign"):
        return
    signed = subprocess.run(["codesign", "--force", "--deep", "--sign", "-", str(bundle)],
                            capture_output=True, text=True, timeout=180)
    checked = subprocess.run(["codesign", "-v", "--strict", str(bundle)],
                             capture_output=True, text=True, timeout=180)
    if signed.returncode != 0 or checked.returncode != 0:
        log.warning("codesign failed: %s %s", signed.stderr[-300:], checked.stderr[-300:])
        raise RuntimeError("the new version could not be signed, so it was not "
                           "installed — the current one is untouched")
    say("signed")


def restart_server() -> dict:
    """Hand the port to a server running the NEW code.

    The window is a separate process pointed at 127.0.0.1, so it survives
    this: only the server is replaced, and the page reconnects on its own.
    A detached helper does the waiting, because the process that has to exit
    cannot also be the one that waits for its own port to come free.
    """
    bundle = bundle_path()
    root = (bundle / "Contents" / "Resources" / "app") if bundle else paths.project_root()
    cfg = config.load()["server"]
    host, port = cfg["host"], int(cfg["port"])
    log_path = str(paths.log_file())
    # The launcher's own tool (the venv has no pip of its own).
    uv = shutil.which("uv") or next((str(p) for p in (Path.home() / ".local" / "bin" / "uv",)
                                     if p.exists()), "")
    requirements = root / "requirements.txt"
    helper = (
        "import socket, subprocess, sys, time, os\n"
        f"host, port = {host!r}, {port}\n"
        "def answering():\n"
        "    try:\n"
        "        with socket.create_connection((host, port), timeout=1):\n"
        "            return True\n"
        "    except OSError:\n"
        "        return False\n"
        "deadline = time.time() + 30\n"
        "while time.time() < deadline and answering():\n"
        "    time.sleep(0.5)\n"
        # The new build's libraries first, as the launcher would (round 4: a
        # new requirement killed the new server on import, logged nowhere).
        f"out = open({log_path!r}, 'a')\n"
        f"if {bool(uv)!r} and os.path.exists({str(requirements)!r}):\n"
        "    try:\n"
        f"        subprocess.run([{uv!r}, 'pip', 'install', '-q', '-r', {str(requirements)!r}],\n"
        f"                       env={{**os.environ, 'VIRTUAL_ENV': {sys.prefix!r}}},\n"
        "                       stdout=out, stderr=out, stdin=subprocess.DEVNULL, timeout=600)\n"
        "    except Exception as exc:\n"
        "        out.write(f'could not update libraries: {exc}\\n')\n"
        f"subprocess.Popen([{sys.executable!r}, {str(root / 'run.py')!r}, 'serve'],\n"
        f"                 cwd={str(root)!r}, stdout=out,\n"
        "                 stderr=out, stdin=subprocess.DEVNULL,\n"
        "                 start_new_session=True)\n"
    )
    subprocess.Popen([sys.executable, "-c", helper],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     stdin=subprocess.DEVNULL, start_new_session=True,
                     env={**os.environ})
    log.info("restart helper spawned; this server will exit")
    return {"restarting": True, "port": port}


def exit_soon(seconds: float = 1.0) -> None:
    """Let the HTTP reply reach the page before the process goes away."""
    import threading

    def stop():
        time.sleep(seconds)
        log.info("exiting for an update restart")
        os._exit(0)

    threading.Thread(target=stop, daemon=True).start()
