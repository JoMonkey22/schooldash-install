"""Link TeamSnap from the Mac app in one step.

[ASKED] 2026-10-07: "linking to team sanp is not wroking". In the Mac app
the button opened go.teamsnap.com (which pywebview does not reliably do)
and then asked him to find TeamSnap's iCal address himself and paste it —
and nothing was ever linked. Now the app opens TeamSnap's schedule-export
page in its OWN browser window (the same dedicated profile the Canvas and
Veracross sign-ins use), waits while he signs in if TeamSnap asks, reads the
"All games and events" calendar address off that page, and connects it the
same way a pasted address is connected — checked, fetched once, saved.

[MEASURED] 2026-10-06 on his account (bridge.js linkTeamSnap): the export
page lists three webcal://ical-cdn.teamsnap.com/… links when signed in; the
one without /filter/ is "All games and events". The address is a password
in disguise: it is never printed or logged here.
"""

from __future__ import annotations

import re
import time

from sillybus.logging_setup import get

log = get("teamsnap")

EXPORT = "https://go.teamsnap.com/team/export_schedule"
FEED = re.compile(r"(?:webcal|https?)://ical-cdn\.teamsnap\.com/[^\s\"'<>]+", re.IGNORECASE)


class LinkError(RuntimeError):
    pass


def find_feeds(html: str) -> list[str]:
    seen, out = set(), []
    for raw in FEED.findall(html or ""):
        url = raw.replace("&amp;", "&")
        url = re.sub(r"^(webcal|http)://", "https://", url, flags=re.IGNORECASE)
        if url not in seen:
            seen.add(url)
            out.append(url)
    return out


def pick(feeds: list[str]) -> str | None:
    """The whole schedule ("All games and events"), not a filtered one."""
    whole = [f for f in feeds if "/filter/" not in f]
    return (whole or feeds or [None])[0]


def read_feed_address(emit=None) -> str:
    """Open TeamSnap in the app's browser window, let him sign in, return the
    calendar address. Raises LinkError with a sentence he can act on."""
    say = emit or (lambda _line: None)
    from playwright.sync_api import sync_playwright
    from sillybus import browser

    from sillybus import pipeline
    say("opening TeamSnap in a SillyBus window — sign in there if it asks")
    # The browser profile is shared: wait for a refresh to finish rather than
    # take the profile from under it (round 7).
    try:
        lock = pipeline.exclusive_run("teamsnap-link", wait_seconds=90)
        lock.__enter__()
    except pipeline.AlreadyRunning as exc:
        raise LinkError("SillyBus is busy refreshing — try Link TeamSnap again in a minute") from exc
    try:
        return _read_with_browser(say)
    finally:
        lock.__exit__(None, None, None)


def _read_with_browser(say) -> str:
    from playwright.sync_api import sync_playwright
    from sillybus import browser
    with sync_playwright() as pw:
        context = browser.open_context(pw, headless=False, reclaim=True)
        try:
            page = browser.watched_page(context)
            page.goto(EXPORT, wait_until="domcontentloaded", timeout=60_000)

            def signed_in(current):
                url = current.url or ""
                return "go.teamsnap.com" in url and "/login" not in url and "auth." not in url

            try:
                # Nine minutes: the page stops waiting at ten (round 7 — the
                # window used to stay open for thirty after the page gave up).
                browser.await_login(context, page, signed_in, what="TeamSnap", poll_seconds=2,
                                    deadline_seconds=540)
            except browser.LoginCancelled as exc:
                raise LinkError("the TeamSnap window was closed before signing in finished") from exc
            except TimeoutError as exc:
                raise LinkError("gave up waiting for the TeamSnap sign-in") from exc
            page = browser.watched_page(context)
            if "export_schedule" not in (page.url or ""):
                page.goto(EXPORT, wait_until="domcontentloaded", timeout=60_000)
            say("signed in — looking for your schedule's calendar link")
            feeds: list[str] = []
            for _ in range(15):          # the page fills itself in after loading
                feeds = find_feeds(page.content())
                if feeds:
                    break
                time.sleep(1)
        finally:
            browser.close_context(context)
    chosen = pick(feeds)
    if not chosen:
        raise LinkError("TeamSnap did not show a calendar link — in TeamSnap open your "
                        "team's Schedule, then Export or Subscribe, and try again")
    log.info("TeamSnap calendar address found (%d offered)", len(feeds))
    return chosen
