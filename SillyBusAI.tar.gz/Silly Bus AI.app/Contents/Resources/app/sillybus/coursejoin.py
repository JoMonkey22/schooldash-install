"""One class, one key — however each source spells its name.

Why this exists
---------------
Every source keys a class with `course_key_from_raw(its OWN name)`. Canvas
says "AP English Literature and Composition-Doud-YR_26/27", the class feed
says "AP English Literature and Composition", and the Veracross grades page
says "AP English Lit". The first two agree once the teacher suffix is cut; the
third does not, so the board drew that class twice — once with the work and
once with the grade — and the tab strip read "AEL AEL". [MEASURED] 2026-09-18
from his own install, along with "APC" and "ACA" for the same chemistry class.

Meeting dates already had a fuzzy fallback (`classfeed.MeetingIndex._key`:
prefix, then two shared words). Nothing joined grades, marks, weights or the
schedule to the class the work belongs to. This is that join, applied ONCE to
the whole state so every consumer — the board, the grade pane, chat grounding,
the Classes page — sees one key per class.

The rules, in the order they are tried
--------------------------------------
1. His own word: `ui.merge` maps a foreign key to the class it belongs to, and
   `ui.keep_apart` names keys that must never be auto-joined. Both win over
   everything below.
2. The keys already agree.
3. The names agree once ABBREVIATIONS are expanded ("AP" for "Advanced
   Placement", "Lit" for "Literature", "Chem" for "Chemistry" — quickadd's
   alias table, which already knows how students shorten class names) and
   the words that carry no identity are dropped ("the", "and", "of",
   "honors", "ap"...).
4. One key is a prefix of the other, in that normalised form.
5. They share two or more significant words AND every number or section
   letter agrees — "Honors English 1" and "Honors English 2" share two words
   and are two classes; "Physics C" and "Physics 1" likewise. In merge.py a
   number is the name of the work; here it is the name of the class.

A rule fires only when it names EXACTLY ONE candidate. Two candidates is
ambiguity, and ambiguity gets no join: a class shown twice is an annoyance, a
grade attached to the wrong class is a false fact about his marks (SPEC §5.10).

What is joined
--------------
The canonical key is the one the WORK carries — profiles and items, i.e. the
Canvas/class-feed side — because that is what the Assignments column, the
class pages and the course records are keyed by. Grades, marks, category
weights and meetings are re-keyed onto it. A foreign class that matches nothing
keeps its own key and stays on the board as its own class; the page can then
offer him the merge by hand. Nothing is dropped, and `state["course_joins"]`
records every join made so the Classes page can show it and he can undo it.
"""

from __future__ import annotations

import re

from sillybus.models import course_key_from_raw

# Words that carry no identity between two spellings of one class. "ap" and
# "honors" are in here because "AP Chemistry" and "Chemistry" ARE the same
# class at this school (Veracross drops the prefix); a school that runs both an
# AP and a regular section would tell them apart by the section letter, which
# is exactly what rule 5 refuses to ignore.
STOP = {"the", "and", "of", "to", "in", "for", "a", "an", "ap", "honors", "honours",
        "advanced", "placement", "intro", "introduction", "course", "class", "period",
        "semester", "yr", "s1", "s2"}

# Short forms students and portals use, longest first so "comp sci" beats "cs".
ALIASES = [
    ("advanced placement", "ap"), ("comp sci", "computer science"), ("computer sci", "computer science"),
    ("lit", "literature"), ("comp", "composition"), ("chem", "chemistry"), ("bio", "biology"),
    ("phys", "physics"), ("calc", "calculus"), ("alg", "algebra"), ("geo", "geometry"),
    ("eng", "english"), ("hist", "history"), ("gov", "government"), ("econ", "economics"),
    ("span", "spanish"), ("psych", "psychology"), ("theo", "theology"), ("rel", "religion"),
    ("apush", "united states history"), ("us", "united states"), ("sci", "science"),
    ("mat", "materials"), ("lang", "language"), ("stats", "statistics"), ("stat", "statistics"),
    ("cs", "computer science"), ("pe", "physical education"),
]
_ROMAN = {"i": "1", "ii": "2", "iii": "3", "iv": "4", "v": "5"}
# A token that names WHICH class: a number, a roman numeral, or a lone section
# letter after the subject ("Physics C", "Calculus BC").
_SECTION = re.compile(r"^(?:\d+|[a-d]|ab|bc|[ivx]{1,4})$")


def words(name_or_key: str) -> list[str]:
    """Significant words of a class name, aliases expanded, stop words gone,
    section markers kept and normalised. Order is kept for the prefix rule."""
    text = re.sub(r"[-_]+", " ", (name_or_key or "").lower())
    text = re.sub(r"[^a-z0-9 ]", " ", text)
    text = f" {text} "
    for short, full in ALIASES:
        text = re.sub(rf" {re.escape(short)} ", f" {full} ", text)
    out = []
    for w in text.split():
        if w in _ROMAN:
            w = _ROMAN[w]
        if w in STOP:
            continue
        out.append(w)
    return out


def sections(ws: list[str]) -> set[str]:
    return {w for w in ws if _SECTION.match(w)}


def canonical_key(foreign_key: str, foreign_name: str, known: dict[str, str],
                  merge: dict | None = None, keep_apart=()) -> tuple[str, str]:
    """(the key this class should carry, how it was decided).

    `known` is canonical key -> display name for the classes the work is
    filed under. Returns the foreign key itself, with how="none", when nothing
    matches or more than one does.
    """
    merge = merge or {}
    if foreign_key in known:
        return foreign_key, "same"
    if foreign_key in merge and merge[foreign_key] in known:
        return merge[foreign_key], "merge"
    if foreign_key in set(keep_apart):
        return foreign_key, "kept-apart"
    mine = words(foreign_name or foreign_key)
    if not mine:
        return foreign_key, "none"
    my_sections = sections(mine)
    mine_key = "-".join(mine)
    by_norm: dict[str, list[str]] = {}
    for key, name in known.items():
        ws = words(name or key)
        if sections(ws) != my_sections:
            continue                       # "English 1" is not "English 2"
        by_norm.setdefault("-".join(ws), []).append(key)
    exact = by_norm.get(mine_key) or []
    if len(exact) == 1:
        return exact[0], "same-name"
    if len(exact) > 1:
        return foreign_key, "none"
    # One significant word is not a prefix, it is a subject: "English" alone
    # must not claim "AP English Literature and Composition" (the test that
    # caught it), or "Chemistry" a chemistry it is not. Two words or more.
    def two_or_more(norm: str) -> bool:
        return norm.count("-") >= 1
    prefix = [k for norm, ks in by_norm.items() for k in ks
              if norm and two_or_more(mine_key) and two_or_more(norm)
              and (norm.startswith(mine_key + "-") or mine_key.startswith(norm + "-"))]
    if len(prefix) == 1:
        return prefix[0], "prefix"
    if len(prefix) > 1:
        return foreign_key, "none"
    my_set = set(mine)
    scored = []
    for norm, ks in by_norm.items():
        shared = my_set & set(norm.split("-"))
        if len(shared) >= 2:
            scored.extend((len(shared), k) for k in ks)
    if not scored:
        return foreign_key, "none"
    scored.sort(reverse=True)
    if len(scored) > 1 and scored[0][0] == scored[1][0]:
        return foreign_key, "none"         # a tie is an ambiguity, not a coin flip
    return scored[0][1], "words"


def unify(state: dict, ui: dict | None = None) -> dict:
    """Re-key every foreign class in `state` onto the class the work carries.

    In place, idempotent. The canonical side is profiles + items; grades,
    scores, gradebook, schedule and meetings_today are re-keyed. Joins are
    written to `state["course_joins"]` for the Classes page.
    """
    ui = ui or {}
    merge = dict(ui.get("merge") or {})
    keep_apart = set(ui.get("keep_apart") or [])
    known: dict[str, str] = {}
    for p in state.get("profiles") or []:
        if p.get("course_key"):
            known.setdefault(p["course_key"], p.get("display_name") or p.get("course_raw") or "")
    for i in state.get("items") or []:
        if i.get("course_key") and i.get("source") != "custom":
            known.setdefault(i["course_key"], (i.get("course") or "").split("-")[0].strip())
    if not known:
        return state
    # Joins made on an earlier pass are kept: after persist the grades already
    # carry the canonical key, so a re-run would find nothing to join and the
    # Classes page would lose its "also known as" line — and with it the
    # button that undoes a wrong join. Dropped only when he has since said so.
    joins: dict[str, dict] = {}
    for j in state.get("course_joins") or []:
        if (isinstance(j, dict) and j.get("to") in known and j.get("from")
                and j["from"] not in keep_apart and j["from"] not in known):
            if j.get("how") == "merge" and merge.get(j["from"]) != j["to"]:
                continue                       # a merge he has since removed
            joins[j["from"]] = j

    def resolve(key: str, name: str) -> str:
        if not key or key in known:
            return key
        if key in joins:
            return joins[key]["to"]
        to, how = canonical_key(key, name, known, merge, keep_apart)
        if to != key:
            joins[key] = {"from": key, "to": to, "name": name or key,
                          "canonical_name": known.get(to, to), "how": how}
        return to

    for g in state.get("grades") or []:
        g["course_key"] = resolve(g.get("course_key") or "", g.get("display_name") or "")
    # two grades landing on one class: keep the graded one, or the first
    seen: dict[str, dict] = {}
    for g in state.get("grades") or []:
        k = g["course_key"]
        if k not in seen or (g.get("graded") and not seen[k].get("graded")):
            seen[k] = g
    if state.get("grades"):
        state["grades"] = list(seen.values())
    for s in state.get("scores") or []:
        s["course_key"] = resolve(s.get("course_key") or "", "")
    book = state.get("gradebook") or {}
    if book:
        rekeyed = {}
        for k, rec in book.items():
            to = resolve(k, (rec or {}).get("display_name") or "")
            if isinstance(rec, dict):
                rec["course_key"] = to
            rekeyed.setdefault(to, rec)
        state["gradebook"] = rekeyed
    for day, meetings in (state.get("schedule") or {}).items():
        for m in meetings or []:
            m["course_key"] = resolve(m.get("course_key") or "", m.get("course_raw") or "")
    for m in state.get("meetings_today") or []:
        m["course_key"] = resolve(m.get("course_key") or "", m.get("course_raw") or "")
    state["course_joins"] = sorted(joins.values(), key=lambda j: j["to"])
    if state.get("grades") is not None and "grades_summary" in state:
        grades = state["grades"]
        scored = [g for g in grades if g.get("graded") and g.get("percent") is not None]
        state["grades_summary"] = {**state.get("grades_summary", {}),
                                   "courses": len(grades), "graded": len(scored),
                                   "ungraded": len(grades) - len(scored)}
    return state
