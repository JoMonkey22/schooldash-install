"""SillyBus AI included: the owner's server answers the AI features.

[ASKED] 2026-10-01: *"add payment for silly bus"*, *"Free month, then
$5/mo"*, *"Only the AI features"*, *"use my api key"*, and *"add a 7 a month
for that and better gmail"*. So the AI behind chat, quizzes, ⚡ Accelerate
and the work checker can come from the owner's server (the Cloudflare
Worker shared with Better Gmail, `better-gmail/server/`), which adds the
owner's Anthropic key. That server keeps the books:

- every account not paying gets 10¢ of AI a month on the owner's key, a
  subscriber $1 ([ASKED] 2026-10-06: "only 10c in APi tokens a month plus
  Cost of learning a class");
- learning a class (x-bgx-purpose: learn) spends from its own pot, outside
  the 10¢, and is never refused for not paying — so the board stays free;
- a subscription — SillyBus AI at $5 a month, or Better Gmail + SillyBus AI
  at $7 — paid inside SillyBus's settings, once a SillyBus price exists.

Nothing here decides who has paid: every answer the server gives says so
itself (402 past the 10¢ when a subscription is on offer, 429 when an
allowance is used). This module only names the install and the account to
it, and asks it for the plan to show in Settings.

What is sent: the install id (random, made here), the signed-in SillyBus
account's email, and — for an AI feature — the prompt that feature builds,
exactly as it would go to Anthropic. Never the board itself.
"""

from __future__ import annotations

import secrets
import string

import httpx

from sillybus import config, paths
from sillybus.logging_setup import get

log = get("billing")

APP = "sillybus"
# Haiku 4.5: the one model the server accepts, and the one plans.py's
# figures were measured on.
MODEL = "claude-haiku-5-5"


def enabled() -> bool:
    cfg = config.load().get("billing") or {}
    return bool(cfg.get("enabled", True) and cfg.get("server"))


def server() -> str:
    return str((config.load().get("billing") or {}).get("server") or "").rstrip("/")


def install_id() -> str:
    """A random id for this copy of SillyBus, made once. It identifies no
    one; the server counts a free month and a day's requests against it."""
    target = paths.data_dir() / "install-id"
    try:
        got = target.read_text(encoding="utf-8").strip()
        if 16 <= len(got) <= 40 and got.isalnum() and got.islower():
            return got
    except OSError:
        pass
    alphabet = string.ascii_lowercase + string.digits
    made = "".join(secrets.choice(alphabet) for _ in range(28))
    try:
        target.write_text(made, encoding="utf-8")
    except OSError as exc:
        log.warning("could not keep the install id: %s", exc)
    return made


def account_email() -> str:
    from sillybus import account
    session = account.current() or {}
    return str(session.get("email") or "").strip().lower()


def account_token() -> str:
    from sillybus import account
    session = account.current() or {}
    return str(session.get("token") or "")


def headers() -> dict:
    # x-bgx-whole: every SillyBus caller throws away an answer cut off at its
    # limit (anthropic_api._call raises on stop_reason "max_tokens"), so the
    # relay must refuse rather than quietly shorten one and charge for it.
    out = {"x-bgx-app": APP, "x-bgx-install": install_id(), "x-bgx-whole": "1",
           "anthropic-version": "2023-06-01", "content-type": "application/json"}
    email = account_email()
    if email:
        out["x-bgx-account"] = email
        # The proof that it IS this account (prosecution round 4, 2026-10-07):
        # the relay asks the SillyBus account server whose token this is, so
        # nobody can name another student and spend their allowance. Both
        # servers are SillyBus's own; the token goes nowhere else.
        token = account_token()
        if token:
            out["x-bgx-token"] = token
    return out


def message_of(response) -> str:
    """The server's own sentence ("Your free month is over…"), never a
    status line."""
    try:
        err = (response.json() or {}).get("error") or {}
        if err.get("message"):
            return str(err["message"])
    except Exception:  # noqa: BLE001
        pass
    return f"SillyBus AI's server answered {response.status_code}."


def _call(method: str, path: str, **kw) -> dict:
    if not enabled():
        return {"ok": False, "error": "SillyBus AI included is turned off on this computer."}
    try:
        response = httpx.request(method, f"{server()}{path}", headers=headers(), timeout=20, **kw)
    except httpx.HTTPError as exc:
        return {"ok": False, "error": f"Could not reach SillyBus AI's server ({exc.__class__.__name__})."}
    if response.status_code >= 400:
        return {"ok": False, "status": response.status_code, "error": message_of(response)}
    try:
        return {"ok": True, **(response.json() or {})}
    except ValueError:
        return {"ok": False, "error": "SillyBus AI's server sent something unreadable."}


def status(recheck: bool = False) -> dict:
    """{state: free|trial|paid|expired, daysLeft, price, plans, usage}."""
    return _call("GET", "/v1/status" + ("?recheck=1" if recheck else ""))


def checkout(plan: str = "sillybus") -> dict:
    """An embedded Stripe Checkout Session for Settings: {clientSecret,
    publishableKey, price}. `plan` is "sillybus" or "bundle"."""
    return _call("POST", "/v1/checkout" + ("?plan=bundle" if plan == "bundle" else ""))


def subscription() -> dict:
    return _call("GET", "/v1/subscription")


def cancel(resume: bool = False) -> dict:
    """Ends the plan at the close of the month already paid for, or (resume)
    takes that back."""
    return _call("POST", "/v1/cancel" + ("?resume=1" if resume else ""))
