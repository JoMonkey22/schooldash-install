"""Which period each class meets, worked out from the schedule itself.

The class feed carries no period numbers (classfeed.py writes `period=None`
for every meeting). What it does carry is the shape of the week, and one
kind of anchor: a free period is named by its number — "5th Period Free",
"1st Period Free". [MEASURED] 2026-09-20 on a real board:

    A days   08:00 Science & Religion   09:30 AP Calculus BC   11:40 AP Lit   13:10 AP Human Geo   14:30 Materials Science
    B days   08:00 5th Period Free      09:30 Team Campion     11:40 AP Physics C   13:10 AP Chemistry   14:30 Materials Science

Two day types, four blocks each, and a class (Materials Science, and the
sport beside it) that meets every day in the last slot and belongs to no
numbered period. "5th Period Free" in B's first block says B's blocks are
periods 5, 6, 7, 8; A, with four blocks of its own, is then 1, 2, 3, 4.

How it is done:
1. Meetings are grouped by day; each day's blocks are its distinct start
   times, in order.
2. A class that meets on (nearly) every school day at the same time is a
   daily class — no period; it is left out of the block structure.
3. Days are clustered into day TYPES by the set of classes they hold (two
   days are the same type when they share most of their classes; a short
   day with fewer blocks still matches the type it is a subset of).
4. Every anchor (an "Nth period free" name) says: in this day type, the block
   it occupies is period N, so block j is period N + (j - i).
5. A day type with no anchor takes the lowest run of numbers nobody holds,
   in the order the types first appear in the week: with B anchored at 5–8
   a four-block A is 1–4; with no anchor at all A is 1–4 and B follows.
6. A class's period is the number its block carries; a class in two
   different blocks (a lab that moves) keeps the most common answer.

Nothing is guessed where the data is silent: a week with no anchor and one
day type still numbers its blocks 1..k (the only honest reading of a
single-type week); a week with two types and no anchor at all numbers them
in order of first appearance, and the class page says "from the schedule"
so the student knows where the number came from and can override it.
"""
from __future__ import annotations

import re
from collections import Counter, defaultdict

FREE_PERIOD = re.compile(r"\b(\d{1,2})(?:st|nd|rd|th)?\s*(?:period|per\.?|pd\.?)\s*free\b|\bfree\s*(?:period|per\.?)\s*(\d{1,2})\b", re.IGNORECASE)
FREE_KEY = re.compile(r"^(\d{1,2})(?:st|nd|rd|th)-period-free$")
MAX_PERIOD = 8


def anchor_number(course_key: str, course_raw: str = "") -> int | None:
    """The period number a free period is named with, or None."""
    m = FREE_KEY.match(course_key or "")
    if m:
        return int(m.group(1))
    m = FREE_PERIOD.search(course_raw or "")
    if m:
        return int(m.group(1) or m.group(2))
    return None


def _blocks(meetings: list[dict]) -> list[str]:
    """A day's distinct start times, in order."""
    return sorted({(m.get("start") or "")[11:16] for m in meetings if m.get("start")})


def infer(schedule: dict[str, list[dict]]) -> dict[str, int]:
    """{course_key: period} for every class the schedule can place."""
    days = {d: [m for m in (ms or []) if m.get("course_key") and m.get("start")]
            for d, ms in (schedule or {}).items()}
    days = {d: ms for d, ms in days.items() if ms}
    if not days:
        return {}
    ordered_days = sorted(days)

    # 2. daily classes: on almost every school day, at one time
    per_class_days: dict[str, set[str]] = defaultdict(set)
    for d, ms in days.items():
        for m in ms:
            per_class_days[m["course_key"]].add(d)
    daily = {k for k, ds in per_class_days.items() if len(ds) >= 0.8 * len(days)}
    blocks_by_day = {d: _blocks([m for m in ms if m["course_key"] not in daily]) for d, ms in days.items()}
    blocks_by_day = {d: b for d, b in blocks_by_day.items() if b}
    if not blocks_by_day:
        return {}

    # 3. day types by class set (a short day is a subset of its type)
    def classes_of(d):
        return frozenset(m["course_key"] for m in days[d] if m["course_key"] not in daily)
    types: list[dict] = []          # {"classes": set, "days": [..], "blocks": [..]}
    for d in ordered_days:
        if d not in blocks_by_day:
            continue
        cs = classes_of(d)
        home = None
        for t in types:
            shared = len(cs & t["classes"])
            if shared and shared >= 0.6 * min(len(cs), len(t["classes"])):
                home = t
                break
        if home is None:
            home = {"classes": set(), "days": [], "blocks": []}
            types.append(home)
        home["classes"] |= cs
        home["days"].append(d)
        if len(blocks_by_day[d]) > len(home["blocks"]):
            home["blocks"] = blocks_by_day[d]      # the fullest day defines the type's blocks

    # which block each class sits in, per type (by start time, most common)
    def block_index(t, course_key):
        votes = Counter()
        for d in t["days"]:
            for m in days[d]:
                if m["course_key"] != course_key:
                    continue
                start = (m.get("start") or "")[11:16]
                full = _blocks([x for x in days[d] if x["course_key"] not in daily])
                if start in full:
                    # map this day's block position onto the type's fullest day
                    j = full.index(start)
                    if len(full) < len(t["blocks"]) and start in t["blocks"]:
                        j = t["blocks"].index(start)
                    votes[j] += 1
        return votes.most_common(1)[0][0] if votes else None

    # 4. anchors
    starts: dict[int, int] = {}
    for idx, t in enumerate(types):
        for d in t["days"]:
            for m in days[d]:
                n = anchor_number(m["course_key"], m.get("course_raw") or "")
                if n is None or m["course_key"] in daily:
                    continue
                j = block_index(t, m["course_key"])
                if j is not None:
                    starts.setdefault(idx, n - j)
    # 5. unanchored types take the lowest run of numbers nobody holds, in the
    #    order the types first appear: with B anchored at 5–8, a four-block A
    #    is 1–4; with no anchor at all, A is 1–4 and B follows at 5.
    used: set[int] = set()
    for idx, s in starts.items():
        used |= set(range(s, s + len(types[idx]["blocks"])))
    for idx, t in enumerate(types):
        if idx in starts:
            continue
        k = len(t["blocks"])
        start = 1
        while any(n in used for n in range(start, start + k)):
            start += 1
        starts[idx] = start
        used |= set(range(start, start + k))

    # A week that does not have the shape gets no numbers at all. A daily
    # rotation (a different class in every slot each day, the dev fixture's
    # own schedule) clusters into many "types" and would hand out confident
    # nonsense — six classes at period 8. [MEASURED] 2026-09-20. Two or three
    # day types is the shape; a class must live in one type; no two classes
    # may share a number.
    if len(types) > 3:
        return {}
    homes: dict[str, set[int]] = defaultdict(set)
    for idx, t in enumerate(types):
        for course_key in t["classes"]:
            homes[course_key].add(idx)
    if any(len(h) > 1 for h in homes.values()):
        return {}

    # 6. every class's number
    out: dict[str, int] = {}
    for idx, t in enumerate(types):
        for course_key in t["classes"]:
            if anchor_number(course_key) is not None:
                continue
            j = block_index(t, course_key)
            if j is None:
                continue
            period = starts[idx] + j
            if 1 <= period <= MAX_PERIOD:
                out[course_key] = period
    if len(set(out.values())) != len(out):
        return {}
    return out


def annotate(schedule: dict[str, list[dict]], periods: dict[str, int] | None = None) -> dict[str, int]:
    """Write the inferred period onto every meeting that has none, in place.
    Returns what was inferred so the caller can record it."""
    periods = periods if periods is not None else infer(schedule)
    for ms in (schedule or {}).values():
        for m in ms or []:
            if not m.get("period") and m.get("course_key") in periods:
                m["period"] = periods[m["course_key"]]
    return periods
