"""The pipeline: stages 1–7 of spec §7.3. There is exactly ONE code path that
produces data — the CLI, the dashboard Refresh, and the skill all call
refresh(). Emits a progress event per step.
"""

import contextlib
import fcntl
import hashlib
import json
import os
import re
import time
import uuid
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path


from sillybus import config, db, duedates, merge as merge_mod, paths, scoring, timezones
from sillybus.feeds import classfeed, ical, veracross
from sillybus.logging_setup import get
from sillybus.models import Item, Run, course_key_from_raw
from sillybus.profiling import store

log = get("pipeline")


def today_local() -> date:
    """The pipeline's 'today'. SILLYBUS_TODAY=YYYY-MM-DD pins it, which is
    how measured baselines are reproduced in verification."""
    pinned = os.environ.get("SILLYBUS_TODAY")
    if pinned:
        return date.fromisoformat(pinned)
    return datetime.now(timezones.zone()).date()


@dataclass
class RefreshOptions:
    docs_only: bool = False
    profiles_dir: str | None = None
    course: str | None = None
    # [MEASURED] 2026-09-02 (COUNT 29): defaulting this off meant the app's
    # Refresh button — which posts an empty body — silently skipped the docs of
    # two of his fourteen courses, Spanish 1 and AI Frontiers, every single
    # time. The warning it produced said "pass --include-private-docs", a
    # terminal flag, to a student who does not use terminals.
    #
    # The cost of defaulting it on is nothing when no private doc exists: the
    # browser is opened lazily, on the first one actually encountered. When one
    # does exist, a second browser launch is the price of that class's
    # homework appearing at all.
    include_private_docs: bool = True
    verbose: bool = False
    emit: object = None            # callable(stage, message, level, course)
    persist: bool = True


def _emit(options, stage, message, level="info", course=None):
    """Log it, and tell the page if anyone is listening.

    `options` may be None: several stage functions take `options=None` in their
    own signatures, and a caller that honours that — a test, or a stage called
    on its own — used to crash HERE, on `options.emit`, after the work had
    already succeeded. The log line always happens; the callback is the
    optional half.
    """
    log.log(30 if level == "warning" else 40 if level == "error" else 20,
            "[%s] %s%s", stage, f"{course}: " if course else "", message)
    if options is not None and getattr(options, "emit", None):
        options.emit(stage, message, level, course)


# How many items in one course must disagree the same way before it is called
# a pattern rather than a coincidence. Two is enough: a teacher who mislabels
# one date is normal, a course whose every date is one class out is a profile
# that reads the wrong column.
CONVENTION_EVIDENCE = 2


def column_convention_warnings(conflicts: list, index, profiles: dict) -> list[str]:
    """Classes whose doc dates are consistently one class off Canvas.

    This is the only independent check available on whether a class profile
    reads its teacher's doc correctly: Canvas carries real due dates for some
    of the same work, so a repeated one-meeting offset in one direction means
    the profile has the wrong convention for its work column — exactly the bug
    he reported on 2026-09-02, when every Honors Algebra item was one class
    early because "THE WORK" was read as due-that-day instead of set-that-day.
    """
    by_course: dict = {}
    for row in conflicts:
        by_course.setdefault(row["course_key"], []).append(row)

    warnings: list[str] = []
    for key, rows in sorted(by_course.items()):
        profile = profiles.get(key)
        lookup = (profile.get("course_raw") if profile else None) or key
        known = index.dates(lookup)
        if not known:
            continue
        early = late = 0
        for row in rows:
            try:
                doc_day = date.fromisoformat(row["doc_date"])
                canvas_day = date.fromisoformat(row["canvas_date"])
            except ValueError:
                continue
            later = [d for d in known if d > doc_day]
            earlier = [d for d in known if d < doc_day]
            if later and later[0] == canvas_day:
                early += 1
            elif earlier and earlier[-1] == canvas_day:
                late += 1
        name = (profile.get("display_name") if profile else None) or key
        if early >= CONVENTION_EVIDENCE:
            warnings.append(
                f"{name}: {early} item(s) are dated one class EARLIER than "
                "Canvas says. Its work column probably lists homework SET that "
                "day rather than due that day — set layout."
                "assigned_column_headers in its class profile")
        elif late >= CONVENTION_EVIDENCE:
            warnings.append(
                f"{name}: {late} item(s) are dated one class LATER than Canvas "
                "says. Its work column probably lists work DUE that day — move "
                "the header from assigned_column_headers to "
                "due_column_headers in its class profile")
    return warnings


# How long an undated item stays on the board.
#
# `_within_reach` keeps undated items on purpose — "an undated item is a
# question, not an expired deadline" — and that is right for a question asked
# this week. [MEASURED] 2026-09-02: "Orientation Day (first day of week 1 8/6)"
# and "Complete Four 'F's handout (will present on Day 1)" were both first
# seen on 2026-08-26 and were still on the board a month into term. Neither can
# ever be dated: the page has no heading for them. Left alone, by June the
# board carries a year of them.
#
# Two weeks is long enough that a real question survives every weekend and
# half-term, and short enough that the first week of school does not follow him
# to Christmas. Nothing is deleted — item_history keeps everything — and the
# count is shown, because a trimmed list has to state its true total.
UNDATED_STALE_DAYS = 14


class _Shim:
    """Lets `retire_stale_undated` read a plain state dict with the same two
    attributes it reads off an Item. Nothing more than that: two field names,
    one place, rather than two versions of the rule."""

    __slots__ = ("entry",)

    def __init__(self, entry: dict):
        self.entry = entry

    @property
    def item_id(self):
        return self.entry.get("item_id")

    @property
    def due_date(self):
        return self.entry.get("due_date")


def prose_grace() -> int:
    from sillybus.docs import prose as prose_mod

    return prose_mod.NO_SUBMISSION_GRACE_DAYS


def retire_stale_undated(items: list, first_seen: dict,
                         today: date) -> tuple[list, int]:
    """(items to show, how many undated ones were retired).

    Only items with no date at all. A dated item has its own rule.
    An item with no history is brand new, and a question asked today is
    exactly the one worth showing.
    """
    floor = today - timedelta(days=UNDATED_STALE_DAYS)
    kept = []
    retired = 0
    for item in items:
        seen = first_seen.get(getattr(item, "item_id", None))
        if item.due_date or not seen:
            kept.append(item)
            continue
        try:
            when = date.fromisoformat(str(seen)[:10])
        except ValueError:
            kept.append(item)
            continue
        if when >= floor:
            kept.append(item)
        else:
            retired += 1
    return kept, retired


def _within_reach(items: list, today: date) -> tuple[list, int]:
    """(items to show, how many were left off) for a source with no
    submitted-status.

    A doc states what was set, never what was handed in. [MEASURED] 2026-09-02:
    teaching the extractor to read the section dates in Honors Algebra's
    "Day 1 / 8/6-A / 8/7-B" cells dated all 18 of its items — 16 of them in
    August. Shown as they were, that is a permanent block of false overdue at
    the top of the board; left undated, it was 16 items with no date at all.
    Neither is the truth, and the truth is not available.

    So the same rule the Canvas pages already use: work older than the grace
    is not shown, the count that was left off IS shown, and nothing is
    deleted — `item_history` keeps every item ever seen.

    Undated items are always kept: an undated item is a question, not an
    expired deadline.
    """
    from sillybus.docs import prose as prose_mod

    floor = (today - timedelta(days=prose_mod.NO_SUBMISSION_GRACE_DAYS)).isoformat()
    kept = [i for i in items if not i.due_date or i.due_date >= floor]
    return kept, len(items) - len(kept)


def _content_key_for(signature: str, profile) -> str:
    """What must be unchanged for a cached extraction to still be right: the
    document, the profile that reads it, AND the code doing the reading.

    [PROVEN] tests/test_prosecution.py: leaving the code out of this key meant
    a refresh after any extractor change handed back the previous answer. It
    hid a whole class's homework for a term.
    """
    from sillybus.docs import fingerprint as fp_mod

    return hashlib.sha1((
        signature
        + json.dumps(profile.raw, sort_keys=True, default=str)
        + "|" + fp_mod.extraction_version()
    ).encode("utf-8")).hexdigest()


def _doc_file_info(profile, cfg) -> tuple[str, str]:
    """(kind, file_id) — the profile's own doc entry, else the imported legacy
    course-doc map matched by course name."""
    kind = profile.get("doc", "kind", default=None)
    file_id = profile.get("doc", "file_id", default=None)
    if file_id:
        return kind or "published-document", file_id
    for entry in (cfg.get("legacy_course_docs") or {}).values():
        if course_key_from_raw(entry.get("name", "")) == profile.course_key:
            return entry.get("kind", "published-document"), entry.get("file_id", "")
    return kind or "published-document", ""


# Fields a relearn must not silently overturn. `assigned_column_headers` says
# that a teacher's work column lists homework SET that day rather than due that
# day, and getting it backwards moves every date in the class by one meeting.
# It is set from a human's confirmation ("2.4 HW … is assigned this class"),
# which no model relearning the doc later has any way to know. A relearn reads
# the doc afresh, so left alone it would be free to guess `due` and quietly put
# the class one class early again — on a classmate's machine, where nobody
# knows to look. Locked profiles are never relearned at all; this protects the
# unlocked ones, including every profile seeded from the app bundle.
CONFIRMED_LAYOUT_FIELDS = ("assigned_column_headers", "due_column_headers")


def _keep_confirmed_layout(old_profile, new_raw: dict) -> list[str]:
    """Carry a human-confirmed column convention across a relearn. Returns the
    field names that were carried, for the warning the caller writes."""
    previous = old_profile.get("layout", "assigned_column_headers", default=None)
    if not previous:
        return []
    layout = new_raw.setdefault("layout", {})
    carried = []
    for field in CONFIRMED_LAYOUT_FIELDS:
        was = old_profile.get("layout", field, default=None)
        if layout.get(field) != was:
            layout[field] = was
            carried.append(field)
    return carried


class AlreadyRunning(RuntimeError):
    """Another process is already driving the browser profile."""

    def __init__(self, holder: str):
        super().__init__(f"already running ({holder})" if holder
                         else "already running")
        self.holder = holder
        self.fix = "wait for it to finish, then try again"


# Everything that drives the one persistent browser profile takes this lock.
#
# [MEASURED] 2026-09-02 (COUNT 24): the 13:10 refresh collided with another
# SillyBus AI process — "another SillyBus AI browser window is already open (pid
# 3319)" — so Canvas silently degraded to the iCal feed, the grades pull timed
# out after 60s, and then the damaged run WROTE its result over a good board.
# The only guard was a threading.Lock inside the web process, which no other
# process can see: the scheduled refresh, `run.py refresh` in a terminal and
# the app's own Refresh button are three separate processes.
#
# flock, not a pid file: the kernel releases it when the holder dies, so a
# crashed refresh cannot leave the Refresh button permanently dead. The file's
# contents are only there to name the holder in the message.
LOCK_WAIT_SECONDS = 90.0


@contextlib.contextmanager
def exclusive_run(kind: str, wait_seconds: float = LOCK_WAIT_SECONDS):
    """Hold the browser-profile lock for the duration of the block.

    Waits `wait_seconds` for the current holder to finish — most runs are
    seconds, and waiting briefly is strictly better than failing at once —
    then raises AlreadyRunning rather than proceeding with a profile it cannot
    have. A caller that cannot get the lock must not write state: a degraded
    result over a good board is worse than no result at all.
    """
    path = paths.cache_dir() / "browser-run.lock"
    handle = path.open("a+", encoding="utf-8")
    deadline = time.monotonic() + max(0.0, wait_seconds)
    while True:
        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            break
        except OSError:
            if time.monotonic() >= deadline:
                handle.seek(0)
                holder = (handle.read(200) or "").strip()
                handle.close()
                raise AlreadyRunning(holder) from None
            time.sleep(0.5)
    try:
        handle.seek(0)
        handle.truncate()
        handle.write(f"{kind} pid={os.getpid()} since="
                     f"{datetime.now(timezones.zone()).isoformat(timespec='seconds')}")
        handle.flush()
        yield
    finally:
        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        finally:
            handle.close()


def _canvas_assignment_items(context, planner_items: list, today: date,
                             cfg: dict, options, index,
                             scores: list | None = None,
                             gradebook: dict | None = None,
                             series_rows: list | None = None) -> list:
    """Assignments Canvas knows about that the planner did not hand over.

    Deduplicated against the planner by assignment URL first — Canvas's own
    identifier for the thing — and by (course, title) after, because the
    planner's html_url for a quiz points at the quiz and the assignments
    endpoint points at the assignment. Same work, two links.
    """
    from sillybus.feeds import canvas as canvas_mod
    from sillybus.feeds import canvas_pages as pages_mod

    window = cfg["window"]
    # Indexed rather than a set of keys, because an assignment the planner
    # already has is not a duplicate to drop — it is the same work described
    # more completely, and the richer description should win. [MEASURED]
    # 2026-09-02: "Progress Video 3" came through the planner, which carries
    # no `submission_types`, so it stayed categorised as reading even after
    # the scorer learned to tell watching from recording.
    by_url: dict = {}
    by_ref: dict = {}
    by_name: dict = {}
    for existing in planner_items:
        if existing.url:
            by_url[existing.url.rstrip("/")] = existing
        ref = _canvas_ref(existing)
        if ref[0] in ("assignment", "quiz", "discussion"):
            by_ref.setdefault(ref, existing)
        # A list, not one slot: two DIFFERENT pieces of work can share a
        # title ("Lab Report" in October and again in November), and the
        # name fallback below has to see every one of them to refuse the
        # wrong one (prosecution round 5, 2026-10-07).
        by_name.setdefault((existing.course_key,
                            (existing.title or "").strip().lower()), []).append(existing)

    added: list = []
    scores = scores if scores is not None else []
    enriched = 0
    read = 0
    # Every assignment in the course, INCLUDING the ones the board's window
    # drops as past. That is what makes `repeats` work on the first refresh
    # rather than after six weeks of history: "Warm Up 9/1" through "Warm Up
    # 9/22" are all in this response even when only the last is on the board.
    series_rows = series_rows if series_rows is not None else []
    # `canvas_courses` also returns finished summer sessions, and reading
    # their assignment lists would put last term's work on the board.
    # `current_courses` is the same test the page reader uses: a course counts
    # if it has meetings in the class feed or a card on the dashboard.
    for course in pages_mod.current_courses(context, index):
        course_id = course.get("canvas_course_id")
        # The name Canvas shows him (the nickname, if any) — what the planner
        # calls the course too, and what these items' ids have always been
        # built from (prosecution round 5, 2026-10-07: courses.canvas_courses
        # now keys the course itself by its real name).
        raw_name = (course.get("canvas_raw") or course.get("course_raw")
                    or course.get("display_name") or "")
        if not course_id:
            continue
        try:
            raw = canvas_mod.assignments_raw(context, str(course_id))
        except Exception as exc:  # noqa: BLE001 — one course, not the run
            log.info("assignments for %s unavailable: %s", raw_name, exc)
            continue
        read += 1
        # The marks Canvas has already given, kept for the per-class strengths
        # summary on the Grades page. Same fetch — no extra request.
        scores.extend(canvas_mod.scores_from_assignments(raw, raw_name))
        # And how Canvas weights them: two small requests per course, so the
        # grade page can say what share of the grade each mark carries. A
        # failure here costs only the weights for one class — never the items.
        if gradebook is not None:
            try:
                groups = canvas_mod.assignment_groups_raw(context, str(course_id))
                course_json = canvas_mod.course_grade_raw(context, str(course_id))
                record = canvas_mod.gradebook_from(raw_name, groups, course_json)
                gradebook[record["course_key"]] = record
            except Exception as exc:  # noqa: BLE001 — weights are a bonus
                log.info("assignment groups for %s unavailable: %s", raw_name, exc)
        course_key = course_key_from_raw(raw_name)
        for entry in raw or []:
            if not entry.get("published", True):
                continue
            name = (entry.get("name") or "").strip()
            if name:
                series_rows.append(
                    (course_key, name, canvas_mod._local_day(entry.get("due_at")) or None))
        for item in canvas_mod.items_from_assignments(
                raw, raw_name, today, days_back=window["days_back"],
                days_forward=window["days_forward"], meetings=index):
            key = (item.course_key, (item.title or "").strip().lower())
            twin = (by_url.get((item.url or "").rstrip("/"))
                    or _twin_by_id(item, by_ref)
                    or _twin_by_name(item, by_name.get(key) or []))
            if twin is not None:
                if _enrich_from_assignment(twin, item):
                    enriched += 1
                continue
            by_name.setdefault(key, []).append(item)
            if item.url:
                by_url[item.url.rstrip("/")] = item
            added.append(item)
    if added or enriched:
        undated = sum(1 for i in added if not i.due_date)
        _emit(options, "canvas",
              f"{len(added)} more from {read} course assignment list(s) "
              f"({undated} with no due date) that the planner did not have"
              + (f"; {enriched} planner item(s) completed from them"
                 if enriched else ""))
    return added


# What Canvas object an item IS, read from its link: ("assignment", "101"),
# ("quiz", "7"), ("discussion", "55"), ("peer_review", "") or ("", "").
_RE_REF = (("assignment", re.compile(r"/assignments/(\d+)")),
           ("quiz", re.compile(r"/quizzes/(\d+)")),
           ("discussion", re.compile(r"/discussion_topics/(\d+)")))


_GRADED_KINDS = {"assignment", "quiz", "discussion_topic"}


def _canvas_ref(item) -> tuple[str, str]:
    """Canvas's own identifier for the work an item stands for.

    A peer review is never a twin of anything: Canvas's planner lists it
    under the reviewed assignment's own title and links it to
    /assignments/<id>/submissions/<someone>, so by link AND by name it looks
    like the assignment itself. It is a second obligation (review a
    classmate's work), and merging the student's own assignment into it hid
    the assignment and copied its submitted state onto the review
    (prosecution round 5, 2026-10-07).
    """
    kind = (item.kind or "").replace(" ", "_").lower()
    if kind == "assessment_request" or "/submissions/" in (item.url or ""):
        return ("peer_review", "")
    for name, pattern in _RE_REF:
        found = pattern.search(item.url or "")
        if found:
            return (name, found.group(1))
    return ("", "")


def _assignment_raw(item) -> dict:
    try:
        raw = json.loads(item.raw_cell or "{}")
    except (TypeError, ValueError):
        return {}
    return raw if isinstance(raw, dict) else {}


def _twin_by_id(item, by_ref: dict):
    """The planner row for the same quiz or discussion, by Canvas's own id.

    The planner links a classic quiz to /quizzes/<quiz id> and a graded
    discussion to /discussion_topics/<topic id>; the assignments endpoint
    links both to /assignments/<id> but says which quiz or topic it is. That
    is an exact match, and it is why the name fallback below is rarely needed.
    """
    raw = _assignment_raw(item)
    for kind, field in (("assignment", "assignment_id"), ("quiz", "quiz_id"),
                        ("discussion", "discussion_topic_id")):
        if raw.get(field):
            twin = by_ref.get((kind, str(raw[field])))
            if twin is not None:
                return twin
    return None


def _twin_by_name(item, candidates: list):
    """The same work under the same title, ONLY where ids cannot decide.

    [prosecution round 5, 2026-10-07] Matching on (course, title) alone
    dropped a real second "Lab Report" — #102, due Oct 30, not handed in —
    as the twin of #101, and in the other direction copied a graded #200's
    "submitted" onto a #201 nobody had handed in, which hid it as done. Two
    assignments with different /assignments/<id> links are two pieces of
    work, whatever they are called.

    So a name match counts only when one side carries no assignment id at all
    (a classic quiz or discussion the id lookup could not pair) AND both say
    the same Canvas due day, and only against a planner row that stands for
    graded work — an assignment, quiz or discussion. A wiki page or a
    planner note with the same title is a different thing to do. The day compared is Canvas's own `due_at` — not a
    date the description moved — because that is the one both endpoints
    share.
    """
    mine = _canvas_ref(item)
    raw = _assignment_raw(item)
    from sillybus.feeds import canvas as canvas_mod
    canvas_day = canvas_mod._local_day(raw.get("due_at")) if raw else item.due_date
    for other in candidates:
        theirs = _canvas_ref(other)
        if "peer_review" in (mine[0], theirs[0]):
            continue
        if (other.kind or "").replace(" ", "_").lower() not in _GRADED_KINDS:
            continue
        if mine[0] == "assignment" and theirs[0] == "assignment":
            continue                       # ids decide, and these differ
        if not canvas_day or other.due_date != canvas_day:
            continue
        return other
    return None


def _enrich_from_assignment(twin, richer) -> bool:
    """Fill in what the planner does not carry. True if anything changed.

    The planner is the student's calendar view: it has the date and the points
    but not the submission types, and its `submissions` block is a bare
    boolean that is absent for some kinds. The assignments endpoint has
    Canvas's own `workflow_state` and what the student must hand in. Neither
    the date nor the title is touched — the planner's are the student's own
    view of the same assignment.
    """
    changed = False
    # Planner rows omit instructions; keep the assignment endpoint's source
    # text when enriching the same assignment instead of dropping it.
    if richer.description and twin.description != richer.description:
        twin.description = richer.description
        changed = True
    # The one exception to "the date is not touched": the assignments reader
    # found the REAL deadline in the description (Canvas's own due_at is
    # often the day it was posted). Prosecution round 2 (2026-10-07): only the
    # flags were copied, so the planner row kept Canvas's wrong date AND
    # gained a "date moved" mark — a false marker on a date that never moved.
    DATE_FLAGS = {"date_from_description", "date_moved", "date_conflict"}
    moved = bool(DATE_FLAGS & set(richer.flags or [])) and richer.due_date and richer.due_date != twin.due_date
    if moved:
        twin.due, twin.due_date = richer.due, richer.due_date
        twin.all_day = richer.all_day
        twin.date_note = richer.date_note
        twin.extractor = richer.extractor
        twin.flags = sorted(set(twin.flags or []) | set(richer.flags))
        changed = True
    elif richer.flags and not twin.flags:
        twin.flags = [f for f in richer.flags if f not in DATE_FLAGS]
        changed = bool(twin.flags)
    if twin.points is None and richer.points is not None:
        twin.points = richer.points
        changed = True
    if twin.submitted is None and richer.submitted is not None:
        twin.submitted = richer.submitted
        changed = True
    elif richer.submitted is True and twin.submitted is False:
        # The planner's `submitted: false` is about a SUBMISSION; on-paper
        # work a teacher has graded never has one, so the planner says false
        # for ever while the assignments endpoint says workflow_state
        # "graded". Filling only a blank kept graded work on the board as
        # owed and overdue (prosecution round 5, 2026-10-07). Only this
        # direction: a stated True is never walked back by a False.
        twin.submitted = True
        changed = True
    if richer.kind == "quiz" and twin.kind != "quiz":
        twin.kind = "quiz"
        changed = True
    return changed


def pull_grades(context, options=None) -> list[dict]:
    """The Veracross grades pull, with one automatic sign-in retry. Raises.

    Shared by the full refresh and by `run.py grades`, so the retry behaviour
    cannot drift between them.
    """
    from sillybus import autologin, browser, credentials
    from sillybus.feeds import veracross_grades as grades_mod

    options = options or RefreshOptions()
    if not config.veracross_in_use():
        # (prosecution round 5, 2026-10-07) A school with no Veracross — or the
        # shipped portal while the school is unconfirmed — has no grades here,
        # and must never reach the retry below: it signed in to Brophy's
        # portal with another school's student's Google password.
        return []
    try:
        return [g.as_dict() for g in grades_mod.fetch_grades(context)]
    except browser.SessionError as dead:
        if not credentials.veracross_login():
            raise
        _emit(options, "grades", "Veracross session expired — signing back in "
              "with the saved details")
        fixed = autologin.veracross(context, capture_feeds=False)
        if not fixed.ok:
            raise browser.SessionError(
                f"Veracross session expired and the automatic sign-in did not "
                f"finish: {fixed.message}",
                fix="python run.py login --auto --veracross") from dead
        _emit(options, "grades", fixed.message)
        return [g.as_dict() for g in grades_mod.fetch_grades(context)]


def pull_gradebooks(context, grades: list, options=None) -> tuple[dict, list]:
    """Every graded class's gradebook, from Veracross — weights AND marks.

    *"i want the grades and assignment grades to only be pulled from veracross
    not canvas because how the classes are weighted is only in veracross"*.

    He is right and it is measurable. [MEASURED] 2026-09-09 on his account
    Canvas reported `group_weight` 0 on all ten courses and held **zero**
    per-assignment scores, while Veracross returned all seven graded classes,
    68 marks, and category weights whose arithmetic reproduces every reported
    percentage to the cent. Canvas is still the source for the WORK — what is
    due, and when. It is no longer a source for what anything scored.

    One request per graded class, no browser rendering: the document is
    server-rendered HTML. A class with no gradebook answers 404 and is simply
    absent (three of his ten are an advisory and two sports). A failure on one
    class costs that class's marks and nothing else — the same rule the rest
    of the refresh follows.
    """
    from sillybus.feeds import veracross_gradebook as vg

    school = vg.school_slug()
    book: dict = {}
    marks: list = []
    bridged = 0
    for grade in grades or []:
        class_id = vg.class_id_from(grade.get("detail_url") or "")
        if not class_id:
            continue
        course_key = grade.get("course_key") or ""
        try:
            # A page his own Chrome already fetched beats signing in again.
            # This is the whole point of the extension: a Veracross session
            # lives about 30 minutes and needs a launchd job to keep it warm,
            # while the browser he is sitting in front of is signed in all
            # day. Same parser either way — `vg.parse` cannot tell, and must
            # not be able to tell, where the HTML came from.
            #
            # A STALE capture is not used: bridge.fresh returns None past its
            # window and the ordinary fetch runs as it always did. A shortcut
            # past a sign-in that quietly served yesterday's grades would be
            # worse than the sign-in it replaced.
            from sillybus import bridge
            markup = bridge.fresh("veracross_gradebook", str(class_id))
            if markup:
                bridged += 1
            else:
                markup = vg.fetch(context, class_id, school)
            record = vg.parse(markup, course_key,
                              grade.get("display_name") or "")
        except Exception as exc:  # noqa: BLE001 — one class, not the refresh
            log.info("gradebook for %s unavailable: %s", course_key, exc)
            continue
        if not record:
            continue
        book[record["course_key"]] = record
        for mark in record["scores"]:
            marks.append({**mark, "course_key": record["course_key"],
                          "url": grade.get("detail_url"), "due_at": None})
        # A total we cannot reproduce is a total we must not silently redraw
        # the page from. Say it once, here, where the numbers are together.
        recomputed = vg.total_percent(record)
        if (record.get("percent") is not None and recomputed is not None
                and abs(recomputed - record["percent"]) > 0.02):
            log.info("gradebook for %s: Veracross says %.2f, the marks add to "
                     "%.2f", course_key, record["percent"], recomputed)
            record["disagrees"] = recomputed
    if book:
        _emit(options, "grades", f"read {len(marks)} mark(s) and the category "
              f"weights for {len(book)} class(es) from Veracross"
              + (f" ({bridged} of them handed over by Chrome)" if bridged else ""))
    return book, marks


def refresh_grades(options: RefreshOptions | None = None) -> dict:
    """Grades only, merged into the state that is already on disk.

    [MEASURED] 2026-09-02: a full refresh took 27 minutes, almost all of it in
    teacher docs, and the grades pull inside it timed out on a contended
    browser. "My grades are not showing" needs none of that work redone, and a
    27-minute wait to retry one page is a reason not to retry.

    Only the grades keys are touched. A failure leaves whatever grades are
    already there — with `grades_stale` saying so — rather than blanking them,
    which is the whole point of the fix this shipped with.
    """
    from playwright.sync_api import sync_playwright

    from sillybus import browser

    options = options or RefreshOptions()
    state = load_state()
    if state is None:
        # Writing a state file containing nothing but grades would leave the
        # board with no today, no items and no schedule — a shape no other
        # code expects, produced by the one command a new user might try
        # first. Checked before the browser opens, so it costs nothing.
        _emit(options, "grades", "there is no board yet — a full refresh has "
              "to run first", "warning")
        return {"ok": False, "kept": 0,
                "error": "there is no board yet — press Refresh on the page "
                         "(or run: python run.py refresh) first",
                "fix": paths.runnable("python run.py refresh")}
    _emit(options, "grades", "reading course grades")
    try:
        # The same lock a full refresh takes: this drives the same browser
        # profile, and racing a refresh for it is what broke the grades pull
        # in the first place (COUNT 24).
        with exclusive_run("grades"), sync_playwright() as pw:
            context = browser.open_context(pw, headless=True)
            try:
                grades = pull_grades(context, options)
                vc_gradebook, vc_scores = pull_gradebooks(context, grades, options)
            finally:
                browser.close_context(context)
    except Exception as exc:  # noqa: BLE001 — reported, never raised at a button
        _emit(options, "grades", f"unavailable ({exc})", "warning")
        kept = len(state.get("grades") or [])
        return {"ok": False, "error": str(exc), "kept": kept,
                "fix": paths.runnable(getattr(exc, "fix", "python run.py login "
                                              "--auto --veracross"))}

    scored = sum(1 for g in grades if g["graded"])
    _emit(options, "grades", f"{len(grades)} course(s), {scored} graded")
    if options.persist and grades:
        state["grades"] = grades
        state["grades_summary"] = _grades_summary(grades)
        state["grades_stale"] = None
        # "Grades only" must not be a downgrade. The grade page is drawn from
        # `scores` and `gradebook`, so a grades refresh that updated the
        # percentages and left last night's marks behind would show a class
        # total that its own assignment list cannot add up to.
        if vc_gradebook:
            state["gradebook"] = vc_gradebook
            state["scores"] = vc_scores
            state["scores_stale"] = None
        state["grades_read_at"] = datetime.now(
            timezones.zone()).isoformat(timespec="seconds")
        target = paths.state_json_path()
        tmp = target.with_suffix(".tmp")
        tmp.write_text(json.dumps(state, indent=1, ensure_ascii=False,
                                  default=str), encoding="utf-8")
        tmp.replace(target)
        _emit(options, "persist", f"grades written ({len(grades)} course(s))")
    return {"ok": True, "courses": len(grades), "graded": scored,
            "grades": grades}


def _relearn(profile, kind, file_id, html, index):
    """One targeted relearn during a refresh. Returns the new raw profile, or
    None on any failure (the caller keeps the old profile and says so)."""
    try:
        from sillybus.ai import detect
        from sillybus.profiling import builder
        provider = detect.provider_for("profiling")
        if provider.name == "null":
            return None
        return builder.build_profile_for_course(
            profile.get("course_raw") or profile.course_key,
            profile.get("canvas_course_id") or "",
            profile.get("canvas_url") or "",
            {"file_id": file_id, "kind": kind,
             "url": profile.get("doc", "url", default=None),
             "candidates": profile.get("doc", "candidates", default=[])},
            html, index, provider)
    except Exception as exc:  # noqa: BLE001
        log.warning("auto-relearn failed for %s: %s", profile.course_key, exc)
        return None


def refresh(options: RefreshOptions | None = None) -> dict:
    """A refresh, holding the browser-profile lock for its whole run.

    Two refreshes at once was the cause of COUNT 24: the loser cannot have the
    browser, degrades to the iCal feed with no grades, and then writes that
    over a good board. Raising here means the loser writes nothing at all,
    which is the only safe outcome. `exclusive_run` waits first, because most
    runs finish in seconds and a short wait beats an immediate refusal.
    """
    options = options or RefreshOptions()
    with exclusive_run("refresh"):
        return _refresh_locked(options)


def _refresh_locked(options: RefreshOptions) -> dict:
    from sillybus.docs import fetch as fetch_mod
    from sillybus.docs import fingerprint as fp_mod
    from sillybus.docs import items as items_mod

    options = options or RefreshOptions()
    cfg = config.load(refresh=True)
    conn = db.connect()
    started = datetime.now(timezones.zone())
    run = Run(run_id=uuid.uuid4().hex[:12], started=started.isoformat(timespec="seconds"))
    today = today_local()
    warnings: list[str] = []
    errors: list[dict] = []
    diagnostics: dict = {"per_course": {}, "fingerprint_changes": [],
                         "ambiguities": [], "model_calls": 0,
                         "adjudication_cap_hit": False,
                         "log_path": str(paths.log_file())}

    # Profiles are loaded before the browser opens: the Canvas-page reader in
    # stage 2.6 wants each teacher's line prefixes ("**Tarea:"), and stage 3
    # wants the whole thing.
    profiles_dir = Path(options.profiles_dir) if options.profiles_dir else None
    profiles, profile_problems = store.load_all(profiles_dir)
    for problem in profile_problems:
        warnings.append(problem)
        _emit(options, "docs", problem, "warning")
    profiles = _heal_profiles(profiles, profiles_dir, warnings, options)

    # ---- stage 1: the class feed — the dated, timed truth -------------------
    _emit(options, "feed", "fetching the class-schedule feed")
    # An empty schedule means two different things — "no classes" and "could
    # not ask" — and only this flag can tell them apart later (COUNT 25).
    feed_failed = False
    try:
        meetings, feed_warnings = classfeed.load_meetings()
        warnings.extend(feed_warnings)
    except ical.FeedError as exc:
        if not cfg["veracross"]["class_ics"] and not config.veracross_in_use(cfg):
            # (prosecution round 5, 2026-10-07) A Canvas-only school has no
            # class feed to fetch. That is the school, not a failure: no
            # "class_feed" error with a fix to sign in to a Veracross it does
            # not have, and not feed_failed, which would make the refresh
            # treat its whole Canvas board as a failed pull.
            meetings = []
            _emit(options, "feed", "no class-schedule feed — this school is set up "
                  "without Veracross, so the board comes from Canvas")
        else:
            meetings = []
            feed_failed = True
            warnings.append(f"class feed unavailable: {exc}")
            errors.append({"code": "class_feed", "message": str(exc),
                           "fix": paths.runnable(getattr(exc, "fix", ""))})
    meetings, sports_hidden = classfeed.without_sports(meetings, cfg)
    if sports_hidden:
        _emit(options, "feed", "left out of the schedule (times come from TeamSnap): "
              + ", ".join(sports_hidden))
    index = classfeed.MeetingIndex(meetings)
    _emit(options, "feed", f"{len(meetings)} meetings, "
          f"{len({m.course_key for m in meetings})} courses")

    # ---- stage 2 + 2.5: Canvas planner and Veracross grades ----------------
    #
    # One browser for both. They used to launch Chrome twice per refresh —
    # [MEASURED] 2026-09-01: ~15 s of a 15.5 s refresh was browser start-up —
    # and the second launch bought nothing, because the two sites fail
    # independently whichever process holds them. So: one context, two
    # try-blocks, and each block still reports its own outcome.
    #
    # When a session is dead and the student has saved their sign-in details,
    # the refresh signs itself back in before giving up (autologin.py). It never
    # opens a window from here: a refresh runs unattended, and a window nobody
    # asked for is the interruption this app has been told off for before. A
    # step that needs a person is reported as an error with a button.
    canvas_items: list[Item] = []
    # Marks Canvas has given, by course — the basis for the Grades page's
    # "what you do well" summary. Never a claim about the report-card grade:
    # Canvas does not publish the category weights.
    canvas_scores: list[dict] = []
    # (course_key, title, due_date) for every assignment Canvas knows about,
    # past ones included. `repeats` turns these into series at stage 6.
    series_rows: list = []
    # How Canvas weights those marks, by course (canvas.gradebook_from).
    canvas_gradebook: dict = {}
    # The gradebook of record: Veracross's marks and category weights, by
    # course. These are what the grade page draws — see pull_gradebooks.
    vc_gradebook: dict = {}
    vc_scores: list[dict] = []
    session_ok = None
    grades: list = []
    # Set when the grades pull itself failed, as opposed to genuinely finding
    # no grades yet. An empty list means opposite things in those two cases and
    # the difference is not recoverable after the fact — see _carry_grades.
    grades_failed = False
    page_items: list[Item] = []
    if not options.docs_only:
        from sillybus import autologin, browser, credentials
        from sillybus.feeds import canvas as canvas_mod
        from sillybus.feeds import veracross_grades as grades_mod

        def _login_error(code, result, default_fix):
            fix = default_fix
            errors.append({"code": code, "message": result.message,
                           "fix": paths.runnable(fix),
                           "needs_human": bool(result.needs_human),
                           "auto_login": result.how})

        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as pw:
                context = browser.open_context(pw, headless=True)
                try:
                    # -- Canvas planner ---------------------------------------
                    _emit(options, "canvas", "pulling the Canvas planner")
                    try:
                        if not browser.whoami(context):
                            if credentials.has("google"):
                                _emit(options, "canvas", "session expired — signing "
                                      "back in with the saved details")
                                fixed = autologin.canvas(context)
                                if not fixed.ok:
                                    raise browser.SessionError(
                                        f"Canvas session expired and the automatic "
                                        f"sign-in did not finish: {fixed.message}",
                                        fix="python run.py login --auto")
                                _emit(options, "canvas", fixed.message)
                            else:
                                raise browser.SessionError(
                                    "the Canvas session is expired or missing",
                                    fix="python run.py login")
                        session_ok = True
                        window = cfg["window"]
                        raw = canvas_mod.planner_items_raw(
                            context, today - timedelta(days=window["days_back"]),
                            today + timedelta(days=window["days_forward"]))
                        canvas_items = canvas_mod.items_from_planner(
                            raw, canvas_mod.group_course_names(context, raw))
                        _emit(options, "canvas", f"{len(canvas_items)} planner items")

                        # The planner is the student's calendar; the
                        # assignments endpoint is the course's truth. Both,
                        # because each holds things the other cannot:
                        # the planner carries calendar events and the
                        # teacher's own to-dos, and the assignments list
                        # carries undated work and anything the planner
                        # simply did not return. [MEASURED] 2026-09-02, his
                        # nine courses: Canvas held 41 published assignments,
                        # the planner returned 24 items, and a 100-point
                        # project due in 23 days and unsubmitted was in
                        # neither the board nor the window.
                        try:
                            added = _canvas_assignment_items(
                                context, canvas_items, today, cfg, options,
                                index, canvas_scores, None, series_rows)
                            if added:
                                canvas_items.extend(added)
                        except Exception as exc:  # noqa: BLE001 — the planner already worked
                            warnings.append(f"canvas assignments: {exc}")
                            _emit(options, "canvas", f"the per-course assignment "
                                  f"lists could not be read ({exc}) — the "
                                  "planner's items stand", "warning")
                    except canvas_mod.CanvasRefused as refused:
                        # A refusal about one request, with a session that
                        # works. Saying "sign in again" here would send him
                        # to a login page that fixes nothing, and marking the
                        # session dead makes the page say so too.
                        session_ok = True
                        warnings.append(f"canvas: {refused}")
                        _emit(options, "canvas", f"{refused} — falling back to "
                              "the calendar feed for this run", "warning")
                        canvas_items = veracross.canvas_ics_items()
                    except Exception as exc:  # noqa: BLE001 — the doc half must survive
                        session_ok = False
                        fix = getattr(exc, "fix", "python run.py login")
                        errors.append({"code": "canvas_session",
                                       "message": f"Canvas unavailable: {exc}",
                                       "fix": paths.runnable(fix)})
                        _emit(options, "canvas", f"unavailable ({exc}) — falling back "
                              "to the calendar feed; the doc half continues", "warning")
                        canvas_items = veracross.canvas_ics_items()
                        if canvas_items:
                            _emit(options, "canvas",
                                  f"{len(canvas_items)} items from the Canvas calendar "
                                  "feed (no points/submitted-status)")

                    # -- Veracross grades -------------------------------------
                    _emit(options, "grades", "reading course grades"
                          if config.veracross_in_use(cfg)
                          else "no Veracross set up for this school — no grades to read")
                    try:
                        grades = pull_grades(context, options)
                        scored = sum(1 for g in grades if g["graded"])
                        _emit(options, "grades",
                              f"{len(grades)} course(s), {scored} graded so far")
                        # The marks and the weights, from the gradebook of
                        # record. Canvas is no longer asked for either.
                        vc_gradebook, vc_scores = pull_gradebooks(
                            context, grades, options)
                    except Exception as exc:  # noqa: BLE001 — homework matters more than grades
                        grades_failed = True
                        _emit(options, "grades",
                              f"unavailable ({exc}) — the rest of the refresh continues",
                              "warning")
                        warnings.append(f"grades: {exc}")
                        fix = getattr(exc, "fix", "")
                        if fix:
                            errors.append({"code": "veracross_grades",
                                           "message": str(exc),
                                           "fix": paths.runnable(fix)})
                    # -- stage 2.6: the course pages themselves ---------------
                    #
                    # Work typed straight onto the Canvas homepage, on a
                    # schedule-ish wiki page, or in an announcement. [MEASURED]
                    # 2026-09-01: Spanish 1's homepage listed a quiz that day
                    # and a test two days later, and the board showed nothing
                    # for that class — the planner had no Canvas assignment for
                    # any of it and the course's Google Doc is private.
                    if session_ok:
                        _emit(options, "pages", "reading the course homepages")
                        try:
                            from sillybus.feeds import canvas_pages

                            def page_emit(message, course, level="info"):
                                _emit(options, "pages", message, level, course)

                            page_items, page_diagnostics = canvas_pages.collect(
                                context, index, conn, today, profiles,
                                emit=page_emit)
                            diagnostics["pages"] = page_diagnostics
                            _emit(options, "pages",
                                  f"{len(page_items)} item(s) from "
                                  f"{page_diagnostics['pages_read']} page(s) read, "
                                  f"{page_diagnostics['pages_reused']} unchanged, "
                                  f"{page_diagnostics['announcements_read']} "
                                  "announcement(s)")
                            if page_diagnostics["dropped_outside_window"]:
                                _emit(options, "pages",
                                      f"{page_diagnostics['dropped_outside_window']} "
                                      "item(s) on those pages are outside the "
                                      f"{cfg['window']['days_back']}-day/"
                                      f"{cfg['window']['days_forward']}-day window "
                                      "and are not shown")
                        except Exception as exc:  # noqa: BLE001 — never the run
                            log.exception("reading the course pages failed")
                            warnings.append(f"course pages: {exc}")
                            _emit(options, "pages",
                                  f"could not be read ({exc}) — the rest of the "
                                  "refresh continues", "warning")
                finally:
                    browser.close_context(context)
        except Exception as exc:  # noqa: BLE001 — the browser itself would not start
            session_ok = False
            fix = getattr(exc, "fix", "close any SillyBus AI browser window and refresh again")
            errors.append({"code": "canvas_session",
                           "message": f"Canvas unavailable: {exc}",
                           "fix": paths.runnable(fix)})
            _emit(options, "canvas", f"the browser could not start ({exc}) — falling "
                  "back to the calendar feed; the doc half continues", "warning")
            canvas_items = veracross.canvas_ics_items()
            grades_failed = True
            warnings.append(f"grades: {exc}")

    # ---- stage 3: published docs, profile-driven -----------------------------
    #
    # A private doc — one shared with the class rather than published to the
    # web — can only be read through the signed-in browser. Stage 2 has a
    # context but closes it, so --include-private-docs could never do anything:
    # [MEASURED] 2026-08-26, two of eleven courses reported "a private doc
    # needs the browser session" whether or not the flag was passed.
    #
    # Opened lazily, and at most once. Most refreshes touch no private doc at
    # all, and launching a browser to discover that would add seconds to every
    # single run for nothing.
    doc_browser: dict = {"playwright": None, "context": None,
                         "failed": False}

    def _doc_context():
        if not options.include_private_docs or doc_browser["failed"]:
            return None
        if doc_browser["context"] is None:
            try:
                from playwright.sync_api import sync_playwright
                from sillybus import browser as browser_mod
                doc_browser["playwright"] = sync_playwright().start()
                doc_browser["context"] = browser_mod.open_context(
                    doc_browser["playwright"], headless=True)
            except Exception as exc:  # noqa: BLE001 — never the whole run
                # This is called as an ARGUMENT inside a try that only catches
                # DocError, so anything escaping here aborted the entire
                # refresh — including the courses whose docs are public and
                # were about to read fine (COUNT 29). Once it has failed, stop
                # retrying: fourteen courses would mean fourteen attempts.
                doc_browser["failed"] = True
                _emit(options, "docs", f"private docs need the browser and it "
                      f"could not start ({exc}) — the public docs continue",
                      "warning")
                warnings.append(f"private docs unavailable: {exc}")
                return None
        return doc_browser["context"]

    def _close_doc_context():
        if doc_browser["context"] is not None:
            try:
                browser.close_context(doc_browser["context"])
            except Exception:  # noqa: BLE001
                pass
        if doc_browser["playwright"] is not None:
            try:
                doc_browser["playwright"].stop()
            except Exception:  # noqa: BLE001
                pass

    doc_items: list[Item] = []
    ambiguities: list[dict] = []
    # Which courses is this person actually in? Their own class feed plus
    # whatever Canvas returned for them. Used only to suppress bundle-seeded
    # profiles below, so an empty answer suppresses nothing.
    enrolled = {m.course_key for m in meetings}
    enrolled |= {i.course_key for i in canvas_items if getattr(i, "course_key", None)}

    for key, profile in sorted(profiles.items()):
        if options.course and options.course not in key:
            continue
        # Self-heal for installs seeded before seed_missing knew about
        # enrolment: a profile that came from someone else's bundle, for a
        # course this person has no trace of, is skipped rather than having its
        # doc fetched — otherwise the board shows a stranger's classes and
        # homework. Guarded on `enrolled` being non-empty, because "we could
        # not read the feed" must never be mistaken for "not enrolled", and it
        # warns rather than hiding, per the nothing-is-hidden rule.
        # And whatever the enrolment says, a starter profile learned on another
        # school's Canvas is not this student's class, however alike the names
        # (prosecution round 5, 2026-10-07): a classmate at another school was
        # "enrolled" in honors-biology and got Brophy's teacher's doc.
        foreign = bool(profile.get("seeded_from_bundle")) and store.from_another_school(profile.raw, cfg)
        if foreign or (enrolled and profile.get("seeded_from_bundle") and key not in enrolled):
            message = (f"{key}: starter profile from another school's Canvas — skipped "
                       f"(delete it to silence this)" if foreign else
                       f"{key}: starter profile for a course you are not "
                       f"enrolled in — skipped (delete it to silence this)")
            warnings.append(message)
            _emit(options, "docs", message, "warning")
            per_course = diagnostics["per_course"].setdefault(key, {
                "display": profile.get("display_name") or key,
                "homework_source": profile.get("homework_source"),
                "doc_items": 0, "problems": []})
            per_course["problems"].append("another school's starter profile — skipped" if foreign
                                          else "not enrolled — starter profile skipped")
            continue
        source = profile.get("homework_source")
        per_course = diagnostics["per_course"].setdefault(key, {
            "display": profile.get("display_name") or key,
            "homework_source": source, "doc_items": 0, "problems": []})
        if source not in ("doc", "both"):
            if profile.get("verified_zero"):
                per_course["verified_zero"] = True
                per_course["reason"] = profile.get("verified_zero_reason")
            continue
        kind, file_id = _doc_file_info(profile, cfg)
        if not file_id:
            per_course["problems"].append("no doc file id known — run discovery")
            warnings.append(f"{key}: no doc file id known")
            continue
        _emit(options, "docs", "fetching the course doc", course=key)
        try:
            html = fetch_mod.fetch_doc(
                kind, file_id,
                context=_doc_context() if kind != "published-document" else None,
                include_private=options.include_private_docs)
        except fetch_mod.DocError as exc:
            per_course["problems"].append(str(exc))
            level = "info" if exc.gone else "warning"
            _emit(options, "docs", str(exc), level, course=key)
            if not exc.gone:
                warnings.append(f"{key}: {exc}")
            continue

        # ---- incremental: unchanged doc + unchanged profile -> reuse --------
        # This is what keeps a whole year sustainable: every refresh fetches
        # (cheap) but only re-interprets what actually changed.
        signature = fp_mod.content_signature(html)

        def _content_key(prof):
            return _content_key_for(signature, prof)

        cached = db.doc_state_get(conn, file_id)
        if cached and cached["content_hash"] == _content_key(profile):
            cached_items = [Item(**entry)
                            for entry in json.loads(cached["items_json"])]
            # The cache holds every item the doc states; the trim is applied
            # here, on the way out, because "older than three days" is a fact
            # about today and not about the document.
            reused, past = _within_reach(cached_items, today)
            doc_items.extend(reused)
            per_course["doc_items"] = len(reused)
            per_course["past_dropped"] = past
            per_course["reused_cache"] = True
            per_course["course_links"] = json.loads(cached["course_links_json"])
            if profile.get("verified_zero") and not cached_items:
                per_course["verified_zero"] = True
                per_course["reason"] = profile.get("verified_zero_reason")
            else:
                # The cache path is the NORMAL path — a doc only re-reads when
                # it changes — so a check that lives only in the extraction
                # branch below never fires for a class that has been dark for
                # a fortnight. That is what happened to AI Frontiers.
                dark = _silent_zero_warning(key, profile, len(cached_items))
                if dark:
                    per_course["silent_zero"] = True
                    warnings.append(dark)
                    _emit(options, "docs", "cached result holds no homework at "
                          "all — profile or extractor is wrong, not the class",
                          "warning", course=key)
            _emit(options, "docs",
                  f"unchanged — reused {len(reused)} item(s) from cache"
                  + (f" ({past} already past)" if past else ""), course=key)
            continue

        print_fp = fp_mod.fingerprint(html)
        stored_fp = profile.get("doc", "fingerprint", default=None)
        if stored_fp and stored_fp != print_fp:
            diagnostics["fingerprint_changes"].append(key)
            if profile.get("locked"):
                warnings.append(
                    f"{key}: the doc's structure changed, but the profile is "
                    "locked (hand-edited) — not relearned automatically")
                _emit(options, "docs", "doc structure changed; profile locked, "
                      "not relearned", "warning", course=key)
            elif options.profiles_dir:
                warnings.append(f"{key}: the doc's structure changed since its "
                                "profile was learned — a relearn is recommended")
            else:
                # self-healing: re-profile JUST this course (spec §7.2)
                _emit(options, "docs", "doc structure changed — relearning this "
                      "course's profile", "warning", course=key)
                new_raw = _relearn(profile, kind, file_id, html, index)
                if new_raw is not None:
                    carried = _keep_confirmed_layout(profile, new_raw)
                    if carried:
                        warnings.append(
                            f"{key}: relearned, but its confirmed work-column "
                            "convention was kept — the doc says which work is "
                            "SET that day, not due that day")
                        _emit(options, "docs", "relearned; kept the confirmed "
                              "work-column convention", "warning", course=key)
                    store.save(new_raw)
                    profile = store.Profile(key, new_raw)
                    profiles[key] = profile
                    diagnostics.setdefault("relearned", []).append(key)
                    diagnostics["model_calls"] = diagnostics.get("model_calls", 0) + 1
                    warnings.append(f"{profile.get('display_name') or key}'s doc "
                                    "changed format; profile relearned — check it")
                else:
                    warnings.append(f"{key}: relearn failed; using the old "
                                    "profile (extraction may be wrong)")

        result = items_mod.extract_doc(html, profile, index)
        # A doc with no table rows to read is not necessarily a doc with no
        # homework. [MEASURED] 2026-09-02: Honors English 1 had reported ZERO
        # items since it was first profiled — its doc is 279,000 characters of
        # prose (a nav table, then "Week 5: August 31-Sep 4", "Class 10 : …",
        # then bullets stating what is due). extract_doc builds items out of
        # table rows, so it found nothing. The prose extractor written for
        # Canvas homepages is exactly the right tool.
        #
        # Only as a fallback: a doc whose tables DO read stays on the proven
        # path, so the four golden fixtures are untouched.
        if not result.items:
            from sillybus.docs import prose as prose_mod
            prose_result = prose_mod.extract_prose(
                html, key, profile.get("display_name") or key,
                profile.get("course_raw") or key, index,
                where="the class doc",
                source_url=profile.get("doc", "url", default="") or "",
                profile=profile, source="doc", kind="homepage doc")
            if prose_result.items:
                result.items = prose_result.items
                per_course["read_as_prose"] = True
                per_course["prose_headings"] = prose_result.diagnostics.get(
                    "headings", 0)
                _emit(options, "docs",
                      f"no table rows to read, but {len(prose_result.items)} "
                      "item(s) are stated in the doc's own prose", course=key)
        # Last: a doc whose table is a LAYOUT table — column names sharing one
        # cell, a cell per meeting. Neither reader above can see it: there are
        # no columns to classify, and prose skips table cells by design.
        # [MEASURED] 2026-09-02, AI Frontiers: zero items since 2026-08-26
        # against nineteen lines naming work, including a 100-point project.
        # Tried only when both proven paths came back empty, so no doc that
        # reads today changes how it is read.
        if not result.items:
            from sillybus.docs import cellblocks as cells_mod
            cell_result = cells_mod.extract_cells(
                html, key, profile.get("display_name") or key,
                profile.get("course_raw") or key, index,
                where="the class doc",
                source_url=profile.get("doc", "url", default="") or "",
                profile=profile, source="doc", kind="cell-per-meeting doc")
            if cell_result.items:
                result.items = cell_result.items
                per_course["read_as_cells"] = True
                per_course["cells_dated"] = cell_result.diagnostics.get(
                    "cells_dated", 0)
                _emit(options, "docs",
                      f"the doc's table is a layout table — read "
                      f"{len(cell_result.items)} item(s) from "
                      f"{cell_result.diagnostics.get('cells_dated', 0)} dated "
                      "cells", course=key)
        shown, past = _within_reach(result.items, today)
        per_course["doc_items"] = len(shown)
        per_course["past_dropped"] = past
        per_course["tables"] = result.diagnostics.get("tables", [])
        per_course["course_links"] = [l.to_dict() for l in result.course_links]
        if profile.get("verified_zero") and not result.items:
            per_course["verified_zero"] = True
            per_course["reason"] = profile.get("verified_zero_reason")
        else:
            dark = _silent_zero_warning(key, profile, len(result.items))
            if dark:
                per_course["silent_zero"] = True
                warnings.append(dark)
                _emit(options, "docs", "read fine but produced no homework at "
                      "all — profile or extractor is wrong, not the class",
                      "warning", course=key)
        for ambiguity in result.ambiguities:
            ambiguity["fingerprint"] = print_fp
        ambiguities.extend(result.ambiguities)
        doc_items.extend(shown)
        # The FULL list is cached, not the trimmed one, so tomorrow's refresh
        # decides again with tomorrow's date.
        db.doc_state_put(conn, file_id, _content_key(profile),
                         [i.to_dict() for i in result.items],
                         [l.to_dict() for l in result.course_links], print_fp)
        _emit(options, "docs", f"{len(shown)} item(s)"
              + (f" ({past} already past)" if past else ""), course=key)

        expected = profile.get("expected_items_per_window")
        if expected and len(expected) == 2:
            window_start = today - timedelta(days=cfg["window"]["days_back"])
            window_end = today + timedelta(days=cfg["window"]["days_forward"])
            in_window = [i for i in result.items if i.due_date
                         and window_start.isoformat() <= i.due_date
                         <= window_end.isoformat()]
            if not expected[0] <= len(in_window) <= expected[1]:
                warnings.append(
                    f"{key}: {len(in_window)} items in the window, outside the "
                    f"expected {expected[0]}–{expected[1]} — worth a look")

    diagnostics["ambiguities"] = ambiguities

    _close_doc_context()

    # ---- stage 3.5: model adjudication of ambiguous cells (capped, cached) ---
    if ambiguities:
        try:
            from sillybus.docs import adjudicate
            adjudicate.run(ambiguities, doc_items, diagnostics, options, cfg)
        except ModuleNotFoundError:
            _emit(options, "docs", f"{len(ambiguities)} ambiguous cell(s) noted "
                  "(adjudication layer not built yet)", "warning")

    # ---- stage 4: secondary feeds --------------------------------------------
    secondary = veracross.assignments_items()
    if secondary:
        _emit(options, "feeds", f"{len(secondary)} Veracross assignment items")
    # AP Classroom: handed over by the Chrome extension, which reads it on the
    # site itself (feeds/apclassroom.py). Nothing on a Mac, which never writes
    # the hand-off; an error there is a banner with a Sign in button.
    from sillybus.feeds import apclassroom as apclassroom_mod
    ap_items, ap_error = apclassroom_mod.items(
        {m.course_key: m.course_raw for m in meetings})
    if ap_items:
        secondary = secondary + ap_items
        _emit(options, "feeds", f"{len(ap_items)} AP Classroom assignment(s)")
    if ap_error:
        errors.append(ap_error)
        _emit(options, "feeds", f"AP Classroom: {ap_error['message']}", "warning")
    diagnostics["ap_classroom"] = apclassroom_mod.summary()
    # Albert.io: the same shape as AP Classroom — read on its own page by the
    # extension, because its API refuses every origin but its own site.
    from sillybus.feeds import albert as albert_mod
    albert_items, albert_error = albert_mod.items(
        {m.course_key: m.course_raw for m in meetings})
    if albert_items:
        secondary = secondary + albert_items
        _emit(options, "feeds", f"{len(albert_items)} Albert.io assignment(s)")
    if albert_error:
        errors.append(albert_error)
        _emit(options, "feeds", f"Albert.io: {albert_error['message']}", "warning")
    diagnostics["albert"] = albert_mod.summary()

    from sillybus.feeds import google_classroom
    classroom_items, classroom_error = google_classroom.items(
        {m.course_key: m.course_raw for m in meetings})
    secondary += classroom_items
    if classroom_error:
        errors.append(classroom_error)
    if classroom_items:
        _emit(options, "feeds", f"{len(classroom_items)} Google Classroom assignment(s) from visited pages")

    # ---- stage 4.5: the calendars he connected himself ----------------------
    #
    # These do NOT become items. A game and a dentist appointment are things
    # that happen to him, not work he hands in, so they are models.Event and
    # the scorer never sees one — see models.Event's docstring and the
    # decision log entry of 2026-09-17. They ride on `state["events"]`.
    #
    # The try is belt and braces: the source contract (SPEC §4.8) says a feed
    # module never raises, and calendars.read is written not to — but a source
    # the student pasted in himself is the one most likely to be strange, and
    # "his homework vanished because a calendar was odd" is not a trade this
    # pipeline makes. A failure here costs the events and nothing else.
    from sillybus.feeds import calendars as calendars_mod
    events: list = []
    connections_failed: set = set()
    try:
        calendar_read = calendars_mod.read(cfg, today=today)
        events = [e.to_dict() for e in calendar_read.events]
        warnings.extend(calendar_read.warnings)
        for error in calendar_read.errors:
            errors.append(error)
            _emit(options, "feeds", error["message"], "warning")
        # Which connections came back with nothing AND an error — the only
        # ones whose previous events are worth carrying forward.
        connections_failed = {c.get("id") for c in calendar_read.status
                              if c.get("error") and not c.get("events")}
        diagnostics["connections"] = calendars_mod.summary()
        if calendar_read.status:
            _emit(options, "feeds", f"{len(events)} event(s) from "
                  f"{len([c for c in calendar_read.status if c.get('enabled')])} "
                  "connected calendar(s)")
    except Exception as exc:  # noqa: BLE001 — never the board
        # Nothing is known about which connection died, so every saved one is
        # treated as failed and its last events are kept.
        connections_failed = {e.get("id") for e in config.connections(cfg)}
        log.exception("connected calendars blew up")
        errors.append({"code": "connections",
                       "message": "your connected calendars could not be read",
                       "fix": "check them under Settings → Your calendars & "
                              "other programs"})
        _emit(options, "feeds", f"connected calendars failed ({type(exc).__name__})",
              "warning")

    # ---- stage 5: merge — Canvas wins ----------------------------------------
    #
    # Page items join the doc side deliberately: a real Canvas assignment is
    # more precise than the same thing typed onto the homepage (it has points
    # and a submitted flag), so Canvas keeps winning duplicates, and dedupe
    # collapses a deadline written in both the doc and the page.
    # ---- stage 4.9: a doc line that names its own deadline -------------------
    #
    # [MEASURED] 2026-09-28: "SARA: By 8 AM October 14, 100% of all lessons
    # must be completed" was dated Sep 29 — the class day of the row it was
    # typed into. `duedates.restate` reads the line's own words and lets them
    # beat the column, with the note saying which day was which. Before the
    # merge, so Canvas still wins against the corrected date exactly as it
    # would have against the wrong one.
    restated = 0
    for i, item in enumerate(doc_items + page_items):
        try:
            verdict = duedates.restate(item, today, meetings=index)
        except Exception as exc:                  # noqa: BLE001 — never the run
            log.info("could not restate %r: %s", item.title[:40], exc)
            continue
        if verdict.changed:
            item.due_date = verdict.due_date
            item.due = None
            item.all_day = True
            item.date_note = verdict.date_note
            item.extractor = verdict.extractor or item.extractor
            item.flags = list(item.flags) + [f for f in verdict.flags if f not in item.flags]
            item.finalize()                       # the id carries the date
            restated += 1
    if restated:
        _emit(options, "docs", f"{restated} doc line(s) named their own deadline; "
              "the words beat the column")
    _emit(options, "merge", f"{len(canvas_items)} canvas + {len(doc_items)} doc + "
          f"{len(page_items)} page items")
    date_conflicts: list = []
    merged = merge_mod.merge(canvas_items, doc_items + page_items,
                             report=date_conflicts)
    merged = merge_mod.merge_secondary(merged, secondary)
    # The doc's "APCR" lines get the open Progress Checks they most likely
    # mean, with links — before the undated ones are dropped as standalone.
    ap_paired = apclassroom_mod.attach_progress_checks(merged, ap_items) if ap_items else 0
    if ap_paired:
        _emit(options, "merge", f"{ap_paired} doc line(s) about Progress Checks linked to AP Classroom")
    if diagnostics.get("ap_classroom") is not None:
        diagnostics["ap_classroom"]["apcr_lines_linked"] = ap_paired
    merged, ap_dropped = apclassroom_mod.drop_old_practice(merged)
    if ap_dropped:
        _emit(options, "merge", f"{ap_dropped} undated AP Classroom practice item(s) "
              f"opened more than {apclassroom_mod.UNDATED_KEEP_DAYS} days ago not shown")
    if diagnostics.get("ap_classroom") is not None:
        diagnostics["ap_classroom"]["dropped_undated_old"] = ap_dropped
    merged, albert_dropped = albert_mod.drop_old_practice(merged)
    if albert_dropped:
        _emit(options, "merge", f"{albert_dropped} undated Albert.io practice item(s) "
              f"opened more than {albert_mod.UNDATED_KEEP_DAYS} days ago not shown")
    if diagnostics.get("albert") is not None:
        diagnostics["albert"]["dropped_undated_old"] = albert_dropped
    _emit(options, "merge", f"{len(merged)} after dedupe")

    # Canvas auditing the docs: a class whose dates are consistently one
    # meeting out has a profile reading the wrong column, not bad luck.
    for message in column_convention_warnings(date_conflicts, index, profiles):
        warnings.append(message)
        _emit(options, "merge", message, "warning")
    diagnostics["date_conflicts"] = date_conflicts

    # ---- stage 6: score & rank ------------------------------------------------
    from sillybus import tasks as tasks_mod
    merged.extend(tasks_mod.all_items(conn))
    item_dicts = _unique_item_ids([item.to_dict() for item in merged])

    # One-time: map the predecessor's doc_done.json (old id recipe) onto the
    # new ids. The first user's file was {} at import time, so this is expected to be a
    # no-op — but the path is real and tested.
    if options.persist and not cfg.get("legacy_doc_done_imported"):
        legacy_done_file = paths.legacy_tracker_dir() / "doc_done.json"
        if legacy_done_file.exists():
            try:
                legacy_done = json.loads(
                    legacy_done_file.read_text(encoding="utf-8"))
            except ValueError:
                legacy_done = {}
            from sillybus.legacy_import import import_doc_done
            matched = import_doc_done(item_dicts, legacy_done, conn)
            _emit(options, "persist",
                  f"legacy doc_done.json import: {matched} of "
                  f"{len(legacy_done)} key(s) matched")
            config.save({"legacy_doc_done_imported": True})

    done_ids = db.get_done_ids(conn)
    for entry in item_dicts:
        entry["done"] = bool(entry.get("submitted")) or entry["item_id"] in done_ids

    # A question nobody answered in a fortnight (COUNT 36). Done here, on the
    # merged list, rather than per course: the history is keyed by item_id and
    # an item can reach the board from either half of the pipeline.
    seen_before = db.first_seen_map(conn, [e["item_id"] for e in item_dicts])
    # An item whose wording our own extractor changed keeps its predecessor's
    # clock: otherwise every improvement to extraction restarts the fortnight
    # and nothing is ever retired (see db.content_key).
    by_content = db.first_seen_by_content(conn)
    for entry in item_dicts:
        inherited = by_content.get(db.content_key(entry))
        current = seen_before.get(entry["item_id"])
        if inherited and (not current or inherited < current):
            seen_before[entry["item_id"]] = inherited
    kept_dicts, undated_retired = retire_stale_undated(
        [_Shim(e) for e in item_dicts], seen_before, today)
    if undated_retired:
        _emit(options, "persist",
              f"{undated_retired} undated item(s) first seen more than "
              f"{UNDATED_STALE_DAYS} days ago are no longer shown "
              "(item_history keeps them)")
    item_dicts = [shim.entry for shim in kept_dicts]

    # ---- stage 6.5: work that comes round again --------------------------------
    #
    # [ASKED] 2026-09-22: *"give it the ablility to see repeats"*. Three
    # sources of occurrences, and each covers what the others cannot:
    #
    # * `series_rows` — every assignment Canvas holds, past ones included, so
    #   a weekly warm-up is a series on the first refresh of a fresh install.
    # * `item_history` — the only record of doc-sourced and hand-added work,
    #   which Canvas never sees.
    # * the board itself — so THIS week's copy counts as the next occurrence
    #   and a row can say which number it is.
    #
    # Nothing here changes a date, a score or an item. `repeats.annotate`
    # attaches a sentence and `repeats.duplicates` raises a hand; the whole
    # safety argument for grouping loosely is that neither can remove work.
    from sillybus import repeats as repeats_mod
    try:
        history_rows = [
            (e.get("course_key") or "", e.get("title") or "", e.get("due_date"))
            for e in db.remembered_items(conn)]
    except Exception as exc:                       # noqa: BLE001 — a label
        log.info("item history unavailable for repeats: %s", exc)
        history_rows = []
    board_rows = [(e.get("course_key") or "", e.get("title") or "",
                   e.get("due_date")) for e in item_dicts]
    series_index = repeats_mod.find_series(series_rows + history_rows + board_rows)
    labelled = repeats_mod.annotate(item_dicts, series_index, today)
    repeated = repeats_mod.duplicates(item_dicts)
    for group in repeated:
        for entry in item_dicts:
            if entry["item_id"] in group["item_ids"]:
                entry.setdefault("flags", []).append("looks_repeated")
    if labelled or repeated:
        _emit(options, "merge",
              f"{labelled} item(s) belong to work that comes round again"
              + (f"; {len(repeated)} look like the same thing listed twice"
                 if repeated else ""))
    diagnostics["repeats"] = {
        "series": len(series_index), "labelled": labelled,
        "duplicates": repeated,
        "occurrences": len(series_rows) + len(history_rows),
    }

    # Grades reach the scorer so work in a class he is behind in rises.
    ranked = scoring.rank(item_dicts, today, grades)

    # What the board is NOT showing, so the page can say so instead of
    # claiming nothing is hidden (COUNT 35). The per-course counts were in the
    # diagnostics all along and only the terminal printed them.
    past_trimmed = sum(info.get("past_dropped") or 0
                       for info in diagnostics["per_course"].values())
    trimmed = {"past": past_trimmed, "undated": undated_retired,
               "grace_days": prose_grace(),
               "undated_days": UNDATED_STALE_DAYS}

    # ---- stage 7: persist ------------------------------------------------------
    finished = datetime.now(timezones.zone())
    counts = {
        "canvas": len(canvas_items), "doc": len(doc_items),
        "page": len(page_items),
        "secondary": len(secondary), "merged": len(merged),
        "shown": len(ranked),
    }
    run.finished = finished.isoformat(timespec="seconds")
    run.ok = not errors
    run.counts = counts
    run.warnings = warnings
    run.diagnostics = {k: v for k, v in diagnostics.items() if k != "ambiguities"}

    todays = [m.to_dict() for m in index.on_date(today)]
    state = {
        "generated_at": finished.isoformat(timespec="seconds"),
        "today": today.isoformat(),
        "block_label": index.block_label(today),
        "items": ranked,
        "trimmed": trimmed,
        "grades": grades,
        "scores": vc_scores,
        "gradebook": vc_gradebook,
        "scores_stale": None,
        "grades_summary": _grades_summary(grades),
        "grades_stale": None,
        "grades_read_at": (finished.isoformat(timespec="seconds")
                           if grades and not grades_failed else None),
        "schedule_stale": None,
        # Said on the calendar, never hidden silently (hard rule 2; round 7):
        # the sports left out of the Veracross schedule.
        "schedule_hidden": sports_hidden,
        "meetings_today": todays,
        "schedule": {
            day.isoformat(): [m.to_dict() for m in index.on_date(day)]
            for day in (today + timedelta(days=n) for n in range(-7, 22))
        },
        # Things that HAPPEN — games, practices, appointments, shifts — from
        # the calendars he connected. A separate list from `items` on purpose:
        # anything that reads `items` (the scorer, the assignments column, the
        # chat payload's open-work list) therefore cannot accidentally rank a
        # soccer game against a lab report.
        "events": events,
        "events_stale": None,
        "connections": diagnostics.get("connections") or {},
        "profiles": [p.to_dict() for p in profiles.values()],
        "warnings": warnings,
        "errors": errors,
        "diagnostics": diagnostics,
        "last_run": run.to_dict(),
        "session_ok": session_ok,
        "duration_s": round((finished - started).total_seconds(), 1),
    }
    # One class, one key (coursejoin.py) — done before the state is written so
    # the file on disk, the chat payload and the published snapshot all agree.
    try:
        from sillybus import coursejoin
        coursejoin.unify(state, (config.load().get("ui") or {}))
    except Exception as exc:  # noqa: BLE001 — a join failure is not a refresh failure
        log.warning("course join skipped at persist: %s", exc)
    if options.persist:
        db.remember_items(conn, ranked)   # memory of old stuff, forever
        db.record_run(conn, run)
        # A refresh that reached nothing must not erase a board that worked.
        # [MEASURED] 2026-09-01 07:00: the scheduled refresh hit a ConnectError
        # on the class feed and an expired Canvas session, wrote its empty
        # result over a state holding 36 items, 88 meetings and 10 grades, and
        # the dashboard greeted a student with "All caught up ✓" — the single
        # most misleading thing this app could say.
        previous = load_state()
        # What changed since the board was last drawn, said in a sentence each
        # (notices.py). Computed against the previous state BEFORE it is
        # replaced, which is the only moment both boards exist.
        try:
            from sillybus import notices as notices_mod
            fresh = notices_mod.build(
                (previous or {}).get("items") or [], ranked, repeated, today,
                when=finished.isoformat(timespec="seconds"))
            state["notices"] = notices_mod.carry(
                (previous or {}).get("notices") or [], fresh,
                finished.replace(tzinfo=None))
            if fresh:
                _emit(options, "persist", f"{len(fresh)} heads-up(s): "
                      + "; ".join(n["text"][:60] for n in fresh[:3]))
        except Exception as exc:  # noqa: BLE001 — a note is never worth a refresh
            log.warning("notices skipped: %s", exc)
            state["notices"] = (previous or {}).get("notices") or []
        # Order matters, and getting it wrong erases the board. The guard below
        # asks whether this run collected ANYTHING, and _carry_grades tops the
        # state up with the previous run's grades — so carrying first makes an
        # empty run look productive and the guard never fires. [MEASURED]
        # 2026-09-02: introduced and caught the same afternoon; see
        # tests/test_prosecution.py COUNT 21.
        if _should_keep_previous(state, previous):
            state = _keep_previous(previous, state)
            _emit(options, "persist",
                  "every source failed — kept the last good data and recorded "
                  "the errors instead of overwriting it", "warning")
        _carry_events(state, previous, connections_failed)
        _keep_other_courses(state, previous, options.course, docs_only=bool(getattr(options, "docs_only", False)))
        _carry_items(state, previous)
        # Period numbers, from the week's own shape (periods.py); the feed
        # carries none. Written onto the meetings so every reader sees them.
        try:
            from sillybus import periods as periods_mod
            state["periods_detected"] = periods_mod.annotate(state.get("schedule") or {})
        except Exception as exc:  # noqa: BLE001 — a board without numbers still draws
            log.warning("period detection skipped: %s", exc)
        _carry_grades(state, previous, grades_failed)
        _carry_scores(state, previous)
        _carry_schedule(state, previous, feed_failed)
        target = paths.state_json_path()
        tmp = target.with_suffix(".tmp")
        tmp.write_text(json.dumps(state, indent=1, ensure_ascii=False,
                                  default=str), encoding="utf-8")
        tmp.replace(target)
        _emit(options, "persist", f"state written ({len(state.get('items') or [])} items)")
    conn.close()
    return state


_state_cache: dict = {"mtime": None, "state": None}


def read_calendars_now() -> int:
    """Read the connected calendars and put their events on the saved board,
    without a whole refresh. Returns how many events it found.

    [ASKED] 2026-10-06: linking TeamSnap from the Chrome button has to end
    with the games ON the calendar. A full refresh signs in to Canvas and
    reads every teacher's doc — a minute, for a change that needs one feed.

    Three rules, from the review pass the same day:
      * The feeds are read OUTSIDE the run lock (network, seconds), and the
        board is re-read and written INSIDE it, so a refresh that finished in
        between is never reverted to the copy this started from. If a refresh
        is running, nothing is written — it reads the new calendar itself.
      * A calendar that could not be read keeps its last events
        (`_carry_events`), and its error is on the board, as in a refresh.
      * Only events, connection diagnostics and connection errors change.
    Never raises: the connection is already saved, and the next refresh reads
    it either way.
    """
    try:
        from sillybus.feeds import calendars as calendars_mod
        target = paths.state_json_path()
        result = calendars_mod.read(config.load())
        connection_summary = calendars_mod.summary()
        fresh = [e.to_dict() for e in result.events]
        failed = {c.get("id") for c in result.status if c.get("error") and not c.get("events")}
        try:
            with exclusive_run("calendars", wait_seconds=5):
                state = (json.loads(target.read_text(encoding="utf-8")) if target.exists() else
                         {"items": [], "events": [], "errors": [], "warnings": []})
                previous = {"events": list(state.get("events") or [])}
                state["events"] = fresh
                state["connections"] = connection_summary
                state["events_stale"] = None
                _carry_events(state, previous, failed)
                state["errors"] = [e for e in (state.get("errors") or [])
                                   if not str(e.get("code") or "").startswith("connection")] \
                    + list(result.errors)
                target.parent.mkdir(parents=True, exist_ok=True)
                tmp = target.with_suffix(".calendars.tmp")
                tmp.write_text(json.dumps(state, indent=1, ensure_ascii=False, default=str),
                               encoding="utf-8")
                tmp.replace(target)
                return len(state["events"])
        except AlreadyRunning:
            return len(fresh)        # the running refresh reads it too
    except Exception as exc:  # noqa: BLE001 — the next refresh reads it anyway
        log.warning("reading calendars now failed: %s", type(exc).__name__)
        return 0


def _collected_nothing(state: dict) -> bool:
    """Did this run bring back anything of its own?

    Grades carried over from an earlier run do not count. They are real, but
    this run did not fetch them, and counting them tells the guard below that
    an empty refresh was productive — which is how a working board gets
    overwritten. `grades_stale` is set exactly when the grades on the state
    came from somewhere other than this run, so it is the honest test. Doing
    it here rather than relying on call order means the invariant holds
    whichever step runs first (COUNT 21).
    """
    own_schedule = {} if state.get("schedule_stale") else (state.get("schedule") or {})
    meetings = sum(len(day or []) for day in own_schedule.values())
    own_grades = [] if state.get("grades_stale") else state.get("grades")
    # His own tasks come from the database, not from a source; four of them
    # made a run with every school source dead look productive.
    # [MEASURED] 2026-09-18, three times in one day on the dev harness.
    own_items = [i for i in state.get("items") or [] if (i or {}).get("source") != "custom"]
    return not (own_items or meetings or own_grades)


def _silent_zero_warning(key: str, profile, count: int) -> str | None:
    """The message for a doc-sourced course that produced no homework at all.

    Returns None when the emptiness is explained: the profile claims the
    course genuinely has none, or its homework does not come from a doc.

    [MEASURED] 2026-09-02 (COUNT 31): AI Frontiers had reported zero doc items
    since 2026-08-26 while its doc held nineteen homework lines, one of them a
    100-point project due Sep 25. The first version of this check lived only
    in the fresh-extraction path — and an unchanged doc is served from cache,
    which is the normal case — so the class stayed silent anyway. Both paths
    call this now.
    """
    if count or profile.get("verified_zero"):
        return None
    if profile.get("homework_source") != "doc":
        return None
    return (f"{key}: its doc read fine but produced NO homework at all, and "
            "the profile does not claim the course has none — the profile or "
            "the extractor is wrong, not the class")


def _carry_events(state: dict, previous: dict | None, failed_ids) -> None:
    """Keep the last known events for any CONNECTION that could not be read.

    The same rule as the timetable and the grades, applied to the sources the
    student added himself: a refresh that could not reach TeamSnap must not
    turn Saturday's game into an empty Saturday.

    Per connection, not per refresh, and that distinction is the whole bug
    this signature fixes. An earlier version bailed out whenever
    `state["events"]` was non-empty — so with TeamSnap and a Google calendar
    connected, Google succeeding was enough to drop TeamSnap's last-known
    games entirely, which is precisely the case the guard exists for.
    `calendars.py` already serves its own cached copy per connection, so this
    catches the case where even that failed (a cache never written, or lost).

    A connection that read fine and genuinely produced nothing writes nothing
    here: its id is not in `failed_ids`, so today's honest empty list stands
    and yesterday's cancelled game does not come back from the dead.
    """
    failed_ids = {i for i in (failed_ids or set()) if i}
    if not failed_ids:
        return
    old = (previous or {}).get("events") or []
    if not old:
        return
    have = {e.get("connection_id") for e in (state.get("events") or [])}
    carried = [e for e in old
               if e.get("connection_id") in failed_ids
               and e.get("connection_id") not in have]
    if not carried:
        return
    state["events"] = (state.get("events") or []) + carried
    state["events"].sort(key=lambda e: (e.get("date") or "", e.get("start") or ""))
    state["events_stale"] = ((previous or {}).get("generated_at")
                             or (previous or {}).get("today"))


def _carry_schedule(state: dict, previous: dict | None, failed: bool) -> None:
    """Keep the last known timetable when the class feed could not be read.

    [MEASURED] 2026-09-02 (COUNT 25): `except ical.FeedError: meetings = []`
    leaves the state with an empty `schedule`, and the all-sources-failed guard
    does not fire when doc items came from cache — so the Schedule panel says
    "no classes today" on a school day. That is the same defect as COUNT 21,
    one stage upstream and in the source the spec calls the spine.

    A timetable is the most stable thing this app holds: rooms and times for a
    whole term, published weeks ahead. Yesterday's copy is very nearly right,
    and saying "from yesterday" is honest. Blanking it is not.
    """
    if not failed or state.get("schedule"):
        return
    old = (previous or {}).get("schedule") or {}
    if not old:
        return
    state["schedule"] = old
    # Today's own row of the carried timetable first: the previous run's
    # meetings_today is YESTERDAY's classes when the feed failed this
    # morning (prosecution round 2, 2026-10-07 — Tuesday's five classes shown
    # as Wednesday's, with the wrong rooms).
    same_day = (previous or {}).get("today") == state.get("today")
    state["meetings_today"] = (old.get(state.get("today"))
                               or ((previous or {}).get("meetings_today") if same_day else None)
                               or [])
    if not state.get("block_label"):
        state["block_label"] = (previous or {}).get("block_label")
    state["schedule_stale"] = {
        "as_of": (previous or {}).get("generated_at"),
        "reason": "the class feed did not load",
    }


def _carry_grades(state: dict, previous: dict | None, failed: bool) -> None:
    """Keep the last good grades when the grades pull failed, in place.

    [MEASURED] 2026-09-02: "my grades are not showing". The 13:10 refresh timed
    out loading the Veracross portal (60s on domcontentloaded, while another
    SillyBus AI browser window held the profile), wrote `grades: []` over ten
    good grades, and reported `ok: true` — the panel simply said "no grades read
    yet — press Refresh", which reads as a fact about school rather than a
    failed read.

    The existing guard above only fires when EVERY source failed, so a single
    dead source silently erases its own half of the board. That is the same
    defect its own comment describes, one source at a time.

    The old numbers are kept, and `grades_stale` says how old they are so the
    panel can show it. Stale-and-labelled beats absent-and-unexplained: absent
    looks like "no grades exist", which is a claim about his marks, not about
    the network.
    """
    if not failed or state.get("grades"):
        return
    old = (previous or {}).get("grades") or []
    if not old:
        return
    state["grades"] = old
    state["grades_summary"] = _grades_summary(old)
    state["grades_stale"] = {
        "as_of": (previous or {}).get("generated_at"),
        "reason": "the Veracross portal did not load",
    }


def _heal_profiles(profiles: dict, profiles_dir, warnings: list, options=None) -> dict:
    """The class profiles come from files; the last board carries a full copy
    of each. A folder that is suddenly EMPTY while a previous board had
    profiles is a folder that was lost, not a school with no classes — so the
    copies are written back and read again, and the board says so.

    [MEASURED] 2026-09-20 on his install: `data/profiles/` went 2 → 7 → 0
    files between refreshes while `state.db` and `config.json` stayed (an
    IDBFS write-back from a second worker removes what that worker never
    saw). The refresh then read the teachers' documents with no profiles
    at all — `doc: 0` — and the class pages lost every link. The lock in
    worker.js stops the cause; this stops the consequence.
    """
    if profiles:
        return profiles
    previous = load_state() or {}
    saved = previous.get("profiles") or []
    if not saved:
        return profiles
    healed = 0
    for raw in saved:
        try:
            store.save(dict(raw), profiles_dir)
            healed += 1
        except Exception as exc:  # noqa: BLE001 — one bad copy must not stop the rest
            warnings.append(f"could not restore the profile for {raw.get('course_key', '?')}: {exc}")
    if not healed:
        return profiles
    profiles, problems = store.load_all(profiles_dir)
    warnings.extend(problems)
    note = f"the class profiles were missing on disk — {healed} restored from the last board"
    warnings.append(note)
    if options is not None:
        _emit(options, "docs", note, "warning")
    return profiles


def _keep_other_courses(state: dict, previous: dict | None, course: str | None,
                        docs_only: bool = False) -> None:
    """A refresh of ONE course must leave every other course's work alone.

    [MEASURED] 2026-10-04: `run.py refresh --docs-only --course honors-english-1`
    — the command the sillybus skill gives for "is <class> pulling right?" —
    wrote a board holding only that course: 35 items became 5 until a full
    refresh. The other courses' items come from the last board instead; this
    run only answers for the course it was asked about (and his own tasks,
    which every run reads)."""
    if not course or not previous:
        return
    mine = list(state.get("items") or [])
    seen = {(i or {}).get("item_id") for i in mine}
    # A docs-only run read only that course's DOC, so its Canvas and page
    # items stand too (35 of 36 kept, the 36th its own Canvas quiz, until this).
    kept = [i for i in previous.get("items") or []
            if (course not in ((i or {}).get("course_key") or "")
                or (docs_only and (i or {}).get("source") != "doc"))
            and (i or {}).get("source") != "custom"
            and (i or {}).get("item_id") not in seen]
    state["items"] = kept + mine


def _unique_item_ids(items: list[dict]) -> list[dict]:
    """Two different pieces of work must not share an id. [MEASURED]
    2026-10-07 (prosecution round 2): a Canvas assignment and its peer review
    ("CYOA Checkpoint 3: Peer Reviews", 09:30 and 09:45) hashed the same —
    the id is (source, class, title, day) — so ticking one ticked both and the
    detail pane opened the wrong one. The id scheme cannot change (every
    saved tick is keyed on it), so the FIRST of a clash keeps its id, in a
    stable order, and each later one gets an id folded with its own address
    and time."""
    seen: dict[str, int] = {}
    order = sorted(range(len(items)), key=lambda n: (items[n].get("due") or "", items[n].get("url") or "",
                                                     items[n].get("title") or ""))
    for n in order:
        entry = items[n]
        base = entry.get("item_id")
        if not base:
            continue
        if base in seen:
            seen[base] += 1
            salt = f"{base}|{entry.get('url') or ''}|{entry.get('due') or ''}|{seen[base]}"
            entry["item_id"] = hashlib.sha1(salt.encode("utf-8")).hexdigest()[:16]
        else:
            seen[base] = 0
    return items


def _carry_items(state: dict, previous: dict | None) -> None:
    """Keep the last known school work when Canvas could not be read and this
    run brought back none of its own — the grades rule, applied to the thing
    the board is for.

    [MEASURED] 2026-09-18, three times on the dev harness in one afternoon: a
    refresh with a dead Canvas session and a dead class feed, but a working
    (and empty) calendars connection and a cached timetable, was "not a wholly
    failed run" — so the all-sources guard stood aside, and 26 school items
    became 0 while the grades were carried over beside them. For a student
    that is a dead Canvas session plus a live Google Calendar, which is an
    ordinary Tuesday. His own tasks are kept from this run; the school's work
    comes from the last run that had any, and `items_stale` says so.
    """
    codes = {(err or {}).get("code") for err in state.get("errors") or []}
    if "canvas_session" not in codes:
        return
    # Per SOURCE, not all-or-nothing. [MEASURED] 2026-10-07 (prosecution
    # round 2): with the Canvas sign-in dead the teacher docs still came back
    # from cache, so the run "had items", nothing was carried — and every
    # Canvas assignment and Canvas-page item vanished with no stale label,
    # Spanish's Thursday test among them (Spanish homework lives only on its
    # Canvas page). Now any source the last run had and this run has none of
    # is carried over, and the board says so.
    here = {(i or {}).get("source") for i in state.get("items") or []}
    old = [i for i in (previous or {}).get("items") or []
           if (i or {}).get("source") not in ("custom", None) and (i or {}).get("source") not in here]
    if not old:
        return
    state["items"] = old + list(state.get("items") or [])
    if not state.get("profiles") and (previous or {}).get("profiles"):
        state["profiles"] = previous["profiles"]
    state["items_stale"] = {
        "as_of": (previous or {}).get("generated_at"),
        "reason": "Canvas could not be read",
    }


def _carry_scores(state: dict, previous: dict | None) -> None:
    """Keep the last good marks and weights when the gradebook could not be
    read, in place — the same rule as _carry_grades, for the same reason.

    The grade page is built from `scores` and `gradebook`. A refresh whose
    grades half failed writes both empty, and the page then says "no marked
    work for this class" — a statement about his marks, when the truth is a
    statement about the network. Kept and labelled, like grades. Only when the
    read itself failed: an empty list from a working gradebook is a fact about
    the class and stays empty.

    **The error watched here is `veracross_grades`, not `canvas_session`.**
    Since 0.18.6.0 the marks and the weights come from Veracross, and this
    guard sat on the wrong source for one commit: a dead Veracross session
    blanked the grade page with no "stale" label at all, while a dead Canvas
    kept marks Canvas had not supplied.
    """
    failed = any((err or {}).get("code") in ("veracross_grades", "canvas_session")
                 for err in state.get("errors") or [])
    if not failed or state.get("scores"):
        return
    old = (previous or {}).get("scores") or []
    if not old:
        return
    state["scores"] = old
    state["gradebook"] = (previous or {}).get("gradebook") or {}
    state["scores_stale"] = {
        "as_of": (previous or {}).get("generated_at"),
        "reason": "the Veracross gradebook could not be read",
    }


def _should_keep_previous(new: dict, previous: dict | None) -> bool:
    """Only when the emptiness is a failure, not a fact.

    A genuinely clear board is allowed to be empty, so zero items alone proves
    nothing. The distinguishing signal is that sources errored AND nothing at
    all came back AND there was something there before.
    """
    if not previous or not new.get("errors") or not _collected_nothing(new):
        return False
    return not _collected_nothing(previous)


def _keep_previous(previous: dict, failed: dict) -> dict:
    """The old data, with the new run's honesty stapled on.

    generated_at deliberately stays the OLD timestamp: the staleness banner is
    the mechanism that tells someone their data is ageing, and moving it forward
    would silence exactly the warning they need. `last_attempt` records when the
    failed run happened.
    """
    kept = dict(previous)
    kept["errors"] = failed.get("errors") or []
    kept["warnings"] = failed.get("warnings") or []
    kept["last_run"] = failed.get("last_run")
    kept["last_attempt"] = failed.get("generated_at")
    kept["kept_previous"] = True
    kept["session_ok"] = failed.get("session_ok")
    return kept


def load_state() -> dict | None:
    """Parsed-state cache keyed by file mtime, so a page load does not re-parse
    a megabyte of JSON (the 5–50 ms cached-load target, spec §11)."""
    target = paths.state_json_path()
    if not target.exists():
        return None
    try:
        mtime = target.stat().st_mtime_ns
        # The join is applied here, from `ui.merge` and `ui.keep_apart`, so a
        # change to EITHER has to invalidate this cache as surely as a change
        # to the file does. [MEASURED] 2026-09-18: "not the same class" saved
        # keep_apart and the board did not move, because the cache was keyed
        # on the file alone and the file had not changed.
        ui = config.load().get("ui") or {}
        joinkey = json.dumps([ui.get("merge") or {}, ui.get("keep_apart") or []], sort_keys=True)
        if _state_cache["mtime"] != mtime or _state_cache.get("joinkey") != joinkey:
            loaded = json.loads(target.read_text(encoding="utf-8"))
            # One class, one key, before anyone reads it. Applied on READ as
            # well as at persist so a state written before the join existed
            # — his, today — is fixed on the next load rather than the next
            # refresh. Idempotent, and never raises into a page load.
            try:
                from sillybus import coursejoin
                coursejoin.unify(loaded, ui)
            except Exception as exc:  # noqa: BLE001 — the board still draws
                log.warning("course join skipped: %s", exc)
            # Periods on read as well as at persist, so a board written before
            # detection existed — his, today — has them on the next load.
            try:
                from sillybus import periods as periods_mod
                loaded["periods_detected"] = periods_mod.annotate(loaded.get("schedule") or {})
            except Exception as exc:  # noqa: BLE001
                log.warning("period detection skipped: %s", exc)
            _state_cache["state"] = loaded
            _state_cache["mtime"] = mtime
            _state_cache["joinkey"] = joinkey
        return json.loads(json.dumps(_state_cache["state"]))  # callers mutate
    except (ValueError, OSError):
        return None


def load_state_overlaid() -> dict | None:
    """load_state plus the db truths applied: tick-offs and custom tasks.
    Every consumer of 'current items' (the API, the publisher) goes through
    this, so a chat-added task or a Done click is never missing."""
    from sillybus import scoring, tasks as tasks_mod
    state = load_state()
    if not state:
        return None
    from sillybus import myevents
    conn = db.connect()
    done_ids = db.get_done_ids(conn)
    custom = [t.to_dict() for t in tasks_mod.all_items(conn)]
    mine = myevents.all_events(conn)
    conn.close()
    # Events he added himself ("practice Thursday at 5") sit beside the ones
    # his calendars sent, so the calendar and Personal draw both — and, like
    # a custom task, they show the moment they are added, not after a refresh.
    if mine:
        state["events"] = sorted(
            [e for e in (state.get("events") or []) if e.get("source") != myevents.SOURCE]
            + mine, key=lambda e: (e.get("date") or "", e.get("start") or ""))
    today = today_local()
    known = {i["item_id"] for i in state.get("items", [])}
    custom_live = {t["item_id"] for t in custom}
    state["items"] = [i for i in state.get("items", [])
                      if i.get("source") != "custom" or i["item_id"] in custom_live]
    # A connector switched off is off NOW, not after the next refresh.
    # [ASKED] 2026-09-20: "you should be able to turn off connectors/shortcuts
    # entirely … its annoying if you don't [use them]". Every reader already
    # honoured its flag on the next pull; what it did not do was take its
    # items off the board he was looking at. A refresh can be an hour away.
    from sillybus import connectors
    gone = connectors.hidden_item_sources()
    if gone:
        state["items"] = [i for i in state["items"] if i.get("source") not in gone]
        state["errors"] = [e for e in (state.get("errors") or [])
                           if e.get("code") not in connectors.off()]
    state["items"].extend(t for t in custom if t["item_id"] not in known)
    # The board's "today" is TODAY, not the last refresh's day. [MEASURED]
    # 2026-10-07 00:43 (prosecution round 2): the page said "Tue, Oct 6" with
    # Tuesday's classes, called Tuesday's quiz "today" and Wednesday's work
    # "tomorrow", and chat answered "what's due today" with Tuesday's list —
    # until a refresh, possibly hours later. The day, its classes and every
    # item's rank and reason are re-read here, on each load.
    grades = state.get("grades")
    by_course = {g.get("course_key"): g.get("percent") for g in (grades or [])
                 if g.get("graded") and g.get("percent") is not None}
    if state.get("today") != today.isoformat():
        state["refreshed_on"] = state.get("today")
        state["today"] = today.isoformat()
        state["meetings_today"] = (state.get("schedule") or {}).get(today.isoformat()) or []
        if state["items"]:
            scoring.rank(state["items"], today, grades)
    else:
        fresh = [i for i in state["items"] if not i.get("est_label")]
        if fresh:
            scoring.rank(fresh, today, grades)
    for item in state["items"]:
        was = item.get("done")
        item["done"] = bool(item.get("submitted")) or item["item_id"] in done_ids
        if item["done"] != was:
            # With the grades, as rank() does: an unticked item used to lose
            # its "weaker class" nudge until the next refresh.
            item["score"], item["reason"] = scoring.score(item, today, by_course)
    state["items"].sort(key=lambda i: i.get("score", 0), reverse=True)
    return state



def _grades_summary(grades: list[dict]) -> dict:
    """Counts for the dashboard header. Deliberately not a GPA: that needs the
    school's scale and each course's credit weight, neither of which the portal
    publishes, and a number computed without them would look authoritative and
    be wrong."""
    scored = [g for g in grades if g.get("graded") and g.get("percent") is not None]
    # A letter-only grade ("A", "P") is graded; see veracross_grades.summarise.
    # (prosecution round 4, 2026-10-07)
    graded = sum(1 for g in grades if g.get("graded"))
    return {
        "courses": len(grades),
        "graded": graded,
        "ungraded": len(grades) - graded,
        "lowest": min((g["percent"] for g in scored), default=None),
        "highest": max((g["percent"] for g in scored), default=None),
    }


def cli_refresh(docs_only=False, profiles_dir=None, course=None, verbose=False,
                include_private_docs=False) -> int:
    def emit(stage, message, level, course_name):
        prefix = f"  [{stage}] " + (f"{course_name}: " if course_name else "")
        print(prefix + message)

    options = RefreshOptions(docs_only=docs_only, profiles_dir=profiles_dir,
                             course=course, verbose=verbose,
                             include_private_docs=include_private_docs,
                             emit=emit if verbose else None)
    try:
        state = refresh(options)
    except AlreadyRunning as busy:
        # The scheduled refresh runs from launchd while he may be pressing
        # Refresh in the app. Neither should win by damaging the board, and a
        # traceback in a log nobody reads is not a report (COUNT 24).
        print(f"A refresh is already running ({busy.holder or 'another window'}).")
        print("Nothing was changed. Try again when it finishes.")
        return 2
    today = state["today"]
    cfg = config.load()
    window_start = (date.fromisoformat(today)
                    - timedelta(days=cfg["window"]["days_back"])).isoformat()
    window_end = (date.fromisoformat(today)
                  + timedelta(days=cfg["window"]["days_forward"])).isoformat()

    print(f"\nSillyBus AI refresh — {state['generated_at']} "
          f"({state['duration_s']}s), today = {today}")
    print(f"{'COURSE':<44} {'DOC ITEMS':>9} {'IN WINDOW':>9}")
    per_course = state["diagnostics"]["per_course"]
    for key, info in sorted(per_course.items()):
        in_window = sum(1 for i in state["items"]
                        if i["course_key"] == key and i["source"] == "doc"
                        and i.get("due_date")
                        and window_start <= i["due_date"] <= window_end)
        note = ""
        if info.get("verified_zero"):
            note = f"  (verified zero: {info.get('reason') or '?'})"
        elif info.get("problems"):
            note = f"  ! {info['problems'][0]}"
        elif info.get("past_dropped"):
            note = (f"  ({info['past_dropped']} more already past — a doc "
                    "cannot say if they were handed in)")
        print(f"{info['display']:<44} {info['doc_items']:>9} {in_window:>9}{note}")
    counts = state["last_run"]["counts"]
    print(f"\nDoc items: {counts['doc']}   Canvas items: {counts['canvas']}   "
          f"Page items: {counts.get('page', 0)}   "
          f"After dedupe: {counts['merged']}   Shown: {counts['shown']}")
    pages = state["diagnostics"].get("pages") or {}
    if pages:
        print(f"Course pages: {pages.get('pages_read', 0)} read, "
              f"{pages.get('pages_reused', 0)} unchanged, "
              f"{pages.get('announcements_read', 0)} announcement(s); "
              f"{pages.get('dropped_outside_window', 0)} item(s) outside the window")
    for error in state["errors"]:
        print(f"  ERROR {error['code']}: {error['message']}\n"
              f"        fix: {error['fix']}")
    if state["warnings"] and verbose:
        for warning in state["warnings"]:
            print(f"  ! {warning}")
    elif state["warnings"]:
        print(f"{len(state['warnings'])} warning(s) — rerun with --verbose to list")
    return 0 if not state["errors"] else 1


def cli_explain(item_id: str) -> int:
    state = load_state()
    if not state:
        print("no cached state — run: python run.py refresh")
        return 1
    matches = [i for i in state["items"] if i["item_id"].startswith(item_id)]
    if not matches:
        print(f"no item with id {item_id!r} in the last refresh")
        return 1
    for item in matches:
        print(f"{item['title']}\n  course      {item['course']}")
        print(f"  source      {item['source']}   extractor: {item['extractor']}   "
              f"confidence: {item['confidence']}")
        print(f"  due         {item.get('due') or 'undated'}")
        print(f"  date note   {item['date_note']}")
        print(f"  raw cell    {item['raw_cell'][:400]}")
        for link in item.get("links", []):
            print(f"  link        [{link['kind']}] {link['text'][:40]} -> {link['url'][:90]}")
        if item.get("merged_from"):
            print(f"  merged from {item['merged_from']}")
        if item.get("flags"):
            print(f"  flags       {item['flags']}")
    return 0
