"""Work that comes round again — and what that tells you about its date.

*"give it the ablility to see repeats"* — 2026-09-22.

Some of a school year is one-off: a project, a unit test, an essay. Most of a
week is not. "Warm Up 9/15", "Warm Up 9/22", "Weekly Reading Log #4", "Kahoot
Tuesday", "Lab Notebook Check" — a board that meets the seventh of those as a
brand-new surprise is losing something the student already knows, and hiding
the one thing on the row that is genuinely new.

Three things this buys, and the third is why this module sits next to
`duedates.py` rather than off on its own:

1. **It says so.** "comes round every week — the 5th of these" on a row is a
   fact about how much of a shock the work is. A repeat with a familiar shape
   is not the same as a new assignment, even when both are due Friday.
2. **It shows what is missing.** If the last four Warm Ups were handed in and
   this week's is not on the board at all, that is worth a line. A gap in a
   series is the shape of an assignment nobody published.
3. **It knows which day these land on.** A recurring assignment that Canvas
   lists with no due date is not really undated: its last five occurrences
   were every one of them a Friday. That does not make Friday this one's
   deadline — see the note on `predict` — but it is a great deal better than
   "no date".

## This is NOT a merger, and the difference is the whole safety argument

`merge.py` decides two rows are **the same piece of work**, and deletes one.
It is careful to the point of paranoia about numbers for that reason: its own
comment records that "Quiz 2" and "Quiz 3" collapsing into one stem cost a
quiz off the board.

This module groups by exactly the stem `merge.py` refuses to use — "Quiz 2"
and "Quiz 3" are deliberately one series here — because it is answering the
opposite question. **Nothing here ever removes, merges, re-dates or re-scores
an item.** It attaches a label. A wrong grouping puts a wrong sentence under a
row; it cannot make work disappear. That asymmetry is the licence to be loose,
and it stops being true the moment anything downstream treats a series as
identity, so: do not.

## Where the occurrences come from

The Canvas assignments endpoint already returns **every** assignment in the
course, including the ones long past that the board's window drops
(`feeds/canvas.py: items_from_assignments`). So a series is visible on the
very first refresh, with no history to build up — which matters, because
`item_history` on a fresh install is empty and a feature that needs six weeks
of data before it does anything is a feature nobody sees working.

`item_history` is read as well, and it is what carries doc-sourced and
hand-added work, which Canvas never sees.

Pure: no network, no clock, no config.
"""

import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import date, timedelta

# How many dated occurrences before a cadence may be claimed. Two points make
# a gap, not a pattern: any two assignments in a course are "every N days" for
# some N, and a board captioned with arithmetic like that is worse than silent.
MIN_FOR_CADENCE = 3

# How many before the series is worth mentioning at all, even without a
# cadence. Two really is a repeat — "this is the 2nd of these" is true and
# useful — it just does not predict anything.
MIN_FOR_SERIES = 2

# A gap may miss by this much and still count as the same cadence. School
# weeks have holidays in them: a "weekly" quiz skips Labor Day and shows up at
# 14 days once, and a Tuesday assignment posted a day late reads as 8.
GAP_SLACK = 1

# How much of the run has to agree before the cadence is stated as fact.
#
# [MEASURED] 2026-09-22: at 0.6 a run with gaps of 3, 15 and 13 days was
# announced as "every two weeks", because two of its three gaps sat within a
# day of 14. Three gaps is the smallest series there is, and two out of three
# is not a pattern. At 0.7 the minimum-size series has to be unanimous, while
# a longer run still tolerates the one holiday that the slack above exists
# for — 3 of 4 is 0.75.
AGREEMENT = 0.7

NAMED = {1: "every day", 7: "every week", 14: "every two weeks",
         21: "every three weeks", 28: "every four weeks"}

WEEKDAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday",
                 "Saturday", "Sunday"]

ORDINALS = {1: "1st", 2: "2nd", 3: "3rd"}

MONTHS = ("jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec")

# What varies between one occurrence and the next, masked so the rest can be
# compared. Order matters: the dates go before the bare numbers, or "9/15"
# becomes "#n/#n" and two different dates stop matching each other.
MASKS = [
    (re.compile(r"\b\d{4}-\d{2}-\d{2}\b"), "#date"),
    (re.compile(r"\b\d{1,2}\s*/\s*\d{1,2}(?:\s*/\s*\d{2,4})?\b"), "#date"),
    (re.compile(rf"\b(?:{MONTHS})[a-z]*\.?\s+\d{{1,2}}(?:st|nd|rd|th)?\b", re.I), "#date"),
    (re.compile(r"\b(?:mon|tues?|wed(?:nes)?|thur?s?|fri|sat|sun)(?:day)?\b", re.I), "#day"),
    # "week 3", "unit 4", "chapter 7", "part ii", "#12", "no. 4"
    (re.compile(r"\b(week|unit|chapter|ch|lesson|day|part|set|section|module|"
                r"assignment|number|no|period|quarter|semester|term|round|topic)"
                r"\.?\s*#?\s*\d+\b", re.I), r"\1 #n"),
    (re.compile(r"#\s*\d+"), "#n"),
    # Roman numerals as a standalone word: "Part III", "Unit IV".
    (re.compile(r"\b(?=[ivxl]{1,6}\b)(?!in\b|it\b|is\b|i\b)[ivxl]+\b", re.I), "#n"),
    (re.compile(r"\b\d+(?:[.\-/]\d+)*\b"), "#n"),
]

# Punctuation and the separators a teacher numbers with. Dropped after the
# masking, so "Warm Up — 9/22" and "Warm Up: #date" land on the same stem.
RE_JUNK = re.compile(r"[^\w#\s]+")


def stem(title: str) -> str:
    """The shape of a title with the part that changes each time masked out.

        "Warm Up 9/15"            -> "warm up #date"
        "Warm Up 9/22"            -> "warm up #date"
        "Weekly Reading Log #4"   -> "weekly reading log #n"
        "Unit 3 Vocab Quiz"       -> "unit #n vocab quiz"

    An empty stem — a title that was nothing but a number — is returned empty
    and never grouped, because everything numeric would land in one bucket.
    """
    text = (title or "").strip().lower()
    for pattern, repl in MASKS:
        text = pattern.sub(repl, text)
    text = RE_JUNK.sub(" ", text)
    text = " ".join(text.split())
    words = [w for w in text.split() if not w.startswith("#")]
    return text if words else ""


@dataclass
class Series:
    """One piece of work that keeps coming back, in one course."""
    course_key: str
    stem: str
    titles: list = field(default_factory=list)
    dates: list = field(default_factory=list)      # sorted ISO strings, unique
    gap_days: int | None = None                    # the modal gap, when agreed
    weekday: int | None = None                     # 0=Monday, when consistent
    agreement: float = 0.0

    @property
    def count(self) -> int:
        return len(self.dates)

    @property
    def sample(self) -> str:
        return self.titles[0] if self.titles else self.stem

    @property
    def regular(self) -> bool:
        return self.gap_days is not None


def _cadence(days: list[date]) -> tuple[int | None, float]:
    """(the gap these occurrences keep, how much of the run keeps it)."""
    if len(days) < MIN_FOR_CADENCE:
        return None, 0.0
    gaps = [(b - a).days for a, b in zip(days, days[1:]) if (b - a).days > 0]
    if not gaps:
        return None, 0.0
    # Snap to a named cadence first: a run of 7, 7, 8, 14, 7 is weekly with a
    # holiday in it, and the raw mode would answer 7 only by luck.
    best_rank = None
    best_gap = None
    for candidate in sorted(set(list(NAMED) + gaps)):
        if candidate <= 0:
            continue
        agreed = sum(1 for g in gaps
                     if abs(g - candidate) <= GAP_SLACK
                     or (candidate in NAMED and g % candidate == 0
                         and g // candidate <= 2))
        share = agreed / len(gaps)
        # A tie goes to the named cadence, and then to the smaller gap: a run
        # that is equally describable as weekly or fortnightly is weekly.
        rank = (share, candidate in NAMED, -candidate)
        if best_rank is None or rank > best_rank:
            best_rank, best_gap = rank, candidate
    if best_rank is None or best_rank[0] < AGREEMENT:
        return None, best_rank[0] if best_rank else 0.0
    return best_gap, best_rank[0]


def find_series(rows) -> dict:
    """{(course_key, stem): Series} from (course_key, title, due_date) rows.

    Source-agnostic on purpose: Canvas's full assignment list, `item_history`
    and the current board all produce the same three fields, and a series
    built from two of them is better than one built from either.
    """
    grouped: dict = {}
    for course_key, title, due in rows:
        shape = stem(title)
        if not shape or not course_key:
            continue
        series = grouped.setdefault((course_key, shape),
                                    Series(course_key=course_key, stem=shape))
        if title and title not in series.titles:
            series.titles.append(title)
        if due and due not in series.dates:
            series.dates.append(due)
    out: dict = {}
    for key, series in grouped.items():
        series.dates.sort()
        series.titles.sort(key=len)
        if len(series.titles) < MIN_FOR_SERIES and series.count < MIN_FOR_SERIES:
            continue
        days = [date.fromisoformat(d) for d in series.dates]
        series.gap_days, series.agreement = _cadence(days)
        weekdays = Counter(d.weekday() for d in days)
        if weekdays and weekdays.most_common(1)[0][1] / len(days) >= AGREEMENT:
            series.weekday = weekdays.most_common(1)[0][0]
        out[key] = series
    return out


def describe(series: Series) -> str:
    """The sentence a row carries. Plain words, and never more certain than
    the evidence: a run with no agreed gap says how many, not how often."""
    times = f"{series.count} so far" if series.count else "seen before"
    if series.regular:
        how = NAMED.get(series.gap_days, f"about every {series.gap_days} days")
        if series.weekday is not None and series.gap_days in (7, 14, 21, 28):
            how += f", on a {WEEKDAY_NAMES[series.weekday]}"
        return f"this one comes round {how} — {times}"
    if series.weekday is not None:
        return (f"this one comes back, usually on a "
                f"{WEEKDAY_NAMES[series.weekday]} — {times}")
    return f"this one comes back — {times}"


def which(series: Series, due: str | None) -> str:
    """"the 5th of these", when the position is actually known."""
    if not due or due not in series.dates:
        return ""
    number = series.dates.index(due) + 1
    return f"the {ORDINALS.get(number, f'{number}th')} of these"


def predict(series: Series, after: date) -> tuple[str | None, str]:
    """(the next date this series would land on, how that was worked out).

    **The caller must not put this in `due_date`.** A deadline nobody set is
    not a deadline, and SPEC §5.9's rule that every date says where it came
    from is not satisfied by a date that came from arithmetic about other
    assignments. This exists so an undated row can say *"the last five of
    these were due on a Friday"* beside "no date" — which is information the
    student has, rather than a deadline the app invented.
    """
    if not series.regular or not series.dates:
        return None, ""
    last = date.fromisoformat(series.dates[-1])
    when = last
    for _ in range(60):
        when = when + timedelta(days=series.gap_days)
        if when > after:
            break
    else:
        return None, ""
    if when <= after:
        return None, ""
    how = NAMED.get(series.gap_days, f"every {series.gap_days} days")
    return when.isoformat(), (
        f"the {series.count} before it ran {how}, the last on "
        f"{last:%a %b %d}")


def annotate(items: list, index: dict, today: date | None = None) -> int:
    """Attach a `repeat` block to every board item that belongs to a series.

    Mutates the dicts and returns how many were labelled. Nothing else about
    an item is touched — not its date, not its score, not its note.
    """
    marked = 0
    for entry in items:
        series = index.get((entry.get("course_key") or "",
                            stem(entry.get("title") or "")))
        if series is None or series.count + len(series.titles) < 3:
            continue
        block = {"stem": series.stem, "count": series.count,
                 "says": describe(series), "which": which(series, entry.get("due_date")),
                 "every": series.gap_days, "weekday": series.weekday}
        if not entry.get("due_date") and today is not None:
            when, how = predict(series, today)
            if when:
                block["expected"] = when
                block["expected_note"] = how
        entry["repeat"] = block
        marked += 1
    return marked


# ---------------------------------------------------------------- duplicates

def duplicates(items: list, slack_days: int = 1) -> list:
    """Groups of rows on ONE board that look like the same work twice.

    The other half of "see repeats", and the half a student means first: the
    same assignment showing up twice because two sources described it
    differently enough that `merge.py` kept them apart.

    **Nothing is removed.** `merge.py` owns that decision and is deliberately
    strict, because a wrong merge hides work. This is the softer question —
    "these two look alike, and you should know" — answered with a flag on both
    rows and a sentence the student can judge for themselves.

    Same course, same stem, and due within `slack_days` of each other. The
    slack is there because the two sources disagree about the day as often as
    about the words: Canvas says 23:59 Tuesday, the class doc says Wednesday,
    and they are the same lab. The same stem a week apart is a series (the
    rest of this module), never a duplicate.

    Which pairs are worth a hand: ones that crossed a source boundary, or two
    rows from one source with the SAME title on the same day — a teacher who
    posted the thing twice. Two Canvas rows with different titles are two
    assignments, and Canvas is authoritative about that.
    """
    shapes: dict = {}
    for entry in items:
        if entry.get("done") or entry.get("submitted"):
            continue
        shape = stem(entry.get("title") or "")
        if not shape or not entry.get("due_date"):
            continue
        try:
            day = date.fromisoformat(entry["due_date"])
        except (TypeError, ValueError):
            continue
        shapes.setdefault((entry.get("course_key") or "", shape), []).append((day, entry))
    out = []
    for rows in shapes.values():
        if len(rows) < 2:
            continue
        rows.sort(key=lambda pair: pair[0])
        # Chain rows whose days touch, so Tue/Wed/Wed is one group.
        group: list = [rows[0]]
        for pair in rows[1:] + [None]:
            if pair is not None and (pair[0] - group[-1][0]).days <= slack_days:
                group.append(pair)
                continue
            _judge(group, out)
            group = [pair] if pair is not None else []
    return out


def _judge(group: list, out: list) -> None:
    if len(group) < 2:
        return
    entries = [e for _, e in group]
    sources = {e.get("source") or "" for e in entries}
    titles = {(e.get("title") or "").strip().lower() for e in entries}
    days = {e.get("due_date") for e in entries}
    if len(sources) >= 2:
        why = ("the same work from two places (" + " and ".join(sorted(sources))
               + ")" + (", a day apart" if len(days) > 1 else ""))
    elif len(titles) == 1 and len(days) == 1:
        why = f"{next(iter(sources))} lists it twice on the same day"
    else:
        return
    out.append({"item_ids": [e["item_id"] for e in entries],
                "titles": [e.get("title") or "" for e in entries],
                "sources": sorted(sources),
                "course": entries[0].get("course") or "",
                "due_date": entries[0].get("due_date"),
                "why": why})
