"""The College Board Course and Exam Description (CED), one unit at a time.

Why this exists. An AP Classroom Progress Check is the one assignment whose
material the app can never read: the questions are College Board's secure
content, behind a sign-in, and copying them would be both against the terms
and useless (a Progress Check is meant to be taken cold). What the app CAN
read is the public document the Progress Check is built from — the CED, a
PDF College Board publishes for every AP course, whose unit sections list
the exact learning objectives, essential knowledge and skills each unit's
questions are written to. Accelerate hands that unit's text to the model
and asks for practice questions in the same shape, which is what "better at
getting questions for APCR" can honestly mean.

What is fetched. `apcentral.collegeboard.org/media/pdf/<slug>-course-and-
exam-description.pdf`, plain HTTP, no sign-in, once per course; the text of
each unit is kept in `cache/ced/<slug>.json` so the PDF is never fetched
twice. Nothing is invented: a course with no CED here, or a unit the PDF
does not name, is reported as not available.

The slugs were checked against the live site on 2026-09-20 (HTTP 200 on a
HEAD request) — every one listed here answered.
"""
from __future__ import annotations

import io
import json
import re
from pathlib import Path

from sillybus import paths
from sillybus.logging_setup import get

log = get("ced")

CED_BASE = "https://apcentral.collegeboard.org/media/pdf/"

# (pattern on the class name, slug). Order matters where one name contains
# another ("Physics C: Mechanics" before "Physics"; "Calculus" covers AB and
# BC with one shared PDF).
COURSES: tuple[tuple[str, str], ...] = (
    (r"physics\s*c.*(?:e\s*&\s*m|electric)", "ap-physics-c-electricity-and-magnetism"),
    (r"physics\s*c", "ap-physics-c-mechanics"),
    (r"physics\s*1", "ap-physics-1"),
    (r"physics\s*2", "ap-physics-2"),
    (r"calculus", "ap-calculus-ab-and-bc"),
    (r"precalc", "ap-precalculus"),
    (r"statistics", "ap-statistics"),
    (r"chemistry", "ap-chemistry"),
    (r"biology", "ap-biology"),
    (r"environmental", "ap-environmental-science"),
    (r"computer\s*science\s*principles|\bcsp\b", "ap-computer-science-principles"),
    (r"computer\s*science", "ap-computer-science-a"),
    (r"english\s*lit", "ap-english-literature-and-composition"),
    (r"english\s*lang", "ap-english-language-and-composition"),
    (r"human\s*geo", "ap-human-geography"),
    (r"world\s*history", "ap-world-history-modern"),
    (r"european|euro\b", "ap-european-history"),
    (r"u\.?\s*s\.?\s*history|united\s*states\s*history|apush", "ap-us-history"),
    (r"comparative\s*gov", "ap-comparative-government-and-politics"),
    (r"gov", "ap-us-government-and-politics"),
    (r"micro", "ap-microeconomics"),
    (r"macro", "ap-macroeconomics"),
    (r"psych", "ap-psychology"),
    (r"spanish", "ap-spanish-language-and-culture"),
    (r"french", "ap-french-language-and-culture"),
    (r"latin", "ap-latin"),
    (r"art\s*history", "ap-art-history"),
    (r"music\s*theory", "ap-music-theory"),
    (r"african\s*american", "ap-african-american-studies"),
    (r"seminar", "ap-seminar"),
    (r"research", "ap-research"),
)

MAX_PAGES = 320          # the longest CEDs run about 300 pages
MAX_UNIT_CHARS = 14_000  # one unit's framework, trimmed to fit the prompt
UNIT_HEAD = re.compile(r"^\s*UNIT\s+(\d{1,2})\b", re.MULTILINE)
UNIT_IN_TITLE = re.compile(r"\bunit\s*(\d{1,2})\b", re.IGNORECASE)


def slug_for(course_name: str) -> str | None:
    """The CED slug for a class name, or None when it is not an AP course
    this module knows. "AP" itself is not required — Veracross writes
    "Advanced Placement Physics C", Canvas writes "AP Physics C"."""
    name = (course_name or "").lower()
    if not name:
        return None
    if not re.search(r"\bap\b|advanced\s*placement", name):
        return None
    for pattern, slug in COURSES:
        if re.search(pattern, name):
            return slug
    return None


def url_for(slug: str) -> str:
    return f"{CED_BASE}{slug}-course-and-exam-description.pdf"


def unit_from_title(title: str) -> int | None:
    match = UNIT_IN_TITLE.search(title or "")
    return int(match.group(1)) if match else None


def split_units(text: str) -> dict[int, str]:
    """{unit number: that unit's text}. A CED names each unit at the head of
    its section ("UNIT 3 ...") and again in the table of contents and the
    exam-weighting table, so the LONGEST run under each number is the unit's
    real section and the short mentions are dropped."""
    heads = list(UNIT_HEAD.finditer(text or ""))
    best: dict[int, str] = {}
    for i, head in enumerate(heads):
        number = int(head.group(1))
        end = heads[i + 1].start() if i + 1 < len(heads) else len(text)
        chunk = text[head.start():end].strip()
        if len(chunk) > len(best.get(number, "")):
            best[number] = chunk
    return {n: (c[:MAX_UNIT_CHARS].rsplit(" ", 1)[0] + "\n[… trimmed]" if len(c) > MAX_UNIT_CHARS else c)
            for n, c in best.items()}


def _pdf_text(data: bytes) -> str:
    from pypdf import PdfReader
    reader = PdfReader(io.BytesIO(data))
    pages = []
    for page in reader.pages[:MAX_PAGES]:
        try:
            pages.append(page.extract_text() or "")
        except Exception:  # noqa: BLE001
            pages.append("")
    return "\n".join(pages)


def _cache_dir() -> Path:
    folder = paths.cache_dir() / "ced"
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def load_units(slug: str, fetch=None) -> dict[int, str]:
    """Every unit's text for a course, from the cache or the PDF. `fetch` is
    a callable(url) -> bytes, so the extension's fetch shim and a test can
    both stand in for the network."""
    cache = _cache_dir() / f"{slug}.json"
    if cache.exists():
        try:
            saved = json.loads(cache.read_text(encoding="utf-8"))
            return {int(k): v for k, v in (saved.get("units") or {}).items()}
        except (OSError, ValueError):
            pass
    if fetch is None:
        import httpx

        def fetch(url):
            response = httpx.get(url, timeout=60.0, follow_redirects=True,
                                 headers={"User-Agent": "sillybus study helper"})
            response.raise_for_status()
            return response.content
    data = fetch(url_for(slug))
    units = split_units(_pdf_text(data))
    cache.write_text(json.dumps({"slug": slug, "url": url_for(slug),
                                 "units": {str(k): v for k, v in units.items()}},
                                ensure_ascii=False), encoding="utf-8")
    log.info("ced %s: %d units read", slug, len(units))
    return units


def unit_text(course_name: str, unit: int | None, fetch=None) -> tuple[str, str] | None:
    """(text, how) for one unit of a course's CED, or None with the reason
    logged. `how` names the source the way Accelerate lists sources."""
    slug = slug_for(course_name)
    if not slug:
        return None
    units = load_units(slug, fetch=fetch)
    if not units:
        return None
    if unit is None or unit not in units:
        # No unit named: the course framework's opening (the first unit's
        # section is where the big ideas and skills are stated), marked as such.
        first = min(units)
        return units[first], f"College Board CED for {slug.replace('-', ' ')} (course framework, unit {first} shown)"
    return units[unit], f"College Board Course and Exam Description, unit {unit}"
