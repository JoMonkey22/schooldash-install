"""The board's own preferences: read them, and refuse to write nonsense.

Why this exists at all
----------------------
Until 0.20 every preference lived in one browser's `localStorage`. That is
fine for one install and wrong for this one, because the same student uses the
same board in TWO places — the Mac bundle and the Chrome extension — and a
choice made in one never reached the other. So the truth moved into
`config.json` under `ui`, and `localStorage` keeps only a mirror of the handful
of appearance keys the pre-paint head script needs before the first frame.

Why the validation is strict
----------------------------
`config.json` is loaded on every request and carries the feed credentials. A
`PUT /api/prefs` is the only route by which the browser writes to it, so it
validates by allow-list: an unknown key, a wrong type or an out-of-range value
is refused with a sentence naming the offending key, and NOTHING is written.
Silently dropping a bad key would be worse than refusing — the page would
report success over a preference that never landed.

Nothing here is secret, so `GET /api/prefs` returns the block verbatim.
"""

from __future__ import annotations

import re

from sillybus import config

# The registry of formats lives in the front end (`SECTIONS` in app.js) because
# that is where the renderers are; this is the same list, kept here so a typo
# in a PUT is caught by the server rather than by an empty section.
SECTION_FORMATS: dict[str, tuple[str, ...]] = {
    "calendar": ("day", "week", "month", "three", "agenda"),
    "chats": ("list", "answer", "ask"),
    "life": ("kinds", "list", "next"),
    "classes": ("strip", "bars", "rows", "table", "average"),
    "work": ("byclass", "even", "byday", "flat"),
    "priority": ("cards", "list", "one", "timeline"),
    "links": ("full", "labels", "icons"),
}

THEMES = ("system", "light", "warm", "dark")
PATTERNS = ("none", "glow", "dots", "grid",
            "aurora", "drift", "waves", "orbit", "tide", "breathe")   # the last six move
PATTERN_STRENGTHS = ("subtle", "normal", "bold")
DENSITIES = ("compact", "roomy")
MOTIONS = ("auto", "off")
DATE_NOTES = ("hover", "always")
GRADE_DISPLAY = ("letter", "percent", "both", "none")
TAB_LABELS = ("auto", "codes", "names")
OPEN_WITH = ("greeting", "last", "chat")
LOOKS = ("simple", "board")
GRADE_LEVELS = ("", "6", "7", "8", "9", "10", "11", "12", "college", "other")
SORTS = ("period", "name", "custom")
STATUS_MARKS = ("symbols", "dot")
TICKS = ("hover", "always")
SURFACES = ("open", "cards", "glass")
TRANSITIONS = ("none", "fade", "slide", "rise", "zoom")
TRANSITION_STRENGTHS = ("subtle", "normal", "strong")
STRIP_TABS = ("work", "life", "calendar", "mail", "done")   # Home and Settings are not optional
PERIODS = (1, 9)                            # 1–8 are periods; 9 is "meets every day, no period"
WEEK_STARTS = ("monday", "sunday")
BACKGROUND_KINDS = ("", "image", "video")

# Google Fonts the page actually loads. A font that is not in the stylesheet
# falls back to the system stack, which reads as "the setting did nothing".
FONTS_BODY = ("Inter", "Source Serif 4", "Space Grotesk", "Nunito",
              "JetBrains Mono", "system-ui")
FONTS_HEAD = ("Fraunces", "Plus Jakarta Sans", "DM Serif Display",
              "Space Grotesk", "Inter", "Nunito")

# Text size in CSS pixels. Below 11 the date_note line stops being readable at
# his window size; above 22 the twelve class bands stop fitting, and the board
# would start hiding work to make room, which is the one thing it may not do.
TEXT_SIZE = (11, 22)

_HEX = re.compile(r"^#[0-9a-fA-F]{6}$")
# A background file NAME, not a path: it is resolved inside the data home, so a
# separator or a dot-dot is a traversal attempt and is refused outright.
_FILENAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")


class PrefError(ValueError):
    """A preference the page sent that this module will not write."""


def defaults() -> dict:
    """A fresh copy of the shipped defaults."""
    import copy

    return copy.deepcopy(config.DEFAULTS["ui"])


def first_name(cfg: dict | None = None) -> str:
    """What the greeting calls the student: the name they typed, else the
    first word of the name their school Google account gave Canvas when they
    signed in. Blank when neither exists — never a guess."""
    cfg = cfg if cfg is not None else config.load()
    typed = load(cfg).get("greeting_name") or ""
    if typed:
        return typed
    full = str(((cfg.get("canvas") or {}).get("name")) or "").strip()
    first = full.split()[0] if full else ""
    # "Rivera, Sam" is how some SIS exports write it
    if "," in full:
        after = full.split(",", 1)[1].strip().split()
        first = after[0] if after else ""
    return first[:40]


def load(cfg: dict | None = None) -> dict:
    """The saved preferences, with every missing key filled from the defaults.

    Never raises: a hand-edited `config.json` costs one preference, not the
    whole board.
    """
    cfg = cfg if cfg is not None else config.load()
    saved = cfg.get("ui")
    out = defaults()
    if not isinstance(saved, dict):
        return out
    for key, value in saved.items():
        if key not in out:
            continue  # a key from a newer version, or a typo — ignore it
        try:
            out[key] = _clean(key, value, out[key])
        except PrefError:
            pass  # keep the default for that one key
    return out


def update(patch: dict) -> dict:
    """Validate `patch`, merge it into config.json, return the whole block.

    Raises `PrefError` before writing anything if any key is bad.
    """
    if not isinstance(patch, dict):
        raise PrefError("preferences must be an object")
    current = load()
    clean: dict = {}
    for key, value in patch.items():
        if key not in current:
            raise PrefError(f"there is no preference called {key!r}")
        clean[key] = _clean(key, value, current[key])
    if not clean:
        return current
    merged = {**current, **clean}
    # replace, not merge: `abbr` and `colors` are keyed by course, and taking
    # a class's code away means its key is GONE from the dict — a merge-write
    # would keep it (see config.replace_key)
    config.replace_key("ui", merged)
    return load()


# --------------------------------------------------------------------------
# validation, one key at a time


def _clean(key: str, value, fallback):
    fn = _CLEANERS.get(key)
    if fn is None:  # unreachable while _CLEANERS covers DEFAULTS["ui"]
        raise PrefError(f"there is no preference called {key!r}")
    return fn(key, value, fallback)


def _one_of(options: tuple[str, ...]):
    def check(key, value, _fallback):
        if value not in options:
            raise PrefError(f"{key} must be one of: {', '.join(o or '(none)' for o in options)}")
        return value

    return check


def _bool(key, value, _fallback):
    if not isinstance(value, bool):
        raise PrefError(f"{key} must be true or false")
    return value


def _colour(key, value, _fallback):
    if not isinstance(value, str) or not _HEX.match(value):
        raise PrefError(f"{key} must be a colour like #0f766e")
    return value.lower()


def _text_size(key, value, _fallback):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise PrefError(f"{key} must be a number")
    low, high = TEXT_SIZE
    if not low <= value <= high:
        raise PrefError(f"{key} must be between {low} and {high}")
    return round(float(value), 1)


def _font(options: tuple[str, ...]):
    def check(key, value, _fallback):
        if value not in options:
            raise PrefError(f"{key} must be one of: {', '.join(options)}")
        return value

    return check


def _keys(key, value, _fallback):
    """A list of course keys — hidden classes, or a custom order."""
    if not isinstance(value, list):
        raise PrefError(f"{key} must be a list of class keys")
    out = []
    for entry in value:
        if not isinstance(entry, str) or not entry.strip():
            raise PrefError(f"{key} may only hold class keys")
        entry = entry.strip()[:120]
        if entry not in out:
            out.append(entry)
    return out


def _colors(key, value, _fallback):
    """course_key -> a hex colour that overrides the one derived from the key.

    Stored per class rather than as a palette, because the thing being fixed is
    a specific collision: two classes whose keys happen to hash to neighbouring
    hues. A class not named here keeps the derived colour, which is why this
    starts empty rather than listing every class.
    """
    if not isinstance(value, dict):
        raise PrefError("colors must be an object of class key -> colour")
    out = {}
    for course_key, colour in value.items():
        if not isinstance(course_key, str) or not isinstance(colour, str):
            raise PrefError("colors must be an object of class key -> colour")
        colour = colour.strip()
        if not _HEX.match(colour):
            raise PrefError(f"the colour for {course_key} must look like #0f766e")
        out[course_key.strip()[:120]] = colour.lower()
    return out


def _abbr(key, value, _fallback):
    """course_key -> short code. Upper-cased and clipped, because the column
    it goes in is 3-4 characters wide and a longer one would push the row."""
    if not isinstance(value, dict):
        raise PrefError("abbr must be an object of class key -> short code")
    out = {}
    for course_key, code in value.items():
        if not isinstance(course_key, str) or not isinstance(code, str):
            raise PrefError("abbr must be an object of class key -> short code")
        # His casing, not ours: "Chem" is what he typed and "CHEM" is a label
        # shouting at him. [ASKED] 2026-09-18: "don't force all caps".
        code = code.strip()[:4]
        if code:
            out[course_key.strip()[:120]] = code
    return out


def _formats(key, value, fallback):
    """Which formats are ticked on, per section. At least one per section —
    zero would leave that section blank with no way back to it from the board."""
    if not isinstance(value, dict):
        raise PrefError("formats must be an object of section -> list")
    out = dict(fallback)
    for section, chosen in value.items():
        allowed = SECTION_FORMATS.get(section)
        if allowed is None:
            raise PrefError(f"there is no section called {section!r}")
        if not isinstance(chosen, list):
            raise PrefError(f"formats.{section} must be a list")
        picked = [f for f in allowed if f in chosen]  # registry order, deduped
        if not picked:
            raise PrefError(
                f"{section} needs at least one format ticked — "
                "an empty section has no way back to itself"
            )
        out[section] = picked
    return out


def _active(key, value, fallback):
    if not isinstance(value, dict):
        raise PrefError("active must be an object of section -> format")
    out = dict(fallback)
    for section, chosen in value.items():
        allowed = SECTION_FORMATS.get(section)
        if allowed is None:
            raise PrefError(f"there is no section called {section!r}")
        if chosen not in allowed:
            raise PrefError(f"{section} has no format called {chosen!r}")
        out[section] = chosen
    return out


def _background(key, value, fallback):
    if not isinstance(value, dict):
        raise PrefError("background must be an object")
    out = dict(fallback)
    if "file" in value:
        name = value["file"]
        if not isinstance(name, str):
            raise PrefError("background.file must be a file name")
        name = name.strip()
        if name and not _FILENAME.match(name):
            raise PrefError("background.file must be a plain file name, no folders")
        out["file"] = name
    if "kind" in value:
        out["kind"] = _one_of(BACKGROUND_KINDS)("background.kind", value["kind"], None)
    if "opacity" in value:
        opacity = value["opacity"]
        if isinstance(opacity, bool) or not isinstance(opacity, (int, float)):
            raise PrefError("background.opacity must be a number")
        if not 0 <= opacity <= 1:
            raise PrefError("background.opacity must be between 0 and 1")
        out["opacity"] = round(float(opacity), 3)
    return out


# Eight is a full top bar at his window; more than that and the row scrolls,
# which is the failure the strip was built to avoid.
MAX_SHORTCUTS = 8
_HTTPS = re.compile(r"^https://[^\s/$.?#][^\s]*$", re.I)


def _shortcuts(key, value, _fallback):
    """His own quick links: a name and an https address each. Only https —
    a shortcut is opened in a new tab from a page that renders a signed-in
    school session, and a javascript: or data: address there is a hole."""
    if not isinstance(value, list):
        raise PrefError("shortcuts must be a list")
    if len(value) > MAX_SHORTCUTS:
        raise PrefError(f"keep it to {MAX_SHORTCUTS} shortcuts — more than that and the top bar scrolls")
    out, seen = [], set()
    for entry in value:
        if not isinstance(entry, dict):
            raise PrefError("each shortcut must be an object with a name and a url")
        name = str(entry.get("name") or "").strip()[:40]
        url = str(entry.get("url") or "").strip()
        if not name:
            raise PrefError("a shortcut needs a name")
        if not _HTTPS.match(url):
            raise PrefError(f"the address for {name} must start with https://")
        if url.lower() in seen:
            continue
        seen.add(url.lower())
        out.append({"name": name, "url": url})
    return out


MAX_HIDDEN_LINKS = 40


def _hidden_links(key, value, _fallback):
    """Quick links the student has switched off, by name. Unbounded would let
    a loop write config.json forever; forty is more sites than the strip can
    ever earn."""
    if not isinstance(value, list):
        raise PrefError("hidden_links must be a list of names")
    out, seen = [], set()
    for entry in value:
        name = str(entry or "").strip()[:60]
        if not name or name.lower() in seen:
            continue
        seen.add(name.lower())
        out.append(name)
    if len(out) > MAX_HIDDEN_LINKS:
        raise PrefError(f"that is more than {MAX_HIDDEN_LINKS} hidden links")
    return out


def _names(key, value, _fallback):
    """course_key -> what he calls the class. Sixty characters, because a tab
    and a chip have to hold it; empty removes the rename."""
    if not isinstance(value, dict):
        raise PrefError("names must be an object of class key -> name")
    out = {}
    for course_key, name in value.items():
        if not isinstance(course_key, str) or not isinstance(name, str):
            raise PrefError("names must be an object of class key -> name")
        name = name.strip()[:60]
        if name:
            out[course_key.strip()[:120]] = name
    return out


def _merge(key, value, _fallback):
    """foreign course key -> the class it belongs to. Both are keys, not names,
    because a name is what changed between sources in the first place."""
    if not isinstance(value, dict):
        raise PrefError("merge must be an object of class key -> class key")
    out = {}
    for src, dst in value.items():
        if not isinstance(src, str) or not isinstance(dst, str) or not src.strip() or not dst.strip():
            raise PrefError("merge must be an object of class key -> class key")
        if src.strip() == dst.strip():
            continue
        out[src.strip()[:120]] = dst.strip()[:120]
    return out


def _periods(key, value, _fallback):
    """course_key -> 1..9. Eight periods across the two day types, plus 9 for
    a class that meets every day and belongs to no period. Anything else is a
    typo, and a class not named here is detected from the schedule."""
    if not isinstance(value, dict):
        raise PrefError("periods must be an object of class key -> period number")
    out = {}
    for course_key, period in value.items():
        if not isinstance(course_key, str):
            raise PrefError("periods must be an object of class key -> period number")
        if period in ("", None):
            continue
        if isinstance(period, bool) or not isinstance(period, int) or not PERIODS[0] <= period <= PERIODS[1]:
            raise PrefError(f"a period is a whole number from {PERIODS[0]} to {PERIODS[1]} (9 means it meets every day)")
        out[course_key.strip()[:120]] = period
    return out


def _tabs_off(key, value, _fallback):
    """Which optional fixed tabs are turned off the strip, in the strip's own
    order. Home and Settings cannot be named."""
    if not isinstance(value, list):
        raise PrefError("tabs_off must be a list")
    for entry in value:
        if entry not in STRIP_TABS:
            raise PrefError(f"tabs_off may only name: {', '.join(STRIP_TABS)}")
    return [t for t in STRIP_TABS if t in value]


def _pattern_color(key, value, _fallback):
    """A hex colour for the background pattern, or blank for the automatic
    one (the accent, dimmed)."""
    if not isinstance(value, str):
        raise PrefError("pattern_color must be a colour like #0f766e, or blank")
    value = value.strip()
    if not value:
        return ""
    if not _HEX.match(value):
        raise PrefError("pattern_color must be a colour like #0f766e, or blank")
    return value.lower()


def _greeting_name(key, value, _fallback):
    """Up to 40 characters of whatever the student wants to be called; blank
    means the greeting says "Hello" alone."""
    if not isinstance(value, str):
        raise PrefError("greeting_name must be text")
    return re.sub(r"\s+", " ", value).strip()[:40]


def _birthday(key, value, _fallback):
    """Blank, or a real date as YYYY-MM-DD — the browser's own date box
    writes exactly that. A date in the future or before 1900 is a typo."""
    import datetime as _dt
    if not isinstance(value, str):
        raise PrefError("birthday must be text")
    value = value.strip()
    if not value:
        return ""
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        raise PrefError("birthday must look like 2010-04-23")
    try:
        day = _dt.date.fromisoformat(value)
    except ValueError:
        raise PrefError("birthday is not a real date") from None
    if day.year < 1900 or day > _dt.date.today():
        raise PrefError("birthday must be a past date")
    return value


def _focus(key, value, fallback):
    """The Focus block: mode, the site list, and how the gate behaves.

    Validated a sub-key at a time and MERGED onto what is saved, so the
    Settings page can send `{"focus": {"mode": "block"}}` without having to
    resend the site list it did not touch. The PIN is deliberately not here:
    it is a secret, `GET /api/prefs` serves this block verbatim, and the gate
    has to check it with no Python running. It lives hashed in the extension's
    own storage (`focus.py`, and `background.js` does the checking).
    """
    from sillybus import focus as focus_mod

    if not isinstance(value, dict):
        raise PrefError("focus must be an object")
    out = dict(fallback)
    if "mode" in value:
        out["mode"] = _one_of(focus_mod.MODES)("focus.mode", value["mode"], None)
    if "remind_every" in value:
        out["remind_every"] = _one_of(focus_mod.REMIND_EVERY)(
            "focus.remind_every", value["remind_every"], None)
    if "when_clear" in value:
        out["when_clear"] = _one_of(focus_mod.WHEN_CLEAR)(
            "focus.when_clear", value["when_clear"], None)
    if "bypass_minutes" in value:
        minutes = value["bypass_minutes"]
        low, high = focus_mod.BYPASS_MINUTES
        if isinstance(minutes, bool) or not isinstance(minutes, int):
            raise PrefError("focus.bypass_minutes must be a whole number of minutes")
        if not low <= minutes <= high:
            raise PrefError(f"focus.bypass_minutes must be between {low} and {high}")
        out["bypass_minutes"] = minutes
    if "sites_off" in value:
        off = value["sites_off"]
        if not isinstance(off, list):
            raise PrefError("focus.sites_off must be a list of site names")
        for entry in off:
            if entry not in focus_mod.PRESET_IDS:
                raise PrefError(f"there is no site called {entry!r} on the list")
        out["sites_off"] = [p for p in focus_mod.PRESET_IDS if p in off]
        if len(out["sites_off"]) == len(focus_mod.PRESET_IDS) and not (
                value.get("custom", out.get("custom")) or []):
            raise PrefError("Focus needs at least one site — with none on the "
                            "list there is nothing for it to do")
    if "custom" in value:
        custom = value["custom"]
        if not isinstance(custom, list):
            raise PrefError("focus.custom must be a list of web addresses")
        if len(custom) > focus_mod.MAX_CUSTOM:
            raise PrefError(f"keep it to {focus_mod.MAX_CUSTOM} sites of your own")
        seen: list[str] = []
        for entry in custom:
            try:
                host = focus_mod.clean_host(entry)
            except focus_mod.FocusError as exc:
                raise PrefError(str(exc)) from None
            # A custom entry a preset already covers would make the same site
            # appear twice in Settings and ask Chrome for the same origin
            # twice, so it is dropped rather than refused.
            if host in seen or any(focus_mod._matches(host, p["hosts"])
                                   for p in focus_mod.active_presets(out)):
                continue
            seen.append(host)
        out["custom"] = seen
    return out


def _start_tab(key, value, _fallback):
    """"home", "life", "calendar", "settings", or a course key — the tab strip
    carries one tab per class, so this cannot be a closed list."""
    if not isinstance(value, str) or not value.strip():
        raise PrefError("start_tab must be a tab name")
    return value.strip()[:120]


_CLEANERS = {
    "theme": _one_of(THEMES),
    "accent": _colour,
    "pattern": _one_of(PATTERNS),
    "font_body": _font(FONTS_BODY),
    "font_head": _font(FONTS_HEAD),
    "text_size": _text_size,
    "density": _one_of(DENSITIES),
    "motion": _one_of(MOTIONS),
    "background": _background,
    "formats": _formats,
    "active": _active,
    "abbr": _abbr,
    "hidden": _keys,
    "order": _keys,
    "date_notes": _one_of(DATE_NOTES),
    "show_estimates": _bool,
    "hide_low_priority": _bool,
    "open_with": _one_of(OPEN_WITH),
    "start_tab": _start_tab,
    "week_starts": _one_of(WEEK_STARTS),
    "show_weekends": _bool,
    "colors": _colors,
    "grade_display": _one_of(GRADE_DISPLAY),
    "tab_labels": _one_of(TAB_LABELS),
    "shortcuts": _shortcuts,
    "hidden_links": _hidden_links,
    "merge": _merge,
    "keep_apart": _keys,
    "names": _names,
    "periods": _periods,
    "sort": _one_of(SORTS),
    "status_marks": _one_of(STATUS_MARKS),
    "ticks": _one_of(TICKS),
    "surface": _one_of(SURFACES),
    "tabs_off": _tabs_off,
    "transition": _one_of(TRANSITIONS),
    "transition_strength": _one_of(TRANSITION_STRENGTHS),
    "greeting_name": _greeting_name,
    "birthday": _birthday,
    "grade_level": _one_of(GRADE_LEVELS),
    "look": _one_of(LOOKS),
    "pattern_color": _pattern_color,
    "pattern_strength": _one_of(PATTERN_STRENGTHS),
    "tour_seen": _bool,
    "focus": _focus,
}
