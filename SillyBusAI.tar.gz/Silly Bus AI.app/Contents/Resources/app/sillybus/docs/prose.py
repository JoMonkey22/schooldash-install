"""Homework typed onto the page itself — no table, and no Canvas assignment.

Why this exists. [MEASURED] 2026-09-01, across eleven course homepages: nine
are a single <iframe> embedding the teacher's Google Doc (which the doc
pipeline already reads), one is a module index, and one — Spanish 1 — **is**
the schedule, typed straight into the Canvas page as flat paragraphs:

    Week 3&4 (Block A and B) - 8/24
    Day 1 (Monday 8/24)
    p. 13-16 ( El calendario )
    **Tarea: P- 7, P-8, Finish Quizlet Write for Para Empezar set by day 4
    …
    Day 4 (Tues 9/1)
    Vocab Quiz on Para Empezar Vocab Set
    Day 5 (Thurs 9/3)
    Test on Para Empezar chapter

Nothing read it. The Canvas planner had no assignment for any of it and that
course's Google Doc is private, so the class showed **zero** homework all term
while its own homepage listed a quiz that day and a test two days later.

`items.py` cannot help: it builds items out of <table> rows, and there is no
table here. This is the prose half of the same job, under the same rules.

**What becomes an item, and what deliberately does not.** Dated headings give
context to work below them. A self-dated task, explicit homework prefix, or
bounded weekly obligation can also stand alone; grading policy and resource
links alone are not work. The main signals are:

1. **a homework prefix** — "**Tarea:", "Homework:", "HW:", "Due:", "Turn in".
   The prefix is the teacher saying "this one is yours to do".
2. **an assessment named at the start of the line** — "Test on …", "Vocab Quiz
   on …". A graded event on a stated day is the single most costly thing to
   miss. It must be *at the start*: [MEASURED] on this page "Calentamiento -
   ¿Qué hora es? Practice Quiz (To show assessment procedures- No grade)" is a
   warm-up, and a substring match on "quiz" would have put a fake quiz on the
   board. A line that calls itself ungraded is not an assessment either.
3. **an instruction to do something that carries a link** — "Complete (Calendar
   and Dates Practice) WayGround Assignment". The link is what separates work
   to hand in from the page numbers the class will read together.
4. **a stated obligation/deadline** — including work written only as homepage
   prose. Visual line breaks do not make the next task part of a lesson label.

Everything else on the day — "p. 13-16 ( El calendario )", "Presentations of
Four 'F's handout", "Intro to alphabet" — is the lesson plan, and putting the
lesson plan on a homework board is how the board stops being read.

**Dates are read, never invented.** A line's date comes from the heading above
it, resolved against that class's real meetings, and every item says in plain
words which heading it came from. Homework is due at the NEXT meeting, matching
the doc extractor. A line's own stated deadline beats that convention; its
stated clock also beats a meeting-time default. An imprecise phrase such as
"next week" remains a range needing confirmation rather than an invented day.
"""

import re
import hashlib
from urllib.parse import urlsplit
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta

from sillybus import timezones
from sillybus.docs import dates as dates_mod
from sillybus.docs import links as links_mod
from sillybus.models import Item

# Line-start markers, wider than the doc extractor's defaults because a page
# is written by whoever owns the page and nobody profiled it first. Spanish's
# "**Tarea (HW):" is the reason the parenthetical is tolerated below.
PAGE_PREFIXES = {
    "next_meeting": ["Homework", "HW", "H.W", "Tarea", "Deberes", "Devoirs",
                     "Assignment", "Assignments", "To Do", "Todo", "Tonight",
                     "For tonight", "For tomorrow", "For next class", "At home"],
    "same_meeting": ["Due Today", "Due", "Turn in", "Hand in", "Submit", "Bring"],
    # The lesson plan. A line marked this way is what happens IN class.
    "skip": ["Agenda", "In class", "In-class", "Plan", "Warm-up", "Warm up",
             "Bell work", "Do Now", "Objective", "Calentamiento", "Repaso"],
}

# An annotation is not a lesson-plan marker: it is a wrapper around whatever
# comes next, and what comes next is often the homework.
#
# [PROVEN] tests/test_prosecution.py — these words used to sit in the skip list
# and were tested FIRST, so three of five real lines came back as nothing:
#   "Reminder: turn in your lab procedures tomorrow" -> (None, '')
#   "Please note: Homework is chapter 4"             -> (None, '')
#   "Note: HW is p. 30"                              -> (None, '')
# The prefix is peeled off and the rest of the line is classified on its own
# merits; a note with no work in it still becomes nothing.
ANNOTATION_PREFIXES = ["Note", "Notes", "Please note", "Reminder", "Reminders",
                       "Remember", "FYI", "NB", "N.B.", "Heads up", "Important",
                       "Aviso", "Ojo"]
# "Homework is chapter 4" reads as "is chapter 4" once the prefix goes, so a
# copula left stranded at the front is dropped too.
RE_STRANDED_COPULA = re.compile(r"^(?:is|are|was|were|will be|=)\s+", re.I)

# A line that OPENS with one of these is describing when something else
# happens, not naming itself. [MEASURED] "After the test, you will set up your
# SARA Account …" was filed as a TEST, because the rule below allows three
# words in front of the word and "After the" is two.
RE_SUBORDINATE_OPENER = re.compile(
    r"^(?:after|before|during|once|when|while|whenever|if|unless|since|until|"
    r"following|prior to|as soon as|in preparation for|to prepare for)\b", re.I)

# An assessment has to be named in the opening words of the line (at most three
# words in front of it, e.g. "Vocab Quiz on …"), or it is not the subject of
# the sentence and this must not guess that it is.
RE_ASSESSMENT_LEAD = re.compile(
    r"^(?:[\w'’¿?.#-]+\s+){0,3}?"
    r"\b(tests?|quiz|quizzes|exams?|midterms?|finals?|assessments?|prueba|examen)\b",
    re.I)
# Longer named subjects are common ("No Red Ink Unit 2 test is today").
# Require an explicit scheduling predicate; a later mention of a test, a review,
# or explanatory prose must not become an assessment merely by adding words.
RE_ASSESSMENT_SCHEDULED = re.compile(
    r"^[^.!?;]{1,100}?\b(tests?|quiz|quizzes|exams?)\s+"
    r"(?:is|will be)\s+(?:today\b|(?:on|in)\s+class\s*#?\s*\d{1,3}\b)", re.I)
RE_NRI_LESSON_SETUP = re.compile(
    r'^Now we will start grammar work\. In Canvas, click on Assignments from '
    r'the left hand menu, and then click on (?P<name>No Red Ink Unit [1-9][0-9]*: [^.!?=]+)\. '
    r'We will walk through the set-up together\. All lessons are due [^=]+?'
    r'=\s*(?P<points>[1-9][0-9]{0,2}) points?\s*\.?$', re.I)
RE_NRI_LESSON_DEADLINE = re.compile(
    r'^(?:[0-9]+\.\s*)?No Red Ink Unit [1-9][0-9]*: [^.!?=]+? '
    r'Canvas assignment is due [^=]+?=\s*(?P<points>[1-9][0-9]{0,2}) points?\s*(?:\.|$)', re.I)
RE_MEMBEAN_ENROLLMENT_TRAINING = re.compile(
    r'^Now, we will set up the vocabulary program called Membean\b[^\n]*?'
    r'\bEvery 2 weeks, ([1-9][0-9]*) minutes of training\b[^=]*?'
    r'must be completed by [^=]+?=\s*([1-9][0-9]{0,2}) points?\b', re.I)
RE_MEMBEAN_SCORED_TRAINING = re.compile(
    r'^[1-9][0-9]* minutes of Membean training\b[^=]*?'
    r'must be completed by [^=]+?=\s*([1-9][0-9]{0,2}) points?\b', re.I)
RE_CANVAS_CLASS_DISCUSSION = re.compile(
    r'(?:^|[.!?]\s+)In Canvas, complete the Discussion Board '
    r'by the end of class today\s*[.!]?$', re.I)
RE_SCORED_CLASS_QUIZ = re.compile(
    r'^(?P<name>The [^.!?;=]{1,80} quiz) is (?:today|Class [1-9][0-9]* next week)\s*=\s*'
    r'(?P<points>[1-9][0-9]{0,2}) points?\s*\.(?=\s|$)', re.I)
RE_PRINTED_QUOTES = re.compile(
        r'^[^.!?;=]{1,100} [1-9][0-9]* Grad@Grad related quotes with analysis '
        r'are (?:also|all) due and must be printed(?: for Class [1-9][0-9]* next week)?'
        r'\s*=\s*([1-9][0-9]{0,2}) points?\s*(?:\.|$)', re.I)
RE_ANNOTATED_BOOK_CHECK = re.compile(
    r"^Today, I will check your annotated copy of [^.!?;=]{1,100}\s*\.\s+"
    r"Your highlights and margin annotations should follow the formats "
    r"on the assignment web page below\s*=\s*([1-9][0-9]{0,2}) points?\s*\.?$",
    re.I)
RE_SCORED_NRI_TEST = re.compile(
    r"^No Red Ink Unit [0-9]+: [^.!?;=]{1,80}\btest\s*=\s*([1-9][0-9]{0,2}) points?\b"
    r"(?:[.!]\s*|$)", re.I)
# The teacher saying it does not count.
RE_NOT_GRADED = re.compile(
    r"\bno grade|not graded|ungraded|practice (quiz|test)|no points\b", re.I)
# "For Class 11, …" / "Next Class 9 - …" / "For next class" — work set now and
# wanted at the next meeting. [MEASURED] Honors English writes both forms, and
# without them the line was dated to the class it was ANNOUNCED in, one class
# early, which then failed to dedupe against that class's own copy of it.
RE_FOR_NEXT = re.compile(
    r"^\W{0,3}(?:for|next)\s+(?:class|session|lesson)\s*\d{1,3}\s*[,:;\-–—]?\s*"
    r"|^\W{0,3}for\s+(?:next\s+class|tomorrow|tonight|"
    r"mon|tues?|wed(?:nes)?|thur?s?|fri)[a-z]*\b\s*[,:;\-–—]?\s*", re.I)

# A line that states a deadline anywhere in it, not just at the front. This is
# how a prose doc marks homework: "True Diary Chapter 2-5 are due with …",
# "…must be completed = 25 points". Deliberately narrow — "you must also attain
# an 85% average" and "*120 minutes completed = 20 points" are not deadlines.
# [MEASURED] 2026-09-02: this gate decided "due by", "due today" and "due
# next" were deadlines and "due Sep 26", "due TONIGHT" and "due Monday" were
# not. AI Frontiers' doc states every deadline the second way — "100 pts, due
# Sep 26", "25 points, due TONIGHT by 11:59 pm", "15 points, due Monday" — so
# its work was never work, and the class had reported zero homework since
# August. The list of connectives was doing the job a date should do.
#
# Still narrow, and in the same way: "due" now has to be followed by an actual
# stated time — a weekday, a month and a day, a numeric date, or tonight. The
# lines the original comment protects stay out, because neither "you must also
# attain an 85% average" nor "*120 minutes completed = 20 points" names one.
RE_DUE_IN_LINE = re.compile(
    r"\b(?:is|are|will be)\s+due\b"
    r"|\bdue\s+(?:date|on|by|before|at|today|tonight|tomorrow|next)\b"
    r"|\bdeadline\s+(?:is|on|by|:)"
    r"|\bdue\s+(?:the\s+)?"
    r"(?:mon|tues?|wednes|wed|thurs|thur|thu|fri|sat|sun)[a-z]*\b"
    r"|\bdue\s+(?:the\s+)?"
    r"(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s*\d{1,2}\b"
    r"|\bdue\s+\d{1,2}\s*/\s*\d{1,2}\b"
    r"|\bmust be (?:completed|finished|turned in|submitted|done|read)\b"
    r"|\bturn(?:ed)? in\b|\bhand(?:ed)? in\b", re.I)

# Classification and resolution must agree: "due start of next class" is
# explicit work even without "at". Biology's chapter shorthand was skipped
# before the existing next-meeting resolver could read it.
RE_DUE_NEXT_CLASS = re.compile(
    r"\bdue\s+(?:(?:at|@)\s+)?(?:(?:the\s+)?(?:start|beginning)\s+of\s+)?"
    r"(?:the\s+)?next\s+(?:class|meeting|lesson|session)\b", re.I)

# A deadline the line states for itself. It beats the heading above it: an
# announcement made in one class about a date eleven days out is not due that
# class, and dating it there would repeat a false deadline under every week
# that mentions it.
#
# A time may come first: "By 8 AM October 14" ([MEASURED] 2026-10-05, Honors
# English's SARA line, which was being dated by the class it sat under).
RE_LINE_DEADLINE = re.compile(
    r"\b(?:due(?:\s+date)?|deadline(?:\s+is)?|by|before|for|completed by|finished by)\s*"
    r"(?:[:\-–]\s*)?(?:on\s+)?"
    r"(?:\d{1,2}(?::\d{2})?\s*[ap]\.?\s?m\.?,?\s+(?:on\s+)?)?(?:the\s+)?"
    r"(?:(?:mon|tues?|wednes|wed|thurs|thur|thu|fri|sat|sun)[a-z]*\.?,?\s*)?"
    r"(?P<date>(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s*"
    r"\d{1,2}(?:st|nd|rd|th)?|\d{1,2}/\d{1,2}(?:/\d{2,4})?)", re.I)

# "100 pts", "20 points", "5 points." — a mark is a property of work, and no
# teacher labels a class day with one.
RE_MARKS_IN_LINE = re.compile(r"\b\d{1,3}\s*(?:pts?|points?)\b", re.I)

# A line that OPENS with what it is worth is the detail line of the work named
# on the line above it. [MEASURED] 2026-09-03, AI Frontiers writes every
# assessment this way:
#
#     Side Hustle Proposal
#     100 points. Due Friday, Sep. 25, 11:59 PM. This is the project ...
#
#     Second Pass: Revise the Mark
#     15 points. Due Tuesday, Aug. 25, 11:59 PM.
#
# Read on its own it became an item called "100 points. Due Friday, Sep. 25,
# 11:59 PM. This is the project everything since Aug 18 has been feeding" —
# a real deadline wearing a title that names no work. The points must LEAD
# the line: "Project launch: High School Side Hustle. 100 points, runs through
# week 8." names its own work and keeps it.
RE_POINTS_LEAD = re.compile(r"^\W{0,3}\d{1,3}\s*(?:pts?|points?)\b", re.I)

# The same thing without the marks. A line that OPENS with a comma is the tail
# of the line above it, not a sentence: Google Docs splits a sentence around a
# link into separate nodes, so "[Side Hustle Proposal], due Sep 26." arrives as
# "Side Hustle Proposal" then ", due Sep 26." — which became an item titled
# "Sep 26". [MEASURED] 2026-09-03.
RE_CONTINUATION = re.compile(r"^\s*[,;]")


def _is_detail_line(text: str) -> bool:
    """This line describes the work named on the line above it."""
    return bool(RE_POINTS_LEAD.match(text or "")
                or RE_CONTINUATION.match(text or "")
                or re.fullmatch(r"due\s+(?:on\s+)?(?:mon|tues?|wed|wednes|thur?s?|fri|sat|sun)[a-z]*"
                                r"(?:\s+next\s+week)?[.!]?", (text or "").strip(), re.I))

# Something to DO. Only counts when the line also carries a link (see above).
RE_ACTION_LEAD = re.compile(
    r"^(?:please\s+)?(complete|finish|submit|turn in|hand in|watch|read|write|register|join|purchase|buy|bring|"
    r"print|fill out|answer|record|upload|post|study for)\b", re.I)
RE_ACTION_IN_LINE = re.compile(r'\b' + RE_ACTION_LEAD.pattern[1:], RE_ACTION_LEAD.flags)

# Date tokens inside a heading: "8/24", "9/1/26", "Sept 3", "August 21st".
RE_DATE_TOKEN = re.compile(
    r"(?<![\w/])(?<!\d\.)(?P<m>\d{1,2})/(?P<d>\d{1,2})(?:/(?P<y>\d{2,4}))?(?![\w/])(?!\.\d)"
    r"|\b(?P<mon>jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s*"
    r"(?P<dd>\d{1,2})(?:st|nd|rd|th)?\b", re.I)
RE_WEEKDAY_WORD = re.compile(
    r"\b(mon|tues|tue|wed|wednes|thurs|thur|thu|fri|sat|sun)[a-z]*\.?\b", re.I)
WEEKDAY_INDEX = {"mon": 0, "tue": 1, "tues": 1, "wed": 2, "wednes": 2,
                 "thu": 3, "thur": 3, "thurs": 3, "fri": 4, "sat": 5, "sun": 6}

# "Day 1", "Día 3" — numbered inside a block, so the count restarts at every
# block heading.
RE_DAY_N_LEAD = re.compile(r"^(?:day|d[íi]a)\s*(\d{1,2})\b", re.I)
# "Class 10", "Session 4", "Lesson 12" — numbered across the whole year, so a
# block heading must NOT reset the count. [MEASURED] Honors English numbers
# every class from the start of the year and lists its weeks newest first.
RE_CLASS_N_LEAD = re.compile(r"^(?:class|session|lesson|clase)\s*(\d{1,3})\b", re.I)
# "Orientation Day (first day of week 1 8/6)", "Back to School Day (8/6)"
RE_NAMED_DAY_LEAD = re.compile(r"^([A-Za-z][A-Za-z'’ ]{0,24}?\bday)\s*(?=\()", re.I)
# "Week 3&4 (Block A and B) - 8/24", "Week of Sept 8", "Unit 2 — Aug 31"
RE_BLOCK_LEAD = re.compile(r"^(?:week|semana|unit|block|quarter|term)\b", re.I)
# A heading is short, or ends in a parenthetical. Anything longer is a
# paragraph that happens to start with a date word.
HEADING_CHARS = 90

# An aside starting mid-line. A Canvas paragraph runs the thing itself and the
# teacher's note about it together — [MEASURED] the real line reads "Vocab Quiz
# on Para Empezar Vocab Set Please note: You will be given the word in English
# and you will have to type it out in Spanish…", which on the board is 110
# characters of title for a four-word quiz. The title stops at the aside; the
# whole line is kept in `detail` and shown when the item is opened.
RE_ASIDE = re.compile(
    r"\s+(?:please\s+note|note that|note:|nb:|n\.b\.|reminder:|"
    r"remember(?:\s+that)?:|fyi:?)\b", re.I)
# Far enough in that what remains is still a name for the work. "Read chapter
# 4" is 14 characters, so the bar sits below that; an aside at the very start
# ("Note: bring your book") is the whole line and is left alone.
MIN_TITLE_BEFORE_ASIDE = 10

# Junk lines: separators the teacher uses to divide weeks, and empties.
RE_SEPARATOR = re.compile(r"^[\s\-–—_=*.·•]{3,}$")

BLOCK_TAGS = ["h1", "h2", "h3", "h4", "h5", "h6", "p", "li", "div", "td", "th"]

# How far back a deadline read out of prose may be and still reach the board.
#
# A Canvas item carries submitted-status, so an overdue one is genuinely
# unsubmitted and belongs at the top. Prose states nothing about what was
# handed in: a schedule doc or a homepage is the record of what happened, and
# its past rows are as likely finished as not. [MEASURED] 2026-09-01 four
# workbook rows from the previous week took the top four places on the whole
# board; 2026-09-02 the English doc alone offered thirty past deadlines.
NO_SUBMISSION_GRACE_DAYS = 3


@dataclass
class ProseResult:
    items: list = field(default_factory=list)
    headings: list = field(default_factory=list)   # what dated the items
    diagnostics: dict = field(default_factory=dict)


def _prefix_regex(entries) -> re.Pattern | None:
    """A line-start prefix matcher that tolerates the decoration teachers put
    around these words: leading asterisks/bullets, a parenthetical gloss, and
    any of colon / dash / en dash as the separator."""
    cleaned = sorted((re.escape(e.strip().rstrip(":-").strip())
                      for e in entries or [] if e and e.strip()), key=len, reverse=True)
    if not cleaned:
        return None
    from sillybus.docs.items import NUMBERED_LEAD

    return re.compile(
        r"^\W{0,3}" + NUMBERED_LEAD
        + r"(?:%s)\b\s*(?:\([^)]{0,24}\))?\s*[:\-–—]?\s*" % "|".join(cleaned),
        re.I)


def compile_prefixes(profile=None) -> dict:
    """Page defaults, widened by the course's profile when it has one. The
    profile was learned from the teacher's DOC, but a teacher who writes
    "**Tarea:" in one place writes it in the other."""
    merged = {key: list(value) for key, value in PAGE_PREFIXES.items()}
    raw = (profile.get("line_prefixes", default=None) if profile else None) or {}
    for group in merged:
        for entry in raw.get(group) or []:
            if entry and entry not in merged[group]:
                merged[group].append(entry)
    return {"homework": _prefix_regex(merged["next_meeting"]),
            "due": _prefix_regex(merged["same_meeting"]),
            "skip": _prefix_regex(merged["skip"]),
            "annotation": _prefix_regex(ANNOTATION_PREFIXES)}


def _weekly_duolingo(text):
    return re.fullmatch(
        r'Complete [1-9][0-9]{0,3}\s*XP of Duolingo by Friday at '
        r'[0-9]{1,2}(?::[0-9]{2})?\s*(?:am|pm) '
        r'\(Duolingo assignments will be weekly and a part of your participation grade\)[.!]?', text, re.I)


def _workbook_weekly_duolingo(text):
    match = re.fullmatch(r'(\*{0,2}Tarea:\s*[0-9]+[A-Z]-[0-9]+),\s*and\s*(Complete .+)', text, re.I)
    return (match[1], match[2]) if match and _weekly_duolingo(match[2]) else None


def _clean(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "")).strip()


def _date_in(text: str, year_start: int | None) -> date | None:
    """The first real date in a heading, or None. Never guesses a year: the
    school year comes from the class feed's own span."""
    for match in RE_DATE_TOKEN.finditer(text or ""):
        if match.group("m"):
            month, day = int(match.group("m")), int(match.group("d"))
            year_text = match.group("y")
            year = (int(year_text) + (2000 if int(year_text) < 100 else 0)
                    if year_text else dates_mod.year_for(month, year_start))
        else:
            month = dates_mod.month_number(match.group("mon"))
            day = int(match.group("dd"))
            year = dates_mod.year_for(month, year_start) if month else None
        if not month or not year or not 1 <= month <= 12:
            continue
        try:
            return date(year, month, day)
        except ValueError:
            continue
    return None


def _weekday_in(text: str) -> int | None:
    match = RE_WEEKDAY_WORD.search(text or "")
    if not match:
        return None
    return WEEKDAY_INDEX.get(match.group(1).lower())


def _weekdays_in(text: str) -> set:
    """EVERY weekday a heading names. A teacher writing one line for several
    class periods names one day per period."""
    return {WEEKDAY_INDEX[m.group(1).lower()]
            for m in RE_WEEKDAY_WORD.finditer(text or "")
            if m.group(1).lower() in WEEKDAY_INDEX}


def _weekdays_by_week(text: str) -> dict:
    """{-1: last week's weekdays, 0: this week's, 1: next week's} in a heading.

    [MEASURED] 2026-10-04, Honors English: "Class 21: Friday for Periods 1 & 3
    and next Monday for Periods 5, 6 & 7" — his period meets on the Monday
    AFTER the week that heading sits in, so looking for a Monday inside that
    week found none. [MEASURED] 2026-10-05, the same teacher, the same class
    copied into the next week: "Class 21: Monday for Periods 5, 6 & 7 and last
    Friday for Periods 1 & 3" — that Friday is the one BEFORE the week."""
    weeks: dict = {-1: set(), 0: set(), 1: set()}
    for m in RE_WEEKDAY_WORD.finditer(text or ""):
        day = m.group(1).lower()
        if day not in WEEKDAY_INDEX:
            continue
        before = (text or "")[max(0, m.start() - 12):m.start()].lower()
        shift = (1 if re.search(r"\bnext\s+$", before)
                 else -1 if re.search(r"\b(?:last|past|previous)\s+$", before) else 0)
        weeks[shift].add(WEEKDAY_INDEX[day])
    return weeks


def _weekdays_split(text: str) -> tuple[set, set]:
    """(this week's weekdays, NEXT week's) in a heading."""
    weeks = _weekdays_by_week(text)
    return weeks[0], weeks[1]


# "By 8 AM this Friday", "due next Tuesday", "before Monday" — a deadline the
# line names by weekday, which only means something counted from the week it
# was written in.
RE_WEEKDAY_DEADLINE = re.compile(
    r"\b(?:due|by|before)\s+(?:\d{1,2}(?::\d{2})?\s*[ap]\.?\s?m\.?\s+)?"
    r"(?:(?:on|at)\s+)?(?:(?P<rel>this|next)\s+)?"
    r"(?P<day>mon|tues?|wednes|wed|thurs|thur|thu|fri|sat|sun)[a-z]*\b", re.I)

RE_WEEKLY_DEADLINE = re.compile(
    r'\bdue\s+(?:by\s+)?each\s+'
    r'(?P<day>mon|tues?|wednes|wed|thurs|thur|thu|fri|sat|sun)[a-z]*\b', re.I)


def weekday_deadline_first(text: str, week, set_on, *, allow_standalone=False):
    """(date, phrase, that week's Monday) when a line's FIRST deadline is a
    weekday and a dated one follows it; else None.

    [MEASURED] 2026-10-05, Honors English, under "Week 7: September 14-18":

        SARA: By 8 AM this Friday, 50% of Reading Level 1 & Writing Level 1
        must be completed = 25 points. By October 14, 100% of all lessons
        must be completed = 25 points.

    `stated_deadline` takes the first deadline that carries a DATE, so "this
    Friday" was stepped over and the line went on the board for October 14,
    under a title promising 50% by "this Friday" — a second SARA row beside
    the current one. Its first deadline was Friday Sep 18. The nearer
    deadline is the one that can be missed next (`stated_deadline`'s own
    rule), so it is dated here, from the week the line was WRITTEN in — the
    block heading's week, else the class it sits under.
    """
    dated = RE_LINE_DEADLINE.search(text or "")
    named = RE_WEEKDAY_DEADLINE.search(text or "")
    if (not named or (not dated and not allow_standalone)
            or (dated and named.start() >= dated.start())):
        return None
    # The document week's Monday is not an unknown class's posting day.
    # Without that anchor, bare "by Monday" might refer to the following
    # week; explicit this/next and the multi-deadline week contract differ.
    if set_on is None and dated is None and not named.group('rel'):
        return None
    # "this Friday ... by Oct 14" explicitly describes the document week,
    # even when the class heading itself points into the following week.
    # A lone weekday under Day 4 of a two-week block counts from that day.
    anchor = ((week[0] if week else None)
              if dated or (named.group('rel') or '').lower() == 'this'
              else set_on) or set_on or (week[0] if week else None)
    if anchor is None:
        return None
    day = WEEKDAY_INDEX[named.group("day").lower()]
    monday = anchor - timedelta(days=anchor.weekday())
    when = monday + timedelta(days=day)
    if (named.group("rel") or "").lower() == "next":
        when += timedelta(days=7)
    elif not named.group("rel") and set_on is not None and when < set_on:
        when += timedelta(days=7)      # "by Monday", written on a Wednesday
    return when, _clean(named.group(0)), monday


RE_RELATIVE_DEADLINE = re.compile(
    r'\b(?:due|by|before)\s+(?:by\s+)?'
    r'(?:\d{1,2}(?::\d{2})?\s*[ap]\.?\s*m\.?\s+)?'
    r'(?P<day>today|tonight|tomorrow)\b', re.I)


# "due Class 22", "by Class 22", "due at the start of Class 22" — a deadline
# named by class number, which only the student's own timetable can turn into
# a date. [MEASURED] 2026-10-04: "Work on Whalefall flashcards and the pages
# 1-41 assignment due Class 22 with a 20 question lockdown browser quiz" was
# dated by the heading it sat under (Class 21), never by its own words.
RE_DUE_DAY_N = re.compile(r"\b(?:due|by|before)\s+(?:on\s+)?day\s*#?\s*(\d{1,2})\b", re.I)


RE_DUE_CLASS_N = re.compile(
    r"\b(?:due|by|before|for)\s+(?:on\s+|at\s+|in\s+)?(?:the\s+)?(?:(?:start|beginning)\s+of\s+)?"
    r"(?:class|session|lesson)\s*#?\s*(\d{1,3})\b", re.I)

# Only an already classified assessment may use an "is in Class N" schedule.
# Making that wording a general due phrase also captures reviews and furniture.
RE_SCHEDULED_CLASS_N = re.compile(
    r"\b(?:is|will be)\s+(?:on|in)\s+class\s*#?\s*(\d{1,3})\b", re.I)

# [MEASURED] English Week 14 assigns a scored practice essay, not an
# ungraded practice test. Require a named essay, numbered schedule and positive
# points; an essay review/workshop or a passing mention is not a hand-in.
RE_GRADED_ESSAY_SCHEDULE = re.compile(
    r"^(?:the\s+)?(?:open[- ]book\s*,?\s*)?(?:practice\s+)?essay"
    r"(?:\s+for\s+[^.!?;]{1,100}?)?\s+(?:is|will be)\s+(?:on|in)\s+"
    r"class\s*#?\s*\d{1,3}\s*(?:[=,:—-]\s*)?[1-9]\d*\s*(?:points?|pts?)\b", re.I)

RE_MOVED_CLASS_WORK = re.compile(
    r'\bthe\s+(?P<title>[^,.;!?]{3,80}?)\s+will\s+move\s+to\s+'
    r'(?:class|session|lesson)\s*(?P<n>\d{1,3})\b', re.I)


def class_stated(course_lookup: str, label: str, block_span, where: str, meetings):
    """A "Class N" heading dated by the weekdays it names: last week, this
    week or next."""
    weeks = _weekdays_by_week(label)
    found = []
    if weeks[0]:
        here = dates_mod.resolve_weekday_in_span(course_lookup, weeks[0], block_span,
                                                 label, where, meetings)
        if here is not None:
            found.append(here)
    if weeks[1] and block_span:
        after = (block_span[1] + timedelta(days=1), block_span[1] + timedelta(days=7))
        there = dates_mod.resolve_weekday_in_span(course_lookup, weeks[1], after,
                                                  label, where, meetings)
        if there is not None:
            found.append(there)
    if weeks[-1] and block_span:
        before = (block_span[0] - timedelta(days=7), block_span[0] - timedelta(days=1))
        earlier = dates_mod.resolve_weekday_in_span(course_lookup, weeks[-1], before,
                                                    label, where, meetings)
        if earlier is not None:
            found.append(earlier)
    if not found:
        return None
    if len(found) == 1:
        return found[0]
    # His period meets on one of them; two candidates means it is not certain.
    first = min(found, key=lambda r: r.when)
    return dates_mod.Resolution(first.when, first.note, first.extractor, "medium")


def day_heading(text: str, year_start: int | None):
    """Is this line a dated heading? -> (kind, value, label, rest) or None.

    kind "date" -> value is a date; kind "dayn" -> value is the day number.
    `label` is the heading as the teacher wrote it (it goes in the date_note,
    so the student can find the line on the page). `rest` is any content that
    followed the heading in the same paragraph.
    """
    line = _clean(text)
    if not line or RE_SEPARATOR.match(line):
        return None
    if re.fullmatch(r'Class\s+[1-9][0-9]{0,2}\s+Team\s+[1-9][0-9]{0,2}:\s*'
                    r'pages\s+[1-9][0-9]{0,3}[-–—][1-9][0-9]{0,3}'
                    r'(?:\s*\([0-9,]+\s+PSI[-–—][0-9,]+\s+PSI\))?', line, re.I):
        return None  # scheduled team ranges must not reset the current class
    if re.fullmatch(r'Class\s+\d+\s+presentations:\s+Chapters\s+\d+(?:-\d+)?'
                    r'(?:\s*&\s*Chapters\s+\d+(?:-\d+)?)?\.?', line, re.I):
        return None  # a team schedule entry, not a new posting-class heading
    # A line that states a deadline or a mark is work, never a section label.
    #
    # [MEASURED] 2026-09-02: "100 points. Due Friday, Sep. 25, 11:59 PM." and
    # "100 pts, due Sep 26" were promoted to headings — the two biggest
    # assignments in AI Frontiers' doc — and a heading is a label, so they
    # were deleted rather than shown. The date-ish lead is the same in both
    # cases ("Sep 25" reads exactly like a day heading); what separates them
    # is that a heading announces a day and this announces work.
    if RE_DUE_IN_LINE.search(line) or RE_MARKS_IN_LINE.search(line):
        return None
    stripped = line.lstrip("*•-–— \t")

    numbered = RE_DAY_N_LEAD.match(stripped)
    classed = None if numbered else RE_CLASS_N_LEAD.match(stripped)
    match = numbered or classed or RE_NAMED_DAY_LEAD.match(stripped)
    if match:
        # Offsets, carefully: the regexes ran against `stripped`, but the label
        # shown to the student has to come out of `line`. Getting this wrong
        # printed "Day 1 (Monday 8/24" with the bracket lopped off.
        lead = len(line) - len(stripped)
        tail = stripped[match.end():]
        spaces = len(tail) - len(tail.lstrip())
        after = tail.lstrip()
        paren = re.match(r"\(([^)]{0,60})\)", after)
        inside = paren.group(1) if paren else ""
        rest = after[paren.end():].strip() if paren else after
        # A heading has to be short OR self-terminate with its parenthetical.
        # Otherwise it is a paragraph that opens with the word "day".
        if not paren and len(line) > HEADING_CHARS:
            return None
        label_end = lead + match.end() + (spaces + paren.end() if paren else 0)
        label = line[:label_end].strip()
        when = _date_in(inside, year_start) or (
            _date_in(rest, year_start) if len(rest) < 40 else None)
        if when is not None:
            return "date", when, label, rest
        if numbered:
            return "dayn", int(match.group(1)), label, rest
        if classed:
            # The whole heading is the label: it carries the weekday names that
            # date it ("Class 10 : Tuesday for Periods 1 & 3 / Wednesday …").
            return "classn", int(match.group(1)), line, ""
        return None

    if len(line) > HEADING_CHARS:
        return None

    # [MEASURED] 2026-11-09: a dated Community section used a pipe before
    # its long caption; current sections also use a spaced hyphen.
    # The eight-word fallback ignored it, so the next
    # reminder inherited the preceding section's later date.
    delimiter = "|" if "|" in line else " - " if " - " in line else None
    if delimiter:
        dated, caption = line.split(delimiter, 1)
        dated = dated.strip()
        if caption.strip() and re.fullmatch(
                r"(?:Mon(?:day)?|Tue(?:sday)?|Wed(?:nesday)?|Thu(?:rsday)?|"
                r"Fri(?:day)?|Sat(?:urday)?|Sun(?:day)?)\.?\s*,?\s+"
                r"[A-Za-z]+\.?\s+\d{1,2}(?:st|nd|rd|th)?(?:,?\s+20\d{2})?",
                dated, re.I):
            when = _date_in(dated, year_start)
            if when is not None:
                return "date", when, line, ""
        return None  # embedded dates in work prose are not section labels

    # "Monday 9/8", "Mon, Sept 8", "9/8", "September 8" — a bare dated heading.
    when = _date_in(line, year_start)
    if when is not None and not RE_BLOCK_LEAD.match(line):
        # Guard against a sentence that merely contains a date.
        words = len(line.split())
        if words <= 8:
            return "date", when, line, ""
    return None


def _heading_label(text: str) -> str:
    """The part of a heading worth quoting back. A block heading is often a
    heading plus a paragraph of instructions to the class ("Please note: we
    will be meeting 5 different times…"); the date_note only needs the part
    that lets the student find the line again."""
    line = _clean(text)
    match = RE_DATE_TOKEN.search(line[:120])
    if match:
        return line[:match.end()].strip()
    return (line[:70] + "…") if len(line) > 70 else line


def block_heading(text: str, year_start: int | None):
    """A 'Week 3&4 … - 8/24' heading -> (start_date, label), or None.

    Only the START matters here. A page section is not bounded the way a table
    is: the teacher names the day the block began and then lists its days.
    """
    line = _clean(text)
    if not line or not RE_BLOCK_LEAD.match(line.lstrip("*•-– \t")):
        return None
    # A real block heading names its date up front; the rest of the paragraph is
    # often a note to the class ("We will be meeting 5 different times…"), so
    # only the opening is searched. Without that bound, a paragraph mentioning
    # "week" and quoting some other date later on would move the whole block.
    opening = line[:120]
    span = dates_mod.parse_range(opening, year_start)
    if span:
        return span[0], span[1], _heading_label(line)
    when = _date_in(opening, year_start)
    if when is not None:
        # Only a start was given, so the week it opens is the span. A block
        # heading names the week; five school days covers it either way.
        weeks = re.search(r'\bweeks?\s+(\d{1,2})\s*(?:&|and|[-–])\s*(\d{1,2})\b', opening, re.I)
        count = int(weeks.group(2)) - int(weeks.group(1)) + 1 if weeks else 1
        count = count if 1 <= count <= 4 else 1
        return when, when + timedelta(days=7 * count - 1), _heading_label(line)
    return None


def _leaf_blocks(body, prefixes=None, year_start=None):
    """Block elements in document order, innermost only, so nesting does not
    read the same sentence twice. Table cells are skipped: a page with a real
    table is handed to items.extract_doc, which understands columns."""
    nodes = []
    for node in body.find_all(BLOCK_TAGS):
        if node.find_parent("table") is not None:
            continue
        if node.find(BLOCK_TAGS) is not None:
            continue          # a container; its children are the leaves
        if node.find('br') is None:
            nodes.append(node)
            continue
        # [MEASURED] 2026-10-31, Spanish: "2B Vocab Intro<br>**Tarea:
        # 2B-1, 2B-2" was read as one lesson-plan line and lost its homework.
        # Split only where the next visual line starts work or a heading;
        # explanatory asides stay attached to the work they explain.
        from bs4 import BeautifulSoup
        groups = []
        rules = prefixes if prefixes is not None else compile_prefixes()
        for fragment in re.split(r'<br\b[^>]*>', node.decode_contents(), flags=re.I):
            part = BeautifulSoup('<div>' + fragment + '</div>', 'lxml').div
            text = _clean(part.get_text(' ', strip=True))
            role, _ = classify_line(text, rules, links_mod.extract_links(part, ''))
            boundary = role or day_heading(text, year_start) or block_heading(text, year_start)
            # [MEASURED] 2026-11-04: a quiz followed by "Intro to [project]"
            # across a BR acquired the project's link/title and lost its quiz
            # identity. A new lesson introduction is not quiz instructions.
            if (groups and re.match(r'^Intro\s+to\b', text, re.I)
                    and names_an_assessment(_clean(groups[-1].get_text(' ', strip=True)))):
                boundary = True
            if groups and not boundary:
                groups[-1].append(BeautifulSoup('<br>', 'lxml').br)
                for child in list(part.contents):
                    groups[-1].append(child)
            else:
                groups.append(part)
        nodes.extend(groups)
    return nodes


# Which assessment word was named decides the category, so a quiz is not
# scored as a test. The scorer's own keyword pass reads titles, and a page line
# is long enough that an incidental word later in it would win otherwise.
TEST_WORDS = re.compile(r"^(tests?|exams?|midterms?|finals?|assessments?|examen)$", re.I)


def _lockdown_essay_change(text: str) -> str | None:
    subject = r'\b(?:the|this)\s+(?:(?:lockdown|practice)\s+)?essay\s+(?:is|has been)\s+'
    if re.search(subject + r'cancel[le]+d\b', text, re.I):
        return 'cancelled'
    if re.search(subject + r'(?:postponed|moved|not happening today)\b', text, re.I):
        return 'deferred'
    return None


def _today_lockdown_essay(text: str) -> bool:
    """A graded essay happening today, with marks in its opening sentence."""
    return bool(re.match(
        r'^Today is (?:the )?lockdown essay over [^.!?;=]{1,100}\S\s*'
        r'=\s*[1-9]\d{0,2}\s+points\b', text, re.I)
        and not RE_NOT_GRADED.search(text)
        and _lockdown_essay_change(text) != 'cancelled')


def _today_graded_practice_essay(text: str) -> bool:
    """A named book's scored practice essay, not an essay review."""
    return bool(re.match(
        r'^Today is (?:the )?(?!practice essay\b|the practice essay\b)[^.!?;=]{3,80}? practice essay on '
        r'[^.!?;=]{2,60}\S\s*=\s*[1-9]\d{0,2}\s+points\b', text, re.I)
        and not re.search(r'\b(?:optional|not|example|may|could|might)\b',
                          re.split(r'[.!?]', text, maxsplit=1)[0], re.I)
        and not RE_NOT_GRADED.search(text)
        and _lockdown_essay_change(text) != 'cancelled')


def names_an_assessment(text: str) -> bool:
    """Does this line say that IT is a test or a quiz?"""
    bare = (text or "").lstrip("*•-–— \t")
    if RE_SUBORDINATE_OPENER.match(bare) or RE_NOT_GRADED.search(bare):
        return False
    # A complete optional-contact notice about existing assessments does
    # not schedule a new test. Fullmatch protects appended catch-up work
    # or a separate newly scheduled assessment in the same paragraph.
    if re.fullmatch(
            r"All (?:previous|past) (?:quizzes and exams|exams and quizzes) are open,\s*"
            r"email me if you['’]d like to meet about (?:any )?(?:confusion|questions)[.!]?",
            bare.strip(), re.I):
        return False
    if _today_lockdown_essay(bare) or _today_graded_practice_essay(bare):
        return True
    if (re.match(r"^(?:this|that|these|those)\s+(?:tests?|quizzes?|exams?)\b", bare, re.I)
            or re.match(r"^(?:test|quiz|exam)\s+(?:review|corrections?|debrief|discussion)\b", bare, re.I)
            or re.match(r"^(?:study|prepare|review)\s+for\b", bare, re.I)):
        return False
    return (RE_ASSESSMENT_LEAD.match(bare) or RE_ASSESSMENT_SCHEDULED.match(bare)
            or RE_SCORED_NRI_TEST.match(bare)) is not None


def assessment_category(text: str) -> str:
    bare = (text or "").lstrip("*•-–— \t")
    if _today_lockdown_essay(bare) or _today_graded_practice_essay(bare):
        return 'essay'
    if not names_an_assessment(bare):
        return "neutral"
    if RE_SCORED_NRI_TEST.match(bare):
        return "test"
    match = RE_ASSESSMENT_LEAD.match(bare) or RE_ASSESSMENT_SCHEDULED.match(bare)
    return "test" if TEST_WORDS.match(match.group(1)) else "quiz"


def _kept_title(pattern, line: str) -> str:
    """Strip a prefix — unless stripping leaves a fragment.

    A LABEL prefix names the column and the information is whatever follows
    it: "Homework: large language models" is about large language models, and
    "HW: #27-49 (odds)" about the problems. A SENTENCE that happens to open
    with "Due" is itself the information.

    [MEASURED] 2026-09-02: "Due by the end of class" reached the board as "by
    the end of class", which names neither the work nor the day. The
    discriminator is the delimiter a label carries and a sentence does not,
    plus the case of what is left — a remainder starting mid-sentence in
    lower case is the tail of a sentence, not a title.
    """
    from sillybus.docs.items import strip_prefix

    match = pattern.match(line)
    stripped = strip_prefix(pattern, line)
    if not match or not stripped:
        return stripped
    if match.group(0).rstrip().endswith((":", "-", "–", "—")):
        return stripped
    return line if stripped[:1].islower() else stripped


def _timed_flint_exercise(text: str):
    return re.fullmatch(
        r'For [1-9]\d{0,2} minutes on a timer, work on the '
        r'(?P<name>Flint exercise about Arguable Claims vs\. Summaries) '
        r'using your class link below[.!]?', text, re.I)


def _scored_flint_paragraph(text: str):
    today = re.fullmatch(
        r"(?P<name>[A-Za-z][A-Za-z'’ &-]{1,60} open book Flint paragraph over pages "
        r"(?P<first>[1-9][0-9]{0,3})[-–—](?P<last>[1-9][0-9]{0,3})) "
        r'is (?P<today>today)(?P<tail>)\s*=\s*(?P<points>[1-9][0-9]{0,2}) points[.!]?',
        text, re.I)
    if (today and not re.match(r'^(?:Study for|Review|Optional|Example|If)\b', text, re.I)
            and int(today.group('first')) <= int(today.group('last'))):
        return today
    handin = re.fullmatch(
        r'(?P<tail>By the end of class today), complete the '
        r'(?P<name>practice paragraph writing test on Flint) '
        r'by the end of class today\s*=\s*(?P<points>[1-9][0-9]{0,2}) points\s*\.?',
        text, re.I)
    if handin:
        return handin
    after_exercise = re.fullmatch(
        r'After the Flint exercise above, complete the '
        r'(?P<name>NY Times Article [1-9]\d* paragraph) '
        r'(?P<tail>by the end of class today) using your class Flint link below = '
        r'(?P<points>[1-9]\d{0,2}) points[.!]?', text, re.I)
    if after_exercise:
        return after_exercise
    match = re.fullmatch(
        r'Using your book and Google notes, complete the (?:(?P<points>[1-9]\d{0,2})-point )?'
        r'(?P<name>Flint paragraph(?:\s+[1-9]\d*)?) in [1-9]\d{0,2} minutes or less '
        r'using your class link below:(?P<tail>.*)', text, re.I)
    if not match:
        return None
    tail = match.group('tail').strip()
    if tail and re.search(r'\b(?:complete|submit|separate|worksheet|lab|cancel\w*|postpon\w*|'
                          r'not|no longer|but|however)\b|:(?!\d{2}\b)', tail, re.I):
        return None
    if tail and not (re.match(r'^Due\b', tail, re.I) and (
            RE_LINE_DEADLINE.search(tail) or RE_WEEKDAY_DEADLINE.search(tail)
            or RE_RELATIVE_DEADLINE.search(tail) or RE_DUE_NEXT_CLASS.search(tail)
            or RE_DUE_CLASS_N.search(tail))):
        return None
    return match


def _named_video_notes(text: str) -> str | None:
    """A named partner artifact with an imperative, not a video reminder."""
    if re.search(r'\b(?:if|optional|example|may|could|might|not|no need|unless|'
                 r'submit|present|presentation|required|hand in|turn in|upload|post)\b', text, re.I):
        return None
    match = re.search(
        r'\bWith a partner in a Google doc titled ([^,.!?;]{3,80}),\s*'
        r'capture at least [1-9]\d* interesting facts from the video\b', text, re.I)
    return match.group(1).strip() if match else None


def classify_line(text: str, prefixes: dict, links: list) -> tuple[str | None, str]:
    """(role, cleaned text). role: homework | due | assessment | action | None."""
    line = _clean(text)
    if not line or len(line) < 3 or RE_SEPARATOR.match(line):
        return None, ""
    if dates_mod.SKIP_TEXT.match(line):
        return None, ""
    # An annotation ("Reminder:", "Please note:") is peeled off first and what
    # is left is judged on its own merits. No extra guard is needed for a note
    # that wraps nothing: "Please note: I will be out on Thursday" matches no
    # rule once the prefix is gone, which is the right answer.
    annotation = prefixes.get("annotation")
    if annotation and annotation.match(line):
        from sillybus.docs.items import strip_prefix as _strip

        stripped_line = RE_STRANDED_COPULA.sub("", _strip(annotation, line))
        if len(stripped_line) >= 3:
            line = stripped_line
    from sillybus.docs.items import strip_prefix

    if RE_FOR_NEXT.match(line):
        return "homework", RE_FOR_NEXT.sub("", line).strip()
    if prefixes["homework"] and prefixes["homework"].match(line):
        return "homework", RE_STRANDED_COPULA.sub(
            "", _kept_title(prefixes["homework"], line))
    if prefixes["due"] and prefixes["due"].match(line):
        return "due", RE_STRANDED_COPULA.sub(
            "", _kept_title(prefixes["due"], line))
    if prefixes["skip"] and prefixes["skip"].match(line):
        return None, ""
    bare = line.lstrip("*•-–— \t")
    if re.fullmatch(r'ALL STUDENTS: After the Second Rotation, head back to your Team Rooms to fill out this survey \[link will be added\] regarding .{10,1200}', bare, re.I) and not links:
        return 'team_room_survey', 'Complete the team room survey'
    if re.fullmatch(r'Final Team Room Survey [–—-] \d{1,2}:\d{2}-\d{1,2}:\d{2}', bare, re.I) and not links:
        return None, ''
    if _weekly_duolingo(bare):
        return "homework", bare
    if RE_CANVAS_CLASS_DISCUSSION.search(bare):
        return 'class_discussion', 'Discussion Board'
    paragraph = _scored_flint_paragraph(bare)
    if paragraph:
        return 'scored_paragraph', paragraph.group('name')
    timed_exercise = _timed_flint_exercise(bare)
    if timed_exercise:
        return 'timed_class_exercise', timed_exercise.group('name')
    if (re.match(r'^Final\s+workshop\s+day\b', bare, re.I) and not links
            and not RE_MARKS_IN_LINE.search(bare)
            and not RE_ACTION_IN_LINE.search(bare)
            and not any(pattern.search(bare) for pattern in (
                RE_LINE_DEADLINE, RE_WEEKDAY_DEADLINE, RE_DUE_DAY_N,
                RE_DUE_CLASS_N, RE_DUE_NEXT_CLASS, RE_RELATIVE_DEADLINE))
            and not re.search(r'\b(?:due|deadline|prepare|study|must|required|present|presents|'
                              r'quiz|exam|test|assessment|grade|graded|submission)\b', bare, re.I)):
        # "Final" here describes the last workshop, not a final exam. Keep
        # explicit homework/points/actions on the existing paths above/below.
        return None, ''
    if re.match(r"^(?:s\s*tudy|prepare|review)\s+for\b", bare, re.I) and re.search(r"\b(?:quiz|test|exam)\b", bare, re.I):
        return "homework", bare
    if RE_ANNOTATED_BOOK_CHECK.fullmatch(bare) or RE_PRINTED_QUOTES.match(bare):
        return "due", bare
    if names_an_assessment(bare) and not RE_NOT_GRADED.search(line):
        return "assessment", bare
    if RE_GRADED_ESSAY_SCHEDULE.match(bare):
        return "due", bare
    # A prose doc marks its homework by stating the deadline inside the
    # sentence rather than with a prefix, so a due phrase anywhere in the line
    # counts — but only under a dated heading, which the caller guarantees.
    if RE_DUE_IN_LINE.search(bare) or RE_DUE_NEXT_CLASS.search(bare):
        return "due", bare
    # "… the pages 1-41 assignment due Class 22 …" is work with a deadline,
    # named by class number instead of by date (see RE_DUE_CLASS_N).
    if RE_DUE_CLASS_N.search(bare):
        return "due", bare
    if RE_DUE_DAY_N.search(bare) and (RE_ACTION_LEAD.match(bare) or re.match(r"^due\b", bare, re.I)):
        return "due", bare
    notes = _named_video_notes(bare)
    if notes and not re.search(r'\b(?:due|deadline|by|before|until|today|tonight|tomorrow)\b', bare, re.I):
        return "named_notes", notes
    if links and RE_ACTION_LEAD.match(bare):
        return "action", bare
    return None, ""


def stated_deadline(text: str, year_start: int | None):
    """(date, quoted phrase) when the line names its own deadline, else None.
    The FIRST one: "By September 18 … By October 14" — the nearer date is the
    one that can be missed next."""
    match = RE_LINE_DEADLINE.search(text or "")
    if not match:
        return None
    when = _date_in(match.group("date"), year_start)
    if when is None:
        return None
    return when, _clean(match.group(0))


RE_DEADLINE_CLOCK = re.compile(
    r"(?<![\d:])(?P<h>1[0-2]|0?[1-9])(?::(?P<m>[0-5]\d))?\s*"
    r"(?P<ap>[ap])\.?\s*m\.?(?!\w)|\b(?P<word>noon|midnight)\b", re.I)


def deadline_clock(text: str, phrase: str):
    """An explicit clock IN or immediately AFTER the selected deadline.

    Office hours and other clocks elsewhere in an assignment are not its
    deadline. No guessing bare hours or carrying a time across a sentence.
    """
    raw, phrase = _clean(text), _clean(phrase)
    start = raw.lower().find(phrase.lower()) if phrase else -1
    if start < 0:
        return None
    hit = RE_DEADLINE_CLOCK.search(phrase)
    if hit is None:
        tail = raw[start + len(phrase):]
        # The weekday matcher omits an abbreviation's final period. Only
        # consume that dot before an immediate clock preposition/symbol;
        # never search into another sentence for an unrelated time.
        if (re.search(r"\b(?:mon|tue|tues|wed|thu|thur|thurs|fri|sat|sun)$", phrase, re.I)
                and re.match(r"^\.\s*(?:@|at\b|by\b|before\b)", tail, re.I)):
            tail = tail[1:]
        # A teacher's "Oct. 8, at 8 AM" has punctuation AND a preposition.
        # Consume them separately without searching past unrelated prose.
        lead = re.match(r"^\s*,?\s*(?:(?:on|in)\s+(?:Canvas|Google\s+Classroom)(?:\s*,\s*|\s+))?"
                        r"(?:(?:@|at|by|before)\s*)?", tail, re.I)
        hit = RE_DEADLINE_CLOCK.match(tail, lead.end())
    if hit is None:
        return None
    if hit.group('word'):
        # "by midnight" on a named day means the end of that day. Keep that
        # convention visible rather than silently moving the calendar date.
        return time(12) if hit.group('word').lower() == 'noon' else time(23, 59)
    hour = int(hit.group('h')) % 12 + (12 if hit.group('ap').lower() == 'p' else 0)
    return time(hour, int(hit.group('m') or 0))


def deadline_moment(day, raw, phrase, meetings, course_lookup, note):
    """Use the stated clock before a timetable default; explain the clock."""
    clock = deadline_clock(raw, phrase)
    if clock is not None:
        moment = datetime.combine(day, clock, tzinfo=timezones.zone())
        label = ('end of the stated day (23:59)'
                 if clock == time(23, 59) and 'midnight' in raw.lower()
                 else clock.strftime('%H:%M'))
        return moment, f'{note}; deadline time {label} from the line itself'
    stamp = meetings.time_on(course_lookup, day)
    tail = (raw or '').partition(phrase or '')[2] if phrase else ''
    before_upload = re.search(r'\bupload\b[^.!?]{0,160}\bPRIOR to coming to class\b', raw or '', re.I)
    if stamp is None and (before_upload or re.match(
            r'\s*(?:@|at)\s+(?:the\s+)?start\b', tail, re.I)):
        note += '; class-start clock unavailable without timetable'
    elif stamp is not None and before_upload:
        note += f'; upload before class; timetable class start {stamp:%H:%M}, clock inferred'
    if stamp is None:
        note += '; time not stated; fallback 23:59, clock inferred'
    elif not before_upload:
        note += f'; timetable class start {stamp:%H:%M}, clock inferred'
    return (stamp if stamp else datetime.combine(
        day, time(23, 59), tzinfo=timezones.zone())), note


# Words that carry no work on their own. A line made only of these plus a
# deadline is an instruction ABOUT the other lines, not a task of its own.
DEADLINE_FILLER = {
    "these", "this", "that", "those", "all", "both", "them", "they", "it",
    "should", "must", "need", "needs", "be", "is", "are", "was", "were",
    "have", "has", "do", "does", "done", "complete", "completed", "completing",
    "finish", "finished", "finishing", "turn", "turned", "hand", "handed",
    "in", "and", "or", "the", "a", "an", "to", "for", "by", "on", "at", "of", "up",
    "please", "above", "below", "work", "assignments", "assignment", "items",
    "everything", "anything", "ready", "class", "tonight", "tomorrow", "due",
}


def deadline_only_line(text: str, year_start: int | None):
    """(date, phrase) when a line states a deadline and nothing else.

    [MEASURED] 2026-09-03. AP Chemistry writes a "For tonight" cell as a list
    and closes it with "These should be done by August 11th." — the deadline
    belongs to the list above it, not to that sentence, and the sentence is
    not homework.

    The test is what survives when the deadline phrase is removed: "These
    should be done" is pronouns and a verb, while "Work on SARA (25% due by
    10/8)" still names SARA and stays a task with a deadline of its own.
    """
    own = stated_deadline(text, year_start)
    if own is None:
        return None
    when, phrase = own
    rest = _clean((text or "").replace(phrase, " "))
    rest = RE_DEADLINE_CLOCK.sub('', rest)
    for token in re.findall(r"[a-z0-9]+", rest.lower()):
        if token.isdigit():
            continue
        if token not in DEADLINE_FILLER:
            return None
    return when, phrase


def _resolution(kind, value, label, course_lookup, meetings, where,
                days_written: int) -> dates_mod.Resolution:
    """Turn a heading into a dated Resolution, against the real timetable."""
    if kind == "dayn":
        return dates_mod.Resolution(
            None, dates_mod.NOTES["page_unresolved"].format(
                where=where, heading=dates_mod.quote_label(label)),
            "unresolved", "low")
    when = value
    weekday = _weekday_in(label)
    stated = f"{when:%a %b %d}"
    if weekday is not None and when.weekday() != weekday:
        # The weekday and the number disagree. The weekday is the reliable half
        # (spec §6.4), so snap to the nearest real meeting on that weekday.
        nearby = [d for d in meetings.dates(course_lookup)
                  if abs((d - when).days) <= 4 and d.weekday() == weekday]
        if nearby:
            chosen = min(nearby, key=lambda d: abs((d - when).days))
            return dates_mod.Resolution(
                chosen, dates_mod.NOTES["page_weekday_snapped"].format(
                    where=where, heading=dates_mod.quote_label(label),
                    claimed=f"{when:%b %d}",
                    actual_weekday=dates_mod.WEEKDAY_NAMES[when.weekday()],
                    chosen=f"{chosen:%a %b %d}"),
                "weekday_snapped", "medium", ["weekday_disagreed"])
        # [MEASURED] 2026-11-08: no timetable must not turn contradictory
        # weekday/date claims into a high-confidence absolute date.
        return dates_mod.Resolution(
            when, f"{where} says '{_clean(label)}'; numeric date {when.isoformat()} "
            f"is {dates_mod.WEEKDAY_NAMES[when.weekday()]}; source weekday disagrees. "
            'No matching timetable meeting resolves this conflict; literal date retained '
            'as an unresolved candidate.', 'absolute', 'low', ['source_weekday_conflict'])
    if not meetings.available or not meetings.dates(course_lookup) \
            or meetings.meeting_on(course_lookup, when):
        return dates_mod.Resolution(
            when, dates_mod.NOTES["page_stated"].format(
                stated=stated, where=where,
                heading=dates_mod.quote_label(label)), "absolute", "high")
    return dates_mod.Resolution(
        when, dates_mod.NOTES["page_stated_not_class"].format(
            stated=stated, where=where, heading=dates_mod.quote_label(label)),
        "absolute", "medium", ["not_a_class_day"])


# Link texts that name nothing. A teacher writes "click here" as often as the
# assignment's name, and a row called "here" is worse than a row called by its
# sentence. Matched WHOLE, so "Click here for Scientific Method Worksheet" — a
# real title in Honors Biology — is not caught by "click here".
GENERIC_LINK_TEXT = {
    "here", "click here", "link", "this", "this link", "that", "canvas",
    "assignment", "assignments", "the assignment", "form", "the form",
    "submission form", "board", "slides", "doc", "document", "google doc",
    "google docs", "read", "watch", "video", "page", "website", "site",
    "more", "learn more", "info", "details", "start here", "find it here",
    "find your task here", "find today's task here", "open", "download",
}

# Words a sentence ends on when it is handing off to the link that follows —
# "Open your [X]", "build toward the [X]", "Then do: [X]". A line ending on
# one of these has not named anything yet; the link does that.
HANDOFF_WORDS = {
    "the", "a", "an", "your", "my", "our", "this", "these", "those", "that",
    "to", "for", "on", "in", "into", "at", "from", "with", "toward", "towards",
    "start", "open", "see", "use", "using", "via", "is", "are", "and",
}

# How much longer than the link a line must be before the link is treated as
# the work's NAME rather than the line being about something else.
LINK_TITLE_SLACK = 12


def _hands_off_to(before: str, after: str) -> bool:
    """Does the sentence before a link hand the naming over to it?

    Two shapes, both from real lines:

      * it dangles — "Bring your numbers. Open your [Market Research with
        Perplexity] before class starts", "Then do: [CTN Practice: Fix a Weak
        Prompt]";
      * it has finished a sentence and the link is followed by marks or a
        deadline — "…[High School Side Hustle]. [Market Research with
        Perplexity], 20 points, now due TONIGHT by 11:59 pm".

    Neither is true of "Complete (Calendar and Dates Practice) [WayGround
    Assignment]" — Spanish 1's homepage, where the sentence names the work and
    the link is only the tool it lives in. Taking the link's words there turned
    a named quiz into "WayGround Assignment" and, because the category is read
    from the title, turned a QUIZ into untyped work. That is why this predicate
    exists instead of "a link wins".
    """
    before = (before or "").strip()
    after = (after or "").strip()
    if not before:
        return False                    # the line IS the link; nothing to do
    if before.endswith((":", "—", "–", "-")):
        return True
    words = re.findall(r"[A-Za-z']+", before)
    if words and words[-1].lower() in HANDOFF_WORDS:
        return True
    if before.endswith((".", "!", "?")):
        return bool(RE_MARKS_IN_LINE.search(after) or RE_DUE_IN_LINE.search(after))
    return False


def _link_title(line: str, links: list) -> str:
    """The work's name, when a line is a sentence wrapped around a link.

    [MEASURED] 2026-09-03. In AI Frontiers every assignment name is a link
    inside a sentence: "Then do: [CTN Practice: Fix a Weak Prompt] — 10
    points, due before class Wednesday". The sentence states the deadline and
    the link names the work, so the row wants the link's words and the
    sentence's date.

    The last qualifying link wins, not the first: these sentences open with
    the standing project and close with the thing that is actually due.
    """
    text = _clean(line)
    best = ""
    for link in links or []:
        name = _clean(getattr(link, "text", "") or "")
        if not 8 <= len(name) <= 70:
            continue
        if len(re.findall(r"[A-Za-z]+", name)) < 2:
            continue
        if name.lower().strip(" .,:;!?") in GENERIC_LINK_TEXT:
            continue
        if name not in text or len(text) < len(name) + LINK_TITLE_SLACK:
            continue
        before, _, after = text.partition(name)
        if _hands_off_to(before, after):
            best = name
    return best


def _names_the_work(line: str, year_start: int | None) -> str:
    """The line above a detail line, when it is a bare NAME for the work.

    "Side Hustle Proposal" and "Second Pass: Revise the Mark" classify as
    nothing at all — no verb, no prefix, no date — which is correct for a
    line on its own and wrong when the next line is "100 points. Due Friday,
    Sep. 25". A name is short, states no deadline of its own, and is not
    itself a detail line. Returns "" when the line is not one.
    """
    text = (line or "").strip()
    named_notes = re.match(r"^(?:TB|Textbook)\s+notes?\b", text, re.I)
    if not text or len(text) > (180 if named_notes else 60) or RE_POINTS_LEAD.match(text):
        return ""
    if stated_deadline(text, year_start) is not None:
        return ""
    words = re.findall(r"[A-Za-z]+", text)
    if not 1 <= len(words) <= (25 if named_notes else 9):
        return ""
    return text.rstrip(" .:;,-–—")


def _essay_preparation_targets(text: str, year_start):
    """An explicitly explained list of page references supports named essays.

    [MEASURED] English Class 31 tells students to make the list after another
    test. It states no separate deadline and explains which essays it helps.
    Keep that instruction on those essays without scheduling an extra task.
    """
    if (not re.match(r"^after\b", text, re.I)
            or not re.search(r"\b(?:create|make|compile)\s+(?:a\s+)?list\b", text, re.I)
            or not re.search(r"\bpage\s+numbers\b", text, re.I)
            or not re.search(r"\bthis\s+will\s+help\b", text, re.I)
            or stated_deadline(text, year_start) is not None
            or RE_DUE_IN_LINE.search(text)
            or RE_DUE_CLASS_N.search(text)):
        return set()
    return {part.lower() for part in re.findall(
        r"\b(?:practice|lockdown\s+browser)\s+essay\b", text, re.I)}


def _shared_essay_support(text, year_start, essays):
    """Keep adjacent pair's stated criteria/review; never create a deadline.

    Nov 4 source puts the rubric and prior-evaluation review AFTER the practice
    and lockdown essays. Require both adjacent named targets, clear on other
    work/headings, and reject review for an explicitly different book.
    """
    if (len(essays) != 2
            or not any("practice essay" in i.title.lower() for i in essays)
            or not any("lockdown browser essay" in i.title.lower() for i in essays)
            or stated_deadline(text, year_start) is not None
            or RE_DUE_IN_LINE.search(text) or RE_DUE_CLASS_N.search(text)):
        return False
    rubric = (re.match(r"^the essay will focus on\b", text, re.I)
              and re.search(r"\bthe essay must persuade\b", text, re.I))
    review = (re.match(r"^be sure to review\b", text, re.I)
              and re.search(r"\bessay evaluation\b", text, re.I)
              and re.search(r"\bthe goal is\b.*\bmistakes\b", text, re.I))
    if not (rubric or review):
        return False
    target = re.search(r"\bon the (.{2,80}?) essay\b", text, re.I)
    books = [re.search(r"\bessay(?:\s+test)?\s+for\s+(.+?)\s+(?:will be|is)\b",
                       i.raw_cell or i.title, re.I) for i in essays]
    books = {_normalised(m.group(1)) for m in books if m}
    return bool(len(books) == 1 and (not target or _normalised(target.group(1)) in books))


def _daily_discussion(parsed, index, source_url, year_start):
    """Daily exercise + discussion link + nearby explicit posting action.

    A term-long board date does not date each daily post. Do not borrow another
    assignment's instructions, a later meeting's text, or an ordinary resource.
    """
    _, _, text, node = parsed[index]
    name = re.match(r"^Daily Warm Up:\s*(.{3,100}?)(?:,\s*on the\b|$)", text, re.I)
    generic = re.match(r'^Daily Warm Up on the Warm Up Board\s*[.!](?:\s|$)', text, re.I)
    if ((not name and not generic) or stated_deadline(text, year_start) is not None
            or RE_DUE_IN_LINE.search(text) or RE_DUE_CLASS_N.search(text)):
        return None
    links = links_mod.extract_links(node, source_url)
    board = [link for link in links if re.search(
        r"/courses/\d+/discussion_topics/\d+(?:[/?#]|$)", link.url)]
    if not board or (generic and not any(link.text.strip() == 'Warm Up Board' for link in board)):
        return None
    instructions = [text]
    for next_kind, _, following, next_node in parsed[index + 1:index + 4]:
        if next_kind in ("day", "block"):
            break
        next_links = links_mod.extract_links(next_node, source_url)
        if any(re.search(r"/courses/\d+/assignments/\d+", link.url) for link in next_links):
            break
        if stated_deadline(following, year_start) or RE_DUE_CLASS_N.search(following):
            break
        if re.search(r"not turned in yet.*finish that first", following, re.I):
            continue
        instructions.append(following)
        if generic and re.search(r'\b(?:post|reply)\b', following, re.I):
            break  # one explicit posting paragraph; do not borrow later activities
    # One source exercise's final reply follows resource references to the
    # student's existing game/story submissions. This is not permission to
    # collect arbitrary later assignment links: require its complete sequence.
    if re.search(r"\bBuild: one path of your story.*inside your game\b",
                 " ".join(instructions), re.I):
        following_lines = []
        for entry in parsed[index + 1:index + 11]:
            if entry[0] in ("day", "block"):
                break
            following_lines.append(entry)
        for offset, entry in enumerate(following_lines):
            if not re.match(r"^Your game:", entry[2], re.I):
                continue
            chain = following_lines[offset:offset + 4]
            if len(chain) == 4 and chain[3][2].strip() == "Warm Up Board":
                chain = following_lines[offset:offset + 5]
            if len(chain) not in (4, 5):
                break
            texts = [part[2] for part in chain]
            if (not re.search(r"download your file from your submission", texts[0], re.I)
                    or not re.match(r"^Your story:", texts[1], re.I)
                    or not re.match(r"^Beat the guess:", texts[2], re.I)
                    or not re.match(r"^Before you leave: reply under your own post\b", texts[-1], re.I)
                    or not re.search(r"\.html\b", texts[-1], re.I)
                    or any(stated_deadline(t, year_start) or RE_DUE_CLASS_N.search(t)
                           or RE_DUE_IN_LINE.search(t) or RE_MARKS_IN_LINE.search(t) for t in texts)):
                break
            chain_links = [links_mod.extract_links(part[3], source_url) for part in chain]
            if (not all(any(re.search(r"/courses/\d+/assignments/\d+", link.url)
                            for link in group) for group in chain_links[:2])
                    or not any(link.url.split("#")[0] == board[0].url.split("#")[0]
                               for group in chain_links[2:-1] for link in group)):
                break
            instructions.extend(t for t in texts if t not in instructions)
            board.extend(link for group in chain_links[:2] for link in group
                         if link.url not in {l.url for l in board})
            break
    raw = " ".join(instructions)
    if not re.search(r"\b(?:post|reply)\b", raw, re.I):
        return None
    if generic and re.search(r"\b(?:no|not|do not|don['’]t)\s+(?:post|reply)\b", raw, re.I):
        return None
    return name.group(1).strip(" .,") if name else '', raw, board


def _printed_pogil(parsed, index, source_url):
    """A linked POGIL + PDF-editor instruction + printed weekday hand-in.

    Source Oct 23: formatting guidance separates the named worksheet from its
    deadline. Keep this exact bounded sequence; never borrow a later task/day.
    """
    chain = parsed[index:index + 3]
    if len(chain) != 3 or any(part[0] != "line" for part in chain):
        return None
    texts = [part[2] for part in chain]
    if not re.fullmatch(r"Please use pdf editors[.!]?", texts[1], re.I):
        return None
    deadline = re.fullmatch(
        r"Due printed (Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday) in class[.!]?",
        texts[2], re.I)
    links = links_mod.extract_links(chain[0][3], source_url)
    named = next((link for link in links if re.search(r"\bPOGIL\b", link.text)
                  and texts[0].lower().startswith(link.text.lower())), None)
    if not deadline or not named:
        return None
    return named.text, " ".join(texts), links, deadline.group(1).lower()


def _practice_launch_guidance(parsed, items, source_url):
    """Enrich one exact book/Class practice forecast from its current launch."""
    number = None
    guides = {}
    launch = re.compile(
        r'For the (?P<book>[^.!?;]{3,60}?) practice essay today, the '
        r'[^.!?;]{2,60}? term and literary term will be assigned in class, '
        r'so do not try to begin prior to class\s*\.\s*'
        r'The open book,\s*practice essay\s*=\s*(?P<points>[1-9][0-9]{0,2}) '
        r'points and click your class Flint link to begin:', re.I)
    for index, (kind, value, text, node) in enumerate(parsed):
        if kind == 'block':
            number = None
        elif kind == 'day':
            number = value[1] if value[0] == 'classn' else None
        elif kind == 'line' and number is not None and index + 1 < len(parsed):
            match = launch.fullmatch(text)
            following_entry = next((entry for entry in parsed[index + 1:index + 4]
                                    if entry[0] != 'line' or entry[2].strip()), None)
            if following_entry is None:
                continue
            next_kind, _, following, next_node = following_entry
            if (not match or next_kind != 'line' or not re.fullmatch(
                    r'(?:Period\s+[1-7]\s*)+', following, re.I)):
                continue
            links = links_mod.extract_links(next_node, source_url)
            if not links or not all(
                    re.fullmatch(r'Period\s+[1-7]', link.text, re.I)
                    and re.fullmatch(r'https://app\.flintk12\.com/activities/[A-Za-z0-9_-]+/?', link.url)
                    for link in links):
                continue
            key = (number, _normalised(match['book']))
            identity = (text, tuple((link.text, link.url) for link in links))
            guides.setdefault(key, {})[identity] = (match['book'], int(match['points']), links, text)
    for (number, _), variants in guides.items():
        if len(variants) != 1:
            continue
        book, points, links, text = next(iter(variants.values()))
        forecast = re.compile(
            r'The open book,\s*practice(?: Flint)? essay for ' + re.escape(book)
            + r' will be in Class ' + str(number) + r'\s*=\s*([1-9][0-9]{0,2}) points[.!]?', re.I)
        candidates = [(item, forecast.fullmatch(_clean(item.raw_cell))) for item in items]
        candidates = [(item, match) for item, match in candidates if match]
        if len(candidates) != 1:
            continue
        item, match = candidates[0]
        if int(match[1]) != points or item.points not in (None, points):
            continue
        # [MEASURED] 2026-11-08: this launch lost its no-early-start rule,
        # score and available period links behind an older Class forecast.
        if text not in item.detail:
            item.detail += '\nCurrent class launch (same practice essay): ' + text
        item.points = points
        seen = {link.url for link in item.links}
        item.links.extend(link for link in links if link.url not in seen)
        if 'class_practice_launch_guidance' not in item.flags:
            item.flags.append('class_practice_launch_guidance')


def _referenced_project_guidance(parsed, items):
    """An explicit Week/Day reference may retain that named project's rubric.

    Never use proximity across sections: require the exact section, distinctive
    quoted project identity, and one unambiguous numbered instruction block.
    """
    week = day = None
    guides = []
    for kind, value, text, node in parsed:
        if kind == "block":
            match = re.search(r"\bWeek\s+(\d+)\b", text, re.I)
            week, day = (int(match.group(1)) if match else None), None
        elif kind == "day":
            day = value[1] if value[0] == "dayn" else None
        elif week is not None and day is not None:
            name = re.match(r"^\W*Intro to ['‘“](.{4,80}?) Project['’”]", text, re.I)
            if (name and re.search(r"\btest grade\b", text, re.I)
                    and re.findall(r"\b([1-4])\.\)", text) == ["1", "2", "3", "4"]
                    and re.search(r"\b(?:expected|at least)\b", text, re.I)):
                guides.append((week, day, name.group(1), text))
    for item in items:
        reference = re.search(r"\bSee day (\d+),?\s*Week (\d+) for instructions below\b",
                              item.raw_cell or "", re.I)
        if not reference:
            continue
        candidates = {text for week, day, name, text in guides
                      if (week, day) == (int(reference.group(2)), int(reference.group(1)))
                      and re.search(r"(?<!\w)" + re.escape(name) + r"(?!\w)", item.title, re.I)
                      and re.findall(r"\d+", name) == re.findall(
                          r"\d+", re.split(r"\bdue\b", item.title, maxsplit=1, flags=re.I)[0])}
        if len(candidates) == 1:
            guidance = candidates.pop()
            item.detail = (item.detail or item.title) + "\nReferenced project instructions: " + guidance
            if "source_project_guidance" not in item.flags:
                item.flags.append("source_project_guidance")


def _finish_project_footer(parsed, index, links, source_url, year_start):
    """One linked project, its measured review instructions, and its deadline."""
    _, _, text, _ = parsed[index]
    assignments = [link for link in links
                   if re.search(r'/courses/\d+/assignments/\d+(?:[?#]|$)', link.url)]
    if len(assignments) != 1 or index + 2 >= len(parsed):
        return None
    assignment = assignments[0]
    if len(assignment.text.strip()) < 3:
        return None
    expected = f'Finish the {assignment.text}. Works Cited instructions are the last step.'
    if _normalised(text) != _normalised(expected):
        return None
    support_kind, _, support, support_node = parsed[index + 1]
    footer_kind, _, footer, footer_node = parsed[index + 2]
    if support_kind != 'line' or footer_kind != 'line':
        return None
    resources = links_mod.extract_links(support_node, source_url)
    if (len(resources) != 2 or any('/assignments/' in link.url for link in resources)
            or not re.search(r'\brubric\b', resources[1].text, re.I)
            or re.search(r'\brubric\b', resources[0].text, re.I)):
        return None
    expected_support = (f'Run it past {resources[0].text} for a required-elements check, '
                        f'then self-grade against the {resources[1].text}.')
    if _normalised(support) != _normalised(expected_support):
        return None
    own = stated_deadline(footer, year_start)
    if (not own or not re.match(r'^Due\b', footer, re.I)
            or not footer.lower().startswith(own[1].lower())
            or links_mod.extract_links(footer_node, source_url)):
        return None
    tail = footer[len(own[1]):]
    if not re.fullmatch(
            r'\s*,?\s*(?:(?:at|by|before|@)\s*)?(?:' + RE_DEADLINE_CLOCK.pattern + r')'
            r'\s*[.!]?\s*(?:Canvas closes then[.!]\s*)?'
            r'(?:Weekend is for polish[.!]?\s*)?', tail, re.I):
        return None
    return assignment.text, ' '.join((text, support, footer)), [*links, *resources], assignment.url


def _google_list_position(node):
    parent = node.find_parent('ol')
    if parent is None:
        return None
    for name in parent.get('class', []):
        match = re.fullmatch(r'lst-kix_(.+)-(\d+)', name)
        if match:
            return match.group(1), int(match.group(2))
    return None


def _below_subtasks(nodes, index, year_start):
    node = nodes[index]
    text = _clean(node.get_text(' ', strip=True))
    match = re.fullmatch(r'Next Class ([1-9]\d{0,2})\s*[-–:]\s*'
                         r'(.{3,120}? Chapters? \d+(?:-\d+)?) (?:is|are) due with all tasks below:', text, re.I)
    is_next = match is not None
    number = int(match.group(1)) if match else None
    name = match.group(2) if match else None
    if not match:
        reading = re.fullmatch(r'For Class ([1-9]\d{0,2}): Read (Chapters? \d+(?:-\d+)?) '
                               r'in ([^.!?;:]{3,120}) and:', text, re.I)
        if reading and not re.search(r'\bonly if\b|\((?:cancelled|canceled|postponed)\)',
                                     reading.group(3), re.I):
            number = int(reading.group(1))
            name = reading.group(3) + ' ' + reading.group(2)
    position = _google_list_position(node)
    if number is None or position is None:
        return None
    children = []
    consumed = []
    for following_index in range(index + 1, min(len(nodes), index + 49)):
        following = nodes[following_index]
        child = _clean(following.get_text(' ', strip=True))
        if not child:
            consumed.append(following_index)
            continue
        child_position = _google_list_position(following)
        if (child_position is None or child_position[0] != position[0]
                or child_position[1] <= position[1]):
            break
        # A later numbered lesson starts new context even when Docs reuses
        # the same indented list for teacher directions.
        later_class = re.match(r'(?:Also\s+)?In Class ([1-9]\d{0,2})\b', child, re.I)
        if later_class and (int(later_class.group(1)) != number or re.search(
                r',\s+(?:the teacher|instructor)\s+will present\b', child, re.I)):
            break
        if (day_heading(child, year_start) or block_heading(child, year_start)
                or RE_MARKS_IN_LINE.search(child)
                or any(pattern.search(child) for pattern in (
                    RE_DUE_IN_LINE, RE_LINE_DEADLINE, RE_WEEKDAY_DEADLINE,
                    RE_DUE_CLASS_N, RE_DUE_DAY_N, RE_DUE_NEXT_CLASS, RE_RELATIVE_DEADLINE))
                or re.search(r'\b(?:due|by|before|at)\s+(?:the\s+)?(?:start|beginning|end)\s+of\b', child, re.I)
                or re.search(r'\b(?:by|before|at)\s+(?:noon|midnight|(?:1[0-2]|0?[1-9])'
                             r'(?::[0-5]\d)?\s*[ap]\.?\s*m\.?)\b', child, re.I)
                or any(re.search(r'/courses/\d+/assignments/\d+', link.url)
                       for link in links_mod.extract_links(following, ''))):
            return None
        children.append((child, following))
        consumed.append(following_index)
        if len(children) > 16:
            return None
    else:
        if index + 49 < len(nodes):
            return None  # never silently accept a clipped instruction range
    return (number, name, children, consumed, is_next) if children else None


def _book_check_reading(text):
    """One physical-book check followed by an explicitly numbered reading."""
    match = re.fullmatch(
        r'Paperback or hardback of (?P<book>.{3,100}?) by .{3,80}? '
        r'due today = (?P<points>[1-9]\d?) point book check\. '
        r'Please review the assignment doc in the Canvas module with '
        r'Ch\. (?P<chapters>\d+-\d+) due Class (?P<class>[1-9]\d{0,2}) '
        r'\(Group [1-9]\d? presented by [^()]{3,80}\)\. '
        r'In Class (?P=class), we will also select presentation teams that begin in Class [1-9]\d{0,2}\.',
        text, re.I)
    if not match or re.search(r'\b(?:optional|if|not|example)\b', match['book'], re.I):
        return None
    return match.groupdict()


def _reading_flint_paragraph(text: str):
    match = re.fullmatch(
        r'(?P<reading>[^.!?;]{3,80}? Chapters \d+-\d+ are due with [^.!?]+\.)\s+'
        r'(?P<writing>Using your book and Google notes, complete the .+)', text, re.I)
    if not match or not _scored_flint_paragraph(match.group('writing')):
        return None
    reading = match.group('reading')
    if (re.search(r'\b(?:optional|if|example|not|for class)\b', reading, re.I)
            or any(pattern.search(reading) for pattern in (
                RE_LINE_DEADLINE, RE_WEEKDAY_DEADLINE, RE_DUE_CLASS_N, RE_DUE_DAY_N,
                RE_DUE_NEXT_CLASS, RE_RELATIVE_DEADLINE))
            or re.search(r'\b(?:due|by|before|at)\s+(?:the\s+)?(?:start|beginning|end)\s+of\s+'
                         r'(?:(?:the|this|next)\s+)?class\b', reading, re.I)):
        return None
    return match.group('reading'), match.group('writing')


def _reading_group_discussion(text: str):
    match = re.fullmatch(
        r'(?P<reading>(?P<book>[^.!?;]{3,80}?) Chapters? (?P<chapters>\d+(?:-\d+)?) '
        r'(?:is|are) due with [^.!?]+\.)\s+'
        r'(?P<discussion>Today, you will complete a group assignment for Chapter '
        r'(?P<target>\d+(?:-\d+)?) in a Canvas discussion board = (?P<points>[1-9]\d{0,2}) points'
        r'(?: with \+[1-9]\d{0,2} extra credit points available for the best group response)?\.)', text, re.I)
    if (not match or match.group('chapters') != match.group('target')
            or re.search(r'\b(?:optional|if|example|not|for class)\b', match.group('book'), re.I)):
        return None
    reading = match.group('reading')
    if any(pattern.search(reading) for pattern in (
            RE_LINE_DEADLINE, RE_WEEKDAY_DEADLINE, RE_DUE_CLASS_N, RE_DUE_DAY_N,
            RE_DUE_NEXT_CLASS, RE_RELATIVE_DEADLINE)) or re.search(
                r'\b(?:due|by|before|at)\s+(?:the\s+)?(?:start|beginning|end)\s+of\s+'
                r'(?:(?:the|this|next)\s+)?class\b', reading, re.I):
        return None
    return match.groupdict()


def _version_submission_pair(text, links, following, following_links):
    """A required partial version followed immediately by its later graded final."""
    progress = re.fullmatch(
        r'Hard gate at (?P<clock>(?:0?[1-9]|1[0-2]):[0-5]\d)\. '
        r'Submit whatever exists at (?P=clock) to (?P<name>[^,.!?]{3,40}?)\s*, '
        r'finished or not\.(?: Canvas timestamps every submission and '
        r"[A-Za-z .’'-]{1,60} reads that list tonight\.)?", text, re.I)
    if not progress:
        return None
    assignments = [link for link in links if link.kind == 'canvas' and re.fullmatch(
        r'/courses/\d+/assignments/\d+/?', urlsplit(link.url).path)]
    if len(assignments) != 1 or assignments[0].text.strip().casefold() != progress['name'].strip().casefold():
        return None
    link = assignments[0]
    if any(re.fullmatch(r'/courses/\d+/assignments/\d+/?', urlsplit(other.url).path)
           and other.url != link.url for other in following_links):
        return None
    final = re.fullmatch(
        rf'The finished {re.escape(link.text)} is due (?P<deadline>.+?), '
        r"(?P<points>[1-9]\d{0,2}) points\. Resubmit over today['’]s version; "
        r'the last one you send is the one graded\.'
        r'(?: (?:Monday|Tuesday|Wednesday|Thursday|Friday) you start writing the story from this page\.)?',
        following, re.I)
    if not final or not re.search(r'\b\d{1,2}(?::[0-5]\d)?\s*[ap]\.?m\.?\b', final['deadline'], re.I):
        return None
    return link, progress['clock'], int(final['points'])


def _practice_monthly_conduct(text: str):
    """Recognize only the complete adjacent test-conduct notice, not arbitrary prose."""
    match = re.fullmatch(
        r'(?P<core>Practice (?P<subject>[^.!?;=]{1,60}) test will be today for monthly test '
        r'in Class [1-9]\d{0,2} = [1-9]\d{0,2} points[.!])\s+'
        r'(?P<conduct>(?P=subject)[’\']s Anti-Cheat feature is now active and prevents students '
        r'from switching tabs during assessments, reloading the page excessively, or minimizing screens\. '
        r'(?P=subject) will warn you the first time\. '
        r'If you do any of those actions again, your test will be flagged as suspicious and submitted immediately\. '
        r'After that, [A-Za-z .’\'-]{1,60} will refer you to [A-Za-z .’\'-]{1,60} for potential consequences\.)',
        text, re.I)
    if not match or re.search(r'\b(?:due|homework|assignment|cancel\w*|postpon\w*)\b', match.group('conduct'), re.I):
        return None
    return match.group('core'), match.group('conduct')


def _practice_monthly_test(text: str):
    supported_conduct = _practice_monthly_conduct(text)
    core = supported_conduct[0] if supported_conduct else text
    today = re.fullmatch(
        r'Practice ([^.!?;=]{1,60}) test will be today for monthly test in '
        r'Class ([1-9]\d{0,2}) = ([1-9]\d{0,2}) points[.!]?', core, re.I)
    if today and not re.search(
            r'\b(?:optional|not|review|workshop|example|cancel\w*|postpon\w*)\b',
            today.group(1), re.I):
        return today.group(1).strip(), int(today.group(2)), int(today.group(3)), None
    future = re.fullmatch(
        r'Practice ([^.!?;=]{1,60}) test will be in Class ([1-9]\d{0,2}) '
        r'for monthly test in Class ([1-9]\d{0,2}) = ([1-9]\d{0,2}) points[.!]?',
        text, re.I)
    if future and not re.search(
            r'\b(?:optional|not|review|workshop|example|cancel\w*|postpon\w*)\b',
            future.group(1), re.I):
        return (future.group(1).strip(), int(future.group(3)), int(future.group(4)),
                int(future.group(2)))
    match = re.fullmatch(
        r'Practice ([^.!?;=]{1,60}) test is today with the monthly test in '
        r'Class ([1-9]\d{0,2}) = ([1-9]\d{0,2}) points[.!]?', text, re.I)
    if not match:
        # The same schedule also occurs as two sentences, with a split
        # initial letter from Google Docs inline formatting.
        match = re.fullmatch(
            r'P\s*ractice monthly ([^.!?;=]{1,60}) tests today\.\s+'
            r'\1 test next Class ([1-9]\d{0,2}) = ([1-9]\d{0,2}) points[.!]?',
            text, re.I)
    if not match or re.search(r'\b(?:optional|not|review|workshop|example|cancel\w*|postpon\w*)\b', match.group(1), re.I):
        return None
    return match.group(1).strip(), int(match.group(2)), int(match.group(3))


def _paired_numbered_essays(text: str):
    """One exact conjoined schedule, with optional shared book preparation."""
    match = re.fullmatch(
        r'Class ([1-9]\d{0,2}) will be (?:the )?practice essay and '
        r'Class ([1-9]\d{0,2}) is (?:the )?lockdown essay over ([^.!?;]{3,100})\.'
        r'(?:\s+(Your book will be your only resource, so make sure [^.!?]+\.'
        r'(?:\s+Those quotes must [^.!?]+\.)?))?', text, re.I)
    if (not match or match.group(1) == match.group(2)
            or re.search(r'\b(?:optional|not|cancel\w*|postpon\w*|due|submit|complete|worksheet)\b', text, re.I)):
        return None
    return int(match.group(1)), int(match.group(2)), match.group(3).strip()


def extract_prose(html: str, course_key: str, course_display: str,
                  course_lookup: str, meetings, where: str = "the class homepage",
                  source_url: str = "", profile=None,
                  source: str = "canvas_page",
                  kind: str = "course homepage") -> ProseResult:
    """Every piece of work stated in one prose document. Pure: no network, no
    clock. `source`/`kind` say where it came from — a Canvas page or a
    teacher's own doc, which are the same shape and the same rules."""
    from bs4 import BeautifulSoup

    result = ProseResult()
    source_kind = kind
    prefixes = compile_prefixes(profile)
    year_start = meetings.school_year_start() or timezones.to_local(
        datetime.now(timezones.zone())).year
    soup = BeautifulSoup(html or "", "lxml")
    body = soup.body or soup
    nodes = _leaf_blocks(body, prefixes, year_start)

    # ---- pass 1: where are the headings, and how many days per block? -------
    parsed: list = []
    block_start = None
    consumed_node_indices = set()
    for node_index, node in enumerate(nodes):
        if node_index in consumed_node_indices:
            continue
        text = _clean(node.get_text(" ", strip=True))
        block = block_heading(text, year_start)
        if block is not None:
            block_start = block[0]
            parsed.append(("block", block, text, ""))
            continue
        below = _below_subtasks(nodes, node_index, year_start)
        if below:
            parsed.append(('below_subtasks', below, text, node))
            consumed_node_indices.update(below[3])
            continue
        book_reading = _book_check_reading(text)
        if book_reading and node.find('a'):
            book_links = links_mod.extract_links(node, source_url)
            if len(book_links) != 1 or book_links[0].text.strip() != book_reading['book']:
                book_reading = None
        if book_reading:
            parsed.append(('book_check_reading', book_reading, text, node))
            continue
        reading_writing = _reading_flint_paragraph(text) if not node.find('a') else None
        if reading_writing:
            parsed.extend(('line', None, part, node) for part in reading_writing)
            continue
        reading_discussion = _reading_group_discussion(text) if not node.find('a') else None
        if reading_discussion:
            parsed.append(('reading_discussion', reading_discussion, text, node))
            continue
        mixed = _practice_monthly_test(text) if not node.find('a') else None
        if mixed:
            parsed.append(('practice_monthly', mixed, text, node))
            continue
        paired = _paired_numbered_essays(text) if not node.find('a') else None
        if paired:
            parsed.append(('paired_essays', paired, text, node))
            continue
        heading = day_heading(text, year_start)
        if heading is not None:
            parsed.append(("day", heading, text, block_start))
            continue
        # English repeats two separately scheduled essays in one paragraph.
        # Split only when every sentence independently names scheduled work.
        # Linked paragraphs retain their markup and existing link ownership.
        # [MEASURED] Spanish: workbook problems followed by a distinct
        # Quizlet Write hand-in in the same paragraph. The later task alone
        # names Day 4; moving the whole paragraph moves the workbook too.
        workbook_duolingo = _workbook_weekly_duolingo(text)
        if workbook_duolingo and not node.find('a'):
            parsed.extend(('line', None, part, node) for part in workbook_duolingo)
            continue
        workbook_then_write = re.fullmatch(
            r"(?P<workbook>\*{0,2}Tarea:\s*(?:WB\s+)?P-\s*\d+"
            r"(?:,\s*P-\s*\d+)*),\s*"
            r"(?P<write>Finish\s+Quizlet\s+Write\s+.+)", text, re.I)
        if (workbook_then_write and not node.find("a")
                and RE_DUE_DAY_N.search(workbook_then_write.group('write'))):
            parsed.extend(("line", None, workbook_then_write.group(part), node)
                          for part in ('workbook', 'write'))
            continue
        parts = _sentences(text)
        if (len(parts) > 1 and not node.find("a") and all(
                RE_GRADED_ESSAY_SCHEDULE.match(part) or (
                    names_an_assessment(part) and RE_SCHEDULED_CLASS_N.search(part))
                for part in parts)):
            parsed.extend(("line", None, part, node) for part in parts)
        else:
            parsed.append(("line", None, text, node))

    # Explicit Day numbers repeat in every block. Index by occurrence, never
    # by a global Day N or even a reused block-start date.
    day_blocks = {}
    numbered_days = {}
    occurrence = -1
    for index, (entry_kind, entry_value, _, _) in enumerate(parsed):
        if entry_kind == "block":
            occurrence += 1
        day_blocks[index] = occurrence
        if entry_kind == "day" and entry_value[0] == "date":
            number = RE_DAY_N_LEAD.match(entry_value[2].lstrip("*•-–— \t"))
            if number:
                numbered_days.setdefault((occurrence, int(number.group(1))), set()).add(entry_value[1])

    def numbered_day_date(number):
        candidates = numbered_days.get((day_blocks[parsed_index], number), set())
        return next(iter(candidates)) if len(candidates) == 1 else None

    days_per_block: dict = {}
    current = None
    for kind, value, _text, _extra in parsed:
        if kind == "block":
            current = value[0]
            days_per_block.setdefault(current, 0)
        elif kind == "day" and value[0] != "classn":
            days_per_block[current] = days_per_block.get(current, 0) + 1

    # ---- pass 1½: every "Class N" heading the page dates by itself ----------
    # [MEASURED] 2026-10-04: the Honors English doc lists its newest class
    # FIRST. "Class 21" is read before any class it could be counted from, its
    # own weekdays point at next week, and it came out "nothing above it gives
    # a date" — so everything set that day vanished from the board. Every
    # class the page dates on its own is found first; an undated one is then
    # counted from the NEAREST of them, before or after.
    class_known: list = []          # (number, date, label), dated by the page itself
    span_now = None
    for kind, value, _text, _extra in parsed:
        if kind == "block":
            span_now = (value[0], value[1])
        elif kind == "day" and value[0] == "classn":
            got = class_stated(course_lookup, value[2], span_now, where, meetings)
            if got is not None and got.when is not None and got.confidence == "high":
                class_known.append((value[1], got.when, value[2]))

    def nearest_class(number: int):
        if not class_known:
            return None
        return min(class_known, key=lambda k: (abs(k[0] - number), k[0] > number))

    def class_date(number: int):
        """The date of "Class N" on his timetable, counted from the nearest
        class the page itself dates."""
        near = nearest_class(number)
        if near is None:
            return None
        got = dates_mod.resolve_day_n_counted(
            course_lookup, number, near[1], near[0], near[2], meetings, where,
            label_is_class=True)
        return got if got.when is not None else None

    # ---- pass 2: build the items -------------------------------------------
    day_resolution = None
    day_label = ""
    block_start = None
    seen_first_day = False
    previous_line = ""          # the line above, for a points-led detail line
    previous_item = None        # and the item it made, which that line replaces
    skipped_before_first_day = 0
    # The most recent date the page actually stated, and the day number it was
    # attached to. An undated "Day 4" counts forward from here.
    anchor_date = None
    anchor_number = 0
    anchor_label = ""
    # A separate anchor for year-long "Class N" numbering, which a block
    # heading must never reset.
    class_anchor = None
    class_anchor_number = 0
    class_anchor_label = ""
    block_span = None
    pending_named_work = None
    preparation_guidance = []
    adjacent_essays = []
    consumed_lines = set()

    for parsed_index, (kind, value, text, extra) in enumerate(parsed):
        if parsed_index in consumed_lines:
            continue
        if kind == "block":
            pending_named_work = None
            preparation_guidance = []
            adjacent_essays = []
            block_start, block_end, block_label = value
            block_span = (block_start, block_end)
            day_resolution, day_label = None, ""
            anchor_date, anchor_number, anchor_label = block_start, 0, block_label
            result.headings.append(block_label)
            continue

        if kind == "day":
            pending_named_work = None
            preparation_guidance = []
            adjacent_essays = []
            heading_kind, heading_value, label, rest = value
            seen_first_day = True
            day_label = label
            if heading_kind == "classn":
                # Numbered across the whole year, so a block heading must not
                # reset the count — and its weekdays are the strongest evidence
                # available, because the doc names one day per class period and
                # only his own timetable says which is his.
                stated = class_stated(course_lookup, label, block_span, where,
                                      meetings)
                if stated is not None and stated.confidence == "high":
                    day_resolution = stated
                elif class_anchor is not None:
                    day_resolution = dates_mod.resolve_day_n_counted(
                        course_lookup, heading_value, class_anchor,
                        class_anchor_number, class_anchor_label, meetings,
                        where, label_is_class=True)
                    if day_resolution.when is None and stated is not None:
                        day_resolution = stated
                elif stated is not None:
                    day_resolution = stated
                elif class_date(heading_value) is not None:
                    day_resolution = class_date(heading_value)
                else:
                    day_resolution = dates_mod.Resolution(
                        None, dates_mod.NOTES["page_day_no_anchor"].format(
                            n=heading_value, where=where), "unresolved", "low")
                if day_resolution.when is not None and (
                        class_anchor is None
                        or day_resolution.confidence == "high"):
                    class_anchor = day_resolution.when
                    class_anchor_number = heading_value
                    class_anchor_label = label
            elif heading_kind == "dayn":
                day_resolution = dates_mod.resolve_day_n_counted(
                    course_lookup, heading_value, anchor_date, anchor_number,
                    anchor_label, meetings, where)
            else:
                day_resolution = _resolution(
                    heading_kind, heading_value, label, course_lookup, meetings,
                    where, days_per_block.get(block_start, 0))
                # A stated date becomes the anchor everything after it counts
                # from, whether or not it carried a day number.
                if day_resolution.when is not None:
                    anchor_date = day_resolution.when
                    anchor_label = label
                    number = RE_DAY_N_LEAD.match(label.lstrip("*•-–— \t"))
                    anchor_number = int(number.group(1)) if number else 0
            result.headings.append(label)
            # A new day starts a new context. Without this the detail line at
            # the top of one cell took its name from the last line of the
            # previous cell — a different day, often a different assignment.
            previous_line = ""
            previous_item = None
            if rest:
                # content that shared the paragraph with its heading
                role, cleaned = classify_line(rest, prefixes, [])
                if role:
                    item = _build(cleaned, rest, role, day_resolution, day_label,
                                  [], course_key, course_display, course_lookup,
                                  meetings, where, source_url, year_start,
                                  source, kind, class_date=class_date,
                                  week=block_span, day_date=numbered_day_date)
                    if item is not None:
                        item.assigned_date = (day_resolution.when.isoformat()
                                              if day_resolution and day_resolution.when else None)
                        result.items.append(item)
            continue

        node = extra
        if node is None or not text:
            continue
        if kind == 'below_subtasks':
            if not seen_first_day:
                skipped_before_first_day += 1
                continue
            number, name, children, _, is_next = value
            source_class = re.search(r'\bClass\s+(\d+)\b', day_label, re.I)
            contradictory = is_next and source_class and number <= int(source_class.group(1))
            explicit_dates = {entry[1] for entry in class_known if entry[0] == number}
            anchor = nearest_class(number)
            anchor_dates = {entry[1] for entry in class_known if anchor and entry[0] == anchor[0]}
            target = (class_date(number) if not contradictory
                      and len(explicit_dates) <= 1 and len(anchor_dates) <= 1 else None)
            day = target.when if target else None
            note = (f'Class {number} explicitly targeted in {where}; '
                    + (target.note + '; exact deadline clock unstated' if day else
                       'target date missing or conflicting; no posting-class deadline assigned'))
            parent_links = links_mod.extract_links(node, source_url)
            identity = hashlib.sha1(f'{course_key}|{source_url}|Class {number}|{name.lower()}'.encode()).hexdigest()
            item = _item(f'{name} — Class {number}', text, course_key, course_display,
                         None, day.isoformat() if day else None, note,
                         'medium' if day else 'low', 'day_n_exact' if day else 'unresolved',
                         ['stated_category', 'below_subtask_parent', 'below_subtask_context:' + identity,
                          'deadline_clock_unstated' if day else 'needs_date_confirmation'],
                         parent_links, source_url, 'due', source, kind=source_kind)
            item.category = 'reading'
            item.assigned_date = day_resolution.when.isoformat() if day_resolution and day_resolution.when else None
            item.detail += '\nRequired steps:\n' + '\n'.join(child for child, _ in children)
            for _, child_node in children:
                for link in links_mod.extract_links(child_node, source_url):
                    if link not in item.links:
                        item.links.append(link)
            result.items.append(item)
            previous_line, previous_item, pending_named_work = '', None, None
            adjacent_essays = []
            continue
        if kind == 'book_check_reading':
            if not seen_first_day:
                skipped_before_first_day += 1
                continue
            assigned = day_resolution.when if day_resolution else None
            number = int(value['class'])
            target = class_date(number)
            for reading in (False, True):
                day = target.when if reading and target else (None if reading else assigned)
                title = (f"{value['book']} Chapters {value['chapters']} — Class {number}" if reading
                         else f"{value['book']} — book check")
                note = (f'Class {number} reading explicitly scheduled in {where}; ' if reading
                        else f'Book check due in the source class in {where}; ')
                note += ((target.note if reading else day_resolution.note) + '; exact deadline clock unstated'
                         if day else 'class date unresolved; no deadline clock assigned')
                detail = (f"{value['book']} Chapters {value['chapters']} due Class {number}. "
                          'Review the assignment document in the Canvas module.' if reading else
                          re.split(r'Please review the assignment doc', text, maxsplit=1, flags=re.I)[0].strip())
                item = _item(title, detail, course_key, course_display, None,
                             day.isoformat() if day else None, note,
                             'medium' if day else 'low', 'day_n_exact' if day else 'unresolved',
                             ['stated_category', 'split_book_check_reading',
                              'deadline_clock_unstated' if day else 'needs_date_confirmation'],
                             [] if reading else links_mod.extract_links(node, source_url),
                             source_url, 'due', source, kind=source_kind)
                item.category = 'reading' if reading else 'admin'
                item.points = None if reading else int(value['points'])
                item.assigned_date = assigned.isoformat() if assigned else None
                item.raw_cell = detail
                result.items.append(item)
            previous_line, previous_item, pending_named_work = '', None, None
            adjacent_essays = []
            continue
        if kind == 'reading_discussion':
            if not seen_first_day:
                skipped_before_first_day += 1
                continue
            day = day_resolution.when if day_resolution else None
            numbered = re.search(r'\b(Class|Day)\s+(\d+)\b', day_label, re.I)
            context = f'{numbered.group(1).title()} {numbered.group(2)}' if numbered else day_label
            if not numbered or numbered.group(1).lower() == 'day':
                context += f' / {block_span}'
            for category in ('reading', 'discussion'):
                part = value['reading'] if category == 'reading' else value['discussion']
                chapter_word = 'chapters' if '-' in value['chapters'] else 'chapter'
                name = f'{value["book"]} {chapter_word} {value["chapters"]}'
                label = f'{"Reading" if category == "reading" else "Group discussion"}: {name} — {context}'
                identity = hashlib.sha1(f'{course_key}|{source_url}|{context}|{name.lower()}|{category}'.encode()).hexdigest()
                note = (f'{where}: {category} in source class; '
                        + (day_resolution.note + '; exact deadline clock unstated' if day else
                           'source class date unresolved; no deadline clock assigned'))
                item = _item(label, part, course_key, course_display, None,
                             day.isoformat() if day else None, note,
                             'medium' if day else 'low', 'day_n_exact' if day else 'unresolved',
                             ['stated_category', 'split_reading_discussion', 'reading_discussion_context:' + identity,
                              'deadline_clock_unstated' if day else 'needs_date_confirmation'],
                             [], source_url, 'due', source, kind=source_kind)
                item.category = category
                item.points = int(value['points']) if category == 'discussion' else None
                item.assigned_date = day.isoformat() if day else None
                result.items.append(item)
            previous_line, previous_item, pending_named_work = '', None, None
            adjacent_essays = []
            continue
        if kind == 'practice_monthly':
            if not seen_first_day:
                skipped_before_first_day += 1
                continue
            subject, number, points, *practice_spec = value
            future_practice = [n for n in practice_spec if n is not None]
            conduct = _practice_monthly_conduct(text)
            assigned = day_resolution.when if day_resolution else None
            practice_target = class_date(future_practice[0]) if future_practice else day_resolution
            practice_day = practice_target.when if practice_target else None
            practice_label = f'in Class {future_practice[0]}' if future_practice else 'today'
            target = class_date(number)
            source_class = re.search(r'\bClass\s+(\d+)\b', day_label, re.I)
            parent = None
            if practice_spec:
                # Preserve completion/planner references to the old combined
                # row while recovering the two separately scheduled events.
                parent_role, parent_title = classify_line(text, prefixes, [])
                parent = _build(parent_title, text, parent_role, day_resolution, day_label, [],
                                course_key, course_display, course_lookup, meetings,
                                where, source_url, year_start, source, source_kind,
                                class_date=class_date, week=block_span, day_date=numbered_day_date)
            for label, category, day, instructions in (
                    (f'Practice {subject} test', 'practice', practice_day,
                     f'Practice {subject} test is {practice_label}.'),
                    (f'Monthly {subject} test', 'test', target.when if target else None,
                     f'Monthly {subject} test is in Class {number} = {points} points.')):
                note = (f'{where}: practice {practice_label}, monthly test explicitly in Class {number}; '
                        + (practice_target.note + '; exact clock unstated' if category == 'practice' and day else
                           target.note + '; exact clock unstated' if day else
                           'target class date unresolved; no date borrowed from the other activity'))
                if category == 'test':
                    identity = number
                elif future_practice:
                    identity = future_practice[0]
                else:
                    identity = int(source_class.group(1)) if source_class else None
                identity_flag = f'split_target:{category}:{identity}'
                if day is None and identity is not None:
                    label += f' (Class {identity})'
                item = _item(label, instructions, course_key, course_display,
                             None, day.isoformat() if day else None, note,
                             'medium' if day else 'low', 'day_n_exact' if day else 'unresolved',
                             ['stated_category', 'split_practice_monthly', identity_flag,
                              'deadline_clock_unstated' if day else 'needs_date_confirmation'],
                             [], source_url, 'due', source, kind=source_kind)
                item.category = category
                item.points = points if category == 'test' else None
                if conduct:
                    item.detail += '\nTest conduct: ' + conduct[1]
                if parent is not None:
                    item.merged_from.append(f'{source}:{parent.item_id}')
                item.raw_cell = text
                item.assigned_date = assigned.isoformat() if assigned else None
                result.items.append(item)
            previous_line, previous_item, pending_named_work = '', None, None
            adjacent_essays = []
            continue
        if kind == 'paired_essays':
            if not seen_first_day:
                skipped_before_first_day += 1
                continue
            first, second, book = value
            for number, label in ((first, 'Practice essay'), (second, 'Lockdown essay')):
                target = class_date(number)
                day = target.when.isoformat() if target and target.when else None
                note = (f'Class {number} explicitly scheduled in {where}; '
                        + (target.note + '; exact deadline clock unstated' if day else
                           'target class date unresolved; no posting-class deadline assigned'))
                item = _item(f'Class {number}: {label.lower()} over {book}', text,
                             course_key, course_display, None, day, note,
                             'medium' if day else 'low', 'day_n_exact' if day else 'unresolved',
                             ['stated_category', 'numbered_essay_target', 'deadline_clock_unstated'] if day else
                             ['stated_category', 'numbered_essay_target', 'needs_date_confirmation'],
                             [], source_url, 'due', source, kind=source_kind)
                item.category = 'essay'
                item.assigned_date = day_resolution.when.isoformat() if day_resolution and day_resolution.when else None
                result.items.append(item)
            previous_line, previous_item, pending_named_work = '', None, None
            adjacent_essays = []
            continue
        weekly = RE_WEEKLY_DEADLINE.search(text)
        if weekly and block_span:
            # The Spanish homepage explicitly repeats 50 XP EACH Friday in
            # its two-week section, before Day 1. Keep those real deadlines
            # rather than dropping them or making one undated TikTok task.
            links = links_mod.extract_links(node, source_url)
            day = block_span[0]
            target = WEEKDAY_INDEX[weekly.group('day').lower()]
            day += timedelta(days=(target - day.weekday()) % 7)
            while day <= block_span[1]:
                note = (f'"{_clean(weekly.group(0))}" on {where}, within '
                        f'{block_span[0].isoformat()} through {block_span[1].isoformat()}')
                phrase = _clean(weekly.group(0))
                clock = deadline_clock(text, phrase)
                moment, note = deadline_moment(day, text, phrase, meetings, course_lookup, note)
                item = _item(text.lstrip('* '), text, course_key, course_display,
                             moment.isoformat() if clock else None, day.isoformat(), note,
                             'high', 'absolute', ['stated_recurring'], links,
                             source_url, 'due', source=source, kind=kind)
                item.all_day = clock is None
                result.items.append(item)
                day += timedelta(days=7)
            continue
        if not seen_first_day:
            # Course furniture above the first dated heading. Counted, not
            # hidden: the diagnostics say how much was passed over.
            # A self-dated task is evidence even without schedule furniture.
            # A broad "everything above Day 1 is policy" rule lost standalone
            # homepage homework. Require a deadline or an explicit HW prefix,
            # and keep actual policy notices out.
            policy = re.match(r'^\W*(?:assessment\s+makeup\s+policy|'
                              r'late\s+work|retake\w*|makeup\w*|'
                              r'office\s+hours|grading\s+policy)\b', text, re.I)
            homework = prefixes['homework'] and prefixes['homework'].match(text)
            if policy or not (stated_deadline(text, year_start) or homework):
                if len(text) > 3:
                    skipped_before_first_day += 1
                continue
        printed = (_printed_pogil(parsed, parsed_index, source_url)
                   if day_resolution and day_resolution.when else None)
        if printed:
            title, instructions, task_links, weekday = printed
            assigned = day_resolution.when
            target = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"].index(weekday)
            when = assigned + timedelta(days=(target - assigned.weekday()) % 7)
            note = ("'" + text + "' and '" + parsed[parsed_index + 2][2] +
                    "' on " + where + "; " + weekday.title() + " counted from " +
                    assigned.isoformat() + " is " + when.isoformat() +
                    "; exact submission clock unstated")
            item = _item(title, instructions, course_key, course_display, None,
                         when.isoformat(), note, "medium", "relative_to_posted",
                         ["printed_handin", "deadline_clock_unstated"], task_links,
                         source_url, "due", source, kind)
            item.assigned_date = assigned.isoformat()
            result.items.append(item)
            consumed_lines.update((parsed_index + 1, parsed_index + 2))
            adjacent_essays = []
            previous_line, previous_item, pending_named_work = "", None, None
            continue
        daily = (_daily_discussion(parsed, parsed_index, source_url, year_start)
                 if day_resolution and day_resolution.when else None)
        if daily:
            name, instructions, board_links = daily
            assigned = day_resolution.when.isoformat()
            caption = "Daily Warm Up: " + name if name else "Daily Warm Up"
            item = _item(caption + " — class " + assigned,
                         instructions, course_key, course_display, None, None,
                         "Daily posting exercise in " + day_label +
                         "; no submission deadline stated; completion unknown",
                         "medium", "unresolved", ["daily_discussion", "deadline_unstated"],
                         board_links, source_url, "homework", source, kind)
            item.assigned_date = assigned
            item.url = board_links[0].url
            if re.search(r"Before you leave: reply under your own post", instructions, re.I):
                item.flags = [f for f in item.flags if f != "deadline_unstated"] + ["deadline_clock_unstated"]
                item.date_note = ("Daily posting exercise in " + day_label +
                                  "; reply requested before leaving class; "
                                  "exact deadline clock unstated; completion unknown")
            result.items.append(item)
            adjacent_essays = []
            previous_line, previous_item, pending_named_work = "", None, None
            continue
        links = links_mod.extract_links(node, source_url)
        if (day_resolution and day_resolution.when and parsed_index + 1 < len(parsed)
                and re.match(r'^Hard gate at ', text, re.I)):
            next_kind, _, following, next_node = parsed[parsed_index + 1]
            following_links = links_mod.extract_links(next_node, source_url) if next_kind == 'line' else []
            version_pair = (_version_submission_pair(text, links, following, following_links)
                            if next_kind == 'line' else None)
            if version_pair:
                assignment, clock_literal, final_points = version_pair
                assigned = day_resolution.when.isoformat()
                final = _build(assignment.text, following, 'due', day_resolution, day_label,
                               [assignment, *following_links], course_key, course_display, course_lookup,
                               meetings, where, source_url, year_start, source, source_kind,
                               class_date=class_date, week=block_span, day_date=numbered_day_date)
                if final is not None and final.due and final.due_date and final.due_date > assigned:
                    old_role, old_title = classify_line(following, prefixes, following_links)
                    old_final = _build(old_title, following, old_role, day_resolution, day_label,
                                       following_links, course_key, course_display, course_lookup,
                                       meetings, where, source_url, year_start, source, source_kind,
                                       class_date=class_date, week=block_span, day_date=numbered_day_date)
                    if old_final is not None and old_final.item_id != final.item_id:
                        final.merged_from.append(f'{source}:{old_final.item_id}')
                    final.points = final_points
                    final.assigned_date = assigned
                    final.url = assignment.url
                    final.flags.append('versioned_assignment_final')
                    milestone = _item(
                        f'Progress submission: {assignment.text} — {assigned} at {clock_literal} (AM/PM unconfirmed)',
                        text, course_key, course_display, None, assigned,
                        f'Required in-class progress version in source class {assigned}; source clock '
                        f'{clock_literal} has no explicit AM/PM; exact instant and completion unconfirmed. '
                        f'This is distinct from the graded final due {final.due_date}.',
                        'low', 'unresolved', ['submission_milestone', 'deadline_clock_ambiguous',
                                              'needs_date_confirmation', 'completion_unknown'],
                        [assignment], source_url, 'due', source, kind='in-class submission milestone')
                    milestone.assigned_date = assigned
                    milestone.url = assignment.url
                    result.items.extend([milestone, final])
                    consumed_lines.add(parsed_index + 1)
                    adjacent_essays = []
                    previous_line, previous_item, pending_named_work = '', None, None
                    continue
        exit_points = re.fullmatch(
            r"Screenshots of today['’]s progress \+ one line on your next step\. ([1-9]\d{0,2}) points\.",
            text, re.I)
        if pending_named_work is not None and exit_points and day_resolution and day_resolution.when:
            name, named_links, instructions = pending_named_work
            assignments = [link for link in named_links if link.kind == 'canvas' and re.fullmatch(
                r'/courses/\d+/assignments/\d+/?', urlsplit(link.url).path)]
            if (re.fullmatch(r'Exit Ticket:\s*.{3,70}', name, re.I)
                    and not re.search(r'\b(?:optional|rubric|example|review)\b', name, re.I)
                    and len(instructions) == 1 and instructions[0] == name and len(assignments) == 1):
                assigned = day_resolution.when.isoformat()
                raw = ' '.join([*instructions, text])
                item = _item(name + ' — class ' + assigned, raw, course_key, course_display,
                             None, None, f'Named graded exit ticket in {day_label}; '
                             f'class date {assigned} is when assigned, not a stated submission deadline',
                             'medium', 'unresolved', ['named_exit_ticket', 'deadline_unstated', 'needs_date_confirmation',
                                                      'exit_ticket_assignment:' + hashlib.sha1(assignments[0].url.encode()).hexdigest()],
                             named_links, source_url, 'due', source, kind=source_kind)
                item.points = int(exit_points[1])
                item.assigned_date = assigned
                item.url = assignments[0].url
                item.raw_cell = raw
                result.items.append(item)
                adjacent_essays = []
                previous_line, previous_item, pending_named_work = '', None, None
                continue
        if _shared_essay_support(text, year_start, adjacent_essays):
            for essay in adjacent_essays:
                if text not in (essay.detail or ""):
                    essay.detail = (essay.detail or essay.title) + (
                        "\nPreparation guidance (no separate deadline stated): " + text)
                if "source_preparation_guidance" not in essay.flags:
                    essay.flags.append("source_preparation_guidance")
                seen = {link.url for link in essay.links}
                essay.links.extend(link for link in links if link.url not in seen)
            previous_line, previous_item, pending_named_work = "", None, None
            continue
        targets = _essay_preparation_targets(text, year_start)
        if targets:
            adjacent_essays = []
            preparation_guidance.append((targets, text, links))
            previous_line, previous_item, pending_named_work = "", None, None
            continue
        role, cleaned = classify_line(text, prefixes, links)
        finish_sequence = _finish_project_footer(parsed, parsed_index, links, source_url, year_start) if role else None
        if finish_sequence:
            links = finish_sequence[2]
        if (pending_named_work is not None and role in ('action', 'due')
                and len(pending_named_work[2]) < 3
                and re.match(r'^Turn in the \.html file on Canvas with your prompts\b', text, re.I)
                and re.search(r'\battach the same file\b', text, re.I)
                and sum(bool(re.search(r'/courses/\d+/discussion_topics/\d+', link.url)) for link in links) == 1
                and not any(re.search(r'/courses/\d+/assignments/\d+', link.url) for link in links)
                and parsed_index + 1 < len(parsed)):
            next_kind, _, following, next_node = parsed[parsed_index + 1]
            named_links = pending_named_work[1]
            pending_assignments = [link for link in named_links
                                   if re.search(r'/courses/\d+/assignments/\d+', link.url)]
            footer = RE_POINTS_LEAD.sub('', following).strip(' .,:;')
            own_footer_date = stated_deadline(footer, year_start)
            bare_footer = bool(re.fullmatch(r'Due by (?:the )?end of class[.!]?', footer, re.I))
            if own_footer_date and footer.lower().startswith(own_footer_date[1].lower()):
                tail = footer[len(own_footer_date[1]):].strip(' .!')
                clock_tail = re.sub(r'^\s*,?\s*(?:(?:at|by|before|@)\s*)?', '', tail, flags=re.I)
                bare_footer = not tail or bool(RE_DEADLINE_CLOCK.fullmatch(clock_tail))
            if (len(pending_assignments) == 1 and next_kind == 'line'
                    and RE_POINTS_LEAD.match(following) and bare_footer
                    and not any(re.search(r'/courses/\d+/assignments/\d+', link.url)
                                for link in links_mod.extract_links(next_node, source_url))):
                # One named .html hand-in, with the SAME file also posted to
                # a discussion. Keep the instructions until its adjacent
                # marks/deadline footer instead of making an unnamed task.
                pending_named_work = (pending_named_work[0], [*named_links, *links],
                                      [*pending_named_work[2], text])
                continue
        if not role:
            if text.strip():
                adjacent_essays = []
            # AI Frontiers: linked Canvas assignment NAME, one paragraph of
            # instructions, then "10 points, due ...". A normal resource link
            # is not evidence that it names the following work.
            assignment_links = [link for link in links
                                if re.search(r'/courses/[^/]+/assignments/\d+', link.url)]
            named = next((link.text for link in assignment_links
                          if _normalised(link.text) == _normalised(text)), None)
            # [MEASURED] 2026-11-04: a linked project name, then "Due by
            # Tuesday @ midnight", became a nameless deadline. Unlike Canvas
            # assignment URLs, other links need both a project-shaped bare
            # name and an immediately adjacent explicit deadline as evidence.
            if (not named and _names_the_work(text, year_start)
                    and re.search(r'\bproject(?:\s+\d+)?\Z', text, re.I)
                    and parsed_index + 1 < len(parsed)):
                next_kind, _, following, _ = parsed[parsed_index + 1]
                bare_deadline = re.fullmatch(
                    r'due\s+(?:(?:by|on)\s+)?'
                    r'(?:mon(?:day)?|tue(?:s(?:day)?)?|wed(?:nesday)?|'
                    r'thu(?:r(?:s(?:day)?)?)?|fri(?:day)?|sat(?:urday)?|sun(?:day)?)'
                    r'(?:\s+next\s+week)?'
                    r'(?:\s*(?:@|at|by)\s*(?:midnight|noon|'
                    r'(?:1[0-2]|0?[1-9])(?::[0-5]\d)?\s*[ap]\.?m\.?))?[.!]?',
                    following, re.I)
                if next_kind == 'line' and bare_deadline:
                    project_links = [link for link in links
                                     if _normalised(link.text) == _normalised(text)]
                    if len(project_links) == 1:
                        named = project_links[0].text
                        assignment_links = project_links
            if named:
                pending_named_work = (named, assignment_links, [text])
            elif pending_named_work is not None:
                new_name = (_names_the_work(text, year_start)
                            and not RE_MARKS_IN_LINE.search(text)
                            and not re.search(r'[.!?]', text)
                            and not re.match(r'^(?:choose|answer|use|your|canvas)\b', text, re.I))
                if new_name:
                    pending_named_work = None
                elif len(pending_named_work[2]) < 4:
                    pending_named_work[2].append(text)
                else:
                    pending_named_work = None
            # A line with no letters in it is not the name of anything. Google
            # Docs splits a sentence around a link into three nodes, so
            # "Workshop: build toward the [Side Hustle Proposal]." arrives as
            # "Workshop: build toward the" / "Side Hustle Proposal" / "." —
            # and the line above the next one is a full stop. [MEASURED]
            # 2026-09-03: that lone "." is why "100 pts, due Sep 26" kept its
            # own name while the identical line two cells earlier did not.
            if any(c.isalpha() for c in text):
                previous_line = text
                previous_item = None
            continue
        titled = cleaned
        raw_text = finish_sequence[1] if finish_sequence else text
        if role == 'team_room_survey' and re.fullmatch(
                r'Final Team Room Survey [–—-] \d{1,2}:\d{2}-\d{1,2}:\d{2}',
                previous_line, re.I):
            raw_text = previous_line + ': ' + text
        supersedes = None
        # In one real doc the assignment's name is the link and the sentence
        # around it is only the lead-in and the deadline.
        named_by_link = finish_sequence[0] if finish_sequence else _link_title(cleaned, links)
        scored_quiz = RE_SCORED_CLASS_QUIZ.match(raw_text) if role == 'assessment' else None
        enrollment = RE_MEMBEAN_ENROLLMENT_TRAINING.match(raw_text)
        lesson_setup = RE_NRI_LESSON_SETUP.fullmatch(raw_text)
        if lesson_setup:
            titled = f"{lesson_setup.group('name')} Canvas assignment"
        elif enrollment:
            titled = f'{enrollment.group(1)} minutes of Membean training'
        elif scored_quiz:
            titled = scored_quiz.group('name')
        elif named_by_link:
            titled = named_by_link
        if (_is_detail_line(text) and previous_line
                and not _is_detail_line(previous_line)):
            # The work is named above; the marks and the date are here. They
            # are ONE assignment, so the detail line does not add a row — it
            # replaces the row the line above made, taking its name and
            # keeping its own stated deadline.
            #
            # Replacing rather than appending is the whole point. A prefix
            # convention ("HOMEWORK:" means due next meeting) had already
            # dated the line above; a deadline the teacher typed on the next
            # line is a statement, and a statement beats a convention. Left as
            # two rows it was the same work twice, two days apart, with the
            # wrong one on top.
            _, named = classify_line(previous_line, prefixes, links)
            if named:
                titled = named
                supersedes = previous_item
            else:
                named = _names_the_work(previous_line, year_start)
                if named:
                    titled = named
        primary_assignment_url = finish_sequence[3] if finish_sequence else None
        if pending_named_work is not None and (
                _is_detail_line(text) or re.match(r'^(?:was\s+)?due\b', text, re.I)):
            titled, named_links, instructions = pending_named_work
            links = list(links) + [link for link in named_links if link not in links]
            raw_text = ' '.join([*instructions, text])
            assignments = [link for link in named_links
                           if re.search(r'/courses/\d+/assignments/\d+', link.url)]
            if (len(assignments) == 1 and any(
                    re.match(r'^Turn in the \.html file on Canvas with your prompts\b', instruction, re.I)
                    for instruction in instructions)):
                primary_assignment_url = assignments[0].url
        item = _build(titled, raw_text, role, day_resolution, day_label, links,
                      course_key, course_display, course_lookup, meetings,
                      where, source_url, year_start, source, kind,
                      class_date=class_date, week=block_span, day_date=numbered_day_date)
        if item is not None:
            parent_text = _clean(node.get_text(' ', strip=True))
            split_parent = _workbook_weekly_duolingo(parent_text)
            if split_parent and text in split_parent:
                parent_role, parent_cleaned = classify_line(parent_text, prefixes, links)
                parent = _build(parent_cleaned, parent_text, parent_role, day_resolution, day_label, links,
                                course_key, course_display, course_lookup, meetings, where, source_url,
                                year_start, source, kind, class_date=class_date, week=block_span,
                                day_date=numbered_day_date)
                if parent is not None:
                    item.merged_from.append(f'{source}:{parent.item_id}')
            paragraph = _scored_flint_paragraph(raw_text)
            writing = paragraph or _timed_flint_exercise(raw_text)
            if writing:
                numbered = re.search(r'\b(Class|Day)\s+(\d+)\b', day_label, re.I)
                context = (f'{numbered.group(1).title()} {numbered.group(2)}'
                           if numbered else day_label or 'source day unresolved')
                if not numbered or numbered.group(1).lower() == 'day':
                    context += f' / {block_span}'
                identity = hashlib.sha1(f'{course_key}|{source_url}|{context}|{writing.group("name").lower()}'.encode()).hexdigest()
                item.title = f'{writing.group("name")} — {context}'
                item.flags.append('scored_writing_context:' + identity)
                item.finalize()
            if writing and parsed_index + 1 < len(parsed):
                alternatives = []
                for entry in parsed[parsed_index + 1:parsed_index + 17]:
                    next_kind, _, following, following_node = entry
                    if not following.strip():
                        continue
                    if next_kind != 'line' or not re.fullmatch(r'(?:Period\s+[1-7]\s*)+', following, re.I):
                        break
                    found = links_mod.extract_links(following_node, source_url)
                    if not all(re.fullmatch(r'Period\s+[1-7]', link.text.strip(), re.I) for link in found):
                        break
                    alternatives.extend(found)
                if alternatives:
                    item.links.extend(link for link in alternatives if link not in item.links)
                    item.url = source_url or None
            if finish_sequence:
                consumed_lines.update((parsed_index + 1, parsed_index + 2))
            if primary_assignment_url:
                item.url = primary_assignment_url
            item.assigned_date = (day_resolution.when.isoformat()
                                  if day_resolution and day_resolution.when else None)
            for targets, guidance, guidance_links in preparation_guidance:
                book = re.search(r"\bfirst\s+pages\s+of\s+([^.!?]{2,80})", guidance, re.I)
                named = re.search(r"\bessay(?:\s+test)?\s+for\s+(.+?)\s+(?:will be|is)\b",
                                  item.raw_cell or item.title, re.I)
                if book and named and _normalised(book.group(1)) != _normalised(named.group(1)):
                    continue
                if any(target in item.title.lower() for target in targets):
                    if guidance not in (item.detail or ""):
                        item.detail = (item.detail or item.title) + (
                            "\nPreparation guidance (no separate deadline stated): " + guidance)
                    if "source_preparation_guidance" not in item.flags:
                        item.flags.append("source_preparation_guidance")
                    seen = {link.url for link in item.links}
                    item.links.extend(link for link in guidance_links if link.url not in seen)
            if supersedes is not None and supersedes in result.items:
                result.items.remove(supersedes)
            result.items.append(item)
        if item is not None and re.search(r"\b(?:practice|lockdown browser) essay\b", item.title, re.I):
            adjacent_essays = (adjacent_essays + [item])[-2:]
        else:
            adjacent_essays = []
        previous_line = text
        previous_item = item
        pending_named_work = None
        moved = RE_MOVED_CLASS_WORK.search(text)
        if moved:
            # English states two distinct obligations in one bullet: finish
            # the reading today; the Flint paragraph moves to Class 30.
            # Never apply one task's deadline to the other task.
            counted = class_date(int(moved.group('n')))
            day = counted.when if counted else None
            note = (f'"{_clean(moved.group(0))}" on {where}; '
                    + (counted.note if counted and day else 'that class date is unresolved'))
            stamp = meetings.time_on(course_lookup, day) if day else None
            extra_item = _item(_clean(moved.group('title')), text[moved.start():], course_key,
                course_display, stamp.isoformat() if stamp else None,
                day.isoformat() if day else None, note, 'medium' if day else 'low',
                'day_n_exact' if day else 'unresolved', [], links, source_url,
                'due', source=source, kind=kind)
            # Without a timetable both dates are None. The source paragraph
            # contains the writing title, so containment dedupe otherwise
            # erases the separate postponed obligation.
            if item is not None:
                item.flags.extend(['moved_work_component', 'split_target:moved:original'])
            extra_item.flags.extend(['moved_work_component',
                                     f'split_target:moved:class:{moved.group("n")}'])
            extra_item.assigned_date = item.assigned_date if item else None
            extra_item.raw_cell = text
            result.items.append(extra_item)

    # A teacher repeats a standing deadline under every class it covers —
    # [MEASURED] the Membean fortnight appears three times. Same work, same
    # date, same id: one item. (merge.dedupe_docs would also catch these, but
    # an extractor should not hand the same thing over three times.)
    unique: dict = {}
    for item in result.items:
        if item.item_id in unique:
            _retain_conditional_late_window(unique[item.item_id], item)
        else:
            unique[item.item_id] = item
    duplicates = len(result.items) - len(unique)
    result.items = list(unique.values())
    before = len(result.items)
    result.items = _collapse_restatements(result.items)
    flint_handins = {
        (match.group(1), item.points)
        for item in result.items
        if (match := re.fullmatch(r'practice paragraph writing test on Flint — Class ([0-9]+)',
                                  item.title, re.I))
    }
    if flint_handins:
        preview = re.compile(
            r'^Also d\s*uring next Class ([0-9]+), there will be a practice paragraph '
            r'writing test on Flint\s*=\s*([1-9][0-9]{0,2}) points\b', re.I)
        result.items = [
            item for item in result.items
            if not ((match := preview.match(item.raw_cell))
                    and (match.group(1), int(match.group(2))) in flint_handins)
        ]

    duplicates += before - len(result.items)
    _referenced_project_guidance(parsed, result.items)
    _practice_launch_guidance(parsed, result.items, source_url)

    result.diagnostics = {
        "headings": len(result.headings),
        "lines_before_first_heading": skipped_before_first_day,
        "repeated_lines_collapsed": duplicates,
        "where": where,
    }
    return result


# "pts" and "points" are the same word, and a teacher uses both in one
# document. Normalised before comparing, or the restatement check below sees
# two different assignments.
RE_MARK_WORD = re.compile(r"\bpts?\b", re.I)
RE_NOT_WORD = re.compile(r"[^a-z0-9]+")


def _normalised(title: str) -> str:
    return RE_NOT_WORD.sub(" ", RE_MARK_WORD.sub(
        "points", (title or "").lower())).strip()


# How far apart two identical names may be and still be one assignment.
RESTATED_DAYS = 2


def date_mod_date(iso: str | None):
    """An ISO date string as a date, or None. Local helper — no clock."""
    try:
        return date.fromisoformat(iso) if iso else None
    except ValueError:
        return None


def _retain_conditional_late_window(first, repeated):
    """Keep the missing-student notice, never turn it into a universal extension."""
    # [MEASURED] 2026-11-08: same-ID final repeats lost the late-only footer.
    if (first.course_key != repeated.course_key or first.due != repeated.due
            or not first.due or repeated.assigned_date != first.due_date):
        return
    canonical = lambda value: links_mod.strip_tracking(links_mod.unwrap_google(value or ''))
    own = canonical(first.url)
    if (own != canonical(repeated.url) or not re.fullmatch(
            r'https://[^/?#]+/courses/[0-9]+/assignments/[0-9]+', own)):
        return
    clock = r'(?:1[0-2]|0?[1-9]):[0-5][0-9] [AP]M'
    notice = re.search(
        r'\bWas due today at ' + clock + r'\. Not submitted yet\? Submit by '
        + clock + r' tonight\. Grading starts tomorrow\.\Z', repeated.raw_cell, re.I)
    if not notice:
        return
    original_clock = deadline_clock(notice.group(), 'Was due today')
    if not original_clock or original_clock.strftime('%H:%M') != first.due[11:16]:
        return
    if notice.group() not in first.detail:
        first.detail += '\nConditional late submission (original deadline unchanged): ' + notice.group()
    if 'conditional_late_window' not in first.flags:
        first.flags.append('conditional_late_window')
        first.date_note += '; conditional late submission instructions retained; original deadline unchanged'


def _collapse_restatements(items: list) -> list:
    """One assignment the teacher wrote more than once, worded differently.

    [MEASURED] 2026-09-02, AI Frontiers' doc names a single project four
    times, in four cells:

        100 points. Due Friday, Sep. 25, 11:59 PM. This is the project …
        , due Sep 26.
        100 points, due Sep 26
        100 pts, due Sep 26

    Three of those share a date and are the same piece of work. `merge`'s 0.7
    Jaccard threshold scores "points" against "pts" at 0.67 and keeps both,
    and the fragment beginning with a comma is a line whose link text was
    lifted out of it. A board that lists one project three times is a board he
    stops reading.

    Deliberately narrow: same date, and one title must CONTAIN another once
    abbreviations are normalised. Two assignments that merely resemble each
    other are never collapsed, because losing real work is the worse error —
    and the longest wording is the one kept, since it carries the most detail.
    """
    by_date: dict = {}
    for item in items:
        split_target = next((f for f in item.flags if f.startswith(('split_target:', 'scored_writing_context:', 'reading_discussion_context:', 'below_subtask_context:', 'exit_ticket_assignment:'))), None)
        key = (item.due_date, split_target) if split_target else item.due_date
        by_date.setdefault(key, []).append(item)

    kept: list = []
    def name(item):
        if 'scored_writing_activity' in (item.flags or []):
            return _normalised(item.title)
        if 'numbered_essay_target' in (item.flags or []):
            return _normalised(item.title)
        # [MEASURED] 2026-10-30: the English contest is restated after a
        # congratulatory sentence. Compare the full work sentence, since the
        # 110-character display title can cut off its identifying words.
        # "Optional" changes obligation, not identity; keep the richer item.
        full = title_of(item.detail or item.title)
        return _normalised(re.sub(r"\boptional\s+", "", full, flags=re.I))

    for _date, group in by_date.items():
        chosen: list = []
        for item in sorted(group, key=lambda i: (
                "stated_category" in (i.flags or []),
                bool(re.search(r"\boptional\b", i.detail or i.title, re.I)),
                len(i.title or "")), reverse=True):
            text = name(item)
            display = _normalised(item.title)
            twin = next((other for other in chosen if text and (
                text in name(other) or (display and display in _normalised(other.title))
            )), None)
            if twin is not None:
                if RE_MEMBEAN_ENROLLMENT_TRAINING.match(item.raw_cell):
                    twin.links.extend(link for link in item.links if link not in twin.links)
                continue
            chosen.append(item)
        kept.extend(chosen)

    # The same NAME on two dates a day or two apart is one assignment the
    # teacher dated twice, not two assignments. [MEASURED] 2026-09-03: AI
    # Frontiers writes "Side Hustle Proposal / 100 points. Due Friday, Sep.
    # 25" in one week's cell and "Side Hustle Proposal / 100 points, due Sep
    # 26" in another. Both are real lines; only one is a deadline.
    #
    # The EARLIER date wins, which is the rule COUNT 27 settled for a
    # different conflict and for the same reason: early is an annoyance, late
    # is a missed assignment. Identical names only — anything looser starts
    # deleting work that merely resembles other work.
    by_name: dict = {}
    for item in kept:
        by_name.setdefault(_normalised(item.title), []).append(item)
    dropped: set = set()
    for _name, group in by_name.items():
        if len(group) < 2:
            continue
        dated = sorted((i for i in group if i.due_date),
                       key=lambda i: i.due_date)
        for later in dated[1:]:
            first = date_mod_date(dated[0].due_date)
            this = date_mod_date(later.due_date)
            if first and this and (this - first).days <= RESTATED_DAYS:
                dropped.add(id(later))
    kept = [i for i in kept if id(i) not in dropped]
    return [item for item in items if item in kept]


def title_of(text: str) -> str:
    """The part of a line that names the work, without the teacher's aside."""
    line = _clean(text)
    # A congratulation is context, but the following sentence can name work.
    # Only peel a complete opening sentence when the remainder is actionable.
    if line.lower().startswith("congratulations "):
        parts = re.split(r"(?<=[.!?])\s+", line, maxsplit=1)
        if len(parts) == 2 and RE_DUE_IN_LINE.search(parts[1]):
            line = parts[1]
    match = RE_ASIDE.search(line)
    if match and match.start() >= MIN_TITLE_BEFORE_ASIDE:
        return line[:match.start()].rstrip(" ,;:-–")
    return line


def _item(cleaned, raw, course_key, course_display, due, due_date, note,
          confidence, extractor, flags, links, source_url, role,
          source: str = "canvas_page", kind: str = "course homepage"):
    """The one place a prose Item is constructed."""
    from sillybus.docs.items import clean_title

    if 'class-start clock unavailable without timetable' in note:
        due = None
        flags = [*flags, 'needs_date_confirmation', 'deadline_clock_unstated']

    paragraph = _scored_flint_paragraph(raw)
    timed_exercise = _timed_flint_exercise(raw)
    category = ('practice' if timed_exercise else 'writing' if paragraph else
                assessment_category(cleaned) if role == "assessment" else None)
    if category and category != "neutral":
        flags = [*flags, "stated_category"]
    if paragraph or timed_exercise:
        flags = [*flags, 'scored_writing_activity']
    item = Item(
        source=source, course_key=course_key, course=course_display,
        title=clean_title(title_of(cleaned)), detail=_clean(raw),
        raw_cell=_clean(raw), kind=kind, category=category or "neutral",
        due=due, due_date=due_date, all_day=False, date_note=note,
        confidence=confidence, extractor=extractor,
        url=links_mod.best_link(links) or source_url or None, links=links,
        flags=flags)
    if paragraph:
        item.points = int(paragraph.group('points')) if paragraph.group('points') else None
    scored_test = RE_SCORED_NRI_TEST.match(raw) if role == 'assessment' else None
    if scored_test is None and role == 'assessment':
        scored_test = re.match(
            r'^The lockdown browser [^.!?;=]{1,80} paragraph test is today'
            r'\s*=\s*([1-9][0-9]{0,2}) points?\b', raw, re.I)
    scored_test = scored_test or RE_ANNOTATED_BOOK_CHECK.fullmatch(raw)
    printed_quotes = RE_PRINTED_QUOTES.match(raw)
    stated_points = scored_test or printed_quotes
    if stated_points:
        item.points = int(stated_points.group(1))
    nri_lessons = RE_NRI_LESSON_SETUP.fullmatch(raw) or RE_NRI_LESSON_DEADLINE.match(raw)
    if nri_lessons:
        item.points = int(nri_lessons.group('points'))
    enrollment = RE_MEMBEAN_ENROLLMENT_TRAINING.match(raw)
    training = RE_MEMBEAN_SCORED_TRAINING.match(raw)
    if enrollment:
        item.points = int(enrollment.group(2))
        item.url = source_url or None
    elif training:
        item.points = int(training.group(1))
    scored_quiz = RE_SCORED_CLASS_QUIZ.match(raw) if role == 'assessment' else None
    if scored_quiz:
        item.points = int(scored_quiz.group('points'))
        item.url = source_url or None
    if item.points is None:
        # A task-owned scored deadline sentence is not a neighboring rubric.
        own_points = re.findall(r'(?:^|[.!?]\s+)([1-9][0-9]{0,2})\s+points?(?:,|\.)\s+due\b',
                                item.raw_cell, re.I)
        all_points = re.findall(r'\b[0-9]+\s+points?\b', item.raw_cell, re.I)
        if len(own_points) == len(all_points) == 1:
            item.points = int(own_points[0])
    if _today_graded_practice_essay(raw):
        primary = [link for link in links if not re.fullmatch(
            r'Period\s+[1-7]', link.text.strip(), re.I)]
        item.url = links_mod.best_link(primary) or source_url or None
    return item.finalize()


def _build(cleaned: str, raw: str, role: str, resolution, heading: str,
           links: list, course_key: str, course_display: str, course_lookup: str,
           meetings, where: str, source_url: str,
           year_start: int | None = None, source: str = "canvas_page",
           kind: str = "course homepage", class_date=None,
           week=None, day_date=None) -> Item | None:
    """One classified line -> one Item, or None when it is not worth showing."""
    if not cleaned or len(cleaned) < 3:
        return None
    if resolution is None:
        resolution = dates_mod.Resolution(
            None, dates_mod.NOTES["page_unresolved"].format(
                where=where, heading=dates_mod.quote_label(heading) or "no heading"),
            "unresolved", "low")

    when = resolution.when
    note = resolution.note
    extractor = resolution.extractor
    confidence = resolution.confidence
    flags = list(resolution.flags)

    if (when is None and week and (week[1] - week[0]).days <= 6
            and _weekly_duolingo(raw) and deadline_clock(raw, 'by Friday') is not None):
        target = week[0] + timedelta(days=(4 - week[0].weekday()) % 7)
        if target <= week[1]:
            weekly_note = (f'Friday in the explicitly bounded weekly Duolingo source block '
                           f'{week[0].isoformat()}–{week[1].isoformat()}; date inferred from source week')
            moment, weekly_note = deadline_moment(target, raw, 'by Friday', meetings, course_lookup, weekly_note)
            return _item(cleaned, raw, course_key, course_display, moment.isoformat(),
                         target.isoformat(), weekly_note, 'medium', 'weekday_snapped',
                         [*flags, 'weekly_source_week'], links, source_url, role, source=source, kind=kind)

    if role == 'timed_class_exercise' and _timed_flint_exercise(raw):
        return _item(cleaned, raw, course_key, course_display, None, None,
                     f'{where}: classroom practice; timer minutes are duration, no submission deadline stated',
                     'medium', 'unresolved', [*flags, 'deadline_unstated'],
                     links, source_url, role, source=source, kind=kind)

    paragraph = _scored_flint_paragraph(raw)
    if (role == 'scored_paragraph' and paragraph
            and paragraph.groupdict().get('today')):
        # [MEASURED] 2026-11-08: named book/page paragraph states today,
        # not midnight or an exact class clock. Section date may be unknown.
        moment = meetings.time_on(course_lookup, when) if when else None
        return _item(cleaned, raw, course_key, course_display,
                     moment.isoformat() if moment else None, when.isoformat() if when else None,
                     note + '; graded in-class paragraph today; exact class clock unavailable'
                     if moment is None else note + '; graded in-class paragraph today; class start inferred from timetable',
                     confidence if when else 'low', extractor, [*flags, 'deadline_clock_unstated']
                     if moment is None else flags, links, source_url, role, source=source, kind=kind)

    if role == 'scored_paragraph' and paragraph and not paragraph.group('tail').strip():
        return _item(cleaned, raw, course_key, course_display, None, None,
                     f'{where}: writing activity; stated minutes are duration, no submission deadline stated',
                     'medium', 'unresolved', [*flags, 'deadline_unstated'],
                     links, source_url, role, source=source, kind=kind)

    if (role == 'assessment' and (_today_lockdown_essay(raw) or _today_graded_practice_essay(raw))
            and _lockdown_essay_change(raw) == 'deferred'
            and (stated_deadline(raw, year_start) is None
                 or re.search(r'\b(?:was|were|used to be|no longer|not)\s+due\b', raw, re.I))):
        return _item(cleaned, raw, course_key, course_display, None, None,
                     f'{where}: essay explicitly deferred; replacement deadline needs confirmation',
                     'low', 'unresolved', [*flags, 'needs_date_confirmation'],
                     links, source_url, role, source=source, kind=kind)

    if role == 'team_room_survey':
        return _item(cleaned, raw, course_key, course_display, None, None,
                     f'{where}: required in-class survey; activity block is not a stated submission cutoff; completion unknown',
                     'medium', 'unresolved', [*flags, 'deadline_unstated'],
                     links, source_url, role, source=source, kind=kind)

    if role == 'named_notes':
        return _item(cleaned, raw, course_key, course_display, None, None,
                     f'{where}: named partner notes activity; no submission deadline stated; completion unknown',
                     'medium', 'unresolved', [*flags, 'deadline_unstated'],
                     links, source_url, role, source=source, kind=kind)

    closed = re.search(r'\bclosed\s+(?:last\s+)?(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\b', raw, re.I)
    missing = re.search(r'\bif\s+yours\s+is\s+(?:still\s+)?not\s+in\b', raw, re.I)
    new_deadline = re.search(r'\b(?:due|by|before|until|extend\w*|reopen\w*|today|tonight|tomorrow)\b', raw, re.I)
    assignment_links = [link for link in links if re.search(r'/courses/\d+/assignments/\d+(?:[?#]|$)', link.url)]
    # [MEASURED] 2026-11-08: missing Friday lab is catch-up, not a new due date.
    missing_lab = (len(assignment_links) == 1 and re.fullmatch(
        r"Didn't turn in (?:Monday|Tuesday|Wednesday|Thursday|Friday)'s lab yet\? "
        r'Finish it first: ' + re.escape(assignment_links[0].text), raw, re.I))
    if missing_lab:
        reminder = _item(assignment_links[0].text, raw, course_key, course_display,
                         None, None, f'{where}: conditional missing-lab reminder; '
                         'original deadline not restated; no new deadline assigned; completion unknown',
                         'low', 'unresolved', [*flags, 'conditional_missing_work'],
                         links, source_url, 'due', source=source, kind=kind)
        reminder.url = assignment_links[0].url
        if when is not None:
            from sillybus.models import make_item_id
            reminder.merged_from.append(f'{source}:' + make_item_id(
                source, course_key, reminder.title, when.isoformat()))
        return reminder

    bare_closed = (len(assignment_links) == 1 and re.match(
        rf'^(?:The\s+)?{re.escape(assignment_links[0].text)}\s+is\s+closed[.!](?:\s|$)',
        raw, re.I))
    closed = closed or bare_closed
    if (closed and missing and re.search(r'\bturn\s+it\s+in\b', raw, re.I)
            and not new_deadline and len(assignment_links) == 1):
        reminder = _item(assignment_links[0].text, raw, course_key, course_display,
                     None, None, f'{where}: closed assignment; conditional missing-work reminder. '
                     'The original deadline is not restated; no new deadline assigned.',
                     'low', 'unresolved', [*flags, 'closed_assignment_reminder'],
                     links, source_url, 'due', source=source, kind=kind)
        reminder.url = assignment_links[0].url
        if bare_closed and when is not None:
            from sillybus.models import make_item_id
            old_id = make_item_id(source, course_key, reminder.title, when.isoformat())
            reminder.merged_from.append(f'{source}:{old_id}')
        return reminder

    # A numbered-day deadline names a different source heading, not the day
    # this instruction was posted. Missing/conflicting scope stays honest.
    by_day = RE_DUE_DAY_N.search(raw or "")
    if by_day and stated_deadline(raw, year_start) is None:
        tail_clause = re.split(r'[.!?;]', (raw or "")[by_day.end():], maxsplit=1)[0]
        qualified = re.search(
            r"\b(?:next|following|previous|prior|last|another)\s+(?:block|week)\b|"
            r"\b(?:of|in)\s+(?:the\s+)?week\s+\d+\b|"
            r"\bof\s+(?:the\s+)?block\s+[a-z0-9]+\b", tail_clause, re.I)
        # A weekday-only extension has no unambiguous source week here. Keep
        # it unresolved rather than silently discard the extension wording.
        qualified = qualified or re.search(r'\bextend(?:ed|sion)\b', (raw or '')[by_day.end():], re.I)
        target = day_date(int(by_day.group(1))) if day_date and not qualified else None
        phrase = _clean(by_day.group(0))
        if target is None:
            return _item(cleaned, raw, course_key, course_display, None, None,
                         f"'{phrase}' on {where}; no unique explicitly dated target in this block",
                         "low", "unresolved", [*flags, "needs_date_confirmation"],
                         links, source_url, role, source=source, kind=kind)
        clock = deadline_clock(raw, phrase)
        moment = datetime.combine(target, clock, tzinfo=timezones.zone()) if clock else None
        note = (f"'{phrase}' on {where} points to Day {by_day.group(1)} explicitly dated {target.isoformat()} in this block; "
                + (f"deadline clock {clock.strftime('%H:%M')} from the line itself"
                   if clock else "exact deadline clock unstated"))
        return _item(cleaned, raw, course_key, course_display,
                     moment.isoformat() if moment else None, target.isoformat(), note,
                     "high", "day_n_exact", flags, links, source_url, role, source=source, kind=kind)

    named_next_week = re.search(r"\bdue\s+(?:on\s+)?(?P<weekday>(?:mon|tues?|wed|wednes|thur?s?|fri|sat|sun)[a-z]*)"
                                r"\s+next\s+week\b", raw or "", re.I)
    if named_next_week and when is not None:
        weekday = _weekday_in(named_next_week.group("weekday"))
        if weekday is not None:
            day = when - timedelta(days=when.weekday()) + timedelta(days=7 + weekday)
            phrase = _clean(named_next_week.group(0))
            relative_note = (f'"{phrase}" in the line itself, counted from the source day '
                             f'{when.isoformat()} — {day.isoformat()}')
            moment, relative_note = deadline_moment(day, raw, phrase, meetings, course_lookup, relative_note)
            return _item(cleaned, raw, course_key, course_display, moment.isoformat(), day.isoformat(),
                         relative_note, 'medium', 'relative_to_posted', flags, links, source_url,
                         role, source=source, kind=kind)

    # [MEASURED] 2026-10-31, Spanish Day 5: "2B Vocab Quiz next week"
    # became due on Day 5. A week is a range, not a stated meeting/day.
    # Preserve the work without inventing which day next week the quiz is.
    first_sentence = re.split(r'(?<=[.!?])\s+', cleaned, maxsplit=1)[0]
    if (when is not None and re.search(r'\bnext\s+week\b', first_sentence, re.I)
            and stated_deadline(raw, year_start) is None
            and not RE_DUE_CLASS_N.search(raw)):
        monday = when - timedelta(days=when.weekday()) + timedelta(days=7)
        note = (f'the line says "next week", counted from {when.isoformat()}: '
                f'{monday.isoformat()} through {(monday + timedelta(days=6)).isoformat()}; '
                'no exact due day was stated')
        return _item(cleaned, raw, course_key, course_display, None, None, note,
                     'low', 'unresolved', [*flags, 'date_range', 'needs_date_confirmation'],
                     links, source_url, role, source=source, kind=kind)

    # "due Class 22": a deadline the line names by class number is the date of
    # that class on his timetable — counted, so medium confidence, with the
    # count in the note. It beats the heading the line sits under, which is
    # only the day the work was SET.
    by_class = None
    if class_date is not None:
        by_class = RE_DUE_CLASS_N.search(raw or "")
        if by_class is None and (role == "assessment" or RE_GRADED_ESSAY_SCHEDULE.match(cleaned)):
            by_class = RE_SCHEDULED_CLASS_N.search(raw or "")
    if by_class and stated_deadline(raw, year_start) is None:
        counted = class_date(int(by_class.group(1)))
        if counted is not None and counted.when is not None:
            when = counted.when
            note = (f"'{_clean(by_class.group(0))}' in the line itself — "
                    f"{counted.note}")
            clock_phrase = _clean(by_class.group(0))
            # A same-sentence "Finish by ..." after the score still states
            # this task's clock; do not carry office hours across a full stop.
            finish = re.match(r"^[^.!?;]{0,80}?\b((?:finish|submit|turn in)\s+by)\b",
                              (raw or "")[by_class.end():], re.I)
            if deadline_clock(raw, clock_phrase) is None and finish:
                clock_phrase = finish.group(1)
            moment, note = deadline_moment(
                when, raw, clock_phrase, meetings, course_lookup, note)
            return _item(cleaned, raw, course_key, course_display, moment.isoformat(),
                         when.isoformat(), note, "medium", "day_n_exact", flags, links,
                         source_url, role, source=source, kind=kind)

        if RE_SCHEDULED_CLASS_N.search(raw or ""):
            # A specific future class is not the posting class when the
            # timetable cannot resolve it. Keep the work and ask for its date.
            return _item(cleaned, raw, course_key, course_display, None, None,
                         f"'{_clean(by_class.group(0))}' in the line itself; that class date is unresolved",
                         "low", "unresolved", [*flags, "needs_date_confirmation"],
                         links, source_url, role, source=source, kind=kind)

    # A deadline the line states for itself wins outright, and is never shifted
    # to the next class — it already IS the deadline. When its first deadline
    # is a weekday and a dated one follows, the weekday is the nearer one.
    own = weekday_deadline_first(raw, week, when, allow_standalone=True)
    if own is not None:
        nearer, phrase, monday = own
        note = dates_mod.NOTES["line_deadline"].format(phrase=phrase)
        note += f", counted from {where} (the week of {monday:%b} {monday.day})"
        moment, note = deadline_moment(nearer, raw, phrase, meetings, course_lookup, note)
        return _item(cleaned, raw, course_key, course_display, moment.isoformat(),
                     nearer.isoformat(), note, "medium", "absolute", flags, links,
                     source_url, role, source=source, kind=kind)
    own = stated_deadline(raw, year_start)
    if own is not None:
        when, phrase = own
        note = dates_mod.NOTES["line_deadline"].format(phrase=phrase)
        extractor, confidence = "absolute", "high"
        moment, note = deadline_moment(when, raw, phrase, meetings, course_lookup, note)
        return _item(cleaned, raw, course_key, course_display, moment.isoformat(),
                     when.isoformat(), note, confidence, extractor, flags, links,
                     source_url, role, source=source, kind=kind)

    relative = RE_RELATIVE_DEADLINE.search(raw or '')
    if relative is not None and when is not None:
        phrase = _clean(relative.group(0))
        day = when + timedelta(days=relative.group('day').lower() == 'tomorrow')
        note = (f'"{phrase}" in the line itself, counted from '
                f'the source day {when.isoformat()} — {day.isoformat()}')
        moment, note = deadline_moment(day, raw, phrase, meetings, course_lookup, note)
        return _item(cleaned, raw, course_key, course_display, moment.isoformat(),
                     day.isoformat(), note, 'medium', 'relative_to_posted', flags,
                     links, source_url, role, source=source, kind=kind)

    next_class = RE_DUE_NEXT_CLASS.search(raw or "")
    if next_class and when is not None:
        following = meetings.next_after(course_lookup, when)
        phrase = _clean(next_class.group(0))
        next_note = (f'"{phrase}" in the line itself, counted from the source day '
                     f'{when.isoformat()}')
        if following is None:
            return _item(cleaned, raw, course_key, course_display, None, None,
                         next_note + '; no following meeting is available', 'low', 'unresolved',
                         [*flags, 'needs_date_confirmation'], links, source_url, role,
                         source=source, kind=kind)
        moment, next_note = deadline_moment(following, raw, phrase, meetings, course_lookup,
                                            next_note + ' — ' + following.isoformat())
        return _item(cleaned, raw, course_key, course_display, moment.isoformat(),
                     following.isoformat(), next_note, 'medium', 'relative_to_posted', flags,
                     links, source_url, role, source=source, kind=kind)

    # An end-of-class hand-in is not due at class START (or the homework
    # default's next meeting). Only terminal obligation wording qualifies.
    # This exact scored activity states its deadline before link/point guidance.
    embedded_class_end = paragraph and re.fullmatch(r'by the end of class today', paragraph.group('tail'), re.I)
    end_text = 'Due by the end of class' if embedded_class_end or role == 'class_discussion' else raw
    end_class = re.search(
        r'(?P<phrase>\b(?:due|submit|turn\s+in)\s+(?:(?:by|at)\s+)?'
        r'(?:the\s+)?end\s+of\s+(?:this\s+|(?P<next>next)\s+)?class\b)'
        r'(?:\s*,?\s*(?:(?:at|by|before|@)\s*)?'
        r'(?:noon|midnight|(?:1[0-2]|0?[1-9])(?::[0-5]\d)?\s*[ap]\.?\s*m\.?))?'
        r'\s*[.!]?\s*\Z', end_text, re.I)
    if end_class:
        phrase = paragraph.group('tail') if embedded_class_end else _clean(end_class.group('phrase'))
        end_note = f"'{phrase}' on {where}; "
        if re.search(r"\b(?:not|never|isn't|isn’t|aren't|aren’t)\s*(?:yet\s*)?\Z",
                     raw[:end_class.start()], re.I):
            return _item(cleaned, raw, course_key, course_display, None, None,
                         end_note + 'this deadline is negated; actual deadline unstated',
                         'low', 'unresolved', [*flags, 'needs_date_confirmation'],
                         links, source_url, role, source=source, kind=kind)
        if end_class.group('next'):
            source_day = when
            source_meeting = meetings.meeting_on(course_lookup, source_day) if source_day else None
            when = meetings.next_after(course_lookup, source_day) if source_meeting else None
            end_note += (f'counted from source class {source_day.isoformat()}; '
                         if source_day else 'source class date unresolved; ')
            if when is None:
                end_note += 'source timetable anchor or following meeting unavailable; '
        clock = deadline_clock(raw, phrase)
        earlier_due = RE_DUE_IN_LINE.search(raw)
        if earlier_due and earlier_due.start() < end_class.start():
            clock = deadline_clock(raw, _clean(earlier_due.group(0))) or clock
        moment = None
        if when is not None and clock is not None:
            moment = datetime.combine(when, clock, tzinfo=timezones.zone())
            end_note += f"deadline clock {clock.strftime('%H:%M')} from the line itself"
        elif when is not None:
            anchor = meetings.meeting_on(course_lookup, when)
            candidates = [m for m in meetings.meetings
                          if anchor and m.course_key == anchor.course_key and m.date == when]
            valid = candidates and all(
                isinstance(m.start, datetime) and isinstance(m.end, datetime)
                and m.start.tzinfo is not None and m.end.tzinfo is not None
                and m.end > m.start and m.start.date() == when
                and m.end.date() == when for m in candidates)
            ends = {m.end for m in candidates} if valid else set()
            if len(ends) == 1:
                moment = next(iter(ends))
                end_note += f"timetable-derived class end {moment.strftime('%H:%M')} on {when.isoformat()}"
            else:
                end_note += f"source class date {when.isoformat()}; unique timetable end unavailable, exact clock unstated"
        else:
            end_note += ('target class date unresolved; '
                         + (f'line states {clock.strftime("%H:%M")}, no date assigned'
                            if clock else 'exact end clock unstated'))
        return _item(cleaned, raw, course_key, course_display,
                     moment.isoformat() if moment else None, when.isoformat() if when else None,
                     end_note, 'medium' if moment else 'low', 'relative_to_posted' if when else 'unresolved',
                     flags if moment else [*flags,
                                           *(['deadline_clock_unstated'] if clock is None else []),
                                           *(['needs_date_confirmation'] if when is None else [])],
                     links, source_url, role, source=source, kind=kind)

    if (re.match(r'^On the day of your presentation, final slideshows are due\b', raw, re.I)
            and re.search(r'\bAt the start of class on your presentation day, you must email slides\b', raw, re.I)
            and re.search(r'\bPDF\b', raw, re.I)):
        return _item(cleaned, raw, course_key, course_display, None, None,
                     f'{where}: slides due at the start of the student’s own presentation class; '
                     'presentation day/team unresolved, not the posting class deadline',
                     'low', 'unresolved', [*flags, 'own_presentation_day', 'needs_date_confirmation'],
                     links, source_url, role, source=source, kind=kind)

    if role == 'scored_paragraph':
        return _item(cleaned, raw, course_key, course_display, None, None,
                     f'{where}: writing deadline stated but unresolved; no posting-class deadline assigned',
                     'low', 'unresolved', [*flags, 'needs_date_confirmation'],
                     links, source_url, role, source=source, kind=kind)

    # Homework is set on the day and wanted at the next class — the same rule
    # the doc extractor uses, so a page and a doc never disagree about it.
    if role == "homework" and when is not None:
        following = meetings.next_after(course_lookup, when)
        presentation = re.search(r'\bwill present on Day\s*(\d+)\b', raw, re.I)
        supplies = re.search(r'\bbring\b[^.!?]{0,100}\bday\s*(\d+)\s+at the latest\b', raw, re.I)
        if (following is None and presentation and supplies
                and presentation[1] != supplies[1]):
            unresolved = _item(cleaned, raw, course_key, course_display, None, None,
                               f'{note}; assigned {when.isoformat()}; different class-day obligations '
                               'need timetable confirmation, not a posting-day deadline',
                               'low', 'unresolved', [*flags, 'needs_date_confirmation'],
                               links, source_url, role, source=source, kind=kind)
            unresolved.assigned_date = when.isoformat()
            # Preserve the old posting-day identity for completion reconciliation.
            from sillybus.models import make_item_id
            unresolved.merged_from.append(f'{source}:' + make_item_id(
                source, course_key, unresolved.title, when.isoformat()))
            return unresolved
        if following is not None:
            shift = dates_mod.NOTES["page_homework"].format(
                assigned=f"{when:%b %d}", where=where,
                heading=dates_mod.quote_label(heading))
            # A note that explains a correction — a weekday that disagreed with
            # the date, a day counted forward, a date that is not a class day —
            # is the only record of why this item sits where it does. Replacing
            # it with the shift template threw that away, so the two are joined
            # instead (the same thing items.py does for a doc row).
            corrected = bool(flags) or resolution.extractor != "absolute"
            # When the first half already explains how the date was found,
            # repeating the heading and the source is 150 wasted characters —
            # see NOTE_LABEL_CHARS. Say only what the shift adds.
            note = (f"{note}; set then, so due at the next class" if corrected
                    else shift)
            when = following

    if role == 'assessment' and RE_SCORED_CLASS_QUIZ.match(raw):
        return _item(cleaned, raw, course_key, course_display, None,
                     when.isoformat() if when else None,
                     f'{note}. Quiz time unstated.', confidence, extractor, flags,
                     links, source_url, role, source=source, kind=kind)

    due = due_date = None
    if when is not None:
        # A time-only deadline ("Classwork, due at midnight") uses the
        # dated source heading, but its clock outranks the class start.
        due_phrase = RE_DUE_IN_LINE.search(raw)
        moment, note = deadline_moment(when, raw,
                                      due_phrase.group(0) if due_phrase else "",
                                      meetings, course_lookup, note)
        due, due_date = moment.isoformat(), when.isoformat()

    return _item(cleaned, raw, course_key, course_display, due, due_date, note,
                 confidence, extractor, flags, links, source_url, role,
                 source=source, kind=kind)


# ---------------------------------------------------------------------------
# announcements
#
# A teacher's announcement is where "orally communicated" homework lands when
# they remember to write it down. [MEASURED] 2026-09-01, Honors Biology:
#
#   title "Quiz Today"
#   body  "…Reminder that you have a quiz today on the patterns of life
#          textbook and lecture content… Also, your measurements worksheet is
#          due today in class. ALL late work will receive a 50%…"
#
# Two items, and both need the POSTED date to mean anything: "today" is only a
# date relative to when it was written. So an announcement item must carry a
# date phrase of its own — no phrase, no item. Without that rule every "late
# work is 50%" policy note becomes an undated task, and the board fills with
# things that are not work.

RE_DUE_PHRASE = re.compile(r"\b(due|turn in|turned in|hand in|handed in|submit|"
                           r"bring|by the end of)\b", re.I)
RE_SENTENCE = re.compile(r"(?<=[.!?])\s+")


def _sentences(text: str) -> list[str]:
    return [s.strip() for s in RE_SENTENCE.split(_clean(text)) if s.strip()]


RE_CALENDAR_DATE = re.compile(
    r"\b\d{4}-\d{2}-\d{2}\b|\b\d{1,2}/\d{1,2}\b|"
    r"\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s+\d{1,2}\b", re.I)


def extract_announcement(title: str, message_html: str, posted: date,
                         course_key: str, course_display: str, course_lookup: str,
                         meetings, url: str = "", profile=None) -> ProseResult:
    """Work stated in one announcement. `posted` anchors every relative date."""
    from bs4 import BeautifulSoup

    from sillybus import quickadd
    from sillybus.docs.items import clean_title

    result = ProseResult()
    prefixes = compile_prefixes(profile)
    soup = BeautifulSoup(message_html or "", "lxml")
    body = soup.body or soup
    links = links_mod.extract_links(body, url)
    posted_label = f"{posted:%b %d}"
    title = _clean(title)

    def add(text: str, phrase: str | None, category: str | None):
        when, how = (quickadd.parse_when(phrase, posted, meetings, course_lookup)
                     if phrase else (None, ""))
        if not when:
            return False
        note = dates_mod.NOTES["announcement_dated"].format(
            phrase=phrase, title=title[:60], posted=posted_label)
        stamp = meetings.time_on(course_lookup, date.fromisoformat(when))
        moment = stamp if stamp else datetime.combine(
            date.fromisoformat(when), time(23, 59), tzinfo=timezones.zone())
        item = Item(
            source="canvas_page", course_key=course_key, course=course_display,
            title=clean_title(title_of(text)), detail=_clean(text),
            raw_cell=_clean(text),
            kind="announcement", category=category or "neutral",
            due=moment.isoformat(), due_date=when, all_day=False,
            date_note=note, confidence="medium",
            # A calendar date said outright is stated; a weekday or "next
            # class" is counted from the day it was posted — inferred.
            extractor="absolute" if RE_CALENDAR_DATE.search(phrase or "") else "relative_to_posted",
            url=links_mod.best_link(links) or url or None, links=links,
            flags=(["from_announcement", "stated_category"]
                   if category and category != "neutral" else ["from_announcement"]))
        result.items.append(item.finalize())
        return True

    def phrase_in(text: str) -> str | None:
        match = quickadd.WHEN.search(text or "")
        return match.group("when") if match else None

    # 1. the title, when the title is the news ("Quiz Today", "HW due Friday")
    title_bare = title.lstrip("*•-–— \t")
    title_phrase = phrase_in(title)
    claimed = False
    if title_phrase and not RE_NOT_GRADED.search(title):
        if RE_ASSESSMENT_LEAD.match(title_bare):
            claimed = add(title, title_phrase, assessment_category(title_bare))
        elif RE_DUE_PHRASE.search(title) or (prefixes["homework"]
                                             and prefixes["homework"].match(title)):
            claimed = add(title, title_phrase, None)

    # Explicit sibling list tasks are separate obligations. Flattening an
    # entire announcement joined a quiz and two worksheets into one quiz.
    # Keep nested instructions with their parent; leave single-task/resource
    # lists and ordinary paragraph context on the existing sentence path.
    list_units = set()
    separator = "\u241e"
    for listing in list(body.find_all(["ul", "ol"])):
        if listing.find_parent(["ul", "ol"]):
            continue
        units = [_clean(li.get_text(" ", strip=True))
                 for li in listing.find_all("li", recursive=False)]
        dated_work = 0
        for unit in units:
            unit_role, _ = classify_line(unit, prefixes, links)
            if (phrase_in(unit) and not RE_NOT_GRADED.search(unit)
                    and (unit_role in ("homework", "due", "assessment")
                         or RE_DUE_PHRASE.search(unit))):
                dated_work += 1
        if dated_work >= 2:
            list_units.update(units)
            listing.replace_with(separator + separator.join(units) + separator)
    sentences = []
    for chunk in body.get_text(" ", strip=True).split(separator):
        cleaned_chunk = _clean(chunk)
        sentences.extend([cleaned_chunk] if cleaned_chunk in list_units
                         else _sentences(chunk))

    # 2. body units that name work AND name when
    for sentence in sentences:
        if RE_NOT_GRADED.search(sentence):
            continue
        role, cleaned = classify_line(sentence, prefixes, links)
        category = assessment_category(sentence) if role == "assessment" else None
        if role not in ("homework", "due", "assessment"):
            if not RE_DUE_PHRASE.search(sentence):
                continue
            cleaned = sentence
            # a quiz/test named anywhere in a sentence that also states a
            # deadline is the subject of that sentence often enough to keep,
            # and the whole sentence is shown either way
            if re.search(r"\b(quiz|test|exam)\b", sentence, re.I):
                category = assessment_category(sentence)
                if category == "neutral":
                    category = "test" if re.search(r"\b(test|exam)\b", sentence,
                                                   re.I) else "quiz"
        phrase = phrase_in(sentence)
        if not phrase:
            continue
        if claimed and title_phrase == phrase and RE_ASSESSMENT_LEAD.match(title_bare) \
                and category in ("quiz", "test"):
            continue          # the title already said this
        add(cleaned or sentence, phrase, category)

    result.diagnostics = {"where": "an announcement", "title": title[:60]}
    return result
