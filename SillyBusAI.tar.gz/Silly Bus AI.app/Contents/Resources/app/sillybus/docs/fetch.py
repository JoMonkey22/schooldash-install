"""Fetching course docs. Published docs are cookieless httpx — no browser.
Private docs need the session and are opt-in only. Raw HTML is cached at
cache/docs/<file_id_prefix>-<ts>.html (last N kept) — that is what makes
golden-file tests possible and lets the dashboard show the student the source.
"""

import re
import time
from pathlib import Path

import httpx

from sillybus import config, paths
from sillybus.logging_setup import get

log = get("fetch")


class DocError(RuntimeError):
    """A doc that cannot be fetched. gone=True (404/410) is a NORMAL outcome —
    a teacher unpublishing a doc is a Tuesday, not an exception."""

    def __init__(self, message, gone=False, needs_login=False):
        super().__init__(message)
        self.gone = gone
        self.needs_login = needs_login


def published_url(file_id: str) -> str:
    return f"https://docs.google.com/document/d/e/{file_id}/pub"


def private_export_url(file_id: str) -> str:
    return f"https://docs.google.com/document/d/{file_id}/export?format=html"


def _cache_key(file_id: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]", "", file_id)[:24] or "doc"


def _write_cache(file_id: str, html: str) -> Path:
    keep = config.load()["docs"]["cache_keep"]
    directory = paths.docs_cache_dir()
    stamp = time.strftime("%Y%m%d-%H%M%S")
    path = directory / f"{_cache_key(file_id)}-{stamp}.html"
    path.write_text(html, encoding="utf-8")
    old = sorted(directory.glob(f"{_cache_key(file_id)}-*.html"))
    for stale in old[:-keep] if keep > 0 else []:
        stale.unlink(missing_ok=True)
    return path


def cached_versions(file_id: str) -> list[Path]:
    return sorted(paths.docs_cache_dir().glob(f"{_cache_key(file_id)}-*.html"))


def latest_cached(file_id: str) -> str | None:
    versions = cached_versions(file_id)
    if not versions:
        return None
    return versions[-1].read_text(encoding="utf-8")


def fetch_published(file_id: str, timeout: float = 20.0, cache: bool = True) -> str:
    try:
        response = httpx.get(published_url(file_id), follow_redirects=True,
                             timeout=timeout,
                             headers={"User-Agent": "sillybus/0.1"})
    except httpx.HTTPError as exc:
        raise DocError(f"could not reach the doc: {type(exc).__name__}") from exc
    if response.status_code in (404, 410):
        raise DocError(f"the teacher unpublished this doc "
                       f"(HTTP {response.status_code})", gone=True)
    if response.status_code != 200:
        raise DocError(f"HTTP {response.status_code} fetching the doc")
    if "accounts.google.com" in str(response.url):
        raise DocError("Google asked for a sign-in on a published doc",
                       needs_login=True)
    html = response.text
    if cache:
        _write_cache(file_id, html)
    return html


def fetch_private(file_id: str, context, cache: bool = True) -> str:
    """Needs a Google session; only called with --include-private-docs.

    [ASKED] 2026-09-23: *"make it read all the connecors using the chrome
    extenion insted of connecting them"*. This is the reader that gains most
    from it. A published doc is cookieless httpx and needs nobody's session,
    but a private one needs Google — and Google is the sign-in this Mac is
    worst at: the school's MDM policy has broken Google SSO in branded Chrome
    before, which is why the app drives Chromium at all. The browser he is
    actually sitting in front of is signed into Google all day.

    Same parser either way, and `bridge.captured` cannot tell — and must not
    be able to tell — where the HTML came from.
    """
    try:
        from sillybus import bridge
        bridged = bridge.captured(private_export_url(file_id),
                                  name="a teacher's document")
    except Exception as exc:  # noqa: BLE001 — never the refresh
        log.info("bridge lookup failed for doc %s: %s", _cache_key(file_id), exc)
        bridged = None
    if bridged:
        if "accounts.google.com" in bridged[:2000]:
            # Chrome's own Google session had lapsed. Fall through rather than
            # cache a sign-in page as a teacher's document — an empty doc
            # reads as "this class set no homework".
            log.info("the bridged copy of %s was a sign-in page",
                     _cache_key(file_id))
        else:
            if cache:
                _write_cache(file_id, bridged)
            return bridged

    response = context.request.get(private_export_url(file_id), timeout=60_000)
    if "accounts.google.com" in (response.url or ""):
        raise DocError("Google asked for a sign-in; run: python run.py login",
                       needs_login=True)
    if response.status in (404, 410):
        raise DocError(f"the doc is gone (HTTP {response.status})", gone=True)
    if not response.ok:
        raise DocError(f"HTTP {response.status} fetching the private doc")
    html = response.text()
    if cache:
        _write_cache(file_id, html)
    return html


def fetch_doc(kind: str, file_id: str, context=None, include_private=False,
              cache: bool = True) -> str:
    if kind == "published-document":
        return fetch_published(file_id, cache=cache)
    if not include_private:
        raise DocError("private doc skipped (pass --include-private-docs to read it)")
    if context is None:
        raise DocError("a private doc needs the browser session", needs_login=True)
    return fetch_private(file_id, context, cache=cache)
