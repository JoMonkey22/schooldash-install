"""Bounded, source-specific novel module handout readers.

No school identifiers, credentials or live transport are stored here.
"""
from io import BytesIO
from zipfile import ZipFile, BadZipFile
from xml.etree import ElementTree as ET
import json
import re

def paragraphs(payload):
    if len(payload)>1_000_000:raise ValueError('file size limit')
    with ZipFile(BytesIO(payload)) as z:
        if sum(i.filename == 'word/document.xml' for i in z.infolist()) != 1:
            raise ValueError('missing or duplicate document part')
        info=z.getinfo('word/document.xml')
        if info.file_size>2_000_000:raise ValueError('document size limit')
        raw=z.read(info)
    if b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():raise ValueError('unsupported XML')
    root=ET.fromstring(raw);ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    return [''.join(p.itertext()).strip() for p in root.findall('.//w:p',ns)]

def schedule(lines):
    if len(lines)>500:return {'status':'bounded_limit','items':[]}
    starts=[i for i,x in enumerate(lines) if x.strip().casefold()=='assignment due dates:']
    if len(starts)!=1:return {'status':'unrecognized','items':[]}
    rows=[];i=starts[0]+1
    while i<len(lines):
        text=lines[i].strip()
        if not text:i+=1;continue
        m=re.fullmatch(r'Ch\. ([1-9]\d?)-([1-9]\d?) are due Class ([1-9]\d{0,2}) \(Groups? [^()]{1,80}\)?',text)
        if not m:
            if text.startswith('Ch.'):
                return {'status':'invalid_schedule','items':[]}
            break
        a,b,n=map(int,m.groups())
        if a>b or b>99 or len(rows)>=16:return {'status':'invalid_or_bounded','items':[]}
        rows.append({'chapters':f'{a}-{b}','class':n,'due_date':None,'due_time':None,'submitted':None})
        i+=1
    if not rows:return {'status':'unrecognized','items':[]}
    # Same range with contradictory class numbers stays unresolved, never last-writer-wins.
    grouped={}
    for row in rows:grouped.setdefault(row['chapters'],set()).add(row['class'])
    for row in rows:
        row['class_conflict']=len(grouped[row['chapters']])>1
        if row['class_conflict']:row['class']=None
    unique={json.dumps(r,sort_keys=True):r for r in rows}
    return {'status':'recognized','items':list(unique.values()),'shared_instructions':lines[i:]}

def norm(value):return re.sub(r'[^a-z0-9]+',' ',str(value).lower().replace('&',' and ')).strip()

def select(book,modules,items_by_module):
    if not isinstance(modules,list) or len(modules)>40:return {'status':'bounded_limit','file':None}
    choices=[m for m in modules if isinstance(m,dict) and norm(m.get('name',''))==norm(book)
        and m.get('published') is not False and m.get('locked_for_user') is not True
        and m.get('state')!='locked' and type(m.get('id')) is int and m['id']>0]
    if len(choices)!=1:return {'status':'missing_or_ambiguous_module','file':None}
    module=choices[0];rows=items_by_module.get(module['id'])
    if not isinstance(rows,list):return {'status':'items_unavailable','file':None}
    if len(rows)>100 or (type(module.get('items_count')) is int and module['items_count']!=len(rows)):
        return {'status':'incomplete_or_bounded_items','file':None}
    candidates={}
    for row in rows:
        if not isinstance(row,dict) or row.get('type')!='File':continue
        title=row.get('title')
        if not isinstance(title,str) or not title.lower().endswith('.docx'):continue
        ident=row.get('content_id')
        if type(ident) is not int or ident<=0:continue
        if row.get('published') is False or row.get('locked_for_user') is True:continue
        details=row.get('content_details') or {}
        if not isinstance(details,dict) or details.get('locked_for_user') is True:continue
        candidates.setdefault(ident,set()).add(title)
    if len(candidates)!=1 or any(len(names)>1 for names in candidates.values()):
        return {'status':'missing_or_ambiguous_file','file':None}
    ident=next(iter(candidates))
    return {'status':'selected','file':ident,'completion':None}


def decode_handout(payload, book):
    """Read one bounded matching-book handout; no dates inferred from file metadata."""
    try:
        lines=paragraphs(payload)
        header=next((x for x in lines if x.strip()), '')
        if norm(header.split(':',1)[0]) != norm(book):
            return {'status':'handout_book_mismatch','items':[]}
        result=schedule(lines)
        if result['status']=='recognized':
            tail=result['shared_instructions']
            example=next((i for i,x in enumerate(tail)
                          if re.match(r'^Example\b', x.strip(), re.I)),len(tail))
            result['shared_instructions']=[x for x in tail[:example] if x.strip()]
        return result
    except (ValueError, KeyError, BadZipFile, ET.ParseError, RuntimeError):
        return {'status':'unreadable_or_bounded_file','items':[]}


def read_module(context, host, course_id, book):
    """Four bounded GETs for one uniquely matched accessible module DOCX.

    Never post, unlock, inspect student responses or reuse a parent-page cache.
    Returned failures carry no URLs or response bodies.
    """
    from urllib.parse import urlsplit
    origin=urlsplit(host)
    if (origin.scheme!='https' or not origin.hostname or origin.username or origin.password
            or origin.path not in ('','/') or origin.query or origin.fragment
            or not re.fullmatch(r'[1-9][0-9]*',str(course_id))):
        return {'status':'invalid_course_origin','items':[]}
    base=f'{host.rstrip("/")}/api/v1/courses/{course_id}'

    def read(url):
        response=context.request.get(url,timeout=15000)
        if not response.ok:return None,'access_unavailable'
        if re.search(r';\s*rel="next"',response.headers.get('link',''),re.I):
            return None,'incomplete_or_bounded_list'
        return response.json(),'ok'

    try:
        modules,status=read(base+'/modules?per_page=100')
        if status!='ok':return {'status':status,'items':[]}
        # Selection is deliberately exact; a current source pointer is required by caller.
        if not isinstance(modules,list) or len(modules)>40:
            return {'status':'bounded_limit','items':[]}
        candidates=[m for m in modules if isinstance(m,dict)
                    and norm(m.get('name',''))==norm(book)
                    and m.get('published') is not False and m.get('locked_for_user') is not True
                    and m.get('state')!='locked' and type(m.get('id')) is int and m['id']>0]
        if len(candidates)!=1:return {'status':'missing_or_ambiguous_module','items':[]}
        module=candidates[0]
        rows,status=read(base+f'/modules/{module["id"]}/items?per_page=100')
        if status!='ok':return {'status':status,'items':[]}
        chosen=select(book,modules,{module['id']:rows})
        if chosen['file'] is None:return {'status':chosen['status'],'items':[]}
        file_id=chosen['file']
        metadata,status=read(base+f'/files/{file_id}')
        if status!='ok':return {'status':status,'items':[]}
        if (not isinstance(metadata,dict) or type(metadata.get('id')) is not int or metadata.get('id')!=file_id
                or metadata.get('locked_for_user') is True or metadata.get('hidden_for_user') is True
                or type(metadata.get('size')) is not int or not 0<metadata['size']<=1_000_000
                or not str(metadata.get('display_name') or metadata.get('filename') or '').lower().endswith('.docx')):
            return {'status':'file_unavailable_or_bounded','items':[]}
        # The same course-scoped download control exposed by Canvas, not a supplied external URL.
        response=context.request.get(f'{host.rstrip("/")}/courses/{course_id}/files/{file_id}/download?download_frd=1',timeout=15000)
        if not response.ok:return {'status':'file_access_unavailable','items':[]}
        result=decode_handout(response.body(),book)
        result['file_id']=file_id
        return result
    except Exception:
        return {'status':'module_read_unavailable','items':[]}


def prepare_source(html, profile, meetings):
    """Require a complete current module pointer and retain dated class proofs."""
    from bs4 import BeautifulSoup
    from datetime import datetime
    from sillybus import timezones
    from sillybus.docs import prose
    if len(html)>2_000_000:return None
    year=meetings.school_year_start() or datetime.now(timezones.zone()).year
    soup=BeautifulSoup(html,'lxml');nodes=prose._leaf_blocks(soup,prose.compile_prefixes(profile),year)
    if len(nodes)>5000:return None
    span=None;pointers=[];anchors=[]
    lookup=profile.get('course_raw') or profile.course_key
    for node in nodes:
        text=prose._clean(node.get_text(' ',strip=True))
        block=prose.block_heading(text,year)
        if block is not None:
            span=(block[0],block[1]);continue
        pointer=prose._book_check_reading(text)
        if pointer:pointers.append(pointer)
        heading=prose.day_heading(text,year)
        if heading and heading[0]=='classn':
            got=prose.class_stated(lookup,heading[2],span,'the teacher homepage',meetings)
            if got and got.when and got.confidence=='high':anchors.append((heading[1],got.when))
    identities={(p['book'],p['chapters'],p['class']) for p in pointers}
    if len(identities)!=1:return None
    book,chapters,number=next(iter(identities))
    return {'book':book,'first_chapters':chapters,'first_class':int(number),'anchors':anchors}


def _class_day(number, anchors, dates):
    if number is None:return None
    predictions=[]
    for n,day in anchors:
        if day not in dates:continue
        index=dates.index(day)+number-n
        if not 0<=index<len(dates):return None
        predictions.append(dates[index])
    return predictions[0] if predictions and len(set(predictions))==1 else None


def make_items(result, pointer, profile, meetings, host, course_id):
    """Class numbers are source facts; calendar dates are explicit inferences."""
    from sillybus.models import Item, Link
    if result.get('status')!='recognized':return []
    dates=meetings.dates(profile.get('course_raw') or profile.course_key)
    source=f'{host.rstrip("/")}/courses/{course_id}/files/{result["file_id"]}'
    steps='\n'.join(result.get('shared_instructions') or [])
    items=[]
    for row in result['items']:
        number=row['class']
        conflict=(row['chapters']==pointer['first_chapters'] and number!=pointer['first_class'])
        day=None if conflict else _class_day(number,pointer['anchors'],dates)
        label=f'Class {number}' if number is not None else 'class needs confirmation'
        title=f"{pointer['book']} Chapters {row['chapters']} — {label}"
        detail=f"Ch. {row['chapters']} are due {label}."
        note=(f'Handout states {label}; calendar date counted from agreeing teacher-homepage class anchors on the course timetable; exact deadline clock unstated'
              if day else f'Handout reading for {label}; calendar date missing or conflicting; exact deadline clock unstated')
        if conflict:note+='; homepage and handout disagree on this reading class'
        item=Item(source='doc',course_key=profile.course_key,
                  course=profile.get('display_name') or profile.course_key,title=title,
                  detail=detail+ ('\nHandout requirements:\n'+steps if steps else ''),raw_cell=detail,
                  kind='module handout',category='reading',due_date=day.isoformat() if day else None,
                  all_day=True,date_note=note,extractor='day_n_exact' if day else 'unresolved',
                  submitted=None,url=source,links=[Link(source,'Teacher reading handout','canvas')],
                  flags=['stated_category','module_reading_schedule','deadline_clock_unstated']+
                        ([] if day else ['needs_date_confirmation'])).finalize()
        items.append(item)
    return items


def enrich_existing(existing, children):
    """Exact same book/range/class/date enriches an existing reading in place."""
    remaining=[]
    for child in children:
        matches=[i for i in existing if i.course_key==child.course_key and i.title==child.title
                 and i.due_date==child.due_date and i.category=='reading']
        if len(matches)!=1:
            remaining.append(child);continue
        item=matches[0]
        marker='\nHandout requirements:\n'
        if marker in child.detail:
            requirements=child.detail.partition(marker)[2]
            if requirements and requirements not in item.detail:item.detail+=marker+requirements
        seen={l.url if hasattr(l,'url') else l.get('url') for l in item.links}
        item.links.extend(l for l in child.links if l.url not in seen)
        if 'module_reading_schedule' not in item.flags:item.flags.append('module_reading_schedule')
    return remaining
