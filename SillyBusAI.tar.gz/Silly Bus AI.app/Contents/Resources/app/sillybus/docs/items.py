"""Cells -> Items: the profile-driven extractor.

Semantics ported from the verified predecessor and kept under test:
- a prose cell is ONE item; only <li> bullets (and separate <p>s) split
- line prefixes are anchored at line start: Homework:/HW:/For tonight -> due at
  the NEXT meeting; Due Today:/Due:/Turn in -> this meeting; Agenda:/In class:/
  Plan: -> skipped
- an unlabelled row (chemistry's "For tonight ...") belongs to the day above it
- a row whose date cell is a block heading sets context and produces nothing
- nothing is ever dropped silently and no date is ever invented: unresolvable
  rows ship as extractor "unresolved" with an honest date_note
"""

import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, time

from sillybus import timezones
from sillybus.docs import columns as columns_mod
from sillybus.docs import dates as dates_mod
from sillybus.docs import links as links_mod
from sillybus.docs import tables as tables_mod
from sillybus.models import Item, course_key_from_raw, make_item_id

DEFAULT_PREFIXES = {
    "next_meeting": ["Homework", "HW", "For tonight", "Tonight"],
    "same_meeting": ["Due Today", "Due", "Turn in", "Hand in"],
    "skip": ["Agenda", "In class", "Plan", "Warm-up", "Bell work"],
}


@dataclass
class ExtractResult:
    items: list = field(default_factory=list)
    ambiguities: list = field(default_factory=list)
    diagnostics: dict = field(default_factory=dict)
    course_links: list = field(default_factory=list)   # course-wide, -> profile card


# A teacher who numbers their sections writes the marker second: "2.4 HW:
# #233-283". The marker still means homework, and the number is the name of the
# work — so the number is kept and only the marker is dropped, leaving
# "2.4 #233-283" rather than "#233-283".
# Deliberately WITHOUT any leading-decoration match: each caller supplies its
# own (items uses \s*, prose uses \W{0,3} so "**Tarea:" still works). Folding
# the two together made the whole lead optional-but-digit-requiring, and
# "**Tarea:" stopped matching at all.
NUMBERED_LEAD = (r"(?P<lead>(?:\d{1,2}(?:\.\d{1,2})?|ch(?:apter)?\.?\s*\d{1,2}"
                 r"|unit\s*\d{1,2}|lesson\s*\d{1,2})\s*)?")


def _prefix_regex(entries: list[str]) -> re.Pattern | None:
    cleaned = [re.escape(e.strip().rstrip(":-").strip()) for e in entries if e and e.strip()]
    if not cleaned:
        return None
    return re.compile(r"^\s*" + NUMBERED_LEAD + r"(?:%s)\b\s*[:\-–]?\s*"
                      % "|".join(cleaned), re.I)


def strip_prefix(pattern: re.Pattern, text: str) -> str:
    """Remove a matched line prefix, keeping any section number in front."""
    match = pattern.match(text)
    if not match:
        return text
    lead = (match.groupdict().get("lead") or "").strip()
    rest = text[match.end():].strip()
    return f"{lead} {rest}".strip() if lead else rest


def compile_prefixes(profile) -> dict:
    raw = (profile.get("line_prefixes", default=None) if profile else None) or {}
    merged = {key: raw.get(key) if raw.get(key) is not None else DEFAULT_PREFIXES[key]
              for key in DEFAULT_PREFIXES}
    return {
        "homework": _prefix_regex(merged["next_meeting"]),
        "due": _prefix_regex(merged["same_meeting"]),
        "skip": _prefix_regex(merged["skip"]),
    }


def classify_line(text: str, in_due_column: bool, prefixes: dict):
    """('due'|'homework'|'skip'|None, cleaned text). Prefixes beat column role,
    so a 'Homework:' line fires in any column; a bare line needs a due column."""
    if prefixes["homework"] and prefixes["homework"].match(text):
        return "homework", strip_prefix(prefixes["homework"], text)
    if prefixes["due"] and prefixes["due"].match(text):
        return "due", strip_prefix(prefixes["due"], text)
    if prefixes["skip"] and prefixes["skip"].match(text):
        return "skip", strip_prefix(prefixes["skip"], text)
    if in_due_column:
        return "due", text
    return None, ""


def scheduled_assessment(text: str, header: str) -> str | None:
    """Named assessments in a lesson column happen on its class day.

    This deliberately does not turn lesson topics, practice or review into
    homework. An explicit skip column still skips everything else.
    """
    # A combined lesson/homework column normally skips bare classroom prose.
    # This complete caption explicitly names the assessment event itself.
    if (re.fullmatch(r"in\s+class\s*/\s*homework", header.strip(), re.I)
            and re.fullmatch(r"midterm\s+benchmark\s+assessment\s+presentations[.!]?",
                             text.strip(), re.I)):
        return "test"
    if not re.fullmatch(r"(?:classroom\s+activit(?:y|ies)|in[ -]class(?:\s+activit(?:y|ies))?)",
                        header.strip(), re.I):
        return None
    if re.search(r"\b(?:review|practice|corrections?|study|prepare|retake|makeup)\b", text, re.I):
        return None
    match = re.match(r"^(?:(?:unit|chapter|lesson|section)\s+\d[\w.-]*\s+)?"
                     r"(quiz|test|exam|midterm|final exam)\b", text.strip(), re.I)
    return ("quiz" if match.group(1).lower() == "quiz" else "test") if match else None


def clean_title(text: str, limit: int = 110) -> str:
    text = re.sub(r"\s+", " ", text or "").strip(" .;:-–")
    if len(text) > limit:
        cut = text[:limit].rsplit(" ", 1)[0]
        text = cut + "…"
    return text


def cell_blocks(cell_node, base: str = ""):
    """[(text, links)] — one per <p> and per <li>, in document order; else the
    whole cell. Document order matters: a bare "For tonight" <p> heading before
    a bullet list applies to the bullets after it (the sticky role in the
    caller). Links outside any <li> attach to every <li> item from that cell."""
    blocks = []
    elements = [e for e in cell_node.find_all(["p", "li"])
                if e.name == "li" or e.find_parent("li") is None]
    if elements:
        outside = links_mod.from_anchors(
            [a for a in cell_node.find_all("a", href=True)
             if a.find_parent("li") is None], base)
        for element in elements:
            text = " ".join(element.get_text(" ", strip=True).split())
            if not text:
                continue
            own = links_mod.extract_links(element, base)
            if element.name == "li":
                seen = {l.url for l in own}
                own = own + [l for l in outside if l.url not in seen]
            blocks.append((text, own))
        if blocks:
            return blocks
    text = " ".join(cell_node.get_text(" ", strip=True).split())
    if text:
        blocks.append((text, links_mod.extract_links(cell_node, base)))
    return blocks


def _parse_all_styles(text, month_hint, year_start, styles):
    """Every enabled style's reading of a cell. >1 distinct reading = ambiguous."""
    readings = []
    for style in styles or []:
        kind, value = dates_mod.parse_day_cell(text, month_hint, year_start, [style])
        if kind is not None:
            readings.append((kind, value))
    distinct = {(k, str(v)) for k, v in readings}
    if not readings:
        return None, None, False
    if len(distinct) > 1:
        return None, None, True
    return readings[0][0], readings[0][1], False


UNRESOLVED = dates_mod.Resolution(
    None, dates_mod.NOTES["unresolved"], "unresolved", "low")


# [MEASURED] Scripture's November block announces the benchmark above Day 1.
# The ordinary heading skip lost it, even though its explicit Day 5 schedule
# and linked project instructions establish a real in-class obligation.
RE_BLOCK_BENCHMARK = re.compile(
    r"^(?:the\s+)?(?P<title>benchmark\s+(?:reflection|essay|project|test|quiz))"
    r"\s+will\s+be\s+(?:written|completed|submitted)\s+in\s+class\s+on\s+"
    r"day\s*#?\s*(?P<n>\d{1,2})\b", re.I)


# Explicit on-Day quiz schedules are work even in a rowspanned block heading.
RE_BLOCK_QUIZ = re.compile(
    r'^Quiz(?:\s*:\s*|\s+on\s+)(?P<title>.{3,100}?)\s+on\s+Day\s*'
    r'(?P<n>\d{1,2})\b(?P<options>\s*\([^)]*\))?[.!]?\Z', re.I)


RE_SECTION_QUIZ = re.compile(
    r'^Quiz(?:\s*:\s*|\s+on\s+)(?P<title>[^()]{3,100}?)\s*'
    r'\((?P<options>[A-Za-z]{3,9}\.?\s+\d{1,2}(?:st|nd|rd|th)?\s+or\s+'
    r'\d{1,2}(?:st|nd|rd|th)?\s+depending on your class period)\)[.!]?\Z', re.I)


def _block_quiz_dates(options, block):
    if not options or not block:
        return set()
    year_start = block[0].year - (block[0].month < 7)
    choices = set(dates_mod.dates_in_cell(options, year_start))
    for month, first, second in re.findall(r'([A-Za-z]{3,9})\.?\s+(\d{1,2})(?:st|nd|rd|th)?\s*(?:/|or)\s*(\d{1,2})(?:st|nd|rd|th)?', options):
        number = dates_mod.month_number(month)
        if not number:
            continue
        for day in (first, second):
            try:
                choices.add(datetime(dates_mod.year_for(number, year_start), number, int(day)).date())
            except ValueError:
                pass
    return {day for day in choices if block[0] <= day <= block[1]}


def _explicit_canvas_task(text):
    puzzle = re.fullmatch(r'Complete [“"](.{3,100}?)[”"] EdPuzzle on Canvas[.!]?', text, re.I)
    if puzzle:
        return 'EdPuzzle: ' + puzzle[1]
    reflection = re.fullmatch(r'Write a short reflection about the (.{3,80}?) on Canvas[.!]?', text, re.I)
    return 'Reflection: ' + reflection[1] if reflection else None


def _block_benchmarks(row, block, written_days, profile, course_display,
                      course_lookup, meetings, source_url):
    from sillybus.docs import prose

    found = []
    row_scope = ' / '.join(cell.text for cell in row if cell.origin and re.fullmatch(
        r'Day\s*\d+(?:\s+and\s+Day\s*\d+)?', cell.text, re.I))
    for cell in row:
        if not cell.origin or cell.node is None:
            continue
        previous_text, previous_links = "", []
        class_scope = row_scope
        blocks = list(cell_blocks(cell.node, source_url))
        for line_index, (text, line_links) in enumerate(blocks):
            if re.match(r'^Day\s*\d+\s+Periods?\b', text, re.I):
                class_scope = text
            inline_flint = re.fullmatch(
                r'Activity:\s*(.{3,70}?)\s*\(complete when asked in class\)', text, re.I)
            inline_links = [link for link in line_links
                            if inline_flint and link.text.strip() == inline_flint[1].strip()]
            if (inline_flint and block and class_scope and len(inline_links) == 1
                    and re.fullmatch(r'https://app\.flintk12\.com/activities/[A-Za-z0-9_-]+/?', inline_links[0].url)
                    and not re.search(r'\b(?:optional|review|practice|example|cancel\w*|postpon\w*)\b', inline_flint[1], re.I)):
                # [MEASURED] 2026-11-08: the completion command can be inline,
                # while Day N still has no personally verified date or clock.
                context = f'{block[0].isoformat()}–{block[1].isoformat()}'
                found.append(prose._item(
                    f'{inline_flint[1]} — class block {context} ({class_scope})',
                    f'{class_scope}: {text}', profile.course_key, course_display, None, None,
                    f'Explicit linked Flint classwork in source block {context}; {class_scope}; '
                    'complete when asked in class; class date and clock need confirmation',
                    'low', 'unresolved', ['needs_date_confirmation', 'explicit_flint_classwork'],
                    inline_links, source_url, 'due', source='doc', kind='in-class Flint task'))
                previous_text, previous_links = '', []
                continue
            flint = re.fullmatch(r'Activity:\s*(Flint\s+.{3,60})', previous_text, re.I)
            if (block and flint and len(previous_links) == 1
                    and previous_links[0].url.startswith('https://app.flintk12.com/')
                    and re.fullmatch(r'Click the link above when instructed in class and complete the assignment[.!]?', text, re.I)):
                instructions = [previous_text, text]
                for following, _ in blocks[line_index + 1:line_index + 3]:
                    if not re.match(r'^(?:This should be your own work|Do not use any resource other than)\b', following, re.I):
                        break
                    instructions.append(following)
                context = f'{block[0].isoformat()}–{block[1].isoformat()}'
                raw = f'{class_scope}: ' + ' '.join(instructions)
                found.append(prose._item(
                    f'{flint[1]} — class block {context}', raw, profile.course_key,
                    course_display, None, None,
                    f'Explicit linked Flint classwork in source block {context}; {class_scope}; '
                    'class day and submission deadline need confirmation',
                    'low', 'unresolved', ['needs_date_confirmation', 'explicit_flint_classwork'],
                    previous_links, source_url, 'due', source='doc', kind='in-class Flint task'))
                previous_text, previous_links = '', []
                continue
            reflection = re.fullmatch(r'Lockdown Browser:\s*(.{3,50} Reflection)', text, re.I)
            if (reflection and block and class_scope and line_index + 2 < len(blocks)
                    and not re.search(r'\b(?:optional|review|practice|example|cancel\w*|postpon\w*)\b', reflection[1], re.I)
                    and re.fullmatch(r'Follow instructions in class for accessing this reflection[.!]?', blocks[line_index + 1][0], re.I)
                    and re.fullmatch(r'Answer the questions honestly and authentically[.!]?', blocks[line_index + 2][0], re.I)):
                context = f'{block[0].isoformat()}–{block[1].isoformat()}'
                raw = f'{class_scope}: ' + ' '.join(part for part, _ in blocks[line_index:line_index + 3])
                found.append(prose._item(
                    f'{reflection[1]} — class block {context} ({class_scope})', raw,
                    profile.course_key, course_display, None, None,
                    f'Explicit in-class reflection response in source block {context}; {class_scope}; '
                    'class period and submission deadline need confirmation', 'low', 'unresolved',
                    ['needs_date_confirmation', 'explicit_class_reflection'], line_links, source_url,
                    'due', source='doc', kind='in-class reflection response'))
                previous_text, previous_links = '', []
                continue
            linked_assignment = re.fullmatch(r'[“"]([^“”"]{3,50})[”"] Assignment', previous_text, re.I)
            if (block and class_scope and linked_assignment and line_index > 0
                    and blocks[line_index - 1][0] == previous_text and len(previous_links) == 1
                    and previous_links[0].kind == 'google_doc'
                    and previous_links[0].text.strip() == previous_text
                    and not re.search(r'\b(?:optional|rubric|example|sample|review)\b', linked_assignment[1], re.I)
                    and re.fullmatch(r'You will work both independently and in small groups for this assignment[.!]?', text, re.I)):
                instructions = [previous_text, text]
                if line_index + 1 < len(blocks):
                    following = blocks[line_index + 1][0]
                    if re.fullmatch(r'Eventually you will briefly present your [A-Za-z -]{2,40} to the class[.!]?', following, re.I):
                        instructions.append(following)
                context = f'{block[0].isoformat()}–{block[1].isoformat()}'
                found.append(prose._item(
                    f'{linked_assignment[1]} Assignment — class block {context} ({class_scope})',
                    f'{class_scope}: ' + ' '.join(instructions), profile.course_key, course_display,
                    None, None, f'Explicit linked classwork in source block {context}; {class_scope}; '
                    'class period and submission deadline need confirmation', 'low', 'unresolved',
                    ['needs_date_confirmation', 'explicit_linked_classwork'], previous_links,
                    source_url, 'due', source='doc', kind='in-class linked assignment'))
                previous_text, previous_links = '', []
                continue
            form = re.fullmatch(r'Form:\s*(.{3,100}?)\s*\(complete in class\)[.!]?', text, re.I)
            form_links = [link for link in line_links if link.kind == 'google_form'
                          and form and link.text.strip().casefold() == form[1].strip().casefold()]
            if form and block and class_scope and len(form_links) == 1:
                context = f'{block[0].isoformat()}–{block[1].isoformat()}'
                found.append(prose._item(
                    f'Form: {form[1]} — class block {context} ({class_scope})',
                    f'{class_scope}: {text}', profile.course_key, course_display, None, None,
                    f'Explicit linked in-class form in source block {context}; {class_scope}; '
                    'class period and completion date/clock need confirmation',
                    'low', 'unresolved', ['needs_date_confirmation', 'explicit_form_classwork',
                                          'form_block:' + context,
                                          *(['introductory_form'] if re.fullmatch(
                                              r'Who are you\?|Getting started|Get to know you|Student introduction|About me',
                                              form[1], re.I) else [])],
                    form_links, source_url, 'due', source='doc', kind='in-class form task'))
                continue
            named_task = _explicit_canvas_task(text)
            if named_task and block:
                context = f'{block[0].isoformat()}–{block[1].isoformat()}'
                raw = f'{class_scope}: {text}' if class_scope else text
                found.append(prose._item(
                    f'{named_task} — class block {context}', raw, profile.course_key,
                    course_display, None, None,
                    f'Explicit Canvas classwork in source block {context}; {class_scope}; '
                    'class day and submission deadline need confirmation',
                    'low', 'unresolved', ['needs_date_confirmation', 'explicit_canvas_classwork'],
                    line_links, source_url, 'due', source='doc', kind='in-class Canvas task'))
                continue
            section_quiz = RE_SECTION_QUIZ.fullmatch(text)
            if (section_quiz and block and not re.search(
                    r'\b(?:review|study|practice|optional|may|might|cancel\w*|postpon\w*)\b',
                    section_quiz['title'], re.I)):
                context = f'{block[0].isoformat()}–{block[1].isoformat()}'
                choices = sorted(_block_quiz_dates(section_quiz['options'], block))
                options = ', '.join(day.isoformat() for day in choices)
                note = (f'Section-specific quiz in source block {context}; '
                        f'stated alternatives: {section_quiz["options"]}; '
                        f'validated dates in block: {options or "none"}; '
                        'class period unverified; exact date and clock need confirmation')
                found.append(prose._item(
                    f'Quiz: {section_quiz["title"]} — class block {context}', text,
                    profile.course_key, course_display, None, None, note, 'low', 'unresolved',
                    ['needs_date_confirmation', 'explicit_section_quiz'], line_links, source_url,
                    'assessment', source='doc', kind='homepage doc'))
                continue
            quiz = RE_BLOCK_QUIZ.fullmatch(text)
            if quiz and re.search(r'\b(?:review|study|practice|optional|may|might)\b', quiz['title'], re.I):
                quiz = None
            match = RE_BLOCK_BENCHMARK.match(text) or quiz
            if not match:
                previous_text, previous_links = text, line_links
                continue
            use = dates_mod.resolve_day_n(course_lookup, int(match.group("n")),
                                          block, meetings, written_days)
            named_project = not quiz and re.match(r"^benchmark\s+(?:project|reflection|essay|test|quiz)\b",
                                     previous_text, re.I)
            links = line_links or (previous_links if named_project else [])
            raw = f"{previous_text} {text}" if named_project else text
            note = f"'{match.group(0)}' in the block heading; {use.note}"
            day = use.when
            moment = None
            flags = list(use.flags)
            choices = _block_quiz_dates(quiz['options'], block) if quiz else set()
            conflict = bool(day and choices and day not in choices)
            if conflict:
                day = None
                note += '; timetable Day conflicts with stated quiz date options; confirmation needed'
            if day:
                moment, note = prose.deadline_moment(
                    day, text, match.group(0), meetings, course_lookup, note)
            else:
                flags.append("needs_date_confirmation")
            found.append(prose._item(
                ("Quiz: " + match.group("title") if quiz else match.group("title")),
                raw, profile.course_key, course_display,
                moment.isoformat() if moment else None, day.isoformat() if day else None,
                note, "low" if conflict else use.confidence,
                "unresolved" if conflict else use.extractor, flags, links, source_url,
                "assessment" if quiz else "due", source="doc", kind="homepage doc"))
    return found


def extract_doc(html: str, profile, meetings, source_url: str = "") -> ExtractResult:
    """Parse one course doc into Items, using that course's profile."""
    result = ExtractResult()
    course_display = (profile.get("display_name") or profile.get("course_raw")
                      or profile.course_key)
    course_lookup = profile.get("course_raw") or course_display
    styles = profile.get("layout", "date_styles", default=None) or \
        ["day_n", "absolute", "month_heading"]
    snap_absolute = bool(profile.get("layout", "snap_absolute_to_meeting",
                                     default=False))
    block_pattern = profile.get("layout", "block_heading_pattern", default=None)
    prefixes = compile_prefixes(profile)
    year_start = meetings.school_year_start() or timezones.to_local(
        datetime.now(timezones.zone())).year

    table_nodes, body = tables_mod.parse_tables(html)
    month_hint = None
    table_diags = []

    for node in body.find_all(["p", "h1", "h2", "h3", "table"]):
        if node.find_parent("table"):
            continue
        if node.name != "table":
            text = node.get_text(" ", strip=True)
            match = dates_mod.RE_BARE_MONTH.match(text)
            if match:
                number = dates_mod.month_number(match.group(1))
                if number:
                    month_hint = number
            # course-wide links live in the doc's header/paragraph area
            result.course_links.extend(links_mod.extract_links(node, source_url))
            continue

        grid = tables_mod.build_grid(node)
        if not grid:
            continue
        header_idx, header_rule = tables_mod.detect_header(grid)
        if header_idx < 0:
            continue
        headers = [c.text for c in grid[header_idx]]
        joined = " ".join(headers).lower()
        if "day" not in joined and "date" not in joined:
            # a resources/links table, not a schedule — its links are course-wide
            result.course_links.extend(links_mod.extract_links(node, source_url))
            continue
        # links in a schedule table's header row are course-wide too
        for cell in grid[header_idx]:
            if cell.origin and cell.node is not None:
                result.course_links.extend(
                    links_mod.extract_links(cell.node, source_url))
        roles, date_col = columns_mod.classify_columns(headers, profile)
        # A profile may list several date-ish columns (CLASS DAY and DATE/WEEK
        # both match). The real date column is the one whose CELLS actually
        # parse as day/date values — block-heading cells do not count.
        candidates = [i for i, role in enumerate(roles) if role == "date"]
        if len(candidates) > 1:
            def _hits(col_index):
                count = 0
                for r, row in enumerate(grid):
                    if r == header_idx or col_index >= len(row):
                        continue
                    kind, _, _ = _parse_all_styles(row[col_index].text,
                                                   month_hint, year_start, styles)
                    if kind in ("dayn", "date", "weekday"):
                        count += 1
                return count
            date_col = max(candidates, key=_hits)
            for other in candidates:
                if other != date_col:
                    roles[other] = "plain"
        diag = {"header_rule": header_rule, "headers": headers, "roles": roles,
                "rows": len(grid), "items": 0, "date_col": date_col}
        table_diags.append(diag)

        # ---- pass 1: date-cell parse + block context per row -----------------
        parsed: list[tuple] = []
        block = None
        for r, row in enumerate(grid):
            if r == header_idx:
                parsed.append((None, None, block, True, False))
                continue
            date_cell = row[date_col] if date_col < len(row) else None
            date_text = date_cell.text if date_cell else ""
            block_origin_row = False
            for cell in row[:date_col]:
                if not cell.text:
                    continue
                span = None
                if block_pattern:
                    span = dates_mod.parse_block_pattern(cell.text, block_pattern,
                                                         year_start)
                span = span or dates_mod.parse_range(cell.text, year_start)
                if span and dates_mod.RE_RANGE.search(cell.text):
                    block = span
                    if cell.origin and not date_text.strip():
                        block_origin_row = True
            kind, value, conflict = _parse_all_styles(date_text, month_hint,
                                                      year_start, styles)
            if kind is None and not conflict:
                special = re.fullmatch(
                    r'Day\s+[1-9][0-9]{0,2}\s+(\d{1,2}/\d{1,2}(?:/\d{2,4})?)\s*\(C-Day\)',
                    date_text, re.I)
                if special:
                    special_kind, special_day = dates_mod.parse_day_cell(
                        special[1], month_hint, year_start, ['absolute'])
                    if special_kind == 'date':
                        kind, value = 'resolved', dates_mod.Resolution(
                            special_day, f'Special schedule source cell "{date_text}"; '
                            f'{special_day.isoformat()} as stated (C-Day)',
                            'absolute', 'high', ['special_schedule_date'])
            if kind is None and not conflict:
                # a block heading in the date column itself (chemistry-style)
                k2, v2 = dates_mod.parse_day_cell(date_text, month_hint,
                                                  year_start, [])
                if k2 == "block":
                    kind, value = k2, v2
            if kind is None and not conflict:
                # A cell naming one date per class section — "Day 1 / 8/6-A /
                # 8/7-B". Every pattern above is anchored to the whole cell, so
                # three lines match none of them. [MEASURED] 2026-09-02 that
                # left all 16 Honors Algebra items undated with the dates
                # written twice in the cell. Last, so it only ever rescues a
                # row nothing else could date.
                labelled = dates_mod.resolve_labelled_dates(
                    course_lookup, date_text, year_start, meetings)
                if labelled is not None:
                    kind, value = "resolved", labelled
            if kind == "block":
                block = value
                block_origin_row = True
            parsed.append((kind, value, block, block_origin_row, conflict))

        dayn_counts = Counter(b for (k, _, b, _, _) in parsed if k == "dayn")

        # ---- pass 2: build items --------------------------------------------
        last_res = None
        prev_block = None
        for r, row in enumerate(grid):
            kind, value, block, is_heading, conflict = parsed[r]
            if r == header_idx:
                continue
            if block != prev_block:
                last_res, prev_block = None, block
            if is_heading:
                scheduled = _block_benchmarks(
                    row, block, dayn_counts.get(block, 0), profile, course_display,
                    course_lookup, meetings, source_url)
                result.items.extend(scheduled)
                diag["items"] += len(scheduled)
                continue
            date_cell = row[date_col] if date_col < len(row) else None
            date_text = date_cell.text if date_cell else ""

            prior_res = last_res
            res = None
            if kind == "resolved":
                res = value
            elif kind == "date":
                res = dates_mod.resolve_absolute(course_lookup, value, meetings,
                                                 snap_absolute)
            elif kind == "weekday":
                claimed, weekday, raw = value
                month_name = [k for k, v in dates_mod.MONTHS.items()
                              if v == month_hint]
                res = dates_mod.snap_weekday(
                    course_lookup, claimed, weekday, raw, meetings,
                    (month_name[0].capitalize() if month_name else "month"))
            elif kind == "dayn":
                res = dates_mod.resolve_day_n(course_lookup, value, block,
                                              meetings, dayn_counts.get(block, 0))
            unresolved_date_cell = kind is None and (conflict
                or dates_mod.looks_date_like(date_text)
                or re.match(r'^Day\s+[1-9][0-9]{0,2}\b', date_text, re.I))
            if unresolved_date_cell:
                # [MEASURED] 2026-11-08: an unreadable new C-Day date borrowed
                # the preceding review row's date. Only blank continuations inherit.
                res = dates_mod.Resolution(
                    None, f'Date cell "{date_text}" is unresolved; previous row date not reused',
                    'unresolved', 'low', ['unresolved_date_cell'])
                last_res = None
            elif res is not None:
                last_res = res
            row_has_content = any(
                c.origin and c.text and c.col != date_col for c in row)
            if unresolved_date_cell:
                if row_has_content:
                    result.ambiguities.append({
                        "course_key": profile.course_key,
                        "cell": date_text,
                        "reason": ("two date styles disagree" if conflict
                                   else "no date style matched a date-like cell"),
                        "headers": headers,
                        "row_text": " | ".join(c.text for c in row if c.origin),
                        "block": [b.isoformat() for b in block] if block else None,
                    })

            use = res if res is not None else (last_res or UNRESOLVED)
            forced_homework = bool(prefixes["homework"]
                                   and prefixes["homework"].match(date_text or ""))

            for cell in row:
                if not cell.origin or cell.node is None:
                    continue
                if cell.col == date_col and kind is not None:
                    continue
                role_col = roles[cell.col] if cell.col < len(roles) else "plain"
                if role_col == "date" and kind is not None:
                    continue
                in_due = role_col == "due"
                # A column of work SET at this class: a bare line in it is
                # homework, which the shift below dates to the next meeting.
                in_assigned = role_col == "assigned"
                # A bare prefix line inside a cell ("For tonight" on its own,
                # then the actual work as following lines — chemistry writes
                # exactly this) sets a sticky role for the REST of that cell.
                sticky_role = None
                # A closing line that states a deadline and nothing else is an
                # instruction about the rest of the cell, not a task. AP
                # Chemistry writes a "For tonight" list and ends it with
                # "These should be done by August 11th." — the videos and the
                # book problems above it are what is due on the 11th.
                from sillybus.docs import prose as prose_mod

                blocks = []
                for block_text, block_links in cell_blocks(cell.node, source_url):
                    # [MEASURED] 2026-11-04: Algebra puts a bare linked "Key"
                    # after each worksheet in THE WORK. It is supporting
                    # material, not another hand-in with its own next-class date.
                    # Keep the link on the task, or in course resources if alone.
                    # Explicit "HW: Key" / "Write an answer key" remain work.
                    if block_links and re.fullmatch(
                            r"(?:key|answer\s+keys?|solutions?)", block_text.strip(), re.I):
                        result.course_links.extend(block_links)
                        if blocks:
                            previous_text, previous_links = blocks[-1]
                            seen = {link.url for link in previous_links}
                            blocks[-1] = (previous_text, previous_links +
                                          [link for link in block_links if link.url not in seen])
                        continue
                    blocks.append((block_text, block_links))
                cell_deadline = None
                cell_deadline_text = ''
                instructions: set = set()
                for cell_text, _ in blocks:
                    only = prose_mod.deadline_only_line(cell_text, year_start)
                    if only is not None:
                        cell_deadline = only
                        cell_deadline_text = cell_text
                        instructions.add(cell_text)
                for text, blk_links in blocks:
                    if text in instructions:
                        continue
                    if dates_mod.SKIP_TEXT.match(text) or len(text) < 3:
                        continue
                    # explicit prefixes first; the bare due-column default
                    # applies LAST, after row-forced and sticky roles
                    assessment_category = (scheduled_assessment(text, headers[cell.col])
                                           if role_col == "skip" and cell.col < len(headers) else None)
                    role, cleaned = classify_line(text, False, prefixes)
                    if role is None and assessment_category:
                        role, cleaned = "due", text
                    if role == "skip":
                        if not cleaned:
                            sticky_role = "skip"
                        continue
                    if role and not cleaned:
                        sticky_role = role
                        continue
                    if role is None:
                        if forced_homework:
                            role, cleaned = "homework", text
                        elif sticky_role in ("homework", "due"):
                            role, cleaned = sticky_role, text
                        elif sticky_role == "skip":
                            continue
                        elif in_assigned:
                            role, cleaned = "homework", text
                        elif in_due:
                            role, cleaned = "due", text
                    if not role or not cleaned or len(cleaned) < 3:
                        continue

                    # Prefix stripping can expose a no-work sentinel (Homework: none).
                    if dates_mod.SKIP_TEXT.fullmatch(cleaned):
                        continue

                    due_day = use.when
                    note = use.note
                    extractor = use.extractor
                    confidence = use.confidence
                    flags = list(use.flags)

                    # A deadline written in the cell wins outright, and is
                    # never shifted to the next class — it already IS the
                    # deadline. The same rule prose has had from the start, so
                    # a teacher who writes a table and a teacher who writes
                    # sentences are read the same way.
                    #
                    # [MEASURED] 2026-09-03, reported: "Work on SARA (25% due
                    # by 10/8)" sat in Honors Algebra's work column and was
                    # dated 2026-08-31 — "assigned Aug 27, due next class" —
                    # so a task due in five weeks was shown as overdue. The
                    # identical SARA programme in the English doc was dated
                    # correctly, because that teacher writes prose.
                    from sillybus.docs import prose as prose_mod

                    own = prose_mod.stated_deadline(text, year_start)
                    clock_phrase = ''
                    clock_text = text
                    if own is not None:
                        due_day, phrase = own
                        clock_phrase = phrase
                        note = dates_mod.NOTES["line_deadline"].format(phrase=phrase)
                        extractor, confidence = "absolute", "high"
                    elif cell_deadline is not None:
                        due_day, phrase = cell_deadline
                        clock_phrase, clock_text = phrase, cell_deadline_text
                        note = dates_mod.NOTES["cell_deadline"].format(phrase=phrase)
                        extractor, confidence = "absolute", "high"
                    elif role == "homework" and due_day:
                        following = meetings.next_after(course_lookup, due_day)
                        if following:
                            shift = dates_mod.NOTES["homework_shift"].format(
                                assigned=f"{due_day:%b %d}")
                            if extractor == "absolute":
                                note = shift
                            else:
                                note = f"{note}; {shift}"
                            due_day = following

                    due = due_date = None
                    if due_day:
                        when, note = prose_mod.deadline_moment(
                            due_day, clock_text, clock_phrase, meetings, course_lookup, note)
                        due, due_date = when.isoformat(), due_day.isoformat()
                        if ('special_schedule_date' in flags and role == 'due'
                                and own is None and cell_deadline is None):
                            special_start = meetings.time_on(course_lookup, due_day)
                            if special_start is None:
                                due = None
                                note += '; exact special-schedule class clock unavailable'
                                flags.append('deadline_clock_unstated')
                            else:
                                note += f'; class start {special_start:%H:%M} inferred from timetable'


                    item = Item(
                        source="doc",
                        course_key=profile.course_key,
                        course=course_display,
                        title=clean_title(cleaned),
                        detail=re.sub(r"\s+", " ", text).strip(),
                        raw_cell=cell.text,
                        kind="homepage doc",
                        category=assessment_category or "neutral",
                        due=due,
                        due_date=due_date,
                        assigned_date=use.when.isoformat() if use.when else None,
                        all_day=False,
                        date_note=note,
                        confidence=confidence,
                        extractor=extractor,
                        url=links_mod.best_link(blk_links) or source_url or None,
                        links=blk_links,
                        flags=flags + (["stated_category"] if assessment_category
                                       and "stated_category" not in flags else []),
                    )
                    item.finalize()
                    if re.fullmatch(r"No actual homework[–—-]\s*work on your duet performances[.!]?",
                                    cleaned, re.I):
                        # The same-cell project introduction names the details
                        # handout for this practice. Do not copy group names,
                        # invent a performance deadline or follow other cells.
                        guides = [link for intro, intro_links in blocks
                                  if re.fullmatch(
                                      r"Practice:\s*We['’]ll introduce our [“\"]\s*Duet Project\s*[”\"]\.\s*"
                                      r"Review the doc for details on the assignment\."
                                      r"(?:\s*Let['’]s start by assigning groups:)?", intro, re.I)
                                  for link in intro_links
                                  if link.text.strip().lower() == "duet project"
                                  and link.kind == "google_drive_file"]
                        if len({link.url for link in guides}) == 1:
                            guides = list({link.url: link for link in guides}.values())
                            known = {link.url for link in item.links}
                            item.links += [link for link in guides if link.url not in known]
                            if not blk_links:
                                item.url = guides[0].url
                            item.detail += "\nDuet Project details are linked; project deadline not stated in this source."
                            item.flags.append("same_cell_project_link")
                    if ('special_schedule_date' in flags and role == 'due'
                            and own is None and cell_deadline is None):
                        old_day = prior_res.when.isoformat() if prior_res and prior_res.when else None
                        old_id = make_item_id('doc', profile.course_key, item.title, old_day)
                        if old_id != item.item_id:
                            item.merged_from.append(f'doc:{old_id}')
                    result.items.append(item)
                    diag["items"] += 1

    seen_urls: set[str] = set()
    deduped_links = []
    for link in result.course_links:
        key = link.url.rstrip("/").lower()
        if key not in seen_urls:
            seen_urls.add(key)
            deduped_links.append(link)
    result.course_links = deduped_links
    result.diagnostics = {"tables": table_diags,
                          "ambiguous_cells": len(result.ambiguities)}
    # A mixed lesson/homework column is intentionally not a due column. Read
    # its explicit obligations with the prose rules even if one distant HW
    # prefix already yielded an item; nonempty is not evidence of completeness.
    mixed_schedule = profile.get("layout", "due_column_headers", default=None) == [] and any(
        all(re.search(pattern, header, re.I)
            for pattern in (r"\bdue\b", r"\bin\s*class\b", r"\bhomework\b"))
        for table in table_diags for header in table["headers"])
    if mixed_schedule:
        from sillybus.docs import cellblocks
        from sillybus import merge
        mixed = cellblocks.extract_cells(html, profile.course_key, course_display,
                                         course_lookup, meetings, source_url=source_url,
                                         profile=profile, source="doc", kind="homepage doc")
        if mixed.items:
            result.items = merge.dedupe_docs(mixed.items + result.items)
            result.diagnostics["read_as_mixed"] = True
    return result
