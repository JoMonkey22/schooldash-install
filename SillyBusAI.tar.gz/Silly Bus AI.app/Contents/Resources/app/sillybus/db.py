"""SQLite persistence at data/state.db. Plain SQL, integer schema version.

Durable state only: tick-offs, run history, the adjudication cache, chat
conversations and session ids, and the memories the student asked chat to keep. The full item list lives in cache/state.json (rebuilt every
refresh) — deleting either file is always safe.
"""

import json
import sqlite3
from datetime import datetime
from pathlib import Path

from sillybus import paths

SCHEMA_VERSION = 1

_SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS done (
    item_id TEXT PRIMARY KEY,
    done_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS runs (
    run_id TEXT PRIMARY KEY,
    started TEXT NOT NULL,
    finished TEXT,
    ok INTEGER NOT NULL DEFAULT 0,
    counts TEXT NOT NULL DEFAULT '{}',
    warnings TEXT NOT NULL DEFAULT '[]',
    diagnostics TEXT NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS adjudications (
    fingerprint TEXT NOT NULL,
    cell_hash TEXT NOT NULL,
    result TEXT NOT NULL,
    created TEXT NOT NULL,
    PRIMARY KEY (fingerprint, cell_hash)
);
CREATE TABLE IF NOT EXISTS ai_usage (
    month TEXT NOT NULL,
    kind TEXT NOT NULL,
    used INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (month, kind)
);
CREATE TABLE IF NOT EXISTS chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    asked_at TEXT NOT NULL,
    role TEXT NOT NULL,
    text TEXT NOT NULL,
    meta_json TEXT,
    conversation_id TEXT
);
CREATE INDEX IF NOT EXISTS chat_messages_time ON chat_messages (asked_at);
CREATE TABLE IF NOT EXISTS chat_conversations (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chat_memories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chat_sessions (
    session_key TEXT PRIMARY KEY,
    provider_session_id TEXT NOT NULL,
    updated TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS custom_tasks (
    item_id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    due_date TEXT,
    course TEXT,
    section TEXT,
    notes TEXT,
    created TEXT NOT NULL,
    archived INTEGER NOT NULL DEFAULT 0,
    category TEXT
);
CREATE TABLE IF NOT EXISTS custom_events (
    event_id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    date TEXT NOT NULL,
    start_time TEXT,
    end_time TEXT,
    location TEXT,
    created TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS doc_state (
    file_id TEXT PRIMARY KEY,
    content_hash TEXT NOT NULL,
    items_json TEXT NOT NULL,
    course_links_json TEXT NOT NULL DEFAULT '[]',
    fingerprint TEXT,
    updated TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS accelerations (
    item_id TEXT PRIMARY KEY,
    content_hash TEXT NOT NULL,
    result_json TEXT NOT NULL,
    provider TEXT,
    created TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS quizzes (
    id TEXT PRIMARY KEY,
    course_key TEXT NOT NULL,
    item_id TEXT,
    created TEXT NOT NULL,
    result_json TEXT NOT NULL,
    provider TEXT,
    attempts_json TEXT NOT NULL DEFAULT '[]'
);
CREATE TABLE IF NOT EXISTS item_history (
    item_id TEXT PRIMARY KEY,
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL,
    item_json TEXT NOT NULL
);
"""


# Columns added after the first release. `CREATE TABLE IF NOT EXISTS` does
# nothing to a table that already exists, so a new column has to be added
# explicitly — and idempotently, because connect() runs on every request.
#
# chat_messages.conversation_id is NULLABLE on purpose: every message written
# before conversations existed keeps NULL, and is still read by
# /api/chat/history and listed as the read-only "Earlier chats" conversation.
# Nothing is rewritten, so the migration cannot lose a message.
_ADDED_COLUMNS = [("custom_tasks", "category", "TEXT"),
                  ("chat_messages", "conversation_id", "TEXT")]

# An index on an added column cannot live in _SCHEMA: executescript runs
# before the column exists on an old database, and would fail there.
_ADDED_INDEXES = ["CREATE INDEX IF NOT EXISTS chat_messages_conversation "
                  "ON chat_messages (conversation_id, id)"]


def _add_missing_columns(conn: sqlite3.Connection) -> None:
    for table, column, kind in _ADDED_COLUMNS:
        existing = {row["name"] for row in
                    conn.execute(f"PRAGMA table_info({table})")}
        if column not in existing:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {kind}")
            conn.commit()
    for statement in _ADDED_INDEXES:
        conn.execute(statement)


def connect(path: Path | None = None) -> sqlite3.Connection:
    conn = sqlite3.connect(path or paths.db_path())
    conn.row_factory = sqlite3.Row
    conn.executescript(_SCHEMA)
    _add_missing_columns(conn)
    row = conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
    if row is None:
        conn.execute("INSERT INTO meta (key, value) VALUES ('schema_version', ?)",
                     (str(SCHEMA_VERSION),))
        conn.commit()
    return conn


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


# ---- tick-off ---------------------------------------------------------------

def get_done_ids(conn: sqlite3.Connection) -> set[str]:
    return {row["item_id"] for row in conn.execute("SELECT item_id FROM done")}


def set_done(conn: sqlite3.Connection, item_id: str, done: bool) -> None:
    """Idempotent, so it doubles as Undo."""
    if done:
        conn.execute(
            "INSERT INTO done (item_id, done_at) VALUES (?, ?) "
            "ON CONFLICT(item_id) DO NOTHING", (item_id, _now()))
    else:
        conn.execute("DELETE FROM done WHERE item_id = ?", (item_id,))
    conn.commit()


# ---- runs -------------------------------------------------------------------

def record_run(conn: sqlite3.Connection, run) -> None:
    conn.execute(
        "INSERT INTO runs (run_id, started, finished, ok, counts, warnings, diagnostics) "
        "VALUES (?, ?, ?, ?, ?, ?, ?) "
        "ON CONFLICT(run_id) DO UPDATE SET finished=excluded.finished, ok=excluded.ok, "
        "counts=excluded.counts, warnings=excluded.warnings, diagnostics=excluded.diagnostics",
        (run.run_id, run.started, run.finished, int(run.ok),
         json.dumps(run.counts), json.dumps(run.warnings), json.dumps(run.diagnostics)))
    conn.commit()


def list_runs(conn: sqlite3.Connection, limit: int = 20) -> list[dict]:
    rows = conn.execute(
        "SELECT * FROM runs ORDER BY started DESC LIMIT ?", (limit,)).fetchall()
    out = []
    for row in rows:
        out.append({
            "run_id": row["run_id"],
            "started": row["started"],
            "finished": row["finished"],
            "ok": bool(row["ok"]),
            "counts": json.loads(row["counts"]),
            "warnings": json.loads(row["warnings"]),
            "diagnostics": json.loads(row["diagnostics"]),
        })
    return out


# ---- adjudication cache -----------------------------------------------------

def adjudication_get(conn: sqlite3.Connection, fingerprint: str, cell_hash: str) -> dict | None:
    row = conn.execute(
        "SELECT result FROM adjudications WHERE fingerprint=? AND cell_hash=?",
        (fingerprint, cell_hash)).fetchone()
    return json.loads(row["result"]) if row else None


def adjudication_put(conn: sqlite3.Connection, fingerprint: str, cell_hash: str,
                     result: dict) -> None:
    conn.execute(
        "INSERT INTO adjudications (fingerprint, cell_hash, result, created) "
        "VALUES (?, ?, ?, ?) ON CONFLICT(fingerprint, cell_hash) DO UPDATE SET "
        "result=excluded.result, created=excluded.created",
        (fingerprint, cell_hash, json.dumps(result), _now()))
    conn.commit()


# ---- custom tasks -------------------------------------------------------------

def add_custom_task(conn: sqlite3.Connection, item_id: str, title: str,
                    due_date: str | None, course: str | None,
                    section: str | None, notes: str | None,
                    category: str | None = None) -> None:
    conn.execute(
        "INSERT INTO custom_tasks (item_id, title, due_date, course, section, "
        "notes, created, category) VALUES (?, ?, ?, ?, ?, ?, ?, ?) "
        "ON CONFLICT(item_id) DO UPDATE SET title=excluded.title, "
        "due_date=excluded.due_date, course=excluded.course, "
        "section=excluded.section, notes=excluded.notes, "
        "category=excluded.category, archived=0",
        (item_id, title, due_date, course, section, notes, _now(), category))
    conn.commit()


def add_custom_event(conn: sqlite3.Connection, event_id: str, title: str, day: str,
                     start: str | None, end: str | None, location: str | None,
                     created: str) -> None:
    conn.execute(
        "INSERT OR REPLACE INTO custom_events (event_id, title, date, start_time, "
        "end_time, location, created) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (event_id, title, day, start, end, location, created))
    conn.commit()


def list_custom_events(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute(
        "SELECT * FROM custom_events ORDER BY date, start_time").fetchall()
    return [dict(row) for row in rows]


def delete_custom_event(conn: sqlite3.Connection, event_id: str) -> bool:
    cur = conn.execute("DELETE FROM custom_events WHERE event_id=?", (event_id,))
    conn.commit()
    return cur.rowcount > 0


def list_custom_tasks(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute(
        "SELECT * FROM custom_tasks WHERE archived=0 ORDER BY created").fetchall()
    return [dict(row) for row in rows]


def archive_custom_task(conn: sqlite3.Connection, item_id: str) -> bool:
    cur = conn.execute(
        "UPDATE custom_tasks SET archived=1 WHERE item_id=?", (item_id,))
    conn.commit()
    return cur.rowcount > 0


# ---- incremental doc cache -----------------------------------------------------

def doc_state_get(conn: sqlite3.Connection, file_id: str) -> dict | None:
    row = conn.execute("SELECT * FROM doc_state WHERE file_id=?",
                       (file_id,)).fetchone()
    return dict(row) if row else None


def doc_state_put(conn: sqlite3.Connection, file_id: str, content_hash: str,
                  items: list[dict], course_links: list[dict],
                  fingerprint: str) -> None:
    conn.execute(
        "INSERT INTO doc_state (file_id, content_hash, items_json, "
        "course_links_json, fingerprint, updated) VALUES (?, ?, ?, ?, ?, ?) "
        "ON CONFLICT(file_id) DO UPDATE SET content_hash=excluded.content_hash, "
        "items_json=excluded.items_json, "
        "course_links_json=excluded.course_links_json, "
        "fingerprint=excluded.fingerprint, updated=excluded.updated",
        (file_id, content_hash, json.dumps(items), json.dumps(course_links),
         fingerprint, _now()))
    conn.commit()


# ---- AI usage, per calendar month ---------------------------------------------
#
# Counted here rather than trusted to the plan, because an allowance nobody
# measures is a promise, not a limit. One row per (month, kind): the month is
# "YYYY-MM" in the student's own timezone, so an allowance resets when their
# month does and not at some UTC hour in the middle of a school night.


def ai_month(when=None) -> str:
    from sillybus import timezones

    now = when or datetime.now(timezones.zone())
    return f"{now.year:04d}-{now.month:02d}"


def ai_usage(conn: sqlite3.Connection, kind: str, month: str | None = None) -> int:
    row = conn.execute("SELECT used FROM ai_usage WHERE month=? AND kind=?",
                       (month or ai_month(), kind)).fetchone()
    return int(row[0]) if row else 0


def ai_usage_all(conn: sqlite3.Connection, month: str | None = None) -> dict:
    target = month or ai_month()
    return {row[0]: int(row[1]) for row in conn.execute(
        "SELECT kind, used FROM ai_usage WHERE month=?", (target,))}


def ai_usage_record(conn: sqlite3.Connection, kind: str,
                    month: str | None = None) -> int:
    """Count one model call. Returns the new total for that month."""
    target = month or ai_month()
    conn.execute(
        "INSERT INTO ai_usage (month, kind, used) VALUES (?, ?, 1) "
        "ON CONFLICT(month, kind) DO UPDATE SET used = used + 1",
        (target, kind))
    conn.commit()
    return ai_usage(conn, kind, target)


# ---- item history (memory of old stuff; the UI only looks at the new) ----------

def remember_items(conn: sqlite3.Connection, items: list[dict]) -> None:
    now = _now()
    conn.executemany(
        "INSERT INTO item_history (item_id, first_seen, last_seen, item_json) "
        "VALUES (?, ?, ?, ?) ON CONFLICT(item_id) DO UPDATE SET "
        "last_seen=excluded.last_seen, item_json=excluded.item_json",
        [(i["item_id"], now, now, json.dumps(i, default=str)) for i in items])
    conn.commit()


def content_key(entry: dict) -> str:
    """A key for "the same line in the same course", stable across rewording.

    An item_id is a hash of the item as extracted, so any improvement to the
    extractor mints a new id for the same line. [MEASURED] 2026-09-02: two
    undated Spanish lines first seen on 2026-08-26 came back with
    `first_seen` of today, purely because that afternoon's prose changes
    altered their titles — which silently restarted the clock the retirement
    rule reads. A fix that any future extractor change disarms is not a fix.

    The raw text the teacher wrote does not change when our reading of it
    does, so that is the key.
    """
    raw = (entry.get("detail") or entry.get("title") or "").strip().lower()
    return f"{entry.get('course_key') or ''}|{' '.join(raw.split())[:160]}"


def first_seen_by_content(conn: sqlite3.Connection) -> dict:
    """{content_key: earliest first_seen} over everything ever remembered.

    The whole table, because the point is to find an ancestor of an item whose
    id has changed. It is small — one row per item ever seen, 80 after a term
    — and read once per refresh.
    """
    out: dict = {}
    for item_id, first_seen, item_json in conn.execute(
            "SELECT item_id, first_seen, item_json FROM item_history"):
        try:
            entry = json.loads(item_json)
        except (TypeError, ValueError):
            continue
        key = content_key(entry)
        if key and (key not in out or first_seen < out[key]):
            out[key] = first_seen
    return out


def remembered_items(conn: sqlite3.Connection, limit: int = 4000) -> list[dict]:
    """Every item ever seen, newest first. Small: one row per item, ever.

    `first_seen_by_content` already walks this table for the retirement clock
    and throws the items away once it has their dates. `repeats` wants the
    items themselves — a title and a due date are how a series is recognised,
    and history is the only place doc-sourced and hand-added work leaves a
    trace, since Canvas's assignment list has never heard of either.

    A row whose JSON will not parse is skipped rather than raised on: this is
    read to draw a label, and a label is never worth failing a refresh for.
    """
    out: list[dict] = []
    for (item_json,) in conn.execute(
            "SELECT item_json FROM item_history ORDER BY last_seen DESC LIMIT ?",
            (limit,)):
        try:
            entry = json.loads(item_json)
        except (TypeError, ValueError):
            continue
        if isinstance(entry, dict):
            out.append(entry)
    return out


def first_seen_map(conn: sqlite3.Connection, item_ids: list[str]) -> dict:
    """{item_id: first_seen ISO string} for the ids given.

    `item_history` has recorded this since the beginning and nothing read it.
    It is the only honest clock for "how long has this been on the board
    unanswered" — see pipeline.retire_stale_undated.
    """
    if not item_ids:
        return {}
    out: dict = {}
    for chunk in range(0, len(item_ids), 400):
        window = item_ids[chunk:chunk + 400]
        marks = ",".join("?" * len(window))
        for row in conn.execute(
                f"SELECT item_id, first_seen FROM item_history "
                f"WHERE item_id IN ({marks})", window):
            out[row[0]] = row[1]
    return out


# ---- accelerated assignments (study guides) -----------------------------------

def acceleration_get(conn: sqlite3.Connection, item_id: str) -> dict | None:
    row = conn.execute("SELECT * FROM accelerations WHERE item_id=?",
                       (item_id,)).fetchone()
    if not row:
        return None
    out = dict(row)
    out["result"] = json.loads(out.pop("result_json"))
    return out


def acceleration_ids(conn: sqlite3.Connection) -> set:
    """Which items have a study guide written. Ids only — the chat payload
    lists them cheaply and fetches the text only when asked about one."""
    return {row[0] for row in conn.execute("SELECT item_id FROM accelerations")}


def acceleration_recent(conn: sqlite3.Connection, limit: int = 12) -> list[dict]:
    """The study guides most recently written, newest first — enough of each
    to draw a row that reopens it, never the whole guide.

    [ASKED] 2026-09-20: Accelerates belong in the "Recent chats" list next to
    the questions, because from a student's side both are "a thing I asked
    the AI for" and both are worth getting back to.
    """
    out = []
    for row in conn.execute(
            "SELECT item_id, result_json, created FROM accelerations "
            "ORDER BY created DESC LIMIT ?", (int(limit),)):
        try:
            result = json.loads(row[1])
        except ValueError:
            continue
        out.append({"item_id": row[0],
                    "title": result.get("item_title") or "",
                    "headline": result.get("headline") or "",
                    "created": row[2]})
    return out


def acceleration_put(conn: sqlite3.Connection, item_id: str, content_hash: str,
                     result: dict, provider: str) -> None:
    conn.execute(
        "INSERT INTO accelerations (item_id, content_hash, result_json, provider, created) "
        "VALUES (?, ?, ?, ?, ?) ON CONFLICT(item_id) DO UPDATE SET "
        "content_hash=excluded.content_hash, result_json=excluded.result_json, "
        "provider=excluded.provider, created=excluded.created",
        (item_id, content_hash, json.dumps(result, ensure_ascii=False), provider, _now()))
    conn.commit()


def acceleration_delete(conn: sqlite3.Connection, item_id: str) -> None:
    conn.execute("DELETE FROM accelerations WHERE item_id=?", (item_id,))
    conn.commit()


# ---- chat sessions ----------------------------------------------------------

# ---- chat history -------------------------------------------------------------
#
# The conversation used to live only in the page. Reloading the app, or opening
# it the next morning, showed an empty box — and the questions a student asks
# are a record of what confused them, which is worth keeping. Stored on their
# own Mac like everything else.
#
# Trimmed rather than unbounded: a year of chat is thousands of rows nobody
# reads, and the model is only ever sent the last few turns of the one
# conversation being continued (chat_memory.HISTORY_TURNS).
CHAT_HISTORY_KEEP = 1000

# A conversation's title is its first question, clipped — the student's own
# words, never a summary a model wrote (a summary can misstate what was asked).
CHAT_TITLE_CHARS = 60


def chat_title(text: str) -> str:
    flat = " ".join((text or "").split())
    if len(flat) <= CHAT_TITLE_CHARS:
        return flat or "New chat"
    return flat[:CHAT_TITLE_CHARS - 1].rstrip() + "…"


def chat_message_add(conn: sqlite3.Connection, role: str, text: str,
                     meta: dict | None = None,
                     conversation_id: str | None = None) -> None:
    now = _now()
    if conversation_id:
        # Created by its first message rather than when the id is minted: a
        # turn that fails before anything is recorded leaves no empty row in
        # the list. The title is set once, from that first message.
        conn.execute(
            "INSERT INTO chat_conversations (id, title, created_at, updated_at) "
            "VALUES (?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET "
            "updated_at=excluded.updated_at",
            (conversation_id, chat_title(text), now, now))
    conn.execute(
        "INSERT INTO chat_messages (asked_at, role, text, meta_json, conversation_id) "
        "VALUES (?, ?, ?, ?, ?)",
        (now, role, text, json.dumps(meta or {}, default=str), conversation_id))
    conn.execute(
        "DELETE FROM chat_messages WHERE id NOT IN "
        "(SELECT id FROM chat_messages ORDER BY id DESC LIMIT ?)",
        (CHAT_HISTORY_KEEP,))
    # A conversation whose every message was trimmed would list as an empty
    # chat that opens to nothing.
    conn.execute(
        "DELETE FROM chat_conversations WHERE id NOT IN (SELECT conversation_id "
        "FROM chat_messages WHERE conversation_id IS NOT NULL)")
    conn.commit()


def _message_rows(rows) -> list[dict]:
    out = []
    for asked_at, role, text, meta_json, conversation_id in rows:
        try:
            meta = json.loads(meta_json or "{}")
        except ValueError:
            meta = {}
        out.append({"at": asked_at, "role": role, "text": text, "meta": meta,
                    "conversation_id": conversation_id})
    return out


# Messages from before conversations existed have conversation_id NULL. They
# are listed under this id, read-only: a new turn sent to it starts a new
# conversation rather than writing more NULL rows.
LEGACY_CONVERSATION = "earlier"


def chat_conversations(conn: sqlite3.Connection, limit: int = 100) -> list[dict]:
    """Newest first: [{id, title, updated_at, message_count}]."""
    rows = conn.execute(
        "SELECT c.id, c.title, c.updated_at, count(m.id) FROM chat_conversations c "
        "JOIN chat_messages m ON m.conversation_id = c.id "
        "GROUP BY c.id ORDER BY c.updated_at DESC, max(m.id) DESC LIMIT ?",
        (int(limit),)).fetchall()
    out = [{"id": r[0], "title": r[1], "updated_at": r[2], "message_count": int(r[3])}
           for r in rows]
    legacy = conn.execute(
        "SELECT count(*), max(asked_at) FROM chat_messages "
        "WHERE conversation_id IS NULL").fetchone()
    if legacy[0]:
        out.append({"id": LEGACY_CONVERSATION, "title": "Earlier chats",
                    "updated_at": legacy[1], "message_count": int(legacy[0])})
    return out


def chat_conversation(conn: sqlite3.Connection, conversation_id: str) -> dict | None:
    """{conversation, messages} oldest first, or None for an unknown id."""
    if conversation_id == LEGACY_CONVERSATION:
        rows = conn.execute(
            "SELECT asked_at, role, text, meta_json, conversation_id FROM chat_messages "
            "WHERE conversation_id IS NULL ORDER BY id").fetchall()
        if not rows:
            return None
        return {"conversation": {"id": LEGACY_CONVERSATION, "title": "Earlier chats",
                                 "updated_at": rows[-1][0], "message_count": len(rows)},
                "messages": _message_rows(rows)}
    head = conn.execute(
        "SELECT id, title, updated_at FROM chat_conversations WHERE id=?",
        (conversation_id,)).fetchone()
    if head is None:
        return None
    rows = conn.execute(
        "SELECT asked_at, role, text, meta_json, conversation_id FROM chat_messages "
        "WHERE conversation_id=? ORDER BY id", (conversation_id,)).fetchall()
    return {"conversation": {"id": head[0], "title": head[1], "updated_at": head[2],
                             "message_count": len(rows)},
            "messages": _message_rows(rows)}


def chat_recent_turns(conn: sqlite3.Connection, conversation_id: str,
                      limit: int) -> list[dict]:
    """The last `limit` messages of one conversation, oldest first."""
    rows = conn.execute(
        "SELECT asked_at, role, text, meta_json, conversation_id FROM chat_messages "
        "WHERE conversation_id=? ORDER BY id DESC LIMIT ?",
        (conversation_id, int(limit))).fetchall()
    return _message_rows(list(reversed(rows)))


# ---- chat memory ----------------------------------------------------------------
#
# Only what the student explicitly said "remember …" about, in their own words.
# Nothing is extracted from conversations. Bounds live in chat_memory.py.

def chat_memories(conn: sqlite3.Connection) -> list[dict]:
    """Oldest first: [{id, text, created_at}]."""
    return [{"id": int(r[0]), "text": r[1], "created_at": r[2]} for r in conn.execute(
        "SELECT id, text, created_at FROM chat_memories ORDER BY id")]


def chat_memory_add(conn: sqlite3.Connection, text: str) -> int:
    cur = conn.execute("INSERT INTO chat_memories (text, created_at) VALUES (?, ?)",
                       (text, _now()))
    conn.commit()
    return int(cur.lastrowid)


def chat_memory_delete(conn: sqlite3.Connection, memory_ids: list[int]) -> int:
    if not memory_ids:
        return 0
    marks = ",".join("?" * len(memory_ids))
    cur = conn.execute(f"DELETE FROM chat_memories WHERE id IN ({marks})",
                       [int(i) for i in memory_ids])
    conn.commit()
    return cur.rowcount


def chat_memory_clear(conn: sqlite3.Connection) -> int:
    count = conn.execute("SELECT count(*) FROM chat_memories").fetchone()[0]
    conn.execute("DELETE FROM chat_memories")
    conn.commit()
    return int(count)


def chat_history(conn: sqlite3.Connection, limit: int = 60, q: str = "") -> list[dict]:
    """Oldest first, so the page can replay it in order. `q` keeps only the
    turns (question + its answer) whose text contains it."""
    if q:
        like = f"%{q}%"
        rows = conn.execute(
            "SELECT m.asked_at, m.role, m.text, m.meta_json, m.conversation_id FROM chat_messages m "
            "WHERE m.text LIKE ? COLLATE NOCASE "
            "   OR EXISTS (SELECT 1 FROM chat_messages o WHERE o.role='user' AND o.text LIKE ? COLLATE NOCASE "
            "              AND o.id = (SELECT max(id) FROM chat_messages p WHERE p.role='user' AND p.id <= m.id)) "
            "ORDER BY m.id DESC LIMIT ?", (like, like, limit)).fetchall()
    else:
        rows = conn.execute(
            "SELECT asked_at, role, text, meta_json, conversation_id FROM chat_messages "
            "ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return _message_rows(list(reversed(rows)))


def chat_history_clear(conn: sqlite3.Connection) -> int:
    """Every message and conversation. Memories are NOT touched — they are
    removed only by "forget …" or the memory endpoints."""
    count = conn.execute("SELECT count(*) FROM chat_messages").fetchone()[0]
    conn.execute("DELETE FROM chat_messages")
    conn.execute("DELETE FROM chat_conversations")
    conn.execute("DELETE FROM chat_sessions WHERE session_key LIKE 'conversation:%'")
    conn.commit()
    return int(count)


def chat_session_get(conn: sqlite3.Connection, session_key: str) -> str | None:
    row = conn.execute(
        "SELECT provider_session_id FROM chat_sessions WHERE session_key=?",
        (session_key,)).fetchone()
    return row["provider_session_id"] if row else None


def chat_session_put(conn: sqlite3.Connection, session_key: str, provider_id: str) -> None:
    conn.execute(
        "INSERT INTO chat_sessions (session_key, provider_session_id, updated) "
        "VALUES (?, ?, ?) ON CONFLICT(session_key) DO UPDATE SET "
        "provider_session_id=excluded.provider_session_id, updated=excluded.updated",
        (session_key, provider_id, _now()))
    conn.commit()


# ------------------------------------------------------------------ quizzes
#
# Practice quizzes the app wrote (sillybus/quizmaker.py). One row per quiz,
# with every attempt the student made at it kept beside it.


def quiz_put(conn: sqlite3.Connection, quiz_id: str, course_key: str,
             item_id: str | None, result: dict, provider: str) -> None:
    conn.execute(
        "INSERT OR REPLACE INTO quizzes (id, course_key, item_id, created, result_json, "
        "provider, attempts_json) VALUES (?, ?, ?, ?, ?, ?, "
        "COALESCE((SELECT attempts_json FROM quizzes WHERE id = ?), '[]'))",
        (quiz_id, course_key, item_id, _now(), json.dumps(result, ensure_ascii=False),
         provider, quiz_id))
    conn.commit()


def _quiz_row(row) -> dict:
    quiz_id, course_key, item_id, created, result_json, provider, attempts_json = row
    try:
        result = json.loads(result_json)
    except (TypeError, ValueError):
        result = {}
    try:
        attempts = json.loads(attempts_json or "[]")
    except (TypeError, ValueError):
        attempts = []
    return {"id": quiz_id, "course_key": course_key, "item_id": item_id,
            "created": created, "provider": provider, "result": result,
            "attempts": attempts}


def quiz_get(conn: sqlite3.Connection, quiz_id: str) -> dict | None:
    row = conn.execute(
        "SELECT id, course_key, item_id, created, result_json, provider, attempts_json "
        "FROM quizzes WHERE id = ?", (quiz_id,)).fetchone()
    return _quiz_row(row) if row else None


def quiz_recent(conn: sqlite3.Connection, course_key: str | None = None,
                limit: int = 20) -> list[dict]:
    if course_key:
        rows = conn.execute(
            "SELECT id, course_key, item_id, created, result_json, provider, attempts_json "
            "FROM quizzes WHERE course_key = ? ORDER BY created DESC LIMIT ?",
            (course_key, limit)).fetchall()
    else:
        rows = conn.execute(
            "SELECT id, course_key, item_id, created, result_json, provider, attempts_json "
            "FROM quizzes ORDER BY created DESC LIMIT ?", (limit,)).fetchall()
    return [_quiz_row(r) for r in rows]


def quiz_add_attempt(conn: sqlite3.Connection, quiz_id: str, attempt: dict) -> None:
    current = quiz_get(conn, quiz_id)
    if current is None:
        return
    attempts = (current.get("attempts") or []) + [attempt]
    conn.execute("UPDATE quizzes SET attempts_json = ? WHERE id = ?",
                 (json.dumps(attempts[-20:], ensure_ascii=False), quiz_id))
    conn.commit()


def quiz_delete(conn: sqlite3.Connection, quiz_id: str) -> None:
    conn.execute("DELETE FROM quizzes WHERE id = ?", (quiz_id,))
    conn.commit()
