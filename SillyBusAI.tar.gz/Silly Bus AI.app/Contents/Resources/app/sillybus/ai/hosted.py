"""HostedProvider — SillyBus AI included.

The same Messages API calls as AnthropicApiProvider, sent to the owner's
server instead of to Anthropic, with no key on this computer: the server
adds the owner's key, and keeps the free month, the plan and the $1 a month
(sillybus/billing.py says what each is). Always Haiku 4.5, the only model
the server takes.

When the server refuses — this month's AI allowance (10¢ for everyone not
paying, $1 for a subscriber) is used, the day's limit is reached — its own
sentence is the error, word for word, so the chat bubble or the Accelerate
card says what happened rather than an HTTP status. Learning a class
(LearnProvider) spends from its own pot on the server and is never refused
for not paying.
"""

import httpx

from sillybus import billing
from sillybus.ai.anthropic_api import AnthropicApiProvider
from sillybus.ai.base import ProviderError


class HostedProvider(AnthropicApiProvider):
    name = "hosted"

    def __init__(self):
        self.key = ""
        self.model = billing.MODEL

    @property
    def url(self) -> str:
        return billing.server() + "/v1/messages"

    def available(self) -> tuple[bool, str]:
        if not billing.enabled():
            return False, "SillyBus AI included is turned off"
        return True, "SillyBus AI included (the owner's server)"

    def _headers(self) -> dict:
        return billing.headers()

    def _error(self, exc) -> str:
        response = getattr(exc, "response", None)
        if response is not None:
            return billing.message_of(response) + _settings_hint(response.status_code)
        return f"Could not reach SillyBus AI's server ({exc.__class__.__name__}). Check the internet connection."

    def _stream_note(self, exc) -> str:
        return "\n\n" + self._error(exc)


class LearnProvider(HostedProvider):
    """Learning a class, on the owner's key ([ASKED] 2026-10-06: "only 10c in
    API tokens a month plus Cost of learning a class"). The same server, the
    same Haiku, marked `x-bgx-purpose: learn` so the server keeps it out of
    the 10¢ a month and never refuses it for not paying — the homework list
    is the free part of SillyBus, and learning a class is what makes a
    teacher's doc readable at all."""
    name = "hosted"

    def available(self) -> tuple[bool, str]:
        ok, reason = super().available()
        return ok, (reason.replace("SillyBus AI included", "Learning classes on SillyBus's server") if ok else reason)

    def _headers(self) -> dict:
        return {**billing.headers(), "x-bgx-purpose": "learn"}


class FallbackProvider:
    """Try the first provider; if it refuses (no internet, this month's
    learning pot is used, the server is down), ask the second — the student's
    own Claude, when they have one — rather than leaving a class unlearned."""

    def __init__(self, first, second):
        self.first, self.second = first, second
        self.name = first.name
        # Which one actually answered the last call — so a profile says
        # "learned by claude_code" when the student's own Claude did it, not
        # "hosted" (prosecution 2026-10-06).
        self.answered_by = first.name

    def available(self) -> tuple[bool, str]:
        return self.first.available()

    def _try(self, method, **kwargs):
        try:
            out = getattr(self.first, method)(**kwargs)
            self.answered_by = self.first.name
            return out
        except ProviderError as first_error:
            ok, _ = self.second.available()
            if not ok:
                raise
            try:
                out = getattr(self.second, method)(**kwargs)
                self.answered_by = self.second.name
                return out
            except ProviderError as second_error:
                # Both said no: both reasons, so a broken local Claude is not
                # hidden behind the server's sentence.
                raise ProviderError(f"{first_error} — and your own {self.second.name} said: {second_error}") from second_error

    def complete(self, **kwargs):
        return self._try("complete", **kwargs)

    def complete_structured(self, **kwargs):
        return self._try("complete_structured", **kwargs)

    def complete_vision(self, **kwargs):
        return self._try("complete_vision", **kwargs)

    def stream(self, **kwargs):
        return self.first.stream(**kwargs)


def _settings_hint(status: int) -> str:
    # 402: the free month is over — the way to pay is in Settings.
    return " Open Settings → About → Plan to subscribe." if status == 402 else ""


__all__ = ["HostedProvider", "LearnProvider", "FallbackProvider", "httpx"]
