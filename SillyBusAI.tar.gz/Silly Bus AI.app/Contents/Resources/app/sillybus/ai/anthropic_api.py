"""AnthropicApiProvider — used only if ANTHROPIC_API_KEY is ever present.
Kept minimal and dependency-free (httpx straight to the Messages API)."""

import base64
import json
import os

import httpx

from sillybus import config
from sillybus.ai import jsonshape
from sillybus.ai.base import ProviderError

API = "https://api.anthropic.com/v1/messages"
VERSION = "2023-06-01"


def headers(key: str) -> dict:
    """The request headers, shared with the key tester in the extension.

    `anthropic-dangerous-direct-browser-access` is what the API requires of
    a request that carries a browser Origin — which every request from the
    Chrome extension does (chrome-extension://…). Without it the API refuses
    the call as unauthenticated even when the key is right ([MEASURED]
    2026-09-14: HTTP 401 on every chat answer in the extension with a key
    that worked elsewhere). It is harmless from the Mac app, where there is
    no Origin, and the key is the student's own, so "dangerous" here means
    only that the key is in the browser — which is exactly where Options
    put it, on purpose."""
    return {"x-api-key": key, "anthropic-version": VERSION,
            "anthropic-dangerous-direct-browser-access": "true",
            "content-type": "application/json"}


def _describe(exc, response=None) -> str:
    """The API's own error message, so a 401 says WHY, never the key."""
    body = ""
    resp = response if response is not None else getattr(exc, "response", None)
    if resp is not None:
        try:
            err = resp.json().get("error") or {}
            body = f"{err.get('type', '')}: {err.get('message', '')}".strip(": ")
        except Exception:  # noqa: BLE001
            body = (getattr(resp, "text", "") or "")[:200]
    return f"{exc}" + (f" — {body}" if body else "")


class AnthropicApiProvider:
    name = "anthropic_api"
    # Where requests go and how they are signed — the hosted provider
    # (ai/hosted.py) changes only these two and how an error reads.
    url = API

    def _headers(self) -> dict:
        return headers(self.key)

    def _error(self, exc) -> str:
        return f"Anthropic API failed: {_describe(exc)}"

    def __init__(self):
        self.key = os.environ.get("ANTHROPIC_API_KEY", "")
        alias = config.load()["ai"]["claude_model"]
        self.model = {"sonnet": "claude-sonnet-5", "opus": "claude-opus-5",
                      "haiku": "claude-haiku-5-5"}.get(alias, alias)

    def available(self) -> tuple[bool, str]:
        if not self.key:
            return False, "ANTHROPIC_API_KEY is not set"
        return True, "Anthropic API key present"

    def _call(self, system, messages, max_tokens, timeout):
        try:
            response = httpx.post(self.url, timeout=timeout, headers=self._headers(),
                json={"model": self.model, "max_tokens": max_tokens,
                      "system": system or "", "messages": messages})
            response.raise_for_status()
        except httpx.HTTPError as exc:
            raise ProviderError(self._error(exc)) from exc
        payload = response.json()
        blocks = payload.get("content", [])
        text = "".join(b.get("text", "") for b in blocks if b.get("type") == "text")
        # A reply that ran out of room is NOT a reply. It comes back as
        # perfectly ordinary-looking text that simply stops mid-sentence, and
        # every caller that parses it then reports something misleading —
        # complete_structured called it "API emitted non-JSON", which reads
        # like the model misbehaved rather than like the budget being too
        # small. Named here, once, where the truth is known.
        if payload.get("stop_reason") == "max_tokens":
            raise ProviderError(
                f"the answer was longer than the {max_tokens}-token reply budget and "
                "was cut off mid-sentence")
        return text

    def complete(self, *, system: str, user: str, max_tokens: int = 1024,
                 timeout: int = 120) -> str:
        return self._call(system, [{"role": "user", "content": user}],
                          max_tokens, timeout)

    def complete_vision(self, *, system: str, user: str,
                        images: list[tuple[str, bytes]],
                        max_tokens: int = 1500, timeout: int = 180) -> str:
        """The Messages API takes image blocks directly, so this one is the
        plain case — unlike the CLI, which needs a streaming input format."""
        if not images:
            raise ProviderError("no pictures were given to look at")
        content: list[dict] = [
            {"type": "image",
             "source": {"type": "base64", "media_type": media,
                        "data": base64.b64encode(raw).decode("ascii")}}
            for media, raw in images]
        content.append({"type": "text", "text": user})
        return self._call(system, [{"role": "user", "content": content}],
                          max_tokens, timeout)

    def complete_structured(self, *, system: str, user: str, schema: dict,
                            timeout: int = 240, max_tokens: int = 8192) -> dict:
        """[MEASURED] 2026-09-20. The budget here was a flat 4096 tokens, and a
        study guide does not fit in 4096 tokens: `guide_markdown` alone is a
        condensed version of a whole reading, and it arrives alongside key
        terms, diagrams, practice questions and watch-outs. The reply was cut
        off part-way through the JSON, json.loads failed on the fragment, and
        ⚡ Accelerate died every time on anything with real material behind it.
        Callers that need more room now say so."""
        prompt = (f"{user}\n\nAnswer ONLY with a JSON object matching this "
                  f"schema, no prose:\n{json.dumps(schema)}")
        text = self._call(system, [{"role": "user", "content": prompt}],
                          max_tokens, timeout).strip()
        if text.startswith("```"):
            text = text.strip("`")
            text = text[text.find("{"):text.rfind("}") + 1]
        try:
            parsed = json.loads(text)
        except ValueError as exc:
            raise ProviderError(f"API emitted non-JSON: {text[:200]!r}") from exc
        # The schema was pasted into the prompt and then never checked. Profiling
        # got away with it because profiling/schema.validate runs downstream; the
        # chat action path had no net at all.
        problems = jsonshape.errors(parsed, schema)
        if problems:
            raise ProviderError("API reply did not match the schema: "
                                + "; ".join(problems[:4]))
        return parsed

    def stream(self, *, system: str, user: str, session_id: str | None = None,
               max_tokens: int = 1024, timeout: int = 120):
        """Really streams, via the Messages API's SSE response.

        It used to satisfy the streaming interface by blocking for the whole
        answer and yielding it as one chunk. That is not a stream: the caller's
        whole reason for streaming — text on screen while the model is still
        talking — was silently unavailable, and only for this provider.

        A stream that dies mid-answer still has to produce a `result`, because
        the caller stamps grounding on whatever arrived; the partial text is
        returned with the error appended rather than thrown away.
        """
        collected: list[str] = []
        try:
            with httpx.stream("POST", self.url, timeout=timeout, headers={
                    **self._headers(),
                    "content-type": "application/json"},
                    json={"model": self.model, "max_tokens": max_tokens,
                          "system": system or "", "stream": True,
                          "messages": [{"role": "user", "content": user}]}) as response:
                if response.status_code >= 400:
                    response.read()
                response.raise_for_status()
                for line in response.iter_lines():
                    if not line or not line.startswith("data:"):
                        continue
                    body = line[5:].strip()
                    if not body or body == "[DONE]":
                        continue
                    try:
                        event = json.loads(body)
                    except ValueError:
                        continue
                    if event.get("type") != "content_block_delta":
                        continue
                    piece = (event.get("delta") or {}).get("text") or ""
                    if piece:
                        collected.append(piece)
                        yield {"type": "text", "text": piece}
        except httpx.HTTPError as exc:
            note = self._stream_note(exc)
            collected.append(note)
            yield {"type": "text", "text": note}
        yield {"type": "result", "text": "".join(collected), "session_id": None}

    def _stream_note(self, exc) -> str:
        return f"\n\n(the answer was cut off: {exc})"
