"""Settings, changed by asking the chat.

[ASKED] 2026-10-07: *"make it so the chat can do anything you ask it like put
SillyBus in dark mode or simple mode or dashbord mode ext"* — and, about
Downtime, *"set a down time … or tell the chat to do it"*.

This reader runs in `/api/chat` BEFORE `lookup.py` and before any model, for
the reasons the lookup does: it cannot invent, it costs nothing, and it works
on a Mac with no AI at all. Three rules shape all of it:

1. **Only what the app really has.** Every value is one the Settings page
   offers and `prefs.py` would accept. "Simple mode" and "dashboard mode" were
   two layouts until 0.20 merged them into one; asked for today they are a
   simpler LOOK of the one layout (no pattern, one status dot, no estimates,
   roomy) and the full one, and the reply says exactly which switches moved.
2. **Never guess.** A request that could mean two things gets a short
   question naming the options, with buttons that say the full sentence.
   "Downtime 10 to 7" is not 10 PM to 7 AM until the student says so.
3. **Never account, password, payment, or anything that loses data.** Those
   are refused with the place in Settings where they live.

Three ways a change is applied, each for a reason:

- Appearance and board preferences (`ui` in config.json) are applied BY THE
  PAGE, through the Settings page's own `setPref()`, so chat and Settings can
  never disagree and the board repaints at once. Each carries `previous`,
  which is what the reply's Undo puts back.
- Focus is applied by the page too, through the same functions Settings uses:
  in Chrome, turning it on needs Chrome's own permission prompt, and loosening
  Block needs the PIN. A server-side write would skip both.
- Downtime, the Mac reminder times and which sources are read are written
  here, server-side, and the reply says what was done.

The model may propose a preference change as well (`chat.answer_action`), but
only through `validate_model_setting`, which holds it to this same whitelist.
"""

from __future__ import annotations

import re

from sillybus.logging_setup import get

log = get("commands")

# ---------------------------------------------------------------------------
# What the app offers. Kept in step with app.js (ACCENTS_UI, PATTERN_COLORS_UI,
# PATTERNS_UI, FONTS_*_UI) and prefs.py; tests/test_chat_settings.py checks
# both directions so a colour cannot be offered here that Settings lacks.

ACCENTS = {
    "teal": "#0f766e", "blue": "#2563eb", "indigo": "#4f46e5", "purple": "#7c3aed",
    "pink": "#db2777", "red": "#e11d48", "orange": "#ea580c", "yellow": "#ca8a04",
    "green": "#16a34a", "cyan": "#0891b2", "gray": "#475569", "brown": "#b45309",
}
PATTERN_COLORS = {
    "teal": "#0f766e", "blue": "#2563eb", "purple": "#7c3aed", "pink": "#db2777",
    "red": "#dc2626", "orange": "#ea580c", "yellow": "#ca8a04", "green": "#16a34a",
    "cyan": "#0891b2", "gray": "#475569", "black": "#111827", "white": "#ffffff",
}
COLOR_ALIASES = {
    "violet": "purple", "rose": "red", "crimson": "red", "gold": "yellow",
    "golden": "yellow", "aqua": "cyan", "grey": "gray", "slate": "gray",
    "amber": "brown", "magenta": "pink",
}
# Colour words a student might say that no swatch is. Recognised so the reply
# can say "not that one — here are the ones there are" instead of nothing.
OTHER_COLORS = {"black", "white", "beige", "tan", "navy", "maroon", "lavender",
                "lime", "silver", "mint", "peach", "coral", "olive", "salmon",
                "burgundy", "khaki", "rainbow"}
SHADES = {"dark", "darker", "light", "lighter", "bright", "pale", "deep", "neon", "pastel"}

THEMES = {"dark": "dark", "night": "dark", "black": "dark", "darker": "dark",
          "light": "light", "white": "light", "bright": "light", "lighter": "light",
          "brighter": "light", "day": "light",
          "warm": "warm", "warmer": "warm", "cream": "warm", "sepia": "warm",
          "offwhite": "warm",
          "system": "system", "auto": "system", "automatic": "system"}
THEME_SAID = {"dark": "dark mode is on", "light": "light mode is on",
              "warm": "the warm theme is on",
              "system": "the theme follows your Mac now"}

PATTERNS = ("none", "glow", "dots", "grid", "aurora", "drift", "waves", "orbit",
            "tide", "breathe")
MOVING_PATTERNS = ("aurora", "drift", "waves", "orbit", "tide", "breathe")

FONTS_BODY = {"inter": "Inter", "source_serif": "Source Serif 4", "serif": "Source Serif 4",
              "space_grotesk": "Space Grotesk", "nunito": "Nunito",
              "jetbrains_mono": "JetBrains Mono", "mono": "JetBrains Mono",
              "monospace": "JetBrains Mono", "system_font": "system-ui"}
FONTS_HEAD = {"fraunces": "Fraunces", "plus_jakarta": "Plus Jakarta Sans",
              "jakarta": "Plus Jakarta Sans", "dm_serif": "DM Serif Display",
              "space_grotesk": "Space Grotesk", "inter": "Inter", "nunito": "Nunito"}

# What a question about fonts offers, as words the reader reads back.
FONT_CHOICES_BODY = [("Inter", "inter"), ("Source Serif", "source serif"),
                     ("Space Grotesk", "space grotesk"), ("Nunito", "nunito"),
                     ("JetBrains Mono", "jetbrains mono"), ("System", "system font")]
FONT_CHOICES_HEAD = [("Fraunces", "fraunces"), ("Plus Jakarta", "plus jakarta"),
                     ("DM Serif", "dm serif"), ("Space Grotesk", "space grotesk"),
                     ("Inter", "inter"), ("Nunito", "nunito")]

TEXT_SIZE = (11, 22)
TEXT_STEP = 2

# The two looks. Since 0.23.0.0 "simple" is a real screen — `ui.look`: the
# app opens like a new chat with the pages across the top — and "dashboard"
# is the whole board. (0.22.11.0 wrote this as four appearance switches,
# because the screen did not exist yet; the two landed the same afternoon.)
SIMPLE_LOOK = {"look": "simple"}
FULL_LOOK = {"look": "board"}

STRIP_TABS = {"assignments": "work", "homework": "work", "work": "work",
              "life": "life", "personal": "life", "calendar": "calendar",
              "done": "done"}
TAB_NAMES = {"work": "Assignments", "life": "Life", "calendar": "Calendar", "done": "Done"}

# Where "open X" goes. A tab is a page in the strip; a settings page is one of
# app.js's SET_PAGES.
NAV = {
    "home": ("tab", "home", "Home"), "dashboard": ("tab", "home", "Home"),
    "main": ("tab", "home", "Home"), "board": ("tab", "home", "Home"),
    "grades": ("tab", "home", "Home"),
    "assignments": ("tab", "work", "Assignments"), "homework": ("tab", "work", "Assignments"),
    "work": ("tab", "work", "Assignments"), "todo": ("tab", "work", "Assignments"),
    "tasks": ("tab", "work", "Assignments"),
    "life": ("tab", "life", "Life"), "personal": ("tab", "life", "Life"),
    "calendar": ("tab", "calendar", "Calendar"), "schedule": ("tab", "calendar", "Calendar"),
    "done": ("tab", "done", "Done"),
    "settings": ("settings", None, "Settings"), "preferences": ("settings", None, "Settings"),
    "options": ("settings", None, "Settings"),
    "appearance": ("settings", "appearance", "Settings → Appearance"),
    "focus": ("settings", "focus", "Settings → Focus"),
    "connections": ("settings", "connections", "Settings → Connections"),
    "sources": ("settings", "connections", "Settings → Connections"),
    "classes": ("settings", "classes", "Settings → Classes"),
    "courses": ("settings", "classes", "Settings → Classes"),
    "textbooks": ("settings", "textbooks", "Settings → Textbooks"),
    "books": ("settings", "textbooks", "Settings → Textbooks"),
    "main_page": ("settings", "mainpage", "Settings → Main page"),
    "about": ("settings", "about", "Settings → About"),
    "account": ("settings", "about", "Settings → About"),
    "plan": ("settings", "about", "Settings → About"),
    "chat": ("view", "chat", "Chat"),
}
# "show me my calendar" is a question the lookup answers; "show" opens a page
# only when the sentence says page/tab, or the page is a settings page.
SHOW_NEEDS_PAGE = {"home", "grades", "assignments", "homework", "work", "todo", "tasks",
                   "calendar", "schedule", "done", "life", "personal", "classes", "courses"}

# The sources a student can flip (config.DEFAULTS["sources"]).
SOURCES = {
    "announcements": ("canvas_announcements", "Canvas announcements"),
    "discussions": ("canvas_discussions", "Canvas discussions"),
    "front_pages": ("canvas_pages", "the homework on each Canvas course's front page"),
    "ap_classroom": ("ap_classroom", "AP Classroom"),
    "albert": ("albert", "Albert.io"),
    "veracross": ("veracross_assignments", "Veracross's assignments feed"),
    "calendars": ("connections", "the calendars you connected"),
    "calendar_feed": ("canvas_ics_fallback", "Canvas's calendar feed"),
}

FOCUS_SITES = {"youtube": "youtube", "instagram": "instagram", "insta": "instagram",
               "tiktok": "tiktok", "snapchat": "snapchat", "snap": "snapchat",
               "twitter": "x", "x.com": "x", "reddit": "reddit", "facebook": "facebook",
               "fb": "facebook", "discord": "discord", "twitch": "twitch",
               "netflix": "netflix", "pinterest": "pinterest"}

DAYS = ("sun", "mon", "tue", "wed", "thu", "fri", "sat")

# ---------------------------------------------------------------------------
# Reading the sentence

# Joined before splitting into words, so each is one token.
PHRASES = [
    (r"\boff[- ]white\b", "offwhite"), (r"\bdown time\b", "downtime"),
    (r"\bto[- ]do\b", "todo"), (r"\bzoom in\b", "bigger"), (r"\bzoom out\b", "smaller"),
    (r"\bmain page\b", "main_page"), (r"\bsign[- ]ins?\b", "signins"),
    (r"\bap classroom\b", "ap_classroom"), (r"\bapclassroom\b", "ap_classroom"),
    (r"\b(?:front|home|course) ?pages?\b", "front_pages"),
    (r"\bcalendar feed\b", "calendar_feed"), (r"\bical feed\b", "calendar_feed"),
    (r"\bsource serif(?: 4)?\b", "source_serif"), (r"\bspace grotesk\b", "space_grotesk"),
    (r"\bjetbrains mono\b", "jetbrains_mono"), (r"\bsystem font\b", "system_font"),
    (r"\bplus jakarta(?: sans)?\b", "plus_jakarta"), (r"\bdm serif(?: display)?\b", "dm_serif"),
    (r"\bsocial media\b", "social_media"), (r"\bschool nights?\b", "weeknights"),
    (r"\bweek nights?\b", "weeknights"), (r"\bevery (?:day|night)\b", "everyday"),
    (r"\ball week\b", "everyday"), (r"\bx\.com\b", "x.com"),
]

# Words that mean nothing to any rule. "go", "open", "show", "hide", "on",
# "off", "mode" and "and" are NOT here: each changes what a sentence asks.
FILLER = {
    "the", "a", "an", "it", "its", "it's", "my", "me", "to", "into", "in", "app",
    "sillybus", "silly", "bus", "ai", "everything", "whole", "thing", "things",
    "please", "pls", "plz", "can", "could", "would", "will", "you", "u", "i",
    "i'd", "id", "i'm", "like", "want", "wanna", "need", "now", "just", "so",
    "be", "of", "ahead", "let's", "lets", "kindly", "hey", "hi", "ok", "okay",
    "yo", "change", "switch", "turn", "set", "make", "put", "use", "using",
    "flip", "give", "little", "bit", "lot", "much", "way", "too", "really",
    "very", "also", "again", "back", "for", "this", "that", "do", "how", "some",
    "maybe", "pretty", "kinda", "rather", "instead", "actually", "thanks",
    "thank", "thx", "rn", "asap", "then", "colors", "should", "get", "have",
    "is", "are", "with", "everywhere", "whole", "entire", "screen", "looks", "look",
}

# Spelled wrong often enough to be worth knowing, and too short for the
# distance rule below to catch safely.
TYPOS = {"drak": "dark", "dakr": "dark", "darl": "dark", "drk": "dark",
         "mdoe": "mode", "moed": "mode", "mod": "mode", "lite": "light",
         "ligth": "light", "lihgt": "light", "blu": "blue", "bleu": "blue",
         "pnik": "pink", "gren": "green", "grean": "green", "colr": "color",
         "clor": "color", "colur": "color", "colour": "color", "colours": "colors",
         "thme": "theme", "foucs": "focus", "focsu": "focus", "fcous": "focus",
         "ont": "on", "of": "of", "teh": "the", "simpel": "simple", "smiple": "simple",
         "dashbaord": "dashboard", "dashbord": "dashboard", "dashbored": "dashboard",
         "dashborad": "dashboard", "yt": "youtube", "bigr": "bigger", "insta": "insta",
         "settins": "settings", "setings": "settings", "seting": "setting",
         "downtim": "downtime", "dowtime": "downtime", "dwontime": "downtime",
         "purpel": "purple", "pruple": "purple", "purp": "purple", "orang": "orange",
         "yelow": "yellow", "yello": "yellow", "calender": "calendar",
         "calander": "calendar", "assignmets": "assignments", "tiktock": "tiktok",
         "youtub": "youtube", "youtbe": "youtube", "grey": "gray"}

# Words a longer typo is corrected TO, by one edit (two from nine letters up).
VOCAB = {
    "dashboard", "simple", "simpler", "settings", "setting", "calendar", "purple",
    "orange", "yellow", "green", "focus", "downtime", "theme", "light", "color",
    "accent", "bigger", "smaller", "larger", "compact", "roomy", "roomier",
    "weekends", "weekend", "estimates", "reminders", "reminder", "notifications",
    "youtube", "instagram", "tiktok", "snapchat", "discord", "netflix", "reddit",
    "pinterest", "facebook", "twitter", "appearance", "pattern", "background",
    "animations", "animation", "assignments", "connections", "announcements",
    "discussions", "albert", "veracross", "schedule", "motion", "indigo", "violet",
    "grades", "block", "unblock", "blocking", "percent", "percentage", "letters",
    "minimal", "textbooks", "preferences", "density", "spacing", "turquoise",
}
# Real words one edit from a VOCAB word, which must never be "corrected".
COMMON = {
    "right", "night", "might", "fight", "sight", "tight", "eight", "lights",
    "these", "those", "there", "their", "where", "greet", "sample", "dimple",
    "simply", "pimple", "black", "clock", "blink", "flock", "blocks", "alert",
    "switch", "notion", "lotion", "potion", "rooms", "downtown", "fellow",
    "mellow", "bellow", "accept", "ascent", "trades", "grapes", "grader",
    "getting", "letting", "sitting", "betting", "setting", "colon", "motions",
    "smaller", "larger", "letter", "better", "bitter", "titles", "weekday",
}

QUESTION_START = re.compile(
    r"^(?:is|are|was|were|does|did|why|what|whats|what's|when|where|which|who|"
    r"should|shall|will|would i|am i)\b")


def _damerau(a: str, b: str) -> int:
    """Edit distance counting a swap of two neighbours as one edit."""
    d = [[0] * (len(b) + 1) for _ in range(len(a) + 1)]
    for i in range(len(a) + 1):
        d[i][0] = i
    for j in range(len(b) + 1):
        d[0][j] = j
    for i in range(1, len(a) + 1):
        for j in range(1, len(b) + 1):
            cost = 0 if a[i - 1] == b[j - 1] else 1
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)
            if i > 1 and j > 1 and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                d[i][j] = min(d[i][j], d[i - 2][j - 2] + 1)
    return d[len(a)][len(b)]


def _fix_word(word: str) -> str:
    """One word, typo corrected — "dashbord" is "dashboard", "drak" is "dark".
    Only when exactly one vocabulary word is that close; a real word is left
    alone ("night" is not "light")."""
    if word in TYPOS:
        return TYPOS[word]
    if (len(word) < 5 or word in VOCAB or word in COMMON or word in FILLER
            or not word.isalpha()):
        return word
    limit = 2 if len(word) >= 9 else 1
    close = [v for v in VOCAB if abs(len(v) - len(word)) <= limit
             and _damerau(word, v) <= limit]
    return close[0] if len(close) == 1 else word


def normalise(message: str) -> str:
    """Lower case, typos fixed, punctuation that matters kept (":" in times,
    "#" in colours, "." in web addresses)."""
    s = (message or "").strip().lower().replace("’", "'").replace("‘", "'")
    # The page prefixes a class context in the open ("About Chemistry: ...").
    s = re.sub(r"^about [^:]{1,80}:\s*", "", s)
    s = re.sub(r"\b([ap])\.\s?m\.?", r"\1m", s)
    s = re.sub(r"(?<=[\dm])\s*[-–]\s*(?=\d)", " to ", s)     # 10pm-7am
    s = re.sub(r"[!?,;\"()]+", " ", s)
    s = re.sub(r"\.(?=\s|$)", " ", s)                          # a full stop, not a domain
    words = [_fix_word(w) for w in s.split()]
    s = " ".join(words)
    for pattern, joined in PHRASES:
        s = re.sub(pattern, joined, s)
    return re.sub(r"\s+", " ", s).strip()


def _tokens(s: str) -> list[str]:
    return [w for w in s.split() if w not in FILLER]


# ---------------------------------------------------------------------------
# What a rule returns


def _result(say: str, *, actions=None, choices=None, server=None, kind="done") -> dict:
    return {"say": say, "actions": list(actions or []), "choices": list(choices or []),
            "server": server, "kind": kind}


def _question(say: str, choices: list[tuple[str, str]]) -> dict:
    return _result(say, choices=[{"label": label, "say": phrase} for label, phrase in choices],
                   kind="question")


def _open(where: str, *, auto: bool) -> dict:
    kind, target, label = NAV[where]
    action = {"kind": "open", "label": label, "auto": auto}
    if kind == "tab":
        action["tab"] = target
    elif kind == "settings":
        action["view"] = "settings"
        if target:
            action["page"] = target
    else:
        action["view"] = target
    return action


def _set(key: str, value, ui: dict) -> dict:
    return {"kind": "set_pref", "key": key, "value": value, "previous": ui.get(key)}


def _colour_list(names) -> str:
    names = list(names)
    return ", ".join(names[:-1]) + " or " + names[-1]


# ---------------------------------------------------------------------------
# Refusals: the things chat never changes, and where they are instead.

_CHANGE = (r"(?:change|cancel|upgrade|downgrade|switch|stop|end|pause|update|delete|"
           r"remove|reset|turn|get|buy|renew|refund|close|deactivate|edit|new|set)")
REFUSALS = [
    (re.compile(r"\bpass ?(?:word|code)s?\b.*|.*\bpass ?(?:word|code)s?\b"),
     re.compile(r"\b(?:my|change|reset|update|set|new|what|show|tell|forgot|forget|see|"
                r"save|remember|type|enter)\b"),
     "Passwords never go through chat. Your school sign-ins are in Settings → "
     "Connections → Your school sign-ins, and your SillyBus password is changed "
     "with “I forgot my password” on the sign-in screen.", "connections"),
    (re.compile(r"\b(?:sign|log)\s*(?:me\s+)?(?:out|off)\b|\blogout\b|\bsignout\b"), None,
     "I won't sign you out from chat — that's in Settings → About → SillyBus AI account.",
     "about"),
    (re.compile(r"\baccount\b"), re.compile(r"\b" + _CHANGE + r"\b|\bmake\b"),
     "I can't change your SillyBus account from chat — it's in Settings → About → "
     "SillyBus AI account.", "about"),
    (re.compile(r"\b(?:subscription|subscribe|unsubscribe|billing|payments?|pay|paying|"
                r"credit card|debit card|card details|refund|upgrade|downgrade|"
                r"(?:my|the) plan|free trial|trial)\b"),
     re.compile(r"\b" + _CHANGE + r"\b|\b(?:pay|subscribe|unsubscribe|upgrade|downgrade|"
                r"refund|billing)\b"),
     "I can't change your plan or anything about payment from chat — that's in "
     "Settings → About → Plan.", "about"),
    (re.compile(r"\bemail\b"), re.compile(r"\b" + _CHANGE + r"\b|\bdifferent\b"),
     "I can't change your account email from chat — that's in Settings → About → "
     "SillyBus AI account.", "about"),
    (re.compile(r"\b(?:signins|login details|log ?ins?|username|credentials)\b"), None,
     "Sign-in details never go through chat. They're in Settings → Connections → "
     "Your school sign-ins, saved on this Mac only.", "connections"),
    (re.compile(r"\b(?:submit|submitting|submission|hand(?:ing)? in|turn(?:ing)? in)\b"),
     re.compile(r"\b(?:on|off|enable|disable|automatic|automatically|switch|allow)\b"),
     "Handing work in to Canvas is switched on or off only in Settings → Connections, "
     "where it shows exactly what it would send.", "connections"),
    (re.compile(r"\b(?:delete|erase|wipe|clear|reset|forget|remove)\b.{0,40}\b(?:everything|"
                r"all|data|history|chats?|conversation|homework|assignments|tasks|grades|"
                r"board|profile|settings)\b|\bfactory reset\b|\buninstall\b"), None,
     "I won't delete or reset anything from chat — nothing I do here can lose your work. "
     "Clearing the chat is the bin button above it; anything bigger is in Settings.",
     None),
]


def _refusal(s: str) -> dict | None:
    for subject, needs, say, page in REFUSALS:
        if not subject.search(s):
            continue
        if needs is not None and not needs.search(s):
            continue
        actions = [{"kind": "open", "view": "settings", "page": page,
                    "label": "Settings → " + {"connections": "Connections",
                                               "about": "About"}[page],
                    "auto": False}] if page else []
        return _result(say, actions=actions, kind="refused")
    return None


# ---------------------------------------------------------------------------
# The rules. Each takes the clause's tokens and returns a result or None. A
# rule matches only when EVERY word left is one it understands, so a sentence
# that also asks for something else is never half-heard.


def _r_help(s, t, ctx):
    if re.match(r"^(?:what|which) (?:settings |things |stuff )?(?:can|could) (?:you|i) "
                r"(?:change|set|switch|turn on|do with settings)", s) \
            or s in ("settings help", "help with settings", "help settings"):
        return _result(HELP)
    return None


HELP = ("I can change these for you — just say it:\n"
        "• “dark mode”, “light mode”, “warm theme”, “follow my Mac”\n"
        "• “make it purple” — teal, blue, indigo, purple, pink, red, orange, yellow, "
        "green, cyan, gray or brown\n"
        "• “simple mode” or “dashboard mode”\n"
        "• “make the text bigger”, “text size 16”, “make it roomy”, “turn off animations”\n"
        "• “background dots”, “no background pattern”\n"
        "• “hide my grades”, “show grades as letters”, “hide time estimates”, "
        "“show weekends”\n"
        "• “hide the Life tab”, “open settings”, “go to the calendar”\n"
        "• “turn on Focus reminders”, “block YouTube”, “turn Focus off”\n"
        "• “set downtime 10pm to 7am”, “turn off downtime”\n"
        "• “reminders at 7am and 4pm”\n"
        "• “stop reading Canvas announcements”\n"
        "I won't touch passwords, your account, payment, or anything that deletes data.")


def _r_undo(s, t, ctx):
    if re.match(r"^(?:undo(?: that| it)?|change it back|put it back|revert(?: that| it)?|"
                r"go back to how it was)$", s):
        return _result("Tap Undo under the change you want back — I keep each "
                       "change's Undo right under it.", kind="info")
    return None


def _r_nav(s, t, ctx):
    verbs = {"open", "go", "goto", "take", "bring", "pull", "jump", "navigate", "visit",
             "show", "see"}
    said = [w for w in t if w in verbs]
    rest = [w for w in t if w not in verbs and w not in
            {"page", "tab", "screen", "up", "section", "view", "menu", "over", "on"}]
    if not said and not (t in (["settings"], ["settings", "page"], ["preferences"])):
        return None
    if len(rest) == 2 and rest[0] in ("focus", "appearance", "classes", "textbooks",
                                      "connections", "about") and rest[1] == "settings":
        rest = rest[:1]
    if len(rest) == 2 and rest[0] == "settings" and rest[1] in NAV:
        rest = rest[1:]
    if len(rest) != 1 or rest[0] not in NAV:
        return None
    where = rest[0]
    if said and set(said) <= {"show", "see"} and where in SHOW_NEEDS_PAGE \
            and not ({"page", "tab"} & set(t)):
        return None          # "show me my calendar" is the lookup's question
    action = _open(where, auto=True)
    extra = " (Grades are on Home, beside each class.)" if where == "grades" else ""
    return _result(f"Opened {action['label']}.{extra}", actions=[action])


def _r_theme(s, t, ctx):
    allowed = set(THEMES) | {"mode", "theme", "on", "off", "mac", "match", "follow",
                             "same", "as", "os", "computer", "scheme", "go", "appearance"}
    if not t or not set(t) <= allowed:
        return None
    vals = {THEMES[w] for w in t if w in THEMES}
    if {"mac", "computer", "os"} & set(t):
        vals.add("system")
    if not vals:
        if "theme" in t:
            return _question("Which theme? There are four:",
                             [("Light", "light mode"), ("Warm", "warm theme"),
                              ("Dark", "dark mode"), ("Follow the Mac", "follow my Mac")])
        return None
    if len(vals) > 1:
        return _question("Which one — " + " or ".join(sorted(vals)) + "?",
                         [(v.title(), f"{v} mode") for v in sorted(vals)])
    value = vals.pop()
    if "off" in t:
        if value == "system":
            return _question("Turn off following the Mac — light or dark?",
                             [("Light", "light mode"), ("Dark", "dark mode")])
        value = "dark" if value == "light" else "light"
    ui = ctx["ui"]
    if ui.get("theme") == value:
        return _result(f"Already done — {THEME_SAID[value]}.", kind="info")
    return _result(f"Done — {THEME_SAID[value]}.", actions=[_set("theme", value, ui)])


SIMPLE_WORDS = {"simple", "simpler", "simplify", "simplified", "minimal", "minimalist",
                "clean", "cleaner", "uncluttered"}
FULL_WORDS = {"dashboard", "dash", "full", "normal", "default", "regular", "original",
              "classic", "detailed"}


def _r_layout(s, t, ctx):
    allowed = SIMPLE_WORDS | FULL_WORDS | {"mode", "layout", "view", "version", "on", "off",
                                           "style", "ui", "interface", "less", "cluttered",
                                           "clutter", "busy", "go"}
    if not t or not set(t) <= allowed:
        return None
    simple = bool(SIMPLE_WORDS & set(t)) or ("less" in t and {"cluttered", "clutter", "busy"} & set(t))
    full = bool(FULL_WORDS & set(t))
    if simple == full:
        return None
    if "off" in t:
        simple = not simple
    ui = ctx["ui"]
    look = SIMPLE_LOOK if simple else FULL_LOOK
    actions = [_set(k, v, ui) for k, v in look.items() if ui.get(k) != v]
    if simple:
        if not actions:
            return _result("It's already in the simple look.", kind="info")
        return _result(
            "Done — the simple look: it opens like a new chat, with Assignments, Grades, "
            "Calendar, Classes and Settings across the top. Say “dashboard mode” to get "
            "the whole board back.", actions=actions + [_open("home", auto=True)])
    home = _open("home", auto=True)
    if not actions:
        return _result("It's already the whole board — I opened Home.",
                       actions=[home], kind="info")
    return _result("Done — the whole board: every column at once. I opened Home.",
                   actions=actions + [home])


def _colour_in(t):
    names, hexes, others = [], [], []
    for i, w in enumerate(t):
        if re.fullmatch(r"#?[0-9a-f]{6}", w) and (w.startswith("#") or not w.isalpha()):
            hexes.append("#" + w.lstrip("#"))
        elif w in ACCENTS or w in PATTERN_COLORS:
            names.append(w)
        elif w in COLOR_ALIASES:
            names.append(COLOR_ALIASES[w])
        elif w in OTHER_COLORS:
            others.append(w)
    return names, hexes, others


def _r_accent(s, t, ctx):
    if {"background", "pattern", "patterns", "bg", "wallpaper"} & set(t):
        return None
    names, hexes, others = _colour_in(t)
    words = set(ACCENTS) | set(PATTERN_COLORS) | set(COLOR_ALIASES) | OTHER_COLORS
    allowed = words | SHADES | {"color", "accent", "main", "highlight", "theme", "go", "of",
                                "shade", "brand"}
    rest = [w for w in t if w not in allowed and w not in hexes and "#" + w not in hexes]
    if rest:
        if {"text", "font", "words"} & set(rest) and (names or others or "color" in t):
            return _result("Text colour follows the theme, so it can't be set on its own — "
                           "try “dark mode”, or change the accent with “make it purple”.",
                           kind="info")
        return None
    listing = _colour_list(list(ACCENTS))
    choices = [(n.title(), f"make it {n}") for n in ACCENTS]
    if not names and not hexes:
        if others and len(t) <= 3:
            return _question(f"{others[0].title()} isn't one of the colours — the accent can "
                             f"be {listing}.", choices)
        if "color" in t or "accent" in t:
            return _question(f"Which colour? The accent can be {listing}.", choices)
        return None
    if len(set(names)) + len(hexes) > 1:
        return _question("Which one? The accent is one colour.",
                         [(n.title(), f"make it {n}") for n in dict.fromkeys(names)])
    if hexes:
        value = hexes[0]
        said = value
    else:
        name = names[0]
        if name not in ACCENTS:
            return _question(f"{name.title()} isn't one of the accent colours — it can be "
                             f"{listing}.", choices)
        for i, w in enumerate(t[:-1]):
            if w in SHADES and t[i + 1] in (name,) + tuple(k for k, v in COLOR_ALIASES.items() if v == name):
                return _question(f"There's one {name} — the colours are {listing}. "
                                 f"Want plain {name}?",
                                 [(name.title(), f"make it {name}")] + choices[:0])
        value = ACCENTS[name]
        said = name
    ui = ctx["ui"]
    if (ui.get("accent") or "").lower() == value:
        return _result(f"It's already {said}.", kind="info")
    return _result(f"Done — the accent colour is {said} now.", actions=[_set("accent", value, ui)])


def _r_pattern(s, t, ctx):
    bg = {"background", "pattern", "patterns", "bg", "wallpaper"}
    if not bg & set(t):
        return None
    names, hexes, others = _colour_in(t)
    allowed = (bg | set(PATTERNS) | set(PATTERN_COLORS) | set(COLOR_ALIASES) | OTHER_COLORS
               | {"no", "off", "on", "animated", "moving", "still", "color", "match", "accent",
                  "plain", "blank", "nothing", "remove", "go", "same", "as", "an", "one",
                  "custom", "picture", "photo", "image"})
    if not set(t) <= allowed | set(hexes) | {h.lstrip("#") for h in hexes}:
        return None
    ui = ctx["ui"]
    if {"picture", "photo", "image", "custom"} & set(t):
        return _result("Your own picture or video goes in Settings → Appearance → Your own "
                       "background — drop the file there.",
                       actions=[_open("appearance", auto=False)], kind="info")
    if "color" in t or names or hexes or others:
        if {"match", "accent"} & set(t):
            if not ui.get("pattern_color"):
                return _result("The pattern already matches the accent.", kind="info")
            return _result("Done — the pattern matches the accent colour again.",
                           actions=[_set("pattern_color", "", ui)])
        value = hexes[0] if hexes else PATTERN_COLORS.get(names[0]) if names else None
        if not value:
            listing = _colour_list(list(PATTERN_COLORS))
            return _question(f"Which colour? The pattern can be {listing}, or match the accent.",
                             [(n.title(), f"background color {n}") for n in PATTERN_COLORS])
        return _result(f"Done — the background pattern is {names[0] if names else value} now.",
                       actions=[_set("pattern_color", value, ui)])
    picked = [w for w in t if w in PATTERNS]
    if len(picked) == 1:
        value = picked[0]
    elif {"no", "off", "plain", "blank", "nothing", "remove"} & set(t):
        if (ui.get("background") or {}).get("file") and "pattern" not in t:
            return _result("Your own background is removed in Settings → Appearance → "
                           "“Remove the background”.",
                           actions=[_open("appearance", auto=False)], kind="info")
        value = "none"
    elif "on" in t:
        value = "glow" if ui.get("pattern") == "none" else ui.get("pattern")
    elif {"animated", "moving"} & set(t):
        return _question("Which moving one? They're slow and subtle:",
                         [(m.title(), f"background {m}") for m in MOVING_PATTERNS])
    else:
        return _question("Which background pattern? " + _colour_list(
            [p.title() for p in PATTERNS]) + ".",
            [(p.title(), f"background {p}") for p in PATTERNS])
    if ui.get("pattern") == value:
        return _result("That's already the background.", kind="info")
    say = ("Done — no background pattern." if value == "none"
           else f"Done — the background is {value.title()} now.")
    return _result(say, actions=[_set("pattern", value, ui)])


def _r_text(s, t, ctx):
    up = {"bigger", "larger", "big", "large", "huge", "increase", "up"}
    down = {"smaller", "small", "tiny", "tinier", "decrease", "down"}
    text = {"text", "font", "size", "words", "letters", "writing", "type", "print"}
    allowed = up | down | text | {"zoom", "more", "less", "px", "pixels", "go"}
    numbers = [w for w in t if re.fullmatch(r"\d{1,2}(?:\.5)?(?:px)?", w)]
    if not t or not set(t) <= allowed | set(numbers):
        return None
    ui = ctx["ui"]
    now = float(ui.get("text_size") or 14)
    low, high = TEXT_SIZE
    if numbers:
        if not text & set(t):
            return None
        value = float(numbers[0].replace("px", ""))
        if not low <= value <= high:
            return _result(f"Text size goes from {low} to {high} — below {low} the date notes "
                           f"stop being readable, above {high} the classes stop fitting.",
                           kind="info")
    elif up & set(t) and not down & set(t):
        value = min(high, now + TEXT_STEP)
        if value == now:
            return _result(f"The text is already as big as it goes ({high:g}px).", kind="info")
    elif down & set(t) and not up & set(t):
        value = max(low, now - TEXT_STEP)
        if value == now:
            return _result(f"The text is already as small as it goes ({low:g}px).", kind="info")
    else:
        if text & set(t) and len(t) <= 2:
            return _question("Bigger or smaller?", [("Bigger", "make the text bigger"),
                                                     ("Smaller", "make the text smaller")])
        return None
    value = int(value) if value == int(value) else value
    return _result(f"Done — text size {value:g}px (it was {now:g}px).",
                   actions=[_set("text_size", value, ui)])


def _r_font(s, t, ctx):
    if not {"font", "fonts", "typeface"} & set(t):
        return None
    head = bool({"heading", "headings", "titles", "title"} & set(t))
    table = FONTS_HEAD if head else FONTS_BODY
    picked = [w for w in t if w in FONTS_BODY or w in FONTS_HEAD]
    allowed = set(FONTS_BODY) | set(FONTS_HEAD) | {"font", "fonts", "typeface", "heading",
                                                   "headings", "titles", "title", "go"}
    if not set(t) <= allowed:
        return None
    key = "font_head" if head else "font_body"
    offered = FONT_CHOICES_HEAD if head else FONT_CHOICES_BODY
    names = [label for label, _ in offered]
    choices = [(label, f"{'heading ' if head else ''}font {said}") for label, said in offered]
    if not picked:
        return _question("Which font? " + _colour_list(names) + ".", choices)
    if picked[0] not in table:
        return _question(f"That one isn't a {'heading ' if head else ''}font here — "
                         + _colour_list(names) + ".", choices)
    value = table[picked[0]]
    return _result(f"Done — {'headings are' if head else 'the font is'} {value} now.",
                   actions=[_set(key, value, ctx["ui"])])


def _r_density(s, t, ctx):
    roomy = {"roomy", "roomier", "spacious", "cramped", "crowded", "squished", "spread"}
    compact = {"compact", "tighter", "denser", "dense", "condensed"}
    allowed = roomy | compact | {"space", "spacing", "spaced", "density", "more", "less",
                                 "out", "room", "breathing", "fit", "mode", "layout", "go"}
    if not t or not set(t) <= allowed:
        return None
    if roomy & set(t) and not ({"compact", "denser", "dense"} & set(t)):
        value = "roomy"
        if {"cramped", "crowded", "squished"} & set(t) and "less" not in t:
            return None
    elif compact & set(t):
        value = "compact"
    elif {"space", "spacing", "room"} & set(t) and ("more" in t) != ("less" in t):
        value = "roomy" if "more" in t else "compact"
    else:
        return None
    ui = ctx["ui"]
    if ui.get("density") == value:
        return _result(f"It's already {value}.", kind="info")
    return _result(f"Done — {value} spacing.", actions=[_set("density", value, ui)])


def _r_motion(s, t, ctx):
    subject = {"animation", "animations", "motion", "moving", "movement", "effects",
               "animated"}
    if not subject & set(t):
        return None
    allowed = subject | {"on", "off", "no", "reduce", "reduced", "stop", "less", "fewer",
                         "still", "freeze", "enable", "disable", "start", "all", "go"}
    if not set(t) <= allowed:
        return None
    if {"off", "no", "reduce", "reduced", "stop", "less", "fewer", "freeze", "disable",
        "still"} & set(t):
        value = "off"
    elif {"on", "enable", "start"} & set(t):
        value = "auto"
    else:
        return None
    ui = ctx["ui"]
    if ui.get("motion") == value:
        return _result("Already done.", kind="info")
    say = ("Done — no animation (the moving backgrounds hold still too)." if value == "off"
           else "Done — animations are back on (unless your Mac asks for reduced motion).")
    return _result(say, actions=[_set("motion", value, ui)])


def _r_grades(s, t, ctx):
    subject = {"grades", "grade", "percent", "percentage", "percentages", "scores"}
    if not subject & set(t):
        return None
    allowed = subject | {"letter", "letters", "both", "hide", "show", "number", "numbers",
                         "as", "%", "display", "on", "off", "unhide", "corner", "strip",
                         "board", "go", "instead"}
    if not set(t) <= allowed:
        return None
    ui = ctx["ui"]
    if {"hide", "off"} & set(t):
        value = "none"
    elif "both" in t:
        value = "both"
    elif {"letter", "letters"} & set(t):
        value = "letter"
    elif {"percent", "percentage", "percentages", "number", "numbers", "%"} & set(t):
        value = "percent"
    elif {"show", "unhide", "on"} & set(t) and ui.get("grade_display") == "none":
        value = "percent"
    else:
        return None           # "show my grades" is the lookup's question
    said = {"none": "the board no longer shows grades beside each class (the class page "
                    "still has them)",
            "letter": "grades show as letters", "percent": "grades show as percentages",
            "both": "grades show as a letter and a percentage"}[value]
    if ui.get("grade_display") == value:
        return _result(f"Already done — {said}.", kind="info")
    return _result(f"Done — {said}.", actions=[_set("grade_display", value, ui)])


def _r_estimates(s, t, ctx):
    if not {"estimates", "estimate", "estimated"} & set(t):
        return None
    allowed = {"time", "times", "estimates", "estimate", "estimated", "hide", "show", "on",
               "off", "guesses", "long", "go"}
    if not set(t) <= allowed:
        return None
    if {"hide", "off"} & set(t):
        value = False
    elif {"show", "on"} & set(t):
        value = True
    else:
        return None
    ui = ctx["ui"]
    if ui.get("show_estimates") is value:
        return _result("Already done.", kind="info")
    return _result("Done — time estimates are " + ("showing." if value else "hidden."),
                   actions=[_set("show_estimates", value, ui)])


def _r_weekends(s, t, ctx):
    ui = ctx["ui"]
    if {"start", "starts", "begin", "begins", "starting"} & set(t) and {"week", "weeks"} & set(t):
        allowed = {"start", "starts", "begin", "begins", "starting", "week", "weeks", "on",
                   "monday", "sunday", "monday's", "sunday's", "calendar", "mondays", "sundays"}
        if not set(t) <= allowed:
            return None
        day = "sunday" if any(w.startswith("sunday") for w in t) else \
            "monday" if any(w.startswith("monday") for w in t) else None
        if not day:
            return _question("Monday or Sunday?", [("Monday", "week starts monday"),
                                                   ("Sunday", "week starts sunday")])
        if ui.get("week_starts") == day:
            return _result(f"Weeks already start on {day.title()}.", kind="info")
        return _result(f"Done — weeks start on {day.title()}.",
                       actions=[_set("week_starts", day, ui)])
    if not {"weekends", "weekend"} & set(t):
        return None
    allowed = {"weekends", "weekend", "show", "hide", "on", "off", "calendar", "include",
               "includes", "including", "week", "view", "saturday", "sunday", "days", "go"}
    if not set(t) <= allowed:
        return None
    if {"hide", "off"} & set(t):
        value = False
    elif {"show", "on", "include", "including", "includes"} & set(t):
        value = True
    else:
        return None
    if ui.get("show_weekends") is value:
        return _result("Already done.", kind="info")
    return _result("Done — the calendar " + ("shows weekends." if value else "shows weekdays only."),
                   actions=[_set("show_weekends", value, ui)])


def _r_tabs(s, t, ctx):
    if not {"tab", "tabs"} & set(t):
        return None
    allowed = set(STRIP_TABS) | {"tab", "tabs", "hide", "show", "remove", "add", "off", "on",
                                 "strip", "bar", "top", "home", "settings", "unhide", "and"}
    if not set(t) <= allowed:
        return None
    if {"home", "settings"} & set(t):
        return _result("Home and Settings always stay in the strip.", kind="info")
    named = list(dict.fromkeys(STRIP_TABS[w] for w in t if w in STRIP_TABS))
    if not named:
        return None
    hide = bool({"hide", "remove", "off"} & set(t))
    show = bool({"show", "add", "on", "unhide"} & set(t))
    if hide == show:
        return None
    ui = ctx["ui"]
    off = list(ui.get("tabs_off") or [])
    for key in named:
        if hide and key not in off:
            off.append(key)
        if show and key in off:
            off.remove(key)
    off = [k for k in ("work", "life", "calendar", "done") if k in off]
    names = " and ".join(TAB_NAMES[k] for k in named)
    if off == list(ui.get("tabs_off") or []):
        return _result("Already done.", kind="info")
    say = (f"Done — the {names} tab{'s are' if len(named) > 1 else ' is'} off the strip "
           f"(still one key away)." if hide else f"Done — {names} is back in the strip.")
    return _result(say, actions=[_set("tabs_off", off, ui)])


_NOT_A_NAME = {"later", "back", "tomorrow", "tonight", "now", "soon", "maybe", "when",
               "if", "after", "before", "again", "sometime", "anytime", "at", "on", "in",
               "mom", "dad", "please", "whatever", "something", "anything"}


def _r_greeting(s, t, ctx):
    m = re.match(r"^(?:please )?(?:call me|change my name to|say hello to me as) "
                 r"([a-z][a-z'\-]{0,20}(?: [a-z][a-z'\-]{0,20})?)$", s)
    ui = ctx["ui"]
    if m:
        name = m.group(1)
        if name.split()[0] in _NOT_A_NAME:
            return None
        name = " ".join(part[:1].upper() + part[1:] for part in name.split())
        return _result(f"Done — the greeting says “Hello {name}”.",
                       actions=[_set("greeting_name", name, ui)])
    if re.match(r"^(?:don'?t|do not|stop) (?:call(?:ing)? me|use|using) (?:by )?(?:my )?"
                r"(?:name|[a-z]+)$", s):
        if not ui.get("greeting_name"):
            return _result("The greeting already just says hello.", kind="info")
        return _result("Done — the greeting just says hello.",
                       actions=[_set("greeting_name", "", ui)])
    return None


def _r_focus(s, t, ctx):
    from sillybus import focus as focus_mod

    sites, custom = [], []
    words = []
    for w in t:
        if w in FOCUS_SITES:
            sites.append(FOCUS_SITES[w])
        elif "." in w and re.fullmatch(r"[a-z0-9.\-/:]+", w):
            custom.append(w)
        else:
            words.append(w)
    vocab = {"focus", "block", "blocking", "blocker", "unblock", "remind", "reminder",
             "reminders", "gate", "distracting", "distractions", "distraction", "sites",
             "websites", "site", "social_media", "allow", "stop", "start", "on", "off",
             "mode", "and", "or", "from", "enable", "disable", "end", "list", "go",
             "everything", "all"}
    if not set(words) <= vocab:
        return None
    w = set(words)
    blocking = bool({"block", "blocking", "blocker"} & w)
    loosen_sites = bool({"unblock", "allow"} & w) or ("stop" in w and blocking)
    focus_said = "focus" in w
    if not (focus_said or blocking or loosen_sites or sites or custom):
        return None
    if (sites or custom) and not (blocking or loosen_sites or focus_said):
        return None
    current = focus_mod.settings()
    mode_now = current.get("mode") or "off"
    previous = {"mode": mode_now, "sites_off": list(current.get("sites_off") or []),
                "custom": list(current.get("custom") or [])}
    action = {"kind": "focus", "mode": None, "add_presets": [], "drop_presets": [],
              "add_custom": [], "drop_custom": [], "loosens": False, "previous": previous}
    labels = {p["id"]: p["label"] for p in focus_mod.PRESETS}

    clean_custom = []
    for host in custom:
        try:
            clean_custom.append(focus_mod.clean_host(host))
        except focus_mod.FocusError as exc:
            return _result(f"{str(exc)[:1].upper()}{str(exc)[1:]}.", kind="refused")

    if sites or clean_custom:
        named = [labels[x] for x in dict.fromkeys(sites)] + clean_custom
        listing = " and ".join(named)
        if loosen_sites:
            action["drop_presets"] = [x for x in dict.fromkeys(sites)
                                      if x not in previous["sites_off"]]
            action["drop_custom"] = [h for h in clean_custom if h in previous["custom"]]
            action["loosens"] = True
            if not (action["drop_presets"] or action["drop_custom"]):
                return _result(f"{listing} {'is' if len(named) == 1 else 'are'} not on your "
                               "Focus list already.", kind="info")
            return _result(f"Done — {listing} {'is' if len(named) == 1 else 'are'} off your "
                           "Focus list.", actions=[action])
        action["add_presets"] = [x for x in dict.fromkeys(sites) if x in previous["sites_off"]]
        action["add_custom"] = [h for h in clean_custom if h not in previous["custom"]]
        if mode_now != "block":
            action["mode"] = "block"
        if not (action["add_presets"] or action["add_custom"] or action["mode"]):
            return _result(f"{listing} {'is' if len(named) == 1 else 'are'} already blocked "
                           "by Focus.", kind="info")
        say = f"Done — Focus blocks {listing}"
        if action["mode"]:
            say += " (Block is on now — the gate opens with your PIN)"
        return _result(say + ".", actions=[action])

    if {"off", "disable", "end"} & w or ("stop" in w and not blocking) or \
            (loosen_sites and {"everything", "all"} & w) or ("stop" in w and blocking):
        if mode_now == "off":
            return _result("Focus is already off.", kind="info")
        action.update({"mode": "off", "loosens": True})
        return _result("Done — Focus is off, and the site permissions were handed back.",
                       actions=[action])
    remind = bool({"remind", "reminder", "reminders"} & w)
    if remind and not (focus_said or "mode" in w):
        return None           # "turn off reminders" is the Mac's notifications
    if remind and not blocking:
        value = "remind"
    elif blocking and not remind:
        value = "block"
    else:
        return _question("Which kind of Focus? Reminder shows what's due when you open a "
                         "distracting site; Block covers the site until you type your PIN.",
                         [("Reminder", "turn on focus reminders"),
                          ("Block", "turn on focus block"), ("Off", "turn focus off")])
    if mode_now == value:
        return _result(f"Focus {'Block' if value == 'block' else 'Reminder'} is already on.",
                       kind="info")
    action["mode"] = value
    action["loosens"] = mode_now == "block"
    say = ("Done — Focus Block is on: sites on your list are covered until you type your PIN."
           if value == "block" else
           "Done — Focus reminders are on: opening a site on your list shows what's due.")
    return _result(say, actions=[action])


# ---- times, for Downtime and the reminders

_TIME = re.compile(r"\b(?:(noon|midday)|(midnight)|(\d{1,2})(?::(\d{2}))?\s?(am|pm)?)\b")


def _times(s: str) -> list[dict]:
    """Every clock time in the sentence, with whether it is sure. "10pm",
    "22:00" and "07:00" are; a bare "10" is not."""
    out = []
    for m in _TIME.finditer(s):
        noon, midnight, h, mins, ap = m.groups()
        if noon:
            out.append({"at": "12:00", "sure": True, "pos": m.start(), "h": 12, "m": 0})
            continue
        if midnight:
            out.append({"at": "00:00", "sure": True, "pos": m.start(), "h": 0, "m": 0})
            continue
        hour, minute = int(h), int(mins or 0)
        if minute > 59:
            continue
        if ap:
            if not 1 <= hour <= 12:
                continue
            hour = hour % 12 + (12 if ap == "pm" else 0)
            sure = True
        elif mins is not None and (hour >= 13 or h.startswith("0") or hour == 0):
            if hour > 23:
                continue
            sure = True
        elif hour > 12 and mins is None:
            continue            # "16 assignments" is not a time
        else:
            if not 1 <= hour <= 12:
                continue
            sure = False
        out.append({"at": f"{hour:02d}:{minute:02d}", "sure": sure, "pos": m.start(),
                    "h": hour, "m": minute, "raw": m.group(0)})
    return out


def pretty(at: str) -> str:
    h, m = (int(x) for x in at.split(":"))
    suffix = "AM" if h < 12 else "PM"
    h12 = h % 12 or 12
    return f"{h12}:{m:02d} {suffix}" if m else f"{h12} {suffix}"


def _downtime_module():
    """The other half of Downtime, built separately. Imported lazily so this
    branch works before it lands."""
    try:
        from sillybus import downtime  # type: ignore[attr-defined]
    except ImportError:
        return None
    return downtime


DOWNTIME_MISSING = "Downtime isn't available in this version yet."


def _day_list(s: str) -> list[str] | None:
    if "weeknights" in s:
        return ["sun", "mon", "tue", "wed", "thu"]
    if re.search(r"\bweekdays?\b", s):
        return ["mon", "tue", "wed", "thu", "fri"]
    if re.search(r"\bweekends?\b", s):
        return ["fri", "sat"] if "nights" in s else ["sat", "sun"]
    if "everyday" in s:
        return list(DAYS)
    return None


def _r_downtime(s, t, ctx):
    if "downtime" not in s.split():
        return None
    times = _times(s)
    days = _day_list(s)
    is_status = bool(re.match(r"^(?:what|whats|what's|when|is|show|how|tell)\b", s)) \
        or s in ("downtime", "my downtime")
    if not times:
        if re.search(r"\b(?:off|disable|stop|cancel|no|remove|delete|pause|end)\b", s):
            kwargs = {"on": False}
            return _result("", server=("downtime", kwargs))
        if re.search(r"\b(?:on|enable|start|resume)\b", s) and not days:
            return _result("", server=("downtime", {"on": True}))
        if days:
            return _result("", server=("downtime", {"on": True, "days": days}))
        if is_status:
            return _result("", server=("downtime_status", {}))
        return _question("From when to when? Say it with AM/PM — for example "
                         "“downtime 10pm to 7am”.",
                         [("10 PM – 7 AM", "set downtime 10pm to 7am"),
                          ("9 PM – 6:30 AM", "set downtime 9pm to 6:30am")])
    if len(times) >= 2:
        start, end = times[0], times[1]
        if re.search(r"\buntil\b|\btill\b", s[:start["pos"]]):
            start, end = end, start
        if not (start["sure"] and end["sure"]):
            guess_start = start["at"] if start["sure"] else f"{start['h'] % 12 + 12:02d}:{start['m']:02d}"
            guess_end = end["at"] if end["sure"] else f"{end['h'] % 12:02d}:{end['m']:02d}"
            phrase = (f"set downtime {pretty(guess_start).lower().replace(' ', '')} to "
                      f"{pretty(guess_end).lower().replace(' ', '')}")
            return _question(f"Is that {pretty(guess_start)} to {pretty(guess_end)}? "
                             "Say it with AM/PM so I don't guess.",
                             [(f"{pretty(guess_start)} – {pretty(guess_end)}", phrase)])
        kwargs = {"on": True, "start": start["at"], "end": end["at"]}
        if days:
            kwargs["days"] = days
        return _result("", server=("downtime", kwargs))
    one = times[0]
    before = s[:one["pos"]]
    if re.search(r"\b(?:until|till|til|ends?|ending|stops?|over|finish(?:es)?)\b", before) \
            or re.search(r"\bto\s*$", before):
        which = "end"
    elif re.search(r"\b(?:from|starts?|starting|begins?|beginning|at)\b\s*$", before):
        which = "start"
    else:
        return _question("Is that when Downtime starts or ends? Say both — "
                         "“downtime 10pm to 7am”.", [])
    if not one["sure"]:
        return _question("AM or PM? Say it with AM/PM so I don't guess.",
                         [(f"{one['h']} AM", f"downtime {which}s at {one['h']}am"),
                          (f"{one['h']} PM", f"downtime {which}s at {one['h']}pm")])
    return _result("", server=("downtime", {"on": True, which: one["at"]}))


def _r_reminders(s, t, ctx):
    if not re.search(r"\b(?:reminders|notifications|notification|banners|reminder times?)\b", s):
        return None
    if "focus" in s.split():
        return None
    times = _times(s)
    if times:
        if not all(x["sure"] for x in times):
            return _question("Say the times with AM/PM — for example “reminders at 7am and "
                             "5pm” — so I don't guess.",
                             [("7 AM and 5 PM", "reminders at 7am and 5pm")])
        if len(times) > 4:
            return _result("Up to four reminder times a day — more than that and they stop "
                           "being read.", kind="info")
        return _result("", server=("reminders", sorted({x["at"] for x in times})))
    if re.search(r"\b(?:off|disable|stop|mute|silence|no more|pause)\b", s):
        return _result("I can't switch Mac notifications off from here — turn them off in "
                       "System Settings → Notifications → SillyBus AI.", kind="info")
    if re.match(r"^(?:what|when|whats|what's|show)\b", s):
        return _result("", server=("reminders_status", None))
    if re.search(r"\b(?:on|enable|start)\b", s):
        return _result("", server=("reminders_on", None))
    return None


def _r_sources(s, t, ctx):
    named = [w for w in t if w in SOURCES]
    onoff = {"on", "off", "stop", "start", "enable", "disable", "ignore", "reading", "read",
             "checking", "check", "pulling", "pull", "include", "exclude", "using"}
    if not (onoff & set(t)):
        return None
    allowed = (set(SOURCES) | onoff | {"canvas", "from", "feed", "connected", "posts",
                                       "topics", "and", "sources", "source", "assignments",
                                       "go"})
    if not set(t) <= allowed:
        return None
    if not named:
        if "canvas" in t:
            return _question("Canvas is where most of your work comes from, so it stays on. "
                             "I can switch off parts of it:",
                             [("Announcements", "stop reading canvas announcements"),
                              ("Discussions", "stop reading canvas discussions"),
                              ("Front pages", "stop reading canvas front pages")])
        return None
    on = not bool({"off", "stop", "disable", "ignore", "exclude"} & set(t))
    changes = {SOURCES[w][0]: on for w in named}
    labels = [SOURCES[w][1] for w in dict.fromkeys(named)]
    return _result("", server=("sources", {"changes": changes, "labels": labels}))


RULES = (_r_help, _r_undo, _r_greeting, _r_downtime, _r_reminders, _r_nav, _r_focus,
         _r_theme, _r_layout, _r_accent, _r_pattern, _r_font, _r_text, _r_density,
         _r_motion, _r_grades, _r_estimates, _r_weekends, _r_tabs, _r_sources)
# The rules that answer a question ("what's my downtime?") rather than change.
QUESTION_RULES = (_r_help, _r_downtime, _r_reminders)


def _clause(s: str, ctx: dict) -> dict | None:
    s = s.strip()
    if not s:
        return None
    refused = _refusal(s)
    if refused:
        return refused
    if re.match(r"^(?:don'?t|do not|never)\b", s):
        return None
    t = _tokens(s)
    asking = bool(QUESTION_START.match(s)) and not re.match(r"^(?:what|which) (?:settings|things)", s)
    for rule in (QUESTION_RULES if asking else RULES):
        try:
            out = rule(s, t if rule is not _r_nav else t, ctx)
        except Exception as exc:  # noqa: BLE001 — a reader bug must not break chat
            log.warning("settings rule %s failed: %s", rule.__name__, exc)
            out = None
        if out is not None:
            return out
    return None


def _context() -> dict:
    from sillybus import prefs as ui_prefs
    try:
        ui = ui_prefs.load()
    except Exception:  # noqa: BLE001
        ui = ui_prefs.defaults()
    return {"ui": ui}


def plan(message: str, ctx: dict | None = None) -> list[dict] | None:
    """What the sentence asks for, without doing any of it. None when it is
    not a settings request at all (the lookup and the model take it).

    The whole sentence is tried first, so "block YouTube and TikTok" and
    "reminders at 7am and 5pm" stay one request; only when that fails is it
    split on "and"/"then"/commas, so "dark mode and purple" is two."""
    s = normalise(message)
    if not s or len(s) > 200:
        return None
    ctx = ctx if ctx is not None else _context()
    whole = _clause(s, ctx)
    if whole is not None:
        return [whole]
    raw = re.sub(r"\s+", " ", (message or "").lower())
    parts = [p for p in re.split(r"\s*(?:,|;|\band then\b|\band also\b|\band\b|\bthen\b|\bplus\b)\s*",
                                 raw) if p.strip()]
    if len(parts) < 2:
        return None
    results = []
    for part in parts:
        got = _clause(normalise(part), ctx)
        results.append(got if got is not None else {"unread": part.strip()})
    if not any("say" in r for r in results):
        return None
    return results


# ---------------------------------------------------------------------------
# Doing it


def _do_downtime(kwargs: dict) -> str:
    mod = _downtime_module()
    if mod is None:
        return DOWNTIME_MISSING
    try:
        if kwargs.get("days") and hasattr(mod, "DAYS"):
            known = list(getattr(mod, "DAYS"))
            kwargs = {**kwargs, "days": [d for d in known
                                         if str(d)[:3].lower() in kwargs["days"]]}
        mod.set(**kwargs)
    except ValueError as exc:
        return str(exc)
    try:
        return "Done — " + mod.describe()
    except Exception:  # noqa: BLE001
        return "Done — Downtime is saved."


def _do_downtime_status() -> str:
    mod = _downtime_module()
    if mod is None:
        return DOWNTIME_MISSING
    try:
        return mod.describe()
    except Exception as exc:  # noqa: BLE001
        return f"I couldn't read Downtime just now ({exc})."


def _do_reminders(times: list[str]) -> str:
    from sillybus import config
    config.save({"notify": {"times": times}})
    said = " and ".join(pretty(x) for x in times)
    ok = _reschedule()
    if ok:
        return f"Done — reminders come at {said} now."
    return (f"Saved — reminders will come at {said} once they're set up on this Mac "
            "(Settings → Connections → Turn on reminders).")


def _reschedule() -> bool:
    """Install the reminder schedule the way Settings' button does. Only the
    installed app's own data home may (schedule_mac refuses any other), so a
    preview copy can never repoint the real LaunchAgents."""
    import contextlib
    import io
    import sys
    if sys.platform != "darwin":
        return False
    try:
        from sillybus import schedule_mac
        with contextlib.redirect_stdout(io.StringIO()):
            return schedule_mac.install() == 0
    except Exception as exc:  # noqa: BLE001
        log.warning("could not reschedule reminders: %s", exc)
        return False


def _do_reminders_status() -> str:
    from sillybus import config
    times = (config.load().get("notify") or {}).get("times") or ["07:00", "17:00"]
    return "Reminders come at " + " and ".join(pretty(x) for x in times) + "."


def _do_reminders_on() -> str:
    if _reschedule():
        return "Done — reminders are on. " + _do_reminders_status()
    return ("I couldn't set up reminders from here — press Turn on reminders in Settings → "
            "Connections.")


def _do_sources(payload: dict) -> str:
    from sillybus import config
    allowed = config.DEFAULTS.get("sources") or {}
    changes = {k: v for k, v in payload["changes"].items() if k in allowed}
    if not changes:
        return "That isn't a source SillyBus reads."
    config.save({"sources": changes})
    on = next(iter(changes.values()))
    listing = " and ".join(payload["labels"])
    if on:
        return f"Done — SillyBus reads {listing} again, from the next refresh."
    return (f"Done — SillyBus stops reading {listing} from the next refresh. Say "
            f"“turn {payload['labels'][0]} back on” to undo.").replace("turn the ", "turn ")


SERVER = {"downtime": _do_downtime, "downtime_status": lambda _: _do_downtime_status(),
          "reminders": _do_reminders, "reminders_status": lambda _: _do_reminders_status(),
          "reminders_on": lambda _: _do_reminders_on(), "sources": _do_sources}


def run(message: str) -> dict | None:
    """Read the sentence and do it: the chat reply, or None to let the lookup
    and the model have it. Server-side changes happen here; the page applies
    `actions` through the Settings functions."""
    planned = plan(message)
    if planned is None:
        return None
    says, actions, choices = [], [], []
    for part in planned:
        if "unread" in part:
            says.append(f"(I only change settings here — ask “{part['unread']}” on its own.)")
            continue
        say = part["say"]
        if part.get("server"):
            name, payload = part["server"]
            try:
                say = SERVER[name](payload)
            except Exception as exc:  # noqa: BLE001
                log.warning("settings change %s failed: %s", name, exc)
                say = f"That didn't save: {exc}"
        says.append(say)
        actions.extend(part["actions"])
        choices.extend(part["choices"])
    return {"answer": "\n".join(x for x in says if x), "actions": actions,
            "choices": choices}


# ---------------------------------------------------------------------------
# The model's proposals, held to the same list

# Every preference the model may set, with the values it may set it to. The
# same values Settings offers; nothing about classes, connections or Focus.
MODEL_SETTABLE: dict[str, tuple] = {
    "theme": ("system", "light", "warm", "dark"),
    "accent": tuple(ACCENTS.values()),
    "pattern": PATTERNS,
    "pattern_color": ("",) + tuple(PATTERN_COLORS.values()),
    "density": ("compact", "roomy"),
    "motion": ("auto", "off"),
    "grade_display": ("percent", "letter", "both", "none"),
    "show_estimates": (True, False),
    "show_weekends": (True, False),
    "week_starts": ("monday", "sunday"),
    "status_marks": ("symbols", "dot"),
    "surface": ("open", "cards", "glass"),
    "text_size": tuple(range(TEXT_SIZE[0], TEXT_SIZE[1] + 1)),
}


def validate_model_setting(key, value) -> dict | None:
    """A set_pref action from the model's proposal, or None if it is not one
    this list allows. The model's words never decide what is written."""
    if key not in MODEL_SETTABLE:
        return None
    if isinstance(value, str):
        v = value.strip().lower()
        if key in ("show_estimates", "show_weekends"):
            value = {"true": True, "false": False}.get(v, value)
        elif key == "text_size":
            try:
                value = int(float(v))
            except ValueError:
                return None
        else:
            value = v
    if value not in MODEL_SETTABLE[key]:
        return None
    from sillybus import prefs as ui_prefs
    try:
        ui_prefs._clean(key, value, None)
    except ui_prefs.PrefError:
        return None
    return _set(key, value, _context()["ui"])
