"""Instructions about how a class works, read straight from a chat sentence.

*"we're a day behind in calc"*, *"materials science doesn't use canvas"*,
*"the lit doc is https://docs.google.com/document/d/…"* — the answers the class
review asks for (routes_api.post_setup_review). The shapes are few and fixed,
so they are parsed here, before any model: it costs nothing, works with no AI
at all, and cannot record a rule the student did not state. Anything subtler
("the date column is when it's assigned") goes to the model as `class_setup`.

`parse` only proposes; `apply` writes through courses.update, the same path
the Settings card uses, and says exactly what was recorded and how to undo it.
"""

import re

from sillybus import classrules, courses

NUMBER = {"a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
          "six": 6, "a couple": 2, "couple": 2}

BEHIND = re.compile(
    r"\b(?:we(?:'re| are)|were|class is|(?:the )?class(?:'s| is)?|it(?:'s| is)|"
    r"we(?:'re| are) running|running)\s+"
    r"(?:(?P<n>\d+|a couple(?: of)?|couple(?: of)?|an?|one|two|three|four|five|six)\s+)?"
    r"(?:school\s+)?(?:days?|class(?:es)?|periods?|meetings?|lessons?)\s+"
    r"(?P<way>behind|ahead)\b", re.I)
CAUGHT_UP = re.compile(r"\b(?:caught up|back on (?:track|schedule)|on schedule|"
                       r"not behind any ?more|no longer behind)\b", re.I)
CANVAS_OFF = re.compile(
    r"\b(?:does(?:n'?t| not)|do(?:n'?t| not)|never|won'?t) (?:really )?use canvas\b"
    r"|\bno canvas\b|\bnot on canvas\b|\b(?:turn|switch) (?:off canvas|canvas off)\b"
    r"|\bignore canvas\b|\bcanvas (?:is )?(?:off|wrong|useless)\b", re.I)
CANVAS_ON = re.compile(r"\b(?:does use canvas|uses canvas|(?:turn|switch) "
                       r"(?:on canvas|canvas (?:back )?on)|canvas back on)\b", re.I)
DOC_URL = re.compile(r"https://docs\.google\.com/document/d/(?:e/)?[\w-]{10,}[^\s)>\]]*")


def parse(message: str, state: dict, course_hint: str | None = None) -> dict | None:
    """{"course_key", "course", "rules", "doc_url"} or None when the sentence
    states no class rule. A rule with no class named comes back with
    course_key None so the caller can ask which class."""
    text = message or ""
    rules: dict = {}
    m = BEHIND.search(text)
    if m:
        raw = (m.group("n") or "a").lower().replace(" of", "").strip()
        n = int(raw) if raw.isdigit() else NUMBER.get(raw, 1)
        rules["shift_meetings"] = n if m.group("way").lower() == "behind" else -n
    elif CAUGHT_UP.search(text) and re.search(r"\b(class|doc|we|it|is|are)\b", text, re.I):
        rules["shift_meetings"] = 0
    if CANVAS_OFF.search(text):
        rules["canvas"] = False
    elif CANVAS_ON.search(text):
        rules["canvas"] = True
    url = DOC_URL.search(text)
    doc_url = url.group(0) if url else None
    if not rules and not doc_url:
        return None
    # A doc link on its own is only an instruction when a class is in view —
    # otherwise it is somebody pasting a link to ask about it.
    if not rules and doc_url and not course_hint and not _named_course(text, state):
        return None
    key, name = resolve_course(text, state, course_hint)
    return {"course_key": key, "course": name, "rules": rules, "doc_url": doc_url}


def resolve_course(text: str, state: dict, course_hint: str | None) -> tuple[str | None, str | None]:
    named = _named_course(text, state)
    if named:
        return named
    if course_hint:
        return _named_course(course_hint, state) or (None, None)
    return None, None


def _named_course(text: str, state: dict) -> tuple[str, str] | None:
    from sillybus import quickadd
    name, key = quickadd.match_course(text, state)
    return (key, name) if key else None


def apply(proposal: dict) -> str:
    """Write it, and say what was written in the student's terms."""
    key = proposal["course_key"]
    patch: dict = {}
    if proposal.get("rules"):
        patch["rules"] = proposal["rules"]
    if proposal.get("doc_url"):
        patch["connectors"] = {"doc_url": proposal["doc_url"]}
    courses.update(key, patch)
    rules = classrules.of(courses.load(key))
    said = []
    r = proposal.get("rules") or {}
    if "shift_meetings" in r:
        n = r["shift_meetings"]
        said.append("back on the doc's own dates" if n == 0 else
                    f"{abs(n)} class{'es' if abs(n) != 1 else ''} "
                    f"{'behind' if n > 0 else 'ahead of'} the doc — its dates will move "
                    f"{abs(n)} class{'es' if abs(n) != 1 else ''} {'later' if n > 0 else 'earlier'}")
    if "canvas" in r:
        said.append("Canvas off — nothing from Canvas will show for this class" if not r["canvas"]
                    else "Canvas back on")
    if proposal.get("doc_url"):
        said.append("homework doc saved — it is read on every refresh")
    undo = []
    if r.get("shift_meetings"):
        undo.append(f"say \"{proposal['course']} is caught up\"")
    if r.get("canvas") is False:
        undo.append(f"say \"{proposal['course']} uses Canvas\"")
    return (f"Recorded for {proposal['course']}: " + "; ".join(said) + "."
            + " It applies from the next Refresh."
            + (f" To undo, {' or '.join(undo)}, or change it in Settings → Classes." if undo else "")
            + (f"\n(Everything noted for this class: {classrules.describe(rules)}.)"
               if classrules.describe(rules) else ""))
