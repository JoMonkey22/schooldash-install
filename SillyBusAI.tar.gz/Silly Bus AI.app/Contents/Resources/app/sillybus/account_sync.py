"""Account snapshots of already-collected schoolwork; never a school login."""
import hashlib
import json
import re
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
from sillybus import account, config, paths, pipeline

FIELDS = {'generated_at', 'today', 'block_label', 'items', 'grades', 'scores',
          'gradebook', 'schedule', 'meetings_today', 'events', 'schedule_stale',
          'grades_stale', 'events_stale'}
SECRET = re.compile(r'password|token|secret|cookie|credential|authorization|api_key|class_ics|assignments_ics|canvas_ics', re.I)


def clean(value, depth=0):
    if depth > 16:
        raise ValueError('Saved board is too deeply nested')
    if isinstance(value, dict):
        return {k: clean(v, depth+1) for k, v in value.items()
                if not SECRET.search(k) and k not in
                {'raw_cell', 'portal_text', '__proto__', 'constructor', 'prototype'}}
    if isinstance(value, list):
        return [clean(v, depth+1) for v in value[:3000]]
    if isinstance(value, str):
        if value.startswith(('https://', 'http://')):
            u = urlsplit(value)
            if u.username or u.password or '.ics' in u.path.lower():
                return ''
            return urlunsplit((u.scheme, u.netloc, u.path,
                              urlencode([(k, v) for k, v in parse_qsl(u.query)
                                         if not SECRET.search(k)]), u.fragment))
        return value[:20000]
    return value


def snapshot(state):
    return clean({k: state[k] for k in FIELDS if k in state})


def digest(state):
    return hashlib.sha256(json.dumps(snapshot(state), sort_keys=True).encode()).hexdigest()


def _meta_path():
    return paths.data_dir() / 'account-sync.json'


def _read_meta():
    try:
        return json.loads(_meta_path().read_text())
    except (OSError, ValueError):
        return {}


def _write_meta(meta):
    p = _meta_path()
    tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps(meta))
    tmp.replace(p)


def run():
    session = account.current()
    if not session:
        return {'status': 'signed_out'}
    url = account.server_url() + '/phone'
    if not config.load().get('account', {}).get('sync', False):
        return {'status': 'off', 'phone_url': url}
    owner = session['email']
    meta = _read_meta()
    if meta.get('owner') and meta['owner'] != owner:
        return {'status': 'account_changed', 'message': 'This device holds another account’s schoolwork. It has not been uploaded.', 'phone_url': url}
    local = pipeline.load_state_overlaid() or {}
    local_hash = digest(local)
    remote = account._call('GET', 'board', token=session['token']).get('board')
    local_empty = not local.get('items')
    remote_state = (remote or {}).get('state') or {}
    remote_hash = digest(remote_state) if remote_state else None
    if remote_state and (local_empty or (meta.get('hash') == local_hash and remote_hash != local_hash)):
        # Only replace an empty device or a board unchanged since its last sync.
        restored = snapshot(remote_state)
        if not isinstance(restored.get('items'), list) or not restored.get('generated_at'):
            raise ValueError('Your saved board could not be read')
        target = paths.state_json_path()
        tmp = target.with_suffix('.sync.tmp')
        tmp.write_text(json.dumps(restored))
        tmp.replace(target)
        # Preserve done marks when the overlay rebuilds them from the local DB.
        from sillybus import db
        conn = db.connect()
        try:
            for item in restored.get('items', []):
                if item.get('item_id'):
                    db.set_done(conn, item['item_id'], bool(item.get('done')))
        finally:
            conn.close()
        _write_meta({'owner': owner, 'hash': remote_hash, 'revision': remote['revision']})
        return {'status': 'restored', 'saved_at': remote['saved_at'], 'phone_url': url}
    if local_empty:
        return {'status': 'empty', 'message': 'Collect schoolwork on one computer first. An empty device will never replace your saved board.', 'phone_url': url}
    if remote_hash == local_hash:
        _write_meta({'owner': owner, 'hash': local_hash, 'revision': remote['revision']})
        return {'status': 'saved', 'saved_at': remote['saved_at'], 'phone_url': url}
    if remote and remote['revision'] != meta.get('revision', 0):
        return {'status': 'conflict', 'message': 'Another device has different saved work. Both copies are kept. Use the device with your latest work.', 'phone_url': url}
    result = account._call('POST', 'board', {'state': snapshot(local), 'revision': (remote or {}).get('revision', 0)}, token=session['token'])
    _write_meta({'owner': owner, 'hash': local_hash, 'revision': result['revision']})
    return {'status': 'saved', 'saved_at': result['saved_at'], 'phone_url': url}
