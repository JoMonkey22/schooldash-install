"""Load, validate, and redact config.json.

config.json is secret-bearing: the Veracross and Canvas feed URLs carry their
credential in the URL itself. Nothing in this module (or anywhere else) may
write a real feed URL into a log line, error message, or document — use
redact() whenever a config value might reach output.
"""

import copy
import json
import os
import re
import shutil
import tempfile
import threading
import time
from pathlib import Path
from urllib.parse import urlsplit

from sillybus import paths

DEFAULTS = {
    "school": {"name": "Brophy College Preparatory", "time_zone": "America/Phoenix"},
    "canvas": {"host": "https://brophyprep.instructure.com", "name": ""},
    "veracross": {
        "class_ics": "",
        "assignments_ics": "",
        "portal": "https://portals.veracross.com/brophyprep/student",
    },
    "canvas_ics": "",
    "window": {"days_back": 8, "days_forward": 14},
    # How far the CONNECTED CALENDARS are read, which is a different question
    # from how far homework is looked at and so is a different setting.
    #
    # [ASKED] 2026-09-21: *"make it better read every thing"*. The connected
    # calendars were being read through `window` — eight days back, fourteen
    # forward — because that is the window the homework pipeline uses and it
    # was the one already to hand. For homework fourteen days is right: work
    # due in March is not work you can do tonight. For a season it is wrong.
    # A TeamSnap calendar carries the whole schedule, and a student asking
    # "when is the Gonzaga game" in September was told nothing, because the
    # game is in November and November was never read.
    #
    # So: events look five months ahead, homework still looks fourteen days,
    # and neither can move the other. `feeds/calendars.py` is the only reader.
    "event_window": {"days_back": 14, "days_forward": 150},
    # canvas_pages: homework typed onto the course homepage or a schedule-ish
    # wiki page (sillybus/feeds/canvas_pages.py). canvas_announcements: work
    # named in a recent announcement. Both on by default — [MEASURED]
    # 2026-09-01 a class showed zero homework for a term because its work was
    # only ever on its homepage — and both switchable if a teacher's page ever
    # turns out to be noisy.
    "sources": {"veracross_assignments": False, "canvas_ics_fallback": True,
                "canvas_pages": True, "canvas_announcements": True,
                # Ungraded discussion topics. On by default because they carry
                # real homework — [MEASURED] 2026-09-03, Honors English:
                # "Select 3 movies ... = 15 points", not graded, not in the
                # planner, so it reached the board through nothing at all.
                "canvas_discussions": True,
                # AP Classroom, read by the Chrome extension on the site itself
                # (feeds/apclassroom.py). Off means the hand-off file is ignored.
                "ap_classroom": True,
                "google_classroom": True,
                # Calendars the student connected themselves — TeamSnap, Google
                # Calendar, any iCal URL (feeds/calendars.py). One switch for
                # all of them; each also has its own `enabled` flag.
                "connections": True,
                # Albert.io, read by the Chrome extension on the site itself
                # (feeds/albert.py), exactly as AP Classroom is.
                "albert": True},
    "ai": {
        "provider": "auto",
        "profiling_provider": "claude_code",
        "chat_provider": "auto",
        # Haiku 4.5, his choice on 2026-09-03 after seeing the numbers:
        # a chat answer is a short factual lookup over a board the
        # extractor has already done the hard work on, and Haiku costs a
        # fifth of Opus for it. See plans.py for the measured figures.
        "claude_model": "haiku",
        "ollama_model": "llama3.2",
        "ollama_host": "http://127.0.0.1:11434",
        "max_adjudications_per_run": 12,
        # How long ⚡ Accelerate may take to write one guide. Reading the
        # material and producing a structured guide measured 30-90 s; the cap
        # is generous because the alternative is losing the work already done.
        "accelerate_timeout": 420,
    },
    # Calendars and other programs the student connected themselves (spec
    # §4.7). A list, not a block of named keys, because the whole point is
    # that a fourth one costs nothing: each entry is
    #   {"id", "kind", "name", "url", "enabled", "added"}
    # and `url` is a CREDENTIAL — the secret is the URL itself, exactly as it
    # is for veracross.class_ics. redact_connections() below is the only way
    # one may reach output.
    "connections": [],
    "browser": {"profile_dir": "", "channel": "auto"},
    "server": {"host": "127.0.0.1", "port": 5055, "stale_after_hours": 18},
    "docs": {"include_private": False, "cache_keep": 3},
    "scoring": {"low_priority": 20, "estimate_scale": 0.4},
    # Scheduled macOS banner: fixed clock times, because "7am and 5pm" is
    # something a person can reason about. A slot missed while asleep is
    # skipped rather than queued, matching the publish schedule's behaviour.
    "notify": {"times": ["07:00", "17:00"]},
    # Online account. `server` empty = no gate at all, which is how a solo
    # install runs. The account holds an email and a password hash; homework
    # never leaves this machine either way.
    "account": {"server": "", "required": True},
    # SillyBus AI included ([ASKED] 2026-10-01: "add payment for silly bus",
    # "use my api key"). The AI features — chat, quizzes, Accelerate, the work
    # checker — are answered by the owner's server with the owner's key: a
    # free month, then $5 a month (or $7 with Better Gmail), at most $1 of AI
    # a person a month. See sillybus/billing.py. `enabled: false` leaves only
    # the student's own Claude, Ollama or key.
    "billing": {"enabled": True, "server": "https://better-gmail-api.jomonkey22.workers.dev"},
    # ------------------------------------------------------------------
    # How the board looks, and which of its several shapes it is wearing.
    #
    # This lives in config.json rather than only in localStorage for one
    # reason: the app runs in TWO places — the Mac bundle and the Chrome
    # extension — and a preference that exists only in one browser's storage
    # does not follow the student between them. localStorage still holds a
    # MIRROR of the appearance keys, because the pre-paint head script has to
    # apply them before the first frame and cannot wait on a fetch. Config is
    # the truth; localStorage is the fast copy.
    #
    # Every key here earns its place. A switch nobody has a reason to flip is
    # a switch that makes the Settings page harder to read.
    "ui": {
        # --- appearance: all of it becomes CSS custom properties and data-*
        # attributes on <html>, so nothing re-renders to re-theme.
        "theme": "system",          # system | light | warm | dark
        "accent": "#E8A317",        # ONE variable; every other brand colour is color-mix'd from it
        # Texture, not decoration: the middle of the board sits on the
        # background with no card around it, and a faint pattern is what keeps
        # it from reading as empty space.
        "pattern": "glow",          # none|glow|dots|grid | aurora|drift|waves|orbit|tide|breathe
                                    # the last six MOVE, slowly; motion: off freezes them
        # [ASKED] 2026-09-20: "the current backgrounds are hardly noticeable.
        # make it so you can pick the colour". Blank = the accent, dimmed;
        # strength is how much of it shows — "normal" is visible on purpose.
        "pattern_color": "",
        "pattern_strength": "normal",   # subtle | normal | bold
        "font_body": "Inter",
        "font_head": "Fraunces",
        "text_size": 14,
        # compact fits twelve classes in a 995x605 window ([MEASURED] his
        # window); roomy is for when the laptop is on a monitor.
        "density": "compact",       # compact | roomy
        # An explicit override of the OS hint, both directions.
        # prefers-reduced-motion is still honoured when this is "auto".
        "motion": "auto",           # auto | off
        # The custom background is a FILE in the data home, never bytes in
        # config.json: config is read on every request and a pasted GIF would
        # be megabytes of it. Empty file = none.
        "background": {"file": "", "kind": "", "opacity": 0.35},

        # --- the format registry (the front end owns the list of formats;
        # this is only which are ticked on and which is showing). Two or more
        # ticked gives that section small tabs; one ticked and they disappear.
        "formats": {
            "calendar": ["day", "week"],
            "chats": ["list"],
            "life": ["kinds"],
            "classes": ["strip"],
            "work": ["byclass"],
            "priority": ["cards"],
            "links": ["full"],
        },
        "active": {
            "calendar": "day", "chats": "list", "life": "kinds",
            "classes": "strip", "work": "byclass", "priority": "cards",
            "links": "full",
        },

        # --- the classes
        # Short codes for the Assignments column, which has room for "CHM" and
        # not for "AP Chemistry". Missing = derived from the name.
        "abbr": {},
        # Course keys switched off the board. [MEASURED] 2026-09-07: 16 courses,
        # 12 current, and Community Period is not homework. NEVER silent — the
        # board states how many are hidden (SPEC 5.5).
        "hidden": [],
        # Custom class order. Empty = by period, which is right most days.
        "order": [],

        # --- honesty controls
        # date_note is required on every item (SPEC 5.9). In the compact
        # Assignments column showing it always costs roughly one item per class
        # band, so "hover" puts a marker on any date the app INFERRED rather
        # than was told, with the sentence on hover and on keyboard focus; the
        # class page and the open item show it in full either way. "always" is
        # the literal reading of 5.9 and is one tick away.
        "date_notes": "hover",      # hover | always
        # The time estimates are the legacy x0.4 guesses. A guessed number
        # beside a real due date can read as a fact, so it can be switched off.
        "show_estimates": True,
        # The existing opt-in "hide anything scoring under 20", which always
        # states the count it is hiding.
        "hide_low_priority": False,

        # --- where the app opens
        "open_with": "greeting",    # greeting | last | chat
        "start_tab": "home",

        # --- calendar reading habits
        "week_starts": "monday",    # monday | sunday
        "show_weekends": False,

        # --- three more, added 2026-09-18 when Settings got its own pages.
        # Each one exists because something on the board was decided FOR him
        # and there was a real reason to want it decided differently.
        #
        # A class's colour is a hash of its course key, which is stable and
        # needs no setup — and which has no idea two classes he mixes up
        # already landed 6 degrees apart on the wheel. This is the override,
        # per class; anything not named here keeps the derived hue.
        "colors": {},
        # What the class strip says next to a name. A live percentage in the
        # corner of the screen all day is not neutral for everyone, and
        # "nothing" is a real answer rather than a broken one — the grade is
        # still one click away on the class page. Never affects the ring,
        # which is about how soon work is due and not about the grade.
        "grade_display": "percent",   # letter | percent | both | none
        # [MEASURED] 2026-09-18: twelve full class names in the tab strip need
        # 2296px against 963px of his window, and short codes need 846px — so
        # codes are the default. At five classes, or on a monitor, the names
        # fit and are better. "auto" measures and picks; the other two are for
        # when he disagrees with the measurement.
        "tab_labels": "codes",        # auto | codes | names
        # Quick links in the top bar are EARNED: a site appears there only when
        # the data carries a link to it, because an invented link is an
        # invented fact (SPEC 5.10). That rule has a cost — Khan Academy and
        # Quizlet never appear in a teacher's doc, so they can never earn one.
        # This is how he adds one honestly: he says so himself. Each is a name
        # and an https address, nothing more; the board marks them as his.
        "shortcuts": [],              # [{"name": "Khan", "url": "https://..."}]
        # And the other direction. A quick link is earned from the data, which
        # means a site a teacher linked once shows in the strip forever even
        # if the student has no account there. [ASKED] 2026-09-20: "you should
        # be able to turn off connectors/shortcuts entirely … not everyone
        # uses all of them and its annoying if you don't." Names, because that
        # is what the strip is keyed on and what the × in Settings puts back.
        "hidden_links": [],           # ["Quizlet", "Onshape"]
        # One class, one key — however each source spells it. Veracross says
        # "AP English Lit", Canvas says "AP English Literature and Composition",
        # and until 2026-09-18 the board drew that class twice (coursejoin.py).
        # The join is automatic where the names leave no doubt; these two are
        # for when they do. `merge` is his word that a foreign key IS a class
        # (foreign key -> the class's key); `keep_apart` names keys the join
        # must never touch, for the day it is confidently wrong.
        "merge": {},
        "keep_apart": [],
        # What he CALLS a class, when the school's name for it is not what he
        # says out loud. "Advanced Placement Physics C" is Physics; a rename
        # is his word and applies everywhere the class is named — strip, tabs,
        # bands, the class page, the chat. The key never changes, so nothing
        # filed under it moves.
        "names": {},

        # --- six more, added 2026-09-18 from a second round of his asks.
        #
        # Which period a class meets. The class feed says so for a class that
        # has a slot; a class with NO slot — Materials Science meets whenever,
        # College Counseling is a period-8-style class with no hours — has
        # nothing to detect, and "no period" sorted it to the bottom as if it
        # were unimportant. 1–7 are the day's slots; 8 is the school's word
        # for a class without hours; a class not named here is detected from
        # the schedule as before.
        "periods": {},                # {"course_key": 1..8}
        # How the classes sit on the board and in the strip. By period is the
        # day's order and the default; A–Z is for the days you look a class up
        # by name; "custom" is the order set with the arrows on the Classes
        # page. One switch, not three settings, because the three are one
        # decision.
        "sort": "period",             # period | name | custom
        # What an assignment row says about itself without being opened. A
        # single kind-coloured dot was minimal and answered one question; he
        # asked for every applicable status in view — the kind, overdue, due
        # today, handed in on Canvas, yours — so "symbols" shows them all as
        # small marks with the words on hover. The dot stays as a choice.
        "status_marks": "symbols",    # symbols | dot
        # The tick that marks a row done. On hover keeps the compact column
        # compact; a touch screen and a keyboard have no hover, so "always" is
        # a real option and not a debug switch.
        "ticks": "hover",             # hover | always
        # Whether a full page — a class, Settings, Life, Calendar, Done — sits
        # straight on the background, in a card, or on frosted glass. Cards
        # read as an app; open reads as paper; glass exists for a photo
        # background, where black text on a photo is unreadable but hiding
        # the photo under a card defeats having one.
        "surface": "open",            # open | cards | glass
        # Which of the fixed tabs (Assignments, Life, Calendar, Done) are turned
        # OFF the strip. Every one is still one key away; a strip is real
        # estate, and a student who never uses Life should not pay for the tab.
        # Stored as the ones turned off — not the ones on — so a tab added in
        # a later version appears for everyone without a migration.
        # [MEASURED] 2026-09-20: the first version stored the tabs that were on,
        # and the new Assignments tab was invisible to every existing install.
        "tabs_off": [],
        # How a page comes in when a tab is opened. [MEASURED] 2026-09-18 from
        # his install: "when I switch between tabs it flashes black and white"
        # — the cut was a repaint bug (paintBackground rebuilt the image), and
        # once fixed a cut is still abrupt. A short fade is the default; the
        # strength is the duration, because 380 ms is right on a monitor and
        # wrong twelve times a minute. `motion: off` wins over both.
        "transition": "fade",         # none | fade | slide | rise | zoom
        "transition_strength": "normal",   # subtle | normal | strong
        # What the greeting calls the student. Blank says "Hello" and nothing
        # else, which is right for an install that is not the author's — the
        # app ships to other students now, and a stranger's name on the board
        # is worse than no name.
        "greeting_name": "",
        # About the student, asked once on the account form and kept HERE —
        # never sent to the account server, which holds an email and a
        # password hash and nothing else. [ASKED] 2026-10-07: "ask them there
        # name and birthday and any other info it might need". The birthday
        # is month-day-year text (YYYY-MM-DD) and is only ever used to say
        # happy birthday; the grade gives the chat the student's year.
        "birthday": "",
        "grade_level": "",
        # Which screen the app is. "simple" (0.23, the default) opens like a
        # new chat — the logo, "Good afternoon, <name>", one box — with
        # Assignments / Grades / Calendar / Classes / Settings across the top.
        # "board" is the 0.20 Studio board, every column at once.
        # [ASKED] 2026-10-07: "make it really simple open like the claude new
        # chat button then across the top have assignments grades etc".
        "look": "simple",
        # The tour of the board plays once, the first time the board opens
        # after setup; Settings -> About runs it again on request.
        "tour_seen": False,

        # --- Focus: self-discipline, as three modes.
        # [ASKED] 2026-09-20: "i just want the option of self dicipline built
        # into the sillybus chrome extension ... 3 modes (off, reminder ...,
        # and block ... but there is a bypass pin). just for helping yourself
        # do homework." What each mode means, the shipped site list and the
        # reasoning behind both are in `focus.py`; this is only what is set.
        "focus": {
            # off | remind | block. Off is the default and off means ABSENT:
            # no site permission is held and no content script is registered,
            # so a student who never wants this never pays for it.
            "mode": "off",
            # Presets the student took OFF the list (focus.PRESETS is the
            # list). Stored as the removals so a site added in a later version
            # appears for everyone without a migration -- the lesson ui.tabs_off
            # learned when its first version hid a newly added tab from every
            # existing install.
            "sites_off": [],
            # Hostnames the student added themselves. The shipped eleven are
            # the ones a student loses an evening to; this is for the twelfth.
            "custom": [],
            # How often a reminder may repeat itself. A card on every page view
            # trains you to dismiss it unread, which is the failure notify.py's
            # digest rule exists to avoid; "visit" is once per run of the site.
            "remind_every": "visit",     # visit | hourly | always
            # How long one correct PIN opens a site for. A teacher's linked
            # video needs about a minute; an evening off needs sixty. Both are
            # real answers, so it is a number rather than a switch.
            "bypass_minutes": 15,
            # What the gate does when nothing is actually due. "allow",
            # because the purpose he named is helping himself do homework --
            # a gate that stays shut over an empty board is a punishment, and
            # it is why self-imposed blockers get switched off.
            "when_clear": "allow",       # allow | block
        },
    },
    # Handing work in to Canvas from the board (sillybus/canvas_submit.py).
    # OFF, and it stays off until a person turns it on. [ASKED] 2026-09-22:
    # *"do not test by submiting anything on my canvas I do not want anything
    # submited unless I say."* This is the whole mechanism behind that
    # sentence — the module refuses before it reads a cookie, so nothing
    # built on top of it can submit by accident while the switch is False.
    "submit": {"enabled": False},
    "publish": {
        # Remote snapshot page (Master Planner, read-only, encrypted).
        # netlify_site_id + netlify_token enable the scheduled push; the token
        # is a secret — never printed, never committed.
        "netlify_site_id": "",
        "netlify_token": "",
        "passphrase": "",
        "schedule_school": ["06:30", "10:40", "14:20", "17:00"],
        "schedule_off": ["06:00", "12:00"],
    },
}

# Keys whose values are credentials and must never appear in output.
SECRET_PATHS = [
    ("veracross", "class_ics"),
    ("veracross", "assignments_ics"),
    ("canvas_ics",),
    ("publish", "netlify_token"),
    ("publish", "passphrase"),
]
# Every connection's `url` is one too. It is not in SECRET_PATHS because that
# list addresses fixed keys and connections are a list — so the rule is spelt
# out here and enforced by redact_connections(), which every caller that puts
# connections into an API reply, a log line or the published snapshot uses.
CONNECTION_SECRET_KEY = "url"

_cached: dict | None = None


class ConfigError(RuntimeError):
    pass


def _merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base)
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _merge(out[key], value)
        else:
            out[key] = value
    return out


def load(path: Path | None = None, refresh: bool = False) -> dict:
    """The full config with defaults filled in. Missing file -> defaults only."""
    global _cached
    if _cached is not None and not refresh and path is None:
        return _cached
    target = path or paths.config_path()
    raw = {}
    if target.exists():
        try:
            raw = json.loads(target.read_text(encoding="utf-8"))
        except ValueError as exc:
            raise ConfigError(f"{target.name} is not valid JSON: {exc}") from exc
    merged = _merge(DEFAULTS, raw)
    _blank_placeholders(merged)
    _moved_account_server(merged)
    _moved_update_base(merged)
    _blank_canvas_host_is_the_default(merged)
    _hold_unconfirmed_portal(merged)
    # A second copy for development can run beside the installed app without
    # editing anyone's config.json: SILLYBUS_PORT wins over server.port.
    port_override = os.environ.get("SILLYBUS_PORT")
    if port_override and port_override.isdigit():
        merged["server"]["port"] = int(port_override)
    if path is None:
        _cached = merged
    return merged


# [ASKED] 2026-10-06: "can you use GitHub insted of netlify". The account
# server left Netlify (deploys blocked for credits; GitHub runs no server
# code) for Cloudflare, with every account copied over. Every install made
# before then has a Netlify address saved in its own config.json, so the old
# addresses are read as the new one — no install has to be edited by hand.
ACCOUNT_SERVER = "https://sillybus-accounts.jomonkey22.workers.dev"
_OLD_ACCOUNT_SERVERS = ("https://schooldash-accounts.netlify.app", "https://sillybus-accounts.netlify.app")


def _moved_account_server(cfg: dict) -> None:
    account = cfg.get("account")
    if isinstance(account, dict) and str(account.get("server") or "").rstrip("/") in _OLD_ACCOUNT_SERVERS:
        account["server"] = ACCOUNT_SERVER


# The installer site left Netlify for GitHub Pages when Netlify ran out of
# credits, and config.example.json kept pointing at the dead address — so
# every classmate install copied a base that could never answer, and the
# update button said "could not check" for ever (prosecution round 5,
# 2026-10-07). Blank falls through to update.DEFAULT_BASE, which is the one
# place the live address is written down.
_OLD_UPDATE_BASES = ("https://schooldash-install.netlify.app",
                     "https://sillybus-setup.netlify.app")


def _moved_update_base(cfg: dict) -> None:
    section = cfg.get("update")
    if isinstance(section, dict) and str(section.get("base") or "").rstrip("/") in _OLD_UPDATE_BASES:
        section["base"] = ""


def _blank_canvas_host_is_the_default(cfg: dict) -> None:
    """An empty Canvas address is "put it back", never "nowhere".

    (prosecution round 5, 2026-10-07) Clearing the Settings box saved "" and
    the sign-in then opened the URL "/login" — a page that does not exist on
    any host. Every caller does `host.rstrip("/") + path`, so the fix belongs
    here, once, rather than in each of them.
    """
    canvas = cfg.get("canvas")
    if isinstance(canvas, dict) and not str(canvas.get("host") or "").strip():
        canvas["host"] = DEFAULTS["canvas"]["host"]


def _blank_placeholders(cfg: dict) -> None:
    """Turn a copied-from-the-example value into "" in place.

    config.example.json carries `<SECRET FEED URL …>` markers so a human can
    see what belongs there. Copied verbatim, those are non-empty strings, so
    every `if not value` guard downstream reads them as configured — and the
    refresh then tries to fetch a URL whose scheme is a `<`. Normalising here
    means one fix covers missing_for_refresh, the feed readers, and health.

    Every `<…>` string anywhere, not only the secret ones (prosecution round 5,
    2026-10-07): the example's `canvas.name` was "<display name>", and the
    setup page greeted a classmate as "signed in as <display name>" because
    only the feed URLs were blanked. No real setting is written in angle
    brackets.
    """
    def walk(node):
        if isinstance(node, dict):
            for key, value in node.items():
                if isinstance(value, str):
                    if _PLACEHOLDER.match(value.strip()):
                        node[key] = ""
                else:
                    walk(value)
        elif isinstance(node, list):
            for value in node:
                if isinstance(value, (dict, list)):
                    walk(value)
    walk(cfg)


_PLACEHOLDER = re.compile(r"^<[^<>]*>\Z")


# ---- which school ----------------------------------------------------------
# The shipped defaults are one school's (Brophy's): its Canvas, its Veracross
# portal, its time zone. (prosecution round 5, 2026-10-07) Setup never asked
# which school, so a classmate at another school was wired to Brophy without
# being told — and with "Veracross uses the same email and password" pre-ticked,
# every refresh typed THEIR Google password into BROPHY's Veracross sign-in.
#
# So the shipped portal is used only when something says it is right:
#   * the student confirmed it on the "Your school" step (school.confirmed_at),
#     or
#   * a class feed is saved — which only ever came from signing in to that
#     portal, so an install that has one (his, and every Brophy classmate who
#     finished setup) has proved the portal is theirs and sees no change.
# (A Canvas address other than the shipped one also counts as having answered
# "which school" — but it can never confirm the shipped PORTAL; see below.)
# And never when the Canvas address is somewhere else: a school is not on
# Brophy's Canvas and Brophy's Veracross at once.
#
# A held portal reads as "" — the same as a school with no Veracross — so the
# refresh, the sign-in, the keep-alive and the grades reader all skip it with
# the code they already have for a blank portal. The file is never changed:
# the hold is lifted the moment the student confirms.
SHIPPED_CANVAS_HOST = DEFAULTS["canvas"]["host"]
SHIPPED_PORTAL = DEFAULTS["veracross"]["portal"]


def _host_of(url: str) -> str:
    try:
        return (urlsplit(str(url or "").strip()).hostname or "").lower()
    except ValueError:
        return ""


def school_confirmed(cfg: dict | None = None) -> bool:
    """Has this install said which school it is at?"""
    cfg = cfg if cfg is not None else load()
    canvas_host = _host_of((cfg.get("canvas") or {}).get("host"))
    return bool(((cfg.get("school") or {}).get("confirmed_at"))
                or ((cfg.get("veracross") or {}).get("class_ics"))
                # a Canvas address other than the shipped one was typed in by
                # the student (Settings -> School), which is their answer
                or (canvas_host and canvas_host != _host_of(SHIPPED_CANVAS_HOST)))


def _hold_unconfirmed_portal(cfg: dict) -> None:
    vx = cfg.get("veracross")
    if not isinstance(vx, dict):
        return
    portal = str(vx.get("portal") or "").strip().rstrip("/")
    if portal.lower() != SHIPPED_PORTAL.lower():
        return
    canvas_host = _host_of((cfg.get("canvas") or {}).get("host"))
    if canvas_host and canvas_host != _host_of(SHIPPED_CANVAS_HOST):
        reason = "canvas_elsewhere"
    elif not school_confirmed(cfg):
        reason = "unconfirmed"
    else:
        return
    vx["portal"] = ""
    vx["portal_held"] = reason
    # Kept only so a link already read off a portal page can still be made
    # absolute (veracross_grades._absolute). Nothing signs in with it.
    vx["portal_shipped"] = portal


def veracross_in_use(cfg: dict | None = None) -> bool:
    """Does this school's setup include a Veracross portal we may sign in to?

    False for a school without Veracross (portal left blank) and for the
    shipped portal while it is held (see above). Everything Veracross —
    sign-in, grades, the class-feed requirement — asks this first.
    """
    cfg = cfg if cfg is not None else load()
    return bool(str((cfg.get("veracross") or {}).get("portal") or "").strip())


def mac_time_zone() -> str:
    """The Mac's own IANA zone, or "" when it cannot be read.

    The default for the "Your school" step, because a student outside Arizona
    was otherwise put on Phoenix time without being asked and every Canvas
    deadline near midnight landed on the wrong day (prosecution round 5,
    2026-10-07).
    """
    from zoneinfo import available_timezones
    zones = available_timezones()
    candidates = [os.environ.get("TZ", "").lstrip(":")]
    try:
        link = os.readlink("/etc/localtime")
        if "zoneinfo/" in link:
            candidates.append(link.split("zoneinfo/", 1)[1])
    except OSError:
        pass
    for name in candidates:
        if name and name in zones:
            return name
    return ""


# ---- writing config.json ----------------------------------------------------
# (prosecution round 5, 2026-10-07) Two things went wrong here, both silently.
#
# 1. A config.json that did not parse — one trailing comma from a hand edit —
#    was read as {} by save(), so the next click anywhere in setup wrote a file
#    holding only that click: the class feed, the Canvas address and the
#    account server, gone. load() already refused the same file; save() now
#    refuses too, and keeps the bad file beside it as config.json.bad-<time>
#    so the one typo can be fixed instead of everything being retyped.
#
# 2. Every writer used ONE temp name ("config.tmp") with no lock. The sign-in
#    subprocess saving the class feed while the page marked a setup milestone
#    is an ordinary moment, and [MEASURED] in the reviewer's repro two writers
#    lost one of the writes or crashed on the shared temp file. Read-merge-
#    write now happens under an exclusive lock file, and each write goes to
#    its own mkstemp file in the same directory, then os.replace — so a reader
#    only ever sees a whole old file or a whole new one.
_write_lock = threading.Lock()


class _FileLock:
    """flock on config.json.lock, plus a thread lock for the same process.

    The thread lock is what still works where flock does not (the extension
    runs this under Pyodide, which has no real fcntl).
    """

    def __init__(self, target: Path):
        self.path = target.with_name(target.name + ".lock")
        self.handle = None

    def __enter__(self):
        _write_lock.acquire()
        try:
            import fcntl
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.handle = open(self.path, "a+")
            fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX)
        except (ImportError, OSError, AttributeError):
            if self.handle is not None:
                self.handle.close()
            self.handle = None
        return self

    def __exit__(self, *exc):
        try:
            if self.handle is not None:
                import fcntl
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
                self.handle.close()
        finally:
            self.handle = None
            _write_lock.release()
        return False


def _read_for_write(target: Path) -> dict:
    """What is on disk now, or ConfigError — never a silent {}."""
    if not target.exists():
        return {}
    text = target.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
        if not isinstance(data, dict):
            raise ValueError("the top level is not an object")
    except ValueError as exc:
        backup = target.with_name(f"{target.name}.bad-{time.strftime('%Y%m%d-%H%M%S')}")
        if not backup.exists():
            shutil.copy2(target, backup)
        raise ConfigError(
            f"{target.name} is not valid JSON ({exc}), so nothing was written to it. "
            f"A copy is kept as {backup.name}; fix the typo in {target.name}, "
            f"or move it aside to start setup again.") from exc
    return data


def _write_whole(target: Path, data: dict) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=target.name + ".", suffix=".tmp", dir=str(target.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(json.dumps(data, indent=2))
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                pass
        if target.exists():
            try:
                os.chmod(tmp, os.stat(target).st_mode & 0o777)
            except OSError:
                pass
        os.replace(tmp, target)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def save(updates: dict, path: Path | None = None) -> dict:
    """Merge-write updates into config.json (like the predecessor's save_config).

    Raises ConfigError, and writes nothing, when the file on disk is not
    valid JSON — see "writing config.json" above.
    """
    global _cached
    target = path or paths.config_path()
    with _FileLock(target):
        existing = _read_for_write(target)
        _write_whole(target, _merge(existing, updates))
        _cached = None
    return load(path=None if path is None else path, refresh=True)


def replace_key(name: str, value, path: Path | None = None) -> dict:
    """Write ONE top-level key wholesale, where `save` would merge into it.

    `save` deep-merges, which is right for almost everything: a caller that
    sets `ai.model` must not wipe `ai.timeout`. It is wrong for a dict whose
    KEYS are the data — `ui.abbr` (course key -> short code), `ui.colors` —
    because clearing an entry means the key is absent from what the caller
    hands back, and a merge keeps whatever was there. [MEASURED] 2026-09-18:
    clearing a class's short code through Settings said "back to the automatic
    code" and left the code in config.json, every time. This is the honest
    write for that case: the key is replaced, nothing under it survives that
    the caller did not send.
    """
    global _cached
    target = path or paths.config_path()
    with _FileLock(target):
        existing = _read_for_write(target)
        existing[name] = value
        _write_whole(target, existing)
        _cached = None
    return load(path=None if path is None else path, refresh=True)


def redact(value: str) -> str:
    """A display-safe form of a secret: never the value itself."""
    if not value:
        return "<not set>"
    return f"<set, {len(value)} chars>"


def connections(cfg: dict | None = None) -> list[dict]:
    """The saved connections, as a list of dicts. Never fails on a hand-edited
    config: anything that is not an object with a url is skipped, because a
    typed-in config.json should cost one connection, not the whole refresh."""
    cfg = cfg or load()
    raw = cfg.get("connections")
    if not isinstance(raw, list):
        return []
    out = []
    for entry in raw:
        if isinstance(entry, dict) and entry.get("url") and entry.get("id"):
            out.append(entry)
    return out


def redact_connections(entries: list[dict]) -> list[dict]:
    """Connections in a form safe to serve, log or publish: everything about
    each one except the URL, which IS the credential."""
    out = []
    for entry in entries or []:
        if not isinstance(entry, dict):
            continue
        safe = {k: v for k, v in entry.items() if k != CONNECTION_SECRET_KEY}
        raw = entry.get(CONNECTION_SECRET_KEY) or ""
        # Google's export address holds no secret (it works only for whoever
        # is signed in to Chrome), and which account it reads — /u/1/ — is
        # what lets "link my second Google account" skip the first.
        # [ASKED] 2026-10-07.
        if re.match(r"^https://calendar\.google\.com/calendar/(?:u/\d/)?exporticalzip$", raw.strip(), re.I):
            safe["url"] = raw.strip()
        else:
            safe["url"] = redact(raw)
        out.append(safe)
    return out


def save_connections(entries: list[dict], path: Path | None = None) -> dict:
    """Write the whole list back. A list cannot be merge-written the way
    `save` merges dicts — merging two lists means guessing what the caller
    meant — so the caller reads, edits and hands back the whole thing."""
    return save({"connections": list(entries)}, path=path)


def missing_for_refresh(cfg: dict | None = None) -> list[str]:
    """What is still needed before a refresh can produce anything.

    Only the class feed is mandatory — everything else degrades gracefully —
    and only at a school that uses Veracross. (prosecution round 5,
    2026-10-07) A Canvas-only school can never have a Veracross feed, so
    asking for one meant its setup could never finish.
    """
    cfg = cfg or load()
    missing = []
    if not cfg["veracross"]["class_ics"] and veracross_in_use(cfg):
        missing.append(
            "veracross.class_ics — the class-schedule feed URL. "
            "Capture it with: python run.py login --veracross"
        )
    return missing


def summary(cfg: dict | None = None) -> dict:
    """A redacted view safe to print or serve."""
    cfg = cfg or load()
    return {
        "school": cfg["school"],
        "canvas_host": cfg["canvas"]["host"],
        "veracross_class_ics": redact(cfg["veracross"]["class_ics"]),
        "veracross_assignments_ics": redact(cfg["veracross"]["assignments_ics"]),
        "canvas_ics": redact(cfg["canvas_ics"]),
        "window": cfg["window"],
        "event_window": cfg["event_window"],
        "ai": {k: v for k, v in cfg["ai"].items()},
        "server": cfg["server"],
        "browser": {
            "profile_dir": cfg["browser"]["profile_dir"] or "<default>",
            "channel": cfg["browser"]["channel"],
        },
    }
