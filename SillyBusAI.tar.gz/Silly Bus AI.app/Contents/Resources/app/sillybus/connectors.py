"""What a connector switch actually turns off.

[ASKED] 2026-09-20: *"you should be able to turn off connectors/shortcuts
entirely (like apcr and albert) bc not everyone uses all of them and its
annoying if you don't."*

Every reader already had an on/off flag in `config.sources`, and each reader
honoured it — for the next refresh. What "off" did not do was make the
connector go away: its items stayed on the board until something rebuilt it,
its diagnostics stayed in Settings, and its site kept a chip in the top strip.
A student with no AP Classroom account switched AP Classroom off and still had
AP Classroom on the screen, which is not off.

So the switch means one thing now, and this module is where that one thing is
written down: which `item.source` values the connector puts on the board,
which hostnames belong to it, and what to call it. Everything that has to
respect an off switch reads this list rather than hard-coding "ap_classroom"
in its own file — there are five such places, and they used to disagree.

Adding a reader means adding an entry here in the same commit as its
`config.DEFAULTS["sources"]` flag; `tests/test_connectors.py` refuses a flag
that has no entry.
"""

from sillybus import config

# switch name -> what it is and what it leaves behind
CONNECTORS: dict[str, dict] = {
    "canvas_pages": {
        "label": "Canvas", "hosts": (),
        # Canvas pages become doc/course items whose source is the extractor's,
        # not a feed's, so there is nothing to sweep off the board.
        "item_sources": (),
    },
    "canvas_announcements": {"label": "Canvas", "hosts": (), "item_sources": ()},
    "canvas_discussions": {"label": "Canvas", "hosts": (), "item_sources": ()},
    "canvas_ics_fallback": {
        "label": "Canvas calendar feed", "hosts": (),
        "item_sources": ("canvas_ics",),
    },
    "veracross_assignments": {
        "label": "Veracross", "hosts": ("veracross.com",),
        "item_sources": ("veracross",),
    },
    "ap_classroom": {
        "label": "AP Classroom", "hosts": ("collegeboard.org",),
        "item_sources": ("ap_classroom",),
    },
    "google_classroom": {
        "label": "Google Classroom", "hosts": ("classroom.google.com",),
        "item_sources": ("google_classroom",),
    },
    "albert": {
        "label": "Albert.io", "hosts": ("albert.io",),
        "item_sources": ("albert",),
    },
    "connections": {
        "label": "Your calendars", "hosts": (),
        # One switch for every calendar address pasted in; the kinds are
        # feeds/calendars.SOURCE_KINDS, which is the list an event's `source`
        # is taken from.
        "item_sources": ("google_calendar", "teamsnap", "schoology", "powerschool",
                         "blackbaud", "canvas_calendar", "ical"),
    },
}


def flags(cfg: dict | None = None) -> dict:
    """Every switch and whether it is on, defaults filled in."""
    cfg = cfg if cfg is not None else config.load()
    on = dict(cfg.get("sources") or {})
    return {name: bool(on.get(name, default))
            for name, default in (config.DEFAULTS.get("sources") or {}).items()}


def enabled(name: str, cfg: dict | None = None) -> bool:
    return flags(cfg).get(name, True)


def off(cfg: dict | None = None) -> list[str]:
    """The switches that are off, in the order DEFAULTS lists them."""
    return [name for name, on in flags(cfg).items() if not on]


def hidden_item_sources(cfg: dict | None = None) -> set:
    """`item.source` values that belong to a connector that is switched off.

    Used to sweep the board the moment a switch is flipped, so "off" does not
    mean "off after the next refresh" — a refresh can be twenty seconds away
    or an hour, and in between the student is looking at a connector they
    just turned off.
    """
    out: set = set()
    for name, on in flags(cfg).items():
        if on:
            continue
        out.update(CONNECTORS.get(name, {}).get("item_sources") or ())
    return out


def hidden_hosts(cfg: dict | None = None) -> list[str]:
    """Hostname suffixes whose quick-link chip should not be drawn, because
    the connector that would have earned it is switched off."""
    out: list[str] = []
    for name, on in flags(cfg).items():
        if on:
            continue
        out.extend(CONNECTORS.get(name, {}).get("hosts") or ())
    return out
