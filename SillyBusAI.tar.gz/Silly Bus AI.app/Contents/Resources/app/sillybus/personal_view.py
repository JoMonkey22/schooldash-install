"""Explicit, reversible chat requests for a student's personal assignment view."""
from __future__ import annotations
import re
from sillybus import prefs


def chat_request(message, state, course=None):
    text = message.strip().rstrip('.!').lower()
    only = re.fullmatch(r'(?:please )?(?:only (?:show|put)|show only) (.+?)(?: assignments| homework| work)?', text)
    dates = re.fullmatch(r'(?:please )?(hide|remove|take out|show|restore) (?:the )?(?:due dates?|dates?)(?: (?:for|in|from) (.+))?(?: though)?', text)
    # "Hide Scripture due dates" is the other common ordering.
    if not dates:
        dates = re.fullmatch(r'(hide|remove|show|restore) (.+?) due dates?', text)
        if dates:
            verb, name = dates.groups()
        else:
            verb, name = None, None
    else:
        verb, name = dates.groups()
    reset = text in ('show all assignments', 'show all classes', 'restore all classes')
    if not (only or dates or reset):
        return None
    ui = prefs.load()
    records = {}
    for item in state.get('items') or []:
        if item.get('course_key'):
            records[item['course_key']] = item.get('course') or item['course_key']
    for row in state.get('courses') or []:
        if isinstance(row, dict) and (row.get('key') or row.get('course_key')):
            records[row.get('key') or row.get('course_key')] = row.get('name') or row.get('course') or row.get('key')
    actions = []
    if reset:
        key, value = 'hidden', []
        answer = 'Showing all classes again.'
    else:
        name = (only.group(1) if only else name) or course
        if name:
            name = re.sub(r'\s+(?:assignments|homework|work)$', '', name, flags=re.I).strip()
            matches = [k for k,v in records.items() if name.casefold() in str(v).casefold() or name.casefold() == k.casefold()]
        else:
            matches = ['*']
        if len(matches) != 1 or (only and matches == ['*']):
            return reply('Which class do you mean? Use the class name shown in SillyBus.', [])
        target = matches[0]
        label = records.get(target, 'all classes')
        if only:
            key, value = 'hidden', [k for k in records if k != target]
            answer = f'Your assignment view now shows only {label}. Other classes are hidden, not deleted. Say “show all assignments” to restore them.'
        else:
            key = 'hidden_date_courses'
            value = list(ui.get(key) or [])
            if verb in ('show', 'restore'):
                value = [] if target == '*' else [k for k in value if k != target]
                # Restore one class from a global hide without exposing others.
                if target != '*' and '*' in value:
                    value = [k for k in records if k != target]
                answer = f'Due dates are visible again for {label}.'
            else:
                value = ['*'] if target == '*' else list(dict.fromkeys(value + [target]))
                answer = f'Due dates are hidden for {label} in your personal view, including calendar positioning. School records stay unchanged. Say “show due dates for {label}” to restore them.'
    actions.append({'kind':'set_pref','key':key,'value':value,'previous':ui.get(key)})
    return reply(answer, actions)


def reply(answer, actions):
    return {'answer':answer,'session_id':None,'provider':'local','mode':'settings',
            'action':{'intent':'settings'},'actions':actions,'grounded':True,
            'confidence':'verified','verified':0,'checked':[],'cited':[],'violations':[]}
