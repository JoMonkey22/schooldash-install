"""Focus: what the extension does when the student opens a distracting site.

[ASKED] 2026-09-20: *"i just want the option of self dicipline built into the
sillybus chrome extension. in settings have 3 modes (off, reminder (where a
reminder pops up when you open yt, insta, etc.), and block (blocks all non
educational content but there is a bypass pin). just for helping yourself do
homework."*

Three modes, and this module is the one place that says what they mean:

- **off** — nothing is registered, no site permission is held, and the page
  never loads a line of Focus code. Off means absent, the way a switched-off
  connector means absent (`connectors.py`).
- **remind** — the first time a site on the list is opened, a card slides in
  saying what is actually due, with a button to the board. It can be waved
  away and the page is never touched.
- **block** — the site is covered by a gate until a PIN is typed. The gate
  names the work, because a blocker that only says "no" is a blocker you
  uninstall.

Three decisions worth writing down
----------------------------------

**"All non-educational content" is a list, not a judgement.** Nothing can look
at a URL and know whether it is educational, and this app does not invent
facts (SPEC §5.10). So Focus blocks *named sites* — the eleven below, each
removable, plus any hostname the student adds — and the Settings page says
exactly that rather than implying a classifier.

**The PIN is friction, not security.** It is four to eight digits, stored as a
PBKDF2 hash in the extension's own storage, never in `config.json` (which
`GET /api/prefs` serves verbatim). Anyone who wants past it can open
`chrome://extensions` and switch the extension off, and the Settings page says
so. The point is the ten seconds of deliberate effort, which is the whole
mechanism a student is buying.

**When nothing is due, the gate lets go.** `when_clear` defaults to "allow"
because the purpose named in the ask is *helping yourself do homework* — a
block that stays shut on a Friday with an empty board is not that purpose, it
is a punishment, and it is the reason self-imposed blockers get turned off.

The site list lives here and not in the extension so that one edit reaches
both the manifest's optional origins and the Settings page; `sites_off` stores
the presets the student REMOVED rather than the ones kept, so a site added in
a later version appears for everyone without a migration (the same lesson
`ui.tabs_off` learned the hard way on 2026-09-20).
"""

from __future__ import annotations

import re

from sillybus import config, notify

MODES = ("off", "remind", "block")

# How often a reminder is allowed to say the same thing again. A card on every
# single page view trains the student to dismiss it without reading, which is
# the failure mode of every notification this app has (see notify.py's digest
# rule); "visit" is once per run of the site and is the default.
REMIND_EVERY = ("visit", "hourly", "always")

# How long one correct PIN opens a site for. One minute is "look up the thing
# the teacher linked"; sixty is an evening. Both are real answers, so it is a
# number and not a switch.
BYPASS_MINUTES = (1, 60)

# What a clear board means for the gate.
WHEN_CLEAR = ("allow", "block")

# The shipped list. Eleven sites, chosen as the ones a student actually loses
# an evening to; the two he named are first. Each is removable, and anything
# missing goes in `custom`.
#
# `hosts` are registrable-domain suffixes: matching is done on the suffix so
# that m.youtube.com, www.youtube.com and youtube.com are one entry rather
# than three, and so that a lookalike domain ending in "notyoutube.com" does
# NOT match (see `_matches`).
PRESETS: tuple[dict, ...] = (
    {"id": "youtube",   "label": "YouTube",   "hosts": ("youtube.com", "youtu.be", "youtube-nocookie.com")},
    {"id": "instagram", "label": "Instagram", "hosts": ("instagram.com",)},
    {"id": "tiktok",    "label": "TikTok",    "hosts": ("tiktok.com",)},
    {"id": "snapchat",  "label": "Snapchat",  "hosts": ("snapchat.com",)},
    {"id": "x",         "label": "X / Twitter", "hosts": ("x.com", "twitter.com")},
    {"id": "reddit",    "label": "Reddit",    "hosts": ("reddit.com",)},
    {"id": "facebook",  "label": "Facebook",  "hosts": ("facebook.com",)},
    {"id": "discord",   "label": "Discord",   "hosts": ("discord.com",)},
    {"id": "twitch",    "label": "Twitch",    "hosts": ("twitch.tv",)},
    {"id": "netflix",   "label": "Netflix",   "hosts": ("netflix.com",)},
    {"id": "pinterest", "label": "Pinterest", "hosts": ("pinterest.com",)},
)

PRESET_IDS = tuple(p["id"] for p in PRESETS)

# A hostname the student typed. No scheme, no path, no wildcard: the pattern
# that reaches Chrome is built here, so what is stored has to be the bare host
# or the permission request is malformed.
_HOSTNAME = re.compile(r"^(?=.{4,253}$)[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?"
                       r"(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$")

# Hosts Focus must never be pointed at. Two reasons, both of which would make
# the feature dangerous rather than annoying: the school sites are where the
# homework IS, and a gate over the browser's own settings pages would take
# away the way out of the gate.
NEVER = ("instructure.com", "veracross.com", "google.com", "docs.google.com",
         "drive.google.com", "collegeboard.org", "albert.io", "brophyprep.org",
         "brophybroncos.org", "chrome.google.com", "chromewebstore.google.com",
         "sillybusai.com", "anthropic.com", "claude.ai")

MAX_CUSTOM = 30


class FocusError(ValueError):
    """A Focus setting that will not be written."""


def settings(cfg: dict | None = None) -> dict:
    """The saved Focus block, defaults filled in. Never raises."""
    from sillybus import prefs as ui_prefs

    return dict((ui_prefs.load(cfg) or {}).get("focus") or defaults())


def defaults() -> dict:
    import copy

    return copy.deepcopy(config.DEFAULTS["ui"]["focus"])


def clean_host(value) -> str:
    """A bare hostname, lower-cased, or raise.

    Accepts what a person actually types — "https://example.com/feed",
    "www.Example.com ", "*.example.com" — because refusing a pasted URL over
    its scheme would be the app being pedantic about something it can fix.
    """
    if not isinstance(value, str):
        raise FocusError("a site is a web address like youtube.com")
    host = value.strip().lower()
    host = re.sub(r"^[a-z]+://", "", host)          # a pasted URL
    host = host.split("/")[0].split("?")[0]         # its path and query
    host = host.split("@")[-1].split(":")[0]        # credentials and a port
    host = re.sub(r"^\*\.", "", host)               # a wildcard someone copied
    host = host.rstrip(".")
    if host.startswith("www."):
        host = host[4:]
    if not host:
        raise FocusError("a site is a web address like youtube.com")
    if not _HOSTNAME.match(host):
        raise FocusError(f"{value.strip()[:60]!r} is not a web address — "
                         "type it like youtube.com")
    if _matches(host, NEVER):
        raise FocusError(f"{host} is where your schoolwork is — Focus will not block it")
    return host


def _matches(host: str, suffixes) -> bool:
    """Is `host` the suffix itself or something under it?

    Suffix matching, not `endswith`: "notyoutube.com".endswith("youtube.com")
    is true and is a different site.
    """
    host = (host or "").lower().rstrip(".")
    if host.startswith("www."):
        host = host[4:]
    for suffix in suffixes:
        if host == suffix or host.endswith("." + suffix):
            return True
    return False


def active_presets(focus: dict | None = None) -> list[dict]:
    """The presets still on the list, in the shipped order."""
    focus = focus if focus is not None else settings()
    gone = set(focus.get("sites_off") or ())
    return [p for p in PRESETS if p["id"] not in gone]


def hosts(focus: dict | None = None) -> list[str]:
    """Every hostname Focus applies to: the kept presets, then the custom ones."""
    focus = focus if focus is not None else settings()
    out: list[str] = []
    for preset in active_presets(focus):
        out.extend(preset["hosts"])
    for host in focus.get("custom") or ():
        if host not in out:
            out.append(host)
    return out


def origins(focus: dict | None = None) -> list[str]:
    """Chrome match patterns for the site list.

    One pattern per host covering the domain and its subdomains, which is the
    narrowest thing Chrome will grant for "YouTube" — there is no pattern that
    means "this domain only, no subdomains", and m.youtube.com has to work.
    """
    return [f"*://*.{host}/*" for host in hosts(focus)]


def applies_to(host: str, focus: dict | None = None) -> str | None:
    """The label of the site-list entry `host` falls under, or None.

    Returns the label rather than a bool so the gate can name the site it is
    covering; a gate that will not say what it stopped reads as a browser
    fault rather than a choice the student made.
    """
    focus = focus if focus is not None else settings()
    if focus.get("mode") == "off":
        return None
    if _matches(host, NEVER):
        return None
    for preset in active_presets(focus):
        if _matches(host, preset["hosts"]):
            return preset["label"]
    for custom in focus.get("custom") or ():
        if _matches(host, (custom,)):
            return custom
    return None


def due_summary(state: dict | None, today) -> dict:
    """What the card and the gate say about the student's actual work.

    The buckets are `notify.buckets` — the same split the Mac banners use — so
    the reminder, the banner and the board can never disagree about how much
    is due. `clear` is what `when_clear` is decided on, and it is false when
    anything is overdue or due in the next two days; an undated item alone
    never makes the board un-clear, because it has no deadline to be late for
    (the rule `notify.compose` already follows).
    """
    if not state:
        # No data is not "nothing due". The gate treats an unknown board as
        # work outstanding, because the alternative is Focus quietly letting
        # everything through the first time the extension is installed.
        return {"known": False, "clear": False, "headline": "",
                "lead": "", "counts": {}}

    groups = notify.buckets(state, today)
    counts = {name: len(items) for name, items in groups.items()}
    composed = notify.compose(groups)
    pressing = counts.get("overdue", 0) + counts.get("today", 0) + counts.get("tomorrow", 0)
    return {
        "known": True,
        "clear": pressing == 0,
        "headline": composed[0] if composed else "",
        "lead": composed[1] if composed else "",
        "counts": counts,
    }


def snapshot(cfg: dict | None = None) -> dict:
    """Everything the extension needs to decide, in one object.

    The content script runs on youtube.com with no Python anywhere — the
    dashboard tab may well be closed — so the whole decision has to be
    readable out of `chrome.storage.local` in one go. This is what gets
    mirrored there, and `bridge.js` rewrites it after every refresh.
    """
    from sillybus import pipeline

    focus = settings(cfg)
    state = None
    try:
        state = pipeline.load_state_overlaid()
    except Exception:  # noqa: BLE001 — a missing board is not a Focus failure
        state = None
    return {
        "mode": focus.get("mode", "off"),
        "remind_every": focus.get("remind_every", "visit"),
        "bypass_minutes": focus.get("bypass_minutes", 15),
        "when_clear": focus.get("when_clear", "allow"),
        "sites": [{"label": p["label"], "hosts": list(p["hosts"])}
                  for p in active_presets(focus)]
                 + [{"label": h, "hosts": [h]} for h in (focus.get("custom") or ())],
        "due": due_summary(state, pipeline.today_local()),
        # The dates themselves, so the gate decides "clear?" on the day it
        # is asked, not the day this was mirrored (prosecution round 3,
        # 2026-10-07: a Friday snapshot left YouTube open all weekend).
        "as_of": pipeline.today_local().isoformat(),
        "open_dates": _open_dates(state),
    }


def _open_dates(state: dict | None) -> list[dict]:
    """Every open dated item as {d: due date, a: is it a test/quiz} — a past
    test is not overdue (notify.is_assessment), so the gate needs to know."""
    out = []
    for item in (state or {}).get("items") or []:
        if item.get("done") or not item.get("due_date"):
            continue
        out.append({"d": item["due_date"], "a": notify.is_assessment(item)})
    return out
