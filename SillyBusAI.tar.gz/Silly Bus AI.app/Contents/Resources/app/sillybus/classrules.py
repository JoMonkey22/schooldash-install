"""What the student has said about how each class really works, applied on refresh.

*"the chat function should give clarifying instructions for reading classes
(like we're a day behind)"* and *"i have a class that doesn't use canvas and i
give it a google doc with everything"* — 2026-09-24.

Three rules per class, kept on the course record (`courses/<key>.json`,
field `rules`) because that is the file the student already edits in Settings
and the one that moves with an export:

  canvas          False = nothing is read from Canvas for this class. "Off"
                  means gone from the board, not greyed out.
  shift_meetings  The class is this many meetings BEHIND the teacher's doc
                  (negative = ahead). Every doc-read date moves by that many of
                  the class's own meetings, so "a day behind" on a class that
                  meets every other day moves work two calendar days, not one.
  reading_notes   Free text for the AI: "the date column is when it's
                  assigned", "ignore the grey rows". Sent to the class-profile
                  learner and to chat; never interpreted by code.

And, because a refresh that quietly rewrites a board is how a student misses
a moved test: `diff_boards` compares the board before and after, and
`shift_hint` spots a class whose doc dates all moved by the same number of
meetings — the usual sign the class is running behind the plan.
"""

from collections import Counter, defaultdict
from datetime import date, datetime

DEFAULTS = {"canvas": True, "shift_meetings": 0, "reading_notes": ""}
MAX_SHIFT = 10


def of(record: dict | None) -> dict:
    """A class's rules, with the defaults filled in."""
    rules = dict(DEFAULTS)
    rules.update({k: v for k, v in ((record or {}).get("rules") or {}).items()
                  if k in DEFAULTS})
    return rules


def clean(patch: dict) -> dict:
    """Only known rules, in range. Raises ValueError with a sentence to show."""
    out = {}
    if "canvas" in patch:
        out["canvas"] = bool(patch["canvas"])
    if "shift_meetings" in patch:
        try:
            shift = int(patch["shift_meetings"] or 0)
        except (TypeError, ValueError):
            raise ValueError("how far behind has to be a whole number of classes")
        if abs(shift) > MAX_SHIFT:
            raise ValueError(f"at most {MAX_SHIFT} classes behind or ahead")
        out["shift_meetings"] = shift
    if "reading_notes" in patch:
        out["reading_notes"] = str(patch["reading_notes"] or "").strip()[:600]
    return out


def all_rules() -> dict[str, dict]:
    """course_key -> rules, only for classes with any rule set."""
    from sillybus import courses
    try:
        records = courses.load_all()
    except Exception:  # noqa: BLE001 — no records, no rules
        return {}
    return {key: of(rec) for key, rec in records.items() if rec.get("rules")}


def describe(rules: dict) -> str:
    """One line for the student (and the chat payload)."""
    bits = []
    if not rules.get("canvas", True):
        bits.append("Canvas off")
    shift = rules.get("shift_meetings") or 0
    if shift:
        bits.append(f"{abs(shift)} class{'es' if abs(shift) != 1 else ''} "
                    f"{'behind' if shift > 0 else 'ahead of'} the doc")
    if rules.get("reading_notes"):
        bits.append(f"note: {rules['reading_notes']}")
    return "; ".join(bits)


# --------------------------------------------------------------------------
# applied during refresh


def drop_canvas(items: list, rules: dict[str, dict]) -> tuple[list, int]:
    """Canvas-read items for classes the student switched Canvas off for."""
    off = {key for key, r in rules.items() if not r.get("canvas", True)}
    if not off:
        return items, 0
    kept = [i for i in items if _key(i) not in off]
    return kept, len(items) - len(kept)


def shift_items(items: list, rules: dict[str, dict], index) -> int:
    """Move doc-read dates by each class's shift, in its own meetings.

    The item id is NOT recomputed: it was stamped from the doc's own date, so a
    done tick survives the student changing the shift, and the id stays the
    same thing the doc says."""
    moved = 0
    for item in items:
        if any(f in (getattr(item, 'flags', None) or []) for f in ('teacher_discussion_entry', 'teacher_own_deadline')):
            continue  # Canvas root-post deadlines are not positional teacher-doc dates
        shift = (rules.get(_key(item)) or {}).get("shift_meetings") or 0
        if not shift or not getattr(item, "due_date", None):
            continue
        new = shifted(item.course, item.due_date, shift, index)
        if not new or new == item.due_date:
            continue
        when = None
        try:
            when = index.time_on(item.course, date.fromisoformat(new)) if index else None
        except Exception:  # noqa: BLE001
            when = None
        item.due_date = new
        if item.due:
            item.due = when.isoformat() if isinstance(when, datetime) else new
        n = abs(shift)
        item.date_note = ((item.date_note or "").rstrip(". ")
                          + f"; moved {n} class{'es' if n != 1 else ''} "
                          + ("later" if shift > 0 else "earlier")
                          + " because you said this class is "
                          + f"{n} {'behind' if shift > 0 else 'ahead'}")
        moved += 1
    return moved


def shifted(course: str, iso: str, shift: int, index) -> str | None:
    """`iso` moved `shift` of this class's meetings. None when the class has no
    meetings in the feed — a shift is never guessed in calendar days."""
    if not index or not getattr(index, "available", False):
        return None
    try:
        day = date.fromisoformat(iso[:10])
    except ValueError:
        return None
    meets = index.dates(course)
    if not meets:
        return None
    if shift > 0:
        ahead = [d for d in meets if d > day]
        # the doc date itself may be a meeting; either way count meetings after it
        return ahead[shift - 1].isoformat() if len(ahead) >= shift else None
    before = [d for d in meets if d < day]
    return before[shift].isoformat() if len(before) >= -shift else None


# --------------------------------------------------------------------------
# what changed between two boards


def diff_boards(before: list[dict], after: list[dict]) -> dict:
    """New, gone and re-dated items between two refreshes.

    Matched by id first, then by (source, course, title) so an item whose date
    changed — which changes its id — reads as moved, not as one gone and one
    new. Done items and hand-added tasks are left out: nothing about them came
    from a refresh."""
    def live(items):
        return [i for i in items or [] if not i.get("done") and i.get("source") != "task"]

    old, new = live(before), live(after)
    old_ids = {i.get("item_id") for i in old}
    new_ids = {i.get("item_id") for i in new}

    def sig(i):
        return (i.get("source"), i.get("course_key"), (i.get("title") or "").strip().lower())

    old_by_sig = defaultdict(list)
    for i in old:
        if i.get("item_id") not in new_ids:
            old_by_sig[sig(i)].append(i)

    moved, added = [], []
    for i in new:
        if i.get("item_id") in old_ids:
            continue
        twins = old_by_sig.get(sig(i))
        if twins:
            was = twins.pop(0)
            moved.append({"item_id": i.get("item_id"), "title": i.get("title"),
                          "course": i.get("course"), "course_key": i.get("course_key"),
                          "source": i.get("source"),
                          "from": was.get("due_date"), "to": i.get("due_date")})
        else:
            added.append(_brief(i))
    gone = [_brief(i) for rest in old_by_sig.values() for i in rest]
    return {"added": added, "gone": gone, "moved": moved,
            "hints": shift_hints(moved)}


def shift_hints(moved: list[dict]) -> list[dict]:
    """A class whose doc dates ALL moved the same way is probably running
    behind or ahead of the plan. Three or more moves in one direction, at
    least 80% of that class's moves, is the bar."""
    by_course = defaultdict(list)
    for m in moved:
        if m.get("source") != "doc" or not m.get("from") or not m.get("to"):
            continue
        try:
            delta = (date.fromisoformat(m["to"]) - date.fromisoformat(m["from"])).days
        except ValueError:
            continue
        if delta:
            by_course[(m.get("course_key"), m.get("course"))].append(delta)
    hints = []
    for (key, course), deltas in by_course.items():
        if len(deltas) < 3:
            continue
        sign = Counter(1 if d > 0 else -1 for d in deltas).most_common(1)[0]
        if sign[1] / len(deltas) >= 0.8:
            hints.append({"course_key": key, "course": course, "count": len(deltas),
                          "direction": "later" if sign[0] > 0 else "earlier"})
    return hints


def summary(changes: dict) -> str:
    """"2 new · 1 moved · 1 gone", or "" when nothing changed."""
    parts = [f"{len(changes.get(k) or [])} {label}"
             for k, label in (("added", "new"), ("moved", "moved"), ("gone", "gone"))
             if changes.get(k)]
    return " · ".join(parts)


def _brief(i: dict) -> dict:
    return {"item_id": i.get("item_id"), "title": i.get("title"), "course": i.get("course"),
            "course_key": i.get("course_key"), "source": i.get("source"),
            "due_date": i.get("due_date")}


def _key(item) -> str:
    return (item.get("course_key") if isinstance(item, dict)
            else getattr(item, "course_key", "")) or ""
