"""What changed since the last refresh, said in a sentence each.

[ASKED] 2026-09-28: *"be able to realize duplicated assignment and give you
notifications accordingly"*. The board already knows when a date moved and
when two rows look like one assignment; what it lacked was a way to SAY so
that survives the moment. A mark on a row is seen only if the row is looked
at, and the row most worth looking at is the one that just changed under you.

A short list, not a feed. The same rule `notify.py` keeps for the macOS
banner: fifteen alerts on a Sunday night train a student to swipe them all
away. So a refresh adds at most a handful, each carries the item it is about,
and each is dismissed once and stays dismissed (the page remembers the ids).

Nothing here changes an item. These are sentences about the board, computed
from the board, after every decision about it has already been made.
"""

import hashlib
import json
from datetime import date, datetime, timedelta

from sillybus import repeats
from sillybus.logging_setup import get

log = get("notices")

KEEP_DAYS = 3        # a notice nobody dismissed is shown for this long
MOST = 8             # per board, newest first
SOON_DAYS = 2        # "new" is only worth saying when it is close
# Bumped when the rule that made a notice changes, so notices written by the
# old rule are dropped rather than carried: 2026-09-29 the key mistook a
# series for a move, and three days of "Progress Video #7 moved" would
# have been carried forward as truth.
RULE = 2


def _key(entry: dict) -> tuple:
    """What makes two rows the same assignment across refreshes.

    `item_id` will not do: it is built from the due date, so a moved date is
    a new id and the whole point is to notice the move. Canvas's own
    assignment id is stable; for everything else the course and the title's
    shape are the best there is.
    """
    raw = entry.get("raw_cell") or ""
    if entry.get("source") == "canvas" and raw:
        try:
            aid = json.loads(raw).get("assignment_id")
        except (TypeError, ValueError):
            aid = None
        if aid:
            return ("canvas", aid)
    # The exact title, not its stem. [MEASURED] 2026-09-29 on the real
    # board: "Progress Video #6" and "Progress Video #7" share a stem, so a
    # stem key called them one assignment whose date had moved, twice, in
    # both directions. A series is the one thing this must not mistake for
    # a move; a title that changes wording is simply a new item.
    return (entry.get("source") or "", entry.get("course_key") or "",
            " ".join((entry.get("title") or "").lower().split()))


def _nice(iso: str | None) -> str:
    try:
        return f"{date.fromisoformat(iso):%a %b %d}" if iso else "no date"
    except (TypeError, ValueError):
        return iso or "no date"


def _id(*parts) -> str:
    return hashlib.sha1("|".join(str(p) for p in parts).encode()).hexdigest()[:12]


def build(previous: list, current: list, twice: list, today: date,
          when: str | None = None) -> list:
    """The notices this refresh adds. Pure: no clock, no disk."""
    when = when or datetime.now().isoformat(timespec="seconds")
    before = {}
    for entry in previous or []:
        before.setdefault(_key(entry), entry)
    out = []

    for entry in current or []:
        if entry.get("done"):
            continue
        key = _key(entry)
        old = before.get(key)
        if old is None:
            # New, and close. A new thing three weeks out is the board's
            # ordinary business; a new thing due tomorrow is a surprise.
            due = entry.get("due_date")
            if due and 0 <= (date.fromisoformat(due) - today).days <= SOON_DAYS:
                out.append({
                    "id": _id("new", key, due), "kind": "new", "when": when, "v": RULE,
                    "item_id": entry.get("item_id"),
                    "text": (f"New: “{entry.get('title')}” is due "
                             f"{_nice(due)} ({entry.get('course') or 'no class'})"),
                })
            continue
        was, now = old.get("due_date"), entry.get("due_date")
        if was and now and was != now:
            out.append({
                "id": _id("moved", key, was, now), "kind": "moved", "when": when, "v": RULE,
                "item_id": entry.get("item_id"),
                "text": (f"“{entry.get('title')}” is due {_nice(now)}, "
                         f"not {_nice(was)} — {entry.get('date_note') or ''}").rstrip(" —"),
            })

    for group in twice or []:
        titles = group.get("titles") or []
        names = " / ".join(f"“{t}”" for t in titles[:3])
        out.append({
            "id": _id("twice", *sorted(group.get("item_ids") or [])),
            "kind": "twice", "when": when, "v": RULE,
            "item_id": (group.get("item_ids") or [None])[0],
            "text": (f"{names} look like the same work listed twice — "
                     f"{group.get('why') or 'two sources'} "
                     f"({group.get('course') or ''}, {_nice(group.get('due_date'))}). "
                     "Nothing has been removed; tick the one you do not need."),
        })
    return out


def carry(previous: list, fresh: list, now: datetime) -> list:
    """Old notices still worth showing, plus the new ones, newest first.

    A notice is kept for KEEP_DAYS whether or not the thing it describes is
    still true — "this moved" is worth knowing for a few days after it moved.
    Same id twice is one notice; the newer text wins.
    """
    keep = {}
    floor = now - timedelta(days=KEEP_DAYS)
    for notice in (previous or []):
        try:
            stamp = datetime.fromisoformat(str(notice.get("when")))
        except (TypeError, ValueError):
            continue
        if stamp.tzinfo is not None:
            stamp = stamp.replace(tzinfo=None)
        if notice.get("v") != RULE:
            continue                      # written by a rule since corrected
        if stamp >= floor and notice.get("id"):
            keep[notice["id"]] = notice
    for notice in fresh or []:
        keep[notice["id"]] = notice
    ordered = sorted(keep.values(), key=lambda n: str(n.get("when")), reverse=True)
    return ordered[:MOST]
