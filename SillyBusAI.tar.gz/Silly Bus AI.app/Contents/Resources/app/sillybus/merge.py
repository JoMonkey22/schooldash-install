"""Merge & dedupe. Order matters (spec §10.9):

1. doc items dedupe against each other (the same deadline written twice —
   "Homework: finish X" on the day set, "Due Today: X" on the day wanted)
2. Canvas wins on a duplicate — authoritative date, points, submitted — but the
   doc's links and detail are KEPT (the doc often carries the AP Classroom link
   Canvas lacks), and merged_from records the absorbed id
3. Veracross / canvas-ics items merge last, lowest precedence

Every merge is logged so a wrong merge is discoverable.
"""

import re
from datetime import date, datetime
from urllib.parse import urlsplit

from sillybus.logging_setup import get
from sillybus.models import Item

log = get("merge")

# Words, and numbers WITH their separators intact.
#
# [MEASURED] 2026-09-03: splitting on the dot turned "2.1" and "2.2" both into
# {"2"}, and "Chapters 2-5" and "Chapters 6-9" into a shared "chapters" plus
# digits that overlapped as often as not. A section number is one name, not a
# sequence of digits — "2.1" identifies work the way "Alchemist" does — so it
# is tokenised whole. Colons stay out, so a time ("11:59") does not become one
# token pretending to be a section.
# Unit letters are part of the identity too: 2A and 2B are different
# quizzes, not the same number 2 with a disposable one-letter word.
WORD = re.compile(r"[a-z]*\d+[a-z]*(?:[.\-/]\d+[a-z]*)*|[a-z]+")


def _words(text: str) -> set[str]:
    """The tokens that identify a piece of work.

    Words of three letters or more, PLUS numbers of two digits or more.
    [MEASURED] 2026-09-02: dropping every short token reduced
    "2.1 #27-49 (odds)" to {"odds"}, so every problem set in Honors Algebra
    ending "(odds)" matched every other at Jaccard 1.0 — and "2.1 HW: #27-49",
    which he had to tell us about, was absorbed into "2.2 HW: #109-131" and
    vanished from the board.

    In maths homework the page numbers ARE the name of the work.

    [MEASURED] 2026-09-03, and this is the second half of the same fix. The
    first version kept numbers of two digits or more and wrote the gap down as
    a decision — "single digits stay out, being mostly section counters".
    They are not counters, they are names:

        Chapters 2-5   vs  Chapters 6-9        both -> {chapters}
        Notes 2.1      vs  Notes 2.2           both -> {notes}
        Quiz 2         vs  Quiz 3              both -> {quiz}

    `dedupe_docs` matches within one date, so four of five such pairs lost an
    item. Nothing had broken on his board only because those happen to fall on
    different days; two quizzes announced for one class would have cost him a
    quiz.

    So: every token carrying a digit counts, at any length. That follows the
    rule stated in the next sentence rather than contradicting it — keeping
    digits is the MORE discriminative direction, and a missed merge shows a
    duplicate while a false merge hides work.
    """
    # Teachers restate the same hand-in with this common worksheet abbreviation.
    return {"worksheet" if w == "wksht" else w
            for w in WORD.findall((text or "").lower())
            if len(w) > 2 or any(c.isdigit() for c in w)}


def _due(item: Item) -> date | None:
    return date.fromisoformat(item.due_date) if item.due_date else None


# "100 points", "15 pts", "5 points." — a mark a teacher wrote into the line.
RE_STATED_MARK = re.compile(r"\b(\d{1,3})\s*(?:pts?|points?)\b", re.I)

# How far apart a doc's statement of a deadline and Canvas's may be and still
# be the same work. One day, because a teacher who moves a deadline restates
# it — [MEASURED] AI Frontiers' doc says both "Due Friday, Sep. 25" and "due
# Sep 26" for one project — and because a doc line stating a date without a
# time is a day out whenever Canvas's deadline is 23:59.
MARK_DATE_SLACK_DAYS = 1


def _stated_mark(item: Item) -> int | None:
    """The mark a doc line claims for itself, if it claims one."""
    for text in (item.title, item.detail):
        match = RE_STATED_MARK.search(text or "")
        if match:
            return int(match.group(1))
    return None


def _same_marked_work(canvas: Item, doc: Item) -> bool:
    """Canvas names the work; the teacher describes it. Match on the mark.

    [MEASURED] 2026-09-02: "Side Hustle Proposal" (Canvas, 100 points, due
    Sep 25) and "100 points. Due Friday, Sep. 25, 11:59 PM. This is the
    project everything since Aug 18 has been feeding." (the teacher's doc)
    share not one word of their titles, so word overlap can never see it — and
    the board carried the same project three times.

    What both state is the mark and the day, and a course does not usually
    hold two different 100-point assignments due within a day of each other.
    Narrow on purpose: the doc line must state a mark, the marks must be
    equal, and the dates must be within a day.
    """
    if canvas.course_key != doc.course_key or _nri_identity_conflict(canvas, doc):
        return False
    if canvas.points is None:
        return False
    mark = _stated_mark(doc)
    if mark is None or int(canvas.points) != mark:
        return False
    canvas_day, doc_day = _due(canvas), _due(doc)
    if not canvas_day or not doc_day:
        return False
    return abs((canvas_day - doc_day).days) <= MARK_DATE_SLACK_DAYS


def _numbers(words: set[str]) -> set[str]:
    return {w for w in words if any(c.isdigit() for c in w)}


def _nri_assessment(title: str):
    """An explicit provider, unit and assessment type; never study/lesson work."""
    text = title or ""
    if re.search(r"\b(?:study|prepare|practice|review|lessons?)\b", text, re.I):
        return None
    unit = re.search(r"\b(?:nri|no\s*red\s*ink)\s+unit\s*(\d+[a-z]?(?:[.\-]\d+[a-z]?)*)\b", text, re.I)
    kinds = {word.lower() for word in re.findall(r"\b(test|quiz|exam)\b", text, re.I)}
    if not unit or len(kinds) != 1:
        return None
    return (unit.group(1).lower(), next(iter(kinds)))


def _nri_identity_conflict(a: Item, b: Item) -> bool:
    left, right = _nri_assessment(a.title), _nri_assessment(b.title)
    return bool(left or right) and left != right


def _canvas_assignment_identity(item: Item):
    if item.kind in ('assessment_request', 'peer_review'):
        return None
    url = urlsplit(item.url or '')
    match = re.fullmatch(r'/courses/(\d+)/assignments/(\d+)/?', url.path)
    if url.scheme in ('http', 'https') and url.hostname and match:
        return (url.hostname, *match.groups())
    return None


def _conflicting_assignment_links(a: Item, b: Item) -> bool:
    left, right = _canvas_assignment_identity(a), _canvas_assignment_identity(b)
    return left is not None and right is not None and left != right


def _disjoint_page_ranges(a: Item, b: Item) -> bool:
    """A shared quiz length is not the identity of a reading assignment."""
    def ranges(item):
        return [(int(lo), int(hi)) for lo, hi in re.findall(
            r'\b(?:pages?|pgs?\.?)\s+(\d{1,5})\s*[-–—]\s*(\d{1,5})\b',
            item.title or '', re.I) if int(lo) <= int(hi)]
    left, right = ranges(a), ranges(b)
    return bool(left and right) and not any(
        max(lo, other_lo) <= min(hi, other_hi)
        for lo, hi in left for other_lo, other_hi in right)


def _same_work(a: Item, b: Item, window_days: int) -> bool:
    if (a.course_key != b.course_key or _nri_identity_conflict(a, b)
            or _conflicting_assignment_links(a, b)):
        return False
    if any('teacher_discussion_entry' in (i.flags or []) for i in (a, b)):
        from sillybus.models import discussion_entry_identity
        if not all('teacher_discussion_entry' in (i.flags or []) for i in (a, b)):
            return False  # board submission/grade cannot represent one teacher root post
        identity = discussion_entry_identity(a.url)
        return bool(identity and identity == discussion_entry_identity(b.url))
    if any('submission_milestone' in (i.flags or []) for i in (a, b)):
        if not all('submission_milestone' in (i.flags or []) for i in (a, b)):
            return False  # final submission/completion does not prove the earlier version hand-in
        shared = _canvas_assignment_identity(a)
        return (shared is not None and shared == _canvas_assignment_identity(b)
                and a.due_date == b.due_date and a.title.casefold() == b.title.casefold())
    if any('named_exit_ticket' in (i.flags or []) for i in (a, b)):
        shared = _canvas_assignment_identity(a)
        if shared is not None and shared == _canvas_assignment_identity(b):
            return True
        if all(i.source != 'canvas' for i in (a, b)):
            return False  # a shared topic does not identify the same hand-in
    if (any('explicit_form_classwork' in (i.flags or []) for i in (a, b))
            and all(i.source != 'canvas' for i in (a, b))):
        if not all('explicit_form_classwork' in (i.flags or []) for i in (a, b)):
            return False
        contexts = [{f for f in i.flags if f.startswith('form_block:')} for i in (a, b)]
        forms = [{link.url for link in i.links if link.kind == 'google_form'} for i in (a, b)]
        return (bool(contexts[0]) and contexts[0] == contexts[1]
                and len(forms[0]) == 1 and forms[0] == forms[1]
                and (a.title.casefold() == b.title.casefold()
                     or all('introductory_form' in (i.flags or []) for i in (a, b))))
    if (any('explicit_section_quiz' in (i.flags or []) for i in (a, b))
            and all(i.source != 'canvas' for i in (a, b))):
        if (not all('explicit_section_quiz' in (i.flags or []) for i in (a, b))
                or a.title.casefold() != b.title.casefold()):
            return False  # no section/date evidence ties separate block quizzes together
    classwork_flags = ('explicit_canvas_classwork', 'explicit_flint_classwork', 'explicit_form_classwork',
                       'explicit_linked_classwork', 'explicit_class_reflection')
    explicit_classwork = [any(flag in (item.flags or []) for flag in classwork_flags) for item in (a, b)]
    if any(explicit_classwork) and any(item.source == 'canvas' for item in (a, b)):
        canonical = a if a.source == 'canvas' else b
        shared = _canvas_assignment_identity(a)
        if (canonical.category in ('quiz', 'test')
                and not (shared is not None and shared == _canvas_assignment_identity(b))):
            return False  # chapter overlap alone does not turn an activity into a quiz
    if any(explicit_classwork) and all(item.source != 'canvas' for item in (a, b)):
        if not all(explicit_classwork) or a.title.casefold() != b.title.casefold():
            return False  # task name AND source block identify these undated commands
    writing = [any(flag in (i.flags or []) for flag in ('scored_writing_activity', 'split_reading_discussion', 'below_subtask_parent'))
               for i in (a, b)]
    if any(writing):
        if a.source == 'canvas' or b.source == 'canvas':
            identity = _canvas_assignment_identity(a)
            return identity is not None and identity == _canvas_assignment_identity(b)
        identities = [next((f for f in i.flags if f.startswith(('scored_writing_context:', 'reading_discussion_context:', 'below_subtask_context:'))), None) for i in (a, b)]
        if not all(writing) or not all(identities) or identities[0] != identities[1]:
            return False
    if (any('split_practice_monthly' in (i.flags or []) for i in (a, b))
            and any('moved_work_component' in (i.flags or []) for i in (a, b))):
        shared = _canvas_assignment_identity(a)
        if shared is None or shared != _canvas_assignment_identity(b):
            return False  # a test mentioned as the reason for postponement is not the reading
    if all('moved_work_component' in (i.flags or []) for i in (a, b)):
        targets = [{f for f in i.flags if f.startswith('split_target:moved:')} for i in (a, b)]
        if all(targets) and targets[0] != targets[1]:
            return False  # reading and postponed writing remain separate even when undated
    own_day = ['own_presentation_day' in (i.flags or []) for i in (a, b)]
    if any(own_day) and not all(own_day):
        return False  # a generic restatement cannot supply the student's team/day
    if (any('split_practice_monthly' in (i.flags or []) for i in (a, b))
            and {a.category, b.category} == {'practice', 'test'}):
        return False
    if all('split_practice_monthly' in (i.flags or []) for i in (a, b)):
        identities = [{f for f in i.flags if f.startswith('split_target:')} for i in (a, b)]
        if all(identities) and identities[0] != identities[1]:
            return False
    if all('numbered_essay_target' in (i.flags or []) for i in (a, b)):
        targets = [re.match(r'^Class (\d+): (practice|lockdown) essay\b', i.title, re.I)
                   for i in (a, b)]
        if all(targets) and targets[0].groups() != targets[1].groups():
            return False
    if any('conditional_missing_work' in (i.flags or []) for i in (a, b)):
        identity = _canvas_assignment_identity(a)
        return bool(identity and identity == _canvas_assignment_identity(b)
                    and all(i.kind != 'assessment_request' for i in (a, b)))
    if any('closed_assignment_reminder' in (i.flags or []) for i in (a, b)):
        if (all(i.source != 'canvas' for i in (a, b))
                and not all('closed_assignment_reminder' in (i.flags or []) for i in (a, b))):
            return False  # keep a dated teacher item alongside its undated reminder
        # An undated catch-up reminder must not attach to a different same-name
        # assignment, or turn a peer-review submission view into ordinary work.
        def identity(item):
            parsed = urlsplit(item.url or '')
            match = re.fullmatch(r'/courses/(\d+)/assignments/(\d+)/?', parsed.path)
            return (parsed.hostname, *match.groups()) if match and parsed.hostname else None
        ref = identity(a)
        return bool(ref and ref == identity(b)
                    and all(i.kind != 'assessment_request' for i in (a, b)))
    # An exact title and assignment link establish identity across sources
    # even when a teacher document still shows an earlier deadline.
    if ((a.source == 'canvas') != (b.source == 'canvas')
            and ' '.join(a.title.casefold().split()) == ' '.join(b.title.casefold().split())):
        identity = _canvas_assignment_identity(a)
        if identity is not None and identity == _canvas_assignment_identity(b):
            return True
    # Two reading ranges can share a quiz length (20 questions) or class
    # number. Those incidental numbers must not defeat work identity.
    shared_assignment = _canvas_assignment_identity(a)
    if (_disjoint_page_ranges(a, b)
            and not (shared_assignment is not None
                     and shared_assignment == _canvas_assignment_identity(b))):
        return False
    def work_title(item):
        if 'named_exit_ticket' in (item.flags or []):
            return item.title.partition(' — class ')[0]
        return (item.title.partition(' — class block ')[0]
                if any(flag in (item.flags or []) for flag in (*classwork_flags, 'explicit_section_quiz')) else item.title)
    a_words, b_words = _words(work_title(a)), _words(work_title(b))
    if not a_words or not b_words:
        return False
    # Different numbers mean different work, however alike the words are.
    #
    # [MEASURED] 2026-09-03: "True Diary Chapters 2-5 are due with highlighted
    # characters" and the same sentence with "6-9" share eight words of ten and
    # score 0.80 — comfortably a merge, and one chapter range would be gone.
    # The overlap cannot see that the single token they differ on is the only
    # part that names the work.
    #
    # Disjoint, not unequal: {2.1} and {2.1, 27-49} are the same section
    # described in more detail by one source, and those SHOULD merge. Two sets
    # that share nothing are two pieces of work. An item with no numbers at all
    # tells us nothing either way, so the word overlap below decides.
    a_nums, b_nums = _numbers(a_words), _numbers(b_words)
    if a_nums and b_nums and not (a_nums & b_nums):
        return False
    smaller = min(len(a_words), len(b_words))
    if not smaller or len(a_words & b_words) / smaller < 0.7:
        return False
    da, db_ = _due(a), _due(b)
    if da and db_:
        return abs((da - db_).days) <= window_days
    return True


def _stated_deadline_clock(item: Item):
    """Recognize extractor-owned clock provenance, checked against its instant."""
    match = re.search(r'\bdeadline (?:time|clock) ([0-2]\d:[0-5]\d) from (?:the )?line itself\b',
                      item.date_note or '')
    if not match or not item.due:
        return None
    try:
        moment = datetime.fromisoformat(item.due)
    except ValueError:
        return None
    return (match.group(1) if moment.tzinfo is not None
            and moment.date().isoformat() == item.due_date
            and moment.strftime('%H:%M') == match.group(1) else None)


def _unresolved_relative_pair(a: Item, b: Item):
    """Return an unresolved relative-day statement that cannot prove same date."""
    if bool(a.due_date) == bool(b.due_date):
        return None
    unknown = b if a.due_date else a
    if (unknown.extractor == 'unresolved' and not unknown.due
            and re.search(r'\b(?:today|tonight|tomorrow)\b',
                          unknown.raw_cell or unknown.detail or unknown.title, re.I)):
        return unknown
    return None


def _numbered_study_event(reminder, candidates):
    """Bind explicit preparation to one nearby numbered quiz, never by topic alone."""
    text = reminder.detail or reminder.title
    named = re.match(r'^s\s*tudy\s+for\s+quiz\s*#?\s*(\d+)\s+on\s+'
                     r'(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\b', text, re.I)
    if not named or not reminder.due_date:
        return None
    weekday = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'].index(named[2].lower())
    origin = _due(reminder)
    matches = []
    for candidate in candidates:
        quiz = re.match(r'^quiz\s*#?\s*(\d+)\b', candidate.title, re.I)
        day = _due(candidate)
        if (not quiz or quiz[1] != named[1] or candidate.course_key != reminder.course_key
                or _conflicting_assignment_links(reminder, candidate)
                or candidate.category != 'quiz' or 'stated_category' not in candidate.flags
                or day is None or day.weekday() != weekday or not 0 <= (day-origin).days <= 7):
            continue
        topic = _words(candidate.title) & _words(text[named.end():])
        if len({w for w in topic if not any(c.isdigit() for c in w)}) >= 3:
            matches.append(candidate)
    return matches[0] if len(matches) == 1 else None


def _catchup_name(item):
    if 'conditional_missing_work' in (item.flags or []):
        return item.title.strip().casefold()
    match = re.fullmatch(r'([A-Za-z][^?!.:]{2,60}?) not turned in yet\?\s*'
                         r'Finish that first[.!]?', item.title or '', re.I)
    return match[1].strip().casefold() if match else None


def _catchup_target(reminder, candidates):
    name = _catchup_name(reminder)
    if not name or not reminder.due_date:
        return None
    matches = [candidate for candidate in candidates
               if candidate.course_key == reminder.course_key
               and candidate.due_date == reminder.due_date
               and _canvas_assignment_identity(candidate) is not None
               and not _conflicting_assignment_links(reminder, candidate)
               and _stated_deadline_clock(candidate) is not None
               and (candidate.title.casefold() == name
                    or candidate.title.casefold().startswith(name + ':'))]
    return matches[0] if len(matches) == 1 else None


def _quizlet_write(item):
    return re.fullmatch(r'Finish\s+(?:Quizlet\s+)?Write\s+for\s+(.{1,80}?)\s+set(.*)',
                        item.title or '', re.I)


def _dated_quizlet_write(item):
    match = _quizlet_write(item)
    day = re.fullmatch(r'\s+by day (\d+)\s*', match[2], re.I) if match else None
    return bool(day and item.due_date and re.search(
        rf'\bDay {day[1]} explicitly dated {re.escape(item.due_date)}\b', item.date_note, re.I))


def _quizlet_reminder_target(reminder, candidates):
    match = _quizlet_write(reminder)
    if (not match or not reminder.due_date
            or not re.fullmatch(r'\s*(?:Optional Gimkit Practice(?: Links to an external site)?)?\s*',
                                match[2], re.I)):
        return None
    matches = [candidate for candidate in candidates
               if candidate.course_key == reminder.course_key and _dated_quizlet_write(candidate)
               and _quizlet_write(candidate)[1].casefold() == match[1].casefold()
               and not _conflicting_assignment_links(reminder, candidate)
               and 0 <= (_due(candidate) - _due(reminder)).days <= 7]
    return matches[0] if len(matches) == 1 else None


def dedupe_docs(doc_items: list[Item]) -> list[Item]:
    """Collapse the same deadline written twice in one doc. The longer wording
    is kept because it carries the instructions."""
    kept: list[Item] = []
    # A named assessment is the subject; its longer "study for" reminder
    # must not replace its title/category when both describe the same event.
    for item in sorted(doc_items, key=lambda i: (
            "stated_category" in (i.flags or []), not bool(_catchup_name(i)),
            _dated_quizlet_write(i), len(i.title or "")), reverse=True):
        candidates = [k for k in kept if _same_work(item, k, 0)]
        compatible = []
        for candidate in candidates:
            unknown = _unresolved_relative_pair(item, candidate)
            if unknown is None:
                compatible.append(candidate)
                continue
            for flag in ('needs_date_confirmation', 'possible_duplicate_deadline'):
                if flag not in unknown.flags:
                    unknown.flags.append(flag)
            marker = 'possible restatement of dated work; relative source day needs confirmation'
            if marker not in unknown.date_note:
                unknown.date_note += '; ' + marker
        twin = next(iter(compatible), None)
        study_hint = re.match(r"^(?:s\s*tudy|prepare|review)\s+for\s+", item.title or "", re.I)
        if twin is None and study_hint and item.due_date:
            named = _words((item.title or "")[study_hint.end():])
            twin = next((k for k in kept if "stated_category" in (k.flags or [])
                         and k.course_key == item.course_key and k.due_date == item.due_date
                         and named and named <= _words(k.title)), None)
        if twin is None and study_hint:
            twin = _numbered_study_event(item, kept)
        if twin is None:
            twin = _catchup_target(item, kept)
        if twin is None:
            twin = _quizlet_reminder_target(item, kept)
        if twin is None:
            kept.append(item)
        else:
            # Keep the richer wording/identity, but do not let its default
            # time erase a stated clock for this same proven deadline.
            stated, kept_clock = _stated_deadline_clock(item), _stated_deadline_clock(twin)
            if (item.due_date and item.due_date == twin.due_date and stated and kept_clock
                    and stated != kept_clock):
                twin.due = None
                twin.date_note += f'; conflicting stated deadline clocks {kept_clock} and {stated}; clock needs confirmation'
                for flag in ('deadline_clock_conflict', 'needs_date_confirmation'):
                    if flag not in twin.flags:
                        twin.flags.append(flag)
                if item.detail and item.detail not in (twin.detail or ''):
                    twin.detail = (twin.detail or twin.title) + '\nDeadline restatement: ' + item.detail
            elif (item.due_date and item.due_date == twin.due_date
                    and stated and not kept_clock and 'deadline_clock_conflict' not in twin.flags):
                twin.due = item.due
                twin.all_day = item.all_day
                twin.date_note = item.date_note + '; clock supplied by a duplicate source restatement'
                twin.flags = [f for f in twin.flags if f != 'deadline_clock_unstated']
                if item.detail and item.detail not in (twin.detail or ''):
                    twin.detail = (twin.detail or twin.title) + '\nDeadline restatement: ' + item.detail
            if (item.due_date == twin.due_date and kept_clock and not stated
                    and len(item.detail or '') > len(twin.detail or '')
                    and item.detail not in (twin.detail or '')):
                twin.detail = (twin.detail or twin.title) + '\nSource restatement: ' + item.detail
            if study_hint and item.detail and item.detail not in (twin.detail or ""):
                twin.detail = (twin.detail or twin.title) + "\nStudy reminder: " + item.detail
            if _catchup_name(item) and item.detail and item.detail not in (twin.detail or ""):
                twin.detail = (twin.detail or twin.title) + "\nCatch-up reminder: " + item.detail
            if (_quizlet_write(item) and _dated_quizlet_write(twin) and item.detail
                    and item.detail not in (twin.detail or "")):
                twin.detail = (twin.detail or twin.title) + "\nSet reminder: " + item.detail
            twin.merged_from.append(f"doc:{item.item_id}")
            seen = {l.url if hasattr(l, "url") else l.get("url") for l in twin.links}
            for link in item.links:
                url = link.url if hasattr(link, "url") else link.get("url")
                if url not in seen:
                    twin.links.append(link)
            log.info("doc dedupe: %r absorbed %r", twin.title[:50], item.title[:50])
    return kept


def _unique_classwork_twin(doc: Item, candidates: list[Item]) -> Item | None:
    """A generic schedule label may name one dated Canvas classwork hand-in.

    Keep Canvas's submitted state; two possible classworks are ambiguous and
    must stay separate. Never use this for tests, quizzes or peer reviews.
    """
    if not doc.due_date or not re.fullmatch(r"classwork\s*(?:\(\s*due\b[^)]*\))?",
                                           doc.title or "", re.I):
        return None
    matches = [item for item in candidates
               if item.course_key == doc.course_key and item.due_date == doc.due_date
               and re.search(r"\bclasswork\b", item.title or "", re.I)
               and not re.search(r"\b(?:quiz|test|exam|peer review)\b", item.title or "", re.I)
               and item.kind not in ("assessment_request", "peer_review")]
    by_assignment = {}
    for item in matches:
        url = (item.url or "").split("?", 1)[0].split("#", 1)[0]
        identity = re.match(r"https?://[^/]+/courses/[^/]+/assignments/\d+(?=/|$)", url)
        key = identity.group(0) if identity else f"unidentified:{id(item)}"
        if key not in by_assignment or url == key:
            by_assignment[key] = item
    return next(iter(by_assignment.values())) if len(by_assignment) == 1 else None


def merge(canvas_items: list[Item], doc_items: list[Item],
          window_days: int = 3, report: list | None = None) -> list[Item]:
    """Canvas wins where both describe the same work; the doc copy's links and
    detail survive on the winner.

    `report` collects the cases where the two sources disagreed about the DATE.
    Canvas is authoritative, so the disagreement is resolved silently — but it
    is also the only independent check on whether a class profile reads its
    teacher's doc correctly, and a class whose doc is consistently one meeting
    out has a profile bug, not bad luck. The pipeline looks for that pattern.
    """
    # Full refresh used to absorb the dated NRI doc test into undated Canvas,
    # erasing the very deadline a document-only refresh had just restored.
    nri_dates = {}
    for doc in doc_items:
        identity = _nri_assessment(doc.title)
        if identity and doc.due_date:
            nri_dates.setdefault((doc.course_key, identity), set()).add((doc.due, doc.due_date))
    kept_docs: list[Item] = []
    for item in dedupe_docs(doc_items):
        identity = _nri_assessment(item.title)
        dates = nri_dates.get((item.course_key, identity), set())
        candidates = [c for c in canvas_items if not _conflicting_assignment_links(item, c)]
        assignment = _canvas_assignment_identity(item)
        if assignment is not None:
            linked = [c for c in candidates if c.course_key == item.course_key
                      and _canvas_assignment_identity(c) == assignment]
            if linked:
                candidates = linked
        winner = next((c for c in candidates
                       if _same_work(item, c, window_days)
                       and not (identity and not c.due_date and len(dates) != 1)), None)
        if winner is None and any(flag in (item.flags or []) for flag in (
                'closed_assignment_reminder', 'conditional_missing_work', 'scored_writing_activity', 'split_reading_discussion', 'below_subtask_parent',
                'submission_milestone')):
            kept_docs.append(item)
            continue
        if winner is None:
            # Canvas names the work and the teacher describes it, so their
            # words can share nothing at all. The mark and the day are what
            # both state (see _same_marked_work).
            winner = next((c for c in candidates
                           if _same_marked_work(c, item)), None)
        if winner is None:
            winner = _unique_classwork_twin(item, candidates)
            if winner is not None:
                winner.flags = list(winner.flags or []) + ["matched_unique_classwork"]
        if winner is None:
            kept_docs.append(item)
            continue
        if (identity and not winner.due_date and item.due_date
                and _nri_assessment(winner.title) == identity and len(dates) == 1):
            winner.due, winner.due_date = item.due, item.due_date
            winner.all_day = item.all_day
            winner.confidence, winner.extractor = "medium", "doc_dated"
            winner.date_note = ("Canvas lists this with no due date; the course doc "
                                f"dates the same No Red Ink unit {identity[0]} {identity[1]} — "
                                f"{item.date_note}")
        winner.merged_from.append(f"doc:{item.item_id}")
        if (report is not None and item.due_date and winner.due_date
                and item.due_date != winner.due_date):
            report.append({"course_key": item.course_key,
                           "course": item.course,
                           "title": winner.title,
                           "doc_date": item.due_date,
                           "canvas_date": winner.due_date})
        seen = {l.url if hasattr(l, "url") else l.get("url") for l in winner.links}
        for link in item.links:
            url = link.url if hasattr(link, "url") else link.get("url")
            if url and url not in seen:
                winner.links.append(link)
                seen.add(url)
        if len(item.detail or "") > len(winner.detail or ""):
            winner.detail = item.detail
        # A long Canvas description must not discard the teacher's separately
        # identified preparation guidance when the two sources merge.
        for flag, marker in (
                ("source_preparation_guidance", "\nPreparation guidance (no separate deadline stated): "),
                ("source_project_guidance", "\nReferenced project instructions: "),
                ("below_subtask_parent", "\nRequired steps:\n")):
            if flag in (item.flags or []):
                guidance = (item.detail or "").partition(marker)[2]
                if guidance and guidance not in (winner.detail or ""):
                    winner.detail = (winner.detail or winner.title) + marker + guidance
        if item.date_note and "Canvas" in winner.date_note and item.date_note not in winner.date_note:
            winner.date_note = (f"{winner.date_note}; the course doc says: "
                                f"{item.date_note}")
        log.info("canvas wins: %r absorbed doc %r", winner.title[:50],
                 item.title[:50])
    date_undated_quizzes(canvas_items, doc_items)
    return list(canvas_items) + kept_docs


RE_ASSESSMENT = re.compile(r"\b(quiz|test|exam)\b", re.I)
# Words that sit beside a quiz in any course and so name none of them.
QUIZ_FILLER = {"quiz", "test", "exam", "pages", "pgs", "page", "chapter",
               "chapters", "details", "unit", "the", "and", "with", "over",
               "question", "questions", "due", "class", "lockdown", "browser"}


def date_undated_quizzes(canvas_items: list[Item], doc_items: list[Item]) -> None:
    """An undated Canvas quiz takes the date the class doc gives that quiz.

    [MEASURED] 2026-10-05, Honors English: Canvas lists "Whalefall Details
    Quiz 1 (pgs 1-41)" with no due date, so it sat at the foot of the board
    under "no date". The teacher's doc says, every class that week, "the
    pages 1-41 assignment due Class 22 with a 20 question lockdown browser
    quiz" — the quiz's day, stated, counted on his timetable as Wed Oct 7.
    The two never merge (three shared words of five), and they should not:
    the doc line is the reading and the flashcards, Canvas's is the quiz.

    Narrow on purpose, because a borrowed date is a claim: the Canvas item
    must be an undated quiz/test/exam; the doc line must name a quiz/test/exam
    too, in the same course, with a date; and they must share BOTH a number
    that has a range or two digits ("1-41") and a word of four letters or more
    that is not furniture ("whalefall"). More than one such line: the earliest
    date, which is the rule COUNT 27 settled — early is an annoyance, late is
    a missed quiz. The note says where the date came from, every time.
    """
    for quiz in canvas_items:
        if quiz.due_date or not RE_ASSESSMENT.search(quiz.title or ""):
            continue
        quiz_words = _words(quiz.title)
        quiz_numbers = {w for w in _numbers(quiz_words) if "-" in w or len(w) >= 2}
        quiz_names = {w for w in quiz_words
                      if len(w) >= 4 and not w[:1].isdigit() and w not in QUIZ_FILLER}
        if not quiz_numbers or not quiz_names:
            continue
        matches = []
        for doc in doc_items:
            # The whole line: a title is cut at ~110 characters, and the real
            # one lost its "quiz" to that.
            text = " ".join(filter(None, (doc.title, doc.detail, doc.raw_cell)))
            if (doc.course_key != quiz.course_key or not doc.due_date
                    or not RE_ASSESSMENT.search(text)):
                continue
            words = _words(text)
            if quiz_numbers & words and quiz_names & words:
                matches.append(doc)
        if not matches:
            continue
        source = min(matches, key=lambda d: d.due_date)
        quiz.due, quiz.due_date = source.due, source.due_date
        quiz.confidence = "medium"
        quiz.extractor = "doc_dated"
        quiz.date_note = ("Canvas lists this with no due date; the class doc "
                          f"gives the quiz's day — {source.date_note}")
        log.info("undated quiz %r dated %s from doc %r", quiz.title[:50],
                 source.due_date, source.title[:50])


def merge_secondary(primary: list[Item], secondary: list[Item],
                    window_days: int = 3) -> list[Item]:
    """Veracross / canvas-ics fallback items: appended only when nothing
    already covers the same work."""
    out = list(primary)
    seen_ids = {p.item_id for p in primary}
    for item in secondary:
        # Only the PRIMARY items can cover a secondary one. Two secondary
        # items are never merged with each other: "Unit 8 Progress Check: MCQ"
        # and "Unit 8 Progress Check: FRQ 1" share four words and a number and
        # are two assignments ([MEASURED] 2026-09-14, AP Classroom).
        if item.item_id in seen_ids:
            continue
        seen_ids.add(item.item_id)
        twin = next((p for p in primary if _same_work(item, p, window_days)), None)
        if twin is None:
            out.append(item)
        else:
            twin.merged_from.append(f"{item.source}:{item.item_id}")
            # The doc says "study for the unit 2 progress check"; AP Classroom
            # knows where that check is. The absorbed item's links travel.
            have = {(l.url if hasattr(l, "url") else l.get("url")) for l in twin.links}
            for link in item.links:
                url = link.url if hasattr(link, "url") else link.get("url")
                if url and url not in have:
                    twin.links.append(link)
                    have.add(url)
            if item.submitted and twin.submitted is None:
                twin.submitted = True
    return out
