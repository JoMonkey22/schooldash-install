"""Student edits layered over imported homework; refresh keeps the source intact."""
from __future__ import annotations

import re
from datetime import date


def identity(item):
    # A specific Canvas assignment has an id independent of its due date.
    # Shared teacher-document URLs are deliberately not identity keys.
    url = item.get('url') or ''
    if item.get('source') == 'canvas' and re.search(r'/assignments/\d+(?:[/?#]|$)', url):
        return (item.get('course_key') or '') + ':' + url.split('?')[0].split('#')[0]
    return None


def save(conn, item, day):
    date.fromisoformat(day)
    conn.execute('INSERT INTO item_due_edits(item_id,due_date) VALUES(?,?) ON CONFLICT(item_id) DO UPDATE SET due_date=excluded.due_date', (item['item_id'], day))
    key = identity(item)
    if key:
        conn.execute('INSERT INTO item_due_identity(identity,due_date) VALUES(?,?) ON CONFLICT(identity) DO UPDATE SET due_date=excluded.due_date', (key,day))
    conn.commit()


def apply(conn, items):
    edits = {r['item_id']: r['due_date'] for r in conn.execute('SELECT item_id, due_date FROM item_due_edits')}
    identities = {r['identity']: r['due_date'] for r in conn.execute('SELECT * FROM item_due_identity')}
    changed = False
    for item in items:
        item.setdefault('school_due_date', item.get('due_date'))
        item['manual_due_date'] = False
        if item.get('item_id') not in edits and identity(item) in identities:
            edits[item['item_id']] = identities[identity(item)]
        if item.get('item_id') in edits:
            changed = True
            item['manual_due_date'] = True
            day = edits[item['item_id']]
            old_due = item.get('due') or ''
            suffix = old_due[10:] if re.match(r'^\d{4}-\d{2}-\d{2}T', old_due) else 'T23:59:00'
            item.update(due_date=day, due=day + suffix,
                        date_note='Due date set by you in chat')
    return changed


def run(message, state, item_id=None, course=None):
    """Only an explicit edit with one real target and one readable date writes."""
    match = re.fullmatch(r'(?:please\s+)?(?:change|set|update|move|reschedule)\s+(.+)\s+(?:due\s+date\s+)?(?:to|for)\s+(.+?)[.!]?', message.strip(), re.I)
    if not match:
        return None
    target, phrase = match.groups()
    target = re.sub(r"^(?:the\s+)?due\s+date\s+(?:of|for)\s+", '', target, flags=re.I)
    target = re.sub(r"\s+(?:due\s+date|deadline)$", '', target, flags=re.I).strip(' \"\'')
    items = state.get('items') or []
    if item_id and target.lower() in ('this', 'it', 'this assignment', 'this homework', 'the due date'):
        matches = [i for i in items if i.get('item_id') == item_id]
    else:
        needle = target.casefold()
        pool = [i for i in items if not course or course.casefold() in str(i.get('course', '')).casefold() or course == i.get('course_key')]
        matches = [i for i in pool if needle == str(i.get('item_id', '')).casefold() or needle == str(i.get('title', '')).casefold()]
        if not matches:
            matches = [i for i in pool if needle in str(i.get('title', '')).casefold()]
    text, updated = '', None
    if len(matches) != 1:
        text = ('Which assignment? Include its full name or open it and ask again.' if not matches else
                'More than one assignment matches. Open the assignment you mean and say “move this to Friday”.')
    else:
        from sillybus import quickadd, db
        from sillybus.pipeline import today_local
        today = today_local()
        try:
            day = date.fromisoformat(phrase).isoformat()
        except ValueError:
            day, _ = quickadd.parse_when(phrase, today)
        if not day:
            text = 'What date should I use? Say a date such as Friday, tomorrow, or 2026-11-02.'
        else:
            item = matches[0]
            conn = db.connect()
            try:
                save(conn, item, day)
            finally:
                conn.close()
            updated = {'item_id': item['item_id'], 'due_date': day}
            text = f'Changed {item["title"]} to {day}. This changes your SillyBus planner; the school’s deadline stays as published.'
    return {'answer': text, 'session_id': None, 'provider': 'local', 'mode': 'edit',
            'action': {'intent': 'edit_due_date', 'updated': updated}, 'actions': [],
            'grounded': True, 'confidence': 'verified', 'verified': 0, 'checked': [],
            'cited': [], 'violations': []}
