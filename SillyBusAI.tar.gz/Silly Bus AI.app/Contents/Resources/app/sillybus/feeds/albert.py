"""Albert.io assignments — a secondary feed, read from a hand-off file.

Built as the twin of `feeds/apclassroom.py`, for the same reason and with the
same boundary. Read that module and `extension/APCLASSROOM.md` first; this
docstring only records what is different.

**Why the extension has to do the reading.** [MEASURED] 2026-09-16: albert.io
is a client-side app whose data comes from a separate origin, `api.albert.io`.
`GET https://api.albert.io/assignments_v3` answers 401 unauthenticated; the
site's own bundle calls it with `credentials: "include"` and the API's CORS
reply names `https://www.albert.io` as the only allowed origin, with
credentials on. So a server-side fetch from Python has no cookie and would be
refused the origin even if it had one, and a fetch from the extension's own
origin is refused too. Only code running ON an albert.io page can ask. The
extension's content script therefore does the reading there and hands this
module assignments — title, subject, due date, status, link — and nothing else.

**The boundary, and it is not an implementation detail.** This module reads
ASSIGNMENT METADATA ONLY: what is assigned, when it is due, whether it is
finished, and a link that opens it. It does NOT read questions, answer
choices, explanations, passages, or any other part of the assessment itself,
and it must never be "improved" to do so. Albert.io is a graded question bank.
Pulling its questions into this app — and from there into a model that would
happily answer them — is doing the check instead of studying for it, which is
not what this program is for and not what its owner asked it to be. AP
Classroom is held to the same line (counts and timers, never content), and so
is anything else that grades answers. If a future change here would put the
text of a question into the app, the answer is no.

The hand-off is a JSON file in the cache directory, written by
boot.apply_albert just before each refresh:

    {"read_at": "2026-09-16T13:05:00-07:00",
     "assignments": [{"id": "9931", "subject": "AP Chemistry",
                      "title": "Unit 4 — Thermodynamics practice set",
                      "due": "2026-09-19T23:59:00-07:00", "status": "assigned",
                      "url": "https://www.albert.io/assignment/9931",
                      "questions": 20, "completed": 6}],
     "diagnostics": {...}, "error": null}

or, when the page could not be read, {"read_at": ..., "error": "…"} — which
becomes an error banner with a Sign in button, never a silent gap.

`questions`/`completed` are COUNTS. They are the same thing AP Classroom's
"12 MCQ, 2 FRQ" is: how much work is left, said without saying what the work
says. They are not content and never become content.
"""

import json
import re
from datetime import datetime, timedelta

from sillybus import config, models, paths, timezones
from sillybus.logging_setup import get

log = get("albert")

SOURCE = "albert"
FILE_NAME = "albert.json"
# Same reasoning as AP Classroom's: the extension writes a fresh hand-off
# before every refresh, so a stale file means the reading stopped happening,
# and a week-old due date must not be shown as news.
STALE_AFTER = timedelta(hours=36)
SIGN_IN_URL = "https://www.albert.io/"
DONE_STATUSES = {"completed", "complete", "submitted", "graded", "scored", "closed",
                 "finished", "done"}
# An assignment with no due date is open practice rather than a deadline.
# Kept only while it is recent, exactly as AP Classroom's undated practice is.
UNDATED_KEEP_DAYS = 14
UNDATED_OLD_FLAG = "albert_undated_old"
_STRIP = re.compile(r"\b(ap|advanced placement|honors|h)\b", re.IGNORECASE)


def handoff_path():
    return paths.cache_dir() / FILE_NAME


def enabled(cfg: dict | None = None) -> bool:
    cfg = cfg or config.load()
    return bool((cfg.get("sources") or {}).get("albert", True))


def load_handoff(now: datetime | None = None) -> dict | None:
    """The hand-off as written, or None when there is none."""
    path = handoff_path()
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        log.warning("albert hand-off unreadable: %s", type(exc).__name__)
        return {"read_at": None, "assignments": [],
                "error": "the hand-off file could not be read"}
    if not isinstance(data, dict):
        return {"read_at": None, "assignments": [],
                "error": "the hand-off file is not an object"}
    now = now or datetime.now(timezones.zone())
    read_at = _parse_when(data.get("read_at"))
    if read_at and now - read_at > STALE_AFTER and not data.get("error"):
        age_h = int((now - read_at).total_seconds() // 3600)
        data = dict(data, error=f"Albert.io was last read {age_h} hours ago; "
                                "open Albert.io in Chrome and SillyBus reads it "
                                "as it loads")
    return data


def _parse_when(value) -> datetime | None:
    if not value or not isinstance(value, str):
        return None
    try:
        stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if stamp.tzinfo is None:
        stamp = stamp.replace(tzinfo=timezones.zone())
    return timezones.to_local(stamp)


def _tokens(name: str) -> set[str]:
    cleaned = _STRIP.sub(" ", name or "")
    return {t for t in re.findall(r"[a-z0-9]+", cleaned.lower()) if len(t) > 1}


def match_course(subject: str, known: dict[str, str]) -> tuple[str, str]:
    """(course_key, display name) — the same word-overlap join AP Classroom
    uses, and for the same reason: Albert's class name is the teacher's, not
    the schedule's. Below half overlap the subject stands as its own course,
    which is visible on the board rather than silently misfiled."""
    want = _tokens(subject)
    best_key, best_score = "", 0.0
    for key, raw in (known or {}).items():
        have = _tokens(models.norm_course(raw)) or _tokens(raw)
        if not want or not have:
            continue
        overlap = len(want & have) / min(len(want), len(have))
        if overlap > best_score:
            best_key, best_score = key, overlap
    if best_key and best_score >= 0.5:
        return best_key, known[best_key]
    return models.course_key_from_raw(subject), subject


def _too_old_to_show(entry: dict, now: datetime) -> bool:
    if entry.get("due"):
        return False
    opened = _parse_when(entry.get("assigned"))
    return opened is None or (now - opened).days > UNDATED_KEEP_DAYS


def _to_item(entry: dict, known: dict[str, str], read_at: str,
             now: datetime | None = None) -> models.Item | None:
    now = now or datetime.now(timezones.zone())
    title = (entry.get("title") or "").strip()
    subject = (entry.get("subject") or "").strip()
    if not title:
        return None
    course_key, course = (match_course(subject, known) if subject
                          else ("unknown-course", "(no course)"))
    due = due_date = None
    all_day = False
    when = _parse_when(entry.get("due"))
    if when:
        due, due_date = when.isoformat(), when.date().isoformat()
        all_day = when.hour == 0 and when.minute == 0
        date_note = "due date shown on Albert.io"
    else:
        date_note = "Albert.io lists this without a due date"
    status = (entry.get("status") or "").strip().lower()
    done = bool(entry.get("submitted")) or status in DONE_STATUSES
    url = (entry.get("url") or "").strip()
    if not url and entry.get("id"):
        url = f"https://www.albert.io/assignment/{entry['id']}"

    # Counts only. See the module docstring: how much is left, never what it
    # asks. `total`/`completed` are the two numbers the assignments list shows
    # the student themselves.
    total = entry.get("questions")
    completed = entry.get("completed")
    bits = [subject, "Albert.io assignment"]
    if isinstance(total, (int, float)) and total:
        if isinstance(completed, (int, float)):
            bits.append(f"{int(completed)} of {int(total)} questions done")
        else:
            bits.append(f"{int(total)} questions")
    if status and not done:
        bits.append(f"status: {status}")
    elif done:
        bits.append("finished")

    item = models.Item(
        source=SOURCE,
        course_key=course_key,
        course=course or "(no course)",
        title=title[:110],
        detail=" · ".join(filter(None, bits)) or title,
        raw_cell=json.dumps({"id": entry.get("id"), "status": status,
                             "questions": total, "completed": completed}),
        kind="Albert.io assignment",
        due=due,
        due_date=due_date,
        all_day=all_day,
        date_note=date_note,
        confidence="high" if when else "medium",
        extractor="canvas_stated",
        points=None,
        submitted=True if done else (False if status else None),
        url=url or None,
        links=[models.Link(url=url, text="Open in Albert.io", kind="albert")] if url else [],
        flags=[UNDATED_OLD_FLAG] if _too_old_to_show(entry, now) else [],
    )
    return item.finalize()


def summary() -> dict | None:
    """What the last hand-off said, for the run's diagnostics — including the
    field names the reader actually saw, so a change on Albert's side turns up
    in Settings rather than as a quietly empty feed. Never a cookie, never a
    token, never a question."""
    # Switched off means gone, not merely ignored: a diagnostics block keeps
    # the connector in Settings and in the run's report. [ASKED] 2026-09-20.
    if not enabled():
        return None
    data = load_handoff()
    if data is None:
        return None
    diag = data.get("diagnostics") or {}
    return {"read_at": data.get("read_at"),
            "undated_keep_days": UNDATED_KEEP_DAYS,
            "reader_version": data.get("reader_version"),
            "assignments": len(data.get("assignments") or []),
            "error": data.get("error"),
            "endpoint": diag.get("endpoint"),
            "http_status": diag.get("http_status"),
            "shape": diag.get("shape"),
            "assignment_keys": diag.get("assignment_keys"),
            "sign_in": diag.get("sign_in"),
            "ms": diag.get("ms")}


def items(known_courses: dict[str, str] | None = None,
          now: datetime | None = None) -> tuple[list[models.Item], dict | None]:
    """(items, error). Never raises; error is an errors[] entry or None."""
    if not enabled():
        return [], None
    data = load_handoff(now)
    if data is None:
        return [], None
    # Not linked in this Chrome: nothing to read and nothing wrong. [ASKED]
    # 2026-10-07 — the site is linked, then read each time he opens it.
    if data.get("error") == "not linked":
        return [], None
    if data.get("error"):
        return [], {"code": "albert", "message": str(data["error"]),
                    "fix": "", "needs_human": True, "open_url": SIGN_IN_URL}
    known = known_courses or {}
    read_at = data.get("read_at") or ""
    now = now or datetime.now(timezones.zone())
    out = []
    for entry in data.get("assignments") or []:
        if not isinstance(entry, dict):
            continue
        try:
            item = _to_item(entry, known, read_at, now)
        except ValueError as exc:
            log.warning("albert item skipped: %s", exc)
            continue
        if item:
            out.append(item)
    return out, None


def drop_old_practice(merged: list[models.Item]) -> tuple[list[models.Item], int]:
    """Standalone Albert items that are undated and were opened long ago go,
    and are counted. One that a doc or Canvas item absorbed keeps its link."""
    kept = [m for m in merged
            if not (m.source == SOURCE and UNDATED_OLD_FLAG in (m.flags or []))]
    return kept, len(merged) - len(kept)
