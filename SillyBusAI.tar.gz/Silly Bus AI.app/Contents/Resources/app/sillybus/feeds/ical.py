"""A tolerant iCalendar parser, plus a bounded expander for repeating events.

Deliberately not a general library: it handles exactly the gotchas these feeds
exhibit — folded continuation lines (unfold BEFORE splitting on ':'), escaped
text, VALUE=DATE all-day stamps, UTC 'Z' stamps, and TZID parameters — and
nothing else. More predictable and more testable than a dependency here.

**Repeating events (added 2026-09-16, for the personal calendars in §4.7).**
The school feeds this module was written for write every class period out in
full, so `parse` alone was enough for them and still is — `expand` is opt-in
and no existing caller passes through it. Personal calendars are the opposite:
[MEASURED] 2026-09-16 against three real Google Calendar exports, 38% of the
VEVENTs were recurrence masters carrying an RRULE, 9% were single-occurrence
overrides (RECURRENCE-ID) and 7% carried cancellations (EXDATE); expanding one
700-event feed produced ~1,520 real occurrences. Reading such a feed without
expanding it silently drops about half of it — and a weekly practice is
exactly the kind of thing a person puts in a calendar once.

`expand` therefore generates occurrences, but only inside the window it is
given: an RRULE with no UNTIL and no COUNT repeats for ever, and a parser that
tries to materialise "for ever" has one outcome. Everything is bounded.

The supported subset is FREQ=DAILY/WEEKLY/MONTHLY/YEARLY with INTERVAL, COUNT,
UNTIL, BYDAY (including 2SU / -1FR ordinals), BYMONTHDAY, BYMONTH and WKST,
plus EXDATE, RDATE and RECURRENCE-ID overrides. Anything outside it — BYSETPOS,
BYWEEKNO, BYYEARDAY, sub-daily frequencies — is NOT guessed at: the series
yields its first occurrence only, flagged `recurrence_unsupported`, so the
caller can say so on the board instead of showing dates nobody wrote.
"""

import re
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from sillybus import timezones


class FeedError(RuntimeError):
    """.fix is the one-line remedy, and it depends on the cause.

    A missing feed URL and a dropped wifi connection are both FeedError, and
    both used to be reported with "setup --import-legacy" — which is useless
    advice for a network blip and sends someone re-importing a config that was
    never the problem.
    """

    def __init__(self, message, fix=""):
        super().__init__(message)
        self.fix = fix


def unfold(text: str) -> str:
    """A line beginning with space/tab continues the previous line. FIRST."""
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    return re.sub(r"\n[ \t]", "", text)


def unescape(value: str) -> str:
    out = []
    i = 0
    while i < len(value):
        ch = value[i]
        if ch == "\\" and i + 1 < len(value):
            nxt = value[i + 1]
            out.append({"n": "\n", "N": "\n", ",": ",", ";": ";", "\\": "\\"}.get(nxt, nxt))
            i += 2
        else:
            out.append(ch)
            i += 1
    return "".join(out)


def _parse_stamp(value: str, params: dict, tz) -> tuple[object, bool]:
    """Returns (date-or-aware-datetime IN ITS OWN ZONE, all_day).

    The stamp is deliberately NOT converted here. A recurrence has to be
    expanded in the timezone the rule was written in — "every Thursday at 7 pm"
    means 7 pm *there* — and converting first throws that zone away. `parse`
    stores both: `dtstart` converted to local, exactly as every existing caller
    expects, and `dtstart_src` in the rule's own zone, which is what `expand`
    works from.
    """
    value = value.strip()
    if params.get("VALUE") == "DATE" or re.fullmatch(r"\d{8}", value):
        return date(int(value[:4]), int(value[4:6]), int(value[6:8])), True
    match = re.fullmatch(r"(\d{8})T(\d{6})(Z?)", value)
    if not match:
        raise ValueError(f"unrecognized iCal stamp: {value!r}")
    stamp = datetime.strptime(match.group(1) + match.group(2), "%Y%m%d%H%M%S")
    if match.group(3) == "Z":
        return stamp.replace(tzinfo=ZoneInfo("UTC")), False
    if params.get("TZID"):
        try:
            return stamp.replace(tzinfo=ZoneInfo(params["TZID"])), False
        except (KeyError, ValueError, ZoneInfoNotFoundError):
            # Outlook writes Windows zone names ("Eastern Standard Time"),
            # which ZoneInfo has never heard of. Falling back to the local
            # zone is a guess, so it is recorded as one by the caller rather
            # than passed off as the feed's own answer.
            return stamp.replace(tzinfo=tz), False
    return stamp.replace(tzinfo=tz), False


def _to_local(stamp, tz):
    return stamp.astimezone(tz) if isinstance(stamp, datetime) else stamp


TEXT_PROPS = {"SUMMARY", "LOCATION", "DESCRIPTION", "UID", "URL", "STATUS"}
# Properties that may legally appear more than once in one VEVENT and whose
# values accumulate rather than replace. Google writes one EXDATE line per
# cancelled occurrence; keeping only the last would un-cancel the rest.
LIST_PROPS = {"EXDATE", "RDATE"}


def parse(text: str, tz=None) -> list[dict]:
    """iCalendar text -> [{summary, dtstart, dtend, all_day, location, ...}].

    dtstart/dtend are tz-aware local datetimes, or plain dates for all-day
    events (all_day True). Unparseable stamps skip the property, never crash.
    """
    tz = tz or timezones.zone()
    events: list[dict] = []
    current: dict | None = None

    for line in unfold(text).split("\n"):
        if not line.strip() or ":" not in line:
            continue
        head, _, value = line.partition(":")
        parts = head.split(";")
        name = parts[0].upper().strip()
        params = {}
        for raw in parts[1:]:
            key, _, val = raw.partition("=")
            if key:
                params[key.upper().strip()] = val.strip().strip('"')

        if name == "BEGIN" and value.strip().upper() == "VEVENT":
            current = {"all_day": False}
        elif name == "END" and value.strip().upper() == "VEVENT":
            if current is not None:
                _end_from_duration(current, tz)
                events.append(current)
            current = None
        elif current is not None:
            if name in ("DTSTART", "DTEND"):
                try:
                    stamp, all_day = _parse_stamp(value, params, tz)
                except ValueError:
                    continue
                # `_src` keeps the rule's own zone for the expander; the plain
                # name stays local, which is what every existing caller reads.
                current[name.lower() + "_src"] = stamp
                current[name.lower()] = _to_local(stamp, tz)
                if all_day:
                    current["all_day"] = True
            elif name in LIST_PROPS:
                for piece in value.split(","):
                    try:
                        stamp, _ = _parse_stamp(piece, params, tz)
                    except ValueError:
                        continue
                    current.setdefault(name.lower() + "_src", []).append(stamp)
                    current.setdefault(name.lower(), []).append(_to_local(stamp, tz))
            elif name == "DURATION":
                current["duration"] = value.strip()
            elif name == "RRULE":
                current["rrule"] = _parse_rrule(value)
            elif name == "RECURRENCE-ID":
                try:
                    stamp, _ = _parse_stamp(value, params, tz)
                except ValueError:
                    pass
                else:
                    current["recurrence_id_src"] = stamp
                    current["recurrence_id"] = _to_local(stamp, tz)
            elif name in TEXT_PROPS:
                current[name.lower()] = unescape(value).strip()
    return events


RE_DURATION = re.compile(
    r"^(?P<sign>[+-])?P(?:(?P<w>\d+)W)?(?:(?P<d>\d+)D)?"
    r"(?:T(?:(?P<h>\d+)H)?(?:(?P<m>\d+)M)?(?:(?P<s>\d+)S)?)?$", re.I)


def _end_from_duration(event: dict, tz) -> None:
    """DTSTART + DURATION with no DTEND (RFC 5545 allows either). Without
    this the event had no end, and the calendar drew a 4 pm practice until
    midnight (prosecution 2026-10-06)."""
    if "dtend" in event or "dtstart_src" not in event or not event.get("duration"):
        return
    m = RE_DURATION.match(event["duration"])
    if not m or m.group("sign") == "-":
        return
    n = {k: int(v) for k, v in m.groupdict().items() if k != "sign" and v}
    delta = timedelta(weeks=n.get("w", 0), days=n.get("d", 0), hours=n.get("h", 0),
                      minutes=n.get("m", 0), seconds=n.get("s", 0))
    if not delta:
        return
    end = event["dtstart_src"] + delta
    event["dtend_src"] = end
    event["dtend"] = _to_local(end, tz)


# --------------------------------------------------------------------------
# Repeating events
# --------------------------------------------------------------------------

WEEKDAYS = {"MO": 0, "TU": 1, "WE": 2, "TH": 3, "FR": 4, "SA": 5, "SU": 6}
SUPPORTED_FREQ = {"DAILY", "WEEKLY", "MONTHLY", "YEARLY"}
# Parts this expander understands. A rule carrying anything else is not
# approximated — see the module docstring.
KNOWN_PARTS = {"FREQ", "INTERVAL", "COUNT", "UNTIL", "BYDAY", "BYMONTHDAY",
               "BYMONTH", "WKST"}
# A ceiling on the day-by-day walk. It exists so a malformed rule cannot spin,
# not to reject long series: a COUNT is counted from DTSTART, so a daily event
# begun in 2004 has to be walked from 2004, and 7,500 days (20 years) silently
# returned NOTHING for one. 40,000 days is 109 years, costs a few milliseconds,
# and hitting it now says so instead of returning an empty list.
MAX_STEPS = 40000


def _parse_rrule(value: str) -> dict:
    """RRULE text -> {part: value}. Unknown parts are KEPT, so `_supported`
    can see them and refuse the rule rather than quietly ignoring them."""
    out: dict = {}
    for piece in value.split(";"):
        key, _, val = piece.partition("=")
        key = key.strip().upper()
        if key:
            out[key] = val.strip()
    return out


def _supported(rule: dict) -> bool:
    """Is this a rule this module gets RIGHT? Not "can it parse it".

    Checked against python-dateutil over several thousand generated rules
    (2026-09-17). Three YEARLY families disagreed and are refused here rather
    than approximated, because a wrong date presented confidently is the one
    outcome this app may never produce (spec §5.10):

      * YEARLY with an ordinal BYDAY and no BYMONTH — RFC 5545 counts the
        ordinal over the whole YEAR ("the last Sunday of the year"), and this
        module counts within a month.
      * YEARLY with a plain BYDAY and no BYMONTH — expands over the year.
      * YEARLY with BYMONTHDAY and no BYMONTH — likewise ("the 13th of every
        month"), where this module would pin it to DTSTART's month.

    All three are rare in a calendar a person keeps by hand; the common ones
    (Thanksgiving as YEARLY;BYMONTH=11;BYDAY=4TH, a birthday, an anniversary)
    carry BYMONTH and are handled exactly.
    """
    freq = rule.get("FREQ", "").upper()
    if freq not in SUPPORTED_FREQ:
        return False
    if set(rule) - KNOWN_PARTS:
        return False
    if freq == "YEARLY" and not _ints(rule, "BYMONTH") \
            and (_byday(rule) or _ints(rule, "BYMONTHDAY")):
        return False
    # RFC 5545 §3.3.10: "BYMONTHDAY MUST NOT be specified when FREQ=WEEKLY".
    # A feed that writes one anyway is writing something with no agreed
    # meaning — implementations disagree about it, which is exactly the case
    # for saying so rather than picking one reading and sounding certain.
    if freq == "WEEKLY" and _ints(rule, "BYMONTHDAY"):
        return False
    return True


def _rule_until(rule: dict, tz):
    """UNTIL as written — a datetime keeps its time of day.

    Truncating it to a date includes one occurrence too many whenever UNTIL
    falls mid-day, which is how Google writes it (`UNTIL=20261030T060000Z`).
    """
    raw = rule.get("UNTIL")
    if not raw:
        return None
    try:
        stamp, _ = _parse_stamp(raw, {}, tz)
    except ValueError:
        return None
    return stamp


def _byday(rule: dict) -> list[tuple[int, int]]:
    """BYDAY -> [(ordinal, weekday)]; ordinal 0 means "every"."""
    out = []
    for token in (rule.get("BYDAY") or "").split(","):
        token = token.strip().upper()
        match = re.fullmatch(r"([+-]?\d+)?([A-Z]{2})", token)
        if match and match.group(2) in WEEKDAYS:
            out.append((int(match.group(1) or 0), WEEKDAYS[match.group(2)]))
    return out


def _ints(rule: dict, key: str) -> list[int]:
    out = []
    for token in (rule.get(key) or "").split(","):
        token = token.strip()
        if re.fullmatch(r"[+-]?\d+", token):
            out.append(int(token))
    return out


def _nth_weekday_in_month(day: date, weekday: int) -> tuple[int, int]:
    """(position from the start, position from the end) of `day` among the
    days of its month sharing `weekday`. (2, -3) for the 2nd of five."""
    first = day.replace(day=1)
    offset = (weekday - first.weekday()) % 7
    first_hit = first + timedelta(days=offset)
    forward = (day - first_hit).days // 7 + 1
    total = 1
    probe = first_hit
    while True:
        nxt = probe + timedelta(days=7)
        if nxt.month != day.month:
            break
        probe, total = nxt, total + 1
    return forward, forward - total - 1


def _matches(day: date, start: date, rule: dict, freq: str, interval: int) -> bool:
    """Does `day` fall on this rule's pattern? Frequency and interval decide
    which period it may fall in; the BY* parts decide where inside it."""
    days = _byday(rule)
    monthdays = _ints(rule, "BYMONTHDAY")
    months = _ints(rule, "BYMONTH")
    if months and day.month not in months:
        return False

    if freq == "DAILY":
        if (day - start).days % interval:
            return False
        if days and day.weekday() not in {w for _, w in days}:
            return False
        return _monthday_matches(day, monthdays)

    if freq == "WEEKLY":
        wkst = WEEKDAYS.get((rule.get("WKST") or "MO").upper(), 0)
        # Interval counts WEEKS, so both dates are pulled back to the start of
        # their own week before the difference is taken — otherwise a
        # fortnightly event drifts whenever the series starts mid-week.
        week_of = lambda d: d - timedelta(days=(d.weekday() - wkst) % 7)
        if ((week_of(day) - week_of(start)).days // 7) % interval:
            return False
        wanted = {w for _, w in days} or {start.weekday()}
        return day.weekday() in wanted

    months_apart = (day.year - start.year) * 12 + (day.month - start.month)
    if freq == "MONTHLY":
        if months_apart % interval:
            return False
    else:                                        # YEARLY
        if (day.year - start.year) % interval:
            return False
        if not months and day.month != start.month:
            return False

    if days:
        # BYDAY and BYMONTHDAY together INTERSECT — "Friday the 13th" is
        # FREQ=MONTHLY;BYDAY=FR;BYMONTHDAY=13, and returning on the weekday
        # alone turns that into every Friday.
        if not _monthday_matches(day, monthdays):
            return False
        for ordinal, weekday in days:
            if day.weekday() != weekday:
                continue
            if not ordinal:
                return True
            forward, backward = _nth_weekday_in_month(day, weekday)
            if ordinal == forward or ordinal == backward:
                return True
        return False
    if monthdays:
        return _monthday_matches(day, monthdays)
    return day.day == start.day


def _monthday_matches(day: date, monthdays: list[int]) -> bool:
    """BYMONTHDAY, counting from either end. -1 is the last day of the month,
    which is how "the last of the month" is written and is not the same date
    twice in a row."""
    if not monthdays:
        return True
    last = _month_length(day)
    return day.day in monthdays or (day.day - last - 1) in monthdays


def _month_length(day: date) -> int:
    nxt = day.replace(day=28) + timedelta(days=4)
    return (nxt.replace(day=1) - timedelta(days=1)).day


def _as_date(value) -> date | None:
    if isinstance(value, datetime):
        return value.date()
    return value if isinstance(value, date) else None


def occurrence_dates(event: dict, window_start: date, window_end: date,
                     tz=None) -> tuple[list[date], bool]:
    """Every date this series lands on inside the window, IN THE RULE'S OWN
    TIMEZONE.

    Returns (dates, understood). `understood` is False when the rule uses
    something this module does not implement, or when the walk hit its own
    step ceiling before finishing — the caller then has one occurrence and a
    reason to say so, rather than a guess or a silent gap.

    The window is widened by a day at each end because the caller filters on
    the LOCAL date: an event at 11 pm in New York is the next day in Phoenix,
    and the day either side is what keeps it from falling off the edge.
    """
    tz = tz or timezones.zone()
    src = event.get("dtstart_src", event.get("dtstart"))
    start = _as_date(src)
    if start is None:
        return [], True
    rule = event.get("rrule")
    if not rule:
        return [start], True
    if not _supported(rule):
        return [start], False

    freq = rule["FREQ"].upper()
    interval = max(1, (_ints(rule, "INTERVAL") or [1])[0])
    count = (_ints(rule, "COUNT") or [0])[0]
    until = _rule_until(rule, tz)
    excluded = {d for d in (_as_date(x) for x in
                            event.get("exdate_src", event.get("exdate")) or []) if d}

    window_start = window_start - timedelta(days=1)
    last = window_end + timedelta(days=1)
    until_date = _as_date(until) if until is not None else None
    if until_date is not None and until_date < last:
        last = until_date
    # UNTIL is a moment, not a day. `UNTIL=20261030T060000Z` on a 9 am series
    # ends BEFORE that morning's occurrence, and stopping at the date alone
    # adds one that the calendar does not have.
    clock = src.timetz() if isinstance(src, datetime) else None

    # COUNT is counted from the series' START, not from the window, so the
    # walk has to begin there whenever there is one to honour. Without a COUNT
    # it can begin at the window: `_matches` is absolute with respect to
    # `start` for every frequency, so skipping the intervening years changes
    # nothing (checked against python-dateutil, 2026-09-17).
    cursor = start if count else max(start, window_start)

    hits: list[date] = []
    seen = 0
    steps = 0
    truncated = False
    while cursor <= last:
        if steps >= MAX_STEPS:
            # A ceiling that returns quietly is the silent gap this app is
            # built not to have. Say the rule was not fully read; the caller
            # turns that into a visible note.
            truncated = True
            break
        steps += 1
        if _matches(cursor, start, rule, freq, interval):
            if until is not None and isinstance(until, datetime) and clock is not None \
                    and datetime.combine(cursor, clock) > until:
                break
            seen += 1
            if count and seen > count:
                break
            if cursor >= window_start and cursor not in excluded:
                hits.append(cursor)
        cursor += timedelta(days=1)
    if truncated:
        return ([start] if window_start <= start <= last else []), False
    for extra in (_as_date(x) for x in
                  event.get("rdate_src", event.get("rdate")) or []):
        if extra and window_start <= extra <= window_end + timedelta(days=1) \
                and extra not in excluded:
            hits.append(extra)
    return sorted(set(hits)), True


def expand(events: list[dict], window_start: date, window_end: date,
           tz=None) -> list[dict]:
    """Parsed VEVENTs -> one dict per real occurrence inside the window.

    Each occurrence is a shallow copy of its master with `dtstart`/`dtend`
    moved onto that date and the clock time kept IN THE RULE'S OWN ZONE, then
    converted to local — so a New York practice at 7 pm stays 7 pm there
    across that zone's daylight-saving change, rather than sliding an hour in
    Phoenix, which has none. Also carries `occurrence_of` (the series UID)
    and, when the rule was not fully understood, `recurrence_unsupported`.

    Overrides (RECURRENCE-ID) replace the generated occurrence for their date;
    a cancelled one removes it.
    """
    tz = tz or timezones.zone()
    overrides: dict[tuple[str, str], dict] = {}
    masters = []
    for event in events:
        moment = _as_date(event.get("recurrence_id_src", event.get("recurrence_id")))
        if moment is not None:
            overrides[(event.get("uid") or "", moment.isoformat())] = event
        else:
            masters.append(event)

    out: list[dict] = []
    for master in masters:
        dates, understood = occurrence_dates(master, window_start, window_end, tz)
        uid = master.get("uid") or ""
        repeats = bool(master.get("rrule"))
        for when in dates:
            override = overrides.pop((uid, when.isoformat()), None)
            source = override if override is not None else master
            if (source.get("status") or "").upper() == "CANCELLED":
                continue
            copy = dict(source)
            for key in ("rrule", "exdate", "exdate_src", "rdate", "rdate_src"):
                copy.pop(key, None)
            if override is None and repeats:
                moved = _move_to(master.get("dtstart_src", master.get("dtstart")), when)
                copy["dtstart_src"] = moved
                copy["dtstart"] = _to_local(moved, tz)
                moved_end = _move_to(master.get("dtend_src", master.get("dtend")),
                                     when + _span(master))
                copy["dtend_src"] = moved_end
                copy["dtend"] = _to_local(moved_end, tz) if moved_end is not None else None
                copy["occurrence_of"] = uid
                if not understood:
                    copy["recurrence_unsupported"] = True
            elif not understood:
                copy["recurrence_unsupported"] = True
            # The window is decided on the LOCAL date, because that is the day
            # the board draws it on.
            local_day = _as_date(copy.get("dtstart"))
            if local_day is None or not (window_start <= local_day <= window_end):
                continue
            out.append(copy)
    # An override for a date the rule never produced (a meeting moved to a day
    # outside the pattern) is still a real event, so it is kept.
    for override in overrides.values():
        when = _as_date(override.get("dtstart"))
        if when and window_start <= when <= window_end \
                and (override.get("status") or "").upper() != "CANCELLED":
            out.append(dict(override))
    return out


def _span(master: dict):
    """How many days the master event covers, so a multi-day occurrence keeps
    its length when it is moved."""
    start, end = _as_date(master.get("dtstart")), _as_date(master.get("dtend"))
    return timedelta(days=(end - start).days) if start and end else timedelta()


def _move_to(stamp, when: date):
    """The same clock time, on another date. Dates stay dates."""
    if isinstance(stamp, datetime):
        return stamp.replace(year=when.year, month=when.month, day=when.day)
    if isinstance(stamp, date):
        return when
    return stamp
