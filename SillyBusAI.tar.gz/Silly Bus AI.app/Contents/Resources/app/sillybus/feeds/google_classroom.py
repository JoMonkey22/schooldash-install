"""Visible Google Classroom coursework imported by the Chrome extension.

Snapshots are partial: later visits merge by stable assignment URL, so reading
one class cannot erase another. Localized due labels stay visible but undated
unless the page supplied an ISO date. No API/model credentials are required.
"""
import json
import re
from datetime import datetime, timedelta, timezone
from urllib.parse import urlsplit

from sillybus import config, models, paths
from sillybus.feeds.albert import match_course


def handoff_path():
    return paths.cache_dir() / 'googleclassroom.json'


def merge_handoff(data):
    """Validate and merge a partial visit; return the exact metadata to persist."""
    previous = {}
    try:
        previous = json.loads(handoff_path().read_text())
    except (OSError, ValueError):
        pass
    if not isinstance(previous, dict):
        previous = {}
    current = datetime.now(timezone.utc)
    try:
        observed = datetime.fromisoformat(data.get("read_at") or "")
        if observed.tzinfo is None or observed > current + timedelta(minutes=5):
            observed = current
    except (TypeError, ValueError):
        observed = current
    now = observed.isoformat()
    rows = {row['url']: row for row in previous.get('assignments', [])
            if isinstance(row, dict) and isinstance(row.get('url'), str)}
    for row in data.get('assignments', []):
        if not isinstance(row, dict):
            continue
        url = str(row.get('url') or '')
        parsed = urlsplit(url)
        if parsed.scheme != 'https' or parsed.netloc != 'classroom.google.com':
            continue
        if not re.match(r'^/c/[^/]+/a/[^/]+(?:/|$)', parsed.path):
            continue
        title = str(row.get('title') or '').strip()
        if not title:
            continue
        fields = {'id', 'subject', 'title', 'due', 'due_text', 'status', 'url'}
        rows[url] = {key: str(value)[:1000] if value is not None else None
                     for key, value in row.items() if key in fields}
        rows[url]['read_at'] = now
    # Bound storage; per-assignment timestamps prevent one fresh class from
    # making coursework from an unvisited class appear freshly read.
    return {'read_at': now, 'partial': True, 'assignments': list(rows.values())[-5000:]}


def items(known_courses=None, now=None):
    if not (config.load().get('sources') or {}).get('google_classroom', True):
        return [], None
    try:
        data = json.loads(handoff_path().read_text())
    except (OSError, ValueError):
        return [], None
    if not isinstance(data, dict):
        return [], {"code": "google_classroom", "message": "Google Classroom handoff is unreadable", "fix": "Link the class page again"}
    now = now or datetime.now(timezone.utc)
    result = []
    for row in data.get('assignments', []):
        try:
            read_at = datetime.fromisoformat(row['read_at'])
            if now - read_at > timedelta(hours=36):
                continue
            key, course = match_course(row.get('subject') or '', known_courses or {})
            raw = row.get('due') or ''
            try:
                when = datetime.fromisoformat(raw) if raw else None
            except ValueError:
                when = None
            date_only = len(raw) == 10
            note = ('due date shown on Google Classroom' if when else
                    f"Google Classroom shows: {row['due_text']} (date not resolved)" if row.get('due_text') else
                    'Google Classroom did not show a readable due date on this page')
            done = (row.get('status') or '').lower() in {'turned in', 'returned', 'graded', 'done'}
            result.append(models.Item(source='google_classroom', course_key=key,
                course=course or row.get('subject') or '(no course)', title=row['title'][:110],
                detail=' · '.join(filter(None, [row.get('subject'), row.get('due_text'), row.get('status'),
                       'Visible coursework only; other pages may contain more assignments'])),
                kind='Google Classroom assignment', due=when.isoformat() if when and not date_only else None,
                due_date=when.date().isoformat() if when else None, all_day=date_only,
                date_note=note, confidence='high' if when else 'medium', extractor='canvas_stated',
                submitted=True if done else None, url=row['url'],
                links=[models.Link(url=row['url'], text='Open in Google Classroom', kind='google_classroom')]).finalize())
        except (KeyError, TypeError, ValueError):
            continue
    return result, None
