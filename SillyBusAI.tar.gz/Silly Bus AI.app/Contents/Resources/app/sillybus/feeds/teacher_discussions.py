"""Teacher-only root exercises on a source-linked recurring discussion board.

Never use a board grade, term deadline or student reply as per-post evidence.
"""
from datetime import date, datetime, timedelta
import re
from bs4 import BeautifulSoup
from sillybus import timezones, duedates
from sillybus.docs.prose import _date_in

def candidates(entries, teacher_ids, today, zone=None):
    zone=zone or timezones.zone()
    if not isinstance(entries,list): return []
    teachers={x for x in teacher_ids if type(x) is int and x>0}
    out=[]
    for e in entries[:100]:
        if not isinstance(e,dict): continue
        if type(e.get('id')) is not int or e['id']<=0: continue
        if type(e.get('user_id')) is not int: continue
        if e.get('parent_id') is not None or e.get('user_id') not in teachers: continue
        if e.get('deleted') or not isinstance(e.get('message'),str): continue
        try:
            stamp=datetime.fromisoformat(e['created_at'].replace('Z','+00:00'))
            if stamp.tzinfo is None: continue
            posted=stamp.astimezone(zone).date()
        except (ValueError,KeyError,TypeError): continue
        if not today-timedelta(days=21)<=posted<=today: continue
        soup=BeautifulSoup(e['message'],'html.parser')
        for node in soup(['script','style']):node.decompose()
        paragraph_nodes=soup.find_all(['p','h1','h2','h3'])
        paragraphs=[p.get_text(' ',strip=True) for p in paragraph_nodes]
        if not paragraphs or not re.search(r'\bDaily Warm Up(?:[.:]|$)',paragraphs[0],re.I):continue
        text=soup.get_text(' ',strip=True)
        if re.search(r'\bno (?:post|reply)(?:ing)? today\b',text,re.I):continue
        if not re.search(r'\b(?:post to this board|reply here with|then post here)\b',text,re.I):continue
        printed=_date_in(re.split(r'Daily Warm Up',paragraphs[0],maxsplit=1,flags=re.I)[0],posted.year)
        conflict=printed is not None and printed != posted
        own_deadlines=[]
        for paragraph in paragraph_nodes[1:]:
            if paragraph.find_parent('blockquote') is not None:continue
            para=paragraph.get_text(' ',strip=True)
            if re.match(r'^This (?:warm[ -]?up|post) is due\b',para,re.I):
                found=duedates.best(para,posted,anchor=printed or posted)
                if found: own_deadlines.append(found)
        unique={(x.due_date,x.due_time) for x in own_deadlines}
        stated=next(iter(unique)) if len(unique)==1 and not conflict else (None,None)
        # Entry identity is separate from its display title and source date.
        # Never read recent_replies or infer completion from a board grade.
        named=re.search(r'Daily Warm Up:\s*(.{3,100}?)[.]?$',paragraphs[0],re.I)
        topic=named[1].rstrip('.').strip() if named else None
        optional=bool(re.search(r'\boptional\b',paragraphs[0],re.I) or re.search(r'This (?:warm[ -]?up|post) is optional\b',text,re.I))
        out.append({'topic':topic,'optional':optional,'entry_id':e['id'],'assigned_date':None if conflict else posted.isoformat(),
                    'date_conflict':conflict,
                    'instructions':text,'due_date':stated[0],'due_time':stated[1],'submitted':None,
                    'deadline_conflict':len(unique)>1,'deadline_relative':bool(stated[0] and any(x.relative for x in own_deadlines)),
                    'evidence':'Board deadline/grade not inherited; personal completion unknown.'})
    return out


def collect_roots(context, host, course_id, topic_id, today, zone=None):
    """Verify course teacher IDs, then read at most two pages of root entries."""
    from urllib.parse import urlsplit
    zone=zone or timezones.zone()
    try:
        origin=urlsplit(host)
        if (re.search(r'\s',host) or origin.scheme!='https' or not origin.hostname
                or origin.username or origin.password or origin.path not in ('','/')
                or origin.query or origin.fragment
                or not all(re.fullmatch(r'[1-9][0-9]*',str(x)) for x in (course_id,topic_id))):
            return {'status':'invalid_origin_or_ids','items':[]}
        base=f'{host.rstrip("/")}/api/v1/courses/{course_id}'
        def read(url):
            response=context.request.get(url,timeout=15000)
            if not response.ok:return None,''
            return response.json(),response.headers.get('link','')
        teachers,link=read(base+'/users?enrollment_type%5B%5D=teacher&per_page=100')
        if not isinstance(teachers,list) or len(teachers)>100 or 'rel="next"' in link:
            return {'status':'teacher_identity_unavailable_or_bounded','items':[]}
        identities={x['id'] for x in teachers if isinstance(x,dict) and type(x.get('id')) is int and x['id']>0}
        if not identities:return {'status':'teacher_identity_unavailable','items':[]}
        topic,_=read(base+f'/discussion_topics/{topic_id}')
        if (not isinstance(topic,dict) or type(topic.get('id')) is not int or topic['id']!=int(topic_id)
                or ' '.join(str(topic.get('title') or '').lower().split())!='warm up board'
                or topic.get('is_announcement') or topic.get('locked_for_user') is True):
            return {'status':'board_unavailable_or_unrecognized','items':[]}
        floor=today-timedelta(days=21);seen={};status='bounded_limit'
        for page in (1,2):
            rows,link=read(base+f'/discussion_topics/{topic_id}/entries?per_page=100&page={page}')
            if not isinstance(rows,list):
                return {'status':'entry_access_unavailable','items':list(seen.values())}
            if len(rows)>100:return {'status':'bounded_limit','items':list(seen.values())}
            for row in candidates(rows,identities,today,zone):
                old=seen.get(row['entry_id'])
                if old is None:seen[row['entry_id']]=row
                elif any(old[k]!=row[k] for k in ('instructions','assigned_date','due_date','due_time')):
                    old.update(assigned_date=None,due_date=None,due_time=None,source_conflict=True)
            stamps=[]
            for row in rows:
                try:
                    stamp=datetime.fromisoformat(row['created_at'].replace('Z','+00:00'))
                    if stamp.tzinfo is None:raise ValueError('naive source timestamp')
                    stamps.append(stamp)
                except (KeyError,TypeError,ValueError):
                    stamps=[];break
            crossed=(bool(stamps) and stamps==sorted(stamps,reverse=True)
                     and stamps[-1].astimezone(zone).date()<floor)
            # Canvas may cap this endpoint at50 despite per_page100. One extra
            # bounded read avoids treating50 recent roots as complete without a Link header.
            if crossed or not rows or ('rel="next"' not in link and len(rows)<50):
                status='complete_bounded_range';break
        return {'status':status,'items':list(seen.values())}
    except Exception:
        return {'status':'teacher_roots_unavailable','items':[]}


def _board_identity(url):
    from urllib.parse import urlsplit
    if not isinstance(url,str) or re.search(r'\s',url):return None
    try:
        p=urlsplit(url);route=re.fullmatch(r'/courses/([1-9][0-9]*)/discussion_topics/([1-9][0-9]*)/?',p.path)
        if (p.scheme!='https' or not p.hostname or p.username or p.password or p.query
                or not route or (p.fragment and not re.fullmatch(r'entry-[1-9][0-9]*',p.fragment))):return None
        return (p.netloc.lower(),*route.groups())
    except ValueError:return None


def prepare_board(html, profile, host):
    """Only a uniquely source-linked recurring warm-up board is eligible."""
    from urllib.parse import urlsplit
    from sillybus.docs import prose,links
    if len(html)>2_000_000:return None
    cid=str(profile.get('canvas_course_id') or '')
    if not re.fullmatch(r'[1-9][0-9]*',cid):return None
    soup=BeautifulSoup(html,'lxml')
    # Most daily teachers put these paragraphs inside table cells; the prose
    # reader intentionally skips whole tables, so inspect their leaf paragraphs.
    nodes=[n for n in soup.find_all(['p','li','h1','h2','h3'])
           if n.name!='li' or not n.find(['p','li'])]
    if len(nodes)>5000:return None
    found=set()
    for node in nodes:
        text=prose._clean(node.get_text(' ',strip=True))
        if not re.match(r'^Daily Warm Up\b',text,re.I):continue
        for link in links.extract_links(node):
            board=_board_identity(link.url)
            if (board and board[:2]==(urlsplit(host).netloc.lower(),cid)
                    and re.search(r'\bWarm Up Board\s*$',link.text,re.I)):
                found.add(board[2])
    return next(iter(found)) if len(found)==1 else None


def _topic(text):return ' '.join(re.findall(r'[a-z0-9]+',text.lower()))


def make_items(result, profile, host, course_id, topic_id):
    from sillybus.models import Item,Link
    out=[]
    for row in result['items']:
        url=f'{host.rstrip("/")}/courses/{course_id}/discussion_topics/{topic_id}#entry-{row["entry_id"]}'
        assigned=row['assigned_date'];topic=row.get('topic')
        label=(datetime.fromisoformat(assigned).strftime('%b %d') if assigned else 'date needs confirmation')
        title=('Optional ' if row.get('optional') else '')+'Daily Warm Up'+(f': {topic}' if topic else '')+f' — {label}'
        due=None
        if row['due_date'] and row['due_time']:
            due=datetime.fromisoformat(f'{row["due_date"]}T{row["due_time"]}').replace(tzinfo=timezones.zone()).isoformat()
        note='Teacher-authored root post; board deadline/grade not inherited; personal completion unknown. '
        if row['due_date']:
            note+=(f'Individual deadline {row["due_date"]} counted from this post source day (relative wording)'
                   if row.get('deadline_relative') else f'Individual deadline {row["due_date"]} stated in this post')
            if row['due_time']:note+=f'; deadline time {row["due_time"]} from the line itself'
            else:note+='; exact deadline clock unstated'
        else:note+='Individual deadline/clock unconfirmed; any before-leaving wording remains in instructions.'
        if row.get('date_conflict') or row.get('deadline_conflict') or row.get('source_conflict'):
            note+=' Conflicting source date/deadline evidence needs confirmation.'
        flags=['teacher_discussion_entry','daily_discussion','stated_category']
        if topic:flags.append('teacher_topic:'+_topic(topic))
        if not row['due_date']:flags.append('deadline_unstated')
        else:flags.append('teacher_own_deadline')
        item=Item(source='canvas_page',course_key=profile.course_key,course=profile.get('display_name') or profile.course_key,
                  title=title,detail=row['instructions'],raw_cell=row['instructions'],kind='teacher discussion post',
                  category='discussion',assigned_date=assigned,due_date=row['due_date'],due=due,
                  all_day=not bool(due),date_note=note,extractor=('relative_to_posted' if row.get('deadline_relative') else 'absolute') if row['due_date'] else 'unresolved',
                  submitted=None,url=url,links=[Link(url,'Teacher warm-up post','canvas')],flags=flags).finalize()
        out.append(item)
    return out


def _urls(item):
    return [item.url]+[l.url if hasattr(l,'url') else l.get('url') for l in item.links]


def enrich_existing(existing, children):
    """Exact root link, or unique named topic+board+day; never date alone."""
    from sillybus.models import discussion_entry_identity
    matches={}
    for n,child in enumerate(children):
        root=discussion_entry_identity(child.url);board=root[:3]
        topic=next((f.partition(':')[2] for f in child.flags if f.startswith('teacher_topic:')),None)
        found=[]
        for i,item in enumerate(existing):
            if item.course_key!=child.course_key or 'daily_discussion' not in item.flags:continue
            if item.title.lower().startswith('optional ')!=child.title.lower().startswith('optional '):continue
            urls=_urls(item)
            direct=any(discussion_entry_identity(u)==root for u in urls)
            named=False
            if topic and child.assigned_date and item.assigned_date==child.assigned_date:
                title=re.sub(r' — class (?:\d{4}-\d{2}-\d{2}|\d+)$','',item.title,flags=re.I)
                m=re.fullmatch(r'(?:Optional )?Daily Warm Up:\s*(.{3,100})',title,re.I)
                named=bool(m and _topic(m[1])==topic and any(_board_identity(u)==board for u in urls))
            if direct or named:found.append(i)
        matches[n]=found
    remaining=[]
    for n,child in enumerate(children):
        found=matches[n]
        if len(found)!=1 or sum(found[0] in v for v in matches.values())!=1:
            remaining.append(child);continue
        item=existing[found[0]]
        marker='\nTeacher post requirements:\n'
        if child.detail not in item.detail:item.detail+=marker+child.detail
        seen=set(_urls(item))
        item.links.extend(l for l in child.links if l.url not in seen)
        if 'teacher_discussion_evidence' not in item.flags:item.flags.append('teacher_discussion_evidence')
        if child.due_date:
            if 'teacher_own_deadline' not in item.flags:item.flags.append('teacher_own_deadline')
            item.due_date=child.due_date;item.due=child.due;item.all_day=child.all_day
            item.extractor=child.extractor;item.date_note=child.date_note
        # Keep the existing document identity and personal done state.
    return remaining
