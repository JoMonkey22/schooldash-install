"""Reading the course homepage itself, on every refresh.

The pipeline had two ways to learn about work: the Canvas planner (assignments
and quizzes the teacher created as Canvas objects) and the Google Doc embedded
on the course homepage. A teacher who simply types the week's work onto the
Canvas page was invisible to both — [MEASURED] 2026-09-01, Spanish 1 listed a
quiz that day and a test two days later on its homepage and the board showed
nothing for that class at all.

So this stage reads, per course, every refresh:

  - the **front page** — the homepage itself;
  - **wiki pages whose title reads like a schedule** ("Weekly Assignments",
    "Daily Agenda", "Homework"), because some teachers keep the homepage as an
    index and the real page one click away;
  - **recent announcements**, which is where work a teacher said out loud gets
    written down.

Extraction is `docs/prose.py` for text and the existing `docs/items.py` for a
page that holds a real table, so a table pasted into Canvas is read by the
machinery already proven against the teachers' docs.

Two things keep the cost down. The page list carries `updated_at`, so a page
that has not been edited is never fetched again — its extracted items are
reused from `doc_state`, keyed on a synthetic `page:<course>:<slug>` id. And
only courses the student is actually taking now are scanned.

Items are trimmed to the same window the rest of the refresh uses, because a
homepage keeps the whole term on it and August's finished homework is not work.
The count trimmed is reported, never silently dropped.
"""

import hashlib
import json
import re
from datetime import date, timedelta

from sillybus import config, db, timezones
from sillybus.docs import fingerprint
from sillybus.docs import prose
from sillybus.logging_setup import get
from sillybus.models import Item, Profile

log = get("canvas_pages")

# A page worth opening. The front page is always read; these are the extra ones.
# Whole words, with the plurals and "-ly" a title actually uses. Without the
# boundaries "Community" matched "unit", "Planets" matched "plan" and "Duet"
# matched "due", and each one took one of the four slots below from a real
# schedule page (prosecution round 5, 2026-10-07).
SCHEDULE_TITLE = re.compile(
    r"\b(?:week(?:s|ly)?|assignments?|homeworks?|agendas?|schedules?|"
    r"calendars?|tareas?|deberes|daily|due|syllabus|units?|plans?|planner)\b",
    re.I)
MAX_EXTRA_PAGES = 4
# How far the page list is followed. 100 a page (Canvas's ceiling) and five
# pages is 500 wiki pages — more than any course here has, and still bounded.
PAGE_LIST_PER_PAGE = 100
PAGE_LIST_MAX_PAGES = 5
NEXT_LINK = re.compile(r'<([^>]+)>;\s*rel="next"')
ANNOUNCEMENT_DAYS = 21
MAX_ANNOUNCEMENTS = 12


# One definition, shared with the doc pipeline (docs/fingerprint.py): both
# caches have to invalidate when the code that reads a document changes.
EXTRACTOR_VERSION = fingerprint.extraction_version()
# One definition, shared with the doc pipeline: both read prose, and neither
# source says anything about what was handed in. See docs/prose.py.
NO_SUBMISSION_GRACE_DAYS = prose.NO_SUBMISSION_GRACE_DAYS


def _get_json(context, url: str, timeout: int = 45_000):
    from sillybus.browser import strip_while1
    try:
        response = context.request.get(url, timeout=timeout)
    except Exception as exc:  # noqa: BLE001 — one page, never the run
        log.debug("GET %s failed: %s", url, exc)
        return None
    if not response.ok:
        return None
    try:
        return json.loads(strip_while1(response.text()))
    except ValueError:
        return None


def get_all_pages(context, url: str, max_pages: int, timeout: int = 45_000) -> list:
    """Every page of a Canvas list, following Link rel="next", at most
    `max_pages` requests. What came back before a failure is kept: a list cut
    short is still better than none, and the caller already treats an empty
    one as "nothing to read"."""
    from sillybus.browser import strip_while1
    out: list = []
    pages = 0
    while url and pages < max_pages:
        pages += 1
        try:
            response = context.request.get(url, timeout=timeout)
        except Exception as exc:  # noqa: BLE001 — one list, never the run
            log.debug("GET %s failed: %s", url, exc)
            break
        if not response.ok:
            break
        try:
            data = json.loads(strip_while1(response.text()))
        except ValueError:
            break
        if not isinstance(data, list):
            break
        out.extend(data)
        headers = getattr(response, "headers", None) or {}
        found = NEXT_LINK.search(headers.get("link", "") or headers.get("Link", "") or "")
        url = found.group(1) if found else None
    return out


def current_courses(context, meetings) -> list[dict]:
    """The courses the student is taking NOW.

    The full /courses list carries finished summer sessions; the dashboard
    cards hide five real courses ([MEASURED] 2026-08-26, 9 cards for 14
    courses). Neither alone is right, so: a course counts if it has meetings in
    the class feed or a card on the dashboard.
    """
    from sillybus import courses as courses_mod
    from sillybus.feeds import canvas as canvas_mod

    everything = courses_mod.canvas_courses(context)
    feed_keys = {m.course_key for m in getattr(meetings, "meetings", [])}
    try:
        card_ids = {c.canvas_course_id for c in canvas_mod.dashboard_courses(context)}
    except Exception:  # noqa: BLE001 — cards are a nicety, the feed is the truth
        card_ids = set()
    current = [c for c in everything
               if c["course_key"] in feed_keys or c.get("canvas_key") in feed_keys
               or c["canvas_course_id"] in card_ids]
    log.info("pages: %d of %d Canvas course(s) are current",
             len(current), len(everything))
    return current or everything


def page_list(context, host: str, course_id: str) -> list[dict]:
    """Every wiki page in the course, most recently edited first.

    [prosecution round 5, 2026-10-07] This asked for one page of 40 in
    Canvas's default order — alphabetical — and the caller took the first
    four schedule-looking titles. So "Week 1".."Week 4" were read on every
    refresh and this week's "Week 7" never was, and page 41 onwards did not
    exist. Canvas is asked to sort by `updated_at`, the Link header is
    followed (bounded), and the list is sorted again here because a captured
    or older response may not have honoured the sort.
    """
    data = get_all_pages(
        context,
        f"{host}/api/v1/courses/{course_id}/pages?sort=updated_at&order=desc"
        f"&per_page={PAGE_LIST_PER_PAGE}",
        PAGE_LIST_MAX_PAGES)
    out = []
    for page in data:
        if not page.get("url"):
            continue
        out.append({"slug": page["url"], "title": page.get("title") or page["url"],
                    "front_page": bool(page.get("front_page")),
                    "updated_at": page.get("updated_at") or "",
                    "html_url": page.get("html_url") or ""})
    out.sort(key=lambda p: p["updated_at"], reverse=True)
    return out


def page_body(context, host: str, course_id: str, slug: str) -> tuple[str, str]:
    data = _get_json(context, f"{host}/api/v1/courses/{course_id}/pages/{slug}")
    if not isinstance(data, dict):
        return "", ""
    return data.get("body") or "", data.get("updated_at") or ""


def front_page(context, host: str, course_id: str) -> tuple[str, str, str]:
    data = _get_json(context, f"{host}/api/v1/courses/{course_id}/front_page")
    if not isinstance(data, dict):
        return "", "", ""
    return (data.get("body") or "", data.get("updated_at") or "",
            data.get("title") or "")


def _local_day(stamp: str | None) -> str:
    """A Canvas timestamp as the school's calendar day. Slicing the UTC stamp
    dated an evening announcement a day late, and every relative date in it
    moved with it: Biology's "due wednesday at midnight", posted on a Tuesday
    evening, landed on the NEXT Wednesday ([MEASURED] 2026-10-07, prosecution
    round 2 — on the board as Oct 14 instead of Oct 7)."""
    if not stamp:
        return ""
    if len(stamp) == 10:
        return stamp                      # already a plain date (todo_date)
    try:
        return timezones.to_local(stamp).date().isoformat()
    except Exception:                     # noqa: BLE001
        return stamp[:10]


def recent_announcements(context, host: str, course_id: str, today: date) -> list[dict]:
    since = (today - timedelta(days=ANNOUNCEMENT_DAYS)).isoformat()
    data = _get_json(
        context,
        f"{host}/api/v1/announcements?context_codes[]=course_{course_id}"
        f"&start_date={since}&end_date={(today + timedelta(days=1)).isoformat()}"
        f"&per_page={MAX_ANNOUNCEMENTS}")
    out = []
    for entry in data if isinstance(data, list) else []:
        posted = _local_day(entry.get("posted_at") or entry.get("created_at"))
        if not posted:
            continue
        out.append({"id": str(entry.get("id") or ""), "title": entry.get("title") or "",
                    "message": entry.get("message") or "", "posted": posted,
                    "url": entry.get("html_url") or ""})
    return out


def recent_discussions(context, host: str, course_id: str,
                       today: date) -> list[dict]:
    """Discussion topics that are neither announcements nor graded work.

    [MEASURED] 2026-09-03, from his real Canvas: Honors English has "Arguable
    claims vs summaries (period 5)", whose body reads "Select 3 movies or
    stories that you know well and create a summary and arguable claim for
    each = 15 points". Fifteen points of homework. It is not graded, so there
    is no assignment behind it, and Canvas's planner did not return it — so it
    reached the board through nothing at all. *"sometimes teachers will post
    stuff in disscutions"*, and he is right.

    Two kinds are deliberately skipped here, because they arrive better
    elsewhere:

      * **announcements** — `/api/v1/announcements` already reads them, and a
        topic fetched twice becomes an item twice.
      * **graded topics** — they have an assignment with a real due date and a
        submitted state, which the assignments reader uses. His AI Frontiers
        "Warm Up Board" and "Ethics Board" are both graded, and both are
        correctly absent from the board because they are already handed in.

    What is left is exactly the gap.
    """
    data = _get_json(
        context,
        f"{host}/api/v1/courses/{course_id}/discussion_topics"
        f"?per_page={MAX_ANNOUNCEMENTS}")
    floor = (today - timedelta(days=ANNOUNCEMENT_DAYS)).isoformat()
    out = []
    for entry in data if isinstance(data, list) else []:
        if entry.get("is_announcement"):
            continue
        if (entry.get("assignment") or {}).get("id"):
            continue
        # Two different days, kept apart (prosecution round 5, 2026-10-07).
        # `posted` is when the words were WRITTEN, and every relative phrase
        # in them ("due Wednesday") is counted from it. `todo_date` is the
        # day the teacher wants it done, which passing in as `posted` moved a
        # Monday "due Wednesday" to the Wednesday after the to-do date. The
        # to-do date only decides whether the topic is recent enough to read.
        posted = _local_day(entry.get("posted_at") or entry.get("created_at"))
        recent = _local_day(entry.get("todo_date")) or posted
        if not posted or not recent or recent < floor:
            continue
        out.append({"id": str(entry.get("id") or ""),
                    "title": entry.get("title") or "",
                    "message": entry.get("message") or "",
                    "posted": posted,
                    "url": entry.get("html_url") or ""})
    return out


def _has_table(html: str) -> bool:
    return bool(re.search(r"<table", html or "", re.I))


def _synthetic_profile(course_key: str, display: str, course_raw: str) -> Profile:
    """A default profile for a page nobody has profiled.

    The course's own profile describes the teacher's DOC — its columns and
    quirks — and pointing that at a different document would apply the wrong
    column rules. So a page table gets neutral defaults and lets the column
    heuristics do their job, which is what they are for.
    """
    return Profile(course_key, {
        "course_key": course_key, "course_raw": course_raw, "display_name": display,
        "homework_source": "doc", "confidence": 0.3,
        "layout": {"shape": None,
                   "date_styles": ["day_n", "absolute", "month_heading",
                                   "weekday_letter"],
                   "date_column_headers": None, "due_column_headers": None,
                   "assigned_column_headers": None,
                   "skip_column_headers": None, "block_heading_pattern": None,
                   "row_is_item": None, "bullet_split": True,
                   "snap_absolute_to_meeting": False, "notes": None},
        "line_prefixes": {k: list(v) for k, v in prose.PAGE_PREFIXES.items()},
        "notation": {}, "quirks": [],
    })


def _as_page_item(item: Item, where: str) -> Item:
    """Re-stamp a table-extracted item as coming from the page it came from.

    items.extract_doc writes source "doc" and notes that say "the doc"; on a
    Canvas page both would send the student somewhere that does not exist.
    Re-finalizing recomputes item_id from the new source.
    """
    item.source = "canvas_page"
    item.kind = "course homepage"
    if where and "homepage" not in item.date_note and "page" not in item.date_note:
        item.date_note = f"{item.date_note} — on {where}"
    return item.finalize()


def extract_page(html: str, course: dict, meetings, where: str, url: str,
                 profile=None) -> list[Item]:
    """Everything one page states, prose and tables alike."""
    key = course["course_key"]
    display = course.get("display_name") or key
    lookup = course.get("course_raw") or display
    items: list[Item] = []
    result = prose.extract_prose(html, key, display, lookup, meetings,
                                 where=where, source_url=url, profile=profile)
    items.extend(result.items)
    if _has_table(html):
        try:
            from sillybus.docs import items as items_mod
            table = items_mod.extract_doc(
                html, _synthetic_profile(key, display, lookup), meetings, url)
            items.extend(_as_page_item(i, where) for i in table.items)
        except Exception as exc:  # noqa: BLE001 — prose already succeeded
            log.warning("%s: table on %s could not be read (%s)", key, where, exc)
    return items


def _cache_key(stamp: str) -> str:
    """What must be unchanged for cached items to still be right: the page, and
    the code that read it."""
    return f"{stamp}|{EXTRACTOR_VERSION}"


def _reuse(conn, file_id: str, stamp: str) -> list[Item] | None:
    """Cached items for a page whose updated_at has not moved."""
    cached = db.doc_state_get(conn, file_id)
    if not cached or not stamp or cached.get("fingerprint") != _cache_key(stamp):
        return None
    try:
        return [Item(**entry) for entry in json.loads(cached["items_json"])]
    except (ValueError, TypeError):
        return None


def _remember(conn, file_id: str, stamp: str, html: str, items: list[Item]) -> None:
    db.doc_state_put(conn, file_id,
                     hashlib.sha1((html or "").encode("utf-8")).hexdigest()[:16],
                     [i.to_dict() for i in items], [], _cache_key(stamp))


def collect(context, meetings, conn, today: date, profiles: dict | None = None,
            emit=None, courses: list[dict] | None = None) -> tuple[list[Item], dict]:
    """Every item stated on the course pages and announcements. (items, diagnostics)"""
    cfg = config.load()
    host = cfg["canvas"]["host"].rstrip("/")
    sources = cfg.get("sources") or {}
    read_pages = sources.get("canvas_pages", True)
    read_announcements = sources.get("canvas_announcements", True)
    read_discussions = sources.get("canvas_discussions", True)
    profiles = profiles or {}
    diagnostics: dict = {"per_course": {}, "pages_read": 0, "pages_reused": 0,
                         "announcements_read": 0, "discussions_read": 0,
                         "dropped_outside_window": 0}
    if not read_pages and not read_announcements and not read_discussions:
        return [], diagnostics

    def say(message, course=None, level="info"):
        if emit:
            emit(message, course, level)

    window = cfg["window"]
    earliest = today - timedelta(days=window["days_back"])
    latest = today + timedelta(days=window["days_forward"])

    course_list = courses if courses is not None else current_courses(context, meetings)
    everything: list[Item] = []

    for course in course_list:
        if course.get("canvas_raw"):
            # Items are named the way Canvas names the course to him (the
            # nickname, if he set one), as they always were: an item's id is
            # built from its course key, and moving it would detach every
            # saved "done" tick (prosecution round 5, 2026-10-07, see
            # courses.canvas_courses).
            course = dict(course, course_key=course["canvas_key"],
                          course_raw=course["canvas_raw"])
        key = course["course_key"]
        course_id = course.get("canvas_course_id")
        if not course_id:
            continue
        profile = profiles.get(key)
        found: list[Item] = []
        per_course = {"pages": [], "announcements": 0, "items": 0, "dropped": 0}

        if read_pages:
            listed = page_list(context, host, course_id)
            wanted: list[dict] = []
            front_slug = next((p["slug"] for p in listed if p["front_page"]), None)
            extras = [p for p in listed
                      if not p["front_page"] and SCHEDULE_TITLE.search(p["title"])]
            for page in extras[:MAX_EXTRA_PAGES]:
                wanted.append(page)
            # The front page always, whether or not it is in the wiki list (a
            # course can have a front page that is not a wiki page at all).
            wanted.insert(0, {"slug": front_slug or "__front__", "title": "homepage",
                              "front_page": True,
                              "updated_at": next((p["updated_at"] for p in listed
                                                  if p["front_page"]), ""),
                              "html_url": f"{host}/courses/{course_id}"})

            for page in wanted:
                file_id = f"page:{course_id}:{page['slug']}"
                where = ("the class homepage" if page["front_page"]
                         else f"the page '{page['title']}'")
                url = page.get("html_url") or f"{host}/courses/{course_id}"
                reused = _reuse(conn, file_id, page["updated_at"])
                if reused is not None:
                    found.extend(reused)
                    diagnostics["pages_reused"] += 1
                    per_course["pages"].append(
                        {"title": page["title"], "items": len(reused), "reused": True})
                    continue
                if page["front_page"]:
                    html, stamp, _title = front_page(context, host, course_id)
                    stamp = page["updated_at"] or stamp
                else:
                    html, stamp = page_body(context, host, course_id, page["slug"])
                    stamp = page["updated_at"] or stamp
                diagnostics["pages_read"] += 1
                if not html:
                    continue
                items = extract_page(html, course, meetings, where, url, profile)
                _remember(conn, file_id, stamp, html, items)
                found.extend(items)
                per_course["pages"].append(
                    {"title": page["title"], "items": len(items), "reused": False})
                if items:
                    say(f"{len(items)} item(s) on {where}", key)

        if read_announcements:
            for entry in recent_announcements(context, host, course_id, today):
                diagnostics["announcements_read"] += 1
                per_course["announcements"] += 1
                try:
                    posted = date.fromisoformat(entry["posted"])
                except ValueError:
                    continue
                result = prose.extract_announcement(
                    entry["title"], entry["message"], posted, key,
                    course.get("display_name") or key,
                    course.get("course_raw") or key, meetings,
                    url=entry["url"], profile=profile)
                if result.items:
                    say(f"{len(result.items)} item(s) in the announcement "
                        f"'{entry['title'][:40]}'", key)
                found.extend(result.items)

        if read_discussions:
            for entry in recent_discussions(context, host, course_id, today):
                diagnostics["discussions_read"] += 1
                per_course["discussions"] = per_course.get("discussions", 0) + 1
                try:
                    posted = date.fromisoformat(entry["posted"])
                except ValueError:
                    continue
                # Same reader as an announcement: a topic and an announcement
                # are the same shape of writing, and one set of rules for
                # "what counts as work" is the whole point.
                result = prose.extract_announcement(
                    entry["title"], entry["message"], posted, key,
                    course.get("display_name") or key,
                    course.get("course_raw") or key, meetings,
                    url=entry["url"], profile=profile)
                if result.items:
                    say(f"{len(result.items)} item(s) in the discussion "
                        f"'{entry['title'][:40]}'", key)
                found.extend(result.items)

        # The window. A homepage holds the whole term; August's finished
        # homework is not work, and showing it as overdue would be a lie about
        # what is left to do. Undated items are always kept.
        floor = max(earliest,
                    today - timedelta(days=NO_SUBMISSION_GRACE_DAYS)).isoformat()
        inside = []
        for item in found:
            if item.due_date and not (floor <= item.due_date <= latest.isoformat()):
                per_course["dropped"] += 1
                continue
            inside.append(item)
        diagnostics["dropped_outside_window"] += per_course["dropped"]
        per_course["items"] = len(inside)
        if per_course["pages"] or per_course["announcements"]:
            diagnostics["per_course"][key] = per_course
        everything.extend(inside)

    log.info("pages: %d item(s) from %d page(s) read, %d reused, %d announcement(s); "
             "%d item(s) outside the window", len(everything),
             diagnostics["pages_read"], diagnostics["pages_reused"],
             diagnostics["announcements_read"], diagnostics["dropped_outside_window"])
    return everything, diagnostics
