"""Canvas via the browser session: planner items, course cards, homepages.

The planner is precise but incomplete — it carries points, submitted-status,
type, and canonical links, and about a quarter of the real workload. On an
expired session it fails loudly and specifically, and the caller lets the doc
half of the run complete regardless.
"""

import json
import re
from datetime import date, timedelta
from urllib.parse import urljoin

from sillybus import config, duedates, models, timezones
from sillybus.browser import SessionError, strip_while1
from sillybus.logging_setup import get

log = get("canvas")

NEXT_LINK = re.compile(r'<([^>]+)>;\s*rel="next"')


class CanvasRefused(RuntimeError):
    """Canvas said no to this request, with a session that is working.

    Kept apart from SessionError on purpose. A SessionError means "sign in
    again" and, inside a refresh, drops the Canvas half to the calendar-feed
    fallback with no points and no submitted status. That is the right answer
    to an expired session and the wrong answer to one endpoint the student
    simply cannot read.
    """


class CanvasHTTPError(SessionError):
    """Canvas answered, with an error that is not about the session: a 404
    for a course with no front page, a 500, a body that was not JSON.

    A SessionError subclass so every existing `except SessionError` still
    catches it, and a class of its own so a caller can tell "this one page is
    missing" from "sign in again" by TYPE. `homepage_html` used to tell them
    apart by looking for "401"/"403" in the message, which carries the URL —
    course 14035 contains "403", so its missing front page was re-raised as an
    auth failure and the syllabus fallback never ran (prosecution round 5,
    2026-10-07).
    """

    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def _session_alive(context, timeout: int = 20_000) -> bool:
    """The cheapest question Canvas answers for a signed-in student."""
    host = config.load()["canvas"]["host"].rstrip("/")
    try:
        probe = context.request.get(f"{host}/api/v1/users/self", timeout=timeout)
    except Exception:  # noqa: BLE001 — no answer is not evidence of a session
        return False
    return bool(getattr(probe, "ok", False))


def _get_json(context, url: str, timeout: int = 45_000):
    """One session GET -> (parsed json, next_url or None).

    Raises SessionError when the session is the problem, so the caller can
    render the exact fix, and CanvasRefused when it is not.

    [MEASURED] 2026-09-02: Canvas caps `context_codes` at ten, so asking about
    fourteen courses at once returned 403 — and this reported "Canvas rejected
    the saved session (expired or logged out)" with the fix "python run.py
    login", while `/users/self` and the planner both answered normally in the
    same second. Signing in again could not have helped, and inside a refresh
    that misreading costs the whole Canvas half.
    """
    # ---- what Chrome already fetched, before asking for it again -----------
    #
    # [ASKED] 2026-09-23: *"make it read all the connecors using the chrome
    # extenion insted of connecting them"*.
    #
    # This is the one place it had to go. Every Canvas reader in this file —
    # the planner, the per-course assignment lists, the assignment groups, the
    # grade summary, the course list — goes through `_get_json`, so checking
    # here moves all of them at once, and a reader added later is carried
    # along without knowing this exists.
    #
    # `bridge.captured_page` returns None when there is no capture or it has
    # gone stale, and **writes down that this address was wanted** so the next
    # sweep fetches it. That is why no list of per-course URLs appears
    # anywhere: the app does not predict which courses exist, it reports what
    # it actually reached for. The honest cost is that a new class is read by
    # this app's own browser once before Chrome takes it over.
    #
    # The bridge is a shortcut and never a requirement: with the extension
    # uninstalled every line below runs exactly as it always did.
    try:
        from sillybus import bridge
        hit = bridge.captured_page(url, name="Canvas")
    except Exception as exc:                 # noqa: BLE001 — never the refresh
        log.info("bridge lookup failed for %s: %s", url[:70], exc)
        hit = None
    if hit:
        text = strip_while1(hit["body"])
        try:
            data = json.loads(text)
        except ValueError:
            # Chrome fetched it and it was not JSON — a sign-in page, most
            # likely. Fall through and let the app's own session try, which
            # reports an expired session properly.
            log.info("bridged %s was not JSON; fetching it directly", url[:70])
        else:
            match = NEXT_LINK.search((hit.get("headers") or {}).get("link", ""))
            log.info("bridged: %s", url[:90])
            return data, (match.group(1) if match else None)

    response = context.request.get(url, timeout=timeout)
    if response.status == 401:
        # 401 needs no second opinion, and a refresh should not pay for one.
        raise SessionError(
            "Canvas rejected the saved session (expired or logged out)",
            fix="python run.py login")
    if response.status == 403:
        if _session_alive(context):
            raise CanvasRefused(
                f"Canvas refused this request (403) with a working session: {url}")
        raise SessionError(
            "Canvas rejected the saved session (expired or logged out)",
            fix="python run.py login")
    if not response.ok:
        raise CanvasHTTPError(f"Canvas returned HTTP {response.status} for {url}",
                              status=response.status)
    text = strip_while1(response.text())
    try:
        data = json.loads(text)
    except ValueError as exc:
        if "login" in (response.url or ""):
            raise SessionError(
                "Canvas redirected to a login page — the session is expired",
                fix="python run.py login") from exc
        raise CanvasHTTPError(f"Canvas sent non-JSON for {url}") from exc
    link_header = response.headers.get("link", "")
    match = NEXT_LINK.search(link_header)
    return data, (match.group(1) if match else None)


def planner_items_raw(context, start: date, end: date) -> list[dict]:
    """Every page of /api/v1/planner/items for the window."""
    host = config.load()["canvas"]["host"].rstrip("/")
    url = (f"{host}/api/v1/planner/items?start_date={start.isoformat()}"
           f"&end_date={end.isoformat()}&per_page=100")
    items: list[dict] = []
    pages = 0
    while url and pages < 20:
        data, url = _get_json(context, url)
        if isinstance(data, list):
            items.extend(data)
        pages += 1
    log.info("planner: %d items over %d page(s)", len(items), pages)
    return items


SKIP_PLANNER_KINDS = {"announcement", "calendar_event"}


# Software requirements a teacher appends to a title. [MEASURED] 2026-09-02:
# six of his Canvas items end in some spelling of "- Requires Respondus
# LockDown Browser", 37 characters of it, in a title with about 40 usable
# characters on his window — it pushed the actual name of the quiz out of
# view and made three different quizzes look like one item.
#
# A fact about the software, not about the work. The full title stays in
# `detail`, so he can still see that the quiz needs LockDown Browser.
# Kept here rather than imported from scoring, which imports nothing from the
# feeds: the two lists are asserted equal by a test so they cannot drift.
PROCTORED_MARKERS = ("lockdown browser", "respondus")


def scoring_produced() -> set:
    from sillybus import scoring

    return scoring.PRODUCED


RE_TITLE_BOILERPLATE = re.compile(
    r"\s*[-–—:(]*\s*requires?\s+(?:respondus\s+)?lock\s*down\s+browser"
    r"(?:\s*\+\s*monitor)?\s*\)?\s*$", re.I)


def clean_title(title: str) -> str:
    """The work's name, without the software it happens to need."""
    text = (title or "").strip()
    stripped = RE_TITLE_BOILERPLATE.sub("", text).strip(" -–—:")
    # A title that is ONLY the requirement keeps it: stripping would leave
    # nothing, and an item with no name is worse than an ugly one.
    return stripped or text


# Which submission states mean "he has handed this in". `pending_review` is a
# quiz waiting on a human to mark it — done, from his point of view, and the
# distinction matters because an item shown as outstanding when it is finished
# is the fastest way to make a board untrustworthy.
DONE_STATES = {"submitted", "graded", "pending_review"}


def assignments_raw(context, course_id: str) -> list[dict]:
    """Every page of /api/v1/courses/<id>/assignments, with submissions.

    The authoritative list, and the reason this exists next to the planner.
    [MEASURED] 2026-09-02, against his nine real courses: Canvas held 41
    published assignments; the planner returned 24 items for a 14-day window,
    and 14 of the dated assignments missing from the board were absent from
    the planner response altogether. The planner is a calendar — it carries
    the student's own dated view and nothing else — so an assignment with no
    due date cannot appear in it at all, however overdue the work is.
    """
    host = config.load()["canvas"]["host"].rstrip("/")
    url = (f"{host}/api/v1/courses/{course_id}/assignments"
           "?per_page=100&include[]=submission&include[]=all_dates")
    out: list[dict] = []
    pages = 0
    while url and pages < 12:
        data, url = _get_json(context, url)
        if isinstance(data, list):
            out.extend(data)
        pages += 1
    log.info("assignments: course %s -> %d over %d page(s)",
             course_id, len(out), pages)
    return out


def _as_date(iso: str | None):
    """An ISO day as a date, or None — for the anchor `duedates.find` takes."""
    try:
        return date.fromisoformat(iso) if iso else None
    except (TypeError, ValueError):
        return None


def _posted_day(entry: dict):
    """The day an assignment's words were put in front of the student.

    The LATER of `unlock_at` and `created_at`. A course built over the summer
    or copied from last year has a `created_at` in August and opens each
    assignment weeks later; "Due Friday" means the Friday after it opened.
    Counting from `created_at` alone read it as a Friday in August
    (prosecution round 5, 2026-10-07).
    """
    days = [d for d in (_as_date(_local_day(entry.get("created_at"))),
                        _as_date(_local_day(entry.get("unlock_at")))) if d]
    return max(days) if days else None


def _local_day(stamp: str | None) -> str | None:
    """A Canvas timestamp as the local calendar day, or None."""
    if not stamp:
        return None
    try:
        return timezones.to_local(stamp).date().isoformat()
    except Exception:                                    # noqa: BLE001
        return None


def items_from_assignments(raw: list[dict], course: str, today: date,
                           days_back: int = 8,
                           days_forward: int = 14,
                           meetings=None,
                           read_descriptions: bool = True) -> list[models.Item]:
    """Map the assignments endpoint to Items.

    What is shown, and why:

    * **Work he still owes is shown however far ahead it is**, dated or not.
      That is the whole point: "Side Hustle Proposal", 100 points, due in 23
      days and unsubmitted, was invisible because the fetch window was 14.
      Behind, everything obeys the same `days_back` floor: work missed three
      weeks ago cannot be handed in, and a permanent block of red at the top
      of the board is its own kind of lie.
    * **Work he has finished is shown only inside the window** — recent
      enough to be context, not a term of history. This is also what keeps
      the end-of-term running logs ("Warm Up Board", due 2026-12-18, already
      graded) off a September board without a special case for them.
    * **Undated and finished is not shown at all.** Five of his six undated
      assignments are graded; an undated finished thing is not a task, and an
      undated item lingers until it is retired.
    * **Unpublished is never shown.** A draft is not work yet.
    * **The description is read for a date Canvas's own field gets wrong.**
      `read_descriptions` switches that off; `meetings` lets "due next class"
      resolve. See the block marked "what the teacher WROTE" below, and
      `sillybus/duedates.py` for the rules it keeps.
    """
    host = config.load()["canvas"]["host"].rstrip("/")
    floor = (today - timedelta(days=days_back)).isoformat()
    ceiling = (today + timedelta(days=days_forward)).isoformat()
    out: list[models.Item] = []
    for entry in raw or []:
        if not entry.get("published", True):
            continue
        raw_title = (entry.get("name") or "").strip()
        if not raw_title:
            continue
        # Read the facts out of the raw title BEFORE cleaning it: the
        # LockDown Browser phrase is the strongest evidence a title carries
        # (scoring.PROCTORED), and stripping it as boilerplate would throw
        # away what it proved.
        proctored = any(m in raw_title.lower() for m in PROCTORED_MARKERS)
        title = clean_title(raw_title)

        submission = entry.get("submission") or {}
        state = (submission.get("workflow_state") or "").lower()
        # No submission block means Canvas did not tell us, and guessing
        # "done" hides real work. Only one of the two errors is safe.
        submitted = state in DONE_STATES

        stamp = entry.get("due_at")
        due = due_date = None
        all_day = False
        if stamp:
            local = timezones.to_local(stamp)
            due = local.isoformat()
            due_date = local.date().isoformat()
            all_day = local.hour == 0 and local.minute == 0

        # ---- what the teacher WROTE, which is sometimes the only right date -
        #
        # [ASKED] 2026-09-22: *"it is not always the day it was assigned some
        # times is says it in the discriptions"*. Canvas has been returning
        # `description` on every one of these entries all along and this
        # function threw it away, so the correction needed no new request, no
        # new permission and no new source — only reading what was already in
        # hand. `duedates` states the rules; the two that matter here are that
        # a date is read only when an obligation word is attached to it, and
        # that Canvas keeps its own date unless it is the day the assignment
        # was created.
        #
        # This runs BEFORE the window test below, deliberately. An assignment
        # Canvas dates to the day it was posted and the teacher dates to next
        # Friday is exactly the item the floor would have dropped as old.
        note = ("Canvas due date" if due_date else
                "Canvas lists this with no due date, and it is not handed in yet")
        extractor = "canvas_stated"
        date_flags: list = []
        stated_dates: list = []
        # The description's words travel with the item. [ASKED] 2026-09-28:
        # "make it better on reading the assignments" — the checker had the
        # title and nothing else; the teacher's own instructions were read
        # for a date here and then thrown away.
        description_text = ""
        try:
            description_text = duedates.text_from_html(entry.get("description") or "")
        except Exception:                             # noqa: BLE001 — never the run
            description_text = ""
        if read_descriptions:
            try:
                # Anchored to the day it was posted: "Friday" in a
                # description written on Monday the 21st is the 25th, and
                # stays the 25th however many weeks later it is read.
                stated_dates = duedates.find(
                    duedates.text_from_html(entry.get("description") or ""),
                    today, meetings, course, anchor=_posted_day(entry))
            except Exception as exc:          # noqa: BLE001 — never the run
                log.info("description date unreadable for %r: %s",
                         raw_title[:40], exc)
        verdict = duedates.reconcile(
            found=stated_dates, canvas_due_date=due_date,
            # Converted, not sliced. [MEASURED] 2026-09-22: `due_at` of
            # 2026-09-22T00:00:00Z is Sep 21 in Phoenix, so comparing it
            # against a raw `created_at` of "2026-09-22" said the two were
            # different days and the rule that exists for exactly this case
            # never fired. Both sides of a date comparison go through the
            # same clock or the comparison is not one (spec §4.6).
            created_on=_local_day(entry.get("created_at")),
            unlock_on=_local_day(entry.get("unlock_at")),
            canvas_note=note)
        note = verdict.date_note
        date_flags = list(verdict.flags)
        if verdict.changed:
            due_date = verdict.due_date
            # A sentence gives a day, not an hour. Dropping the timestamp is
            # the honest shape, and `all_day` is what the board reads to stop
            # printing a time nobody stated.
            due, all_day = None, True
            extractor = verdict.extractor or extractor
            log.info("description date: %r -> %s (%s)", raw_title[:40],
                     due_date, verdict.flags)

        # Canvas gave no date and he has not handed it in: that is owed work,
        # and a date read out of the description must never be what takes it
        # off the board. [prosecution round 5, 2026-10-07] "Due Friday" in an
        # assignment built in August and opened on Oct 5 was counted from
        # August, landed before the floor, and the work vanished. The anchor
        # is fixed above; this is the backstop for any other misreading —
        # the item stays, undated, and the note says what was read and why
        # it was not used.
        if (verdict.changed and not stamp and not submitted
                and due_date and due_date < floor):
            log.info("description date %s for %r has passed; kept undated",
                     due_date, raw_title[:40])
            note = (f"{verdict.date_note}. That day has already passed and "
                    "Canvas has no due date of its own, so this stays on the "
                    "board with no date until it is handed in")
            due_date = due = None
            all_day = False
            extractor = "canvas_stated"
            date_flags = []

        if due_date:
            # No horizon ahead — unfinished work is unfinished, and hiding a
            # 100-point project because it is 23 days out was the defect that
            # started this. Behind, the same floor as everything else: an
            # assignment from three weeks ago that was never handed in cannot
            # be handed in now, and `_within_reach` names what showing it
            # produces — "a permanent block of false overdue at the top of the
            # board".
            if due_date < floor:
                continue
            if submitted and due_date > ceiling:
                continue
        elif submitted:
            continue

        quiz = bool(entry.get("quiz_id") or entry.get("is_quiz_assignment")
                    or proctored)
        # What Canvas says he has to hand in, which decides whether a title
        # containing "video" or "watch" is something to consume or to produce.
        produced = {t for t in (entry.get("submission_types") or [])
                    if t in scoring_produced()}
        url = entry.get("html_url") or ""
        if url:
            url = urljoin(host + "/", url)
        item = models.Item(
            source="canvas",
            course_key=models.course_key_from_raw(course),
            course=course,
            title=title[:110],
            detail=raw_title,
            # `submission_types` rides along, not just the must_submit
            # boolean below. Canvas refuses a submission whose type the
            # assignment does not allow, so handing work in from the board
            # needs the actual list — and this is the only place that has it.
            # Sorted so the JSON is stable and two runs produce equal items.
            raw_cell=json.dumps({"assignment_id": entry.get("id"),
                                 "due_at": entry.get("due_at"),
                                 "workflow_state": state or None,
                                 "quiz_id": entry.get("quiz_id"),
                                 # The planner links a graded discussion to
                                 # its TOPIC; this is what pairs the two by
                                 # id instead of by title (round 5).
                                 "discussion_topic_id": (
                                     entry["discussion_topic"].get("id")
                                     if isinstance(entry.get("discussion_topic"), dict)
                                     else None),
                                 "submission_types": sorted(
                                     entry.get("submission_types") or []),
                                 # The two dates duedates.reconcile turns on.
                                 # Without them a swapped date cannot be
                                 # argued with after the fact.
                                 "created_at": entry.get("created_at"),
                                 "unlock_at": entry.get("unlock_at")}),
            kind="quiz" if quiz else "assignment",
            due=due,
            due_date=due_date,
            all_day=all_day,
            assigned_date=(_local_day(entry.get("unlock_at"))
                           or _local_day(entry.get("created_at"))),
            description=description_text[:6000],
            date_note=note,
            confidence="high",
            extractor=extractor,
            points=entry.get("points_possible"),
            submitted=submitted,
            url=url or None,
            flags=(["must_submit"] if produced else []) + date_flags,
            links=[models.Link(url=url, text=title, kind="canvas")] if url else [],
        )
        out.append(item.finalize())
    return out


def planner_done(entry: dict) -> bool | None:
    """Has the student finished this planner item? None when Canvas did not say.

    `submissions.submitted` alone is not the answer (prosecution round 5,
    2026-10-07). Three more things Canvas states mean the work is closed:

    * **graded** — on-paper work, or a test sat in class, never has a
      submission, so `submitted` stays false for ever; the assignments
      endpoint calls the same thing workflow_state "graded", which this app
      already counts as done (DONE_STATES).
    * **excused** — the teacher has said he does not owe it.
    * **planner_override.marked_complete** — he ticked it off in Canvas's own
      planner. Reading Canvas's tick is the least a second to-do list owes him.

    A teacher's redo request reopens it, whatever else is true.
    """
    submissions = entry.get("submissions")
    override = entry.get("planner_override")
    marked = isinstance(override, dict) and bool(override.get("marked_complete"))
    if isinstance(submissions, dict):
        if submissions.get("redo_request"):
            return False
        return bool(submissions.get("submitted") or submissions.get("graded")
                    or submissions.get("excused") or marked)
    return True if marked else None


def items_from_planner(raw: list[dict],
                       group_courses: dict | None = None) -> list[models.Item]:
    """Map planner JSON to Items. Dates convert to Phoenix FIRST (spec §4.6).

    `group_courses` maps a Canvas group id to the name of the course that
    group belongs to (see `group_course_names`).
    """
    host = config.load()["canvas"]["host"].rstrip("/")
    group_courses = group_courses or {}
    out: list[models.Item] = []
    for entry in raw:
        plannable = entry.get("plannable") or {}
        kind = (entry.get("plannable_type") or "").replace("_", " ")
        if kind.replace(" ", "_") in SKIP_PLANNER_KINDS:
            continue
        raw_title = plannable.get("title") or plannable.get("name") or ""
        if not raw_title:
            continue
        title = clean_title(raw_title)
        course = entry.get("context_name") or ""
        group_note = ""
        if (entry.get("context_type") or "").lower() == "group":
            # A Canvas GROUP (a lab team, a project group) is not a class,
            # and its name used to become one: "Lab Team 4" turned up on the
            # board as a course of its own (prosecution round 5, 2026-10-07).
            # Filed under the group's own course when Canvas said which; when
            # it did not, kept — group work is still work — and the note says
            # whose it is, so it is marked rather than silently misfiled.
            gid = str(entry.get("group_id") or "")
            owner = group_courses.get(gid)
            if owner:
                group_note = f" (for the Canvas group “{course}”)"
                course = owner
            else:
                log.info("planner: group %s (%r) has no known course; "
                         "kept under the group's name", gid, course[:40])
                group_note = (f" (from the Canvas group “{course}” — Canvas "
                              "did not say which class it belongs to)")
        stamp = plannable.get("due_at") or entry.get("plannable_date")
        due = due_date = None
        all_day = False
        if stamp:
            local = timezones.to_local(stamp)
            due = local.isoformat()
            due_date = local.date().isoformat()
            all_day = local.hour == 0 and local.minute == 0
        submitted = planner_done(entry)
        url = entry.get("html_url") or plannable.get("html_url") or ""
        if url:
            url = urljoin(host + "/", url)
        item = models.Item(
            source="canvas",
            course_key=models.course_key_from_raw(course),
            course=course,
            title=title[:110],
            detail=raw_title,
            raw_cell=json.dumps({k: entry.get(k) for k in
                                 ("plannable_type", "plannable_date", "context_name")}),
            kind=kind or "assignment",
            due=due,
            due_date=due_date,
            all_day=all_day,
            date_note="Canvas due date" + group_note,
            confidence="high",
            extractor="canvas_stated",
            points=plannable.get("points_possible"),
            submitted=submitted,
            url=url or None,
            links=[models.Link(url=url, text=title, kind="canvas")] if url else [],
        )
        out.append(item.finalize())
    return out


def scores_from_assignments(raw: list[dict], course: str) -> list[dict]:
    """Every assignment Canvas has actually put a score on, with its kind.

    *"add a summery of what type of assighnments i am bad at and what I am
    good at"*. This is the honest basis for that, and it is real: [MEASURED]
    2026-09-03, twelve of fifteen Honors Biology assignments carry a score,
    and four of six in Spanish 1 — where the two quizzes are 60% and 70%
    while the test is 89%. That is a pattern from marks, not a guess from a
    single course percentage.

    What it is NOT: the Veracross gradebook. These are the Canvas-graded
    pieces only, and Canvas does not say how much each category counts
    towards the report-card grade. So a summary built from this may say "your
    quizzes come out lower than your tests" — a fact about the scores — and
    must not say "quizzes are dragging your grade down", which needs weights
    nobody here can read.
    """
    from sillybus import scoring

    out: list[dict] = []
    for entry in raw or []:
        submission = entry.get("submission") or {}
        score = submission.get("score")
        possible = entry.get("points_possible")
        if score is None:
            continue
        # Extra credit is an assignment out of 0 with points scored. Canvas
        # adds those points to the group and adds nothing to what was
        # possible; skipping it (as `not possible` did) left the grade page
        # short of Canvas's own total. Kept with percent None — a mark out of
        # 0 has no percent of its own, so it is never averaged as one. A 0/0
        # mark is nothing at all and is still skipped.
        # (prosecution round 4, 2026-10-07)
        if not possible and not float(score):
            continue
        title = (entry.get("name") or "").strip()
        if not title:
            continue
        kind = "quiz" if (entry.get("quiz_id")
                          or entry.get("is_quiz_assignment")) else "assignment"
        out.append({
            "course_key": models.course_key_from_raw(course),
            "title": clean_title(title)[:90],
            "category": scoring.categorize(title, kind=kind),
            "score": float(score),
            "possible": float(possible or 0),
            "percent": (round(float(score) / float(possible) * 100, 1)
                        if possible else None),
            "graded_at": submission.get("graded_at"),
            "url": entry.get("html_url") or None,
            # Which assignment group Canvas files this under, so the grade
            # page can weight it the way Canvas does (see gradebook_from).
            # `omit` marks work Canvas itself leaves out of the final grade —
            # a running log, a practice set — which must not be given a share.
            "assignment_id": entry.get("id"),
            "group_id": entry.get("assignment_group_id"),
            "omit": bool(entry.get("omit_from_final_grade")),
            "due_at": entry.get("due_at"),
        })
    return out


def assignment_groups_raw(context, course_id: str) -> list[dict]:
    """Every assignment group in the course, with its weight.

    /api/v1/courses/<id>/assignment_groups returns `group_weight` per group,
    and the course itself says whether those weights are applied
    (`apply_assignment_group_weights`). Together they are the only readable
    statement of how much a kind of work counts — the Veracross gradebook
    renders inside its own SPA and comes back as an empty shell ([MEASURED]
    2026-09-03). One request per course, no pagination in practice.
    """
    host = config.load()["canvas"]["host"].rstrip("/")
    url = f"{host}/api/v1/courses/{course_id}/assignment_groups?per_page=100"
    out: list[dict] = []
    pages = 0
    while url and pages < 5:
        data, url = _get_json(context, url)
        if isinstance(data, list):
            out.extend(data)
        pages += 1
    return out


def course_grade_raw(context, course_id: str) -> dict:
    """The course record with the student's own enrollment and Canvas's
    computed current score — the number the weights below add up to."""
    host = config.load()["canvas"]["host"].rstrip("/")
    data, _ = _get_json(
        context, f"{host}/api/v1/courses/{course_id}?include[]=total_scores")
    return data if isinstance(data, dict) else {}


def gradebook_from(course: str, groups_raw: list[dict], course_raw: dict) -> dict:
    """What Canvas says about how this class's grade is put together.

    *"have something to show the % of your grade each assignment is bc some
    are weighted"*. This is the honest basis for that. It is NOT a claim about
    the report-card grade: Veracross is the gradebook of record and may hold
    marks Canvas never sees. So the record carries Canvas's own computed score
    beside the weights — when it matches the Veracross percentage the weights
    explain the grade; when it does not, the page says so rather than
    pretending. `weighted` false means Canvas adds points straight up, and a
    share is then simply points over total points.
    """
    weighted = bool(course_raw.get("apply_assignment_group_weights"))
    enrollments = [e for e in (course_raw.get("enrollments") or [])
                   if isinstance(e, dict)]
    mine = next((e for e in enrollments
                 if (e.get("type") or "").lower().startswith("student")),
                enrollments[0] if enrollments else {})
    current = mine.get("computed_current_score")
    groups = []
    for group in groups_raw or []:
        if not isinstance(group, dict) or group.get("id") is None:
            continue
        try:
            weight = float(group.get("group_weight") or 0)
        except (TypeError, ValueError):
            weight = 0.0
        groups.append({"id": group.get("id"),
                       "name": (group.get("name") or "").strip()[:60],
                       "weight": weight,
                       "position": group.get("position")})
    groups.sort(key=lambda g: (g["position"] is None, g["position"] or 0))
    return {
        "course_key": models.course_key_from_raw(course),
        "weighted": weighted,
        "canvas_percent": (float(current) if isinstance(current, (int, float))
                           else None),
        "groups": groups,
    }


def group_course_names(context, planner_raw: list[dict]) -> dict:
    """{group id: course name} for the groups the planner mentions.

    One request (/users/self/groups), made only when a planner item comes
    from a group. The course's NAME is taken from the planner's own items for
    that course first, so a group item lands under exactly the course key its
    classmates' items use; the course list is asked only when the planner had
    nothing else from that course. Best effort: {} on any failure, and the
    caller keeps the group items marked as such.
    """
    wanted = {str(e.get("group_id")) for e in planner_raw or []
              if (e.get("context_type") or "").lower() == "group" and e.get("group_id")}
    if not wanted:
        return {}
    host = config.load()["canvas"]["host"].rstrip("/")
    groups: list = []
    url = f"{host}/api/v1/users/self/groups?per_page=100"
    pages = 0
    try:
        while url and pages < 5:
            data, url = _get_json(context, url)
            if isinstance(data, list):
                groups.extend(data)
            pages += 1
    except Exception as exc:  # noqa: BLE001 — the items stay, marked
        log.info("groups unavailable: %s", exc)
        return {}
    course_of = {str(g.get("id")): str(g.get("course_id"))
                 for g in groups if isinstance(g, dict) and g.get("course_id")
                 and (g.get("context_type") or "Course") == "Course"}
    names = {str(e.get("course_id")): e.get("context_name")
             for e in planner_raw or []
             if e.get("course_id") and e.get("context_name")
             and (e.get("context_type") or "Course").lower() == "course"}
    if any(course_of.get(g) and course_of[g] not in names for g in wanted):
        try:
            from sillybus import courses as courses_mod
            for c in courses_mod.canvas_courses(context):
                names.setdefault(str(c["canvas_course_id"]),
                                 c.get("canvas_raw") or c["course_raw"])
        except Exception as exc:  # noqa: BLE001
            log.info("course list unavailable for group mapping: %s", exc)
    return {g: names[course_of[g]] for g in wanted
            if course_of.get(g) and names.get(course_of[g])}


def dashboard_courses(context) -> list[models.Course]:
    """The course cards: id, name, homepage URL."""
    host = config.load()["canvas"]["host"].rstrip("/")
    data, _ = _get_json(context, f"{host}/api/v1/dashboard/dashboard_cards")
    courses: list[models.Course] = []
    for card in data if isinstance(data, list) else []:
        name = card.get("originalName") or card.get("shortName") or ""
        cid = str(card.get("id") or "")
        if not cid:
            continue
        courses.append(models.Course(
            course_key=models.course_key_from_raw(name),
            course_raw=name,
            display_name=card.get("shortName") or name,
            canvas_course_id=cid,
            canvas_url=f"{host}/courses/{cid}",
        ))
    return courses


def homepage_html(context, course_id: str) -> str:
    """The course homepage HTML: the front page body, else the syllabus body,
    else the rendered page (a last resort that needs a page object)."""
    host = config.load()["canvas"]["host"].rstrip("/")
    # Decided by the exception's TYPE, never its text (prosecution round 5,
    # 2026-10-07). A missing front page (CanvasHTTPError) and a page this
    # student may not read with a working session (CanvasRefused) both mean
    # "try the syllabus"; only a real session failure stops here.
    try:
        data, _ = _get_json(context, f"{host}/api/v1/courses/{course_id}/front_page")
        body = data.get("body") if isinstance(data, dict) else None
        if body:
            return body
    except (CanvasHTTPError, CanvasRefused) as exc:
        log.info("front page for course %s unavailable (%s); trying the syllabus",
                 course_id, type(exc).__name__)
    try:
        data, _ = _get_json(
            context, f"{host}/api/v1/courses/{course_id}?include[]=syllabus_body")
        body = data.get("syllabus_body") if isinstance(data, dict) else None
        if body:
            return body
    except (SessionError, CanvasRefused):
        pass
    # Last resort: render the page and return its HTML (catches iframes the
    # API bodies would carry anyway, plus themes that hide the front page).
    page = context.new_page()
    try:
        page.goto(f"{host}/courses/{course_id}", wait_until="domcontentloaded",
                  timeout=60_000)
        try:
            page.wait_for_load_state("networkidle", timeout=12_000)
        except Exception:  # noqa: BLE001
            pass
        return page.content()
    finally:
        page.close()
