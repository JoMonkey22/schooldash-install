"""Calendars the student connected themselves — TeamSnap, Google Calendar,
and any other iCal URL (spec §4.7).

*"it should also be able to read other programs like teamsnap, albert.io,
google calendar, etc."*

**Why one module and not three.** TeamSnap, Google Calendar and a school
district's PowerSchool portal all offer the same thing: a per-user URL whose
token IS the URL, answering with iCalendar text and needing no login, no OAuth
app and no registration. [MEASURED] 2026-09-16 (research, with sources in
BUILDLOG): Google publishes one under Settings → Integrate calendar → "Secret
address in iCal format"; TeamSnap publishes a combined all-teams one under
My Full Schedule → Subscribe/Export; Canvas, Schoology, PowerSchool, Blackbaud
and Veracross all publish their own. Writing a module per vendor would be
writing the same twenty lines per vendor, so the vendor is a *kind* — a label,
a way of naming an event, a line of help text — and the reading is shared.
That is what makes the fifth one an afternoon.

**The boundary.** Everything here is a thing that HAPPENS: a game, a practice,
a shift, an appointment. None of it is work the student hands in, so none of
it becomes a `models.Item`; it becomes a `models.Event`, which the scorer
never sees. A soccer game cannot outrank a lab report because the two are
never in the same list. See models.Event's docstring.

**Failure.** One connection failing is one connection failing. Each is fetched
in its own try-block, a failed one falls back to the last good copy in the
cache (and says so), and the error is reported with a one-line fix. A
connection that has never been read once produces nothing and an error — never
a silent gap, never an empty board.

── The source contract ──────────────────────────────────────────────────────
Read this before writing the fifth integration; §4.8 of SPEC.md is the same
text. A source module in `sillybus/feeds/` exposes:

    enabled(cfg=None) -> bool          is this source switched on?
    read(cfg=None, ...) -> Result      do the work; NEVER raise
    summary() -> dict                  what the last read did, for diagnostics

and `Result` carries `items` and/or `events`, `errors` (dicts with code,
message and a one-line `fix`) and `warnings`. The rules, all of which this
module keeps and the next one must:

 1. Never raise into the pipeline. A source that throws takes the board with
    it; a source that returns an error gets a banner.
 2. Never erase. On failure, return the last good data and say it is old.
 3. Every dated thing carries a `date_note` saying where its date came from,
    in the student's words. `Item.finalize` and `Event.finalize` enforce it.
 4. Convert to `America/Phoenix` through `sillybus.timezones` before any
    date-level decision. Never a hardcoded offset.
 5. Config keys are declared in `config.DEFAULTS`, and any key holding a URL
    with a token in it is a credential: redacted in every reply, never logged,
    never printed, never committed, and deleted when the connection is.
 6. Switchable: `config["sources"][<name>]`, or — for anything the student
    adds themselves — an `enabled` flag on the entry.
 7. Cache under `paths.cache_dir()`, poll on the refresh cycle and not on
    render, and back off after a failure.
 8. A test with a golden file, built from a scrubbed fixture. A source module
    with no test does not ship.
─────────────────────────────────────────────────────────────────────────────
"""

import json
import re
import secrets
import time
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta

import httpx

from sillybus import config, models, paths, timezones
from sillybus.feeds import ical
from sillybus.logging_setup import get

log = get("calendars")

SOURCE_KINDS = {
    # kind -> (label, the sentence a date_note starts with)
    "google_calendar": ("Google Calendar", "from your Google Calendar"),
    "teamsnap": ("TeamSnap", "from your TeamSnap calendar"),
    # The other schools' systems. [RESEARCHED] 2026-09-18: Schoology (Account
    # Settings -> Share Your Schoology Calendar), PowerSchool (Class
    # Assignments -> Subscribe) and Blackbaud (calendar -> RSS/iCal) each hand
    # a student a per-user iCal address, and so does Canvas's own calendar.
    # A kind here is a label and a sentence — no new reader — which is the
    # whole point of the source contract (SPEC 4.8): the fifth integration
    # is an afternoon, and these four were twenty lines.
    "schoology": ("Schoology", "from your Schoology calendar"),
    "powerschool": ("PowerSchool", "from your PowerSchool calendar"),
    "blackbaud": ("Blackbaud", "from your Blackbaud calendar"),
    "canvas_calendar": ("Canvas calendar", "from your Canvas calendar feed"),
    "ical": ("Calendar", "from the calendar you connected"),
}
DEFAULT_KIND = "ical"
# How a pasted URL names itself. Checked in order; anything unrecognised is a
# plain iCal feed, which is the right answer for most of the internet.
URL_KINDS = [
    (re.compile(r"calendar\.google\.com/calendar/ical/", re.I), "google_calendar"),
    (re.compile(r"calendar\.google\.com/calendar/exporticalzip", re.I), "google_calendar"),
    (re.compile(r"\bteamsnap\.com\b", re.I), "teamsnap"),
    (re.compile(r"\bschoology\.com\b", re.I), "schoology"),
    (re.compile(r"\bpowerschool\.com\b|/public/.*\.ics", re.I), "powerschool"),
    (re.compile(r"\bblackbaud\.com\b|\bmyschoolapp\.com\b", re.I), "blackbaud"),
    (re.compile(r"\binstructure\.com/feeds/calendars/", re.I), "canvas_calendar"),
]
CACHE_DIR = "calendars"
# A cached copy older than this is still served when the fetch fails — it is
# better than nothing — but the board says how old it is.
FETCH_TIMEOUT = 30
# Google sends no ETag and no Last-Modified ([MEASURED] 2026-09-16: cache-control
# no-store, expires 1990), so there is nothing to revalidate against and every
# poll is a full download. That is the reason to poll on the refresh cycle and
# never on render.
MAX_BYTES = 8 * 1024 * 1024
# A team calendar carries a season; a personal one can carry a decade. Neither
# is worth holding in memory, so only the window is ever built into Events.

# ...and the window is five months now (config `event_window`), not two weeks,
# which is long enough that one busy family calendar could put thousands of
# rows on the board on its own. So there is a ceiling per connection, and when
# it is reached the board SAYS the furthest-off ones were left out. Silently
# truncating is the thing SPEC §5.5 forbids — "nothing hidden silently" — and
# a calendar that quietly stops in January is worse than one that stops in a
# fortnight, because nothing on screen admits it stopped.
MAX_EVENTS_PER_CONNECTION = 600

# What the summary line of a TeamSnap event tends to say. Used only to pick a
# label for the row — never to change a date, and never to drop anything.
GAME_WORDS = re.compile(r"\b(game|match|vs\.?|@|tournament|meet|scrimmage)\b", re.I)
PRACTICE_WORDS = re.compile(r"\b(practice|training|workout|lift|conditioning)\b", re.I)
SHIFT_WORDS = re.compile(r"\b(shift|work|working)\b", re.I)
APPOINTMENT_WORDS = re.compile(r"\b(appointment|appt|dentist|doctor|orthodont|haircut|dmv)\b", re.I)
MEETING_WORDS = re.compile(r"\b(meeting|council|rehearsal|mass|retreat|club)\b", re.I)

_last: dict = {"read": None, "connections": []}


@dataclass
class Result:
    """What a source hands the pipeline. See the contract above."""
    events: list = field(default_factory=list)
    items: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    status: list = field(default_factory=list)   # one entry per connection


class ConnectionError_(Exception):
    """Internal: a fetch that failed, with the sentence a person can act on."""

    def __init__(self, message: str, fix: str = "", no_cache: bool = False):
        super().__init__(message)
        self.message = message
        self.fix = fix
        # True when the last good copy must NOT be shown instead — it would be
        # someone else's calendar (a Google account that moved in Chrome).
        self.no_cache = no_cache


def enabled(cfg: dict | None = None) -> bool:
    cfg = cfg or config.load()
    return bool((cfg.get("sources") or {}).get("connections", True))


def kind_for_url(url: str) -> str:
    """Which program a pasted URL belongs to. Nothing depends on getting this
    right — it picks a label and a sentence — so an unknown URL is simply a
    calendar rather than a question the student has to answer."""
    for pattern, kind in URL_KINDS:
        if pattern.search(url or ""):
            return kind
    return DEFAULT_KIND


def suggested_name(url: str, kind: str) -> str:
    label = SOURCE_KINDS.get(kind, SOURCE_KINDS[DEFAULT_KIND])[0]
    if kind == "google_calendar":
        # .../calendar/ical/<calendar id>/private-<token>/basic.ics — the
        # calendar id is the owner's address and is not a secret; the token is.
        match = re.search(r"/calendar/ical/([^/]+)/", url or "")
        if match:
            who = match.group(1).replace("%40", "@").split("@")[0]
            if who and not who.startswith("private"):
                return f"Google Calendar — {who}"
    return label


def new_connection(url: str, name: str = "", kind: str = "") -> dict:
    kind = kind or kind_for_url(url)
    return {
        # The clock alone collides when two are added in the same millisecond,
        # and two connections sharing an id share a cache file and a Remove
        # button. The suffix costs nothing and removes the question.
        "id": f"conn-{int(time.time() * 1000):x}-{secrets.token_hex(3)}",
        "kind": kind if kind in SOURCE_KINDS else DEFAULT_KIND,
        "name": (name or suggested_name(url, kind)).strip()[:60],
        "url": url.strip(),
        "enabled": True,
        "added": datetime.now(timezones.zone()).date().isoformat(),
    }


# Hosts on this machine or its own network. A calendar lives on the internet,
# so refusing these costs nothing — and not refusing them turns "paste an
# address and I will tell you exactly how it answered" into a port scanner for
# anything else running on his Mac or his home network. The app is
# loopback-only and account-gated, so this is defence in depth rather than the
# only lock, but it is four lines.
PRIVATE_HOST = re.compile(
    r"^(localhost|127\.|0\.0\.0\.0$|10\.|192\.168\.|169\.254\.|::1$|\[::1\]$"
    r"|172\.(1[6-9]|2\d|3[01])\.)|(\.local|\.internal|\.lan)$", re.I)


def check_url(url: str) -> tuple[bool, str]:
    """Is this something worth saving? (ok, the sentence to show if not).

    Deliberately shallow: the scheme, the shape, and whether the host is on
    this machine. Whether the feed answers is decided by fetching it, which
    the caller does next and reports on — a guess here would only be a second,
    wronger opinion.
    """
    url = (url or "").strip()
    if not url:
        return False, "paste the calendar address first"
    if not re.match(r"^(https?|webcal)://", url, re.I):
        return False, ("that does not look like a calendar address — it should "
                       "start with https:// or webcal://")
    host = re.sub(r"^\w+://", "", url).split("/")[0].split("@")[-1]
    host = host.split(":")[0] if not host.startswith("[") else host
    if PRIVATE_HOST.search(host):
        return False, ("that address is on this computer or your own network, "
                       "not a calendar on the internet")
    return True, ""


def connection_key(url: str) -> str:
    """The same calendar however it was written: webcal:// and https://, the
    host's case, a trailing slash (round 7: a pasted webcal:// and the https://
    the TeamSnap link found were saved as two calendars, every event twice)."""
    url = _normalise(url).strip().rstrip("/")
    match = re.match(r"^(https?://)([^/]+)(.*)$", url, re.I)
    if not match:
        return url
    scheme, host, rest = match.groups()
    if is_google_export(url):
        return f"google:u{google_account_of(url)}"
    return "https://" + host.lower() + rest


def _normalise(url: str) -> str:
    """webcal:// is https:// wearing a hat: the scheme exists to make a
    calendar app open the link, and httpx has never heard of it."""
    url = (url or "").strip()
    if url.lower().startswith("webcal://"):
        return "https://" + url[len("webcal://"):]
    return url


def _cache_path(connection_id: str):
    safe = re.sub(r"[^A-Za-z0-9_.-]", "_", connection_id)[:64] or "unnamed"
    folder = paths.cache_dir() / CACHE_DIR
    folder.mkdir(parents=True, exist_ok=True)
    return folder / f"{safe}.ics"


def forget(connection_id: str) -> None:
    """Remove what was cached for a connection. Called when it is removed:
    deleting the URL and leaving its last download on disk would be keeping
    the data after being told to stop."""
    try:
        _cache_path(connection_id).unlink(missing_ok=True)
    except OSError as exc:
        log.warning("could not remove the cached copy: %s", type(exc).__name__)


# Google Calendar's own Export (Settings → Import & export), read with the
# Google sign-in Chrome already has. [ASKED] 2026-10-06: "by pass this for
# every one" — the secret iCal address needs a click on an eye icon on a
# settings page, and a school can switch it off. [MEASURED] 2026-10-06 on his
# school account: this address answers 200 application/zip with one .ics per
# calendar he owns (deflated), signed in; it holds no secret, so it is not a
# password in disguise the way a feed address is — it works only for whoever
# is signed in, and only inside Chrome (the extension's XHR, with
# credentials). The Mac app has no Google session and says so.
GOOGLE_EXPORT = "https://calendar.google.com/calendar/exporticalzip"
# The same export for the Nth Google account signed in to Chrome
# ([ASKED] 2026-10-07: "add a way to a mutipul google calender accounts I
# have 2"). [MEASURED] the same day in his Chrome: /calendar/u/0/ and /u/1/
# each answer 200 application/zip (different calendars), /u/2/ answers 403.
GOOGLE_EXPORT_N = re.compile(r"^https://calendar\.google\.com/calendar/(?:u/(\d)/)?exporticalzip$", re.I)


def is_google_export(url: str) -> bool:
    return bool(GOOGLE_EXPORT_N.match((url or "").strip().rstrip("/")))


def google_account_of(url: str) -> int:
    """Which signed-in Google account an export address reads (0 = the first)."""
    found = GOOGLE_EXPORT_N.match((url or "").strip().rstrip("/"))
    return int(found.group(1) or 0) if found else 0


def _unzip_calendars(blob: bytes) -> str:
    """Every .ics in Google's export zip as ONE calendar: the first file's
    header, then each file's time zones and events. Bounded before anything is
    inflated, so a hostile zip cannot fill memory."""
    import io
    import zipfile
    try:
        archive = zipfile.ZipFile(io.BytesIO(blob))
    except zipfile.BadZipFile:
        raise ConnectionError_("Google Calendar did not send a calendar",
                               "sign in to Google in Chrome, then try again") from None
    members = [m for m in archive.infolist() if not m.is_dir()]
    if sum(m.file_size for m in members) > MAX_BYTES:
        raise ConnectionError_("that calendar is too big to read in one go",
                               "link a single calendar with its secret address instead")
    head, blocks = "", []
    for member in members:
        text = archive.read(member).decode("utf-8", errors="replace")
        if "BEGIN:VCALENDAR" not in text.upper():
            continue
        if not head:
            head = text.split("BEGIN:VEVENT", 1)[0].split("BEGIN:VTIMEZONE", 1)[0]
        blocks += re.findall(r"BEGIN:VTIMEZONE.*?END:VTIMEZONE\r?\n?", text, re.S)
        blocks += re.findall(r"BEGIN:VEVENT.*?END:VEVENT\r?\n?", text, re.S)
    if not head:
        raise ConnectionError_("Google Calendar sent nothing to read",
                               "check you are signed in to the right Google account in Chrome")
    return head + "".join(blocks) + "END:VCALENDAR\r\n"


def google_ids(blob: bytes) -> list[str]:
    """Which calendars an export holds, as short one-way hashes of their ids
    (the ids are email addresses, so they are never stored as written).
    Chrome numbers its Google accounts /u/0/, /u/1/… and RENUMBERS them when
    one signs out (round 7, 2026-10-07: the other account's events then
    showed twice); these fingerprints say which account an export really is."""
    import hashlib
    import io
    import zipfile
    try:
        names = zipfile.ZipFile(io.BytesIO(blob)).namelist()
    except zipfile.BadZipFile:
        return []
    stems = sorted({n.rsplit("/", 1)[-1][:-4].lower() for n in names if n.lower().endswith(".ics")})
    return [hashlib.sha256(("sillybus-gcal|" + s).encode()).hexdigest()[:12] for s in stems]


def same_google_account(a, b) -> bool:
    """Half or more of the calendars in common: the same account (a shared
    calendar or two can overlap between different accounts; most cannot)."""
    a, b = set(a or []), set(b or [])
    if not a or not b:
        return False
    return len(a & b) * 2 >= min(len(a), len(b))


# What the last fetch of each export address found, for the route that links
# it (post_connection records the fingerprints with the connection).
LAST_GOOGLE_IDS: dict[str, list[str]] = {}


def _google_blob(url: str) -> bytes | None:
    if not getattr(httpx, "IS_CHROME_SHIM", False):
        import base64
        from sillybus import bridge
        captured = bridge.captured(url, "Google Calendar")
        if captured and captured.startswith("sillybus-google-zip:"):
            try:
                return base64.b64decode(captured.split(":", 1)[1], validate=True)
            except ValueError:
                return None
        return None
    response = httpx.get(url, timeout=FETCH_TIMEOUT, follow_redirects=True, with_credentials=True)
    blob = response.content or b""
    if response.status_code in (401, 403) or not blob.startswith(b"PK"):
        return None
    return blob


def _fetch_google_export(url: str = GOOGLE_EXPORT, expect: list | None = None) -> str:
    url = (url or GOOGLE_EXPORT).strip().rstrip("/")
    blob = _google_blob(url)
    if blob is None and not getattr(httpx, "IS_CHROME_SHIM", False) and expect:
        # The Mac app has no fresh copy from Chrome (Chrome closed, or not
        # run for four hours). That is "waiting", not "this account left" —
        # the last good copy stays on the board (2026-10-07: treating it as
        # a moved account erased his Google events whenever Chrome was shut).
        raise ConnectionError_("Waiting for Chrome to read Google Calendar again",
                               "open Chrome — the SillyBus AI extension sends it every few minutes")
    if blob is None and not expect:
        if not getattr(httpx, "IS_CHROME_SHIM", False):
            raise ConnectionError_("Waiting for the SillyBus AI Chrome extension to read Google Calendar",
                                   "connect the extension to the Mac app, then use Link this page on Google Calendar")
        raise ConnectionError_("Google Calendar did not let SillyBus in",
                               "sign in to Google in Chrome (calendar.google.com), then press Refresh")
    if expect and (blob is None or not same_google_account(google_ids(blob), expect)):
        # The account moved to another number in Chrome: find it.
        here = google_account_of(url)
        blob = None
        for n in range(5):
            if n == here:
                continue
            other = _google_blob(f"https://calendar.google.com/calendar/u/{n}/exporticalzip")
            if other is not None and same_google_account(google_ids(other), expect):
                log.info("a linked Google account moved from account %d to %d in Chrome", here + 1, n + 1)
                blob = other
                break
        if blob is None:
            raise ConnectionError_(
                "this Google account is not signed in to Chrome any more",
                "sign in to it in Chrome, or remove this calendar in Settings → Connections",
                no_cache=True)
    LAST_GOOGLE_IDS[url] = google_ids(blob)
    return _unzip_calendars(blob)


def _fetch(url: str, expect: list | None = None) -> str:
    if is_google_export(url):
        return _fetch_google_export(url, expect)
    response = httpx.get(_normalise(url), timeout=FETCH_TIMEOUT,
                         follow_redirects=True,
                         headers={"User-Agent": "sillybus/1.0"})
    # Asked before the body is read. Checking `len(response.text)` afterwards
    # bounds nothing — by then the whole thing is already in memory, which is
    # the thing the cap exists to prevent.
    declared = response.headers.get("content-length")
    if declared and declared.isdigit() and int(declared) > MAX_BYTES:
        raise ConnectionError_(
            "that calendar is too big to read in one go",
            "connect a single calendar rather than an everything feed")
    if response.status_code == 404:
        raise ConnectionError_(
            "that calendar address is not there any more (404)",
            "the program may have reset the link — copy it again and paste the new one")
    if response.status_code in (401, 403):
        raise ConnectionError_(
            "that calendar address was refused (it may have been reset)",
            "copy the address again from the program and paste the new one")
    response.raise_for_status()
    text = response.text
    if len(text.encode("utf-8", "ignore")) > MAX_BYTES:
        raise ConnectionError_(
            "that calendar is too big to read in one go",
            "connect a single calendar rather than an everything feed")
    if "BEGIN:VCALENDAR" not in text.upper():
        raise ConnectionError_(
            "that address answered, but not with a calendar",
            "check you copied the iCal/ICS address and not the web page's address")
    return text


def _read_one(entry: dict, window_start: date, window_end: date,
              now: datetime) -> tuple[list, dict]:
    """One connection: (events, status). Never raises."""
    connection_id = entry.get("id") or "unnamed"
    label = SOURCE_KINDS.get(entry.get("kind"), SOURCE_KINDS[DEFAULT_KIND])[0]
    status = {"id": connection_id, "name": entry.get("name") or label,
              "kind": entry.get("kind") or DEFAULT_KIND, "label": label,
              "enabled": bool(entry.get("enabled", True)),
              "events": 0, "last_read": None, "error": None, "fix": None,
              "from_cache": False, "note": None}
    if not status["enabled"]:
        status["note"] = "switched off"
        return [], status

    cache = _cache_path(connection_id)
    text = None
    try:
        ids = entry.get("google_ids")
        text = _fetch(entry.get("url") or "", ids) if ids else _fetch(entry.get("url") or "")
        try:
            cache.write_text(text, encoding="utf-8")
        except OSError as exc:                     # a full disk is not a read failure
            log.warning("could not cache %s: %s", connection_id, type(exc).__name__)
        status["last_read"] = now.isoformat(timespec="seconds")
    except (ConnectionError_, httpx.HTTPError, OSError) as exc:
        message = getattr(exc, "message", None) or _plain(exc)
        status["error"] = message
        status["fix"] = getattr(exc, "fix", "") or \
            "check the address in Settings → Connections, or try again in a moment"
        # Rule 2: never erase. The last good copy is better than nothing, and
        # saying how old it is beats pretending it is today's — unless it would
        # be someone else's calendar (a Google account that left Chrome).
        if cache.exists() and not getattr(exc, "no_cache", False):
            try:
                text = cache.read_text(encoding="utf-8")
                status["from_cache"] = True
                read_at = datetime.fromtimestamp(cache.stat().st_mtime,
                                                 timezones.zone())
                status["last_read"] = read_at.isoformat(timespec="seconds")
                hours = max(0, int((now - read_at).total_seconds() // 3600))
                status["note"] = (f"showing what was read {hours} h ago — "
                                  "this refresh could not reach it")
            except (OSError, ValueError):
                text = None
        if text is None:
            return [], status

    try:
        parsed = ical.parse(text)
        occurrences = ical.expand(parsed, window_start, window_end)
    except Exception as exc:                        # a malformed feed, not a crash
        log.warning("could not read %s: %s", connection_id, type(exc).__name__)
        status["error"] = "that calendar could not be read"
        status["fix"] = "check the address in Settings → Connections"
        return [], status

    events = []
    unsupported = 0
    for raw in occurrences:
        event = _to_event(raw, entry, status)
        if event is None:
            continue
        if raw.get("recurrence_unsupported"):
            unsupported += 1
        events.append(event)
    # Nearest first, so that if the ceiling is hit the ones kept are the ones
    # the student is actually about to live through.
    events.sort(key=lambda e: (e.date, e.start or ""))
    if len(events) > MAX_EVENTS_PER_CONNECTION:
        dropped = len(events) - MAX_EVENTS_PER_CONNECTION
        events = events[:MAX_EVENTS_PER_CONNECTION]
        status["note"] = ((status["note"] + " · ") if status["note"] else "") + \
            (f"this calendar has more than {MAX_EVENTS_PER_CONNECTION} events in "
             f"the window, so the {dropped} furthest off are not shown")
    status["events"] = len(events)
    if unsupported:
        status["note"] = ((status["note"] + " · ") if status["note"] else "") + \
            (f"{unsupported} repeating event(s) use a pattern this app does not "
             "read yet, so only the first of each is shown")
    return events, status


def _plain(exc: Exception) -> str:
    """An httpx failure in words, and never the URL — which is the token."""
    name = type(exc).__name__
    if isinstance(exc, httpx.TimeoutException):
        return "that calendar took too long to answer"
    if isinstance(exc, httpx.HTTPStatusError):
        return f"that calendar answered with an error ({exc.response.status_code})"
    if isinstance(exc, httpx.TransportError):
        return "could not reach that calendar (no connection?)"
    return f"that calendar could not be read ({name})"


def classify(summary: str, kind: str) -> str:
    """Which word the board puts on the row. Never changes a date and never
    drops anything: the worst case is a game labelled "event"."""
    text = summary or ""
    if PRACTICE_WORDS.search(text):
        return "practice"
    if GAME_WORDS.search(text):
        return "game"
    if APPOINTMENT_WORDS.search(text):
        return "appointment"
    if SHIFT_WORDS.search(text):
        return "shift"
    if MEETING_WORDS.search(text):
        return "meeting"
    # Anything else is an event. A TeamSnap feed is a team's calendar, so the
    # temptation is to call its unlabelled rows games — but a team also has
    # dinners, photo days and bus calls, and "game" on one of those is the app
    # telling him something the calendar did not say.
    return "event"


def _when_phrase(start, all_day: bool) -> str:
    """"4:00 pm Thursday" / "all day Saturday" — the half of the date_note
    that tells him he can trust it, in the words he would use himself."""
    if all_day or not isinstance(start, datetime):
        day = start if isinstance(start, date) else None
        return f"all day {day.strftime('%A')}" if day else "all day"
    clock = start.strftime("%-I:%M %p").lower() if hasattr(start, "strftime") else ""
    return f"{clock} {start.strftime('%A')}".strip()


def _to_event(raw: dict, entry: dict, status: dict) -> models.Event | None:
    title = (raw.get("summary") or "").strip()
    if not title:
        return None
    kind = entry.get("kind") or DEFAULT_KIND
    start, end = raw.get("dtstart"), raw.get("dtend")
    if start is None:
        return None
    all_day = bool(raw.get("all_day")) or not isinstance(start, datetime)

    if isinstance(start, datetime):
        local = timezones.to_local(start)
        day, start_iso = local.date().isoformat(), local.isoformat()
    else:
        local = None
        day, start_iso = start.isoformat(), None
    end_iso = end_day = None
    if isinstance(end, datetime):
        local_end = timezones.to_local(end)
        end_iso, end_day = local_end.isoformat(), local_end.date().isoformat()
    elif isinstance(end, date):
        # An all-day DTEND is EXCLUSIVE in iCalendar: a one-day event ends the
        # NEXT morning. Subtracting the day is the difference between a game
        # on Saturday and a game "Saturday to Sunday".
        end_day = (end - timedelta(days=1)).isoformat()
    # A TIMED event ending at exactly midnight ends the night it started: a
    # shift written 20:00–00:00 is one evening, not two days. (The all-day
    # case above is different and already handled — there DTEND is exclusive
    # by the spec, here it is a real clock time that happens to be 00:00.)
    if end_day and isinstance(end, datetime) and end_iso and end_iso[11:16] == "00:00":
        end_day = None
    if end_day and end_day <= day:
        end_day = None

    where = (raw.get("location") or "").strip()
    note_lead = SOURCE_KINDS.get(kind, SOURCE_KINDS[DEFAULT_KIND])[1]
    name = (entry.get("name") or "").strip()
    if name and name.lower() not in note_lead.lower():
        note_lead = f"{note_lead} ({name})"
    date_note = f"{note_lead}, {_when_phrase(local or start, all_day)}"
    if status.get("from_cache"):
        date_note += " — read before this refresh, which could not reach it"

    url = (raw.get("url") or "").strip()
    link_kind = "teamsnap" if kind == "teamsnap" else "calendar"
    detail = " · ".join(filter(None, [
        where,
        (raw.get("description") or "").strip().replace("\n", " ")[:200],
    ]))
    event = models.Event(
        source=kind,
        connection_id=entry.get("id") or "unnamed",
        connection=name or SOURCE_KINDS.get(kind, SOURCE_KINDS[DEFAULT_KIND])[0],
        title=title[:110],
        date=day,
        start=start_iso,
        end=end_iso,
        end_date=end_day,
        all_day=all_day,
        location=where[:120],
        detail=detail,
        kind=classify(title, kind),
        date_note=date_note,
        confidence="medium" if status.get("from_cache") else "high",
        url=url or None,
        links=[models.Link(url=url, text=title[:60], kind=link_kind)] if url else [],
        flags=["from_cache"] if status.get("from_cache") else [],
    )
    return event.finalize()


def read(cfg: dict | None = None, today: date | None = None,
         now: datetime | None = None) -> Result:
    """Every enabled connection, read into Events. NEVER raises (contract §1)."""
    cfg = cfg or config.load()
    result = Result()
    if not enabled(cfg):
        _remember(None, [])
        return result
    entries = config.connections(cfg)
    if not entries:
        _remember(now, [])
        return result

    now = now or datetime.now(timezones.zone())
    today = today or now.date()
    # `event_window`, NOT `window`. The homework window is fourteen days and
    # should stay fourteen days; a season is five months. Falls back to the
    # defaults rather than to `window`, so an old config.json written before
    # this key existed reads the whole season too instead of silently keeping
    # the fortnight it used to have.
    window = cfg.get("event_window") or config.DEFAULTS["event_window"]
    window_start = today - timedelta(days=int(window.get("days_back", 14)))
    window_end = today + timedelta(days=int(window.get("days_forward", 150)))

    for entry in entries:
        try:
            events, status = _read_one(entry, window_start, window_end, now)
        except Exception as exc:                    # contract §1, belt and braces
            log.warning("connection %s blew up: %s",
                        entry.get("id"), type(exc).__name__)
            events = []
            status = {"id": entry.get("id"), "name": entry.get("name") or "calendar",
                      "kind": entry.get("kind"), "enabled": True, "events": 0,
                      "last_read": None, "from_cache": False, "note": None,
                      "error": "that calendar could not be read",
                      "fix": "check the address in Settings → Connections"}
        result.events.extend(events)
        result.status.append(status)
        if status.get("error"):
            name = status.get("name") or "a calendar"
            result.errors.append({
                "code": f"connection:{status.get('id')}",
                "message": f"{name}: {status['error']}"
                           + (" — showing the last copy that worked"
                              if status.get("from_cache") else ""),
                "fix": status.get("fix") or "",
            })
    result.events.sort(key=lambda e: (e.date, e.start or ""))
    _remember(now, result.status)
    return result


def _remember(now, status) -> None:
    _last["read"] = now.isoformat(timespec="seconds") if now else None
    _last["connections"] = status


def summary() -> dict:
    """What the last read did, for `/api/state`'s diagnostics. Carries no URL
    — `_read_one` never puts one in a status, and this is why."""
    return {"read_at": _last["read"],
            "connections": _last["connections"],
            "events": sum(c.get("events") or 0 for c in _last["connections"])}
