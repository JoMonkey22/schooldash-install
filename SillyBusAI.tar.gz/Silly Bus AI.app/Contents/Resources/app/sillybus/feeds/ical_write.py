"""Writing iCalendar, so the board can be put INTO another calendar.

*"add stuff to google calender based on teamsnap and other things"*

`feeds/ical.py` is the reader and stays the reader; this is the other
direction and is deliberately a second module. Reading someone else's feed and
writing your own are different jobs with different failure modes — a parser
must survive anything the internet hands it, and a writer must emit exactly
what the spec says — and one file doing both is one file with two reasons to
change.

**Why a file and not a sync.** Google Calendar can be written to three ways:
its API (OAuth, a Google Cloud project, a consent screen — forbidden outright
by SPEC §5.3), a URL it subscribes to (needs an address Google's servers can
reach, and this app is loopback-only by §5.7), or an **import**. Import is the
one that breaks no constraint, and it is not a lesser thing: Google's import
creates real events in the real calendar. What it costs is that a person
presses a button instead of it happening by itself.

**Re-importing must not duplicate.** That is what makes this usable over a
season rather than once. Every VEVENT carries a UID that is stable for the
thing it describes — the event's own occurrence id, the assignment's own item
id — so a second import of a changed file UPDATES those events instead of
laying a second copy beside them. `SEQUENCE` goes up with the content hash so
a client that ignores a bare change still takes the newer one. Get the UID
wrong and a student has three of every game by November, which is worse than
having none.

**What it will not do.** It does not invent a duration. A deadline is a moment,
so an assignment with a due *time* is written with `DTSTART` and no `DTEND`,
which RFC 5545 §3.6.1 defines as ending at the same instant; padding it to
"about half an hour" would be inventing a fact about someone's homework, and
this app does not do that anywhere else either.
"""

from __future__ import annotations

import hashlib
from datetime import date, datetime, timedelta, timezone

from sillybus.logging_setup import get

log = get("ical_write")

PRODID = "-//SillyBus AI//Homework and events//EN"
# The domain half of a UID. It is never resolved and never contacted; RFC 5545
# only asks that a UID be globally unique, and a fixed suffix on ids that are
# already unique within this app achieves that without leaking anything.
UID_HOST = "sillybus.local"
MAX_LINE_OCTETS = 75


# --------------------------------------------------------------------------
# the mechanics RFC 5545 actually requires


def escape(value: str) -> str:
    """Text as a property value: backslash, semicolon, comma and newline.

    Order matters — the backslash has to go first or it doubles the escapes
    that follow it.
    """
    out = (value or "").replace("\\", "\\\\")
    out = out.replace("\r\n", "\\n").replace("\r", "\\n").replace("\n", "\\n")
    return out.replace(";", "\\;").replace(",", "\\,")


def fold(line: str) -> str:
    """Fold to 75 OCTETS, not characters, without splitting a character.

    The distinction is the whole point: a course called "Español" is more
    bytes than it is letters, and folding on a character count puts the break
    in the wrong place on exactly the lines that carry an accent. Splitting
    mid-character would produce invalid UTF-8, which some clients render as a
    replacement glyph and others reject outright.
    """
    raw = line.encode("utf-8")
    if len(raw) <= MAX_LINE_OCTETS:
        return line
    chunks, start = [], 0
    limit = MAX_LINE_OCTETS
    while start < len(raw):
        end = min(start + limit, len(raw))
        # back off until `end` sits on a character boundary
        while end > start and end < len(raw) and (raw[end] & 0xC0) == 0x80:
            end -= 1
        chunks.append(raw[start:end].decode("utf-8"))
        start = end
        limit = MAX_LINE_OCTETS - 1      # continuations spend one octet on the space
    return "\r\n ".join(chunks)


def _stamp(value: datetime) -> str:
    """A UTC timestamp. Everything timed is written in UTC on purpose: it
    needs no VTIMEZONE block, it cannot be misread by a client with a stale
    zone database, and Google converts it back to the reader's own zone."""
    return value.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _day(value: date) -> str:
    return value.strftime("%Y%m%d")


def _when(text: str | None) -> datetime | None:
    """A tz-aware ISO string from the board, or None. Never raises: one
    unreadable date costs that row, not the export."""
    if not text:
        return None
    try:
        parsed = datetime.fromisoformat(text)
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:                 # a naive string cannot be placed
        return None
    return parsed


def _date(text: str | None) -> date | None:
    if not text:
        return None
    try:
        return date.fromisoformat(text[:10])
    except (TypeError, ValueError):
        return None


def uid(kind: str, key: str) -> str:
    """Stable for the thing, unique across kinds.

    `key` is already unique within its kind (`event_id`, `item_id`), and the
    kind prefix keeps an assignment and an event that happened to share an id
    from colliding in the calendar they are both imported into.
    """
    safe = "".join(ch for ch in (key or "") if ch.isalnum() or ch in "-_.")
    if not safe:                              # nothing usable: hash whatever came
        safe = hashlib.sha256((key or "").encode("utf-8")).hexdigest()[:16]
    return f"{kind}-{safe}@{UID_HOST}"


def _sequence(*parts: str) -> int:
    """A number that changes when the content does, so a client that has seen
    this UID takes the newer copy. Not a counter — nothing here remembers a
    previous export — but a stable hash of what is being written, which is
    enough for "different from what you have"."""
    digest = hashlib.sha256("\x1f".join(p or "" for p in parts).encode("utf-8"))
    return int.from_bytes(digest.digest()[:3], "big")       # 0 .. 16_777_215


# --------------------------------------------------------------------------
# the two shapes


def event_lines(event: dict, now: datetime) -> list[str]:
    """One VEVENT for something that HAPPENS — a game, a practice, a shift."""
    title = (event.get("title") or "").strip() or "Event"
    day = _date(event.get("date"))
    if day is None:
        return []
    lines = ["BEGIN:VEVENT",
             f"UID:{uid('event', event.get('event_id') or '')}",
             f"DTSTAMP:{_stamp(now)}"]

    start = _when(event.get("start"))
    if event.get("all_day") or start is None:
        # DTEND on an all-day event is EXCLUSIVE — the day after the last one.
        # Off by one here shows up as a tournament that ends the night before
        # it does, which is the classic iCalendar mistake.
        last = _date(event.get("end_date")) or day
        lines.append(f"DTSTART;VALUE=DATE:{_day(day)}")
        lines.append(f"DTEND;VALUE=DATE:{_day(last + timedelta(days=1))}")
    else:
        lines.append(f"DTSTART:{_stamp(start)}")
        end = _when(event.get("end"))
        if end and end > start:
            lines.append(f"DTEND:{_stamp(end)}")

    lines.append(f"SUMMARY:{escape(title)}")
    if event.get("location"):
        lines.append(f"LOCATION:{escape(event['location'])}")

    # The date_note travels with it. Every dated thing in this app says where
    # its date came from (SPEC §5.9), and an event that leaves for another
    # calendar should not shed the one sentence that makes it checkable.
    detail = " · ".join(p for p in ((event.get("detail") or "").strip(),
                                    (event.get("date_note") or "").strip()) if p)
    where = event.get("connection") or ""
    if where:
        detail = (detail + " · " if detail else "") + f"from {where}, via SillyBus AI"
    if detail:
        lines.append(f"DESCRIPTION:{escape(detail)}")
    if event.get("url"):
        lines.append(f"URL:{escape(event['url'])}")
    lines.append("CATEGORIES:SillyBus,Personal")
    lines.append(f"SEQUENCE:{_sequence(title, event.get('date'), event.get('start'), detail)}")
    lines.append("END:VEVENT")
    return lines


def item_lines(item: dict, now: datetime) -> list[str]:
    """One VEVENT for a piece of WORK, placed at the moment it is due."""
    title = (item.get("title") or "").strip() or "Assignment"
    course = (item.get("course") or "").strip()
    summary = f"{course}: {title}" if course else title
    due_day = _date(item.get("due_date")) or _date(item.get("due"))
    if due_day is None:
        return []                             # undated work is not a calendar row

    lines = ["BEGIN:VEVENT",
             f"UID:{uid('work', item.get('item_id') or '')}",
             f"DTSTAMP:{_stamp(now)}"]
    due = _when(item.get("due"))
    if item.get("all_day") or due is None:
        lines.append(f"DTSTART;VALUE=DATE:{_day(due_day)}")
        lines.append(f"DTEND;VALUE=DATE:{_day(due_day + timedelta(days=1))}")
    else:
        # No DTEND. A deadline is an instant, and RFC 5545 §3.6.1 reads a
        # DATE-TIME DTSTART with no DTEND as ending at that same instant.
        lines.append(f"DTSTART:{_stamp(due)}")

    lines.append(f"SUMMARY:{escape(summary)}")
    detail = " · ".join(p for p in ((item.get("detail") or "").strip(),
                                    (item.get("date_note") or "").strip()) if p)
    detail = (detail + " · " if detail else "") + "from SillyBus AI"
    lines.append(f"DESCRIPTION:{escape(detail)}")
    if item.get("url"):
        lines.append(f"URL:{escape(item['url'])}")
    lines.append("CATEGORIES:SillyBus,Homework")
    lines.append(f"SEQUENCE:{_sequence(summary, item.get('due'), item.get('due_date'), detail)}")
    lines.append("END:VEVENT")
    return lines


# --------------------------------------------------------------------------


def build(events: list | None = None, items: list | None = None, *,
          now: datetime | None = None, name: str = "SillyBus AI") -> str:
    """The whole calendar, as iCalendar text with CRLF endings.

    Never raises on one bad row: a row that cannot be written is skipped and
    counted in the log, because an export that fails completely because of a
    single malformed date is an export nobody can use.
    """
    now = now or datetime.now(timezone.utc)
    out = ["BEGIN:VCALENDAR",
           "VERSION:2.0",
           f"PRODID:{PRODID}",
           "CALSCALE:GREGORIAN",
           # PUBLISH is what an importer expects; REQUEST would make every row
           # look like a meeting invitation the student has to answer.
           "METHOD:PUBLISH",
           f"X-WR-CALNAME:{escape(name)}"]
    skipped = 0
    for event in (events or []):
        try:
            lines = event_lines(event, now)
        except Exception:                     # noqa: BLE001 — one row, not the file
            lines, skipped = [], skipped + 1
        if not lines:
            skipped += 1
        out.extend(lines)
    for item in (items or []):
        if item.get("done"):
            continue                          # finished work is not a deadline
        try:
            lines = item_lines(item, now)
        except Exception:                     # noqa: BLE001
            lines, skipped = [], skipped + 1
        if not lines:
            skipped += 1
        out.extend(lines)
    out.append("END:VCALENDAR")
    if skipped:
        log.info("export skipped %d row(s) with no usable date", skipped)
    return "\r\n".join(fold(line) for line in out) + "\r\n"


def counts(events: list | None = None, items: list | None = None) -> dict:
    """What an export WOULD contain, for the button to say so before it is
    pressed. Cheap: it counts dates, it does not build the file."""
    datable = [e for e in (events or []) if _date(e.get("date"))]
    work = [i for i in (items or [])
            if not i.get("done") and (_date(i.get("due_date")) or _date(i.get("due")))]
    return {"events": len(datable), "work": len(work),
            "total": len(datable) + len(work)}
