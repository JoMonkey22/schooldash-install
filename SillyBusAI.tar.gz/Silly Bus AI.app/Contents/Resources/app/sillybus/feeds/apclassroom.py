"""AP Classroom assignments — a secondary feed, read from a hand-off file.

AP Classroom (apclassroom.collegeboard.org) authorises every API call with a
Bearer token that lives in the page's own localStorage, not a cookie, so the
cookie-carrying fetch that reads Canvas and Veracross gets nothing there. The
Chrome extension therefore does the reading ON the AP Classroom page itself
(extension/apclassroom.js, a content script) and hands this module only the
assignments — title, subject, due date, status, link. The token never leaves
the site and never reaches Python. See extension/APCLASSROOM.md.

The hand-off is a JSON file in the cache directory, written by
boot.apply_apclassroom just before each refresh:

    {"read_at": "2026-09-14T13:05:00-07:00",
     "assignments": [{"id": "123", "subject": "AP Calculus BC", "subject_id": "26",
                      "title": "Unit 1 Progress Check: MCQ Part A",
                      "due": "2026-09-18T23:59:00-07:00", "status": "assigned",
                      "url": "https://apclassroom.collegeboard.org/26/assignments/123",
                      "kind": "Progress Check"}],
     "error": null}

or, when the page could not be read, {"read_at": ..., "error": "…"} — which
becomes an error banner with a Sign in button, never a silent gap.

The Mac app never writes this file, so on the Mac the feed yields nothing and
says nothing. Items enter the pipeline through merge_secondary: appended only
when no Canvas or doc item already covers the same work, so the "APCR" a
teacher typed into the homepage doc and the same assignment from AP Classroom
become one item, with the AP Classroom link kept.
"""

import json
import re
from datetime import datetime, timedelta

from sillybus import config, models, paths, timezones
from sillybus.logging_setup import get

log = get("apclassroom")

SOURCE = "ap_classroom"
FILE_NAME = "apclassroom.json"
# A hand-off older than this is treated as missing: the extension writes a
# fresh one before every refresh, so a stale file means the pull stopped
# happening and the board must not keep showing a week-old due date as news.
STALE_AFTER = timedelta(hours=36)
SIGN_IN_URL = "https://apclassroom.collegeboard.org/"

# Statuses AP Classroom uses for work that is finished ([MEASURED] 2026-09-14:
# an open assignment is "opened"; submissions carry submitted_at). Anything
# else is open.
DONE_STATUSES = {"completed", "complete", "submitted", "scored", "graded", "closed"}
# The list's `type` field, in the student's words.
KINDS = {"ppc": "Progress Check", "teacher-authored": "teacher quiz", "fym": "practice",
         "video": "AP Daily video", "practice": "practice", "quiz": "quiz"}
# An assignment with no due date is open practice, not a deadline. The ones
# opened recently belong on the board (the teacher just posted them); ones
# opened long ago would sit there for ever — [MEASURED] 2026-09-14: 56 of 59
# assignments were undated Physics C quizzes opened over the year. Those are
# flagged here, still offered to the merge (a dated doc item that names the
# same progress check gains the AP Classroom link), and the ones nothing
# absorbed are dropped by the pipeline and COUNTED in the run's diagnostics.
UNDATED_KEEP_DAYS = 14
UNDATED_OLD_FLAG = "ap_undated_old"
# The teacher's shorthand for "do a Progress Check in AP Classroom" — Physics
# C writes "APCR", "APCR's (2 of them)"; others write "Progress Check".
APCR_TITLE = re.compile(r"\bAPCRs?\b|\bAPCR[’']s\b|\bprogress\s*check", re.IGNORECASE)
APCR_COUNT = re.compile(r"\((\d+)\s+of\s+them\)", re.IGNORECASE)
UNIT_IN_TITLE = re.compile(r"\bunit\s*(\d+)", re.IGNORECASE)
# Matched with a word boundary so "AP Physics C: Mechanics" and "Advanced
# Placement Physics C" meet in the middle.
_STRIP = re.compile(r"\b(ap|advanced placement|honors|h)\b", re.IGNORECASE)


def handoff_path():
    return paths.cache_dir() / FILE_NAME


def enabled(cfg: dict | None = None) -> bool:
    cfg = cfg or config.load()
    sources = cfg.get("sources") or {}
    return bool(sources.get("ap_classroom", True))


def load_handoff(now: datetime | None = None) -> dict | None:
    """The hand-off as written, or None when there is none. A stale file is
    returned with error set so the caller can say why nothing is shown."""
    path = handoff_path()
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        log.warning("apclassroom hand-off unreadable: %s", type(exc).__name__)
        return {"read_at": None, "assignments": [], "error": "the hand-off file could not be read"}
    if not isinstance(data, dict):
        return {"read_at": None, "assignments": [], "error": "the hand-off file is not an object"}
    now = now or datetime.now(timezones.zone())
    read_at = _parse_when(data.get("read_at"))
    if read_at and now - read_at > STALE_AFTER and not data.get("error"):
        age_h = int((now - read_at).total_seconds() // 3600)
        data = dict(data, error=f"AP Classroom was last read {age_h} hours ago; "
                                "open AP Classroom in Chrome and SillyBus reads it as it loads")
    return data


def _parse_when(value) -> datetime | None:
    if not value or not isinstance(value, str):
        return None
    try:
        stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if stamp.tzinfo is None:
        stamp = stamp.replace(tzinfo=timezones.zone())
    return timezones.to_local(stamp)


def _tokens(name: str) -> set[str]:
    cleaned = _STRIP.sub(" ", name or "")
    return {t for t in re.findall(r"[a-z0-9]+", cleaned.lower()) if len(t) > 1}


def match_course(subject: str, known: dict[str, str]) -> tuple[str, str]:
    """(course_key, display name) for an AP Classroom subject.

    `known` maps course_key -> course_raw from the class schedule. The subject
    "AP Calculus BC" and the class "AP Calculus BC-Smith-YR_26/27" share every
    meaningful word; "AP Physics C: Mechanics" and "Advanced Placement Physics
    C" share "physics" and "c". The best overlap wins when it covers at least
    half of the shorter name; otherwise the subject stands as its own course,
    which is visible on the board rather than silently misfiled.
    """
    want = _tokens(subject)
    best_key, best_score = "", 0.0
    for key, raw in known.items():
        have = _tokens(models.norm_course(raw)) or _tokens(raw)
        if not want or not have:
            continue
        overlap = len(want & have) / min(len(want), len(have))
        if overlap > best_score:
            best_key, best_score = key, overlap
    if best_key and best_score >= 0.5:
        return best_key, known[best_key]
    return models.course_key_from_raw(subject), subject


def _to_item(entry: dict, known: dict[str, str], read_at: str,
             now: datetime | None = None) -> models.Item | None:
    now = now or datetime.now(timezones.zone())
    title = (entry.get("title") or "").strip()
    subject = (entry.get("subject") or "").strip()
    if not title:
        return None
    course_key, course = match_course(subject, known) if subject else ("unknown-course", "(no course)")
    due = due_date = None
    all_day = False
    when = _parse_when(entry.get("due"))
    if when:
        due, due_date = when.isoformat(), when.date().isoformat()
        all_day = when.hour == 0 and when.minute == 0
        date_note = f"AP Classroom due date, read {read_at[:16].replace('T', ' ')}"
    else:
        date_note = "AP Classroom lists this without a due date"
    status = (entry.get("status") or "").strip().lower()
    url = entry.get("url") or ""
    if not url and entry.get("subject_id") and entry.get("id"):
        url = f"https://apclassroom.collegeboard.org/{entry['subject_id']}/assignments/{entry['id']}"
    raw_kind = (entry.get("kind") or "").strip().lower()
    kind = KINDS.get(raw_kind, raw_kind or "assignment")
    submitted_at = entry.get("submitted")
    done = bool(submitted_at) or status in DONE_STATUSES
    score, max_score = entry.get("score"), entry.get("max_score")
    state = (entry.get("state") or ("submitted" if done else "")).strip()
    questions = entry.get("questions") if isinstance(entry.get("questions"), dict) else {}
    timer = entry.get("timer")
    detail_bits = [subject, f"AP Classroom {kind}"]
    if state:
        detail_bits.append(state)
    elif status:
        detail_bits.append(f"status: {status}")
    q_bits = [f"{n} {label}" for key, label in (("mcq", "MCQ"), ("frq", "FRQ")) for n in [questions.get(key)] if n]
    if q_bits:
        detail_bits.append(", ".join(q_bits))
    if isinstance(timer, (int, float)) and timer:
        detail_bits.append(f"{int(timer)} min timer")
    if score is not None and max_score:
        detail_bits.append(f"score {score}/{max_score}")
    item = models.Item(
        source=SOURCE,
        course_key=course_key,
        course=course or "(no course)",
        title=title[:110],
        detail=" · ".join(filter(None, detail_bits)) or title,
        raw_cell=json.dumps({"id": entry.get("id"), "subject_id": entry.get("subject_id"),
                             "status": status, "kind": kind, "state": state,
                             "unit": _unit_of(title), "results_url": entry.get("results_url")}),
        kind=f"AP Classroom {kind}",
        due=due,
        due_date=due_date,
        all_day=all_day,
        date_note=date_note,
        confidence="high" if when else "medium",
        extractor="canvas_stated",
        points=float(max_score) if isinstance(max_score, (int, float)) and max_score else None,
        submitted=True if done else (False if status else None),
        url=url or None,
        links=[models.Link(url=url, text="Open in AP Classroom", kind="ap_classroom")] if url else [],
        flags=[UNDATED_OLD_FLAG] if _too_old_to_show(entry, now) else [],
    )
    return item.finalize()


def _unit_of(title: str) -> int | None:
    match = UNIT_IN_TITLE.search(title or "")
    return int(match.group(1)) if match else None


def _ap_facts(item: models.Item) -> dict:
    try:
        return json.loads(item.raw_cell or "{}")
    except ValueError:
        return {}


def attach_progress_checks(merged: list[models.Item], ap_items: list[models.Item]) -> int:
    """Give the teacher's "APCR" lines the Progress Checks they most likely mean.

    A Physics C doc says "APCR's (2 of them)" on a date and names no unit; AP
    Classroom lists the open Progress Checks with no due dates. Neither alone
    says which is which. The teacher assigns them in unit order, so the doc's
    APCR lines, in date order, are paired with the open (unsubmitted) Progress
    Checks in unit order, as many per line as the line says. The pairing is
    written into the item as a *probable* match — "probably Unit 8 …" — with
    the links to open them, never as a fact the doc stated. Lines with nothing
    left to pair get the subject's assignments page. Returns how many lines
    were given links.
    """
    by_course: dict[str, list[models.Item]] = {}
    for ap in ap_items:
        facts = _ap_facts(ap)
        if "Progress Check" in (ap.kind or "") and facts.get("state") != "submitted" and not ap.submitted:
            by_course.setdefault(ap.course_key, []).append(ap)
    for course_items in by_course.values():
        course_items.sort(key=lambda a: (_ap_facts(a).get("unit") or 999,
                                         0 if "MCQ" in a.title.upper() else 1, a.title))
    dashboards = {ap.course_key: f"https://apclassroom.collegeboard.org/{_ap_facts(ap)['subject_id']}/assignments/dashboard"
                  for ap in ap_items if _ap_facts(ap).get("subject_id")}
    cursor: dict[str, int] = {}
    attached = 0
    lines = [m for m in merged
             if m.source != SOURCE and APCR_TITLE.search(m.title or "")
             and not any((l.kind if hasattr(l, "kind") else l.get("kind")) == "ap_classroom" for l in m.links)]
    lines.sort(key=lambda m: (m.due_date or "9999-99-99", m.title))
    for line in lines:
        pool = by_course.get(line.course_key) or []
        if not pool and line.course_key not in dashboards:
            continue
        count_match = APCR_COUNT.search(line.title or "") or APCR_COUNT.search(line.detail or "")
        wanted = int(count_match.group(1)) if count_match else 1
        start = cursor.get(line.course_key, 0)
        picked = pool[start:start + wanted]
        cursor[line.course_key] = start + len(picked)
        if picked:
            names = ", ".join(p.title for p in picked)
            for p in picked:
                for link in p.links:
                    line.links.append(link)
            line.detail = (line.detail + " — " if line.detail and line.detail != line.title else "") + \
                f"AP Classroom: probably {names} (the next open Progress Check{'s' if len(picked) > 1 else ''}; check the list to be sure)"
            line.merged_from.append(f"{SOURCE}:{','.join(p.item_id for p in picked)}")
        else:
            line.links.append(models.Link(url=dashboards[line.course_key], text="Open AP Classroom assignments", kind="ap_classroom"))
            line.detail = (line.detail + " — " if line.detail and line.detail != line.title else "") + \
                "AP Classroom: no unassigned Progress Check left to pair with this — see the list"
        attached += 1
    return attached


def _too_old_to_show(entry: dict, now: datetime) -> bool:
    """Undated, and opened more than UNDATED_KEEP_DAYS ago (or with no
    opening date at all): open practice, not something due."""
    if entry.get("due"):
        return False
    opened = _parse_when(entry.get("assigned"))
    return opened is None or (now - opened).days > UNDATED_KEEP_DAYS


def summary() -> dict | None:
    """What the last hand-off said, for the run's diagnostics: when it was
    read, how many assignments and subjects, the error if any, and the field
    names the content script saw — so a change in AP Classroom's JSON shows
    up in Settings rather than as a quietly empty feed. Never a token."""
    # Switched off means gone, not merely ignored: a diagnostics block keeps
    # the connector in Settings and in the run's report. [ASKED] 2026-09-20.
    if not enabled():
        return None
    data = load_handoff()
    if data is None:
        return None
    diag = data.get("diagnostics") or {}
    return {"read_at": data.get("read_at"),
            "undated_keep_days": UNDATED_KEEP_DAYS,
            "reader_version": data.get("reader_version"),
            "assignments": len(data.get("assignments") or []),
            "subjects": [s.get("name") for s in (data.get("subjects") or []) if isinstance(s, dict)],
            "error": data.get("error"),
            "assignment_keys": diag.get("assignment_keys"),
            "resource_keys": diag.get("resource_keys"),
            "subject_keys": diag.get("subject_keys"),
            "per_subject": diag.get("per_subject"),
            # presence and expiry of the page's token, never the token
            "sign_in": diag.get("sign_in"),
            "subject_sample": diag.get("subject_sample"),
            "resource_sample": diag.get("resource_sample"),
            "overview_sample": diag.get("overview_sample"),
            "assignment_sample": diag.get("assignment_sample"),
            "question_lookups": diag.get("question_lookups"),
            "question_errors": diag.get("question_errors"),
            "overview_errors": diag.get("overview_errors"),
            "list_keys": diag.get("list_keys"),
            "me_errors": diag.get("me_errors"),
            "ms": diag.get("ms")}


def items(known_courses: dict[str, str] | None = None,
          now: datetime | None = None) -> tuple[list[models.Item], dict | None]:
    """(items, error) from the hand-off. error is an errors[] entry for the
    pipeline, or None. Config-gated; silent on a Mac that has no hand-off."""
    if not enabled():
        return [], None
    data = load_handoff(now)
    if data is None:
        return [], None
    # Not linked in this Chrome: nothing to read and nothing wrong. [ASKED]
    # 2026-10-07 — the site is linked, then read each time he opens it.
    if data.get("error") == "not linked":
        return [], None
    if data.get("error"):
        return [], {"code": "ap_classroom", "message": str(data["error"]),
                    "fix": "", "needs_human": True, "open_url": SIGN_IN_URL}
    known = known_courses or {}
    read_at = data.get("read_at") or ""
    now = now or datetime.now(timezones.zone())
    out = []
    for entry in data.get("assignments") or []:
        if not isinstance(entry, dict):
            continue
        try:
            item = _to_item(entry, known, read_at, now)
        except ValueError as exc:
            log.warning("apclassroom item skipped: %s", exc)
            continue
        if item:
            out.append(item)
    return out, None


def drop_old_practice(merged: list[models.Item]) -> tuple[list[models.Item], int]:
    """After the merge: standalone AP Classroom items that are undated and were
    opened long ago go, and are counted. A doc or Canvas item that absorbed one
    keeps it (and its link). (items, dropped)."""
    kept = [m for m in merged
            if not (m.source == SOURCE and UNDATED_OLD_FLAG in (m.flags or []))]
    return kept, len(merged) - len(kept)
