"""What SillyBus Lock is told: is today's schoolwork done?

[ASKED] 2026-10-06: "I want an app that is link to the chrome extention and
the exteyion sends the info to the app and the data on the app restrics
stuff" — on this Mac, blocking "all social media and games" by default — and
it unlocks when "Today's work is done", or, his second choice, "do one
assignemt the 30 mins then lock until Today's work is done".

The lock app (lock/ in this repo) holds no school data and makes no
decision about homework: it is told, by whichever SillyBus is open (the
Chrome extension or the Mac app), what this module says. One definition, so
the lock, the Focus gate in Chrome and the banners cannot disagree about
what "due" means — the buckets are `notify.buckets`.

What counts as "today's work", exactly:
  * school work due TODAY or TOMORROW that is not ticked Done — tonight's
    homework is, almost always, due tomorrow, so "today's work" that left it
    out would unlock the games with the evening's homework untouched;
  * not a test or quiz due TODAY: by the evening it has been sat in class,
    and there is nothing left to do about it (tomorrow's still counts — the
    studying is the work, and he ticks it Done when it is studied);
  * not his own Life items (goals, practice, makeup) — those are his, not
    the school's;
  * not undated items, which have no deadline to be late for;
  * not overdue items. They are LISTED, so he sees them, but they do not
    hold the lock: one stale item the extractor got wrong would otherwise
    keep every game shut for good, and a lock that can never open is a lock
    that gets deleted.

The message goes only to 127.0.0.1 (this Mac). It carries the titles of
what is left, for the lock's "still to do" card, and NOT the item ids: the
second unlock rule needs to notice "one more thing was finished", and for that
a short one-way hash of each finished item is enough (`done_keys`).

[ASKED] 2026-10-07, Downtime ("in settings add a thing where you set a down
time or tell the chat to do it"): the message also carries `downtime` from
`sillybus/downtime.py` — whether it is Downtime now, until when, and the
schedule itself, so the lock can keep Downtime on its own while it cannot
hear SillyBus. It rides along signed out too: it holds no school data, and a
lock that forgot Downtime whenever a sign-in expired would not be one.
"""

from __future__ import annotations

import hashlib
from datetime import timedelta

from sillybus import notify
from sillybus.scoring import _due_of

MAX_LISTED = 10
MAX_DONE_KEYS = 200
# Finished work counts toward the 30-minute rule if it was due from a week ago
# onward: doing next week's essay early is still finishing an assignment.
DONE_LOOKBACK_DAYS = 7


def _is_life(item: dict) -> bool:
    return any(str(f).startswith("section:") for f in (item.get("flags") or []))


def _key(item: dict) -> str:
    # `item_id`: [MEASURED] 2026-10-06 the board's items carry item_id and no
    # `id` at all, so every key fell back to course|title|due — and a ticked
    # item that a refresh re-dated or re-titled became "newly finished" and
    # handed out a 30-minute break (prosecution 2026-10-06).
    raw = str(item.get("item_id") or item.get("id")
              or f"{item.get('course')}|{item.get('title')}|{item.get('due')}")
    return hashlib.sha256(("sillybus-lock|" + raw).encode()).hexdigest()[:16]


def _brief(item: dict) -> dict:
    due = _due_of(item)
    title = (item.get("title") or "").strip() or "Untitled"
    if len(title) > 80:
        title = title[:79].rstrip() + "…"
    return {"title": title, "course": (item.get("course") or "").strip()[:40],
            "due": due.isoformat() if due else None}


def _typed_in(item: dict) -> bool:
    """Added by hand in SillyBus. Still counted as work to do, but ticking it
    never earns a break: any number of dated tasks could be typed and ticked
    for a break each (prosecution 2026-10-06)."""
    return item.get("extractor") == "manual"


def _downtime() -> dict | None:
    """Downtime for the message, or None. A config that cannot be read must
    not stop the lock hearing whether the work is done — with None it keeps
    the last schedule it was sent."""
    from sillybus import downtime
    try:
        return downtime.status()
    except Exception:  # noqa: BLE001
        return None


def status(state: dict | None, today, tz: str | None = None, downtime: dict | None = None) -> dict:
    """The whole message, ready to send. `known` is False when there is no
    board yet — the lock treats that as "check first", never as done.
    `downtime` defaults to what config.json says now (downtime.status())."""
    if downtime is None:
        downtime = _downtime()
    if not state:
        return {"known": False, "done": False, "for_date": today.isoformat(),
                "open_count": None, "open": [], "overdue_count": 0,
                "done_keys": [], "tz": tz, "downtime": downtime}
    groups = notify.buckets(state, today)
    pressing = ([i for i in groups["today"] if not _is_life(i) and not notify.is_assessment(i)]
                + [i for i in groups["tomorrow"] if not _is_life(i)])
    overdue = [i for i in groups["overdue"] if not _is_life(i)]

    since = today - timedelta(days=DONE_LOOKBACK_DAYS)
    finished = []
    for item in state.get("items") or []:
        if not item.get("done") or _is_life(item) or _typed_in(item):
            continue
        due = _due_of(item)
        if due is not None and due >= since:
            finished.append(_key(item))

    return {
        "known": True,
        "done": not pressing,
        "for_date": today.isoformat(),
        "open_count": len(pressing),
        "open": [_brief(i) for i in pressing[:MAX_LISTED]],
        "overdue_count": len(overdue),
        "done_keys": sorted(set(finished))[:MAX_DONE_KEYS],
        # The zone `today` was counted in, so the lock counts days the same
        # way — the Mac's own clock can be in another zone.
        "tz": tz,
        # How done_keys are made. 2 = from item_id (2026-10-07); the lock
        # re-baselines a source whose version changes, so the switch from the
        # old keys did not count every finished item as new (round 2).
        "key_version": 2,
        # Downtime ([ASKED] 2026-10-07): set hours when the lock stays shut
        # even on a finished day. See downtime.status().
        "downtime": downtime,
    }
