#!/bin/bash
# Silly Bus AI's app launcher — runs from inside Silly Bus AI.app every time it
# opens. First launch builds the Python environment (the only thing that needs
# a network download and a few minutes), then opens the app window; the rest of
# setup — sign-ins, finding the schedule feed, learning the classes — happens
# INSIDE the app, on its Setup screen, where progress is visible and every step
# can be retried on its own.
#
# It used to run the sign-ins from here, through macOS dialogs and browser
# windows the student had to notice. [MEASURED] 2026-08-25 (twice), 2026-08-26
# and 2026-09-01 on a second Mac: that is the step where setup stopped. A shell
# script cannot show progress, cannot retry one step, and cannot type a saved
# password into a form; the app can do all three.
#
# Nothing here needs an administrator password: uv installs into ~/.local,
# and the Python environment lives inside this app bundle. Mutable state
# (config.json, data/, cache/, logs/, browser_profile/) lives in
# ~/Library/Application Support/Silly Bus AI instead — see the
# SILLYBUS_DATA_HOME comment below for why.
#
# First run is a sequence of named steps, each of which records that it
# finished. A run that dies halfway — a closed sign-in window, wifi dropping
# during the download — resumes at the step that failed instead of starting
# over. Setup takes minutes, and asking a student to sit through the minutes
# they already sat through is how people give up on an app.
#
# SILLYBUS_LAUNCHER_DRY_RUN=1 walks the whole sequence, printing what each
# step would run without running it and without a single dialog. That is what
# tests/test_launcher.py drives; a launcher nothing can exercise is a launcher
# whose failure modes are discovered by students.
#
# TWO MODES (0.23):
#
#   default  — what installed copies up to 0.22 run as Contents/MacOS/sillybus:
#              notifications and dialogs for progress, then `run.py app` opens
#              the pywebview window. Unchanged, because it is how an already-
#              installed copy keeps running until it updates.
#
#   serve    — SILLYBUS_LAUNCHER_MODE=serve. The native Swift app
#              (Contents/MacOS/SillyBusAI) runs this file as
#              Contents/Resources/setup.sh and draws its OWN progress screen,
#              so this mode never shows a notification, a dialog, a window or
#              a browser. It does the same setup, then `run.py serve --detach`,
#              and exits with that command's code (0 = the server answers).
#              Progress goes to SILLYBUS_PROGRESS_FILE, OVERWRITTEN each time
#              with ONE line "STEP|text": STEP is one of start, env, packages,
#              browser, server, done, error. The text is shown to a student as
#              is, so it never names Python, a venv, uv, pip or Terminal — the
#              owner asked for an install "like how I install Claude — not
#              python", and a progress line that says "pip" is python.
#              tests/test_launcher_serve_mode.py holds that rule.

set -uo pipefail

MODE="${SILLYBUS_LAUNCHER_MODE:-}"
SERVE_MODE=""
[ "$MODE" = "serve" ] && SERVE_MODE=1
PROGRESS_FILE="${SILLYBUS_PROGRESS_FILE:-}"

# progress <step> <text> — serve mode only. The Swift app polls the file, so
# it is replaced with a rename, never written in place: a half-written line
# read mid-write would show a student a sentence cut in two. Newlines are
# folded, because the protocol is ONE line.
progress() {
  [ -n "$SERVE_MODE" ] || return 0
  local text
  text="$(printf '%s' "$2" | tr '\n' ' ' | tr -s ' ')"
  echo "[progress] $1|$text"
  [ -n "$PROGRESS_FILE" ] || return 0
  mkdir -p "$(dirname "$PROGRESS_FILE")" 2>/dev/null
  printf '%s|%s\n' "$1" "$text" >"$PROGRESS_FILE.tmp.$$" 2>/dev/null \
    && mv -f "$PROGRESS_FILE.tmp.$$" "$PROGRESS_FILE" 2>/dev/null
  return 0
}

# Where the bundle is. This file runs from two places: Contents/MacOS/sillybus
# (the default-mode launcher of copies up to 0.22) and Contents/Resources/
# setup.sh (run by the native app). "../.." is only right for the first, so
# the bundle is found by walking up to the nearest *.app directory; "../.."
# stays as the fallback for a copy that somehow lives outside one.
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"          # .../Contents/MacOS or .../Contents/Resources
find_bundle() {
  local dir="$SCRIPT_DIR"
  while [ -n "$dir" ] && [ "$dir" != "/" ]; do
    case "$dir" in
      *.app) printf '%s' "$dir"; return 0 ;;
    esac
    dir="$(dirname "$dir")"
  done
  return 1
}
APP_BUNDLE="$(find_bundle)" || APP_BUNDLE="$(cd "$SCRIPT_DIR/../.." && pwd)"   # .../Silly Bus AI.app
HERE="$(cd "$APP_BUNDLE/Contents/Resources/app" 2>/dev/null && pwd)"           # the read-only payload (source only)
if [ -z "$HERE" ] || ! cd "$HERE"; then
  echo "--- FAILED: no payload at $APP_BUNDLE/Contents/Resources/app ---"
  progress error "SillyBus is missing some of its own files. Delete it, then install it again."
  exit 1
fi
export PATH="$HOME/.local/bin:$PATH"

DRY_RUN="${SILLYBUS_LAUNCHER_DRY_RUN:-}"

# All mutable state (config.json, data/, cache/, logs/, browser_profile/)
# lives OUTSIDE the app bundle. A bundle launched normally (not from a
# trusted terminal) can't write inside itself: files copied out of a
# downloaded, quarantined disk image carry a com.apple.provenance attribute
# that os.replace()/rename() refuses to cross for a process without
# elevated trust ([MEASURED] PermissionError/EPERM). A location the app
# creates itself at runtime never inherits that attribute.
DATA_HOME="${SILLYBUS_DATA_HOME:-$HOME/Library/Application Support/Silly Bus AI}"
# The app was SchoolDash until 0.19.0.0. A Mac that ran it has its config,
# venv, browser session and saved homework under the old name; renaming the
# folder (same volume, so instant) keeps all of it instead of starting a
# student over. Only when the new folder does not exist yet — never merge.
OLD_DATA_HOME="$HOME/Library/Application Support/SchoolDash"
if [ -z "${SILLYBUS_DATA_HOME:-}" ] && [ ! -e "$DATA_HOME" ] && [ -d "$OLD_DATA_HOME" ]; then
  mv "$OLD_DATA_HOME" "$DATA_HOME" 2>/dev/null || true
fi
export SILLYBUS_DATA_HOME="$DATA_HOME"

# Python's bytecode cache goes next to the other state, never inside the bundle.
#
# [MEASURED] 2026-08-26: without this, the first import wrote __pycache__/*.pyc
# into Contents/Resources/app, which broke the app's own code signature — "a
# sealed resource is missing or invalid", with every .pyc listed as "file
# added". macOS then refused to launch it: "You can't open the application
# Silly Bus AI because it is not responding." The app destroyed its own signature
# simply by running, so it worked exactly once.
#
# PYTHONPYCACHEPREFIX keeps the speed-up and moves the files out, which is
# better than switching bytecode off. It also means an upgrade cannot leave
# stale .pyc behind next to newer source.
export PYTHONPYCACHEPREFIX="$DATA_HOME/pycache"
mkdir -p "$DATA_HOME/logs" "$DATA_HOME/data"

# One setup at a time, per data home (serve mode). [MEASURED] Prosecution
# round 7: quitting the app mid-setup left this script running, and opening
# the app again started a second one beside it — two uv installs into one
# venv. The app now stops its setup when it quits, but two copies of the app
# (/Applications and ~/Applications), or a copy that crashed, can still
# overlap; so this script re-runs itself under lockf(1) on
# "$DATA_HOME/setup.lock". A second one exits 75 (EX_TEMPFAIL) at once,
# having done nothing, and the native app says "already getting ready" and
# waits for the board. The lock is the kernel's (flock), so a setup that
# dies releases it — there is no stale lock file to clean up. lockf does not
# hand its descriptor to the command, so the server that `serve --detach`
# starts never holds it.
#
# Not in default mode: that ends by exec'ing the window, which would hold the
# lock for as long as the window is open.
#
# Only when the data home is writable: when it is not, there is nowhere for
# the lock, and the check below says so in words a student can act on.
if [ -n "$SERVE_MODE" ] && [ -z "${SILLYBUS_SETUP_LOCKED:-}" ] && [ -x /usr/bin/lockf ] \
   && [ -d "$DATA_HOME" ] && [ -w "$DATA_HOME" ]; then
  export SILLYBUS_SETUP_LOCKED=1
  # By absolute path: the payload folder is already the working directory.
  /usr/bin/lockf -k -t 0 "$DATA_HOME/setup.lock" /bin/bash "$SCRIPT_DIR/$(basename "$0")" "$@"
  code=$?
  if [ "$code" -eq 75 ]; then
    echo "--- another setup is already running for $DATA_HOME — not starting a second ---" >&2
  fi
  exit "$code"
fi

# The Python environment lives beside the other mutable state, NOT inside the
# app bundle.
#
# [MEASURED] with it at $HERE/.venv it did not survive an upgrade. The
# installer replaces Silly Bus AI.app wholesale, which deletes the venv, while
# the "env_ready" marker lives out here and survives — so the next launch
# skipped rebuilding the environment and ran a python that was no longer
# there: ".venv/bin/python: No such file or directory", on every launch,
# forever, with no way for the app to recover on its own.
#
# Anything the installer can replace must not hold state the app needs. The
# bundle is now purely code, and everything that has to outlive it is here.
VENV="$DATA_HOME/venv"
STEPS_DIR="$DATA_HOME/data/.setup"
DONE_MARKER="$DATA_HOME/data/.first_run_complete"
mkdir -p "$STEPS_DIR"

LOG="$DATA_HOME/logs/first_run.log"
if [ -z "$DRY_RUN" ]; then
  exec >>"$LOG" 2>&1
fi
echo "=== launcher run: $(date) ==="

as_escape() {
  printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g'
}

# In serve mode nothing below reaches osascript: the native app owns the
# screen, and a notification popping up beside its own progress screen is two
# apps talking at once. The words still go to the log. Serve mode checks come
# BEFORE the dry-run ones, so a dry run proves serve mode never gets as far as
# the line that would have called osascript.
notify() {
  [ -n "$SERVE_MODE" ] && { echo "[log] $1 — $2"; return 0; }
  [ -n "$DRY_RUN" ] && { echo "[notify] $1 — $2"; return 0; }
  local title body
  title="$(as_escape "$1")"; body="$(as_escape "$2")"
  osascript -e "display notification \"$body\" with title \"Silly Bus AI\" subtitle \"$title\"" >/dev/null 2>&1
}

confirm() {
  [ -n "$SERVE_MODE" ] && { echo "[log] $1"; return 0; }
  [ -n "$DRY_RUN" ] && { echo "[confirm] $1"; return 0; }
  local body
  body="$(as_escape "$1")"
  osascript -e "display dialog \"$body\" with title \"Silly Bus AI\" buttons {\"Continue\"} default button 1" >/dev/null 2>&1
}

# Two buttons, so a step that failed for a reason the student can fix (a
# closed window, wifi that dropped) does not end the whole setup. Returns 0
# for "Try Again". Anything else — Quit, or the dialog failing to appear —
# returns 1, because a launcher that loops forever on a dialog nobody can
# see is worse than one that stops.
ask_retry() {
  [ -n "$SERVE_MODE" ] && { echo "[log] $1"; return 1; }
  [ -n "$DRY_RUN" ] && { echo "[ask_retry] $1"; return 1; }
  local body answer
  body="$(as_escape "$1")"
  answer="$(osascript -e "display dialog \"$body\" with title \"Silly Bus AI — setup\" buttons {\"Quit\", \"Try Again\"} default button \"Try Again\" with icon caution" 2>/dev/null)"
  [ "${answer##*:}" = "Try Again" ]
}

# Every dead end says where the whole story is written down, and offers to
# open it — "check the log" is not actionable if you have never seen a log.
#
# In serve mode the dialog becomes an "error|…" progress line and the exit is
# still non-zero; the native app shows the sentence and can offer the log.
fail() {
  local body answer
  echo "--- FAILED: $1 ---"
  if [ -n "$SERVE_MODE" ]; then
    progress error "$1 Everything setup did is written down in $LOG — opening SillyBus again picks up where this left off."
    exit 1
  fi
  [ -n "$DRY_RUN" ] && { echo "[fail] $1"; exit 1; }
  body="$(as_escape "$1

Everything setup did is written down in first_run.log. Reopening Silly Bus AI picks up where this left off — nothing you already did has to be done twice.")"
  answer="$(osascript -e "display dialog \"$body\" with title \"Silly Bus AI — setup problem\" buttons {\"Show Log\", \"OK\"} default button \"OK\" with icon caution" 2>/dev/null)"
  [ "${answer##*:}" = "Show Log" ] && open -R "$LOG" >/dev/null 2>&1
  exit 1
}

# --- step bookkeeping -------------------------------------------------------

# A step counts as done only if the thing it was supposed to produce is still
# there. Trusting the flag alone is what turned one deleted directory into an
# app that could never start again — the marker said "environment ready" long
# after the environment had been thrown away. Markers record intent; these
# checks record reality, and reality wins.
step_precondition_met() {
  case "$1" in
    env_ready)     [ -x "$VENV/bin/python" ] ;;
    browser_ready) [ -x "$VENV/bin/python" ] ;;
    *)             return 0 ;;
  esac
}

step_done() {
  [ -f "$STEPS_DIR/$1" ] || return 1
  if step_precondition_met "$1"; then
    return 0
  fi
  echo "--- $1: marked done but its result is missing — redoing it ---"
  rm -f "$STEPS_DIR/$1"
  return 1
}

mark_step()  { : >"$STEPS_DIR/$1"; }

# run_step <name> <description> <command...>
# Skips a step that already finished; records the ones that do.
run_step() {
  local name="$1" description="$2"; shift 2
  if step_done "$name"; then
    echo "--- $name: already done, skipping ---"
    return 0
  fi
  echo "--- $name: $description ---"
  if [ -n "$DRY_RUN" ]; then
    echo "[would run] $*"
    mark_step "$name"
    return 0
  fi
  if "$@"; then
    mark_step "$name"
    return 0
  fi
  return $?
}

# --- preflight -------------------------------------------------------------

# Running straight from the disk image cannot work: the payload is read-only,
# so the Python environment has nowhere to go. Say so instead of failing four
# steps later with a permissions error.
#
# */AppTranslocation/* is the other read-only place (round 7): a copy opened
# before it was moved out of Downloads, which macOS runs from a random
# folder. Same two shapes as update.py's _cannot_write. The native app checks
# both before it runs this at all; this is the backstop.
case "$APP_BUNDLE" in
  /Volumes/*)
    fail "Silly Bus AI is still inside the disk image, which is read-only.

Drag Silly Bus AI to your Applications folder (or your Desktop) first, then open it from there."
    ;;
  */AppTranslocation/*)
    fail "macOS is running Silly Bus AI from a temporary, read-only place because it hasn't been moved yet.

Drag Silly Bus AI to your Applications folder first, then open it from there."
    ;;
esac

# Nothing is written inside the bundle any more, so it does not need to be
# writable — only the data directory does.
if ! mkdir -p "$DATA_HOME" 2>/dev/null || [ ! -w "$DATA_HOME" ]; then
  fail "Silly Bus AI cannot write to its data folder:

$DATA_HOME

Check that your home folder is not full or locked down, then open it again."
fi

# --- first run -------------------------------------------------------------

if [ ! -f "$DONE_MARKER" ]; then
  if step_done env_ready; then
    notify "Setting up" "Picking up where setup left off…"
    progress start "Picking up where setup left off…"
  else
    notify "Welcome to Silly Bus AI" "One-time setup: a few minutes of downloading, then the app opens."
    progress start "Getting SillyBus ready — this only happens the first time (about 2 minutes)"
  fi
else
  progress start "Opening SillyBus…"
fi

if [ ! -f "$DONE_MARKER" ]; then

  # ---- Python -------------------------------------------------------------
  if ! step_done env_ready; then
    # The student-facing words never say "Python" (0.23): the owner asked for
    # an install "like how I install Claude — not python".
    notify "Setting up" "Getting SillyBus ready…"
    progress env "Setting up the parts SillyBus runs on…"
    echo "--- checking for uv ---"
    if ! command -v uv >/dev/null 2>&1; then
      echo "--- installing uv ---"
      if [ -z "$DRY_RUN" ]; then
        curl -LsSf https://astral.sh/uv/install.sh | sh \
          || fail "Could not download what Silly Bus AI needs to run. Check your internet connection, then reopen Silly Bus AI to try again."
      fi
      export PATH="$HOME/.local/bin:$PATH"
    fi
    if [ -z "$DRY_RUN" ]; then
      command -v uv \
        || fail "Setup did not finish. Reopen Silly Bus AI to try again."
      if [ ! -x "$VENV/bin/python" ]; then
        echo "--- uv venv ---"
        uv venv --python 3.12 "$VENV" \
          || fail "Could not set up the parts Silly Bus AI runs on. Reopen Silly Bus AI to try again."
      fi
      notify "Setting up" "Installing what it needs…"
      progress packages "Downloading what SillyBus needs…"
      echo "--- uv pip install ---"
      VIRTUAL_ENV="$VENV" uv pip install -q -r requirements.txt \
        || fail "Could not download what Silly Bus AI needs. Check your internet connection, then reopen Silly Bus AI to try again."
    else
      progress packages "Downloading what SillyBus needs…"
      echo "[would run] uv venv --python 3.12 $VENV"
      echo "[would run] uv pip install -q -r requirements.txt"
      # A dry run still leaves the artifact behind, because the steps that
      # follow now check for it. Simulating "the environment was built" while
      # leaving no environment would make the dry run disagree with reality on
      # exactly the point these checks exist to catch.
      mkdir -p "$VENV/bin"
      printf '#!/bin/sh\nexit 0\n' >"$VENV/bin/python"
      chmod +x "$VENV/bin/python"
    fi
    mark_step env_ready
  else
    echo "--- env_ready: already done, skipping ---"
  fi

  PY="$VENV/bin/python"
  [ -n "$DRY_RUN" ] && PY="python3"
fi

# ---- upgrades: new dependencies -------------------------------------------
#
# The environment is built once, but requirements.txt changes with the app
# (pywebview and pypdf arrived in 0.12). The env_ready marker says "an
# environment exists", not "it has everything this version needs", so the
# requirements file's hash is remembered and a change reinstalls.
REQ_HASH_FILE="$STEPS_DIR/requirements.sha"
REQ_HASH="$(shasum -a 256 requirements.txt 2>/dev/null | cut -d' ' -f1)"
if [ -n "$REQ_HASH" ] && [ "$(cat "$REQ_HASH_FILE" 2>/dev/null)" != "$REQ_HASH" ]; then
  if [ -f "$REQ_HASH_FILE" ]; then
    echo "--- requirements changed since the last install — updating ---"
    notify "Updating" "Installing what this version needs…"
    progress packages "Downloading what this version of SillyBus needs…"
  fi
  if [ -n "$DRY_RUN" ]; then
    echo "[would run] uv pip install -q -r requirements.txt"
    printf '%s' "$REQ_HASH" >"$REQ_HASH_FILE"
  else
    export PATH="$HOME/.local/bin:$PATH"
    # The hash is written ONLY on success. [MEASURED] 2026-09-02: it used to be
    # written either way, so one failed install — a dropped connection during
    # an upgrade — marked this version's libraries as done and they were never
    # retried. pywebview is one of them, and without it the app opens a
    # browser tab instead of its own window, for good. "Some features may be
    # missing until the next launch" was not true: there was no next attempt.
    if VIRTUAL_ENV="$VENV" uv pip install -q -r requirements.txt; then
      printf '%s' "$REQ_HASH" >"$REQ_HASH_FILE"
    else
      notify "Heads up" "Could not finish downloading this version's updates. Reopen Silly Bus AI to try again."
    fi
  fi
fi

# Belt and braces on the one library whose absence changes what the app IS.
# pywebview arrived in 0.12, and an install carried across that boundary can
# have a matching requirements hash and no window: the hash only notices when
# requirements.txt itself changes, not when an install of it half-worked.
#
# Not in serve mode: there the native app IS the window, and pywebview is
# never imported. Installing a window library nothing uses would only add a
# download to a student's first minutes.
if [ -z "$SERVE_MODE" ] && [ -z "$DRY_RUN" ] && [ -x "$VENV/bin/python" ]; then
  if ! "$VENV/bin/python" -c 'import webview' >/dev/null 2>&1; then
    echo "--- pywebview missing — installing it so the app opens in its own window ---"
    notify "Finishing an update" "Installing one more library so Silly Bus AI opens in its own window…"
    export PATH="$HOME/.local/bin:$PATH"
    VIRTUAL_ENV="$VENV" uv pip install -q pywebview \
      || notify "Heads up" "Silly Bus AI will open in your browser this time. Reopen it later to try again."
  fi
fi

if [ ! -f "$DONE_MARKER" ]; then
  PY="$VENV/bin/python"
  [ -n "$DRY_RUN" ] && PY="python3"

  # ---- the browser for signing in -----------------------------------------
  #
  # Playwright's bundled Chromium is a 150 MB download and Google sign-in
  # rejects it, so sillybus/browser.py only ever reaches for it after real
  # Chrome and Edge have both failed. On a Mac that has Chrome — which is
  # every Mac this is aimed at — downloading it is minutes of a student's
  # evening spent fetching a browser that will not be used. So: only when
  # there is no system browser to drive.
  if ! step_done browser_ready; then
    if [ -d "/Applications/Google Chrome.app" ] || [ -d "/Applications/Microsoft Edge.app" ] \
       || [ -d "$HOME/Applications/Google Chrome.app" ] || [ -d "$HOME/Applications/Microsoft Edge.app" ]; then
      echo "--- browser_ready: system Chrome/Edge found, skipping the 150 MB Chromium download ---"
      mark_step browser_ready
    else
      notify "Setting up" "Downloading the browser used for signing in (about 150 MB)…"
      progress browser "Downloading the browser SillyBus uses to sign in to school sites (about 150 MB)…"
      echo "--- playwright install chromium ---"
      if [ -n "$DRY_RUN" ]; then
        echo "[would run] $PY -m playwright install chromium"
        mark_step browser_ready
      elif "$PY" -m playwright install chromium; then
        mark_step browser_ready
      else
        notify "Heads up" "The browser download failed — signing in may not work yet."
      fi
    fi
  else
    echo "--- browser_ready: already done, skipping ---"
  fi

  [ -f "$DATA_HOME/config.json" ] || cp config.example.json "$DATA_HOME/config.json"

  # Everything that used to follow here — the two sign-ins, run.py setup, the
  # first refresh, the reminders — now lives on the app's Setup screen
  # (/setup). The launcher's job ends once Python is ready.

  # ---- Dock ---------------------------------------------------------------
  if ! step_done dock_pin; then
    echo "--- dock pin ---"
    if [ -n "$DRY_RUN" ]; then
      echo "[would run] defaults write com.apple.dock persistent-apps (for $APP_BUNDLE)"
    elif ! defaults read com.apple.dock persistent-apps 2>/dev/null | grep -qF "$APP_BUNDLE"; then
      defaults write com.apple.dock persistent-apps -array-add \
        "<dict><key>tile-data</key><dict><key>file-data</key><dict><key>_CFURLString</key><string>$APP_BUNDLE</string><key>_CFURLStringType</key><integer>0</integer></dict></dict></dict>"
      killall Dock
    fi
    mark_step dock_pin
  else
    echo "--- dock_pin: already done, skipping ---"
  fi

  : >"$DONE_MARKER"
  notify "Ready" "Opening Silly Bus AI — finish setting up on the screen that appears."
  echo "--- first run complete ---"
fi

# The app window (pywebview). `run.py app` starts the server if it is not
# already answering and opens the window on it; a fresh install lands on the
# Setup screen because the page itself notices nothing is connected yet.
#
# Serve mode stops short of that: the native app is the window, so this starts
# the server (or leaves a current one running — serve_detached replaces one
# that is still on an older build, so an update always serves the new code)
# and hands back its exit code. Not exec'd, because the last progress line has
# to be written after it answers.
if [ -n "$SERVE_MODE" ]; then
  progress server "Starting SillyBus…"
  echo "--- run.py serve --detach ---"
  if [ -n "$DRY_RUN" ]; then
    echo "[would run] $VENV/bin/python run.py serve --detach"
    code=0
  else
    "$VENV/bin/python" run.py serve --detach
    code=$?
  fi
  if [ "$code" -eq 0 ]; then
    progress done "Ready"
  else
    progress error "SillyBus could not start. Quit it and open it again; if this keeps happening, the details are in the logs folder: $DATA_HOME/logs"
  fi
  exit "$code"
fi

echo "--- exec run.py app ---"

if [ -n "$DRY_RUN" ]; then
  echo "[would run] $VENV/bin/python run.py app"
  exit 0
fi

exec "$VENV/bin/python" run.py app
